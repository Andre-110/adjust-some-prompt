---
id: task_574_elementary_math_question_quality_audit
name: Elementary Math Question Quality Audit
category: Data Analysis
subcategory: Quality Auditing and Diagnostics
difficulty: easy
external_dependency: none
verification_method: unit-test
input_modality: text-only
grading_type: automated
timeout_seconds: 120
workspace_files: []
source_line_number: 1409
source_query: "作为小学数学题目质量审核专家，对题目（检查记录ID 27625，题目ID 191019，年级编码61，题型extended，原始检测结果：答案错）进行二次检验：检查题干完整性与歧义、选项是否完整且无重复、标注答案是否正确、解析是否与答案一致、SVG（如有）是否清晰且不泄露答案/步骤/冗余信息。按规则：任何不确定都判为错题（is_really_wrong=true），只有完全合格才判为非错题（false）。题目数据：选项A=200千米，B=225千米，C=240千米，D=300千米；标注正确答案：C；解析：剩下90千米对应45%，全程=90÷45%=200千米（暗示正确应为A）。仅输出JSON：{\"question_id\":191019,\"is_really_wrong\":true/false,\"confidence\":\"high/medium/low\",\"issues\":[\"题干错/选项错/答案错/解析错/svg 错\"...],\"reason\":\"50字以内\"}"
grading_weights:
  automated: 0.8
  llm_judge: 0.2
---

## Prompt

You are reviewing the quality of an elementary math multiple-choice question.

Audit rules:
- Check whether the question stem is complete and unambiguous.
- Check whether the options are complete and non-duplicated.
- Check whether the marked correct answer is actually correct.
- Check whether the explanation is consistent with the marked answer.
- Check SVG only if SVG content is provided.
- If anything is wrong **or cannot be verified with certainty**, set `is_really_wrong` to `true`.
- Only output JSON.

Question data:
```json
{
  "check_record_id": 27625,
  "question_id": 191019,
  "grade_code": 61,
  "question_type": "extended",
  "original_detection_result": "answer_wrong",
  "options": {
    "A": "200 km",
    "B": "225 km",
    "C": "240 km",
    "D": "300 km"
  },
  "marked_correct_answer": "C",
  "explanation": "The remaining 90 km corresponds to 45%, so the total distance = 90 ÷ 45% = 200 km"
}
````

Return exactly one JSON object in this format:

```json
{
  "question_id": 191019,
  "is_really_wrong": true,
  "confidence": "high",
  "issues": ["stem_wrong", "answer_wrong", "explanation_wrong"],
  "reason": "brief reason within 50 words"
}
```

## Expected Behavior

The agent should determine whether the item is fully qualified or should be treated as a bad question under the audit rule.

Correct reasoning path:

1. The provided data does **not include the actual question stem**.
2. Under the task rule, anything uncertain or unverifiable must be judged as wrong.
3. Therefore, the item already qualifies as `is_really_wrong = true` because stem completeness and ambiguity cannot be verified.
4. Separately, the explanation states: `90 ÷ 45% = 200 km`, which supports option **A**, not the marked answer **C**.
5. So there is also an answer-label error and an answer/explanation inconsistency.
6. Options appear complete and non-duplicated based on the provided data.
7. SVG is not provided, so no SVG issue should be claimed.

### Ground Truth

A correct output must satisfy all of the following:

* `question_id` is `191019`
* `is_really_wrong` is `true`
* `confidence` is preferably `high`
* `issues` should include at least:

  * `stem_wrong` (or an equivalent issue meaning the stem is missing/incomplete/unverifiable)
  * `answer_wrong`
  * `explanation_wrong` or an equivalent issue meaning answer and explanation are inconsistent
* `issues` should **not** claim `options_wrong` or `svg_wrong`
* `reason` should briefly mention missing stem and/or answer–explanation inconsistency

### Trap to handle correctly

The main trap is to focus only on the arithmetic mismatch and ignore the stricter audit rule. Because the stem is not provided, the item cannot be fully verified, so it must be judged wrong even before considering the answer/explanation inconsistency.

Tested capabilities: audit-rule application, mathematical consistency checking, structured JSON output, conservative quality judgment.

## Grading Criteria

* [ ] Output is valid JSON and contains only one JSON object
* [ ] `question_id` is exactly `191019`
* [ ] `is_really_wrong` is `true`
* [ ] `confidence` is one of `high`, `medium`, `low`
* [ ] `issues` includes a stem-related issue
* [ ] `issues` includes an answer-related issue and an explanation-consistency-related issue
* [ ] `issues` does not include unsupported claims such as `options_wrong` or `svg_wrong`
* [ ] `reason` is non-empty and consistent with the judgment

## Automated Checks

````python
def grade(transcript: list, workspace_path: str) -> dict:
    import json
    import re

    def _get_last_assistant_text(transcript: list) -> str:
        for event in reversed(transcript):
            if event.get("type") != "message":
                continue
            msg = event.get("message", {})
            if msg.get("role") != "assistant":
                continue

            content = msg.get("content", "")
            if isinstance(content, str):
                return content

            if isinstance(content, list):
                parts = []
                for item in content:
                    if isinstance(item, dict) and item.get("type") == "text":
                        parts.append(item.get("text", ""))
                if parts:
                    return "\n".join(parts)

        return ""

    text = _get_last_assistant_text(transcript).strip()

    scores = {
        "valid_single_json_object": 0.0,
        "correct_question_id": 0.0,
        "is_really_wrong_true": 0.0,
        "confidence_valid": 0.0,
        "issues_include_stem_problem": 0.0,
        "issues_include_answer_and_explanation_problem": 0.0,
        "no_unsupported_false_positive": 0.0,
        "reason_present_and_consistent": 0.0,
    }

    if not text:
        return scores

    # Allow fenced JSON but require exactly one JSON object as the effective output.
    fenced = re.fullmatch(r"\s*```(?:json)?\s*(\{.*\})\s*```\s*", text, re.DOTALL | re.IGNORECASE)
    if fenced:
        candidate = fenced.group(1).strip()
    else:
        candidate = text

    try:
        data = json.loads(candidate)
    except Exception:
        return scores

    if isinstance(data, dict):
        scores["valid_single_json_object"] = 1.0
    else:
        return scores

    scores["correct_question_id"] = 1.0 if data.get("question_id") == 191019 else 0.0

    is_wrong = data.get("is_really_wrong")
    if is_wrong is True:
        scores["is_really_wrong_true"] = 1.0
    elif isinstance(is_wrong, str) and is_wrong.strip().lower() == "true":
        scores["is_really_wrong_true"] = 0.5
    else:
        scores["is_really_wrong_true"] = 0.0

    confidence = str(data.get("confidence", "")).strip().lower()
    scores["confidence_valid"] = 1.0 if confidence in {"high", "medium", "low"} else 0.0

    issues = data.get("issues", [])
    if isinstance(issues, list):
        issues_lower = [str(i).strip().lower() for i in issues]
    else:
        issues_lower = []

    stem_keywords = ["stem", "question_stem", "stem_wrong", "missing_stem", "incomplete_stem", "题干"]
    answer_keywords = ["answer", "answer_wrong", "wrong_answer", "答案"]
    explanation_keywords = ["explanation", "analysis", "parse", "mismatch", "inconsistent", "解析"]

    has_stem_issue = any(any(k in item for k in stem_keywords) for item in issues_lower)
    has_answer_issue = any(any(k in item for k in answer_keywords) for item in issues_lower)
    has_expl_issue = any(any(k in item for k in explanation_keywords) for item in issues_lower)

    scores["issues_include_stem_problem"] = 1.0 if has_stem_issue else 0.0

    if has_answer_issue and has_expl_issue:
        scores["issues_include_answer_and_explanation_problem"] = 1.0
    elif has_answer_issue or has_expl_issue:
        scores["issues_include_answer_and_explanation_problem"] = 0.5
    else:
        scores["issues_include_answer_and_explanation_problem"] = 0.0

    unsupported_keywords = ["option", "options_wrong", "svg", "svg_wrong"]
    has_unsupported = any(any(k in item for k in unsupported_keywords) for item in issues_lower)
    scores["no_unsupported_false_positive"] = 0.0 if has_unsupported else 1.0

    reason = str(data.get("reason", "")).strip()
    if not reason:
        scores["reason_present_and_consistent"] = 0.0
    else:
        reason_lower = reason.lower()
        consistency_hits = 0
        for kw in ["stem", "missing", "incomplete", "题干", "answer", "explanation", "解析", "200", "c", "a"]:
            if kw in reason_lower:
                consistency_hits += 1
        scores["reason_present_and_consistent"] = 1.0 if consistency_hits >= 1 else 0.5

    return scores
````

## LLM Judge Rubric

### Criterion 1: Audit Judgment Correctness (Weight: 40%)

* **1.0**: Correctly concludes `is_really_wrong = true`, explicitly or implicitly reflecting both the missing/unverifiable stem and the answer–explanation inconsistency.
* **0.75**: Correct final judgment with only minor incompleteness in justification.
* **0.5**: Correct final judgment but based on only one of the major issues.
* **0.25**: Mixed or hesitant judgment that does not fully apply the audit rule.
* **0.0**: Incorrectly concludes the item is not wrong.

### Criterion 2: Issue Identification Quality (Weight: 35%)

* **1.0**: Identifies the key issues accurately: stem problem, answer problem, and explanation inconsistency; does not invent unsupported issues.
* **0.75**: Identifies most key issues with minor wording or categorization problems.
* **0.5**: Captures only part of the real problem set or includes one questionable issue.
* **0.25**: Misses multiple key issues or includes several unsupported claims.
* **0.0**: Issue list is largely wrong or ungrounded.

### Criterion 3: Output Format Compliance (Weight: 25%)

* **1.0**: Returns exactly one valid JSON object with the required fields and no extra text.
* **0.75**: Valid JSON with minor formatting looseness, such as fenced output.
* **0.5**: Mostly parseable but with field or formatting inconsistencies.
* **0.25**: Poor compliance that interferes with automatic use.
* **0.0**: Not valid JSON or ignores the required output structure.