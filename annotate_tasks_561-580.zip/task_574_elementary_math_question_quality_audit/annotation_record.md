| 序号 | 修改项 | 修改原因 |
|---|---|---|
| 1 | 将 `difficulty` 从 `medium` 改为 `easy` | 给定数据已足以直接判错，推理链短，且输出结构固定，难度与 easy 更匹配 |
| 2 | 重写 `## Prompt` | 原 Prompt 直接提示“这看起来不匹配”，明显泄露答案；新版本保留任务要求但去掉答案暗示 |
| 3 | 在 `Expected Behavior` 中补充“题干缺失即判错” | 原版本只强调答案与解析不一致，漏掉了更关键的“任何不确定都判错”规则应用 |
| 4 | 新增 `Ground Truth` | 原文件没有完整、可验证的 Ground Truth 条件集合 |
| 5 | 新增 `Trap to handle correctly` | 明确指出不要只看算术冲突，还要执行“题干缺失即错”的保守审核规则 |
| 6 | 重写 `Grading Criteria` | 使条目与任务关键能力和 score key 精确对应，并增强独立可验证性 |
| 7 | 重写 `grade()` 的输出提取与 JSON 校验 | 原逻辑会从任意文本中正则抠 JSON，过宽松；现要求有效输出整体就是单个 JSON 对象（可容忍 fenced JSON） |
| 8 | 为 `is_really_wrong` 增加部分得分 | 原逻辑仅 0/1；现对字符串 `"true"` 给 0.5，支持部分得分 |
| 9 | 强化 `issues` 检查 | 原逻辑只要 issue 中出现模糊错误关键词就通过，现分别检查 stem、answer、explanation 三类核心问题 |
| 10 | 增加对 unsupported false positives 的限制 | 原逻辑虽有负向检查，但粒度较粗；现明确限制 `options_wrong`、`svg_wrong` 等无依据问题 |
| 11 | 调整 `reason` 校验 | 原逻辑只检查非空，现增加与判断结果的一致性检查 |
| 12 | 补充 `grading_weights` | 原文件缺少 automated 与 llm_judge 权重配置，不满足规范 |
| 13 | 新增 `LLM Judge Rubric` | 原文件缺失 Rubric，不满足维度 E 的要求 |
| 14 | 设置 3 个 Rubric 维度且权重和为 100% | 满足“维度充分、权重正确、等级描述清晰”的要求 |