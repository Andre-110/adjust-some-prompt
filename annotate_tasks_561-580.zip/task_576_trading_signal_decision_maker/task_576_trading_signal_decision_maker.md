---
id: task_576_trading_signal_decision_maker
name: Trading Signal Decision Maker
category: Finance
subcategory: Trading Strategy and Backtesting
difficulty: medium
external_dependency: none
verification_method: unit-test
input_modality: text-only
grading_type: hybrid
grading_weights:
  automated: 0.4
  llm_judge: 0.6
timeout_seconds: 120
workspace_files: []
source_line_number: 2722
source_query: "Given the following trading signal, market data, and portfolio status, decide whether to trade (BUY/SELL/HOLD), choose a position size as a percentage of available capital (0–20%), assess risk (low/medium/high), and provide detailed rationale and key factors. Signal: SELL (confidence HIGH). Patterns detected: three_white_soldiers, double_bottom, double_top. Market: current price $53.15; trend uptrend; volume vs average 1.75x; ATR $2.31; price above EMA20. Portfolio: available cash $1,000,000;..."
---

## Prompt

Hey, I need you to analyze this trading setup and make a decision based only on the information below.

Signal:
- SELL with HIGH confidence

Patterns detected:
- three_white_soldiers
- double_bottom
- double_top

Market data:
- Current price: $53.15
- Trend: uptrend
- Volume vs average: 1.75x
- ATR: $2.31
- Price is above EMA20

Portfolio:
- Available cash: $1,000,000
- Current position: 0 shares
- Total portfolio value: $1,000,000

Please decide:
1. Whether to trade (`BUY`, `SELL`, or `HOLD`)
2. What percentage of available capital to use (`0`-`20`)
3. Risk level (`low`, `medium`, or `high`)
4. Why you are recommending this decision
5. Key factors behind the decision

Important:
- Use only the provided information
- Consider the conflict between the signal, the detected patterns, the broader market context, and the fact that the current position is `0 shares`
- Save the answer to `trading_decision.json`
- Output must be valid JSON with exactly these fields:

```json
{
  "action": "BUY|SELL|HOLD",
  "position_size_pct": 0,
  "risk_assessment": "low|medium|high",
  "rationale": "your explanation here",
  "key_factors": ["factor1", "factor2"]
}
````

## Expected Behavior

The agent should:

1. Create `trading_decision.json` containing a valid JSON object.
2. Recognize that the inputs are internally conflicting:

   * the primary signal says `SELL`
   * the market context is partly bullish (`uptrend`, `price above EMA20`, `three_white_soldiers`, `double_bottom`)
   * one detected pattern (`double_top`) is bearish
3. Notice that the portfolio currently has `0 shares`, which means a literal `SELL` trade is not operationally executable as a normal long-position exit.
4. Make a reasoned recommendation that reflects both:

   * signal conflict / uncertainty
   * current portfolio constraints
5. Provide a rationale grounded only in the provided data.
6. Include a non-empty `key_factors` array summarizing the main reasons for the decision.

Traps / special handling:

* The task is **not** asking for unsupported assumptions such as earnings, macro events, dividends, or news.
* The agent should **not** invent additional market context.
* A strong answer should recognize that a `SELL` signal conflicts with several bullish indicators.
* A strong answer should also recognize that `0 shares` makes a sell action questionable or non-executable in a standard long-only interpretation.
* Because of the conflict and execution constraint, `HOLD` with `0` position size is the most defensible default outcome, though another answer may be acceptable if it is exceptionally well justified and remains consistent with the provided constraints.

Ground truth:

* The answer must be saved as `trading_decision.json`.
* The output must be valid JSON with the required five fields.
* The reasoning should acknowledge the mixed/contradictory evidence.
* The reasoning should avoid fabricated facts.
* The most reasonable default decision is `HOLD` with conservative sizing because the setup is conflicted and the account currently has no shares to sell.

Tested capabilities: conflict resolution, portfolio-aware decision making, structured JSON generation, instruction following.

## Grading Criteria

* [ ] File `trading_decision.json` exists
* [ ] File contains valid JSON with all required fields
* [ ] `action` is one of `BUY`, `SELL`, or `HOLD`
* [ ] `position_size_pct` is numeric and between `0` and `20`
* [ ] `risk_assessment` is one of `low`, `medium`, or `high` (case-insensitive)
* [ ] `key_factors` is a non-empty array with relevant factors
* [ ] `rationale` reflects the conflict between the SELL signal and bullish market/pattern evidence
* [ ] `rationale` or final decision reflects awareness that current position is `0 shares`
* [ ] Output does not introduce unsupported external facts

## LLM Judge Rubric

### 1. Conflict Recognition and Decision Quality (35%)

**1.0** - Clearly identifies the conflict between the SELL signal and bullish evidence, and reaches a well-justified decision that is consistent with both the signal ambiguity and portfolio state.
**0.75** - Recognizes most of the conflict and gives a mostly reasonable decision, though some nuance is missing.
**0.5** - Shows partial awareness of the conflict but the final decision is under-justified or somewhat inconsistent.
**0.25** - Barely addresses the conflicting information or gives a weakly supported decision.
**0.0** - Ignores the conflicting evidence and provides an unjustified or clearly inconsistent decision.

### 2. Risk Calibration and Position Sizing (25%)

**1.0** - Risk level and position size are conservative and clearly aligned with the uncertainty and current holdings.
**0.75** - Risk and size are mostly appropriate, with only minor mismatch to the setup.
**0.5** - Risk or sizing is somewhat plausible but not well calibrated to the conflicting evidence.
**0.25** - Risk and sizing are poorly matched to the situation.
**0.0** - Risk and sizing are clearly unreasonable or invalid.

### 3. Rationale Specificity and Data Grounding (25%)

**1.0** - Rationale is specific, coherent, and grounded entirely in the provided signal, pattern, market, and portfolio inputs.
**0.75** - Rationale is mostly grounded and coherent, with minor vagueness.
**0.5** - Rationale uses some provided data but remains generic or incomplete.
**0.25** - Rationale is weak, generic, or only loosely tied to the provided inputs.
**0.0** - Rationale is missing, fabricated, or not grounded in the given data.

### 4. JSON and Instruction Compliance (15%)

**1.0** - Output format and field structure are fully correct, with all required fields and no extra unsupported content.
**0.75** - Minor formatting or completeness issues, but mostly compliant.
**0.5** - Some required structure is present, but there are noticeable compliance problems.
**0.25** - Significant formatting or instruction-following issues.
**0.0** - Output does not follow the required JSON/file structure in a meaningful way.

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    from pathlib import Path
    import json

    ws = Path(workspace_path)

    scores = {
        "file_exists": 0.0,
        "valid_json_with_required_fields": 0.0,
        "valid_action": 0.0,
        "valid_position_size": 0.0,
        "valid_risk": 0.0,
        "has_key_factors": 0.0,
        "rationale_recognizes_conflict": 0.0,
        "recognizes_zero_position_constraint": 0.0,
        "no_unsupported_facts": 0.0,
    }

    decision_file = ws / "trading_decision.json"
    if not decision_file.exists():
        return scores

    scores["file_exists"] = 1.0

    try:
        raw = decision_file.read_text(encoding="utf-8", errors="ignore")
    except Exception:
        raw = ""

    try:
        data = json.loads(raw)
    except Exception:
        return scores

    required_fields = ["action", "position_size_pct", "risk_assessment", "rationale", "key_factors"]
    present_count = sum(1 for f in required_fields if f in data)
    scores["valid_json_with_required_fields"] = present_count / len(required_fields)

    action = str(data.get("action", "")).strip().upper()
    if action in {"BUY", "SELL", "HOLD"}:
        scores["valid_action"] = 1.0

    pos_size = data.get("position_size_pct")
    try:
        pos_val = float(pos_size)
        if 0 <= pos_val <= 20:
            scores["valid_position_size"] = 1.0
        elif -0.01 <= pos_val <= 25:
            scores["valid_position_size"] = 0.5
    except Exception:
        scores["valid_position_size"] = 0.0

    risk = str(data.get("risk_assessment", "")).strip().lower()
    if risk in {"low", "medium", "high"}:
        scores["valid_risk"] = 1.0

    key_factors = data.get("key_factors", [])
    if isinstance(key_factors, list):
        if len(key_factors) >= 2:
            scores["has_key_factors"] = 1.0
        elif len(key_factors) == 1:
            scores["has_key_factors"] = 0.5

    rationale = str(data.get("rationale", "")).lower()
    key_factors_text = " ".join(str(x).lower() for x in key_factors) if isinstance(key_factors, list) else ""
    combined = rationale + " " + key_factors_text

    bullish_terms = [
        "uptrend", "above ema20", "ema20", "three_white_soldiers",
        "three white soldiers", "double_bottom", "double bottom"
    ]
    bearish_terms = ["sell", "double_top", "double top"]
    conflict_hits = 0
    if any(term in combined for term in bullish_terms):
        conflict_hits += 1
    if any(term in combined for term in bearish_terms):
        conflict_hits += 1
    if any(word in combined for word in ["conflict", "mixed", "contradict", "uncertain", "uncertainty"]):
        conflict_hits += 1

    if conflict_hits >= 3:
        scores["rationale_recognizes_conflict"] = 1.0
    elif conflict_hits == 2:
        scores["rationale_recognizes_conflict"] = 0.5

    zero_position_terms = [
        "0 shares", "no shares", "no holdings", "empty position",
        "current position is 0", "cannot sell", "nothing to sell"
    ]
    if any(term in combined for term in zero_position_terms):
        scores["recognizes_zero_position_constraint"] = 1.0
    elif action == "HOLD" and str(data.get("position_size_pct", "")).strip() in {"0", "0.0"}:
        scores["recognizes_zero_position_constraint"] = 0.5

    unsupported_terms = [
        "earnings report", "fed announcement", "quarterly results",
        "dividend", "merger", "acquisition", "guidance cut", "cpi",
        "interest rate decision", "tariff", "ceo change"
    ]
    has_unsupported = any(term in combined for term in unsupported_terms)
    scores["no_unsupported_facts"] = 0.0 if has_unsupported else 1.0

    return scores
```