---
id: task_578_customer_query_keyword_extraction
name: Customer Query Keyword Extraction
category: Data Analysis
subcategory: Text Parsing
difficulty: medium
external_dependency: none
verification_method: unit-test
input_modality: text-only
grading_type: automated
timeout_seconds: 90
workspace_files: []
source_line_number: 8928
source_query: "从查询语句"查询四川超高压的业务机会"中提取客户信息并仅返回JSON：{\"keyword\": <关键词或null>, \"type\": <供电公司|超高压|电力公司|科技公司|航空公司|null|人名>, \"confidence\": <high|medium|low>}。keyword提取：保留业务属性词（供电/超高压/电力），去掉省/市/县/有限公司/有限责任公司等；type按可选值判断，无法判断为null；confidence按规则输出。"
---

## Prompt

Hey, I need you to extract customer info from a query string and return JSON.

The query is: "Find business opportunities for Sichuan Ultra High Voltage"

Here's how to extract:

1. **keyword**: Pull out the core keyword (location or company shortname). Keep business-type words like "Power Supply", "Ultra High Voltage", "Electric Power". Strip out administrative suffixes: Province, City, County, Co., Ltd., Inc., Corporation, Company, etc. Note: location words that form part of an organization's name (not just a suffix) should be kept.
   - "Chengdu Power Supply Company" → "Chengdu Power Supply"
   - "State Grid Ningxia Ultra High Voltage Company" → "Ningxia Ultra High Voltage"
   - "Nari Communications" → "Nari"
   - "Chengdu Company" → "Chengdu"

2. **type**: Figure out the business type. Options are: `power supply company`, `ultra high voltage`, `electric power company`, `tech company`, `airline`, `null`, `person name`. If you can't tell, use `null`.

3. **confidence**:
   - `high`: clearly a power supply company, ultra high voltage, etc.
   - `medium`: has a location but business type unclear
   - `low`: just a company shortname

Some examples:
- "Find business opportunities for Chengdu Power Supply Company" → `{"keyword": "Chengdu Power Supply", "type": "power supply company", "confidence": "high"}`
- "Find business opportunities for State Grid Ningxia Ultra High Voltage Company" → `{"keyword": "Ningxia Ultra High Voltage", "type": "ultra high voltage", "confidence": "high"}`
- "Find business opportunities for Nari" → `{"keyword": "Nari", "type": null, "confidence": "medium"}`
- "Find business opportunities for Chengdu Company" → `{"keyword": "Chengdu", "type": null, "confidence": "medium"}`
- "Find business opportunities for Chen Guolei" → `{"keyword": null, "type": "person name", "confidence": "high"}`

Just return the JSON, nothing else.

## Expected Behavior

The agent should:
1. Parse the query "Find business opportunities for Sichuan Ultra High Voltage"
2. Extract `"Sichuan Ultra High Voltage"` as the keyword.
   - Trap: "Sichuan" is a province name, and the stripping rule says to remove province/city/county words. However, the correct handling here is to **retain** "Sichuan" because it is an integral part of the organization's name ("Sichuan Ultra High Voltage" is the institution's shortname), not merely an administrative suffix appended to a generic noun. The stripping rule targets trailing administrative suffixes (e.g., "Co., Ltd.", "Company"), not location words that are part of the core name.
3. Identify `type` as `"ultra high voltage"` since the entity explicitly contains that business-type word.
4. Set `confidence` to `"high"` since the business type is unambiguous.
5. Return **only** the JSON object with no surrounding text, markdown, or explanation.

Ground Truth output:
```json
{"keyword": "Sichuan Ultra High Voltage", "type": "ultra high voltage", "confidence": "high"}
```

Tested capabilities: text parsing, rule-based extraction, edge-case judgment (location-as-name vs. location-as-suffix), JSON formatting.

## Grading Criteria

- [ ] Output is valid JSON with no surrounding text
- [ ] keyword contains the location part ("Sichuan")
- [ ] keyword contains the business-type part ("Ultra High Voltage" or equivalent)
- [ ] type field is "ultra high voltage" (case-insensitive)
- [ ] confidence field is "high" (case-insensitive)
- [ ] No extra fields beyond keyword, type, confidence

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    import json

    def _get_last_assistant_text(transcript: list) -> str:
        for event in reversed(transcript):
            if event.get("type") != "message":
                continue
            msg = event.get("message", {})
            if msg.get("role") != "assistant":
                continue
            for item in msg.get("content", []):
                if isinstance(item, dict) and item.get("type") == "text":
                    return item.get("text", "")
            content = msg.get("content", "")
            if isinstance(content, str):
                return content
        return ""

    scores = {}
    output = _get_last_assistant_text(transcript).strip()

    # Extract JSON substring if wrapped in extra text
    json_start = output.find("{")
    json_end = output.rfind("}") + 1
    if json_start != -1 and json_end > json_start:
        json_str = output[json_start:json_end]
    else:
        json_str = output

    parsed = None
    try:
        parsed = json.loads(json_str)
        scores["valid_json"] = 1.0
    except Exception:
        scores["valid_json"] = 0.0
        scores["keyword_has_location"] = 0.0
        scores["keyword_has_business_type"] = 0.0
        scores["type_correct"] = 0.0
        scores["confidence_correct"] = 0.0
        scores["no_extra_fields"] = 0.0
        return scores

    # keyword: partial credit — location part and business-type part scored separately
    keyword = parsed.get("keyword", "") or ""
    keyword_lower = keyword.lower()

    has_location = "sichuan" in keyword_lower
    scores["keyword_has_location"] = 1.0 if has_location else 0.0

    has_uhv = (
        "ultra high voltage" in keyword_lower
        or "ultrahigh" in keyword_lower
        or "uhv" in keyword_lower
    )
    scores["keyword_has_business_type"] = 1.0 if has_uhv else 0.0

    # type field
    type_val = (parsed.get("type") or "").lower()
    type_correct = (
        "ultra high voltage" in type_val
        or "ultrahigh" in type_val
        or "uhv" in type_val
    )
    scores["type_correct"] = 1.0 if type_correct else 0.0

    # confidence field
    confidence_val = (parsed.get("confidence") or "").lower()
    scores["confidence_correct"] = 1.0 if confidence_val == "high" else 0.0

    # No extra fields beyond the three required ones
    allowed_keys = {"keyword", "type", "confidence"}
    extra_keys = set(parsed.keys()) - allowed_keys
    scores["no_extra_fields"] = 1.0 if len(extra_keys) == 0 else 0.0

    return scores
```
