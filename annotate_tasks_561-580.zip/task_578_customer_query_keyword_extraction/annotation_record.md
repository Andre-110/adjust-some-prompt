| 序号 | 修改项 | 修改原因 |
|------|--------|--------|
| 1 | **Expected Behavior — 补充陷阱说明** | 题目存在隐性陷阱："Sichuan"是省名，按规则本应去掉，但此处应保留，因为它是机构名称的组成部分而非行政后缀。原文未作任何说明，按维度B要求补充了陷阱及正确处理方式 |
| 2 | **Grading Criteria — 将 keyword 拆分为两条独立标准** | 原第2条将"含 Sichuan"和"含 Ultra High Voltage"合并为一条，导致两个独立知识点只能全对或全错，无部分得分；拆分后对应 grade() 中两个独立 key，满足维度C可独立验证和维度D部分得分的要求 |
| 3 | **grade() — `keyword_correct` 拆分为 `keyword_has_location` + `keyword_has_business_type`** | 原函数所有 key 均为纯 0/1，违反维度D第2点"支持部分得分"；拆分 keyword 评分为两个独立 key，使得仅识别出一半时仍能获得部分分数 |
| 4 | **grade() — 修正 `None` 处理方式** | 原代码对 `keyword`、`type`、`confidence` 为 `None` 时分别做了 `if x is None: x = ""` 的处理，改为更简洁的 `(parsed.get(...) or "")` 统一写法，逻辑等价但更健壮 |
| 5 | **Prompt — keyword 规则说明补充一句注意事项** | 为与 Expected Behavior 中的陷阱说明一致，在 keyword 提取规则后补充了"location words that form part of an organization's name should be kept"，避免模型因规则描述不完整而误删地名 |