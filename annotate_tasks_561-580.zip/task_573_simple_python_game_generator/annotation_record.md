| 序号 | 修改项 | 修改原因 |
|---|---|---|
| 1 | 在 frontmatter 中新增 `grading_weights` | 原文件缺少该字段；按规范需保证 `automated + llm_judge = 1.0` |
| 2 | 保持 `grading_type: automated`，并设置 `automated: 1.0 / llm_judge: 0.0` | 该题本质为自动评分任务，权重应与任务类型一致 |
| 3 | 轻度改写 Prompt | 原 Prompt 基本清晰自然，但“actually runs”略口语化且可验证边界不清，改为“complete and runnable”更明确 |
| 4 | 在 Expected Behavior 中补充“简单游戏”的最低标准 | 原文只列举了游戏例子，但没有明确什么算合格的“game-like logic”，不利于稳定判分 |
| 5 | 补充“仅依赖标准库”的约束 | 防止模型生成依赖第三方库的代码，造成运行不可控 |
| 6 | 明确 desktop 路径处理的环境容忍性 | 原任务要求“save to desktop”，但不同评测环境 desktop 路径不完全一致，需在 Expected Behavior 中写清常见路径容忍方式 |
| 7 | 保持 difficulty 为 `easy` | 任务主要是简单代码生成与文件保存，复杂度与 easy 匹配 |
| 8 | 保持 Grading Criteria 数量简洁，但与 score key 对齐 | 原标准大体合理，无需大幅扩展，只需确保与自动评分项一致 |
| 9 | 重写 `grade()` 的初始化逻辑 | 统一所有 score key 默认 0.0，满足主输出缺失时全零分 |
| 10 | 改进 `has_game_logic`，增加部分得分 | 原实现只有 0/1，且阈值偏粗；修正后支持 0.5/1.0，区分较弱与较强游戏逻辑 |
| 11 | 改进 `non_trivial_code`，增加部分得分 | 原实现只有 0/1，修正后按代码长度、函数、赋值、导入等信号综合判断 |
| 12 | 改进 `has_interactive_element`，增加部分得分 | 原实现只检查 `input` 和 `print`，修正后引入提示文本和循环信号，增强区分度 |
| 13 | 删除未使用变量 `has_game_loop` | 原代码中定义了 `has_game_loop` 但没有实际用于评分，存在冗余 |
| 14 | 提升评分逻辑鲁棒性 | 在读取文件、解析 AST 等环节使用更稳健的 early return，避免异常导致不一致评分 |
| 15 | 补充完整 LLM Judge Rubric | 原文件缺失该部分；按你给的任务文件结构规范应补齐 |
| 16 | 为 LLM Judge Rubric 设置 3 个维度且权重合计 100% | 满足“至少 3 个评分维度”“权重和为 100%”的要求 |
| 17 | 为 Rubric 补齐 1.0 / 0.75 / 0.5 / 0.25 / 0.0 五档描述 | 满足等级描述清晰的要求 |