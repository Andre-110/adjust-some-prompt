---
id: task_573_simple_python_game_generator
name: Simple Python Game Generator
category: System Administration
subcategory: Software and Environment Management
difficulty: easy
external_dependency: none
verification_method: unit-test
input_modality: text-only
grading_type: automated
grading_weights:
  automated: 1.0
  llm_judge: 0.0
timeout_seconds: 120
workspace_files: []
source_line_number: 2967
source_query: "生成一个简单的 Python 小游戏，并将完整代码保存为桌面上的 .py 文件"
---

## Prompt

Hey, can you make me a simple Python game and save it as a `.py` file on the desktop?

Something like a number guessing game, rock-paper-scissors, or a small text-based adventure is fine. Please make sure the code is complete and runnable.

## Expected Behavior

The agent should create a complete Python source file for a simple playable game and save it as a `.py` file on the desktop.

The output should satisfy all of the following:

1. A Python file with the `.py` extension is saved to a desktop directory.
2. The file contains syntactically valid Python code.
3. The code implements a simple game rather than a static script. A valid simple game should include at least:
   - some game state or variables,
   - at least one control-flow structure such as a loop or repeated turns,
   - at least one conditional branch,
   - and some form of user interaction such as input prompts.
4. The script should be runnable as a standalone terminal-based Python program without requiring external packages beyond the Python standard library.
5. The code should be more than trivial boilerplate or a sequence of print statements.

Expected desktop handling:
- The agent should save the file to a desktop-like location available in the environment, such as `~/Desktop` or another common desktop path recognized by the grader.

Tested capabilities:
- generating runnable Python code
- saving files to a user-facing filesystem location
- producing a minimally interactive terminal game
- basic environment/path handling

## Grading Criteria

- [ ] A `.py` file exists in a desktop directory checked by the grader
- [ ] The file contains valid Python syntax
- [ ] The file contains recognizable game logic
- [ ] The file is non-trivial
- [ ] The file contains an interactive gameplay element

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    from pathlib import Path
    import ast
    import re

    scores = {
        "py_file_exists": 0.0,
        "valid_python_syntax": 0.0,
        "has_game_logic": 0.0,
        "non_trivial_code": 0.0,
        "has_interactive_element": 0.0,
    }

    home = Path.home()
    desktop_paths = [
        home / "Desktop",
        home / "desktop",
        Path("/root/Desktop"),
        Path("/root/desktop"),
    ]

    desktop = None
    for dp in desktop_paths:
        if dp.exists():
            desktop = dp
            break

    if desktop is None:
        return scores

    py_files = list(desktop.glob("*.py"))
    if not py_files:
        return scores

    scores["py_file_exists"] = 1.0

    py_file = max(py_files, key=lambda f: f.stat().st_mtime)

    try:
        content = py_file.read_text(encoding="utf-8", errors="ignore")
    except Exception:
        return scores

    try:
        tree = ast.parse(content)
        scores["valid_python_syntax"] = 1.0
    except SyntaxError:
        return scores

    has_loop = bool(re.search(r"\b(while|for)\b", content))
    has_conditional = bool(re.search(r"\b(if|elif|else)\b", content))
    has_random = bool(re.search(r"\b(random|randint|choice|randrange)\b", content))
    has_comparison = bool(re.search(r"(==|!=|<=|>=|<|>)", content))
    has_score_words = bool(re.search(r"\b(score|win|lose|guess|turn|round|game)\b", content, re.IGNORECASE))

    game_indicator_count = sum([
        has_loop,
        has_conditional,
        has_random,
        has_comparison,
        has_score_words,
    ])
    if game_indicator_count >= 3:
        scores["has_game_logic"] = 1.0
    elif game_indicator_count == 2:
        scores["has_game_logic"] = 0.5

    lines = [
        l for l in content.splitlines()
        if l.strip() and not l.strip().startswith("#")
    ]
    has_function_def = bool(re.search(r"\bdef\s+\w+\s*\(", content))
    has_assignment = bool(re.search(r"\b\w+\s*=\s*", content))
    has_import = bool(re.search(r"^\s*(import|from)\s+", content, re.MULTILINE))

    non_trivial_signals = sum([
        len(lines) >= 10,
        len(lines) >= 20,
        has_function_def,
        has_assignment,
        has_import,
    ])
    if non_trivial_signals >= 3:
        scores["non_trivial_code"] = 1.0
    elif non_trivial_signals == 2:
        scores["non_trivial_code"] = 0.5

    has_input = bool(re.search(r"\binput\s*\(", content))
    has_print = bool(re.search(r"\bprint\s*\(", content))
    has_prompt_text = bool(re.search(r'input\s*\(\s*["\']', content))
    has_repeat_loop = bool(re.search(r"\bwhile\b|\bfor\b", content))

    interactive_signals = sum([
        has_input,
        has_print,
        has_prompt_text,
        has_repeat_loop,
    ])
    if has_input and has_print and interactive_signals >= 3:
        scores["has_interactive_element"] = 1.0
    elif has_input and has_print:
        scores["has_interactive_element"] = 0.5

    return scores
````

## LLM Judge Rubric

Use this rubric only if manual or model-based review is needed as a fallback.

### Dimension 1: Game Completeness (Weight: 40%)

* **1.0**: The file contains a complete, playable Python terminal game with clear start-to-finish interaction.
* **0.75**: The game is mostly complete and playable, with only minor issues.
* **0.5**: The script resembles a game but is incomplete or only partially playable.
* **0.25**: The script has fragments of game behavior but is barely functional as a game.
* **0.0**: The script is not meaningfully a playable game.

### Dimension 2: Code Quality and Correctness (Weight: 35%)

* **1.0**: Code is syntactically correct, organized, and runnable as a standalone script.
* **0.75**: Code is largely correct with only minor quality or structure issues.
* **0.5**: Code is partly correct but has noticeable weaknesses in structure or execution readiness.
* **0.25**: Code quality is poor and likely fragile, though some valid structure exists.
* **0.0**: Code is invalid or unusable.

### Dimension 3: Instruction Following (Weight: 25%)

* **1.0**: Saves a `.py` file to the desktop and satisfies the simple-game requirement exactly.
* **0.75**: Mostly follows instructions, with only a minor mismatch.
* **0.5**: Partially follows instructions, but misses an important requirement.
* **0.25**: Substantially misses the requested output format or location.
* **0.0**: Does not follow the core task requirements.