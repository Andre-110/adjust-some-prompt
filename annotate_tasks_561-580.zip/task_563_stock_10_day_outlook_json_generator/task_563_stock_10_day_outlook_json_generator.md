---
id: task_563_stock_10_day_outlook_json_generator
name: Stock 10-Day Outlook JSON Generator
category: Finance
subcategory: Market Analysis and Research
difficulty: medium
external_dependency: none
verification_method: output-check
input_modality: text-only
grading_type: hybrid
grading_weights:
  automated: 0.4
  llm_judge: 0.6
timeout_seconds: 120
workspace_files: []
source_line_number: 5621
source_query: "Using the provided market/technical summary data for stock 0568.HK (LatestDate: 2026-02-23; LatestClose: 4.12; ReturnPct_5D: 4.040403038175144; ReturnPct_10D: 4.303796209217081; ReturnPct_20D: 3.77833678359647; Latest_Volume: 5155600.0; Latest_Histogram: NaN; Latest_MA5: 3.98; Latest_MA10: 3.97; Latest_MA20: 4.06; Latest_MA60: 3.74; Latest_MA120: 3.95; Latest_MA250: 3.38), produce a 10-trading-day outlook.  Definitions: - PointEstimatePct: expected percent change of Close over the next 10 tra..."
---

## Prompt

Hey, I need a 10-trading-day outlook for this Hong Kong stock based on the market summary below.

```json
{
  "StockSymbol": "0568.HK",
  "Rows": 489,
  "HasDate": true,
  "LatestDate": "2026-02-23",
  "LatestClose": 4.12,
  "ReturnPct_5D": 4.040403038175144,
  "ReturnPct_10D": 4.303796209217081,
  "ReturnPct_20D": 3.77833678359647,
  "Latest_Volume": 5155600.0,
  "Latest_Histogram": null,
  "Latest_MA5": 3.98,
  "Latest_MA10": 3.97,
  "Latest_MA20": 4.06,
  "Latest_MA60": 3.74,
  "Latest_MA120": 3.95,
  "Latest_MA250": 3.38
}
````

Please save the result to `outlook.json`.

Output only valid JSON in the file using this exact schema:

```json
{
  "StockSymbol": "0568.HK",
  "HorizonTradingDays": 10,
  "LatestClose": 4.12,
  "PointEstimatePct": <number>,
  "ConfidencePct": <number>,
  "ConfidenceSentence": "<one sentence>",
  "ExpectedHighPrice": <number>,
  "ExpectedLowPrice": <number>,
  "PriceRangeConfidencePct": <number>,
  "PriceRangeConfidenceSentence": "<one sentence>",
  "KeyDrivers": ["...", "...", "..."],
  "Risks": ["...", "...", "..."],
  "AnalysisText": "<plain text paragraph(s)>",
  "DataNotes": "<plain text>",
  "TimestampHKT": "2026-02-23 17:12:18"
}
```

## Expected Behavior

The agent should create a valid JSON file named `outlook.json` in the workspace and populate all required fields in the requested schema.

Ground-truth fixed fields:

* `StockSymbol` must be `0568.HK`
* `HorizonTradingDays` must be `10`
* `LatestClose` must be `4.12`
* `TimestampHKT` must be `2026-02-23 17:12:18`

Expected handling of the provided data:

1. The agent should interpret the supplied technical summary and generate a short-horizon outlook for the next 10 trading days.
2. The agent should use the provided returns, moving averages, and volume context to produce a coherent directional view and price range.
3. The agent should recognize that `Latest_Histogram` is missing (`null`) and explicitly mention this missing/weak data point in `DataNotes`.
4. The agent should avoid inventing unsupported facts such as company news, macro events, fundamentals, or catalysts not present in the input.
5. Numeric forecast fields should be numeric JSON values, not strings.
6. `ExpectedHighPrice` and `ExpectedLowPrice` should be plausible relative to the latest close and consistent with a 10-trading-day technical outlook rather than extreme tail scenarios.
7. `KeyDrivers` and `Risks` should each contain exactly 3 items and should be grounded in the supplied technical data.
8. `AnalysisText` should be consistent with the numeric estimates and with the observed technical setup from the input data.

Key data cues available to the agent:

* latest close is above MA5, MA10, MA60, MA120, and MA250
* latest close is slightly above MA20
* 5-day, 10-day, and 20-day returns are positive
* MACD histogram data is unavailable and should be treated as a limitation rather than fabricated

Tested capabilities:

* technical-summary interpretation
* structured JSON generation
* constraint following for a fixed output schema
* handling missing data without fabrication
* producing internally consistent short-horizon market commentary

## Grading Criteria

* [ ] File `outlook.json` exists
* [ ] File content is valid JSON
* [ ] All required schema fields are present
* [ ] Fixed fields match expected values (`StockSymbol`, `HorizonTradingDays`, `LatestClose`, `TimestampHKT`)
* [ ] Required numeric forecast fields are numeric JSON values, not strings
* [ ] `KeyDrivers` and `Risks` each contain exactly 3 entries
* [ ] Price estimates are plausible for a 10-trading-day horizon and internally ordered (`ExpectedHighPrice >= LatestClose >= ExpectedLowPrice`)
* [ ] `DataNotes` explicitly mentions missing/null/unavailable histogram or MACD information
* [ ] Output contains no unsupported extra top-level fields

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    from pathlib import Path
    import json

    scores = {
        "file_exists": 0.0,
        "valid_json": 0.0,
        "all_fields_present": 0.0,
        "fixed_fields_correct": 0.0,
        "numeric_types_correct": 0.0,
        "list_lengths_correct": 0.0,
        "price_estimates_reasonable": 0.0,
        "data_notes_mentions_missing": 0.0,
        "no_unsupported_extra_fields": 0.0,
    }

    ws = Path(workspace_path)
    outlook_file = ws / "outlook.json"

    if not outlook_file.exists():
        return scores

    scores["file_exists"] = 1.0

    try:
        data = json.loads(outlook_file.read_text(encoding="utf-8"))
        scores["valid_json"] = 1.0
    except Exception:
        return scores

    if not isinstance(data, dict):
        return scores

    required_fields = [
        "StockSymbol",
        "HorizonTradingDays",
        "LatestClose",
        "PointEstimatePct",
        "ConfidencePct",
        "ConfidenceSentence",
        "ExpectedHighPrice",
        "ExpectedLowPrice",
        "PriceRangeConfidencePct",
        "PriceRangeConfidenceSentence",
        "KeyDrivers",
        "Risks",
        "AnalysisText",
        "DataNotes",
        "TimestampHKT",
    ]

    present_count = sum(1 for f in required_fields if f in data)
    scores["all_fields_present"] = present_count / len(required_fields)

    fixed_match_count = 0
    if data.get("StockSymbol") == "0568.HK":
        fixed_match_count += 1
    if data.get("HorizonTradingDays") == 10:
        fixed_match_count += 1
    if data.get("LatestClose") == 4.12:
        fixed_match_count += 1
    if data.get("TimestampHKT") == "2026-02-23 17:12:18":
        fixed_match_count += 1
    scores["fixed_fields_correct"] = fixed_match_count / 4.0

    numeric_fields = [
        "PointEstimatePct",
        "ConfidencePct",
        "ExpectedHighPrice",
        "ExpectedLowPrice",
        "PriceRangeConfidencePct",
    ]
    numeric_ok = 0
    for f in numeric_fields:
        if isinstance(data.get(f), (int, float)) and not isinstance(data.get(f), bool):
            numeric_ok += 1
    scores["numeric_types_correct"] = numeric_ok / len(numeric_fields)

    list_ok = 0
    key_drivers = data.get("KeyDrivers")
    risks = data.get("Risks")

    if isinstance(key_drivers, list) and len(key_drivers) == 3 and all(isinstance(x, str) and x.strip() for x in key_drivers):
        list_ok += 1
    if isinstance(risks, list) and len(risks) == 3 and all(isinstance(x, str) and x.strip() for x in risks):
        list_ok += 1
    scores["list_lengths_correct"] = list_ok / 2.0

    high_price = data.get("ExpectedHighPrice")
    low_price = data.get("ExpectedLowPrice")
    latest_close = 4.12

    reason_score = 0.0
    if isinstance(high_price, (int, float)) and isinstance(low_price, (int, float)):
        ordered = high_price >= latest_close >= low_price
        plausible_high = latest_close <= high_price <= latest_close * 1.2
        plausible_low = latest_close * 0.8 <= low_price <= latest_close
        if ordered and plausible_high and plausible_low:
            reason_score = 1.0
        elif ordered and (plausible_high or plausible_low):
            reason_score = 0.5
    scores["price_estimates_reasonable"] = reason_score

    data_notes = str(data.get("DataNotes", "")).lower()
    missing_keywords = ["missing", "null", "histogram", "macd", "unavailable", "not available", "nan"]
    keyword_hits = sum(1 for kw in missing_keywords if kw in data_notes)
    if keyword_hits >= 2:
        scores["data_notes_mentions_missing"] = 1.0
    elif keyword_hits == 1:
        scores["data_notes_mentions_missing"] = 0.5

    allowed_fields = set(required_fields)
    actual_fields = set(data.keys())
    extra_fields = actual_fields - allowed_fields
    if len(extra_fields) == 0:
        scores["no_unsupported_extra_fields"] = 1.0
    elif len(extra_fields) == 1:
        scores["no_unsupported_extra_fields"] = 0.5

    return scores
```

## LLM Judge Rubric

Use this rubric for the model-judged portion of the score.

### Dimension 1: Technical Analysis Quality (Weight: 35%)

* **1.0**: Correctly interprets the technical summary, uses moving averages and positive recent returns appropriately, and produces a coherent short-term outlook fully consistent with the provided data.
* **0.75**: Mostly correct interpretation with only minor omissions or slight overstatement, while remaining generally consistent with the input data.
* **0.5**: Partially correct interpretation, but misses important technical cues or includes some weak reasoning.
* **0.25**: Weak technical interpretation with substantial misunderstanding of the supplied indicators.
* **0.0**: Analysis is inconsistent with the provided data or largely unsupported.

### Dimension 2: KeyDrivers and Risks Grounding (Weight: 25%)

* **1.0**: `KeyDrivers` and `Risks` are specific, relevant, and clearly grounded in the supplied technical summary without inventing unsupported catalysts.
* **0.75**: Most listed drivers and risks are relevant, with only minor generic or weakly supported items.
* **0.5**: Mix of relevant and generic points; some items are only loosely tied to the provided data.
* **0.25**: Mostly generic or weakly supported drivers/risks.
* **0.0**: Drivers and risks are fabricated, irrelevant, or ungrounded.

### Dimension 3: Consistency of Forecast Numbers and Narrative (Weight: 20%)

* **1.0**: Numeric estimates, confidence levels, price range, and narrative explanation are internally consistent and mutually reinforcing.
* **0.75**: Mostly consistent, with only small mismatches between numbers and commentary.
* **0.5**: Some inconsistencies between estimates and explanation, but the overall output remains usable.
* **0.25**: Significant inconsistency between numeric outputs and written analysis.
* **0.0**: Forecast numbers and narrative clearly contradict each other.

### Dimension 4: Instruction Following and Missing-Data Handling (Weight: 20%)

* **1.0**: Follows the requested schema exactly, avoids unsupported extra claims, and clearly acknowledges the missing histogram/MACD limitation in `DataNotes`.
* **0.75**: Mostly follows instructions, with only minor schema or missing-data handling issues.
* **0.5**: Partial instruction following, including noticeable omissions or mild fabrication.
* **0.25**: Significant failures in schema compliance or missing-data handling.
* **0.0**: Does not follow the task requirements in a reliable way.

Total rubric weight: 100%

```