| 序号 | 修改项 | 修改原因 |
|---|---|---|
| 1 | 保留 difficulty 为 `medium` | 任务要求结构化输出、短期技术分析和约束遵循，但不涉及复杂多步外部检索或高难推理，整体仍与 medium 匹配 |
| 2 | 轻度改写 Prompt，删除“bullish momentum”这类带结论色彩的引导 | 原 Prompt 虽未直接泄露答案，但 Expected Behavior 中已有明显方向性提示；Prompt 应尽量避免替模型预设结论 |
| 3 | 在 Expected Behavior 中补充固定 Ground Truth 字段 | 原文未把 `TimestampHKT` 作为明确 Ground Truth 写出，补充后更利于统一判分 |
| 4 | 强化 Expected Behavior 中“不得编造”要求 | 原题是金融分析类任务，容易引入未给定新闻/基本面/事件，需明确禁止无依据扩展 |
| 5 | 明确 `KeyDrivers` 和 `Risks` 应各为 3 项 | 原 schema 暗示了 3 项，但 Expected Behavior 和自动评分没有显式约束，补上后更完整 |
| 6 | 重写 Grading Criteria，使条目与 score key 一一对应 | 原标准与自动评分项存在粒度不完全一致的问题，修正后更便于审校和解释分数 |
| 7 | 将“fixed fields”检查扩展到 `TimestampHKT` | 原自动评分漏掉了 schema 中固定值 `TimestampHKT`，应纳入固定字段校验 |
| 8 | 将 `all_fields_present` 改为支持部分得分 | 原实现纯 0/1，不满足部分得分要求；修正为按字段覆盖比例评分 |
| 9 | 将 `fixed_fields_correct` 改为支持部分得分 | 原实现纯 0/1，修正后按 4 个固定字段的命中比例计分 |
| 10 | 将 `numeric_types_correct` 改为按字段比例计分 | 原逻辑只要存在字段且全是数值才得分，不利于细粒度区分 |
| 11 | 新增 `list_lengths_correct` 检查项 | 原自动评分未验证 `KeyDrivers`/`Risks` 是否真的是长度为 3 的非空字符串列表 |
| 12 | 改进 `price_estimates_reasonable` 逻辑 | 原逻辑范围较粗且未检查高低价与 latest close 的相对顺序；修正后同时检查顺序与合理区间 |
| 13 | 改进 `data_notes_mentions_missing` 为部分得分 | 原实现只要命中任一关键词即满分，过于宽松；修正后按关键词覆盖程度给 0.5/1.0 |
| 14 | 将 `no_fabricated_extra_fields` 重命名为 `no_unsupported_extra_fields` | 表达更准确，强调不应添加 schema 外顶层字段 |
| 15 | 统一 `grade()` 的空白零分前置逻辑 | 初始化所有 key 为 0.0，主文件不存在或 JSON 不合法时直接返回，满足“空白零分”要求 |
| 16 | 补全并重写 LLM Judge Rubric | 原 rubric 只有权重说明，没有 1.0/0.75/0.5/0.25/0.0 的分档描述，不符合规范 |
| 17 | 将 LLM Judge Rubric 细化为 4 个维度 | 满足“至少 3 个评分维度”，并覆盖技术分析、驱动风险、数值-叙述一致性、指令遵循 |
| 18 | 保持 grading_weights 不变 | 原 automated 0.4 + llm_judge 0.6 = 1.0，符合要求，无需改动 |