| 序号 | 修改项 | 修改原因 |
|---|---|---|
| 1 | 在 frontmatter 中新增 `grading_weights` | 原文件缺少 automated 与 llm_judge 权重配置，不满足总和为 1.0 的要求 |
| 2 | 微调 `## Prompt` 表述 | 保持任务自然、清晰，减少不必要歧义，同时继续明确输出到 `solution.md` |
| 3 | 重写并补充 `Expected Behavior` | 原版本缺少完整解题路径与更明确的 bash 语义解释 |
| 4 | 新增 `Ground Truth` | 原文件没有显式 Ground Truth，不满足“答案明确”要求 |
| 5 | 新增 `Trap to handle correctly` | 明确指出不要误把问题归因于 `openclaw` 或子命令本身，而应归因于 shell 语法 |
| 6 | 调整 `Grading Criteria` 文案 | 让各条更独立、可验证，并与 score key 精确对应 |
| 7 | 重写 `grade()` 的 score key 初始化 | 保证文件不存在时所有 score key 明确返回 0.0 |
| 8 | 为 `grade()` 增加部分得分 | 原逻辑基本为纯 0/1；现在对“部分命中但不完整”的回答支持 0.5 |
| 9 | 增强 `identifies_angle_brackets` 检查 | 原逻辑要求同时命中特定“special character”措辞，过于死板；现更稳健 |
| 10 | 增强 `explains_redirection` 检查 | 原逻辑主要靠少数关键词，现覆盖 redirection / metacharacter / bash interpretation 等常见表述 |
| 11 | 收紧 `shows_corrected_command` 检查 | 明确要求使用 `YOUR_TOKEN_HERE` 且不能保留尖括号，和题目要求更一致 |
| 12 | 保留“文件不存在全 0”前置逻辑 | 该项原本是合格的，修订后继续保留并显式化 |
| 13 | 补充 `LLM Judge Rubric` | 原文件缺失 Rubric，不满足维度 E 要求 |
| 14 | 保持 `difficulty: easy` 不变 | 题目核心是典型 bash 特殊字符误用，难度与 easy 匹配 |