| 序号 | 修改项 | 修改原因 |
|------|--------|--------|
| 1 | **grade() — `no_fabricated_position` 重命名为 `accounts_for_zero_position` 并重写逻辑** | 原 key 名与 Criteria 第8条描述不对齐（维度D第5点）；原逻辑只检查有无"编造持仓"的负向词，完全没有正向验证模型是否识别了0持仓下不能直接 SELL 的核心约束，导致一个直接输出 SELL 且不提任何持仓的模型反而得满分——这是最严重的逻辑错误；重写为按 action 分支判断：HOLD 且提及无仓约束得满分，SELL 且明确做空框架得 0.75，其他情况梯度得分 |
| 2 | **grade() — `has_rationale` 改为部分得分** | 原逻辑为纯 0/1（长度>20 即满分），无法区分答案质量；按长度梯度改为 0/0.5/0.75/1.0，满足维度D第2点"支持部分得分"要求 |
| 3 | **grade() — `has_key_factors` 改为部分得分** | 原逻辑为纯 0/1（数量>=2 即满分）；按数量梯度改为 0/0.5/0.75/1.0，满足维度D第2点要求 |
| 4 | **grade() — `has_all_fields` 改为部分得分** | 原逻辑为纯 0/1（全有才得分）；改为按缺失字段比例给分，部分字段存在时可获得部分分数，避免一个字段缺失导致整项归零 |
| 5 | **grade() — 统一前置零分返回为 `_zero` 常量** | 原代码在多处重复拼写相同的 dict，key 拼写风险高；提取为 `_zero` 常量统一维护，同步更新所有 key 名以与修正后的 Grading Criteria 对齐 |
| 6 | **Expected Behavior — 补充陷阱说明和 Ground Truth** | 原文对陷阱（直接输出 SELL）的描述不够明确，未给出 Ground Truth 示例格式；按维度B要求补充了典型可接受输出示例，并明确说明只有在 rationale 明确做空框架时 SELL 才可接受 |
| 7 | **Grading Criteria — 第1条和第6条措辞细化** | 原第1条"Output is valid JSON"未说明不能有额外文本（题目明确要求 only JSON）；原第6条"rationale is a non-empty string"未体现质量要求；分别细化为"no surrounding text"和"substantive explanation"，与 grade() 中的长度梯度逻辑保持一致 |