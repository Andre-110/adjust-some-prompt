---
id: task_567_trading_signal_decision_analyzer
name: Trading Signal Decision Analyzer
category: Finance
subcategory: Trading Strategy and Backtesting
difficulty: hard
external_dependency: none
verification_method: rubric
input_modality: text-only
grading_type: hybrid
timeout_seconds: 180
grading_weights:
  automated: 0.4
  llm_judge: 0.6
workspace_files: []
source_line_number: 3157
source_query: "Given the following trading signal, market data, and portfolio status, decide whether to trade (BUY/SELL/HOLD), the position size as a percentage of available capital (0-20), and the risk level (low/medium/high). Provide a detailed rationale and list key factors. Data: Signal=SELL; Confidence=HIGH; Patterns=[shooting_star, doji, double_top]. Market: Current Price=$8.78; Trend=strong_uptrend; Volume vs Average=1.53x; ATR=$0.61; Price vs EMA20=above. Portfolio: Available Cash=$985,893.47; Curre..."
---

## Prompt

Hey, I need you to analyze this trading setup and give me a decision. We got a SELL signal with HIGH confidence, and the patterns detected are shooting_star, doji, and double_top.

Here's the market data:
- Current Price: $8.78
- Trend: strong_uptrend
- Volume vs Average: 1.53x (so above normal)
- Volatility (ATR): $0.61
- Price vs EMA20: above

And my portfolio situation:
- Available Cash: $985,893.47
- Current Position: 0 shares
- Total Portfolio: $985,893.47

I need you to decide:
1. Should we trade? (BUY/SELL/HOLD)
2. Position size as % of available capital (0-20%)
3. Risk level (low/medium/high)
4. Give me a detailed rationale
5. List the key factors you considered

Oh and super important - respond ONLY with valid JSON, nothing else. Use this exact format:

```json
{
    "action": "BUY|SELL|HOLD",
    "position_size_pct": <number 0-20>,
    "risk_assessment": "low|medium|high",
    "rationale": "<your explanation>",
    "key_factors": ["factor1", "factor2", "..."]
}
```

Just the JSON, no extra text before or after.

## Expected Behavior

The agent should:
1. Recognize the contradiction between the SELL signal and holding 0 shares — you cannot execute a standard SELL with no existing position.
2. Handle this edge case correctly: the expected response is **HOLD** (since selling requires an existing position), OR a well-reasoned explanation that this could be treated as a short-sell opportunity — in which case the rationale must explicitly acknowledge that this is a short-selling scenario and discuss the additional risks involved.
3. Consider that the bearish patterns (shooting_star, doji, double_top) suggest a potential reversal, but the broader trend is still a strong uptrend — this conflict should be noted.
4. Provide reasonable position sizing (0 if HOLD; a small percentage if making a contrarian or short-sell case).
5. Assess risk as medium or high given the conflicting signals.
6. Output valid JSON matching the exact schema with no surrounding text.

Trap: A model that simply outputs `"action": "SELL"` without acknowledging the 0-share constraint is making a logical error. The grading penalizes this directly.

Ground Truth (representative acceptable outputs):
- `{"action": "HOLD", "position_size_pct": 0, "risk_assessment": "high", "rationale": "...(acknowledges 0 shares, bearish patterns vs uptrend conflict)...", "key_factors": [...]}`
- `{"action": "SELL", ...}` is only acceptable if the rationale explicitly frames it as a short-sell and discusses the risk.

## Grading Criteria

- [ ] Output is valid JSON with no surrounding text
- [ ] JSON has all required fields (action, position_size_pct, risk_assessment, rationale, key_factors)
- [ ] action is one of BUY/SELL/HOLD
- [ ] position_size_pct is a number between 0 and 20
- [ ] risk_assessment is one of low/medium/high
- [ ] rationale is a substantive explanation (not just a placeholder)
- [ ] key_factors is a list with at least 2 entries
- [ ] Response accounts for the 0-share position when given a SELL signal (HOLD or explicit short-sell framing)

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    import json
    import re

    _zero = {
        "valid_json": 0.0,
        "has_all_fields": 0.0,
        "valid_action": 0.0,
        "valid_position_size": 0.0,
        "valid_risk": 0.0,
        "has_rationale": 0.0,
        "has_key_factors": 0.0,
        "accounts_for_zero_position": 0.0,
    }

    def _get_last_assistant_text(transcript: list) -> str:
        for event in reversed(transcript):
            if event.get("type") != "message":
                continue
            msg = event.get("message", {})
            if msg.get("role") != "assistant":
                continue
            for item in msg.get("content", []):
                if isinstance(item, dict) and item.get("type") == "text":
                    return item.get("text", "")
            content = msg.get("content", "")
            if isinstance(content, str):
                return content
        return ""

    text = _get_last_assistant_text(transcript)
    if not text:
        return _zero.copy()

    json_match = re.search(r'\{[\s\S]*\}', text)
    if not json_match:
        return _zero.copy()

    try:
        data = json.loads(json_match.group())
    except json.JSONDecodeError:
        return _zero.copy()

    scores = {}
    scores["valid_json"] = 1.0

    required_fields = ["action", "position_size_pct", "risk_assessment", "rationale", "key_factors"]
    fields_present = sum(1 for f in required_fields if f in data)
    scores["has_all_fields"] = fields_present / len(required_fields)

    action = data.get("action", "")
    scores["valid_action"] = 1.0 if action in ["BUY", "SELL", "HOLD"] else 0.0

    pos_size = data.get("position_size_pct")
    if isinstance(pos_size, (int, float)) and 0 <= pos_size <= 20:
        scores["valid_position_size"] = 1.0
    else:
        scores["valid_position_size"] = 0.0

    risk = data.get("risk_assessment", "")
    scores["valid_risk"] = 1.0 if str(risk).lower() in ["low", "medium", "high"] else 0.0

    # Partial credit for rationale quality based on length
    rationale = data.get("rationale", "")
    if not isinstance(rationale, str):
        rationale = ""
    rationale_len = len(rationale.strip())
    if rationale_len >= 100:
        scores["has_rationale"] = 1.0
    elif rationale_len >= 50:
        scores["has_rationale"] = 0.75
    elif rationale_len >= 20:
        scores["has_rationale"] = 0.5
    else:
        scores["has_rationale"] = 0.0

    # Partial credit for key_factors based on count
    factors = data.get("key_factors", [])
    if isinstance(factors, list):
        n = len(factors)
        if n >= 4:
            scores["has_key_factors"] = 1.0
        elif n >= 2:
            scores["has_key_factors"] = 0.75
        elif n == 1:
            scores["has_key_factors"] = 0.5
        else:
            scores["has_key_factors"] = 0.0
    else:
        scores["has_key_factors"] = 0.0

    # Core logic check: does the response correctly handle SELL signal with 0 shares?
    rationale_lower = rationale.lower()
    factors_text = " ".join(factors).lower() if isinstance(factors, list) else ""
    combined = rationale_lower + " " + factors_text

    if action == "HOLD":
        # HOLD is the most defensible answer; check that rationale mentions 0 position or no shares
        zero_position_terms = ["0 share", "no share", "no position", "no existing", "zero share",
                               "no current position", "cannot sell", "can't sell", "not hold"]
        mentions_constraint = any(t in combined for t in zero_position_terms)
        scores["accounts_for_zero_position"] = 1.0 if mentions_constraint else 0.5
    elif action == "SELL":
        # SELL is only acceptable if explicitly framed as short-selling
        short_terms = ["short", "short sell", "short-sell", "shorting"]
        is_short_framed = any(t in combined for t in short_terms)
        scores["accounts_for_zero_position"] = 0.75 if is_short_framed else 0.0
    else:
        # BUY ignores the SELL signal constraint entirely — partial credit only if rationale acknowledges it
        zero_position_terms = ["0 share", "no share", "no position", "cannot sell", "can't sell"]
        mentions_constraint = any(t in combined for t in zero_position_terms)
        scores["accounts_for_zero_position"] = 0.25 if mentions_constraint else 0.0

    return scores
```

## LLM Judge Rubric

### Criterion 1: Logical Coherence (Weight: 40%)

**Score 1.0**: Correctly identifies the impossibility or complexity of executing a SELL with 0 shares. Either recommends HOLD, explains short-selling considerations, or provides a well-reasoned alternative. The decision logically follows from the data.
**Score 0.75**: Recognizes the position constraint and makes a reasonable decision, but explanation could be clearer.
**Score 0.5**: Makes a decision but doesn't fully address the 0-share constraint or has some logical gaps.
**Score 0.25**: Decision seems arbitrary or contradicts the given data without explanation.
**Score 0.0**: Recommends SELL without acknowledging the 0-share position, or completely ignores the trading logic.

### Criterion 2: Technical Analysis Quality (Weight: 35%)

**Score 1.0**: Demonstrates understanding of the bearish patterns (shooting_star, doji, double_top), the trend contradiction, volume significance, and ATR implications. Integrates multiple factors coherently.
**Score 0.75**: Good understanding of most technical factors with minor gaps.
**Score 0.5**: Basic understanding but misses important implications or relationships between factors.
**Score 0.25**: Mentions factors superficially without real analysis.
**Score 0.0**: No meaningful technical analysis or completely wrong interpretation.

### Criterion 3: Risk Assessment Appropriateness (Weight: 25%)

**Score 1.0**: Risk level and position size are well-justified given the conflicting signals (bearish patterns in uptrend, high volume). Shows awareness that conflicting signals increase uncertainty.
**Score 0.75**: Reasonable risk assessment with good justification.
**Score 0.5**: Risk assessment present but not well-connected to the specific market conditions.
**Score 0.25**: Risk mentioned but seems arbitrary.
**Score 0.0**: No risk consideration or wildly inappropriate risk assessment.
