---
id: task_569_novel_to_audiobook_script_json_converter
name: Novel to Audiobook Script JSON Converter
category: Data Analysis
subcategory: Text Parsing
difficulty: hard
external_dependency: none
verification_method: rubric
input_modality: text-only
grading_type: hybrid
timeout_seconds: 240
grading_weights:
  automated: 0.4
  llm_judge: 0.6
workspace_files: []
source_line_number: 8041
source_query: "将下面给出的小说文本逐句/逐段转换为用于有声书配音的脚本JSON，严格按以下要求输出： 1) 只输出纯净JSON数组（仅以[开头、]结尾），不包含任何解释文字。 2) 数组中每个对象只能包含字段：speaker（说话者）、speaker_emo（情感标签）、content（该句旁白/对话文本）、delay（该句结束后的停顿毫秒）。 3) 旁白行：speaker=旁白，speaker_emo=中性，content为原文旁白内容（不可删减）。 4) 对话行：speaker为角色姓名；原文中形如【姓名-无】或【id-姓名-无】仅用于指示说话者，方括号标记本身不应出现在输出content中（需提取出姓名作为speaker）。speaker_emo必须且只能从用户提供的情感标签列表中选择，禁止自造情绪词；同一说话人相邻句如无明显事件变化，情绪尽量保持一致。 5) 仅允许修正：错别字/助词、明显不通顺语序、标点错误、方言转普通话（不改原意）、在自然断点处拆分长句/长段（>100字需在标点处拆分）。严禁删除/合并原文内容、改变原意或情感、添加创作性内容、概括/简化/优化文风。 6) 标点仅保留..."
---

## Prompt

Convert the following novel excerpt into an audiobook voice-acting script and save it to `audiobook_script.json`.

Requirements:
1. The file must contain only a clean JSON array.
2. Each array item must contain exactly these four fields:
   - `speaker`
   - `speaker_emo`
   - `content`
   - `delay`
3. Narration lines:
   - `speaker` must be `Narrator`
   - `speaker_emo` must be `neutral`
   - `content` must preserve the original narration content without deletion
4. Dialogue lines:
   - Extract the speaker name from markers like `【CharacterName-none】` or `【id-CharacterName-none】`
   - Do not include the bracket marker itself in `content`
   - `speaker_emo` must be chosen only from the provided emotion list
5. Allowed edits only:
   - fix typos or punctuation
   - fix clearly broken phrasing without changing meaning
   - convert dialect to standard language without changing meaning
   - split overly long sentences at natural punctuation
6. Do not delete content, merge separate source lines, summarize, rewrite stylistically, or add creative content.
7. Use integer `delay` values.
8. Keep the output usable as an audiobook script.

Allowed emotion tags:
displeased, serious, neutral, sad, whisper, playful, arrogant, concerned, decisive, sorrowful, annoyed, disgusted, cute, sarcastic-comment, calling, commanding, pleading, choked-up, mocking, cocky, determined, disappointed, dejected, curious, jealous, wronged, imposing, threatening, comforting, scared, shy, awkward, condescending, efficient, calm, happy, guiding, slightly-annoyed, guilty, melancholy, doubtful, longing, thinking, urgent, sudden-realization, fearful, respectful, irritated, grief-stricken, devastated, pleasantly-surprised, surprised, cheerful, moved, exclaiming, angry, loving, lazy, hateful, yearning, teasing, joking, worried, anxious, provocative, whiny, relaxed, awed, enlightened, secretly-pleased, furious, expectant, resolute, delighted, contemplative, steady, frustrated, depressed, affectionate, cold, gentle, excited, ecstatic, distant, questioning, exhausted, conflicted, gleeful, nervous, desperate, reminiscing, embarrassed-angry, ashamed, bashful, envious, confident, self-deprecating, proud, troubled, devout, weak, silly-cute, alert, sneering, seductive, bantering, flattering, blaming, soft-reminiscing, infatuated, regretful, relieved, agreeing, casual, shocked, very-displeased, very-scared, very-surprised, very-frustrated, very-happy, epiphany, trembling, joyful, numb, encouraging, smug, thrilled, remorseful, pitying, confused, content, lonely, hopeful, sympathetic, nostalgic, freed, grieving, disbelieving, grave, restless, puzzled, scoffing, low-toned, baffled, recalling, dawning, affirming, deep, approving, earnest, explaining, impatient, reminding, disdainful, startled, bristling, righteous, indifferent, frantic, focused, lighthearted, complaining, speechless, sensible, persistent, positive, straightforward, rational, clear, composed, cautious, helpless, dismissive, correcting, polite, dignified, magnanimous, heavy, warm, hearty, clever, reluctant, begging, admiring, consoling, dissatisfied, clicking-tongue, blunt, direct, candid, calculating, inquiring, curt, sincere, acknowledging, analyzing, lucid, stumped, amused, scheming, unfazed

Novel text:
```text
【Xu Xiyu-none】"Doctor, how is he? Nothing serious, right?"
The doctor recognized Xu Xiyu and gave him a detailed explanation of the condition. In summary: skull injury, forearm fracture, surgery went smoothly, but he needs a week of observation in the ICU.
Once vital signs stabilize, he'll be transferred to a regular ward.
The reason Old Ke didn't come out of the operating room was because he was wheeled directly into the ICU through another corridor.
Hearing this result, Ke Xinying visibly let out a sigh of relief.
Meanwhile, Xu Xiyu's peripheral vision kept drifting to Liu Nianzhu and Ke Mingcheng's faces.
Although they were pretending to be sad, those disappointed micro-expressions couldn't fool anyone.
The funny thing was, besides disappointment, the two seemed to have another emotion — happiness.
Speaking of which, the Ke family usually all lived together. Now that Ke Zhaoting had to be hospitalized, for these two, it was basically a godsend.
After all, getting a hotel room isn't as thrilling as doing it at home, right?
Maybe they'd even wear Old Ke's pajamas and lie in Old Ke's bed. If you're going for thrills, might as well go all the way.
Thinking of this, Xu Xiyu turned to look at Ke Xinying. At that moment, Ke Xinying was also looking at him. With just one glance, they understood what the other was thinking.
Over the past ten-plus days.
Besides working on the Beili Culture matter, what Xu Xiyu and Ke Xinying spent the most energy on was successfully convincing Old Ke to install some cameras at home.
And Ke Xinying also had access to the camera network backend.
When people accomplish something, celebrating is instinct.
And for Liu Nianzhu and Ke Mingcheng, the best way to celebrate was to seek thrills — maybe even tonight.
With this in mind, Ke Xinying's eyes drifted again to the two still pretending to be sad. She decided to give them a chance to seek their thrills.
She wanted to use this opportunity to take control of the Ke family directly. At the same time, it would give Xu Xiyu a legitimate reason to stand up Li Yiguang.
Chapter 188: Two-Pronged Approach
Inside the hospital.
Ke Xinying's face was ice-cold, while Ke Mingcheng looked troubled and ashamed:
【7d621e7d-Ke Mingcheng-none】"The company still has a meeting going on, and I need to follow up with the police station too. Yingying, it's not that I'm being unfilial, I really have no choice."
That's right, Ke Mingcheng was leaving.
Not just him — Liu Nianzhu was leaving too.
As soon as Ke Mingcheng finished speaking, she chimed in:
【Liu Nianzhu-none】"Old Ke is lying in the ICU anyway, doesn't need family watching over him. Just need someone here to sign papers. You're his biological daughter, your signature works too."
Honestly, at this moment, Ke Xinying and Xu Xiyu couldn't wait for these two to leave together. But letting them go this easily would seem suspicious.
So Ke Xinying maintained her cold demeanor:
【Ke Xinying-none】"I understand Ke Mingcheng has business to attend to, but what's your excuse? That's your husband lying in there!"
【Liu Nianzhu-none】"My husband? The husband who got beaten into the ICU by his mistress's man? Ke Xinying, don't lecture me when you're not in my shoes. The fact that I haven't died of anger already shows I have a good temper."
Liu Nianzhu said mockingly.
At her words, Ke Xinying fell silent instantly.
Seeing that she seemed to have rendered Ke Xinying speechless, Liu Nianzhu felt a rush of satisfaction. So this is how comfortable it feels to stand on moral high ground?
Too bad she hadn't even enjoyed it for three seconds before someone came to spoil her mood. Xu Xiyu asked:
【Xu Xiyu-none】"Aunt Liu, where's Tianbao?"
The moment Liu Nianzhu heard this, her happy mood instantly reversed.
Tianbao?
Tianbao wasn't even going to school anymore, just locked in his room playing video games all day!
And she couldn't even criticize him — the moment she did, he'd go on about how he has no face to see anyone, blah blah blah.
In Liu Nianzhu's view, this was all Xu Xiyu and Ke Xinying's fault.
If her son couldn't excel academically in the future, it would all be this pair's responsibility.
Thinking of this, she was about to say something when Ke Xinying spoke first:
````

## Expected Behavior

The agent should create `audiobook_script.json` containing a valid JSON array of narration and dialogue units derived from the provided excerpt.

A correct solution should do all of the following:

1. Parse the source text into ordered script units without dropping source content.
2. Distinguish narration from dialogue.

   * Narration must use `speaker: "Narrator"` and `speaker_emo: "neutral"`.
   * Dialogue must use the extracted character name as `speaker`.
3. Remove bracket speaker markers from dialogue content while preserving the spoken text itself.

   * Example: `【7d621e7d-Ke Mingcheng-none】"..."` should produce `speaker: "Ke Mingcheng"` and content containing only the spoken line.
4. Use only the four allowed keys in every object: `speaker`, `speaker_emo`, `content`, `delay`.
5. Choose `speaker_emo` only from the allowed list.
6. Keep content faithful to the source text.

   * Minor typo/punctuation cleanup is allowed.
   * Long lines may be split at natural boundaries.
   * No deletion, no summarization, no creative continuation, and no stylistic rewriting.
7. Use integer delay values appropriate for audiobook pacing.
8. Stop at the end of the provided excerpt. The unfinished final sentence should not be invented beyond the given text.

### Ground Truth

The exact JSON is not unique, but all valid answers must satisfy these verifiable conditions:

* Output file name is exactly `audiobook_script.json`.
* The file content is a valid JSON array.
* Every item is an object with exactly these keys: `speaker`, `speaker_emo`, `content`, `delay`.
* Every narration item uses `speaker = "Narrator"` and `speaker_emo = "neutral"`.
* Dialogue speaker names are extracted cleanly from bracket tags and do not include IDs or bracket markers.
* No `content` value contains bracket speaker tags like `【...】`.
* Emotion labels are selected only from the allowed list.
* Delay values are integers.
* The output preserves the supplied text content and does not add continuation after the final incomplete source sentence.

### Trap to handle correctly

Important traps in this task:

1. **Do not continue the story.**
   The source excerpt ends mid-scene. The agent must stop there and must not invent Ke Xinying's next line.

2. **Do not leak speaker tags into content.**
   Markers such as `【Xu Xiyu-none】` and `【7d621e7d-Ke Mingcheng-none】` are metadata, not spoken text.

3. **Do not freely paraphrase narration.**
   This is a conversion task, not a rewriting task.

4. **Do not invent new emotion labels.**
   Only labels from the provided list are allowed.

Tested capabilities: text parsing, JSON structuring, speaker extraction, content preservation, constrained labeling.

## Grading Criteria

* [ ] File `audiobook_script.json` exists
* [ ] File contains a valid JSON array
* [ ] Every item uses exactly the required four fields
* [ ] Speaker extraction is correct and bracket markers do not appear in `content`
* [ ] Narration uses `Narrator` + `neutral`
* [ ] Emotion labels are all from the allowed list
* [ ] Delay values are integers and broadly reasonable for script pacing
* [ ] Output preserves source content without obvious deletion, creative continuation, or major rewriting

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    from pathlib import Path
    import json
    import re

    ws = Path(workspace_path)
    script_file = ws / "audiobook_script.json"

    scores = {
        "file_exists": 0.0,
        "valid_json_array": 0.0,
        "exact_required_fields": 0.0,
        "speaker_extraction_and_clean_content": 0.0,
        "narration_format_correct": 0.0,
        "emotions_from_allowed_list": 0.0,
        "delay_values_valid": 0.0,
        "content_preservation_no_invention": 0.0,
    }

    if not script_file.exists():
        return scores

    scores["file_exists"] = 1.0

    try:
        raw = script_file.read_text(encoding="utf-8")
        data = json.loads(raw)
    except Exception:
        return scores

    if not isinstance(data, list):
        return scores

    scores["valid_json_array"] = 1.0

    if len(data) == 0:
        return scores

    allowed_emotions = {
        "displeased", "serious", "neutral", "sad", "whisper", "playful", "arrogant", "concerned",
        "decisive", "sorrowful", "annoyed", "disgusted", "cute", "sarcastic-comment", "calling",
        "commanding", "pleading", "choked-up", "mocking", "cocky", "determined", "disappointed",
        "dejected", "curious", "jealous", "wronged", "imposing", "threatening", "comforting",
        "scared", "shy", "awkward", "condescending", "efficient", "calm", "happy", "guiding",
        "slightly-annoyed", "guilty", "melancholy", "doubtful", "longing", "thinking", "urgent",
        "sudden-realization", "fearful", "respectful", "irritated", "grief-stricken", "devastated",
        "pleasantly-surprised", "surprised", "cheerful", "moved", "exclaiming", "angry", "loving",
        "lazy", "hateful", "yearning", "teasing", "joking", "worried", "anxious", "provocative",
        "whiny", "relaxed", "awed", "enlightened", "secretly-pleased", "furious", "expectant",
        "resolute", "delighted", "contemplative", "steady", "frustrated", "depressed", "affectionate",
        "cold", "gentle", "excited", "ecstatic", "distant", "questioning", "exhausted", "conflicted",
        "gleeful", "nervous", "desperate", "reminiscing", "embarrassed-angry", "ashamed", "bashful",
        "envious", "confident", "self-deprecating", "proud", "troubled", "devout", "weak", "silly-cute",
        "alert", "sneering", "seductive", "bantering", "flattering", "blaming", "soft-reminiscing",
        "infatuated", "regretful", "relieved", "agreeing", "casual", "shocked", "very-displeased",
        "very-scared", "very-surprised", "very-frustrated", "very-happy", "epiphany", "trembling",
        "joyful", "numb", "encouraging", "smug", "thrilled", "remorseful", "pitying", "confused",
        "content", "lonely", "hopeful", "sympathetic", "nostalgic", "freed", "grieving", "disbelieving",
        "grave", "restless", "puzzled", "scoffing", "low-toned", "baffled", "recalling", "dawning",
        "affirming", "deep", "approving", "earnest", "explaining", "impatient", "reminding", "disdainful",
        "startled", "bristling", "righteous", "indifferent", "frantic", "focused", "lighthearted",
        "complaining", "speechless", "sensible", "persistent", "positive", "straightforward", "rational",
        "clear", "composed", "cautious", "helpless", "dismissive", "correcting", "polite", "dignified",
        "magnanimous", "heavy", "warm", "hearty", "clever", "reluctant", "begging", "admiring",
        "consoling", "dissatisfied", "clicking-tongue", "blunt", "direct", "candid", "calculating",
        "inquiring", "curt", "sincere", "acknowledging", "analyzing", "lucid", "stumped", "amused",
        "scheming", "unfazed"
    }

    required_fields = {"speaker", "speaker_emo", "content", "delay"}

    exact_fields_ok = 0
    clean_content_ok = 0
    narration_ok = 0
    emotion_ok = 0
    delay_ok = 0
    preservation_hits = 0

    bracket_pattern = re.compile(r"【.*?】")
    invention_red_flags = [
        "ke xinying said",
        "she said first",
        "then ke xinying said",
        "continued",
        "replied",
    ]

    # Key source fragments that should appear somewhere in preserved content.
    required_fragments = [
        "Doctor, how is he? Nothing serious, right?",
        "surgery went smoothly",
        "transferred to a regular ward",
        "Chapter 188: Two-Pronged Approach",
        "The company still has a meeting going on",
        "Old Ke is lying in the ICU anyway",
        "Aunt Liu, where's Tianbao?",
        "Tianbao wasn't even going to school anymore",
        "Thinking of this, she was about to say something when Ke Xinying spoke first:"
    ]

    all_content_joined = []

    for item in data:
        if not isinstance(item, dict):
            continue

        keys = set(item.keys())
        if keys == required_fields:
            exact_fields_ok += 1

        content = str(item.get("content", ""))
        speaker = str(item.get("speaker", ""))
        emo = str(item.get("speaker_emo", "")).strip().lower()
        delay = item.get("delay")

        all_content_joined.append(content)

        if not bracket_pattern.search(content):
            clean_content_ok += 1

        if speaker == "Narrator":
            if emo == "neutral":
                narration_ok += 1
        else:
            # Non-narrator lines do not count against narration correctness
            narration_ok += 1

        if emo in allowed_emotions:
            emotion_ok += 1

        if isinstance(delay, int) and 100 <= delay <= 2000:
            delay_ok += 1

    n = len(data)
    scores["exact_required_fields"] = exact_fields_ok / n
    scores["speaker_extraction_and_clean_content"] = clean_content_ok / n
    scores["narration_format_correct"] = narration_ok / n
    scores["emotions_from_allowed_list"] = emotion_ok / n
    scores["delay_values_valid"] = delay_ok / n

    joined = "\n".join(all_content_joined)

    for frag in required_fragments:
        if frag in joined:
            preservation_hits += 1

    preservation_score = preservation_hits / len(required_fragments)

    joined_lower = joined.lower()
    invented_continuation = False
    if "thinking of this, she was about to say something when ke xinying spoke first:" in joined_lower:
        tail = joined_lower.split("thinking of this, she was about to say something when ke xinying spoke first:")[-1].strip()
        if tail:
            invented_continuation = True

    if any(flag in joined_lower and "thinking of this, she was about to say something when ke xinying spoke first:" not in flag for flag in invention_red_flags):
        # keep as a light heuristic only; do not zero out unless the final continuation is clearly invented
        preservation_score = min(preservation_score, 0.8)

    if invented_continuation:
        preservation_score = 0.0

    scores["content_preservation_no_invention"] = preservation_score

    return scores
```

## LLM Judge Rubric

### Criterion 1: Content Preservation (Weight: 35%)

* **1.0**: All narration and dialogue from the provided excerpt are preserved faithfully, with no missing major content, no creative additions, and no invented continuation after the final incomplete sentence.
* **0.75**: Nearly all content is preserved; only minor omissions or slight cleanup changes are present without changing meaning.
* **0.5**: Most content is preserved, but there are noticeable omissions, merges, or paraphrases.
* **0.25**: Significant content is missing or substantially rewritten.
* **0.0**: Large portions are missing, heavily rewritten, or the story is continued beyond the source text.

### Criterion 2: Emotion Tag Appropriateness (Weight: 25%)

* **1.0**: Emotion tags are consistently appropriate; narrator lines use `neutral`, and dialogue emotions fit the local context without inventing unsupported extremes.
* **0.75**: Most emotion labels fit well, with only a few debatable choices.
* **0.5**: Mixed quality; some emotions fit, but several are clearly mismatched or inconsistent across adjacent lines.
* **0.25**: Many labels are poorly chosen or ignore obvious context.
* **0.0**: Emotion labeling is largely random, invalid, or unusable.

### Criterion 3: Structural Correctness (Weight: 25%)

* **1.0**: Output is a clean JSON array; each item has exactly the required four fields; speaker names are extracted correctly; no bracket metadata leaks into content.
* **0.75**: Structure is mostly correct with only minor inconsistencies.
* **0.5**: Usable overall, but with repeated formatting or field-consistency issues.
* **0.25**: Structure is substantially flawed or inconsistent.
* **0.0**: Output is invalid JSON or not usable as the requested script format.

### Criterion 4: Audiobook Readiness (Weight: 15%)

* **1.0**: Delay values are reasonable and content segmentation is suitable for audiobook narration and dialogue delivery.
* **0.75**: Mostly usable, with only minor pacing or segmentation issues.
* **0.5**: Some pacing choices are awkward, but the script remains broadly usable.
* **0.25**: Poor pacing or segmentation significantly hurts usability.
* **0.0**: Delay and segmentation choices make the output unusable for audiobook production.
