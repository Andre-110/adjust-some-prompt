| 序号 | 修改项 | 修改原因 |
|---|---|---|
| 1 | 保留 `difficulty: hard` | 任务包含长文本解析、角色抽取、情绪标签受限选择、内容保真、JSON 结构化输出等多重约束，难度与 hard 匹配 |
| 2 | 重写 `## Prompt` | 原 Prompt 过于像规则清单，真实请求感较弱；同时保留必要约束，减少实现层细节堆砌 |
| 3 | 补充 `Expected Behavior` | 原版本过于概括，未完整写出正确处理路径，尤其缺少对未完结结尾不能续写的说明 |
| 4 | 新增 `Ground Truth` | 原题是开放式转换任务，没有唯一 JSON，但仍需给出可验证的 Ground Truth 条件集合 |
| 5 | 新增 `Trap to handle correctly` | 明确指出四个关键陷阱：续写、speaker tag 泄漏、自由改写、杜撰情绪标签 |
| 6 | 重写 `Grading Criteria` | 使条目更独立可判定，并与自动评分 key 一一对齐 |
| 7 | 重写 `grade()` 的 score keys | 原 key 未覆盖“exactly 四个字段”“旁白格式正确”“内容保真且不续写”等关键点，现已补齐 |
| 8 | 保留并强化“文件不存在全 0”逻辑 | 满足“空白零分”要求，并使所有 score key 显式归零 |
| 9 | 将字段检查从“required_fields.issubset”改为“exact keys” | 原逻辑允许额外字段混入，不符合“每个对象只能包含字段 speaker / speaker_emo / content / delay” |
| 10 | 增加 `narration_format_correct` 检查 | 原自动评分未检查 Narrator/neutral 的硬约束，与题意不完全一致 |
| 11 | 增加关键内容覆盖启发式 | 原评分几乎只看结构，不足以约束“不得删减原文”；现加入关键片段覆盖的弱监督 |
| 12 | 增加“不续写结尾”检查 | 原评分无法识别模型在最后一句后擅自续写，现加入明确检测 |
| 13 | 保留情绪与 delay 的比例评分 | 这部分原来有部分得分思路，修订后继续保留并增强整体一致性 |
| 14 | 修复 LLM Rubric 标题重复 | 原文最后一个维度误写成第二个 “Criterion 3”，现改为 “Criterion 4” |
| 15 | 调整 LLM Rubric 维度与表述 | 让四个维度覆盖内容保真、情绪、结构、可配音性，且权重和为 100% |
