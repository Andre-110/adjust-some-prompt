| 序号 | 修改项 | 修改原因 |
|---|---|---|
| 1 | 重写 Prompt，使文件输出要求更明确 | 原 Prompt 基本清楚，但“输出 should be a JSON file”与“直接做文件”边界还能更明确，修正后更利于可评分 |
| 2 | 明确只翻译 `names`，并明确不得输出 `allergens`、`ingredients` | 原 Prompt 虽提到 skip，但约束不够正式，容易被模型保留空字段 |
| 3 | 明确只保留目标语言，不保留源语言 | 强化结构要求，减少把 `en/de/fr/it` 一起带入输出的常见错误 |
| 4 | 补充 Expected Behavior 的完整结构说明 | 原版本较简略，没有把“只允许一个 top-level key: names”说清楚 |
| 5 | 增加 Ground Truth / expected output properties | 原版本缺少明确 Ground Truth，修正后更利于人工与模型统一判分 |
| 6 | 补充关键陷阱说明 | 明确不能输出源语言、不能保留空字段、不能改动固定 token、不能只在聊天中给 JSON 而不创建文件 |
| 7 | 扩充 Grading Criteria | 原标准未单独检查 top-level key 唯一性、空字段排除、值非空等关键点 |
| 8 | 优化 Grading Criteria 的独立性 | 让每条标准都能独立验证，覆盖结构、内容、约束、完整性 |
| 9 | 重写 LLM Judge Rubric | 原 Rubric 没有 1.0 / 0.75 / 0.5 / 0.25 / 0.0 的完整分档描述，不符合要求 |
| 10 | 将 Rubric 细化为 4 个维度 | 更好覆盖翻译质量、固定 token 保留、JSON 结构完整性、指令遵循 |
| 11 | 重写 `grade()`，增加统一 zero_scores | 满足“空白零分”，并确保 score key 稳定返回 |
| 12 | 增加 `has_only_names_top_key` | 原自动评分没检查 top-level 是否只有 `names`，容易漏判多余字段 |
| 13 | 将语言键检查改为“exact target set + partial score” | 原版只按存在数量算分，不能区分“数量对但多余键也在”的情况 |
| 14 | 增加 `no_empty_sections` | 原版没有真正检查顶层是否错误保留 `allergens`、`ingredients`、`target_languages` |
| 15 | 增加 `non_empty_values` | 原版未检查翻译值是否为空串，覆盖不足 |
| 16 | 保留并优化 brand / tech details 检查 | 继续覆盖固定 token 保留这一核心要求 |
| 17 | 保持 difficulty=medium 不变 | 该题既要求结构化输出文件，又要求多语言翻译和固定 token 保留，整体仍符合 medium |