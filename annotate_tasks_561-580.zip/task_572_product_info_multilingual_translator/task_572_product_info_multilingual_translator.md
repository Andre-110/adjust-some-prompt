---
id: task_572_product_info_multilingual_translator
name: Product Info Multilingual Translator
category: Data Analysis
subcategory: Data Processing and Management
difficulty: medium
external_dependency: none
verification_method: unit-test
input_modality: text-only
grading_type: hybrid
grading_weights:
  automated: 0.4
  llm_judge: 0.6
timeout_seconds: 180
workspace_files: []
source_line_number: 4349
source_query: "Translate the following product info JSON into all languages listed in target_languages. Translate each non-empty field (e.g., names, allergens, ingredients) into every target language, and return a JSON containing only translations for the target_languages.  Input JSON: {\"names\":{\"en\":\"Rioja blanco \\\"Mirando Al Sur\\\" DOCa, 75cl, 2020\",\"de\":\"Rioja blanco \\\"Mirando Al Sur\\\" DOCa, 75cl, 2020\",\"fr\":\"Rioja blanco \\\"Mirando Al Sur\\\" DOCa, 75cl, 2020\",\"it\":\"Rioja blanco..."
---

## Prompt

Please create a file named `translations.json` in the workspace based on the product JSON below.

Input JSON:
```json
{
  "names": {
    "en": "Rioja blanco \"Mirando Al Sur\" DOCa, 75cl, 2020",
    "de": "Rioja blanco \"Mirando Al Sur\" DOCa, 75cl, 2020",
    "fr": "Rioja blanco \"Mirando Al Sur\" DOCa, 75cl, 2020",
    "it": "Rioja blanco \"Mirando Al Sur\" DOCa, 75cl, 2020"
  },
  "allergens": {},
  "ingredients": {},
  "target_languages": ["bg", "cs", "da", "el", "es", "fi", "hu", "ja", "ko", "nb", "nl", "pl", "pt", "ro", "ru", "sv", "tr", "zh-tw"]
}
````

Task requirements:

* Translate only the non-empty `names` field into every language listed in `target_languages`.
* Do not include `allergens` or `ingredients` in the output because they are empty.
* Create `translations.json` with this structure:

```json
{
  "names": {
    "bg": "...",
    "cs": "...",
    "...": "..."
  }
}
```

* Include only the target language codes in the output.
* Do not include the original source language codes (`en`, `de`, `fr`, `it`) in the output.
* Preserve the product-specific elements exactly where appropriate:

  * `Mirando Al Sur`
  * `DOCa`
  * `75cl`
  * `2020`
* Translate only the descriptive product phrase (`Rioja blanco`) naturally into each target language.
* Write the result to the workspace file `translations.json`.

## Expected Behavior

The ideal response should:

1. Parse the input JSON and identify that:

   * `names` contains content and must be translated
   * `allergens` and `ingredients` are empty objects and should be omitted from the output
   * `target_languages` contains 18 required target language codes

2. Create a file named `translations.json` in the workspace.

3. Write a valid JSON object with exactly this top-level structure:

   * a single top-level key: `names`
   * `names` must be an object whose keys are exactly the 18 target language codes:

     * `bg`, `cs`, `da`, `el`, `es`, `fi`, `hu`, `ja`, `ko`, `nb`, `nl`, `pl`, `pt`, `ro`, `ru`, `sv`, `tr`, `zh-tw`

4. Preserve the non-translated product elements consistently across all translations:

   * brand / cuvée text: `Mirando Al Sur`
   * certification / designation: `DOCa`
   * volume: `75cl`
   * vintage year: `2020`

5. Translate the descriptive phrase `Rioja blanco` appropriately for each target language as the concept of “white Rioja” / “white Rioja wine”, while keeping the full product-name format natural and readable.

6. Exclude:

   * original language keys (`en`, `de`, `fr`, `it`)
   * empty sections such as `allergens` and `ingredients`
   * any extra commentary or wrapper structure beyond the requested JSON file content

Ground truth / expected output properties:

* The output artifact is a workspace file named `translations.json`.
* The JSON should contain exactly one top-level field: `names`.
* `names` should contain exactly 18 target-language entries and no source-language entries.
* Every translation should preserve `Mirando Al Sur`, `DOCa`, `75cl`, and `2020`.
* High-quality answers translate only the descriptive portion and keep wine/product naming conventions natural in each language.

Key traps to handle correctly:

* Do not echo the input languages into the output.
* Do not include empty `allergens` or `ingredients` sections.
* Do not translate or alter `Mirando Al Sur`, `DOCa`, `75cl`, or `2020`.
* Do not output the JSON only in chat without creating `translations.json`.

Tested capabilities: JSON parsing, structured file creation, multilingual translation, preservation of proper nouns and technical tokens, instruction following.

## Grading Criteria

* [ ] File `translations.json` exists and contains valid JSON
* [ ] JSON contains exactly one top-level key: `names`
* [ ] `names` contains exactly the 18 required target language codes
* [ ] Output does not include original language codes (`en`, `de`, `fr`, `it`)
* [ ] Output does not include empty sections such as `allergens` or `ingredients`
* [ ] All translations preserve `Mirando Al Sur`
* [ ] All translations preserve `DOCa`, `75cl`, and `2020`
* [ ] Each value under `names` is a non-empty string
* [ ] Translations are linguistically appropriate and only translate the descriptive phrase rather than product-specific tokens

## LLM Judge Rubric

### Dimension 1: Translation Accuracy (35%)

Assesses whether each translation correctly conveys the meaning of `Rioja blanco` as “white Rioja” / “white Rioja wine” in the target language.

* **1.0**: Translations are consistently accurate, natural, and appropriate across nearly all target languages.
* **0.75**: Most translations are accurate and natural, with only minor awkwardness or small terminology issues.
* **0.5**: Mixed quality; several translations are acceptable, but others are literal, awkward, or partially inaccurate.
* **0.25**: Many translations are weak, misleading, or insufficiently translated.
* **0.0**: Translations are largely incorrect, missing, or untranslated.

### Dimension 2: Preservation of Fixed Product Tokens (25%)

Assesses whether product-specific tokens are preserved exactly where required.

* **1.0**: `Mirando Al Sur`, `DOCa`, `75cl`, and `2020` are preserved correctly in all translations.
* **0.75**: Almost all translations preserve the required fixed tokens, with only minor inconsistency.
* **0.5**: Some required fixed tokens are preserved, but others are altered or missing in multiple entries.
* **0.25**: Preservation is inconsistent and unreliable.
* **0.0**: Fixed product tokens are frequently translated, removed, or corrupted.

### Dimension 3: JSON Structure and Completeness (25%)

Assesses whether the output file follows the required structure and includes the complete target language set.

* **1.0**: Output is valid JSON with exactly one top-level `names` object containing exactly the 18 required target language keys and no extra source-language keys.
* **0.75**: Structure is mostly correct, with only a small omission or minor extra content.
* **0.5**: Structure is partly correct but has multiple missing or extra keys.
* **0.25**: Structure is weak or incomplete and deviates notably from requirements.
* **0.0**: Output format is unusable or not aligned with the requested schema.

### Dimension 4: Instruction Compliance (15%)

Assesses whether the agent follows the non-translation and file-output constraints.

* **1.0**: Correctly omits empty fields, writes the file, and avoids extra content.
* **0.75**: Mostly compliant, with only minor deviation.
* **0.5**: Partially compliant; some requirements are missed.
* **0.25**: Multiple instruction-following failures.
* **0.0**: Major non-compliance, such as not creating the file or including clearly disallowed content.

Weights:

* Translation Accuracy: 35%
* Preservation of Fixed Product Tokens: 25%
* JSON Structure and Completeness: 25%
* Instruction Compliance: 15%

Total: 100%

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    from pathlib import Path
    import json

    score_keys = [
        "file_exists",
        "valid_json",
        "has_only_names_top_key",
        "correct_lang_keys",
        "no_original_langs",
        "no_empty_sections",
        "brand_preserved",
        "tech_details_preserved",
        "non_empty_values",
    ]

    def zero_scores():
        return {k: 0.0 for k in score_keys}

    ws = Path(workspace_path)
    trans_file = ws / "translations.json"

    target_langs = ["bg", "cs", "da", "el", "es", "fi", "hu", "ja", "ko", "nb", "nl", "pl", "pt", "ro", "ru", "sv", "tr", "zh-tw"]
    original_langs = ["en", "de", "fr", "it"]

    if not trans_file.exists():
        return zero_scores()

    scores = zero_scores()
    scores["file_exists"] = 1.0

    try:
        data = json.loads(trans_file.read_text(encoding="utf-8"))
    except Exception:
        return scores

    if not isinstance(data, dict):
        return scores

    scores["valid_json"] = 1.0

    top_keys = set(data.keys())
    scores["has_only_names_top_key"] = 1.0 if top_keys == {"names"} else 0.5 if "names" in top_keys else 0.0

    names = data.get("names")
    if not isinstance(names, dict):
        return scores

    name_keys = set(names.keys())
    target_set = set(target_langs)
    original_set = set(original_langs)

    exact_target_count = len(name_keys & target_set)
    extra_keys = name_keys - target_set
    missing_keys = target_set - name_keys

    if not extra_keys and not missing_keys:
        scores["correct_lang_keys"] = 1.0
    else:
        scores["correct_lang_keys"] = exact_target_count / len(target_langs)

    has_original = any(lang in name_keys for lang in original_set)
    scores["no_original_langs"] = 0.0 if has_original else 1.0

    forbidden_top_keys = {"allergens", "ingredients", "target_languages"}
    has_forbidden = any(k in data for k in forbidden_top_keys)
    scores["no_empty_sections"] = 0.0 if has_forbidden else 1.0

    present_targets = [lang for lang in target_langs if lang in names and isinstance(names[lang], str)]

    if present_targets:
        brand_count = 0
        tech_count = 0
        non_empty_count = 0

        for lang in present_targets:
            text = names[lang]
            if text.strip():
                non_empty_count += 1
            if "Mirando Al Sur" in text:
                brand_count += 1
            if "DOCa" in text and "75cl" in text and "2020" in text:
                tech_count += 1

        scores["brand_preserved"] = brand_count / len(target_langs)
        scores["tech_details_preserved"] = tech_count / len(target_langs)
        scores["non_empty_values"] = non_empty_count / len(target_langs)
    else:
        scores["brand_preserved"] = 0.0
        scores["tech_details_preserved"] = 0.0
        scores["non_empty_values"] = 0.0

    return scores
```