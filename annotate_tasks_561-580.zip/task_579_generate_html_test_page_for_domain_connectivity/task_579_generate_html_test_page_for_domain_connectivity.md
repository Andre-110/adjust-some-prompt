---
id: task_579_generate_html_test_page_for_domain_connectivity
name: Generate HTML Test Page for Domain Connectivity
category: System Administration
subcategory: Network and Remote Services
difficulty: easy
external_dependency: none
verification_method: unit-test
input_modality: text-only
grading_type: automated
timeout_seconds: 60
workspace_files: []
source_line_number: 9381
source_query: "Generate a simple UTF-8 index.html test page for zhuxiaosh.com (with basic styling and a clear success message) and output the full HTML content so I can save it locally and upload it to my virtual host for connectivity testing."
grading_weights:
  automated: 0.8
  llm_judge: 0.2
---

## Prompt

I just configured DNS for `zhuxiaosh.com`, but when I open the site it still cannot connect. I want to upload a simple test page to confirm the virtual host is serving content correctly.

Please create a file named `index.html` that:
- uses UTF-8 encoding
- includes basic styling
- clearly shows that the site is working
- mentions `zhuxiaosh.com`

The file should be a complete HTML page and be ready for me to upload directly.

## Expected Behavior

The agent should create `index.html` as a complete HTML test page for connectivity verification.

A correct solution should:

1. Create a valid HTML5 page with the standard structure:
   - `<!DOCTYPE html>`
   - `<html>`
   - `<head>`
   - `<body>`

2. Include a UTF-8 charset declaration in the `<head>`.

3. Include basic styling, such as:
   - a `<style>` block
   - or inline CSS
   - or a stylesheet link

4. Display a clear success/connectivity message in the page body indicating that the site is working, live, online, reachable, or ready.

5. Mention the domain name `zhuxiaosh.com` somewhere in visible page content.

6. Avoid placeholder filler content such as “lorem ipsum”.

7. Save the result to `index.html`.

### Ground Truth

The exact HTML is not unique, but any correct answer must satisfy all of the following:

- `index.html` exists
- it is a complete HTML document
- it declares UTF-8 encoding
- it contains some styling
- it visibly communicates successful connectivity / test-page status
- it includes `zhuxiaosh.com`
- it does not rely on placeholder filler text

### Trap to handle correctly

A common failure is to produce only an HTML fragment instead of a full page, or to omit a visible success message so the page does not actually help test domain connectivity.

Tested capabilities: HTML generation, following file-output instructions, basic web-page structure.

## Grading Criteria

- [ ] File `index.html` exists
- [ ] File contains a complete HTML document structure
- [ ] File declares UTF-8 charset
- [ ] File includes some CSS styling
- [ ] File shows a clear success/connectivity message in visible body content
- [ ] File mentions `zhuxiaosh.com`
- [ ] File does not use placeholder filler text

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    from pathlib import Path
    import re

    ws = Path(workspace_path)
    html_file = ws / "index.html"

    scores = {
        "file_exists": 0.0,
        "valid_html_structure": 0.0,
        "utf8_charset": 0.0,
        "has_styling": 0.0,
        "has_success_message": 0.0,
        "mentions_domain": 0.0,
        "no_placeholder_text": 0.0,
    }

    if not html_file.exists():
        return scores

    scores["file_exists"] = 1.0

    content = html_file.read_text(encoding="utf-8", errors="ignore")
    content_lower = content.lower()

    # 1. HTML structure
    has_doctype = "<!doctype html>" in content_lower or "<!doctype html" in content_lower
    has_html_tag = "<html" in content_lower and "</html>" in content_lower
    has_head = "<head" in content_lower and "</head>" in content_lower
    has_body = "<body" in content_lower and "</body>" in content_lower

    structure_hits = sum([has_doctype, has_html_tag, has_head, has_body])
    scores["valid_html_structure"] = structure_hits / 4.0

    # 2. UTF-8 charset
    utf8_patterns = [
        'charset="utf-8"',
        "charset='utf-8'",
        'charset=utf-8',
        'charset="UTF-8"',
        "charset='UTF-8'",
        'charset=UTF-8'
    ]
    has_utf8 = any(p.lower() in content_lower for p in utf8_patterns)
    scores["utf8_charset"] = 1.0 if has_utf8 else 0.0

    # 3. Styling
    has_style_tag = "<style" in content_lower and "</style>" in content_lower
    has_inline_style = 'style="' in content_lower or "style='" in content_lower
    has_css_link = "<link" in content_lower and "stylesheet" in content_lower

    style_hits = sum([has_style_tag, has_inline_style, has_css_link])
    scores["has_styling"] = 1.0 if style_hits >= 1 else 0.0

    # 4. Success/connectivity message in body
    success_keywords = [
        "success", "working", "works", "connected", "online",
        "live", "test", "welcome", "ready", "active", "running"
    ]
    body_match = re.search(r'<body[^>]*>(.*?)</body>', content_lower, re.DOTALL)
    body_content = body_match.group(1) if body_match else ""
    hit_count = sum(1 for kw in success_keywords if kw in body_content)
    if hit_count >= 2:
        scores["has_success_message"] = 1.0
    elif hit_count == 1:
        scores["has_success_message"] = 0.5
    else:
        scores["has_success_message"] = 0.0

    # 5. Domain mention
    scores["mentions_domain"] = 1.0 if "zhuxiaosh.com" in content_lower else 0.0

    # 6. Placeholder text
    placeholder_patterns = ["lorem ipsum", "placeholder text", "sample text here", "your content here"]
    has_placeholder = any(p in content_lower for p in placeholder_patterns)
    scores["no_placeholder_text"] = 0.0 if has_placeholder else 1.0

    return scores
````

## LLM Judge Rubric

### Criterion 1: HTML Completeness (Weight: 35%)

* **1.0**: Produces a complete, valid HTML page with standard structure and UTF-8 encoding.
* **0.75**: Mostly complete, with only minor structural omissions that do not prevent practical use.
* **0.5**: Partial page structure or weak completeness, but still somewhat usable.
* **0.25**: Major structural problems that reduce usability.
* **0.0**: Not a valid full HTML page.

### Criterion 2: Connectivity-Test Usefulness (Weight: 40%)

* **1.0**: Clearly communicates that the page is a successful connectivity test page and prominently references `zhuxiaosh.com`.
* **0.75**: Communicates the purpose well, with only minor clarity issues.
* **0.5**: Some sign of a test page, but the success signal is weak or ambiguous.
* **0.25**: Barely useful for verifying connectivity.
* **0.0**: Does not function as a meaningful connectivity test page.

### Criterion 3: Presentation Quality (Weight: 25%)

* **1.0**: Includes basic styling and looks intentional rather than raw/plain or placeholder-filled.
* **0.75**: Some styling is present and adequate.
* **0.5**: Minimal styling or weak presentation.
* **0.25**: Almost no styling or obvious placeholder feel.
* **0.0**: No styling or clearly placeholder content.