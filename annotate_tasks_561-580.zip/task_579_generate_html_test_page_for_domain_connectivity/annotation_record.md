| 序号 | 修改项 | 修改原因 |
|---|---|---|
| 1 | 补充 `grading_weights` | 原文件缺少 automated 与 llm_judge 权重配置，不满足规范 |
| 2 | 微调 `## Prompt` | 保留原始意图，同时让请求更自然、清晰，避免过于像任务分解说明 |
| 3 | 补充 `Expected Behavior` | 原版本缺少完整正确解题路径和更明确的可验证目标 |
| 4 | 新增 `Ground Truth` | 虽然 HTML 内容不唯一，但需要明确列出合格输出的验证条件 |
| 5 | 新增 `Trap to handle correctly` | 明确指出常见失败模式：只给 HTML 片段或没有可见成功信息 |
| 6 | 调整 `Grading Criteria` 文案 | 让条目与自动评分 key 更严格一一对应 |
| 7 | 重写 `grade()` 初始化逻辑 | 保证文件不存在时所有 score key 明确返回 0.0 |
| 8 | 为 HTML 结构检查增加部分得分 | 原逻辑纯 0/1；现在按 doctype/html/head/body 命中数量给分，更符合“部分得分”要求 |
| 9 | 为成功消息检查增加部分得分 | 原逻辑只要命中任意一个关键词就满分，过宽松；现在按关键词覆盖程度区分 0 / 0.5 / 1.0 |
| 10 | 新增 `LLM Judge Rubric` | 原文件缺失 Rubric，不满足维度 E 要求 |