| 序号 | 修改项 | 修改原因 |
|---|---|---|
| 1  | 保持 `difficulty: easy` 不变  | 该题只要求创建目录与 markdown 文件，并写入简单模板，复杂度与 easy 匹配。                                                                |
| 2  | 轻微重写 `## Prompt`          | 原 Prompt 基本清晰，但 “today's memory file” 与固定日期 `2026-02-23` 容易产生歧义。已改为明确“本题以 2026-02-23 作为 today”，避免和真实当前日期混淆。 |
| 3  | 补充 `## Expected Behavior` | 原 Expected Behavior 基本完整，但缺少对“不要留占位符”“模板应可直接使用”的明确说明。已补充 Ground Truth 与关键约束。                                |
| 4  | 重写 `## Grading Criteria`  | 原条目可用，但“Tasks/Notes/Completed”分别拆开后区分度有限；现保留独立可验性，同时使条目与自动评分 key 更清晰对齐。                                     |
| 5  | 重写 `## Automated Checks`  | 原 `grade()` 可运行，但几乎全是 0/1，部分得分不足；且未检查文件是否为常规文件、占位符检查偏窄。已增强为支持部分得分、空白输出全 0、格式更稳。                             |
| 6  | 轻微修正 `source_query`       | 原 `source_query` 用“今日”描述，和硬编码日期可能冲突；已改为明确指定该任务中的 today 即 `2026-02-23`。                                      |
