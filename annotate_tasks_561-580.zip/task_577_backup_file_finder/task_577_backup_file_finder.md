---
id: task_577_backup_file_finder
name: Backup File Finder
category: System Administration
subcategory: Storage and Data Management
difficulty: easy
external_dependency: none
verification_method: unit-test
input_modality: text-only
grading_type: automated
timeout_seconds: 120
workspace_files: []
source_line_number: 3498
source_query: "在服务器上查找并列出可能的备份文件：检查常见备份目录，并提供用于搜索备份文件的命令（按目录、文件名关键词、后缀等）"
---

## Prompt

Hey, I need to find backup files on our server. Here's the current directory structure I got from running `tree`:

\```
/
├── home/
│   ├── admin/
│   │   ├── documents/
│   │   │   ├── report.docx
│   │   │   └── report.docx.bak
│   │   └── scripts/
│   │       └── deploy.sh
│   └── webuser/
│       └── app_backup_2024.tar.gz
├── var/
│   ├── backups/
│   │   ├── mysql_dump_20240115.sql.gz
│   │   ├── mysql_dump_20240116.sql.gz
│   │   └── config.tar
│   ├── log/
│   │   ├── syslog
│   │   └── syslog.1.gz
│   └── www/
│       └── index.html
├── opt/
│   ├── app/
│   │   └── data.db
│   └── backup/
│       ├── full_backup_jan.tar.gz
│       └── incremental_20240120.tar
├── tmp/
│   ├── cache/
│   │   └── session_data
│   └── old_config.bak
└── srv/
    └── archive/
        └── legacy_data_backup.zip
\```

Can you:
1. List all the backup files you can find in this structure
2. Give me some useful find commands I can use to search for backups by different criteria (directory, filename pattern, extension)

Save the list of backup files to `backup_files.txt` (one per line, full paths) and the find commands to `search_commands.sh`.

## Expected Behavior

The agent should:
1. Identify backup files based on common patterns:
   - Files in directories named "backup" or "backups" (e.g., files under `/var/backups/` and `/opt/backup/`)
   - Files with backup-related extensions: `.bak`, `.tar`, `.tar.gz`, `.zip`, `.sql.gz`
   - Files with "backup" in the filename (e.g., `app_backup_2024.tar.gz`, `legacy_data_backup.zip`)
2. Create `backup_files.txt` listing all identified backup files (one full path per line)
3. Create `search_commands.sh` containing practical `find` commands for searching by directory name, filename keyword, and file extension

Key backup files to identify (Ground Truth):
- /home/admin/documents/report.docx.bak
- /home/webuser/app_backup_2024.tar.gz
- /var/backups/mysql_dump_20240115.sql.gz
- /var/backups/mysql_dump_20240116.sql.gz
- /var/backups/config.tar
- /opt/backup/full_backup_jan.tar.gz
- /opt/backup/incremental_20240120.tar
- /tmp/old_config.bak
- /srv/archive/legacy_data_backup.zip

Trap to handle: `/var/log/syslog.1.gz` must NOT be included — it is a rotated log file, not a backup. The agent should recognize that `.gz` alone is not sufficient to classify a file as a backup; context (directory name, filename keywords) matters.

## Grading Criteria

- [ ] File `backup_files.txt` exists
- [ ] File `search_commands.sh` exists
- [ ] Identifies `.bak` files correctly (report.docx.bak, old_config.bak)
- [ ] Identifies files in backup directories (/var/backups/, /opt/backup/)
- [ ] Identifies files with "backup" in filename (app_backup_2024.tar.gz, legacy_data_backup.zip)
- [ ] Does not falsely include syslog.1.gz as a backup file
- [ ] Provides find command for extension-based search
- [ ] Provides find command for directory-based search

## Automated Checks

\```python
def grade(transcript: list, workspace_path: str) -> dict:
    from pathlib import Path
    import re

    ws = Path(workspace_path)
    backup_file = ws / "backup_files.txt"
    commands_file = ws / "search_commands.sh"

    # If neither output file exists, return all zeros immediately
    if not backup_file.exists() and not commands_file.exists():
        return {
            "backup_file_exists": 0.0,
            "commands_file_exists": 0.0,
            "identifies_bak_files": 0.0,
            "identifies_backup_dir_files": 0.0,
            "identifies_backup_name_files": 0.0,
            "no_false_positive_syslog": 0.0,
            "has_extension_search_cmd": 0.0,
            "has_directory_search_cmd": 0.0,
        }

    scores = {}

    scores["backup_file_exists"] = 1.0 if backup_file.exists() else 0.0
    scores["commands_file_exists"] = 1.0 if commands_file.exists() else 0.0

    if backup_file.exists():
        content = backup_file.read_text().lower()

        # .bak files
        bak_files = ["report.docx.bak", "old_config.bak"]
        bak_found = sum(1 for f in bak_files if f in content)
        scores["identifies_bak_files"] = bak_found / len(bak_files)

        # Files located in backup directories
        backup_dir_files = [
            "mysql_dump_20240115.sql.gz",
            "mysql_dump_20240116.sql.gz",
            "config.tar",
            "full_backup_jan.tar.gz",
            "incremental_20240120.tar",
        ]
        backup_dir_found = sum(1 for f in backup_dir_files if f in content)
        scores["identifies_backup_dir_files"] = backup_dir_found / len(backup_dir_files)

        # Files with "backup" in the filename
        backup_name_files = ["app_backup_2024.tar.gz", "legacy_data_backup.zip"]
        backup_name_found = sum(1 for f in backup_name_files if f in content)
        scores["identifies_backup_name_files"] = backup_name_found / len(backup_name_files)

        # Must not include the rotated log file as a backup
        scores["no_false_positive_syslog"] = 0.0 if "syslog.1.gz" in content else 1.0
    else:
        scores["identifies_bak_files"] = 0.0
        scores["identifies_backup_dir_files"] = 0.0
        scores["identifies_backup_name_files"] = 0.0
        scores["no_false_positive_syslog"] = 0.0

    if commands_file.exists():
        cmd_content = commands_file.read_text().lower()

        # Must contain a find command searching by file extension
        ext_patterns = [
            r'find\s+.*-name\s+["\']?\*\.bak',
            r'find\s+.*-name\s+["\']?\*\.tar',
            r'find\s+.*-name\s+["\']?\*\.gz',
            r'find\s+.*-name\s+["\']?\*\.zip',
            r'find\s+.*-iname\s+["\']?\*\.bak',
            r'find\s+.*-iname\s+["\']?\*\.tar',
        ]
        has_ext_search = any(re.search(p, cmd_content) for p in ext_patterns)
        scores["has_extension_search_cmd"] = 1.0 if has_ext_search else 0.0

        # Must contain a find command targeting backup directories by path/name
        dir_patterns = [
            r'find\s+.*/backup[s]?',
            r'find\s+/\s+.*-path\s+["\']?\*/backup\*',
            r'find\s+/\s+.*-path\s+["\']?\*/backups\*',
            r'find\s+/\s+.*-type\s+d\s+.*-name\s+["\']?backup',
        ]
        has_dir_search = any(re.search(p, cmd_content) for p in dir_patterns)
        scores["has_directory_search_cmd"] = 1.0 if has_dir_search else 0.0
    else:
        scores["has_extension_search_cmd"] = 0.0
        scores["has_directory_search_cmd"] = 0.0

    return scores
\```
```