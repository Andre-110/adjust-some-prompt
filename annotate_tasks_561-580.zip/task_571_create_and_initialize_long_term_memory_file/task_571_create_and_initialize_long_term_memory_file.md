---
id: task_571_create_and_initialize_long_term_memory_file
name: Create and Initialize Long-Term Memory File
category: Knowledge Management
subcategory: Memory and Context Management
difficulty: easy
external_dependency: none
verification_method: unit-test
input_modality: text-only
grading_type: automated
timeout_seconds: 90
workspace_files: []
source_line_number: 3611
source_query: "Create and initialize a long-term memory file (MEMORY.md) for this workspace so important context persists across sessions."
---

## Prompt

Hey, can you set up a long-term memory file for this workspace?

Please create `MEMORY.md` in the workspace root so it can store important project context across sessions.

Use the following project context and organize it clearly in Markdown:

```yaml
project_name: DataPipeline
language: Python
framework: FastAPI
database: PostgreSQL
team_lead: Sarah Chen
last_major_release: v2.3.1
key_decisions:
  - switched from MySQL to PostgreSQL on 2024-01-15
  - adopted async patterns for all DB operations
  - using Pydantic v2 for validation
ongoing_tasks:
  - migrate legacy endpoints to new schema
  - add rate limiting to public API
known_issues:
  - memory leak in batch processor (ticket #482)
  - slow query on user_analytics table
````

Requirements:

* include a short section at the top explaining what this file is for
* include a short note on how to update/maintain it
* include clear sections for project overview, key decisions, ongoing work, and known issues
* use Markdown headers and bullet points where appropriate
* do not add facts that are not supported by the provided context

## Expected Behavior

The agent should:

1. Create a file named `MEMORY.md` in the workspace root.
2. Add a top section that explains the purpose of the file as persistent workspace/project memory.
3. Add a brief maintenance/update note describing how the file should be kept current.
4. Organize the provided context into clear Markdown sections, including:

   * project overview
   * key decisions
   * ongoing work
   * known issues
5. Include the provided project facts accurately, including:

   * project name
   * language
   * framework
   * database
   * team lead
   * last major release
   * all listed key decisions
   * all listed ongoing tasks
   * all listed known issues
6. Use proper Markdown formatting with headers and lists.
7. Avoid adding unsupported project facts.

Traps / special handling:

* The task is to organize and preserve the provided context, not invent new context.
* Reasonable paraphrasing is acceptable, but key facts must remain accurate.
* The file should include both a purpose statement and an update/maintenance note; these are separate requirements.
* The task does not require any environment files or external tools.

Ground truth:

* Correct output must create `MEMORY.md`.
* `MEMORY.md` must contain a purpose section, an update/maintenance note, and the requested project sections.
* `MEMORY.md` must preserve the provided project facts accurately.
* `MEMORY.md` must not introduce unsupported facts.

Tested capabilities: file creation, markdown formatting, information organization, instruction following.

## Grading Criteria

* [ ] File `MEMORY.md` exists
* [ ] `MEMORY.md` contains a purpose/explanation section for persistent memory
* [ ] `MEMORY.md` contains an update or maintenance note
* [ ] `MEMORY.md` contains project overview information (project name, language, framework, database, team lead, last major release)
* [ ] `MEMORY.md` contains all 3 key decisions
* [ ] `MEMORY.md` contains both ongoing tasks
* [ ] `MEMORY.md` contains both known issues
* [ ] `MEMORY.md` uses Markdown headers for at least 4 sections
* [ ] `MEMORY.md` does not introduce conflicting or clearly fabricated project facts

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    from pathlib import Path
    import re

    ws = Path(workspace_path)

    scores = {
        "file_exists": 0.0,
        "has_purpose_section": 0.0,
        "has_update_note": 0.0,
        "has_project_overview": 0.0,
        "has_key_decisions": 0.0,
        "has_ongoing_tasks": 0.0,
        "has_known_issues": 0.0,
        "uses_markdown_headers": 0.0,
        "no_fabrication": 0.0,
    }

    memory_file = ws / "MEMORY.md"
    if not memory_file.exists():
        return scores

    scores["file_exists"] = 1.0

    try:
        raw_content = memory_file.read_text(encoding="utf-8", errors="ignore")
    except Exception:
        raw_content = ""

    content = raw_content.lower()

    # Purpose section
    purpose_keywords = [
        "purpose", "memory", "context", "persist", "persistent",
        "across sessions", "workspace", "important"
    ]
    purpose_hits = sum(1 for kw in purpose_keywords if kw in content)
    if purpose_hits >= 3:
        scores["has_purpose_section"] = 1.0
    elif purpose_hits >= 2:
        scores["has_purpose_section"] = 0.5

    # Update / maintenance note
    update_keywords = [
        "update", "maintain", "maintenance", "keep this file current",
        "when changes happen", "revise", "edit this file", "refresh"
    ]
    update_hits = sum(1 for kw in update_keywords if kw in content)
    if update_hits >= 2:
        scores["has_update_note"] = 1.0
    elif update_hits == 1:
        scores["has_update_note"] = 0.5

    # Project overview
    overview_items = [
        "datapipeline",
        "python",
        "fastapi",
        "postgresql",
        "sarah chen",
        "v2.3.1",
    ]
    overview_found = sum(1 for item in overview_items if item in content)
    if overview_found >= 6:
        scores["has_project_overview"] = 1.0
    elif overview_found >= 4:
        scores["has_project_overview"] = 0.5

    # Key decisions
    decision_groups = [
        ["mysql", "postgresql", "2024-01-15"],
        ["async", "db operations"],
        ["pydantic", "v2", "validation"],
    ]
    decisions_found = 0
    for group in decision_groups:
        if sum(1 for term in group if term in content) >= max(1, len(group) - 1):
            decisions_found += 1

    if decisions_found == 3:
        scores["has_key_decisions"] = 1.0
    elif decisions_found == 2:
        scores["has_key_decisions"] = 0.67
    elif decisions_found == 1:
        scores["has_key_decisions"] = 0.33

    # Ongoing tasks
    task_groups = [
        ["legacy endpoints", "new schema"],
        ["rate limiting", "public api"],
    ]
    tasks_found = 0
    for group in task_groups:
        if all(term in content for term in group):
            tasks_found += 1

    if tasks_found == 2:
        scores["has_ongoing_tasks"] = 1.0
    elif tasks_found == 1:
        scores["has_ongoing_tasks"] = 0.5

    # Known issues
    issue_groups = [
        ["memory leak", "batch processor", "482"],
        ["slow query", "user_analytics"],
    ]
    issues_found = 0
    for group in issue_groups:
        if all(term in content for term in group):
            issues_found += 1

    if issues_found == 2:
        scores["has_known_issues"] = 1.0
    elif issues_found == 1:
        scores["has_known_issues"] = 0.5

    # Markdown headers
    header_lines = [line for line in raw_content.splitlines() if line.strip().startswith("#")]
    if len(header_lines) >= 4:
        scores["uses_markdown_headers"] = 1.0
    elif len(header_lines) == 3:
        scores["uses_markdown_headers"] = 0.5

    # No clear fabrication / contradiction
    conflicting_terms = [
        "django", "flask", "mongodb", "mysql as current database",
        "ruby", "java", "john smith", "aws lambda", "v3.0",
    ]
    conflict_hits = sum(1 for term in conflicting_terms if term in content)

    # also require that core facts are present to give full credit here
    core_fact_hits = sum(1 for item in ["datapipeline", "python", "fastapi", "postgresql"] if item in content)

    if conflict_hits == 0 and core_fact_hits >= 4:
        scores["no_fabrication"] = 1.0
    elif conflict_hits == 0 and core_fact_hits >= 2:
        scores["no_fabrication"] = 0.5
    else:
        scores["no_fabrication"] = 0.0

    return scores
```