| 序号 | 修改项 | 修改原因 |
|---|---|---|
| 1  | 保留 `difficulty: easy`           | 该题是典型的信息整理与 Markdown 文件创建任务，要求明确、结构固定，难度与 `easy` 匹配                      |
| 2  | 微调 Prompt 表述                    | 原 Prompt 已较清晰自然，仅补强“仅依据提供上下文，不要添加未提供事实”的约束，减少编造内容风险                      |
| 3  | 补充 Expected Behavior            | 原内容缺少 Ground Truth 和陷阱说明；补充“不得扩展未给出的项目背景”“需包含更新说明”“允许合理改写但不能丢失事实”等       |
| 4  | 重写 Grading Criteria             | 原标准基本可用，但“project overview”与“does not fabricate”覆盖边界略模糊；改成更独立、可单项判定的一组标准 |
| 5  | 优化 `grade()` 的 key 对齐           | 让评分 key 与 Grading Criteria 一一对应，避免语义不清或隐藏检查项                             |
| 6  | 提升 `grade()` 的格式容忍度             | 原评分大量依赖精确关键词，容易误伤合理改写；增加同义表达与部分得分逻辑                                      |
| 7  | 增强“空白零分”显式性                     | 原代码已有缺失文件直接返回 0，但未统一初始化全部 key；改为统一初始化，逻辑更清晰稳定                            |
| 8  | 修正 “no_fabrication” 逻辑过窄        | 原实现只排查少量特定词，不能很好约束编造；改为以“关键事实是否完整 + 明显冲突词排查”结合，仍保持自动评分可操作性               |
| 9  | 增加对“update instructions” 的单独检查  | Prompt 明确要求顶部说明文件用途和如何更新，原评分只检查用途，没单独覆盖“如何更新”                            |
| 10 | 保持 `grading_type: automated` 不变 | 本题无需 LLM Judge Rubric，automated-only 设定合理，因此不新增 rubric                   |
