---
id: task_568_competitor_website_change_analysis
name: Competitor Website Change Analysis
category: Data Analysis
subcategory: Business Scenario Analysis
difficulty: medium
external_dependency: none
verification_method: output-check
input_modality: text-only
grading_type: automated
grading_weights:
  automated: 1.0
  llm_judge: 0.0
timeout_seconds: 120
workspace_files: []
source_line_number: 6934
source_query: "Analyze the following competitor website change and return a valid JSON object with fields {\"summary\":\"1-2 sentence summary\",\"analysis\":\"competitive implications\",\"significance\":0.0-1.0,\"action_items\":[...],\"change_type\":\"content|price|layout|seo|new_page|removed\"}.  Target URL: https://siteimpact.com/ Change magnitude: 0.74% Section changed: \"speak with a marketing expert\"  Diff: --- previous +++ current @@ -238,7 +238,7 @@ ### speak with a marKETING EXPERT:  * [Phone: 954-..."
---

## Prompt

Hey, I'm tracking changes on competitor websites and need a quick analysis of this one.

Target URL: https://siteimpact.com/  
Change magnitude: 0.74%  
Section changed: "speak with a marketing expert"

Here's the diff:

```diff
--- previous
+++ current
@@ -238,7 +238,7 @@
 ### speak with a marKETING EXPERT:
 
 *   [Phone: 000-000-0000](tel:0000000000)
-*   [Email: info@example.com](https://siteimpact.com/cdn-cgi/l/email-protection#oldprotected)
+*   [Email: sales@example.com](https://siteimpact.com/cdn-cgi/l/email-protection#newprotected)
 *   [Do Not Sell My Personal Information](https://siteimpact.com/cali_compliance.php)
 
 [Contact Us](https://siteimpact.com/contact-us.php)
````

Please return a valid JSON object with these fields:

* `summary`: 1-2 sentence summary of the change
* `analysis`: competitive implications of the change
* `significance`: a float from 0.0 to 1.0
* `action_items`: a list of recommended actions
* `change_type`: one of `content`, `price`, `layout`, `seo`, `new_page`, `removed`

Save the result to `analysis.json`.

## Expected Behavior

The agent should create a valid JSON file named `analysis.json` in the workspace.

The output should satisfy all of the following:

1. The JSON contains exactly these top-level fields:

   * `summary`
   * `analysis`
   * `significance`
   * `action_items`
   * `change_type`

2. The agent should correctly interpret the diff as a small content-level update to contact information in an existing section, specifically an email/contact change.

3. The appropriate `change_type` is:

   * `content`

4. The `significance` score should be low because the observed change is minor and administrative rather than a major product, pricing, positioning, SEO, or site-structure change.

   * A reasonable score is at or below `0.5`

5. The `summary` should mention that the change is an email/contact update or equivalent wording.

6. The `analysis` should describe proportionate competitive implications, such as possible routing of inbound leads or contact handling changes, without inventing unsupported major strategic conclusions.

7. `action_items` should be a JSON array of practical, proportionate follow-up actions grounded in the observed change.

8. The agent should not fabricate unsupported claims such as major strategic repositioning, pricing changes, new product launches, or large website overhauls.

Ground-truth interpretation:

* The changed line is an email field in a contact section.
* The meaning of the change is an update from one contact email address to another.
* This is not a layout, pricing, SEO, new-page, or removed-page event.

Tested capabilities:

* parsing a small textual diff
* identifying the nature of a website content update
* proportional business interpretation
* producing structured JSON output without fabrication

## Grading Criteria

* [ ] File `analysis.json` exists
* [ ] Output is valid JSON
* [ ] All required top-level fields are present
* [ ] Output contains no unsupported extra top-level fields
* [ ] `significance` is a numeric value between 0.0 and 1.0
* [ ] `action_items` is a non-empty list
* [ ] `change_type` is one of the allowed values
* [ ] `change_type` is correctly classified as `content`
* [ ] `summary` mentions an email/contact change
* [ ] `significance` is appropriately low for this minor change
* [ ] `analysis` does not fabricate major strategic implications

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    from pathlib import Path
    import json

    scores = {
        "file_exists": 0.0,
        "valid_json": 0.0,
        "has_all_fields": 0.0,
        "no_extra_fields": 0.0,
        "significance_valid": 0.0,
        "action_items_valid": 0.0,
        "change_type_valid": 0.0,
        "change_type_correct": 0.0,
        "summary_mentions_email_change": 0.0,
        "significance_appropriate": 0.0,
        "analysis_non_fabricated": 0.0,
    }

    ws = Path(workspace_path)
    analysis_file = ws / "analysis.json"

    if not analysis_file.exists():
        return scores

    scores["file_exists"] = 1.0

    try:
        data = json.loads(analysis_file.read_text(encoding="utf-8"))
        scores["valid_json"] = 1.0
    except Exception:
        return scores

    if not isinstance(data, dict):
        return scores

    required_fields = ["summary", "analysis", "significance", "action_items", "change_type"]
    allowed_fields = set(required_fields)
    actual_fields = set(data.keys())

    present_count = sum(1 for f in required_fields if f in data)
    scores["has_all_fields"] = present_count / len(required_fields)

    extra_fields = actual_fields - allowed_fields
    if len(extra_fields) == 0:
        scores["no_extra_fields"] = 1.0
    elif len(extra_fields) == 1:
        scores["no_extra_fields"] = 0.5

    sig = data.get("significance")
    if isinstance(sig, (int, float)) and not isinstance(sig, bool) and 0.0 <= float(sig) <= 1.0:
        scores["significance_valid"] = 1.0

    action_items = data.get("action_items")
    if isinstance(action_items, list):
        non_empty_items = [
            x for x in action_items
            if isinstance(x, str) and x.strip()
        ]
        if len(non_empty_items) >= 1:
            scores["action_items_valid"] = 1.0
        elif len(action_items) >= 1:
            scores["action_items_valid"] = 0.5

    valid_types = {"content", "price", "layout", "seo", "new_page", "removed"}
    change_type = str(data.get("change_type", "")).strip().lower()
    if change_type in valid_types:
        scores["change_type_valid"] = 1.0
    if change_type == "content":
        scores["change_type_correct"] = 1.0

    summary = str(data.get("summary", "")).strip().lower()
    email_keywords = ["email", "contact", "address", "inbox", "sales@", "info@"]
    change_keywords = ["change", "changed", "update", "updated", "switch", "switched", "replace", "replaced"]
    has_email_signal = any(kw in summary for kw in email_keywords)
    has_change_signal = any(kw in summary for kw in change_keywords)

    if has_email_signal and has_change_signal:
        scores["summary_mentions_email_change"] = 1.0
    elif has_email_signal:
        scores["summary_mentions_email_change"] = 0.5

    if isinstance(sig, (int, float)) and not isinstance(sig, bool):
        sig_value = float(sig)
        if 0.0 <= sig_value <= 0.5:
            scores["significance_appropriate"] = 1.0
        elif 0.5 < sig_value <= 0.65:
            scores["significance_appropriate"] = 0.5

    analysis_text = str(data.get("analysis", "")).lower()
    fabrication_terms = [
        "major strategic",
        "significant pivot",
        "dramatic shift",
        "complete overhaul",
        "revolutionary",
        "pricing overhaul",
        "new product launch",
        "major repositioning"
    ]
    has_fabrication = any(term in analysis_text for term in fabrication_terms)
    scores["analysis_non_fabricated"] = 0.0 if has_fabrication else 1.0

    return scores
```

## LLM Judge Rubric

Use this rubric only if manual or model-based review is needed as a fallback.

### Dimension 1: Change Interpretation Accuracy (Weight: 40%)

* **1.0**: Correctly identifies the observed change as a minor contact/email content update in an existing section and classifies it appropriately.
* **0.75**: Mostly correct interpretation, with only slight imprecision in describing the change.
* **0.5**: Partially correct, but mixes the email/contact change with other unsupported interpretations.
* **0.25**: Misinterprets the change in a substantial way.
* **0.0**: Fails to recognize the basic nature of the diff.

### Dimension 2: Proportional Competitive Analysis (Weight: 35%)

* **1.0**: Provides realistic and proportionate business implications without overstating the importance of the change.
* **0.75**: Mostly proportionate, with only minor overreach or generic phrasing.
* **0.5**: Some relevant analysis, but contains noticeable speculation or weak grounding.
* **0.25**: Analysis is largely exaggerated, generic, or weakly supported.
* **0.0**: Analysis is misleading, highly speculative, or clearly fabricated.

### Dimension 3: Output Format and Actionability (Weight: 25%)

* **1.0**: Output follows the required JSON structure exactly, and action items are practical and relevant.
* **0.75**: Minor formatting or actionability issues, but still mostly usable.
* **0.5**: Partially usable output with noticeable formatting or recommendation problems.
* **0.25**: Poorly structured or weakly actionable output.
* **0.0**: Output is missing, malformed, or unusable.

Total rubric weight: 100%

```