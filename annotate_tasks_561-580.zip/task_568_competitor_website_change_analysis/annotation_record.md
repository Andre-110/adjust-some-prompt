| 序号 | 修改项 | 修改原因 |
|---|---|---|
| 1 | 在 Prompt 中将真实电话和邮箱替换为虚构信息 | 题目中含有真实隐私/联系方式信息，按规范应替换为虚构数据，邮箱使用 `@example.com` |
| 2 | 在 frontmatter 中新增 `grading_weights` | 原文件缺少该字段；按规范需保证 `automated + llm_judge = 1.0` |
| 3 | 保持 `grading_type: automated`，并设置 `automated: 1.0 / llm_judge: 0.0` | 该题本质是 automated 评分任务，权重应与任务类型一致 |
| 4 | 轻度改写 Prompt，减少答案泄露 | 原 Prompt 虽未完全直说答案，但 Expected Behavior 明确给出“minor contact information change”与“email address update”，需要把标准答案更多放到 Expected Behavior，而不是让 Prompt 预设结论 |
| 5 | 重写 Expected Behavior，补充结构化 Ground Truth | 原版本有方向但不够标准化，修正后明确 change_type、significance 范围、禁止编造的边界 |
| 6 | 明确这是现有页面中的联系邮箱变更 | 这是本题核心 Ground Truth，应在 Expected Behavior 中写清楚 |
| 7 | 明确 `change_type` 应为 `content` | 原文虽提到，但需要更明确地作为 Ground Truth 固定下来 |
| 8 | 细化 Grading Criteria，增加“无额外字段”和“change_type 正确性” | 原标准只检查 change_type 是否属于允许集合，没有单独检查是否正确分类为 `content` |
| 9 | 重写 `grade()` 的初始化逻辑 | 统一所有 score key 先置 0.0，满足主文件不存在时全 0 的要求 |
| 10 | 将 `has_all_fields` 改为支持部分得分 | 原实现是纯 0/1，不符合“支持部分得分”的要求 |
| 11 | 新增 `no_extra_fields` 检查 | 原版本未检查是否添加了 schema 外字段，无法保证输出严格可评分 |
| 12 | 将 `significance_is_float` 改为 `significance_valid` | 更准确表达要求：既要是数值，也要在 0.0-1.0 范围内 |
| 13 | 改进 `action_items` 检查逻辑 | 原实现只检查是否为 list，不检查是否为空、元素是否为有效字符串 |
| 14 | 拆分 `change_type_valid` 与 `change_type_correct` | 原版只检查 change_type 是否在允许集合内，但没有检查是否正确识别为 `content` |
| 15 | 改进 `summary_mentions_email` 为 `summary_mentions_email_change` | 原实现只要提到 email/contact 就满分，无法体现“这是一次变更”这一核心语义 |
| 16 | 将 `significance_appropriate` 改为支持部分得分 | 原实现只有 ≤0.5 才满分，略高一些但仍较低的值应有部分得分 |
| 17 | 将 `no_fabrication` 改为 `analysis_non_fabricated` | 命名更清晰，并聚焦在分析文本是否夸大或编造重大含义 |
| 18 | 新增完整 LLM Judge Rubric | 原文件缺失 LLM Judge Rubric，而你的规范要求任务文件包含该部分 |
| 19 | 为 LLM Judge Rubric 设置 3 个维度且总权重为 100% | 满足“至少 3 个评分维度”“权重和为 100%”的要求 |
| 20 | 为 LLM Judge Rubric 补齐五档描述 | 满足每个等级（1.0 / 0.75 / 0.5 / 0.25 / 0.0）有明确判定描述的要求 |