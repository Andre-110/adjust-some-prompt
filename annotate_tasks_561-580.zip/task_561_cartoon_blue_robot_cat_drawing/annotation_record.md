| 序号 | 修改项                      | 修改原因                                                                                                                           |
| -- | ------------------------ | ------------------------------------------------------------------------------------------------------------------------------ |
| 1  | 调整 `difficulty` 为 `easy` | 该题本质是基础 Python 绘图 + README 说明，要求虽多但大多是显式视觉元素检查，整体复杂度更接近 `easy` 而非 `medium`                                                     |
| 2  | 改写 Prompt                | 原 Prompt 较自然，但带有较强的具体形象暗示，且“like those classic round-faced robot cats from anime” 容易引向具体 IP；改为描述目标外观特征，保留用户自然表达，同时避免过度依赖特定角色名称 |
| 3  | 补充 Expected Behavior     | 原内容缺少 Ground Truth 和陷阱说明；补充“允许 turtle 或 matplotlib 任一种”“不要求必须实现 bell/collar”“README 需说明保存方式”等关键约束                              |
| 4  | 重写 Grading Criteria      | 原标准存在重复：第一条已含“valid Python”，第十一条又再次检查语法；同时条目之间部分耦合较强，现改为更独立、可单独判定的一组标准                                                         |
| 5  | 修正 `grade()` 的 key 对齐问题  | 原评分 key 与标准不完全一一对应，且存在 `readme_exists`、`no_fabricated_imports` 等未在标准中清晰体现的问题；现统一对齐                                             |
| 6  | 修正 `grade()` 的部分得分能力不足   | 原自动评分几乎全是 0/1，不满足“支持 0.0-1.0 之间部分得分”；对视觉元素覆盖和 README 说明增加部分得分逻辑                                                                |
| 7  | 提升 `grade()` 的格式容忍度      | 原始代码检查区分大小写不统一、`read_text()` 无容错，且对 matplotlib 判定过宽；现在统一采用 `lower()`、编码容错与更稳健匹配                                                |
| 8  | 放宽并纠正“图形库”判断             | 原来 `"plt" in code` 容易误判；改为识别更可靠的 `matplotlib` / `pyplot` 导入痕迹                                                                  |
| 9  | 调整“导出图片”评分逻辑             | 题目要求 README 解释如何保存/导出为图片，但不要求脚本本身必须直接保存；评分中明确以 README 为主，避免过严                                                                  |
| 10 | 重写 LLM Judge Rubric      | 原 rubric 只有权重，没有 1.0 / 0.75 / 0.5 / 0.25 / 0.0 五档描述，不满足要求                                                                      |
| 11 | 校验 `grading_weights`     | `automated: 0.4` 与 `llm_judge: 0.6` 之和为 1.0，保持不变                                                                               |

---