---
id: task_561_cartoon_blue_robot_cat_drawing
name: Cartoon Blue Robot Cat Drawing
category: Automation
subcategory: Script and Terminal Automation
difficulty: easy
external_dependency: none
verification_method: unit-test
input_modality: text-only
grading_type: hybrid
grading_weights:
  automated: 0.4
  llm_judge: 0.6
timeout_seconds: 180
workspace_files: []
source_line_number: 5000
source_query: "采用“方案二：本地代码绘图”的方式，提供一份可运行的 Python 示例（如 turtle/matplotlib），绘制一个哆啦A梦风格的卡通蓝色机器猫形象，并说明运行步骤与如何导出/保存成图片。"
---

## Prompt

Please create a Python drawing script for a cute cartoon blue robot cat and save it as `robot_cat.py`.

The drawing should be made with either `turtle` or `matplotlib`, and it should depict a simple cartoon robot cat character with these features:
- a blue head and/or body
- a white face area
- a red round nose
- eyes with pupils
- whiskers (at least 3 on each side)

Optional extra detail: a collar and bell.

Also create a `README.md` that explains:
- how to run the script
- what library or libraries are needed
- how to save or export the drawing as an image file such as PNG

Keep it self-contained and runnable with normal Python tools. Do not include extra explanation outside the requested files.

## Expected Behavior

The agent should:

1. Create `robot_cat.py` containing runnable Python code that draws a cartoon blue robot cat.
2. Use either the `turtle` module or `matplotlib` for the drawing implementation.
3. Include the key requested visual elements in code: blue head/body, white face area, red nose, eyes with pupils, and whiskers.
4. Create `README.md` with clear instructions for running the script.
5. In `README.md`, state what library or libraries are required.
6. In `README.md`, explain a reasonable way to save or export the drawing to an image file such as PNG.
7. Ensure the Python code is syntactically valid.

Traps / special handling:
- The task does **not** require a specific named copyrighted character; it requires a cartoon blue robot cat with the listed features.
- The task allows either `turtle` or `matplotlib`; either is acceptable.
- The collar and bell are optional and should not be treated as mandatory for correctness.
- The task primarily requires code and documentation; it does not require pre-generated image files in the workspace.

Ground truth:
- Correct output must include both `robot_cat.py` and `README.md`.
- `robot_cat.py` must contain valid Python drawing code using `turtle` or `matplotlib`.
- The code must include the main requested robot-cat visual elements.
- `README.md` must explain running the script and how to save/export the drawing.

Tested capabilities: Python graphics programming, code generation, documentation writing, instruction following.

## Grading Criteria

- [ ] `robot_cat.py` exists
- [ ] `README.md` exists
- [ ] `robot_cat.py` has valid Python syntax
- [ ] `robot_cat.py` uses either `turtle` or `matplotlib`
- [ ] `robot_cat.py` includes code for the required color elements (blue, white, red)
- [ ] `robot_cat.py` includes code for whiskers
- [ ] `robot_cat.py` includes code for eyes or pupils
- [ ] `README.md` explains how to run the script
- [ ] `README.md` states the required library or libraries
- [ ] `README.md` explains how to save or export the drawing as an image

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    from pathlib import Path
    import ast

    ws = Path(workspace_path)

    scores = {
        "script_exists": 0.0,
        "readme_exists": 0.0,
        "valid_python_syntax": 0.0,
        "uses_graphics_lib": 0.0,
        "has_required_colors": 0.0,
        "has_whisker_code": 0.0,
        "has_eye_code": 0.0,
        "readme_has_run_instructions": 0.0,
        "readme_has_library_instructions": 0.0,
        "readme_has_save_instructions": 0.0,
    }

    script_file = ws / "robot_cat.py"
    readme_file = ws / "README.md"

    if script_file.exists():
        scores["script_exists"] = 1.0
    if readme_file.exists():
        scores["readme_exists"] = 1.0

    if script_file.exists():
        try:
            code = script_file.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            code = ""

        code_lower = code.lower()

        try:
            ast.parse(code)
            scores["valid_python_syntax"] = 1.0
        except SyntaxError:
            scores["valid_python_syntax"] = 0.0

        # graphics library check
        uses_turtle = ("import turtle" in code_lower) or ("from turtle import" in code_lower)
        uses_matplotlib = (
            "import matplotlib" in code_lower
            or "from matplotlib import" in code_lower
            or "import matplotlib.pyplot" in code_lower
            or "from matplotlib.pyplot import" in code_lower
        )
        scores["uses_graphics_lib"] = 1.0 if (uses_turtle or uses_matplotlib) else 0.0

        # required colors: allow partial credit
        blue_indicators = [
            "blue", "#0000ff", "#00bfff", "#1e90ff", "dodgerblue",
            "deepskyblue", "cornflowerblue", "(0, 0, 255)", "(0,0,255)"
        ]
        white_indicators = [
            "white", "#ffffff", "#fff", "(255, 255, 255)", "(255,255,255)",
            "(1, 1, 1)", "(1,1,1)", "(1.0, 1.0, 1.0)"
        ]
        red_indicators = [
            "red", "#ff0000", "(255, 0, 0)", "(255,0,0)", "(1, 0, 0)", "(1,0,0)"
        ]

        color_hits = 0
        if any(ind in code_lower for ind in blue_indicators):
            color_hits += 1
        if any(ind in code_lower for ind in white_indicators):
            color_hits += 1
        if any(ind in code_lower for ind in red_indicators):
            color_hits += 1

        if color_hits == 3:
            scores["has_required_colors"] = 1.0
        elif color_hits == 2:
            scores["has_required_colors"] = 0.67
        elif color_hits == 1:
            scores["has_required_colors"] = 0.33

        # whisker detection
        whisker_keywords = ["whisker", "whiskers"]
        line_drawing_keywords = [
            "line", "goto", "pendown", "forward", "setheading",
            "plot(", "ax.plot", "lineto"
        ]
        has_whisker_label = any(k in code_lower for k in whisker_keywords)
        line_signal_count = sum(1 for k in line_drawing_keywords if k in code_lower)

        if has_whisker_label and line_signal_count >= 1:
            scores["has_whisker_code"] = 1.0
        elif line_signal_count >= 2:
            scores["has_whisker_code"] = 0.5

        # eye / pupil detection
        eye_keywords = ["eye", "eyes", "pupil", "pupils"]
        shape_keywords = ["circle", "dot", "ellipse", "oval", "arc", "patches.circle", "patches.ellipse"]
        eye_hits = 0
        if any(k in code_lower for k in eye_keywords):
            eye_hits += 1
        if any(k in code_lower for k in shape_keywords):
            eye_hits += 1

        if eye_hits == 2:
            scores["has_eye_code"] = 1.0
        elif eye_hits == 1:
            scores["has_eye_code"] = 0.5

    if readme_file.exists():
        try:
            readme = readme_file.read_text(encoding="utf-8", errors="ignore").lower()
        except Exception:
            readme = ""

        run_indicators = ["python", "python3", "run", "execute", ".py", "terminal", "command line"]
        if any(ind in readme for ind in run_indicators):
            scores["readme_has_run_instructions"] = 1.0

        library_indicators = ["turtle", "matplotlib", "standard library", "pip install", "python comes with"]
        library_hits = sum(1 for ind in library_indicators if ind in readme)
        if library_hits >= 2:
            scores["readme_has_library_instructions"] = 1.0
        elif library_hits == 1:
            scores["readme_has_library_instructions"] = 0.5

        save_indicators = ["save", "export", "png", "image", "postscript", "savefig", "getcanvas", "screenshot"]
        save_hits = sum(1 for ind in save_indicators if ind in readme)
        if save_hits >= 2:
            scores["readme_has_save_instructions"] = 1.0
        elif save_hits == 1:
            scores["readme_has_save_instructions"] = 0.5

    return scores
````

## LLM Judge Rubric

### 1. Visual Completeness (40%)

**1.0** - The code clearly aims to draw a recognizable cartoon blue robot cat and includes all required visual elements: blue head/body, white face area, red nose, eyes with pupils, and whiskers.
**0.75** - The drawing includes most required elements and would likely appear as a robot-cat-like cartoon, with only minor omissions or roughness.
**0.5** - The code includes some required features, but the drawing is incomplete, ambiguous, or only partially matches the requested robot cat.
**0.25** - The code has minimal visual correspondence to the requested drawing and omits several core features.
**0.0** - The submission does not meaningfully implement the requested robot cat drawing.

### 2. Code Quality and Runnability (25%)

**1.0** - Code is valid, organized, readable, and plausibly runnable as a standalone drawing script.
**0.75** - Code is mostly sound and runnable, with minor readability or structure issues.
**0.5** - Code is partially workable but has notable structure, clarity, or reliability issues.
**0.25** - Code is hard to follow, fragile, or likely to fail without significant fixes.
**0.0** - Code is missing, non-runnable, or fundamentally broken.

### 3. Documentation Quality (20%)

**1.0** - README clearly explains how to run the script, what libraries are needed, and how to save/export the drawing.
**0.75** - README covers most required instructions with only small omissions.
**0.5** - README exists but is incomplete or only somewhat helpful.
**0.25** - README provides very limited guidance.
**0.0** - README is missing or not useful.

### 4. Instruction Following (15%)

**1.0** - The response follows all core task constraints, including correct filenames and use of `turtle` or `matplotlib`, without adding irrelevant output requirements.
**0.75** - The response follows the main requirements with only minor deviations.
**0.5** - The response satisfies some requirements but misses others.
**0.25** - The response only weakly follows the task instructions.
**0.0** - The response does not follow the task in a meaningful way.

```
