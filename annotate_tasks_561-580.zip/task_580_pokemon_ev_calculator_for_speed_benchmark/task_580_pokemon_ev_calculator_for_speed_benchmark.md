---
id: task_580_pokemon_ev_calculator_for_speed_benchmark
name: Pokemon EV Calculator for Speed Benchmark
category: Data Analysis
subcategory: Statistical Analysis and Modeling
difficulty: medium
external_dependency: none
verification_method: unit-test
input_modality: text-only
grading_type: automated
timeout_seconds: 120
workspace_files: []
source_line_number: 4102
source_query: "In Pokemon battle EV planning, calculate whether Ting-Lu can outspeed a max-Speed positive-nature Hippowdon at level 50 under the stated assumptions. If the benchmark is unreachable, explicitly report that it is impossible rather than fabricating an EV value."
---

## Prompt

I need help with a competitive Pokémon Speed benchmark.

I want to know whether my Ting-Lu can outspeed a max-Speed Hippowdon with a Speed-boosting nature and 252 Speed EVs. Assume level 50, 31 IVs for both Pokémon, and Ting-Lu has a **neutral Speed nature**.

Use this stat formula at level 50:

`floor((floor((2 * base + IV + floor(EV/4)) * level / 100) + 5) * nature)`

Stat data:
```yaml
pokemon:
  ting_lu:
    base_speed: 45
  hippowdon:
    base_speed: 47

level: 50

nature_multipliers:
  positive: 1.1
  neutral: 1.0

assumptions:
  ivs: 31
  hippowdon_speed_evs: 252
  ting_lu_speed_nature: neutral
````

Please save the answer to `speed_calc.json` with these fields:

* `hippowdon_speed`: final Speed stat of the Hippowdon benchmark
* `ting_lu_min_evs`: minimum EVs Ting-Lu needs under the stated assumptions, or `null` if impossible
* `ting_lu_speed`: Ting-Lu’s resulting Speed at that EV value, or Ting-Lu’s maximum achievable Speed under the stated assumptions if impossible
* `calculation_notes`: brief explanation

Important:

* Do not assume a positive Speed nature for Ting-Lu
* If the benchmark is impossible under the stated assumptions, say so clearly instead of inventing a working EV value

## Expected Behavior

The agent should:

1. Correctly compute the benchmark Speed for Hippowdon at level 50 with:

   * base Speed 47
   * 31 IV
   * 252 Speed EVs
   * positive Speed nature
2. Correctly compute Ting-Lu’s Speed using:

   * base Speed 45
   * 31 IV
   * variable EVs
   * neutral Speed nature
3. Compare Ting-Lu’s maximum achievable neutral-nature Speed against the required target.
4. Recognize the key trap: under the stated assumptions, Ting-Lu cannot outspeed this Hippowdon benchmark at level 50.
5. Write `speed_calc.json` in a structured way without fabricating a successful EV solution.

Ground truth:

* Hippowdon benchmark Speed = `108`
* Ting-Lu needs at least `109` Speed to outspeed by 1 point
* Ting-Lu’s maximum achievable Speed with neutral nature and 252 EVs at level 50 is `97`
* Therefore the benchmark is impossible under the stated assumptions

Required handling for the impossible case:

* `hippowdon_speed` should be `108`
* `ting_lu_min_evs` should be `null`
* `ting_lu_speed` should be `97`
* `calculation_notes` should clearly state that the benchmark is impossible with neutral-nature Ting-Lu

Key trap:

* A model may incorrectly back-solve for an EV value and claim Ting-Lu can reach the target. That is wrong and should not receive full credit.

Tested capabilities:

* formula-based stat calculation
* careful handling of floor operations
* recognizing infeasible optimization targets
* structured JSON output

## Grading Criteria

* [ ] File `speed_calc.json` exists
* [ ] File is valid JSON and contains all required fields
* [ ] `hippowdon_speed` is correctly computed as `108`
* [ ] Response correctly identifies that the benchmark is impossible under the stated assumptions
* [ ] Output does not fabricate a working EV value for Ting-Lu
* [ ] `calculation_notes` briefly explains the impossibility

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    from pathlib import Path
    import json

    SCORE_KEYS = [
        "file_exists",
        "valid_json_with_required_fields",
        "hippowdon_speed_correct",
        "identifies_impossibility",
        "no_fabricated_solution",
        "notes_explain_impossibility",
    ]

    def zero_scores():
        return {k: 0.0 for k in SCORE_KEYS}

    def calc_speed(base, iv, ev, level, nature_mult):
        inner = (2 * base + iv + (ev // 4)) * level // 100
        return int((inner + 5) * nature_mult)

    ws = Path(workspace_path)
    calc_file = ws / "speed_calc.json"

    if not calc_file.exists():
        return zero_scores()

    scores = zero_scores()
    scores["file_exists"] = 1.0

    try:
        data = json.loads(calc_file.read_text(encoding="utf-8"))
    except Exception:
        return scores

    required_fields = {
        "hippowdon_speed",
        "ting_lu_min_evs",
        "ting_lu_speed",
        "calculation_notes",
    }
    scores["valid_json_with_required_fields"] = 1.0 if required_fields.issubset(set(data.keys())) else 0.0

    hippo_speed = data.get("hippowdon_speed")
    scores["hippowdon_speed_correct"] = 1.0 if hippo_speed == 108 else 0.0

    ting_lu_evs = data.get("ting_lu_min_evs")
    ting_lu_speed = data.get("ting_lu_speed")
    notes = str(data.get("calculation_notes", "")).lower()

    impossible_keywords = [
        "impossible", "cannot", "can't", "unable",
        "not possible", "does not reach", "cannot outspeed",
        "too slow", "benchmark is unreachable", "unreachable",
    ]
    recognized_impossible = any(kw in notes for kw in impossible_keywords)

    # impossible identification
    if ting_lu_evs is None and ting_lu_speed == 97:
        scores["identifies_impossibility"] = 1.0
    elif recognized_impossible:
        scores["identifies_impossibility"] = 1.0
    else:
        scores["identifies_impossibility"] = 0.0

    # no fabricated working solution
    fabricated = False
    if isinstance(ting_lu_evs, (int, float)):
        if ting_lu_evs < 0 or ting_lu_evs > 252:
            fabricated = True
        else:
            actual_speed = calc_speed(45, 31, int(ting_lu_evs), 50, 1.0)
            if actual_speed >= 109:
                fabricated = True
    elif ting_lu_evs is None:
        fabricated = False
    else:
        fabricated = True

    if isinstance(ting_lu_speed, (int, float)):
        if ting_lu_speed >= 109:
            fabricated = True

    scores["no_fabricated_solution"] = 0.0 if fabricated else 1.0

    # notes quality
    enough_explanation = (
        recognized_impossible and
        ("neutral" in notes or "nature" in notes or "97" in notes or "108" in notes)
    )
    scores["notes_explain_impossibility"] = 1.0 if enough_explanation else 0.0

    return scores
```