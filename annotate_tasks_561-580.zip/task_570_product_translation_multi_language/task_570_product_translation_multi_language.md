---
id: task_570_product_translation_multi_language
name: Product Translation Multi-Language
category: Data Analysis
subcategory: Data Processing and Management
difficulty: medium
external_dependency: none
verification_method: unit-test
input_modality: text-only
grading_type: hybrid
grading_weights:
  automated: 0.4
  llm_judge: 0.6
timeout_seconds: 180
workspace_files: []
source_line_number: 1042
source_query: "Translate the provided product JSON fields from German into all languages listed in target_languages. Translate each non-empty field in names, allergens, and ingredients into every target language, output only the target-language translations, preserve literal codes such as (CH), and do not retain the source-language key."
---

## Prompt

I need to localize some product information from German into multiple languages for an international store.

Source data:
```json
{
  "names": {
    "de": "Tempeh Bagus Soja Tempeh Indian Masala 200g"
  },
  "allergens": {
    "de": "Enthält Soja"
  },
  "ingredients": {
    "de": "Bio SOJA (CH)"
  }
}
````

Target languages:
`bg, cs, da, el, en, es, fi, fr, hu, it, ja, ko, nb, nl, pl, pt, ro, ru, sv, tr, zh-cn, zh-tw`

Please create a file named `translations.json` with the translated output.

Requirements:

* Translate all three non-empty fields: `names`, `allergens`, and `ingredients`
* For each of those fields, include all listed target languages as keys
* Do not keep the original `de` key in the output
* Preserve literal codes such as `(CH)` exactly
* Return only the translated target-language content in JSON form
* Do not add extra commentary, metadata, or extra top-level fields

Expected output structure:

```json
{
  "names": {
    "bg": "...",
    "cs": "...",
    "...": "..."
  },
  "allergens": {
    "bg": "...",
    "cs": "...",
    "...": "..."
  },
  "ingredients": {
    "bg": "...",
    "cs": "...",
    "...": "..."
  }
}
```

## Expected Behavior

The agent should:

1. Parse the German source JSON correctly.
2. Translate all three populated fields (`names`, `allergens`, `ingredients`) into all 22 target languages.
3. Produce `translations.json` with exactly three top-level objects: `names`, `allergens`, and `ingredients`.
4. Ensure each of those objects contains all 22 required target-language keys.
5. Remove the source-language key `de` from the output.
6. Preserve the literal code `(CH)` unchanged in ingredient translations.
7. Keep allergen translations semantically clear as an allergen warning about soy.
8. Avoid adding unrelated fields, placeholder values, or untranslated German source entries.

Ground truth and constraints:

* Number of required target languages per field: 22
* Required top-level keys: `names`, `allergens`, `ingredients`
* Forbidden key in output: `de`
* `(CH)` must remain unchanged
* Output must be valid JSON
* All target-language values should be non-empty strings

Key traps:

* The model may incorrectly retain the `de` key.
* The model may omit some target languages in one or more fields.
* The model may alter or drop `(CH)`.
* The model may add extra top-level metadata or leave some values untranslated/empty.

Tested capabilities:

* multilingual translation
* structured JSON transformation
* preservation of literal codes
* consistent field coverage across languages
* instruction-following under format constraints

## Grading Criteria

* [ ] File `translations.json` exists
* [ ] `translations.json` is valid JSON
* [ ] `names`, `allergens`, and `ingredients` each contain all 22 target languages with non-empty string values
* [ ] Output does not contain the source-language key `de`
* [ ] Ingredient translations preserve `(CH)`
* [ ] English allergen translation clearly refers to soy/soya
* [ ] Japanese output is present and uses non-Latin characters
* [ ] Output contains no extra top-level fields or fabricated structural content

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    from pathlib import Path
    import json

    SCORE_KEYS = [
        "file_exists",
        "valid_json",
        "all_fields_complete",
        "no_german_key",
        "ch_preserved",
        "en_allergen_clear",
        "ja_present",
        "no_extra_structure",
    ]

    TARGET_LANGS = [
        "bg", "cs", "da", "el", "en", "es", "fi", "fr", "hu", "it",
        "ja", "ko", "nb", "nl", "pl", "pt", "ro", "ru", "sv", "tr", "zh-cn", "zh-tw"
    ]
    REQUIRED_TOP_KEYS = {"names", "allergens", "ingredients"}

    def zero_scores():
        return {k: 0.0 for k in SCORE_KEYS}

    ws = Path(workspace_path)
    trans_file = ws / "translations.json"
    if not trans_file.exists():
        return zero_scores()

    scores = zero_scores()
    scores["file_exists"] = 1.0

    try:
        data = json.loads(trans_file.read_text(encoding="utf-8"))
    except Exception:
        return scores

    scores["valid_json"] = 1.0

    top_keys = set(data.keys())
    scores["no_extra_structure"] = 1.0 if top_keys == REQUIRED_TOP_KEYS else 0.0

    names = data.get("names", {})
    allergens = data.get("allergens", {})
    ingredients = data.get("ingredients", {})

    def field_completion(obj):
        if not isinstance(obj, dict):
            return 0.0
        count = 0
        for lang in TARGET_LANGS:
            value = obj.get(lang)
            if isinstance(value, str) and value.strip():
                count += 1
        return count / float(len(TARGET_LANGS))

    names_score = field_completion(names)
    allergens_score = field_completion(allergens)
    ingredients_score = field_completion(ingredients)
    scores["all_fields_complete"] = (names_score + allergens_score + ingredients_score) / 3.0

    def has_de_key(obj):
        return isinstance(obj, dict) and "de" in obj

    has_german = has_de_key(names) or has_de_key(allergens) or has_de_key(ingredients)
    scores["no_german_key"] = 0.0 if has_german else 1.0

    ch_count = 0
    if isinstance(ingredients, dict):
        for lang in TARGET_LANGS:
            value = ingredients.get(lang, "")
            if isinstance(value, str) and "(ch)" in value.lower():
                ch_count += 1
    scores["ch_preserved"] = ch_count / float(len(TARGET_LANGS))

    en_allergen = allergens.get("en", "")
    if isinstance(en_allergen, str):
        en_allergen_lower = en_allergen.lower()
        scores["en_allergen_clear"] = 1.0 if ("soy" in en_allergen_lower or "soya" in en_allergen_lower or "soja" in en_allergen_lower) else 0.0
    else:
        scores["en_allergen_clear"] = 0.0

    ja_name = names.get("ja", "") if isinstance(names, dict) else ""
    ja_allergen = allergens.get("ja", "") if isinstance(allergens, dict) else ""
    ja_ingredients = ingredients.get("ja", "") if isinstance(ingredients, dict) else ""
    ja_text = "".join(x for x in [ja_name, ja_allergen, ja_ingredients] if isinstance(x, str))
    has_non_latin = any(ord(c) > 127 for c in ja_text)
    scores["ja_present"] = 1.0 if (ja_name.strip() and ja_allergen.strip() and ja_ingredients.strip() and has_non_latin) else 0.0

    return scores
```

## LLM Judge Rubric

### Criterion 1: Translation Accuracy and Naturalness (Weight: 35%)

**Score 1.0**: Translations are accurate, natural, and semantically appropriate across languages, with the product name, allergen, and ingredient information clearly conveyed.
**Score 0.75**: Most translations are correct and understandable, with only minor awkwardness or wording issues.
**Score 0.5**: Translations are mixed in quality; some are understandable, but several are literal, awkward, or partially inaccurate.
**Score 0.25**: Many translations are weak, unclear, or partially untranslated.
**Score 0.0**: Translations are largely unusable or incorrect.

### Criterion 2: Safety-Critical Allergen Clarity (Weight: 25%)

**Score 1.0**: Allergen translations clearly communicate the presence of soy/soya in a way that would be understandable to users.
**Score 0.75**: Most allergen translations are clear, with only minor ambiguity in a small number of languages.
**Score 0.5**: Some allergen translations are understandable, but others are ambiguous or weak.
**Score 0.25**: Allergen wording is unclear across multiple languages.
**Score 0.0**: Allergen information is mistranslated, omitted, or unsafe.

### Criterion 3: Structural Completeness and Consistency (Weight: 25%)

**Score 1.0**: All 22 target languages are present for all three fields, `de` is absent, `(CH)` is preserved, and the JSON structure is fully compliant.
**Score 0.75**: Nearly complete, with only minor omissions or small structural inconsistencies.
**Score 0.5**: Several omissions or inconsistencies are present, but much of the structure is still usable.
**Score 0.25**: Major incompleteness or repeated structural mistakes reduce reliability.
**Score 0.0**: Output structure is substantially incorrect or incomplete.

### Criterion 4: Constraint Compliance (Weight: 15%)

**Score 1.0**: Output follows all stated constraints exactly, including no extra top-level fields, no extra metadata, and no fabricated structural content.
**Score 0.75**: Minor constraint violation with limited impact.
**Score 0.5**: Noticeable constraint violations, but the main output remains partially usable.
**Score 0.25**: Multiple constraint violations reduce trustworthiness.
**Score 0.0**: Output substantially ignores the requested format or constraints.