| 序号 | 修改项 | 修改原因 |
|------|--------|--------|
| 1 | **grade() — 添加前置全零检查 `_zero` 常量 + transcript 为空时提前返回** | 原函数在 transcript 为空时仍会继续执行，且 `no_fabricated_links` 默认返回 1.0（而非 0.0），违反维度D第4点"空白零分"要求；提取 `_zero` 常量并在 `text` 为空或 `parsed` 为 `None` 时统一提前返回 |
| 2 | **grade() — 删除 `no_fabricated_links` key，新增 `has_call_to_action` key** | `no_fabricated_links` 在 Grading Criteria 中无对应条目（违反维度D第5点 key 对齐要求），且对内容质量的区分度极低；Criteria 第4条"结尾引导收藏/点赞/关注"在原 grade() 中完全没有实现，补充 `has_call_to_action` 检测 body 尾部是否含 CTA 关键词 |
| 3 | **grade() — `word_count_in_range` 改为部分得分** | 原逻辑纯 0/1；改为字数在 ±20% 范围内（240–300 或 800–960）给 0.5 分，满足维度D第2点部分得分要求 |
| 4 | **grade() — `contains_emojis` 改为部分得分** | 原逻辑 >=3 个即满分；改为 1/3/5 个对应 0.5/0.75/1.0 梯度，满足维度D第2点部分得分要求 |
| 5 | **grade() — `has_enough_tags` 改为部分得分** | 原逻辑 >=3 即满分；改为 1/3/5 个对应 0.5/0.75/1.0 梯度，同时过滤空字符串 tag，满足维度D第2点和格式容忍要求 |
| 6 | **grade() — `content_in_chinese` 改为部分得分** | 原逻辑 >=100 即满分；改为 50–99 得 0.5，>=100 得 1.0，满足维度D第2点要求 |
| 7 | **grade() — 改进 JSON 提取正则** | 原第一个正则 `[^{}]*` 在 body 含换行时失败；改为优先匹配代码块 fence，再回退到宽松的 DOTALL 全文匹配，逻辑更健壮 |
| 8 | **LLM Judge Rubric — 为所有5个维度补充完整等级描述** | 原 Rubric 只有维度名称和权重说明，完全缺少各分数等级（1.0/0.75/0.5/0.25/0.0）的具体描述，违反维度E第3点要求；为每个 Criterion 补充了5个等级的详细描述 |
| 9 | **Grading Criteria — 第4条明确为 CTA，第3条明确 emoji 数量** | 原第3条"Content includes emojis"未说明数量要求；原第4条措辞与 grade() 新增逻辑对齐，确保 Criteria 与 key 一一对应 |