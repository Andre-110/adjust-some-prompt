---
id: task_562_xiaohongshu_working_mom_content_generator
name: Xiaohongshu Working Mom Content Generator
category: Automation
subcategory: Scenario Based Automation
difficulty: medium
external_dependency: none
verification_method: llm-judge
input_modality: text-only
grading_type: hybrid
grading_weights:
  automated: 0.4
  llm_judge: 0.6
timeout_seconds: 120
workspace_files: []
source_line_number: 4548
source_query: "生成一篇面向上班妈妈的小红书图文笔记文案，主题为"宝宝睡眠训练"。字数300-800字，风格真实、温暖、有干货；开头吸引眼球并制造焦虑或共鸣；多用emoji；段落短小（每段不超过3行）；结尾引导收藏/点赞/关注；适当加入话题标签 #上班妈妈 #育儿 #职场。按以下JSON格式输出：{\"title\":\"标题\",\"body\":\"正文(用\\\\n换行)\",\"tags\":[\"标签1\",\"标签2\",\"标签3\"],\"cover_hint\":\"封面图描述\"}"
---

## Prompt

Hey! I need you to write a Xiaohongshu (Chinese social media) style post for working moms about baby sleep training.

Target audience: working mothers
Niche: parenting + work-life balance

Style guidelines:
- Hook at the beginning that creates urgency or emotional connection
- Use lots of emojis to keep it warm and friendly
- Keep paragraphs short (max 3 lines each)
- End with a call-to-action for saves/likes/follows
- Include hashtags like #WorkingMom #Parenting #WorkLife

Requirements:
- Word count: 300-800 words (in Chinese)
- Tone: authentic, warm, practical tips
- Must include: title, body, tags, cover image suggestion

Output as JSON directly in your response:
```json
{
    "title": "your title here",
    "body": "main content with \\n for line breaks",
    "tags": ["tag1", "tag2", "tag3"],
    "cover_hint": "description of suggested cover image"
}
```

The content should be in Chinese since it's for Xiaohongshu users. Make it feel real, like an actual mom sharing her experience, not a corporate post.

## Expected Behavior

The agent should:
1. Generate a complete JSON object with all four required fields: `title`, `body`, `tags`, `cover_hint`
2. Write the title and body in Chinese with appropriate Xiaohongshu style
3. Include emojis (at least 3) throughout the body text
4. Keep paragraphs short and scannable (max 3 lines each)
5. Include practical sleep training tips that working moms can realistically implement
6. End the body with a clear engagement call-to-action (e.g., 收藏、点赞、关注 or equivalent)
7. Include at least 3 relevant hashtags in the `tags` array
8. Provide a cover image description in `cover_hint`
9. Body text should contain 300–800 Chinese characters

Tested capabilities: content generation, cultural awareness, format compliance, creative writing in Chinese.

## Grading Criteria

- [ ] Output contains valid JSON with all required fields (title, body, tags, cover_hint)
- [ ] Body Chinese character count is within 300–800
- [ ] Content includes at least 3 emojis
- [ ] Body ends with a call-to-action for saves/likes/follows
- [ ] Tags array contains at least 3 relevant hashtags
- [ ] Content is predominantly in Chinese (at least 100 Chinese characters)

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    import json
    import re

    _zero = {
        "valid_json_structure": 0.0,
        "word_count_in_range": 0.0,
        "contains_emojis": 0.0,
        "has_call_to_action": 0.0,
        "has_enough_tags": 0.0,
        "content_in_chinese": 0.0,
    }

    def _get_last_assistant_text(transcript: list) -> str:
        for event in reversed(transcript):
            if event.get("type") != "message":
                continue
            msg = event.get("message", {})
            if msg.get("role") != "assistant":
                continue
            for item in msg.get("content", []):
                if isinstance(item, dict) and item.get("type") == "text":
                    return item.get("text", "")
            content = msg.get("content", "")
            if isinstance(content, str):
                return content
        return ""

    text = _get_last_assistant_text(transcript)
    if not text:
        return _zero.copy()

    # Attempt to extract JSON robustly
    json_str = ""
    # Try code-fenced JSON first
    fenced = re.search(r'```(?:json)?\s*(\{.*?\})\s*```', text, re.DOTALL)
    if fenced:
        json_str = fenced.group(1)
    else:
        # Fall back to outermost { ... } containing all four keys
        raw = re.search(r'\{.*"title".*"body".*"tags".*"cover_hint".*\}', text, re.DOTALL)
        json_str = raw.group(0) if raw else ""

    parsed = None
    if json_str:
        try:
            parsed = json.loads(json_str)
        except json.JSONDecodeError:
            cleaned = re.sub(r'[\x00-\x1f]', ' ', json_str)
            try:
                parsed = json.loads(cleaned)
            except Exception:
                parsed = None

    if parsed is None:
        return _zero.copy()

    scores = {}

    has_title = isinstance(parsed.get("title"), str) and len(parsed["title"].strip()) > 0
    has_body = isinstance(parsed.get("body"), str) and len(parsed["body"].strip()) > 0
    has_tags = isinstance(parsed.get("tags"), list)
    has_cover = isinstance(parsed.get("cover_hint"), str) and len(parsed.get("cover_hint", "").strip()) > 0
    scores["valid_json_structure"] = 1.0 if (has_title and has_body and has_tags and has_cover) else 0.0

    body = parsed.get("body", "") if has_body else ""
    chinese_chars = re.findall(r'[\u4e00-\u9fff]', body)
    char_count = len(chinese_chars)

    # Partial credit for word count: full if 300-800, partial if within ±20% of range
    if 300 <= char_count <= 800:
        scores["word_count_in_range"] = 1.0
    elif 240 <= char_count < 300 or 800 < char_count <= 960:
        scores["word_count_in_range"] = 0.5
    else:
        scores["word_count_in_range"] = 0.0

    # Emoji detection with partial credit
    emoji_pattern = re.compile(
        "["
        "\U0001F600-\U0001F64F"
        "\U0001F300-\U0001F5FF"
        "\U0001F680-\U0001F6FF"
        "\U0001F1E0-\U0001F1FF"
        "\U00002702-\U000027B0"
        "\U0001F900-\U0001F9FF"
        "\U0001FA00-\U0001FA6F"
        "\U00002600-\U000026FF"
        "]+",
        flags=re.UNICODE
    )
    emoji_count = len(emoji_pattern.findall(body))
    if emoji_count >= 5:
        scores["contains_emojis"] = 1.0
    elif emoji_count >= 3:
        scores["contains_emojis"] = 0.75
    elif emoji_count >= 1:
        scores["contains_emojis"] = 0.5
    else:
        scores["contains_emojis"] = 0.0

    # Call-to-action detection at the end of body (last 150 characters)
    cta_terms = ["收藏", "点赞", "关注", "评论", "转发", "save", "like", "follow", "觉得有用", "有帮助"]
    body_tail = body[-150:].lower()
    has_cta = any(t in body_tail for t in cta_terms)
    scores["has_call_to_action"] = 1.0 if has_cta else 0.0

    # Tags count with partial credit
    tags = parsed.get("tags", []) if has_tags else []
    valid_tags = [t for t in tags if isinstance(t, str) and len(t.strip()) > 0]
    if len(valid_tags) >= 5:
        scores["has_enough_tags"] = 1.0
    elif len(valid_tags) >= 3:
        scores["has_enough_tags"] = 0.75
    elif len(valid_tags) >= 1:
        scores["has_enough_tags"] = 0.5
    else:
        scores["has_enough_tags"] = 0.0

    scores["content_in_chinese"] = 1.0 if char_count >= 100 else (0.5 if char_count >= 50 else 0.0)

    return scores
```

## LLM Judge Rubric

### Criterion 1: Content Quality & Authenticity (Weight: 30%)

**Score 1.0**: Content reads like a genuine personal account from a working mom — uses first-person perspective, shares real feelings and struggles, avoids corporate or generic phrasing. Tone is warm, relatable, and emotionally resonant.
**Score 0.75**: Mostly authentic with minor lapses into generic language; still feels personal overall.
**Score 0.5**: Mix of authentic moments and formulaic content; some sections feel templated.
**Score 0.25**: Predominantly generic or corporate tone; only surface-level personal touches.
**Score 0.0**: Feels entirely like a marketing copy or AI-generated template with no authentic voice.

### Criterion 2: Practical Value (Weight: 25%)

**Score 1.0**: Provides 3+ specific, actionable sleep training tips that working mothers can realistically implement (e.g., concrete schedules, specific methods like Ferber/no-cry, tips for re-entry after work). Tips are detailed and directly relevant.
**Score 0.75**: 2–3 actionable tips, mostly specific but one may be vague.
**Score 0.5**: Tips are present but too generic (e.g., "establish a routine" with no specifics) or only 1 actionable point.
**Score 0.25**: Mentions sleep training in passing but provides no real guidance.
**Score 0.0**: No practical tips; purely emotional content with no useful information.

### Criterion 3: Xiaohongshu Style Compliance (Weight: 20%)

**Score 1.0**: Fully follows all Xiaohongshu conventions — attention-grabbing hook in the first sentence, short paragraphs (≤3 lines), generous emoji usage throughout, clear engagement CTA at the end, and relevant hashtags.
**Score 0.75**: Meets most conventions; one element is weak (e.g., CTA is present but generic, or one paragraph is too long).
**Score 0.5**: Meets some conventions but noticeably violates others (e.g., long dense paragraphs, or completely missing CTA).
**Score 0.25**: Only superficially resembles Xiaohongshu style; most conventions missing.
**Score 0.0**: Reads like a blog post or essay with no platform-specific formatting.

### Criterion 4: Emotional Resonance (Weight: 15%)

**Score 1.0**: Opening immediately creates urgency or strong emotional connection (e.g., describes the exhaustion of a working mom, a relatable struggle). Content acknowledges real pain points while offering hope and empathy.
**Score 0.75**: Good emotional hook but follow-through in the body is uneven.
**Score 0.5**: Some emotional language present but the hook is weak or the body is emotionally flat.
**Score 0.25**: Minimal emotional engagement; mostly informational without empathy.
**Score 0.0**: No emotional connection; cold or clinical tone throughout.

### Criterion 5: Overall Polish (Weight: 10%)

**Score 1.0**: Well-structured flow from hook → tips → CTA; no awkward phrasing; casual yet professional; JSON fields all populated correctly and coherently.
**Score 0.75**: Mostly polished with minor structural or phrasing issues.
**Score 0.5**: Noticeable structural gaps or several awkward phrases that break reading flow.
**Score 0.25**: Poorly structured or contains multiple grammar/phrasing issues.
**Score 0.0**: Content is incoherent, unfinished, or structurally broken.