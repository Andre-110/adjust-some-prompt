---
id: task_565_competitor_website_change_analysis
name: Competitor Website Change Analysis
category: Research
subcategory: Business and Market Research
difficulty: medium
external_dependency: none
verification_method: output-check
input_modality: text-only
grading_type: hybrid
grading_weights:
  automated: 0.4
  llm_judge: 0.6
timeout_seconds: 120
workspace_files: []
source_line_number: 7934
source_query: "Analyze a detected website diff on a competitor page and return only a JSON object with fields summary, analysis, significance, action_items, and change_type. Infer the likely business meaning from the diff without fabricating unrelated changes."
---

## Prompt

I’m monitoring competitor website changes and got an alert on one of their pages. Please analyze the change and tell me what it likely means from a competitive/operational perspective.

Target URL: https://siteimpact.com/  
Change magnitude: 0.74%  
Section changed: `speak with a marketing expert`

Diff:
```diff
--- previous
+++ current
@@ -238,7 +238,7 @@
 ### speak with a marketing expert:
 
 *   [Phone: 954-982-7900](tel:9549827900)
-*   [Email: [email protected]](https://siteimpact.com/cdn-cgi/l/email-protection#1b687a777e685b68726f7e72766b7a786f35787476)
+*   [Email: [email protected]](https://siteimpact.com/cdn-cgi/l/email-protection#f58694999086b5869c81909c9885949681db969a98)
 *   [Do Not Sell My Personal Information](https://siteimpact.com/cali_compliance.php)
 
 [Contact Us](https://siteimpact.com/contact-us.php)
````

Return ONLY one JSON object with exactly these fields:

* `summary`: 1-2 sentence summary of the observed change
* `analysis`: concise competitive or operational interpretation grounded in the diff
* `significance`: float from `0.0` to `1.0`
* `action_items`: array of recommended actions
* `change_type`: one of `"content"`, `"price"`, `"layout"`, `"seo"`, `"new_page"`, `"removed"`

Requirements:

* Base the analysis only on the diff shown above
* Do not invent unrelated site changes
* Do not add any text outside the JSON object

## Expected Behavior

The agent should:

1. Parse the diff and identify that the changed element is the contact email entry in the “speak with a marketing expert” section.
2. Infer that this is a minor content/contact-detail update rather than a pricing, layout, SEO, new-page, or removed-page change.
3. Classify `change_type` as `content`.
4. Assign a low significance score because the reported change magnitude is only 0.74% and the diff reflects a narrow operational/contact update.
5. Provide grounded action items, such as monitoring whether the new email suggests lead-routing changes or updating competitor contact tracking notes.
6. Avoid fabricating broader conclusions such as pricing changes, product launches, redesigns, or structural site changes.

Ground truth:

* The observable change is a contact email update in a contact/CTA section.
* The best `change_type` is `content`.
* The significance should be low, not medium-high or high.
* The response should stay tightly grounded in the diff.

Key trap:

* The model may over-interpret a small contact-detail edit as a major strategic, SEO, pricing, or site-structure change. That would be incorrect.

Tested capabilities:

* diff reading
* structured business analysis
* calibrated significance scoring
* strict JSON formatting
* avoiding hallucinated competitive claims

## Grading Criteria

* [ ] Response is a valid JSON object and contains no extra non-JSON text
* [ ] Includes all required fields: `summary`, `analysis`, `significance`, `action_items`, `change_type`
* [ ] `significance` is numeric and between `0.0` and `1.0`
* [ ] `action_items` is an array
* [ ] `change_type` is one of the allowed values and correctly classified as `content`
* [ ] `summary` or `analysis` identifies the change as an email/contact detail update
* [ ] Response does not fabricate unrelated changes or exaggerate the significance

## Automated Checks

````python
def grade(transcript: list, workspace_path: str) -> dict:
    import json
    import re

    SCORE_KEYS = [
        "valid_json_only",
        "has_all_required_fields",
        "significance_valid",
        "action_items_is_array",
        "change_type_correct",
        "mentions_email_or_contact_update",
        "grounded_and_not_exaggerated",
    ]

    def zero_scores():
        return {k: 0.0 for k in SCORE_KEYS}

    def get_last_assistant_text(transcript: list) -> str:
        for event in reversed(transcript):
            if event.get("type") != "message":
                continue
            msg = event.get("message", {})
            if msg.get("role") != "assistant":
                continue

            content = msg.get("content", "")
            if isinstance(content, str):
                return content.strip()

            if isinstance(content, list):
                texts = []
                for item in content:
                    if isinstance(item, dict) and item.get("type") == "text":
                        texts.append(item.get("text", ""))
                return "\n".join(texts).strip()

        return ""

    response = get_last_assistant_text(transcript)
    if not response:
        return zero_scores()

    scores = zero_scores()
    candidate = response.strip()

    fenced = re.fullmatch(r"```(?:json)?\s*(\{.*\})\s*```", candidate, flags=re.DOTALL | re.IGNORECASE)
    if fenced:
        candidate = fenced.group(1).strip()

    if not (candidate.startswith("{") and candidate.endswith("}")):
        return scores

    try:
        data = json.loads(candidate)
    except Exception:
        return scores

    scores["valid_json_only"] = 1.0

    required_fields = ["summary", "analysis", "significance", "action_items", "change_type"]
    scores["has_all_required_fields"] = 1.0 if all(field in data for field in required_fields) else 0.0

    sig = data.get("significance")
    if isinstance(sig, (int, float)) and 0.0 <= float(sig) <= 1.0:
        scores["significance_valid"] = 1.0
    else:
        scores["significance_valid"] = 0.0

    scores["action_items_is_array"] = 1.0 if isinstance(data.get("action_items"), list) else 0.0

    change_type = str(data.get("change_type", "")).strip().lower()
    valid_types = {"content", "price", "layout", "seo", "new_page", "removed"}
    if change_type in valid_types:
        scores["change_type_correct"] = 1.0 if change_type == "content" else 0.0
    else:
        scores["change_type_correct"] = 0.0

    summary = str(data.get("summary", "")).lower()
    analysis = str(data.get("analysis", "")).lower()
    combined = f"{summary} {analysis}"

    contact_signals = [
        "email", "contact", "contact detail", "contact details",
        "contact info", "contact information", "email address",
        "info@", "sales@"
    ]
    scores["mentions_email_or_contact_update"] = 1.0 if any(s in combined for s in contact_signals) else 0.0

    fabricated_or_exaggerated_terms = [
        "price change", "pricing update", "new pricing",
        "layout redesign", "redesign", "seo overhaul",
        "new page", "page launch", "removed page",
        "product launch", "new product", "major strategic shift",
        "major repositioning", "sitewide change", "broad redesign"
    ]
    has_fabrication = any(term in combined for term in fabricated_or_exaggerated_terms)

    low_sig_ok = isinstance(sig, (int, float)) and float(sig) <= 0.35
    scores["grounded_and_not_exaggerated"] = 1.0 if (not has_fabrication and low_sig_ok) else 0.0

    return scores
````

## LLM Judge Rubric

### Criterion 1: Change Identification Accuracy (Weight: 35%)

**Score 1.0**: Correctly identifies the observed change as a contact/email detail update and keeps the explanation tightly grounded in the diff.
**Score 0.75**: Correctly identifies the contact-related change but with minor imprecision.
**Score 0.5**: Partially identifies the change but adds unclear or weakly supported interpretation.
**Score 0.25**: Notices something changed but misstates the nature of the change.
**Score 0.0**: Fails to identify the actual change.

### Criterion 2: Competitive Interpretation Calibration (Weight: 25%)

**Score 1.0**: Interprets the change as minor and operational, with an appropriately low significance score.
**Score 0.75**: Mostly calibrated, though the significance or implications are slightly overstated.
**Score 0.5**: Mixed calibration; includes speculative implications not well supported by the diff.
**Score 0.25**: Strong over-interpretation or under-interpretation of the change.
**Score 0.0**: Interpretation is largely ungrounded or clearly wrong.

### Criterion 3: JSON Schema Compliance (Weight: 20%)

**Score 1.0**: Returns exactly one valid JSON object with all required fields and correct field types.
**Score 0.75**: Minor formatting issue but still parseable and mostly compliant.
**Score 0.5**: Some required fields are missing or malformed.
**Score 0.25**: Major schema issues reduce usability.
**Score 0.0**: Not valid JSON or not a single JSON object.

### Criterion 4: Actionability and Non-Fabrication (Weight: 20%)

**Score 1.0**: Action items are practical and restrained, and the response avoids inventing unrelated changes.
**Score 0.75**: Action items are reasonable, with only slight speculative overreach.
**Score 0.5**: Some useful action items, but also includes unsupported claims.
**Score 0.25**: Action items are weak or mostly speculative.
**Score 0.0**: Response is dominated by fabricated claims or irrelevant actions.

```