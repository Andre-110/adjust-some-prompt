---
id: task_00478_momentum_volatility_factor
name: Momentum Volatility Composite Factor Calculation
category: Finance and Quantitative Trading
subcategory: Trading Strategies and Backtesting
difficulty: medium
grading_type: automated
timeout_seconds: 600
input_modality: text-only
external_dependency: none
skill_creation: false
workspace_files:
  - path: data/stock_prices.csv
    role: input
    description: Daily OHLCV price data for a stock (60 trading days)
  - path: data/sample_prices.csv
    role: noise
    description: Simplified sample price data with Date and Close columns only
  - path: data/factor_spec.json
    role: context
    description: JSON specification of the factor formula and parameters
  - path: data/market_metadata.json
    role: noise
    description: Market metadata for the stock (not needed for computation)
  - path: data/sector_performance.csv
    role: noise
    description: Sector-level performance summary (not needed for computation)
---

## Prompt

I have daily stock price data in `data/stock_prices.csv` that includes Date, Open, High, Low, Close, and Volume columns. I need you to compute a quantitative factor called "momentum_volatility" — it's a momentum-volatility composite factor defined as:

(Close / Ref(Close, 20) - 1) / Std(Return, 20)

where the numerator is the 20-day momentum (today's close divided by the close 20 trading days ago, minus 1), and the denominator is the rolling 20-day standard deviation of daily returns. Daily return is simply Close_t / Close_{t-1} - 1.

Please write the implementation as `momentum_volatility.py` and save the computed factor values to `data/momentum_volatility.csv` with Date and the factor column.

## Expected Behavior

The agent should:

1. Read the stock price data from `data/stock_prices.csv` containing Date, Open, High, Low, Close, and Volume columns.
2. Create a Python script `momentum_volatility.py` that implements the factor formula:
   - Extract the Date and Close columns from the OHLCV data (ignoring Open, High, Low, Volume for this calculation).
   - Compute daily returns from the Close prices: `Return_t = Close_t / Close_{t-1} - 1`.
   - Compute 20-day momentum as `Close_t / Close_{t-20} - 1`.
   - Compute the rolling 20-day standard deviation of daily returns (using the 20 most recent daily returns including the current day).
   - Divide the 20-day momentum by the rolling 20-day standard deviation to get the composite factor.
3. The script should handle the first 20 rows having NaN/missing values due to insufficient lookback period:
   - Daily return is undefined for the first row (index 0).
   - 20-day momentum requires 20 prior close values, so it is undefined for the first 20 rows (indices 0-19).
   - Rolling 20-day standard deviation of returns requires 20 return values, so it is undefined for the first 20 rows as well.
   - Therefore, the factor value should be NaN for the first 20 rows (indices 0-19) and computed for rows 20-59 (approximately 40 values).
4. Save the results to `data/momentum_volatility.csv` with at least a Date column and a factor value column.
5. The script should run successfully without errors.

For reference, using the provided `data/stock_prices.csv`:
- The first computable row is 2024-10-01 (index 20), where momentum = Close[20]/Close[0] - 1 and std is the rolling 20-day std of returns ending at that date.
- The last row is 2024-11-22 (index 59).
- Factor values should be finite real numbers (not infinity), since the std denominator should be non-zero for realistic price data with variation.

## Grading Criteria

- [ ] `momentum_volatility.py` exists and is a valid Python script
- [ ] The script contains the core formula components (momentum calculation, std of returns, division)
- [ ] The script correctly reads from `data/stock_prices.csv` and uses the Close column from the OHLCV data
- [ ] `data/momentum_volatility.csv` output file is created with results
- [ ] The output CSV contains a Date column and a factor value column
- [ ] Factor values are present for rows where sufficient lookback data exists (after row 20)
- [ ] The first ~20 rows correctly have no factor value (NaN or empty) due to insufficient data

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    import os
    import csv
    import re
    from pathlib import Path

    scores = {
        "script_exists": 0.0,
        "formula_components": 0.0,
        "correct_data_source": 0.0,
        "output_csv_exists": 0.0,
        "output_csv_structure": 0.0,
        "factor_values_present": 0.0,
        "nan_handling": 0.0,
    }

    ws = Path(workspace_path)

    # 1. Check that momentum_volatility.py exists
    script_path = ws / "momentum_volatility.py"
    if not script_path.exists():
        return scores
    scores["script_exists"] = 1.0

    # 2. Read script content
    try:
        script_content = script_path.read_text(encoding="utf-8")
    except Exception:
        script_content = ""

    # 3. Check formula components in the script
    component_count = 0
    # Check for momentum calculation: close divided by lagged close
    if re.search(
        r'close.*\[.*-\s*20|close.*20.*ago|ref.*close.*20|momentum|close_lag|'
        r'close\[i\s*-\s*20\]|shift\s*\(\s*20\s*\)|\.shift\(20\)',
        script_content, re.IGNORECASE
    ):
        component_count += 1
    # Check for return calculation
    if re.search(
        r'return|ret|pct_change|close.*close.*-\s*1|close\[i\].*close\[i\s*-\s*1\]',
        script_content, re.IGNORECASE
    ):
        component_count += 1
    # Check for standard deviation
    if re.search(
        r'\.std\(|std\(|stdev|standard.*dev|variance.*sqrt|sqrt.*variance|rolling.*std',
        script_content, re.IGNORECASE
    ):
        component_count += 1
    # Check for division of momentum by std
    if re.search(
        r'momentum.*std|momentum.*vol|mom.*std|numerator.*denominator|'
        r'/\s*std|/\s*stdev|/\s*rolling_std|/\s*vol',
        script_content, re.IGNORECASE
    ):
        component_count += 1

    scores["formula_components"] = min(component_count / 4.0, 1.0)

    # 4. Check correct data source (should use stock_prices.csv, not sample_prices.csv)
    if re.search(r'stock_prices\.csv', script_content):
        scores["correct_data_source"] = 1.0
    elif re.search(r'sample_prices\.csv', script_content):
        # Using sample_prices.csv is acceptable but not ideal (simpler data)
        scores["correct_data_source"] = 0.5
    else:
        # Some other file reference or hardcoded data
        scores["correct_data_source"] = 0.25

    # 5. Check output CSV exists
    output_path = ws / "data" / "momentum_volatility.csv"
    if not output_path.exists():
        return scores
    scores["output_csv_exists"] = 1.0

    # 6. Check output CSV structure
    try:
        with open(output_path, "r", encoding="utf-8") as f:
            reader = csv.reader(f)
            headers = next(reader, [])
            rows = list(reader)
    except Exception:
        return scores

    headers_lower = [h.strip().lower() for h in headers]
    has_date = any("date" in h for h in headers_lower)
    has_factor = any(
        kw in h
        for h in headers_lower
        for kw in [
            "momentum_volatility", "factor", "mv_factor",
            "momentum_vol", "mom_vol", "composite"
        ]
    )

    if has_date and has_factor:
        scores["output_csv_structure"] = 1.0
    elif has_date or has_factor:
        scores["output_csv_structure"] = 0.5
    else:
        # Even if column names differ, if there are at least 2 columns, partial credit
        if len(headers) >= 2:
            scores["output_csv_structure"] = 0.25

    # 7. Check that factor values are present for rows with sufficient lookback
    # The input has 60 rows; after 20-day lookback, ~40 rows should have values
    factor_col_idx = None
    for i, h in enumerate(headers_lower):
        for kw in [
            "momentum_volatility", "factor", "mv_factor",
            "momentum_vol", "mom_vol", "composite"
        ]:
            if kw in h:
                factor_col_idx = i
                break
        if factor_col_idx is not None:
            break

    # Fallback: use last column if no named factor column found
    if factor_col_idx is None and len(headers) >= 2:
        factor_col_idx = len(headers) - 1

    if factor_col_idx is not None:
        non_empty_values = 0
        empty_values = 0
        numeric_values = []
        for row in rows:
            if factor_col_idx < len(row):
                val = row[factor_col_idx].strip()
                if val == "" or val.lower() in ("nan", "none", "null"):
                    empty_values += 1
                else:
                    try:
                        numeric_values.append(float(val))
                        non_empty_values += 1
                    except ValueError:
                        empty_values += 1
            else:
                empty_values += 1

        # We expect roughly 39-40 non-empty values out of 60 rows
        if non_empty_values >= 30:
            scores["factor_values_present"] = 1.0
        elif non_empty_values >= 20:
            scores["factor_values_present"] = 0.75
        elif non_empty_values >= 10:
            scores["factor_values_present"] = 0.5
        elif non_empty_values >= 1:
            scores["factor_values_present"] = 0.25

        # 8. Check NaN handling: first ~20 rows should be empty/NaN
        early_empty = 0
        for row in rows[:20]:
            if factor_col_idx < len(row):
                val = row[factor_col_idx].strip()
                if val == "" or val.lower() in ("nan", "none", "null"):
                    early_empty += 1

        late_filled = 0
        for row in rows[20:]:
            if factor_col_idx < len(row):
                val = row[factor_col_idx].strip()
                if val != "" and val.lower() not in ("nan", "none", "null"):
                    try:
                        float(val)
                        late_filled += 1
                    except ValueError:
                        pass

        # At least 15 of first 20 should be empty, and at least 30 of remaining should be filled
        if early_empty >= 18 and late_filled >= 30:
            scores["nan_handling"] = 1.0
        elif early_empty >= 15 and late_filled >= 20:
            scores["nan_handling"] = 0.75
        elif early_empty >= 10 and late_filled >= 10:
            scores["nan_handling"] = 0.5
        elif early_empty >= 5:
            scores["nan_handling"] = 0.25

    return scores
```