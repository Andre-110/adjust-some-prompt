| 序号 | 修改项 | 修改原因 |
|------|--------|----------|
| 1 | Prompt 中将数据文件引用从 `data/sample_prices.csv` 改为 `data/stock_prices.csv`，并说明使用 Close 列 | `stock_prices.csv` 数据更真实（有真实波动特征和 OHLCV 结构），`sample_prices.csv` 数据过于机械线性，不符合真实价格行为 |
| 2 | Expected Behavior 更新为引用 `data/stock_prices.csv`，说明需从 OHLCV 中选取 Date 和 Close 列 | 与 Prompt 修改保持一致 |
| 3 | Expected Behavior 中补充关键数值验证点 | 增强答案明确性 |
| 4 | `workspace_files` 列表补全所有 Assets 目录文件 | 确保 workspace_files 与实际 Assets 目录一致 |
| 5 | grade() 函数中输出文件路径保持不变（`data/momentum_volatility.csv`） | 无需修改 |
| 6 | grade() 函数中增加对 `stock_prices.csv` 列结构的兼容性（Agent 可能输出包含 Open/High/Low/Volume 等额外列） | 增强鲁棒性 |
| 7 | Grading Criteria 中增加一条：正确从多列 CSV 中选取 Close 列进行计算 | `stock_prices.csv` 有 OHLCV 多列，这是一个有区分度的检查点 |