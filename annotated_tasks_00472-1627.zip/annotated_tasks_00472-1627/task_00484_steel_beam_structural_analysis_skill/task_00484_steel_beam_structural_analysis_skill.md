---
id: task_00484_steel_beam_structural_analysis_skill
name: Steel Beam Structural Analysis Skill
category: Data Analysis and Modeling
subcategory: Statistical Analysis and Modeling
difficulty: hard
grading_type: hybrid
grading_weights: {automated: 0.4, llm_judge: 0.6}
timeout_seconds: 600
input_modality: text-only
external_dependency: none
skill_creation: true
workspace_files:
  - path: input_params.json
    content: |
      {
        "beam_length_mm": 2500,
        "section_width_mm": 120,
        "section_height_mm": 60,
        "concentrated_load_N": 1500,
        "material": "Q235 structural steel",
        "elastic_modulus_GPa": 206,
        "yield_strength_MPa": 235
      }
  - path: requirements.txt
    content: |
      numpy
      scipy
  - path: data/beam_case_study.json
    content: |
      {
        "case_id": "BEAM-2025-0047",
        "title": "Rectangular Steel Beam - Central Point Load Analysis",
        "date": "2025-07-15",
        "engineer": "J. Morrison",
        "status": "pending_analysis",
        "beam": {
          "material": "Structural Steel (Q235B)",
          "length_mm": 2500,
          "width_mm": 120,
          "height_mm": 60,
          "cross_section": "solid_rectangular",
          "youngs_modulus_GPa": 206,
          "yield_strength_MPa": 235,
          "density_kg_m3": 7850,
          "poissons_ratio": 0.3
        },
        "loading": {
          "type": "concentrated_vertical",
          "magnitude_N": 1500,
          "position": "midspan",
          "position_mm": 1250,
          "direction": "downward"
        },
        "support_conditions": {
          "type": "simply_supported",
          "left_support": {
            "type": "pin",
            "location_mm": 0,
            "constraints": ["vertical_displacement", "horizontal_displacement"]
          },
          "right_support": {
            "type": "roller",
            "location_mm": 2500,
            "constraints": ["vertical_displacement"]
          }
        },
        "requirements": {
          "safety_factor_min": 2.0,
          "max_deflection_ratio": "L/250",
          "analysis_type": "elastic",
          "code_reference": "GB 50017-2017"
        },
        "notes": "Standard classroom demonstration case. Rectangular cross-section for simplified hand calculation."
      }
  - path: data/beam_formulas_reference.md
    content: |
      # Beam Analysis Quick Reference — Common Loading Cases

      ## 1. Simply Supported Beam, Central Point Load (P at L/2)

      | Quantity | Formula |
      |---|---|
      | Reaction forces | R_A = R_B = P/2 |
      | Max bending moment | M_max = P·L / 4 (at midspan) |
      | Shear force (left half) | V = +P/2 |
      | Shear force (right half) | V = −P/2 |
      | Max deflection | δ_max = P·L³ / (48·E·I) (at midspan) |
      | Max bending stress | σ_max = M_max · c / I where c = h/2 |

      ## 2. Simply Supported Beam, Uniformly Distributed Load (w per unit length)

      | Quantity | Formula |
      |---|---|
      | Reaction forces | R_A = R_B = w·L/2 |
      | Max bending moment | M_max = w·L² / 8 (at midspan) |
      | Max shear force | V_max = w·L/2 (at supports) |
      | Max deflection | δ_max = 5·w·L⁴ / (384·E·I) (at midspan) |

      ## 3. Cantilever Beam, Point Load at Free End

      | Quantity | Formula |
      |---|---|
      | Reaction force | R = P |
      | Reaction moment | M_R = P·L |
      | Max bending moment | M_max = P·L (at fixed end) |
      | Max shear force | V_max = P (constant) |
      | Max deflection | δ_max = P·L³ / (3·E·I) (at free end) |

      ## 4. Fixed-Fixed Beam, Central Point Load

      | Quantity | Formula |
      |---|---|
      | Reaction forces | R_A = R_B = P/2 |
      | Max bending moment | M_max = P·L / 8 (at midspan and supports) |
      | Max deflection | δ_max = P·L³ / (192·E·I) |

      ## Section Properties — Rectangular Cross-Section (b × h)

      | Property | Formula |
      |---|---|
      | Area | A = b · h |
      | Second moment of area (I_x) | I = b·h³ / 12 |
      | Section modulus (S_x) | S = b·h² / 6 |
      | Distance to extreme fiber | c = h / 2 |

      ## Safety Factor

      n = σ_yield / σ_max

      If n ≥ required safety factor → design is adequate.

      ## Deflection Serviceability Limit

      Typical allowable deflection: L/250 to L/360 depending on code and application.
  - path: data/bolt_connection_specs.csv
    content: |
      bolt_grade,nominal_diameter_mm,pitch_mm,tensile_strength_MPa,yield_strength_MPa,proof_load_kN,torque_Nm,typical_application
      4.6,M12,1.75,400,240,28.8,49,Light structural connections
      4.6,M16,2.00,400,240,54.1,116,General framing
      4.6,M20,2.50,400,240,84.3,226,Column base plates
      8.8,M12,1.75,800,640,57.7,98,High-strength beam connections
      8.8,M16,2.00,800,640,108.2,232,Moment-resisting frames
      8.8,M20,2.50,800,640,168.6,452,Bridge girder connections
      8.8,M24,3.00,800,640,244.6,787,Heavy structural joints
      10.9,M12,1.75,1040,940,75.1,121,Pre-tensioned bolted connections
      10.9,M16,2.00,1040,940,140.8,302,Slip-critical joints
      10.9,M20,2.50,1040,940,219.4,588,Wind-bracing systems
      10.9,M24,3.00,1040,940,318.0,1023,High-load tower connections
      12.9,M16,2.00,1220,1100,165.0,354,Specialized high-strength assemblies
      12.9,M20,2.50,1220,1100,257.0,689,Heavy machinery mounting
  - path: data/previous_analysis_log.txt
    content: |
      [2025-07-15 09:12:03] INFO  Session started: Structural beam analysis demo
      [2025-07-15 09:12:15] INFO  User requested: Define a steel beam example for structural analysis demonstration
      [2025-07-15 09:12:18] INFO  Parameters agreed:
                                  - Material: Q235B structural steel
                                  - Length: 2500 mm
                                  - Width: 120 mm
                                  - Height: 60 mm
                                  - Load: 1500 N vertical concentrated at midspan
      [2025-07-15 09:12:22] INFO  Cross-section type: Solid rectangular
      [2025-07-15 09:12:25] INFO  Support condition: Simply supported (pin + roller)
      [2025-07-15 09:12:30] INFO  Case file written to data/beam_case_study.json
      [2025-07-15 09:13:01] INFO  User confirmed parameters. Ready for full structural analysis.
      [2025-07-15 09:13:05] PENDING  Awaiting analysis execution request...
      [2025-07-15 09:15:42] INFO  User requested: Demonstrate the structural force analysis for this case
      [2025-07-15 09:15:43] INFO  Analysis type: Elastic beam theory (Euler-Bernoulli)
      [2025-07-15 09:15:44] PENDING  Analysis not yet performed. Initiating workflow...
  - path: data/project_load_combinations.yaml
    content: |
      # Load Combinations per GB 50009-2012 (Code for Loads)
      # Project: Workshop Mezzanine Floor Retrofit - Phase 2
      # Document: LC-2025-003 Rev.A

      project:
        name: "Workshop Mezzanine Floor Retrofit"
        location: "Building C, Industrial Park Zone 3"
        code: "GB 50009-2012"
        design_life_years: 50

      dead_loads:
        self_weight_steel: 0.785
        concrete_slab: 3.0
        floor_finish: 0.5
        MEP_services: 0.25
        ceiling: 0.15

      live_loads:
        office_area: 2.0
        storage_area: 5.0
        corridor: 3.5
        equipment_point: 1.5

      combinations:
        - id: "LC-01"
          description: "Dead + Live (basic)"
          formula: "1.2D + 1.4L"
          gamma_D: 1.2
          gamma_L: 1.4
          psi_L: 1.0
          governs: false
        - id: "LC-02"
          description: "Dead + Live (favorable dead)"
          formula: "1.0D + 1.4L"
          gamma_D: 1.0
          gamma_L: 1.4
          psi_L: 1.0
          governs: true
        - id: "LC-03"
          description: "Dead only"
          formula: "1.35D"
          gamma_D: 1.35
          gamma_L: 0.0
          psi_L: 0.0
          governs: false
        - id: "LC-04"
          description: "Dead + Live + Wind (combination)"
          formula: "1.2D + 0.7×1.4L + 0.6×1.4W"
          gamma_D: 1.2
          gamma_L: 0.98
          gamma_W: 0.84
          governs: false
        - id: "LC-05"
          description: "Serviceability - characteristic"
          formula: "1.0D + 1.0L"
          gamma_D: 1.0
          gamma_L: 1.0
          limit_state: "serviceability"
          deflection_limit: "L/250"

      notes:
        - "Point load of 1500N used for local beam check (equipment placement scenario)"
        - "Beam specimen: 2500×120×60 mm rectangular solid steel, Q235B"
        - "See beam_case_study.json for detailed single-beam analysis parameters"
  - path: data/steel_material_properties.csv
    content: |
      grade,standard,yield_strength_MPa,tensile_strength_MPa,youngs_modulus_GPa,elongation_pct,density_kg_m3,poissons_ratio,thermal_expansion_1e6_per_C,typical_use
      Q195,GB/T 700,195,315,206,33,7850,0.30,12.0,Light structures and general fabrication
      Q215,GB/T 700,215,335,206,31,7850,0.30,12.0,Riveted structures and general use
      Q235A,GB/T 700,235,370,206,26,7850,0.30,12.0,General structural steel beams and columns
      Q235B,GB/T 700,235,370,206,26,7850,0.30,12.0,Building frames and bridges - improved toughness
      Q275,GB/T 700,275,410,206,22,7850,0.30,12.0,Heavy-duty structural members
      Q345B,GB/T 1591,345,470,206,22,7850,0.30,12.0,High-strength structural applications
      Q390B,GB/T 1591,390,490,206,20,7850,0.30,12.0,Large-span bridges and heavy equipment
      Q420B,GB/T 1591,420,520,206,19,7850,0.30,12.0,Offshore and high-load structures
      Q460C,GB/T 1591,460,550,206,17,7850,0.30,12.0,High-performance structural steel
      SS400,JIS G3101,245,400,200,21,7860,0.30,11.7,General Japanese structural steel
      A36,ASTM A36,250,400,200,23,7850,0.29,11.7,US general structural steel
      S235JR,EN 10025,235,360,210,26,7850,0.30,12.0,European general structural steel
      S275JR,EN 10025,275,410,210,23,7850,0.30,12.0,European medium-strength structural steel
      S355JR,EN 10025,355,470,210,22,7850,0.30,12.0,European high-strength structural steel
---

## Prompt

Hey, I need a reusable skill for performing simply-supported beam structural analysis. Create it as a SKILL.md file in the workspace — think of it like a "beam-analyzer" skill, similar in spirit to how a "data-enricher" skill enriches data or a "design-assets" skill creates graphic assets, but for structural engineering calculations.

The skill should describe how to take beam geometry, material properties, and loading conditions as inputs, then produce a full structural analysis report including bending moment, shear force, maximum bending stress, deflection, and safety factor.

Once you've created the skill, use it to analyze this steel beam:
- Length: 2500 mm
- Cross-section width: 120 mm
- Cross-section height: 60 mm
- Concentrated vertical load: 1500 N applied at midspan
- Material: Q235 structural steel (E = 206 GPa, yield strength = 235 MPa)

There are some reference files already in the workspace under `data/` — a case study JSON, formula reference sheet, and material properties table that may be helpful.

Assume a simply-supported beam (pin at one end, roller at the other). Write a Python script `beam_analysis.py` that performs all the calculations, and save a results report to `output/analysis_report.txt`. The report should clearly state the support/boundary conditions, calculation assumptions, and output the bending moment, shear force, max bending stress, deflection, safety factor, and a conclusion about whether the beam is safe.

## Expected Behavior

The agent should:

1. **Create a SKILL.md file** with YAML frontmatter (including `name` and `description` fields) and markdown instruction sections describing the beam analysis capability — inspired by existing skills like "data-enricher" and "design-assets" but focused on structural beam analysis.

2. **Create `beam_analysis.py`** — a Python script that:
   - Reads or defines beam parameters (L=2500mm, b=120mm, h=60mm, P=1500N)
   - Assumes a simply-supported beam with midspan concentrated load
   - Calculates support reactions (R_A = R_B = P/2 = 750 N)
   - Calculates maximum bending moment (M_max = PL/4 = 937,500 N·mm)
   - Calculates maximum shear force (V_max = P/2 = 750 N)
   - Calculates second moment of area (I = bh³/12 = 120×60³/12 = 2,160,000 mm⁴)
   - Calculates section modulus (S = bh²/6 = 72,000 mm³)
   - Calculates maximum bending stress (σ = M/S = 937500/72000 ≈ 13.02 MPa)
   - Calculates maximum deflection using standard formula (δ = PL³/(48EI) = 1500×2500³/(48×206000×2160000) ≈ 1.10 mm)
   - Computes safety factor against yield (n = 235/13.02 ≈ 18.05)
   - Writes results to output/analysis_report.txt

3. **Create `output/analysis_report.txt`** containing:
   - Stated boundary conditions (simply-supported: pin + roller)
   - Calculation assumptions (Euler-Bernoulli beam theory, linear elastic, small deflections, etc.)
   - Numerical results for bending moment, shear force, max stress, deflection, safety factor
   - A conclusion about structural adequacy (beam is safe — safety factor well above typical minimum of 2.0, deflection within L/250 serviceability limit)

4. The numerical results should be physically reasonable for the given parameters: max bending stress around 13 MPa, safety factor around 18, deflection around 1.1 mm.

**Note on data consistency:** The `input_params.json` file and the Prompt both specify E = 206 GPa, which is consistent with Q235B steel properties in `data/steel_material_properties.csv` and `data/beam_case_study.json`. The agent should use E = 206 GPa for calculations.

## Grading Criteria

- [ ] SKILL.md exists with proper YAML frontmatter (name and description fields)
- [ ] SKILL.md contains meaningful instruction sections for beam analysis
- [ ] beam_analysis.py script exists
- [ ] output/analysis_report.txt exists
- [ ] Report mentions simply-supported boundary conditions
- [ ] Report contains bending moment value
- [ ] Report contains shear force value
- [ ] Report contains maximum bending stress value
- [ ] Report contains deflection value
- [ ] Report contains safety factor value
- [ ] Report contains a conclusion about beam safety

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    import os
    import re

    scores = {}
    ws = workspace_path

    # 1. Check SKILL.md exists and has proper structure
    skill_path = os.path.join(ws, "SKILL.md")
    skill_score = 0.0
    if os.path.isfile(skill_path):
        try:
            with open(skill_path, "r", encoding="utf-8") as f:
                content = f.read()
            has_frontmatter = content.strip().startswith("---")
            has_name = bool(re.search(r'(?i)name\s*:', content))
            has_description = bool(re.search(r'(?i)description\s*:', content))
            has_sections = len(re.findall(r'^#{1,3}\s+', content, re.MULTILINE)) >= 1
            if has_frontmatter and has_name and has_description:
                skill_score = 0.7
            if has_sections:
                skill_score = min(skill_score + 0.3, 1.0)
        except Exception:
            skill_score = 0.0
    scores["skill_md_structure"] = skill_score

    # 2. Check beam_analysis.py exists
    script_path = os.path.join(ws, "beam_analysis.py")
    script_score = 0.0
    if os.path.isfile(script_path):
        try:
            with open(script_path, "r", encoding="utf-8") as f:
                script_content = f.read()
            if len(script_content) > 50:
                script_score = 0.5
            # Check for key calculation patterns
            calc_keywords = ["moment", "shear", "stress", "deflect", "safety"]
            found = sum(1 for kw in calc_keywords if kw.lower() in script_content.lower())
            script_score = min(script_score + found * 0.1, 1.0)
        except Exception:
            script_score = 0.0
    scores["beam_analysis_script"] = script_score

    # 3. Check output/analysis_report.txt exists and has content
    report_path = os.path.join(ws, "output", "analysis_report.txt")
    alt_paths = [
        os.path.join(ws, "output", "analysis_report.txt"),
        os.path.join(ws, "output", "analysis_report.md"),
        os.path.join(ws, "analysis_report.txt"),
    ]
    report_content = ""
    for p in alt_paths:
        if os.path.isfile(p):
            try:
                with open(p, "r", encoding="utf-8") as f:
                    report_content = f.read()
                break
            except Exception:
                pass

    report_exists_score = 1.0 if len(report_content) > 100 else 0.0
    scores["report_exists"] = report_exists_score

    # 4. Check report contains key engineering results
    report_lower = report_content.lower()
    result_checks = {
        "boundary_conditions": any(term in report_lower for term in ["simply-supported", "simply supported", "pin", "roller", "simple support"]),
        "bending_moment": any(term in report_lower for term in ["bending moment", "moment"]) and bool(re.search(r'\d+', report_content)),
        "shear_force": any(term in report_lower for term in ["shear force", "shear"]),
        "max_stress": any(term in report_lower for term in ["bending stress", "max stress", "maximum stress", "stress"]),
        "deflection": any(term in report_lower for term in ["deflection", "displacement"]),
        "safety_factor": any(term in report_lower for term in ["safety factor", "factor of safety", "fos"]),
        "conclusion": any(term in report_lower for term in ["conclusion", "safe", "adequate", "pass", "acceptable"]),
    }

    found_count = sum(1 for v in result_checks.values() if v)
    scores["report_completeness"] = round(found_count / len(result_checks), 2)

    # 5. Check for reasonable numerical values in report
    numerical_score = 0.0

    # Check for a moment value in reasonable range (800000 - 1100000 N*mm or 800-1100 N*m)
    # Flexible unit matching: N·mm, N*mm, Nmm, N-mm, N mm, etc.
    moment_patterns = [
        r'(\d[\d,]*\.?\d*)\s*(?:N[\s\.\·\*\-]*mm|Nmm)',
        r'(\d[\d,]*\.?\d*)\s*(?:N[\s\.\·\*\-]*m\b|Nm\b)',
    ]
    moment_found = False
    for pattern in moment_patterns:
        moment_match = re.search(pattern, report_content)
        if moment_match:
            try:
                val = float(moment_match.group(1).replace(",", ""))
                # Check N*mm range
                if 800000 <= val <= 1100000:
                    numerical_score += 0.33
                    moment_found = True
                    break
                # Check N*m range
                elif 800 <= val <= 1100:
                    numerical_score += 0.33
                    moment_found = True
                    break
            except ValueError:
                pass

    # If no unit-tagged moment found, look for the raw number near "moment"
    if not moment_found:
        moment_context = re.search(r'(?:moment)[^\d]*(\d[\d,]*\.?\d*)', report_content, re.IGNORECASE)
        if moment_context:
            try:
                val = float(moment_context.group(1).replace(",", ""))
                if 800000 <= val <= 1100000 or 800 <= val <= 1100:
                    numerical_score += 0.33
            except ValueError:
                pass

    # Check bending stress in reasonable range (~13 MPa, accept 10-20 MPa)
    stress_match = re.search(r'(?:stress|σ)[^\d]*(\d+\.?\d*)\s*(?:MPa|mpa)?', report_content, re.IGNORECASE)
    if stress_match:
        try:
            stress_val = float(stress_match.group(1))
            if 10.0 <= stress_val <= 20.0:
                numerical_score += 0.33
        except ValueError:
            pass

    # Check safety factor > 1 (expected ~18, accept > 5 as reasonable for this case)
    sf_patterns = [
        r'(?:safety\s*factor|factor\s*of\s*safety|fos)\s*[=:≈~]\s*(\d+\.?\d*)',
        r'(?:safety\s*factor|factor\s*of\s*safety|fos)\s*(?:is|of)\s*(?:approximately\s*)?(\d+\.?\d*)',
    ]
    for sf_pattern in sf_patterns:
        sf_match = re.search(sf_pattern, report_content, re.IGNORECASE)
        if sf_match:
            try:
                sf_val = float(sf_match.group(1))
                if sf_val > 1.0:
                    numerical_score += 0.34
                    break
            except ValueError:
                pass

    scores["numerical_accuracy"] = min(round(numerical_score, 2), 1.0)

    return scores
```

## LLM Judge Rubric

### Skill File Quality (Weight: 20%)
- 1.0: SKILL.md is well-structured with YAML frontmatter (name, description), clear sections describing the beam analysis methodology, inputs, outputs, and usage instructions — comparable in quality to reference skills like "data-enricher"
- 0.75: SKILL.md exists with frontmatter and reasonable content but missing some sections or lacking detail
- 0.5: SKILL.md exists but is minimal or poorly structured
- 0.25: SKILL.md exists but is essentially a stub with little