---
id: task_1090_trading_strategy_and
name: Trading Strategy Analysis and Position Decision for XYZT
category: Finance
grading_type: hybrid
difficulty: hard
timeout_seconds: 600
workspace_files:
- source: task_1090_trading_strategy_and/data/market/XYZT_ohlcv_daily.csv
  dest: data/market/XYZT_ohlcv_daily.csv
- source: task_1090_trading_strategy_and/data/market/XYZT_ohlcv_intraday.csv
  dest: data/market/XYZT_ohlcv_intraday.csv
- source: task_1090_trading_strategy_and/data/signals/signal_report_2024-12-13.json
  dest: data/signals/signal_report_2024-12-13.json
- source: task_1090_trading_strategy_and/data/portfolio/current_positions.json
  dest: data/portfolio/current_positions.json
- source: task_1090_trading_strategy_and/data/risk/risk_parameters.yaml
  dest: data/risk/risk_parameters.yaml
- source: task_1090_trading_strategy_and/data/signals/sentiment_analysis.json
  dest: data/signals/sentiment_analysis.json
- source: task_1090_trading_strategy_and/data/market/sector_performance.csv
  dest: data/market/sector_performance.csv
- source: task_1090_trading_strategy_and/data/market/economic_calendar.json
  dest: data/market/economic_calendar.json
- source: task_1090_trading_strategy_and/data/risk/correlation_matrix.csv
  dest: data/risk/correlation_matrix.csv
- source: task_1090_trading_strategy_and/reports/backtest_summary_XYZT_sell.csv
  dest: reports/backtest_summary_XYZT_sell.csv
- source: task_1090_trading_strategy_and/data/signals/technical_indicators.json
  dest: data/signals/technical_indicators.json
- source: task_1090_trading_strategy_and/logs/model_execution_2024-12-13.log
  dest: logs/model_execution_2024-12-13.log
- source: task_1090_trading_strategy_and/data/market/options_chain_XYZT.csv
  dest: data/market/options_chain_XYZT.csv
- source: task_1090_trading_strategy_and/data/signals/peer_comparison.csv
  dest: data/signals/peer_comparison.csv
grading_weights:
  automated: 0.55
  llm_judge: 0.45
source_query: 'Given the following signal, market data, and portfolio status, decide
  whether to trade (BUY/SELL/HOLD), choose a position size as a percentage of available
  capital (0–20%), assess risk (low/medium/high), and provide a detailed rationale
  and key factors. Signal: SELL (confidence: MEDIUM), patterns: d'
source_line_number: 1090
subcategory: Trading Strategy and Backtesting
---
## Prompt

End of day Friday, and I need to make a call on our XYZT position before Monday's open. We're sitting on 800 shares with a pretty ugly unrealized loss, and the quant model just fired a signal after today's close. The Fed decision is Monday, which makes this even more fun.

All the relevant data is in the workspace — daily and intraday price history, the model's signal report, our current portfolio and positions, risk parameters from the risk committee, sector performance, correlation data, economic calendar, a backtest summary of prior SELL signals on this name, and a few other supporting files (sentiment, technicals, options chain, peer comparison).

I need you to pull everything together and write up a comprehensive trading decision memo in `trading_decision.md`. Specifically, I need:

- An assessment of XYZT's current technical picture based on the price data and indicators
- Evaluation of the quant model's signal in context — what's it telling us and how reliable has it been historically?
- A risk analysis of our current XYZT position relative to our portfolio constraints and sector exposure limits
- Consideration of the macro environment (the economic calendar, sector trends) and how that factors in
- Your recommended action: reduce/close/hold/add to the position, with specific sizing, price levels (entry/exit/stop-loss), and rationale
- Any data quality issues or inconsistencies you notice across the files — flag anything that doesn't add up

Be rigorous. Cross-reference the data sources against each other and don't just take everything at face value. Some of these files come from different systems and different time periods, so sanity-check what you're working with.

## Expected Behavior

The agent should produce a thorough trading decision memo that synthesizes multiple data sources while correctly identifying and handling three embedded traps:

**Core Analysis:**
1. **Technical Assessment:** The agent should analyze `data/market/XYZT_ohlcv_daily.csv` to identify the clear downtrend — price rose from ~$85 to ~$95 over the first 60 days, then declined to ~$68 over the last 60 days. The intraday data (`data/market/XYZT_ohlcv_intraday.csv`) shows a failed morning rally (up to ~$70.37) followed by a sharp selloff to close at $66.80, with heavy volume on the downside. Technical indicators from `data/signals/technical_indicators.json` and the signal report confirm bearish conditions: RSI at 28.4 (oversold territory), bearish MACD crossover, price below lower Bollinger Band.

2. **Signal Evaluation:** The primary signal report (`data/signals/signal_report_2024-12-13.json`) shows a SELL signal with MEDIUM confidence (0.62), citing double top, bearish engulfing, and volume climax patterns. The agent should evaluate this signal's reliability using the backtest summary.

3. **Portfolio & Risk Analysis:** From `data/portfolio/current_positions.json`, the XYZT position is 800 shares at avg cost $82.30, current price $66.80, with an unrealized P&L of approximately -$12,400. From `data/risk/risk_parameters.yaml`, the agent should check sector exposure (Technology is at 28.5% vs 35% limit), max single loss (5% of portfolio = $25,000, current XYZT loss is ~$12,400), and the high correlation between XYZT and ABCD (0.78 from `data/risk/correlation_matrix.csv`), which compounds technology sector risk.

4. **Macro Considerations:** The economic calendar (`data/market/economic_calendar.json`) shows the Fed rate decision on Monday 2024-12-16 — a HIGH impact event. The agent should note this as a reason for caution/risk reduction ahead of the event. Technology sector has been the worst performer at -8.2% over 30 days (`data/market/sector_performance.csv`).

**Trap Handling:**

- **Trap 1 (Outdated Sentiment Report):** The file `data/signals/sentiment_analysis.json` shows a BULLISH/BUY signal with higher confidence (0.71) than the primary signal (0.62). However, the agent MUST recognize that this report is dated 2024-11-28 — two full weeks stale — and references a price of $78.50, which is dramatically different from the actual current price of $66.80. The stock has fallen ~15% since that sentiment report was generated. The agent should explicitly flag this as outdated/unreliable and NOT let it override the current signal report from 2024-12-13. The correct approach is to rely on the primary signal report and current price data.

- **Trap 2 (Backtest Unit Mismatch):** The file `reports/backtest_summary_XYZT_sell.csv` has a column labeled `return_pct` but the values are actually in basis points (e.g., 280 means 2.80%, not 280%). The agent should recognize this unit mismatch — an average "return_pct" of ~280 would be nonsensical as a percentage (280% return on a trade) but makes perfect sense as 280 basis points (2.8%). The agent should report the correct win rate of approximately 56% (14/25 trades) and the actual average return of ~2.8%, not 280%.

- **Trap 3 (Peer Comparison Market Cap):** In `data/signals/peer_comparison.csv`, the `market_cap_B` column header implies values in billions, but at least one entry (PQRS at 4200) appears to be in millions, which would make it $4.2B — not $4,200B (which would be absurdly large, larger than Apple). The agent should flag this inconsistency if it references peer comparison data.

**Recommended Action:** Given the confluence of bearish technical signals, the existing unrealized loss approaching risk limits, high sector correlation with ABCD, the worst-performing sector, and a major macro event (Fed decision) on Monday, the correct recommendation should lean toward reducing or closing the XYZT position. The agent should specify concrete price levels for stop-loss (around $65.00 support level from the signal report), and note that holding through the Fed decision adds unnecessary event risk to an already losing position.

## Grading Criteria

- [ ] The output file `trading_decision.md` exists and contains a structured trading decision memo
- [ ] The agent correctly identifies the bearish technical picture for XYZT (downtrend, failed intraday rally, oversold RSI, bearish MACD, price below lower Bollinger Band)
- [ ] The agent correctly identifies the sentiment analysis report (`data/signals/sentiment_analysis.json`) as outdated (dated 2024-11-28 with stale price of $78.50) and does NOT treat it as a current, valid signal
- [ ] The agent identifies the unit mismatch in `reports/backtest_summary_XYZT_sell.csv` where return_pct values are actually in basis points, reporting the correct average return of approximately 2.8% (not 280%)
- [ ] The agent calculates or references the unrealized loss on the XYZT position (~$12,400) and evaluates it against the max single loss risk parameter (5% of $500K = $25,000)
- [ ] The agent discusses the high correlation (0.78) between XYZT and ABCD and the implications for concentrated Technology sector risk
- [ ] The agent accounts for the Fed rate decision on Monday 2024-12-16 as a material risk factor in the trading decision
- [ ] The recommendation includes a specific directional action (reduce/close/hold) with concrete price levels (stop-loss, targets) and position sizing rationale
- [ ] The agent explicitly flags at least two data quality issues or inconsistencies across the workspace files
- [ ] The overall recommendation is logically consistent with the evidence presented (bearish technicals + risk limits + macro uncertainty should not result in a BUY recommendation)

## Automated Checks

```python
import os
import re
from pathlib import Path

def grade(transcript: list, workspace_path: str) -> dict:
    """Grade the trading_decision.md output file."""
    
    result = {
        "output_file_exists": 0.0,
        "action_is_sell_or_reduce": 0.0,
        "position_size_range": 0.0,
        "risk_assessment_present": 0.0,
        "identifies_outdated_sentiment": 0.0,
        "mentions_fed_decision_risk": 0.0,
        "mentions_existing_xyzt_position": 0.0,
        "mentions_sector_concentration": 0.0,
        "oversold_rsi_acknowledged": 0.0,
        "rationale_section_exists": 0.0,
        "key_factors_section_exists": 0.0,
        "no_inflated_backtest_returns": 0.0,
    }
    
    output_file = Path(workspace_path) / "trading_decision.md"
    
    # 1. output_file_exists
    if not output_file.exists():
        return result
    
    result["output_file_exists"] = 1.0
    
    content = output_file.read_text(encoding="utf-8", errors="replace")
    content_lower = content.lower()
    
    # 2. action_is_sell_or_reduce: the recommended action should be to sell/reduce/close/exit,
    # not to hold (without qualification) or buy.
    # Accept: SELL, sell, reduce, close, exit, trim — in context of action/decision/recommendation
    pattern_bearish_action = r'(?i)(action|decision|recommendation|trade|position)[:\s\-–]{0,5}(sell|reduce|close|exit|trim)'
    # Also accept standalone "sell" or "reduce" at the start of a line (common in memo bullet points)
    pattern_standalone = r'(?im)^\s*[\*\-]?\s*(sell|reduce|close\s+position|exit\s+position|trim)\b'
    if re.search(pattern_bearish_action, content) or re.search(pattern_standalone, content):
        result["action_is_sell_or_reduce"] = 1.0
    
    # 3. position_size_range: numeric_range 5-20
    # Look for position size context and extract a number in range 5-20
    pos_size_patterns = [
        r'(?i)position\s*size[^.:\n]*?(\d+(?:\.\d+)?)\s*%',
        r'(?i)size[:\s]*(\d+(?:\.\d+)?)\s*%',
        r'(?i)(\d+(?:\.\d+)?)\s*%\s*(?:of\s+)?(?:portfolio|position|capital)',
        r'(?i)allocat\w*[^.:\n]*?(\d+(?:\.\d+)?)\s*%',
        r'(?i)reduc\w+[^.:\n]*?(\d+(?:\.\d+)?)\s*%',
    ]
    for pat in pos_size_patterns:
        matches = re.findall(pat, content)
        for m in matches:
            try:
                val = float(m)
                if 5 <= val <= 20:
                    result["position_size_range"] = 1.0
                    break
            except ValueError:
                continue
        if result["position_size_range"] == 1.0:
            break
    
    # 4. risk_assessment_present: risk level is medium or high
    pattern_risk = r'(?i)(risk[\s:]*assessment|risk[\s:]*level|risk[\s:]*rating)[\s:]*(medium|high)'
    if re.search(pattern_risk, content):
        result["risk_assessment_present"] = 1.0
    
    # 5. identifies_outdated_sentiment: "outdated" or "stale" near sentiment-related terms
    if re.search(r'\b(outdated|stale)\b', content_lower):
        result["identifies_outdated_sentiment"] = 1.0
    
    # 6. mentions_fed_decision_risk: "Fed" and "risk" in same paragraph
    paragraphs = re.split(r'\n\s*\n', content)
    for para in paragraphs:
        para_lower = para.lower()
        if re.search(r'\bfed\b', para_lower) and re.search(r'\brisk\b', para_lower):
            result["mentions_fed_decision_risk"] = 1.0
            break
    
    # 7. mentions_existing_xyzt_position: reference to current/existing position AND loss on XYZT.
    # Broaden from exact "existing position" + "unrealized loss" to accept common synonyms.
    position_terms = r'(?:existing|current|open|held?)\s+position'
    loss_terms = r'(?:unrealized|paper|open)\s+(?:loss|p[&\s]?l|pnl)'
    # Also accept direct dollar amounts near "loss" 
    dollar_loss = r'\$12[,.]?400|\-12[,.]?400'
    for para in paragraphs:
        para_lower = para.lower()
        has_position = bool(re.search(position_terms, para_lower))
        has_loss = bool(re.search(loss_terms, para_lower)) or bool(re.search(dollar_loss, para_lower))
        # Also accept if both "XYZT" and "loss" appear together
        has_xyzt_loss = 'xyzt' in para_lower and re.search(r'\bloss\b', para_lower)
        if (has_position and has_loss) or has_xyzt_loss:
            result["mentions_existing_xyzt_position"] = 1.0
            break
    
    # 8. mentions_sector_concentration: "sector" and "concentration" or "exposure" in same paragraph
    for para in paragraphs:
        para_lower = para.lower()
        if re.search(r'\bsector\b', para_lower) and re.search(r'\b(concentration|exposure|overweight)\b', para_lower):
            result["mentions_sector_concentration"] = 1.0
            break
    
    # 9. oversold_rsi_acknowledged: "RSI" and "oversold" in same paragraph
    for para in paragraphs:
        if re.search(r'\bRSI\b', para) and re.search(r'\boversold\b', para.lower()):
            result["oversold_rsi_acknowledged"] = 1.0
            break
    
    # 10. rationale_section_exists: markdown heading containing "Rationale"
    if re.search(r'^#{1,6}\s+.*\bRationale\b', content, re.MULTILINE | re.IGNORECASE):
        result["rationale_section_exists"] = 1.0
    
    # 11. key_factors_section_exists: markdown heading containing "Key Factors"
    if re.search(r'^#{1,6}\s+.*\bKey\s+Factors\b', content, re.MULTILINE | re.IGNORECASE):
        result["key_factors_section_exists"] = 1.0
    
    # 12. no_inflated_backtest_returns: "280%" or "280 percent" must NOT appear
    if not re.search(r'\b280\s*%|\b280\s+percent\b', content, re.IGNORECASE):
        result["no_inflated_backtest_returns"] = 1.0
    
    return result
```

## LLM Judge Rubric

### Criterion 1: Depth and Rigor of Cross-Source Synthesis (Weight: 35%)
**Score 1.0**: The memo seamlessly integrates data from nearly all provided files (daily OHLCV, intraday OHLCV, signal report, technical indicators, portfolio positions, risk parameters, correlation matrix, sector performance, economic calendar, backtest summary, options chain, peer comparison) into a cohesive narrative. Each analytical section (technical, signal, risk, macro) draws on multiple corroborating or conflicting data points, and the agent explicitly cross-references figures across files (e.g., verifying the current price in the signal report against the latest close in the OHLCV data, checking portfolio P&L math against position data). The analysis demonstrates original reasoning rather than simply restating file contents.
**Score 0.75**: The memo integrates most key data sources and cross-references several data points across files. There may be one or two files that are underutilized or one area where the agent simply restates data without synthesizing. The overall narrative is coherent and most analytical claims are grounded in specific data.
**Score 0.5**: The memo references the major data sources but treats them in relative isolation — each section draws primarily from one file without meaningful cross-referencing. Some analytical claims lack specific supporting data points. The synthesis is adequate but reads more like a summary of individual files than an integrated analysis.
**Score 0.25**: The memo references only a few data sources and makes broad or generic analytical statements. Cross-referencing is largely absent. Several conclusions appear unsupported by specific data or seem to be generic financial reasoning not tied to the actual XYZT situation.
**Score 0.0**: The memo is superficial, references very few files, and contains mostly generic or hallucinated analysis not grounded in the provided data.

### Criterion 2: Trap Detection Quality and Reasoning Transparency (Weight: 40%)
**Score 1.0**: The agent explicitly identifies and correctly resolves all three traps with clear reasoning: (1) flags the sentiment report's date as stale/outdated and explains why its higher confidence score should not override the current signal, showing the specific date discrepancy; (2) identifies the basis point vs. percentage mismatch in the backtest return data, correctly interprets the actual return magnitudes (e.g., 280 bps ≈ 2.8%), and explains how misreading this would distort the analysis; (3) catches the market cap unit anomaly (4200 in a column labeled billions would imply $4.2 trillion) and flags it as implausible for XYZT. For each trap, the agent articulates *why* it is a problem and *how* it adjusts its analysis accordingly.
**Score 0.75**: The agent correctly identifies and resolves two of the three traps with clear reasoning, and at least partially flags the third (e.g., notes something seems off but doesn't fully resolve it). Explanations are mostly transparent.
**Score 0.5**: The agent identifies and resolves one trap clearly, and may partially flag a second. One or more traps are missed entirely, or the agent flags an issue but draws the wrong conclusion from it. Some reasoning about data quality is present but incomplete.
**Score 0.25**: The agent makes a vague mention of data quality concerns but fails to identify any specific trap correctly, or identifies one trap superficially without explaining the implications. The analysis may unknowingly incorporate flawed data.
**Score 0.0**: The agent does not detect any of the three traps and incorporates flawed data uncritically into the analysis (e.g., uses the outdated sentiment report as a primary bullish counterargument, cites 280% backtest returns, or treats XYZT as a $4.2 trillion company).

### Criterion 3: Professional Memo Quality and Decision Framework Coherence (Weight: 25%)
**Score 1.0**: The memo reads as a polished, professional trading decision document suitable for a portfolio manager or risk committee. It has a clear structure with well-defined sections, an executive summary or recommendation upfront, specific and actionable trade parameters (sizing, levels, stops) with explicit rationale tying back to the analysis. The recommendation logically follows from the evidence presented, including appropriate hedging of the conclusion (e.g., acknowledging oversold conditions as a counterargument, noting Fed uncertainty). Conditional logic is present (e.g., "if price breaks X, then Y"). The tone is appropriately measured — neither overconfident nor wishy-washy.
**Score 0.75**: The memo is well-structured and professional with clear sections and a coherent recommendation. Trade parameters are specific and mostly justified. Minor gaps in conditional logic or slight disconnect between analysis and recommendation. The tone is appropriate.
**Score 0.5**: The memo has a recognizable structure and provides a recommendation with some trade parameters, but the connection between analysis and recommendation has noticeable gaps. Some parameters may lack justification, or the memo may be overly one-sided without acknowledging counterarguments. Formatting is adequate but not polished.
**Score 0.25**: The memo is poorly organized, with sections that feel disconnected. The recommendation may contradict parts of the analysis, or trade parameters are vague/missing. The document would not be suitable for professional use without significant revision.
**Score 0.0**: The output lacks coherent structure, provides no actionable recommendation, or the recommendation fundamentally contradicts the data presented. The document is unprofessional in tone or format.