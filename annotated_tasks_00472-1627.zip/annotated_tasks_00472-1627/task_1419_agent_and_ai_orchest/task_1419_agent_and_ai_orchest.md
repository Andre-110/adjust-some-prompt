---
id: task_1419_agent_and_ai_orchest
name: Multi-Agent Orchestration System Design
category: Automation
grading_type: hybrid
difficulty: hard
timeout_seconds: 720
grading_weights:
  automated: 0.45
  llm_judge: 0.55
workspace_files:
- source: task_1419_agent_and_ai_orchest/research/frameworks_comparison.csv
  dest: research/frameworks_comparison.csv
- source: task_1419_agent_and_ai_orchest/research/architecture_patterns.json
  dest: research/architecture_patterns.json
- source: task_1419_agent_and_ai_orchest/research/benchmark_results.csv
  dest: research/benchmark_results.csv
- source: task_1419_agent_and_ai_orchest/config/current_infra.yaml
  dest: config/current_infra.yaml
- source: task_1419_agent_and_ai_orchest/config/team_requirements.yaml
  dest: config/team_requirements.yaml
- source: task_1419_agent_and_ai_orchest/logs/pilot_run_crewai.log
  dest: logs/pilot_run_crewai.log
- source: task_1419_agent_and_ai_orchest/logs/pilot_run_autogen.log
  dest: logs/pilot_run_autogen.log
- source: task_1419_agent_and_ai_orchest/research/cost_analysis.csv
  dest: research/cost_analysis.csv
- source: task_1419_agent_and_ai_orchest/research/failure_modes.json
  dest: research/failure_modes.json
- source: task_1419_agent_and_ai_orchest/docs/legacy_orchestrator_notes.md
  dest: docs/legacy_orchestrator_notes.md
- source: task_1419_agent_and_ai_orchest/docs/vendor_pitch_agentcloud.md
  dest: docs/vendor_pitch_agentcloud.md
- source: task_1419_agent_and_ai_orchest/research/token_usage_breakdown.json
  dest: research/token_usage_breakdown.json
- source: task_1419_agent_and_ai_orchest/config/model_capabilities.yaml
  dest: config/model_capabilities.yaml
- source: task_1419_agent_and_ai_orchest/docs/agent_teams_api_spec.yaml
  dest: docs/agent_teams_api_spec.yaml
source_query: 调研并设计一个"agent teams"多代理协作方案：让主agent可以将子任务分派给多个agent并汇总结果，说明总体架构、任务拆分与协调流程，以及可选的实现框架/落地思路。
source_line_number: 1419
subcategory: Agent and AI Orchestration
---
## Prompt

We're at the point where we need to make a real architectural decision on how to build our multi-agent orchestration layer. The team has been doing research for the past few weeks — framework comparisons, pilot runs, cost projections, the whole nine yards — and all of that material is sitting in the workspace under `research/`, `config/`, `logs/`, and `docs/`.

What I need from you is a comprehensive design document that synthesizes everything we've gathered and produces a concrete recommendation. Specifically: which framework should we adopt, what architecture pattern fits our requirements, how should we structure agent teams for our four core task types (research, code review, data analysis, report generation), and what does the cost picture look like at our expected scale? I also need you to address failure modes and how we'll mitigate them in production.

Make sure you ground everything in the actual data — the benchmark results, the pilot run logs, the infrastructure constraints in our config files. There are various docs and notes floating around from different time periods and sources, so please be careful about what's current versus what might be stale or irrelevant. Our budget ceiling is documented in the infra config and the requirements spec, so the recommendation needs to stay within those bounds.

The output should go into `agent_teams_design.md`. Structure it however makes sense for a technical design doc — executive summary, framework evaluation, architecture recommendation, team composition per task type, cost projections, risk mitigation, that kind of thing. This will be reviewed by engineering leadership, so it needs to be thorough and well-reasoned, not just a summary of each file.

## Expected Behavior

The agent must synthesize data from multiple workspace files to produce a coherent multi-agent system design document. The correct solution involves several critical judgment calls:

**Trap 1 — Outdated Legacy Notes (`docs/legacy_orchestrator_notes.md`):**
The legacy notes from April 2024 recommend BabyAGI as the top framework, claim AutoGen does NOT support hierarchical orchestration, and state the maximum practical agent count is 3. All of these are outdated and contradicted by current data. The `research/frameworks_comparison.csv` shows AutoGen supports hierarchical orchestration (`supports_hierarchical: True`) and has been tested with up to 12 agents. The `config/team_requirements.yaml` specifies support for 3-10 sub-agents per team. The agent should recognize the legacy notes as stale and rely on the current framework comparison data, benchmark results, and pilot logs instead. BabyAGI should NOT appear as a recommendation. The design should acknowledge that modern frameworks like CrewAI, AutoGen, and LangGraph all support hierarchical orchestration with 10+ agents.

**Trap 2 — Unit Mismatch in Token Usage (`research/token_usage_breakdown.json`):**
The `research/token_usage_breakdown.json` file labels token counts for researcher_agent and coder_agent as "tokens" but the values (12.5, 8.3) are actually in k-tokens (thousands). The actual pilot run logs (`logs/pilot_run_crewai.log`) contain the raw token counts that are much larger numbers. When computing cost projections or comparing token usage, the agent should cross-reference with the log files and recognize the unit discrepancy. Correct analysis should normalize all token values to the same unit (raw tokens) before making comparisons or cost calculations.

**Trap 3 — Vendor Pitch Misleading Context (`docs/vendor_pitch_agentcloud.md`):**
The AgentCloud vendor pitch document sits in the `docs/` folder alongside legitimate documentation and promotes a proprietary platform at approximately $50,000/year with inflated capability claims. The `config/current_infra.yaml` specifies a `monthly_budget_usd: 5000` ($60,000/year total, but this covers ALL infrastructure, not just the orchestration layer). The `config/team_requirements.yaml` indicates a preference for a Python-based open-source stack. The agent should NOT recommend the proprietary AgentCloud platform and should instead design around open-source frameworks that fit within the budget constraints.

**Correct Framework Recommendation:**
Based on the benchmark results (`research/benchmark_results.csv`), pilot logs, and infrastructure constraints, the recommendation should favor one or a combination of the well-established open-source frameworks (CrewAI, AutoGen, or LangGraph). The pilot logs show CrewAI completed in ~62 seconds with a timeout issue on the researcher agent, while AutoGen completed in ~48 seconds with higher token usage but no timeouts. The design should weigh these tradeoffs explicitly.

**Architecture Pattern:**
The `research/architecture_patterns.json` describes four patterns. Given the requirements for 3-10 agents, multiple task types, and graceful degradation, a hierarchical pattern (with noted mitigations for single-point-of-failure) or a hybrid approach is most appropriate. The design should reference the pros/cons from the architecture patterns data.

**Cost Projections:**
Using `research/cost_analysis.csv` and the $5,000/month budget from `config/current_infra.yaml`, the design should show that the recommended approach fits within budget. The cost analysis shows monthly costs ranging from $360 to $12,000 depending on scale and model choice, so the design should recommend an appropriate mix of models (including local llama-3-70b for cost optimization).

**Failure Mode Mitigation:**
The `research/failure_modes.json` catalogs six failure modes. The design should address at least the high-severity ones (infinite loops, hallucination cascades, context overflow) with specific mitigation strategies mapped to the chosen architecture.

## Grading Criteria

- [ ] The document is saved to `agent_teams_design.md` and is structured as a professional technical design document with clear sections (executive summary, framework evaluation, architecture recommendation, team composition, cost projections, risk/failure mitigation).
- [ ] The framework recommendation is grounded in data from `research/frameworks_comparison.csv` and `research/benchmark_results.csv`, citing specific metrics (success rates, latency, token usage, cost).
- [ ] The agent correctly avoids the outdated legacy notes trap: does NOT recommend BabyAGI, correctly states that AutoGen supports hierarchical orchestration, and designs for more than 3 agents per team.
- [ ] The agent correctly handles the token usage unit mismatch: either cross-references with pilot logs to identify the discrepancy in `research/token_usage_breakdown.json`, or uses the raw log data directly for token calculations.
- [ ] The agent correctly avoids the vendor pitch trap: does NOT recommend the proprietary AgentCloud platform and stays within the $5,000/month budget constraint using open-source frameworks.
- [ ] The design includes specific agent team compositions for each of the four task types (research, code review, data analysis, report generation) with defined roles and responsibilities.
- [ ] The architecture pattern recommendation references the patterns from `research/architecture_patterns.json` with justification for why the chosen pattern fits the requirements.
- [ ] Cost projections are included and demonstrate the solution fits within the $5,000/month budget, referencing data from `research/cost_analysis.csv` and model pricing.
- [ ] Failure modes from `research/failure_modes.json` are addressed with specific mitigation strategies appropriate to the chosen architecture.
- [ ] The design accounts for infrastructure constraints from `config/current_infra.yaml` (Kubernetes deployment, RabbitMQ, 50 max concurrent requests, Prometheus+Grafana monitoring) and business requirements from `config/team_requirements.yaml` (SLAs, audit trail, sync/async execution, graceful degradation).

## Automated Checks

```python
import os
import re
from pathlib import Path

def grade(transcript: list, workspace_path: str) -> dict:
    """Grade the agent_teams_design.md output file."""
    
    scores = {
        "file_exists": 0.0,
        "architecture_section": 0.0,
        "task_decomposition_section": 0.0,
        "coordination_flow_section": 0.0,
        "framework_recommendation": 0.0,
        "no_babyagi_primary": 0.0,
        "hierarchical_pattern": 0.0,
        "failure_handling": 0.0,
        "budget_awareness": 0.0,
        "result_aggregation": 0.0,
        "implementation_section": 0.0,
        "async_or_parallel": 0.0,
    }
    
    output_file = Path(workspace_path) / "agent_teams_design.md"
    
    # 1. file_exists: The output design document was created
    if not output_file.is_file():
        return scores
    
    scores["file_exists"] = 1.0
    
    content = output_file.read_text(encoding="utf-8", errors="replace")
    content_lower = content.lower()
    
    # 2. architecture_section: section_exists for "Architecture"
    # Look for markdown heading containing "Architecture"
    if re.search(r'(?im)^#{1,3}\s+.*\barchitecture\b', content):
        scores["architecture_section"] = 1.0
    
    # 3. task_decomposition_section: regex_match
    pattern_task = r'(?i)#{1,3}\s.*(task\s+(decomposition|split|breakdown|dispatch|delegation)|subtask\s+(allocation|routing))'
    if re.search(pattern_task, content):
        scores["task_decomposition_section"] = 1.0
    
    # 4. coordination_flow_section: regex_match
    pattern_coord = r'(?i)#{1,3}\s.*(coordination|orchestration|workflow|execution)\s*(flow|process|pipeline|mechanism)'
    if re.search(pattern_coord, content):
        scores["coordination_flow_section"] = 1.0
    
    # 5. framework_recommendation: regex_match for current frameworks
    pattern_fw = r'(?i)(CrewAI|AutoGen|LangGraph|MetaGPT)'
    if re.search(pattern_fw, content):
        scores["framework_recommendation"] = 1.0
    
    # 6. no_babyagi_primary: absence_check
    # Score 1.0 when BabyAGI does NOT appear in a recommendation/primary context.
    # Check for patterns like "recommend BabyAGI", "BabyAGI is recommended",
    # "primary: BabyAGI", "adopt BabyAGI", "use BabyAGI" etc.
    babyagi_recommend_pattern = r'(?i)(recommend\s+babyagi|babyagi\s+(is\s+)?(our\s+)?(top\s+|primary\s+|main\s+)?recommend|adopt\s+babyagi|use\s+babyagi\s+for|build\s+(on|around|with)\s+babyagi|babyagi\s+as\s+(the\s+)?(primary|top|main|recommended|chosen)|primary\s+(framework|choice|recommendation)\s*[:\-]?\s*babyagi)'
    if not re.search(babyagi_recommend_pattern, content_lower):
        scores["no_babyagi_primary"] = 1.0
    
    # 7. hierarchical_pattern: content_contains "hierarchical"
    if re.search(r'(?i)\bhierarchical\b', content):
        scores["hierarchical_pattern"] = 1.0
    
    # 8. failure_handling: regex_match
    pattern_fail = r'(?i)(failure\s+(handling|mode|recover)|retry|graceful\s+degradation|fallback|timeout|error\s+handling)'
    if re.search(pattern_fail, content):
        scores["failure_handling"] = 1.0
    
    # 9. budget_awareness: regex_match
    pattern_budget = r'(?i)(budget|cost|\$5[,.]?000|monthly.*spend|token.*cost|pricing)'
    if re.search(pattern_budget, content):
        scores["budget_awareness"] = 1.0
    
    # 10. result_aggregation: content_near — "aggregat" and "result" in same paragraph
    paragraphs = re.split(r'\n\s*\n', content)
    for para in paragraphs:
        para_lower = para.lower()
        if re.search(r'aggregat', para_lower) and re.search(r'result', para_lower):
            scores["result_aggregation"] = 1.0
            break
    
    # 11. implementation_section: regex_match
    pattern_impl = r'(?i)#{1,3}\s.*(implementation|framework\s+(selection|choice|comparison)|technology|stack)'
    if re.search(pattern_impl, content):
        scores["implementation_section"] = 1.0
    
    # 12. async_or_parallel: regex_match
    pattern_async = r'(?i)(async(hronous)?|parallel|concurrent)\s*(execution|processing|task|agent|dispatch)'
    if re.search(pattern_async, content):
        scores["async_or_parallel"] = 1.0
    
    return scores
```

## LLM Judge Rubric

### Criterion 1: Trap Detection and Data Contradiction Resolution (Weight: 40%)
**Score 1.0**: The document explicitly identifies and correctly resolves all three traps: (1) clearly flags the legacy notes as outdated and explains why BabyAGI is not suitable, noting that AutoGen does support hierarchical orchestration contrary to the legacy claim; (2) identifies the k-token unit mismatch in the token usage JSON, cross-references with pilot run logs, and normalizes values before computing cost projections; (3) recognizes the vendor pitch as a sales document and either dismisses AgentCloud or critically evaluates it against the budget ceiling rather than accepting its claims at face value. Reasoning for each resolution is transparent and grounded in specific file references.
**Score 0.75**: The document correctly resolves at least two of the three traps with clear reasoning and file references. The third trap may be partially addressed (e.g., the agent avoids the wrong conclusion but doesn't explicitly explain why the source was problematic) or handled implicitly without explicit acknowledgment of the contradiction.
**Score 0.5**: The document correctly resolves one trap fully and shows partial awareness of another (e.g., doesn't recommend BabyAGI but also doesn't explain why the legacy notes are wrong; or uses token values without normalization but arrives at roughly correct cost estimates through other means). One trap is clearly missed.
**Score 0.25**: The document avoids the worst outcomes of the traps (e.g., doesn't recommend BabyAGI as primary) but shows no evidence of critically evaluating contradictory sources. Cost figures may be based on unnormalized token data. The vendor pitch may influence recommendations without scrutiny.
**Score 0.0**: The document falls for two or more traps — recommends BabyAGI as a top choice, uses raw JSON token values without normalization leading to wildly incorrect cost projections, or recommends AgentCloud based on the vendor pitch without critical evaluation.

### Criterion 2: Analytical Depth and Evidence-Based Reasoning (Weight: 35%)
**Score 1.0**: The design document demonstrates rigorous analytical reasoning throughout. Framework evaluation includes specific benchmark data, pilot run outcomes, and quantitative comparisons (latency, token efficiency, success rates). Agent team structures for all four task types (research, code review, data analysis, report generation) are justified with concrete rationale tied to task characteristics. Cost projections show clear methodology with assumptions stated, and the recommendation logically follows from the synthesized evidence. The document distinguishes between what was empirically tested versus what is projected.
**Score 0.75**: The document provides solid evidence-based reasoning for most sections. Framework evaluation references actual data points from the workspace. Team structures are well-reasoned for at least three of four task types. Cost projections are present with reasonable methodology, though some assumptions may be unstated. Minor gaps in connecting evidence to conclusions.
**Score 0.5**: The document references workspace data in some sections but relies on general knowledge or plausible-sounding assertions in others. Framework evaluation may list pros/cons without tying them to specific benchmark results. Team structures are described but not deeply justified. Cost projections exist but methodology is vague or partially disconnected from actual token/usage data.
**Score 0.25**: The document is largely generic — it reads like a template design doc that could apply to any multi-agent system. Occasional references to workspace data are superficial. Recommendations appear to be based on general industry knowledge rather than the specific research, benchmarks, and constraints in the workspace.
**Score 0.0**: The document contains no meaningful references to actual workspace data. Recommendations are entirely hallucinated or based on generic knowledge with no connection to the specific pilot runs, benchmarks, config constraints, or cost data provided.

### Criterion 3: Professional Quality, Coherence, and Completeness (Weight: 25%)
**Score 1.0**: The document reads as a polished, production-ready technical design document. It has a logical narrative flow — executive summary sets context, evaluation builds the case, architecture section presents the solution, team designs operationalize it, cost analysis validates feasibility, and failure modes address production readiness. Sections reference each other coherently (e.g., failure handling connects to the architecture pattern chosen). Language is precise and appropriate for a technical audience making an architectural decision. No significant gaps in coverage.
**Score 0.75**: The document is well-structured and coherent with clear section organization. Most sections flow logically into each other. Minor issues such as occasional redundancy, one section that feels underdeveloped relative to others, or slight inconsistencies between sections. Overall suitable for team review with minor revisions.
**Score 0.5**: The document covers the required topics but reads more like a collection of separate analyses than a unified design document. Some sections may feel disconnected or the narrative thread is weak. Adequate for conveying information but would need significant editing before presenting as a formal design recommendation.
**Score 0.25**: The document is disorganized or incomplete — missing significant subsections, inconsistent terminology, or contradictory statements between sections. The reader would struggle to extract a clear, actionable recommendation from the document.
**Score 0.0**: The document is incoherent, severely incomplete, or so poorly structured that it fails to function as a design document. Key sections are missing or contain only placeholder text.