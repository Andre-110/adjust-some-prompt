---
id: task_00492_save_trading_system_memory_note
name: Save Trading System Task to Memory Note
category: Knowledge and Memory Management
subcategory: Planning and Research Notes
difficulty: medium
grading_type: hybrid
grading_weights: {automated: 0.4, llm_judge: 0.6}
timeout_seconds: 600
input_modality: text-only
external_dependency: none
workspace_files:
  - path: MEMORY.md
    role: context
    description: Long-term memory file with user profile, active task registry, and known issues
  - path: memory/.gitkeep
    role: scaffold
    description: Empty placeholder ensuring the memory/ directory exists
  - path: memory/2026-02-21.md
    role: context
    description: Daily notes from Feb 21 including task updates and initial XUAUSD+ discussion
  - path: memory/2026-02-22.md
    role: context
    description: Daily notes from Feb 22 with Task 5 specs discussion and BYX delivery failures
  - path: memory/heartbeat-state.json
    role: context
    description: JSON state file tracking last health checks and heartbeat timestamps
  - path: tasks/btc-analysis-template.md
    role: context
    description: Template for BTC daily analysis reports (Task 2)
  - path: tasks/byx-article-config.json
    role: context
    description: Configuration for BYX article generation task (Task 3)
  - path: tasks/cron-error-log.txt
    role: context
    description: Error log from cron jobs on 2026-02-22
skill_creation: false
---

## Prompt

Hey, can you save the details for Task 5 — the XUAUSD+ automated trading system — into a memory note? Put it at memory/2026-02-23.md. Make sure to include: the delivery deadline is 2026-02-23 08:00 GMT+8; the strategy uses 1-minute candles with RSI divergence as the entry signal, grid adds every 0.1% up to 10 positions max; take-profit closes all when there are ≥5 positions and +0.1% profit, or when there are 10 positions and average cost +0.1%; stop-loss triggers when total drawdown hits ≥1.0%. Also note that we need to validate on Bybit Testnet for 1–2 days before going live. Deliverables should be: Python code, config template, install script, and test guide. And don't forget to mention post-deployment monitoring needs.

## Expected Behavior

The agent should:

1. Create the file `memory/2026-02-23.md` (or a similarly named markdown file inside the `memory/` directory).
2. Include the delivery deadline: **2026-02-23 08:00 GMT+8**.
3. Document the full strategy specifications:
   - 1-minute candles (1m timeframe)
   - RSI divergence as the entry signal
   - Grid position adding every 0.1%, up to a maximum of 10 positions
   - Take-profit rule 1: close all when ≥5 positions and +0.1% profit
   - Take-profit rule 2: close all when 10 positions and average cost +0.1%
   - Stop-loss: total drawdown ≥1.0%
4. Include the validation plan: run on Bybit Testnet for 1–2 days before going live.
5. List the deliverables: Python code, config template, install script, test guide.
6. Mention post-deployment monitoring requirements.
7. Confirm to the user that the note has been saved.

The agent may optionally reference existing context files (MEMORY.md, previous daily notes) to maintain consistency with the established task registry format.

## Grading Criteria

- [ ] File `memory/2026-02-23.md` (or similar .md in memory/) exists
- [ ] Contains delivery deadline (2026-02-23 08:00 GMT+8)
- [ ] Contains strategy specs (1-minute candles, RSI divergence, grid 0.1%, 10 positions)
- [ ] Contains take-profit and stop-loss rules (≥5 positions +0.1%, 10 positions avg cost +0.1%, 1.0% drawdown stop-loss)
- [ ] Contains Bybit Testnet validation plan
- [ ] Contains deliverables list (Python code, config template, install script, test guide)
- [ ] Mentions post-deployment monitoring

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    import os
    import re

    scores = {
        "file_exists": 0.0,
        "deadline_present": 0.0,
        "strategy_specs": 0.0,
        "risk_rules": 0.0,
        "validation_plan": 0.0,
        "deliverables": 0.0,
        "monitoring": 0.0,
    }

    # Check if the memory note file exists
    filepath = os.path.join(workspace_path, "memory", "2026-02-23.md")
    if not os.path.isfile(filepath):
        # Try to find any .md file in memory/ directory that wasn't there before
        memory_dir = os.path.join(workspace_path, "memory")
        if os.path.isdir(memory_dir):
            md_files = [f for f in os.listdir(memory_dir) if f.endswith(".md") and f != ".gitkeep"]
            # Exclude pre-existing daily notes
            pre_existing = {"2026-02-21.md", "2026-02-22.md"}
            new_files = [f for f in md_files if f not in pre_existing]
            if new_files:
                filepath = os.path.join(memory_dir, new_files[0])
            else:
                return scores
        else:
            return scores

    scores["file_exists"] = 1.0

    try:
        with open(filepath, "r", encoding="utf-8") as f:
            content = f.read().lower()
    except Exception:
        return scores

    # Check deadline
    if "2026-02-23" in content and ("08:00" in content or "8:00" in content):
        if "gmt+8" in content or "gmt +8" in content or "utc+8" in content:
            scores["deadline_present"] = 1.0
        else:
            scores["deadline_present"] = 0.5

    # Check strategy specs: 1-minute candles, RSI divergence, grid 0.1%, 10 positions
    spec_score = 0.0
    if any(term in content for term in ["1-minute", "1 minute", "1min", "1m candle", "1-min", "1m timeframe"]):
        spec_score += 0.25
    if "rsi" in content and "divergen" in content:
        spec_score += 0.25
    if "0.1%" in content and ("grid" in content or "add" in content):
        spec_score += 0.25
    if "10" in content and "position" in content:
        spec_score += 0.25
    scores["strategy_specs"] = spec_score

    # Check risk rules: take-profit and stop-loss
    risk_score = 0.0
    # Take-profit rule 1: >=5 positions and +0.1%
    if ("5" in content) and ("position" in content or "pos" in content) and ("profit" in content or "take" in content or "close" in content):
        risk_score += 0.33
    # Take-profit rule 2: 10 positions and average cost +0.1%
    if ("10" in content) and ("average" in content or "avg" in content) and ("cost" in content):
        risk_score += 0.33
    # Stop-loss: 1.0% drawdown
    if ("1.0%" in content or "1%" in content) and ("drawdown" in content or "stop" in content or "loss" in content):
        risk_score += 0.34
    scores["risk_rules"] = min(risk_score, 1.0)

    # Check validation plan: Bybit Testnet
    if "bybit" in content and ("testnet" in content or "test net" in content):
        scores["validation_plan"] = 1.0
    elif "bybit" in content and "test" in content:
        scores["validation_plan"] = 0.5

    # Check deliverables
    deliv_score = 0.0
    if "python" in content and ("code" in content or "script" in content):
        deliv_score += 0.25
    if "config" in content and ("template" in content):
        deliv_score += 0.25
    if "install" in content and ("script" in content or "guide" in content or "instruction" in content):
        deliv_score += 0.25
    if "test" in content and ("guide" in content or "instruction" in content or "document" in content):
        deliv_score += 0.25
    scores["deliverables"] = deliv_score

    # Check post-deployment monitoring
    if "monitor" in content:
        scores["monitoring"] = 1.0
    elif "post-deploy" in content or "post deploy" in content or "after deploy" in content:
        scores["monitoring"] = 0.5

    return scores
```

## LLM Judge Rubric

### Completeness of Saved Information (Weight: 35%)
- 1.0: All required elements are present: deadline, full strategy specs (candles, RSI, grid, positions, take-profit rules, stop-loss), validation plan, deliverables, and monitoring needs.
- 0.75: Most elements present but one minor detail is missing or vague (e.g., monitoring mentioned but not elaborated).
- 0.5: Several elements present but missing 2-3 key details (e.g., take-profit rules incomplete or stop-loss omitted).
- 0.25: Only a few elements captured; the note is a rough skeleton missing most specifics.
- 0.0: File not created or content is essentially empty/irrelevant.

### Accuracy and Precision of Strategy Details (Weight: 30%)
- 1.0: All numerical values and rules are exactly correct (0.1% grid, 10 max positions, ≥5 positions TP rule, 10 positions avg cost TP rule, 1.0% drawdown SL, 1-minute candles, RSI divergence).
- 0.75: All rules present with at most one minor numerical inaccuracy or ambiguity.
- 0.5: Core rules present but some values are wrong or imprecise (e.g., wrong percentage thresholds).
- 0.25: Strategy is mentioned but most specific values are missing or incorrect.
- 0.0: No strategy details provided.

### Organization and Readability (Weight: 20%)
- 1.0: Well-structured markdown with clear headings/sections, easy to scan and reference later. Logical grouping of deadline, strategy, validation, deliverables, and monitoring.
- 0.75: Reasonably organized with some structure, minor formatting issues.
- 0.5: Content is present but poorly organized — wall of text or confusing layout.
- 0.25: Minimal structure, hard to parse the information.
- 0.0: Unreadable or not in markdown format.

### Confirmation and Communication (Weight: 15%)
- 1.0: Agent clearly confirms the file was saved and provides a concise summary of what was included.
- 0.75: Agent confirms the save with a brief mention of contents.
- 0.5: Agent confirms the save but provides no summary.
- 0.25: Vague or unclear confirmation.
- 0.0: No confirmation provided to the user.
