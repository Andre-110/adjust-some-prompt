| 序号 | 修改项 | 修改原因 |
|------|--------|----------|
| 1 | Expected Behavior 第7条中 section headings 改为与 `section_headings.yaml` 一致的英文标题 | 原文混用了中文标题（`## 用户画像` 等）和英文标题，但 `section_headings.yaml` 和 `current_user_profile.md` 均使用英文标题。source_query 中的中文标题是原始 query 片段，不应出现在 Expected Behavior 的规范要求中。 |
| 2 | Grading Criteria 中补充对 `memory_update` 中 Ethiopian 咖啡偏好的检查项明确化 | 原 Grading Criteria 第13条已存在，但 grade() 函数中缺少对应检查，需在 grade() 中补充 |
| 3 | grade() 函数新增 `coffee_preference_ethiopian` 检查项 | 覆盖 Grading Criteria 中"light roast Ethiopian coffee preference"的检查 |
| 4 | grade() 函数新增 `headache_blue_light` 检查项 | 覆盖 Grading Criteria 中"screen-related headaches or blue-light glasses"的检查 |
| 5 | grade() 函数新增 `relationship_companion` 检查项 | 覆盖 Grading Criteria 中"treats AI as a companion/partner"的检查 |
| 6 | grade() 函数新增 `tech_stack_question_removed` 检查项 | 覆盖 Grading Criteria 中"pending_questions does NOT contain the tech stack question"的检查 |
| 7 | grade() 函数新增 `new_pending_question` 检查项 | 覆盖 Grading Criteria 中"pending_questions contains at least one new question"的检查 |
| 8 | grade() 函数新增 `correct_age_28` 检查项 | 覆盖 Grading Criteria 中"correct age 28"的检查 |
| 9 | grade() 函数新增 `cat_info_in_memory_update` 检查项 | 覆盖 Grading Criteria 中"memory_update contains information about the cat Pixel"的检查 |
| 10 | grade() 中 `resolved_pending_question_cat` 检查逻辑改进 | 原逻辑仅检查 "decided on a breed" 是否不存在，但 pending_questions 可能以其他措辞保留该问题。改为检查 parsed pending_questions 数组中是否不包含猫品种相关问题 |
| 11 | Prompt 微调：最后一句更自然 | 原文 "just output the JSON file, no markdown code fences wrapping it" 略显指令化，微调为更自然的表达 |
| 12 | Grading Criteria 新增"history_entry 为2-5句"的检查项 | 增加区分度，检查 history_entry 的长度是否在合理范围内 |
