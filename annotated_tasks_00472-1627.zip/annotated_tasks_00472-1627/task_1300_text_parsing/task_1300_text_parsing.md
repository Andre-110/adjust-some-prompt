---
id: task_1300_text_parsing
name: Parse Novel Chapter into Audiobook Emotion Script
category: Data Analysis
grading_type: automated
difficulty: hard
timeout_seconds: 600
workspace_files:
- source: task_1300_text_parsing/data/novel_chapter.txt
  dest: data/novel_chapter.txt
- source: task_1300_text_parsing/data/character_profiles.json
  dest: data/character_profiles.json
- source: task_1300_text_parsing/data/emotion_labels.json
  dest: data/emotion_labels.json
- source: task_1300_text_parsing/config/output_format_spec.yaml
  dest: config/output_format_spec.yaml
- source: task_1300_text_parsing/config/delay_guidelines.md
  dest: config/delay_guidelines.md
- source: task_1300_text_parsing/examples/sample_output.json
  dest: examples/sample_output.json
- source: task_1300_text_parsing/examples/old_script_v1.json
  dest: examples/old_script_v1.json
- source: task_1300_text_parsing/data/chapter_metadata.json
  dest: data/chapter_metadata.json
- source: task_1300_text_parsing/data/audio_settings.yaml
  dest: data/audio_settings.yaml
- source: task_1300_text_parsing/config/speaker_alias_map.json
  dest: config/speaker_alias_map.json
- source: task_1300_text_parsing/logs/previous_run.log
  dest: logs/previous_run.log
source_query: '将下面提供的小说文本逐句转换为"有声书情绪脚本"的纯JSON数组。


  硬性要求：

  1) 只输出JSON数组（禁止任何解释文字），输出必须以 [ 开头、以 ] 结尾。

  2) 数组中每个对象只能包含以下四个字段：speaker（说话者）、speaker_emo（情感标签）、content（文本内容）、delay（停顿毫秒整数）。

  3) 旁白行：speaker=旁白，speaker_emo=中性。

  4) 角色对话：speaker为说话人姓名；若原文出现【姓名-无】或【姓名】等标记，只表示说话人是"姓名"，该标记本身不得出现在content中，且【姓名-无】与【姓名】视为同一人。

  5) 路人/网友/观'
source_line_number: 1300
subcategory: Text Parsing
---
## Prompt

We're producing an audiobook for a Chinese web novel series and I need your help converting a raw chapter text into a structured emotion script that our TTS pipeline can consume. The source chapter is in `data/novel_chapter.txt`, and I've left a bunch of reference files around the workspace — output format spec in `config/output_format_spec.yaml`, delay guidelines in `config/delay_guidelines.md`, emotion label vocabulary in `data/emotion_labels.json`, and character profiles in `data/character_profiles.json`. There are also some example files from previous runs in the `examples/` folder, plus a speaker alias mapping in `config/`.

The core idea: go through the chapter line by line, identify who's speaking (or if it's narration), assign an appropriate emotion label from the allowed vocabulary, extract the clean dialogue/narration text, and set a delay value in milliseconds based on the punctuation and sentence type guidelines.

A few things to keep in mind:

- The novel uses speaker tags in the format `【name】` or `【name-无】` before dialogue. The `-无` suffix is just a voice style marker — it does NOT mean it's a different character. So `【林远-无】` and `【林远】` are the same person, 林远. Sometimes dialogue is attributed inline (like `苏晴说：`), so you'll need to catch those too.
- Narration lines (no speaker attribution) should use `旁白` as the speaker.
- Be careful with brackets that appear inside narration content — not every `【...】` is a speaker tag. If brackets appear mid-sentence as part of the prose, they're just text.
- The output must be a JSON array written to `output/audiobook_script.json`. Each element should have exactly four fields: `speaker`, `speaker_emo`, `content`, and `delay`. No extra fields, no wrapper object, just the array.
- Emotion labels must come from `data/emotion_labels.json` — all in Chinese.
- Delays are plain integers (milliseconds), not strings.
- Speaker tags must be stripped from the content field — the content should be clean text only.

I trust the format spec in `config/output_format_spec.yaml` and the delay guidelines in `config/delay_guidelines.md` as the authoritative references. Please produce the full script for every meaningful line in the chapter. Thanks!

## Expected Behavior

The agent must parse `data/novel_chapter.txt` line by line, producing a JSON array in `output/audiobook_script.json` where each entry has exactly four fields: `speaker` (string), `speaker_emo` (string from the allowed Chinese emotion labels), `content` (clean text with speaker tags removed), and `delay` (integer in milliseconds).

**Trap 1 — Sample Output with Wrong Format (`examples/sample_output.json`):**
This file uses `"narrator"` instead of `"旁白"` for narration lines, includes an extra `"volume"` field, and uses an English emotion label `"calm"`. The agent should recognize that `config/output_format_spec.yaml` is the authoritative spec and must use `"旁白"` for narration, include only 4 fields (no `volume`), and use only Chinese emotion labels from `data/emotion_labels.json`. The sample output should be disregarded where it conflicts with the spec.

**Trap 2 — Speaker Alias Map Contradicts Tag Resolution (`config/speaker_alias_map.json`):**
This file maps `"林远-无"` to `"林小远"`, suggesting it's a different character. This is wrong. The prompt and the format spec both clarify that `【name-无】` is the same person as `【name】`. Both `【林远-无】` and `【林远】` must resolve to speaker `"林远"`. The agent should not follow the alias map's incorrect mapping.

**Trap 3 — Old Script with Embedded Tags and String Delays (`examples/old_script_v1.json`):**
This file shows content fields that still contain raw `【name】` tags (e.g., `"【林远】你到底想怎样？"`) and uses delay values as strings like `"500ms"`. The agent must strip all speaker tags from the content field and use integer delay values (e.g., `500` not `"500ms"`), as specified in `config/output_format_spec.yaml`.

**Correct behavior summary:**
1. Read `data/novel_chapter.txt` and process each meaningful line (skip blank lines and chapter titles that are purely structural).
2. For lines with `【name】` or `【name-无】` tags at the start, extract the speaker name (stripping `-无` suffix), remove the tag from content.
3. For lines with inline attribution (e.g., `苏晴说：`), extract the speaker and the dialogue.
4. For narration lines, set speaker to `"旁白"` and speaker_emo to `"中性"`.
5. Assign `speaker_emo` using only labels from `data/emotion_labels.json`, informed by `data/character_profiles.json` and the emotional tone of the content.
6. Assign `delay` as an integer following `config/delay_guidelines.md` rules based on ending punctuation and sentence type.
7. Handle the edge case where `【旧照片】` appears inside a line attributed to 苏晴 — this inner bracket is NOT a speaker tag but part of the prose text and should be kept in the content.
8. Output a valid JSON array to `output/audiobook_script.json` with no extra fields.

## Grading Criteria

- [ ] Output file `output/audiobook_script.json` exists and is valid JSON containing an array of objects
- [ ] Every entry in the array has exactly four fields: `speaker`, `speaker_emo`, `content`, `delay` — no extra fields like `volume`
- [ ] Narration lines use speaker value `"旁白"` (not `"narrator"` or any English equivalent)
- [ ] Both `【林远-无】` and `【林远】` tagged lines resolve to speaker `"林远"` (not `"林小远"` or any other variant)
- [ ] All `speaker_emo` values are drawn from the allowed Chinese emotion labels in `data/emotion_labels.json` — no English labels
- [ ] All `delay` values are integers (not strings like `"500ms"`)
- [ ] Content fields do not contain raw speaker tags like `【林远】` or `【苏晴】` at the beginning — tags are stripped
- [ ] The embedded brackets `【旧照片】` appearing mid-sentence in a dialogue line are preserved as-is in the content field (not treated as a speaker tag)
- [ ] Lines from 路人甲 use speaker value `"路人甲"`, and lines from 网友A/网友B use speaker values `"网友A"` / `"网友B"`
- [ ] The output covers all dialogue and narration lines from the chapter (no significant lines omitted)
- [ ] All `delay` values fall within the valid range of 200–2000ms as specified in `config/delay_guidelines.md`

## Automated Checks

```python
import json
import os
import re
from pathlib import Path

def grade(transcript: list, workspace_path: str) -> dict:
    """Grade the audiobook_script.json output file."""
    
    result = {
        "output_file_exists": 0.0,
        "valid_json_array": 0.0,
        "no_volume_field": 0.0,
        "no_english_narrator": 0.0,
        "narrator_present": 0.0,
        "narrator_emotion_neutral": 0.0,
        "lin_yuan_correct_name": 0.0,
        "no_wrong_alias": 0.0,
        "no_raw_speaker_tags_in_content": 0.0,
        "has_four_required_fields": 0.0,
        "delay_is_integer": 0.0,
        "delay_in_range": 0.0,
        "passerby_prefix_correct": 0.0,
        "su_qing_present": 0.0,
    }
    
    output_file = Path(workspace_path) / "output" / "audiobook_script.json"
    
    # 1. output_file_exists
    if not output_file.is_file():
        return result
    result["output_file_exists"] = 1.0
    
    # Read file content
    try:
        raw_content = output_file.read_text(encoding="utf-8")
    except Exception:
        return result
    
    # Try to parse as JSON array
    try:
        data = json.loads(raw_content)
        assert isinstance(data, list)
    except Exception:
        # Not valid JSON or not an array — still check raw string for partial credit on other items
        data = None
    
    # 2. valid_json_array: Parses as a JSON array successfully
    if data is not None:
        result["valid_json_array"] = 1.0
    
    # For raw string checks, use the file content directly
    content = raw_content
    
    # 3. no_volume_field: Must NOT contain "volume" as a JSON field key
    if '"volume"' not in content.lower():
        result["no_volume_field"] = 1.0
    
    # 4. no_english_narrator: Must NOT use "narrator" as speaker value
    if not re.search(r'"speaker"\s*:\s*"narrator"', content, re.IGNORECASE):
        result["no_english_narrator"] = 1.0
    
    # 5. narrator_present: Output contains 旁白 as speaker for narration lines
    if re.search(r'"speaker"\s*:\s*"旁白"', content):
        result["narrator_present"] = 1.0
    
    # 6. narrator_emotion_neutral: 旁白 entries use 中性 as speaker_emo
    if re.search(r'"speaker_emo"\s*:\s*"中性"', content):
        result["narrator_emotion_neutral"] = 1.0
    
    # 7. lin_yuan_correct_name: Speaker is correctly 林远 (not 林小远)
    if re.search(r'"speaker"\s*:\s*"林远"', content):
        result["lin_yuan_correct_name"] = 1.0
    
    # 8. no_wrong_alias: Must NOT contain 林小远 as a speaker value
    if not re.search(r'"speaker"\s*:\s*"林小远"', content):
        result["no_wrong_alias"] = 1.0
    
    # 9. no_raw_speaker_tags_in_content: Content fields must not start with raw speaker tags.
    # Parse entries and check each content value for leading 【name】 or 【name-无】 patterns.
    if data is not None:
        tag_pattern = re.compile(r'^【[^】]+】')
        all_clean = True
        for entry in data:
            if isinstance(entry, dict):
                c = entry.get("content", "")
                if isinstance(c, str) and tag_pattern.match(c):
                    all_clean = False
                    break
        if all_clean:
            result["no_raw_speaker_tags_in_content"] = 1.0
    else:
        # Fallback: check raw string for the most common offending patterns
        forbidden = ['【林远-无】', '【林远】', '【苏晴】', '【路人甲】', '【网友A】', '【网友B】']
        # These may legitimately appear as speaker tag keys in raw JSON, so check if they
        # appear specifically inside a "content" value context
        if not re.search(r'"content"\s*:\s*"[^"]*【(?:林远|苏晴|路人甲|网友[AB])[^】]*】', content):
            result["no_raw_speaker_tags_in_content"] = 1.0
    
    # 10. has_four_required_fields: Each object has exactly the four required fields.
    # Check parsed objects rather than relying on a brittle regex.
    if data is not None:
        required_keys = {"speaker", "speaker_emo", "content", "delay"}
        all_correct = True
        checked = 0
        for entry in data:
            if isinstance(entry, dict):
                if set(entry.keys()) != required_keys:
                    all_correct = False
                    break
                checked += 1
        if all_correct and checked > 0:
            result["has_four_required_fields"] = 1.0
    
    # 11. delay_is_integer: All delay values are integers, not strings.
    if data is not None:
        all_int = all(
            isinstance(entry.get("delay"), int)
            for entry in data
            if isinstance(entry, dict)
        )
        if all_int and len(data) > 0:
            result["delay_is_integer"] = 1.0
    else:
        # Fallback raw check: forbidden pattern is "delay": " (string value)
        if not re.search(r'"delay"\s*:\s*"', content):
            result["delay_is_integer"] = 1.0
    
    # 12. delay_in_range: All delay values are within 200–2000ms
    if data is not None:
        delays = [entry.get("delay") for entry in data if isinstance(entry, dict)]
        if delays and all(isinstance(d, int) and 200 <= d <= 2000 for d in delays):
            result["delay_in_range"] = 1.0
    
    # 13. passerby_prefix_correct: 路人甲 and 网友A/B use correct speaker values
    # Check that 路人甲 entries exist with the right speaker and netizen entries appear correctly
    has_lurenJia = re.search(r'"speaker"\s*:\s*"路人甲"', content) is not None
    has_wangyou = (
        re.search(r'"speaker"\s*:\s*"网友A"', content) is not None and
        re.search(r'"speaker"\s*:\s*"网友B"', content) is not None
    )
    if has_lurenJia and has_wangyou:
        result["passerby_prefix_correct"] = 1.0
    
    # 14. su_qing_present: Character 苏晴 appears as a speaker
    if re.search(r'"speaker"\s*:\s*"苏晴"', content):
        result["su_qing_present"] = 1.0
    
    return result
```