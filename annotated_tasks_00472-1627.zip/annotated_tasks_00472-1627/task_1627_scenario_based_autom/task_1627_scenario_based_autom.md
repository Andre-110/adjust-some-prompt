---
id: task_1627_scenario_based_autom
name: Expert Workbench Implementation Plan for Engineering Operations Support Center
category: Automation
grading_type: hybrid
difficulty: hard
timeout_seconds: 720
input_modality: text-only
external_dependency: none
skill_creation: false
grading_weights:
  automated: 0.45
  llm_judge: 0.55
workspace_files:
- source: task_1627_scenario_based_autom/data/current_system_inventory.csv
  dest: data/current_system_inventory.csv
- source: task_1627_scenario_based_autom/data/expert_roster.csv
  dest: data/expert_roster.csv
- source: task_1627_scenario_based_autom/data/incident_log_2024.csv
  dest: data/incident_log_2024.csv
- source: task_1627_scenario_based_autom/config/project_charter_v2.yaml
  dest: config/project_charter_v2.yaml
- source: task_1627_scenario_based_autom/config/infrastructure_specs.json
  dest: config/infrastructure_specs.json
- source: task_1627_scenario_based_autom/docs/stakeholder_requirements.md
  dest: docs/stakeholder_requirements.md
- source: task_1627_scenario_based_autom/docs/ai_model_catalog.json
  dest: docs/ai_model_catalog.json
- source: task_1627_scenario_based_autom/data/budget_breakdown_v1.csv
  dest: data/budget_breakdown_v1.csv
- source: task_1627_scenario_based_autom/docs/competitor_analysis_2023.md
  dest: docs/competitor_analysis_2023.md
- source: task_1627_scenario_based_autom/config/data_classification_policy.yaml
  dest: config/data_classification_policy.yaml
- source: task_1627_scenario_based_autom/data/kpi_targets_2025.json
  dest: data/kpi_targets_2025.json
- source: task_1627_scenario_based_autom/logs/integration_test_results.log
  dest: logs/integration_test_results.log
- source: task_1627_scenario_based_autom/docs/org_chart_engineering.md
  dest: docs/org_chart_engineering.md
- source: task_1627_scenario_based_autom/config/api_gateway_config.yaml
  dest: config/api_gateway_config.yaml
source_query: 为"工程作业智能支持中心专家工作台"建设工作制定方案：给出目标与范围、核心功能模块、数据/模型/应用架构建议、实施里程碑、角色分工与风险清单
source_line_number: 1627
subcategory: Scenario Based Automation
---
## Prompt

We're about three weeks from our steering committee presentation for the Expert Workbench initiative — the intelligent support center platform for our engineering operations division. I've been pulled onto a parallel workstream and I need someone to synthesize all the project materials we've accumulated and produce a comprehensive implementation plan.

Everything you need is in the workspace: project charter, infrastructure specs, stakeholder requirements, the AI model catalog, incident data from 2024, our expert roster, system inventory, budget files, KPI targets, data classification policies, competitor analysis, API gateway config, and some integration test logs. There's a lot of material and I know some of these documents were created at different points in time, so please be careful about consistency — if you spot conflicts between documents, call them out explicitly and recommend which source should be treated as authoritative.

The deliverable I need is `deliverables/expert_workbench_plan.md` — a structured implementation plan that covers:

- **Executive Summary**: Project scope, objectives, and key parameters (budget, timeline, team size) grounded in the authoritative project documents
- **Current State Analysis**: Summarize our existing system landscape (what's active vs. deprecated, integration patterns), analyze the 2024 incident data for patterns in response/resolution times by severity and category, and characterize our expert pool (specialty distribution, availability, experience)
- **Technical Architecture**: Recommend an architecture for the workbench platform that accounts for our infrastructure specs, the AI model catalog, data classification requirements, and integration needs with existing systems. Flag any configuration issues you notice.
- **Resource & Budget Plan**: Present the budget with a clear breakdown, reconcile any discrepancies you find across documents, and map expert resources to project phases
- **Risk Register**: Identify at least 8 material risks based on your analysis — including data inconsistencies you've found, infrastructure gaps, staffing constraints, and compliance concerns
- **KPI Framework**: Tie the 2025 KPI targets back to specific platform capabilities and propose measurement approaches
- **Phased Roadmap**: A phase-by-phase plan aligned with the project charter's timeline, with key milestones and dependencies

Be thorough. The steering committee will have the same source documents, so anything that doesn't add up will get flagged. I'd rather we catch the inconsistencies ourselves first.

## Expected Behavior

The agent should systematically review all workspace files and produce a comprehensive implementation plan at `deliverables/expert_workbench_plan.md`. The correct solution requires:

### Data Synthesis
1. **System Inventory Analysis**: Parse `data/current_system_inventory.csv` (35 systems) and categorize by status (active/deprecated/planned) and integration type (API/batch/manual). Identify key systems like SCADA, ERP, MES, etc.
2. **Incident Analysis**: Analyze `data/incident_log_2024.csv` (200 records) to compute response/resolution time statistics by severity (P1-P4) and category. Note patterns in resolution methods (manual vs. auto).
3. **Expert Roster**: Analyze `data/expert_roster.csv` (48 experts) for specialty distribution, availability, experience levels, and location spread.
4. **Infrastructure**: Synthesize `config/infrastructure_specs.json` for current vs. planned capabilities.
5. **AI Models**: Reference `docs/ai_model_catalog.json` for the 12 models and their deployment readiness.
6. **Stakeholder Requirements**: Map REQ-001 through REQ-028 from `docs/stakeholder_requirements.md` to architecture components.
7. **KPI Targets**: Incorporate `data/kpi_targets_2025.json` into the KPI framework section.
8. **Data Policy**: Reference `config/data_classification_policy.yaml` for compliance and security architecture.

### Trap Handling (Critical)

**Trap 1 — Budget Discrepancy**: The agent must recognize that `config/project_charter_v2.yaml` specifies a total budget of 18,500,000 CNY while `data/budget_breakdown_v1.csv` line items sum to only 15,200,000 CNY. The charter (v2) is the authoritative source. The agent should explicitly flag this 3,300,000 CNY discrepancy and note that the budget breakdown is version v1 and needs updating. The plan should use 18.5M CNY as the correct total budget.

**Trap 2 — Timeline and Team Size Conflict**: `docs/competitor_analysis_2023.md` recommends a 12-month timeline and team of 15, but `config/project_charter_v2.yaml` specifies 18 months and 25 team members. The agent must use the charter's values (18 months, 25 people) and note that the 2023 competitor analysis contains outdated recommendations that have been superseded. The agent should NOT use GPT-3.5 or monolithic architecture recommendations from the competitor analysis.

**Trap 3 — API Rate Limit Inconsistency**: Within `config/api_gateway_config.yaml`, there is a contradictory rate limit specification — 1000/minute in one section vs. 1000/second in another for the expert-workbench endpoint. This is a 60x difference. The agent should flag this as a configuration risk that could cause either service denial (if too restrictive) or system overload (if too permissive), and recommend clarification before deployment.

### Document Quality
The output should be well-structured Markdown with clear sections, data-backed observations (actual numbers from the CSVs), and actionable recommendations. The risk register should include at least 8 risks, with the three data inconsistencies among them.

## Grading Criteria

- [ ] Output file exists at `deliverables/expert_workbench_plan.md` and is well-structured Markdown with all seven requested sections (Executive Summary, Current State Analysis, Technical Architecture, Resource & Budget Plan, Risk Register, KPI Framework, Phased Roadmap)
- [ ] Executive Summary correctly states the budget as 18,500,000 CNY (from the charter v2), timeline as 18 months, and team size as 25 — NOT the conflicting values from other documents
- [ ] Current State Analysis includes quantitative analysis of the system inventory (counts by status and integration type) with specific numbers from the CSV
- [ ] Current State Analysis includes statistical analysis of incident data (response/resolution times broken down by severity and/or category) with actual computed values from the 200 incident records
- [ ] Current State Analysis characterizes the expert roster with specialty distribution, availability ranges, and experience level breakdown
- [ ] Budget discrepancy between charter v2 (18.5M CNY) and budget breakdown v1 (15.2M CNY) is explicitly identified, the ~3.3M gap is noted, and the charter is treated as authoritative
- [ ] Timeline/team-size conflict between competitor analysis 2023 (12 months, 15 people) and charter v2 (18 months, 25 people) is explicitly identified, with the charter treated as authoritative and the competitor analysis noted as outdated
- [ ] API gateway rate limit inconsistency (1000/minute vs 1000/second within the same config file) is identified and flagged as a configuration risk
- [ ] Technical Architecture section references specific AI models from the catalog and addresses data classification/security requirements from the policy
- [ ] Risk Register contains at least 8 distinct risks, including the three document inconsistencies discovered during analysis
- [ ] Phased Roadmap aligns with the charter's 5-phase structure (requirements, design, development, testing, deployment) and 18-month timeline
- [ ] KPI Framework section references specific targets from kpi_targets_2025.json and maps them to platform capabilities

## Automated Checks

```python
import os
import re
from pathlib import Path

def grade(transcript: list, workspace_path: str) -> dict:
    """Grade the expert workbench plan output."""
    
    output_file = os.path.join(workspace_path, "deliverables", "expert_workbench_plan.md")
    
    # Initialize all scores to 0.0
    results = {
        "file_created": 0.0,
        "section_objectives_scope": 0.0,
        "section_core_modules": 0.0,
        "section_architecture": 0.0,
        "section_milestones": 0.0,
        "section_roles": 0.0,
        "section_risks": 0.0,
        "correct_budget_reference": 0.0,
        "correct_timeline_18_months": 0.0,
        "no_outdated_12month_timeline": 0.0,
        "flags_api_rate_limit_inconsistency": 0.0,
        "kpi_response_time_target": 0.0,
        "mentions_knowledge_graph_or_ai": 0.0,
        "data_security_mentioned": 0.0,
    }
    
    # Check if file exists
    if not os.path.isfile(output_file):
        return results
    
    results["file_created"] = 1.0
    
    # Read file content
    try:
        with open(output_file, "r", encoding="utf-8") as f:
            content = f.read()
    except Exception:
        return results
    
    if not content.strip():
        return results
    
    # --- Section checks (regex_match on headings) ---
    
    # section_objectives_scope: (?i)#.*(?:objective|goal|scope|target)
    if re.search(r'(?i)#.*(?:objective|goal|scope|target)', content):
        results["section_objectives_scope"] = 1.0
    
    # section_core_modules: (?i)#.*(?:core.*module|function.*module|key.*module|core.*function)
    if re.search(r'(?i)#.*(?:core.*module|function.*module|key.*module|core.*function)', content):
        results["section_core_modules"] = 1.0
    
    # section_architecture: (?i)#.*(?:architect|data.*model|technical.*design)
    if re.search(r'(?i)#.*(?:architect|data.*model|technical.*design)', content):
        results["section_architecture"] = 1.0
    
    # section_milestones: (?i)#.*(?:milestone|timeline|roadmap|implementation.*plan|phase)
    if re.search(r'(?i)#.*(?:milestone|timeline|roadmap|implementation.*plan|phase)', content):
        results["section_milestones"] = 1.0
    
    # section_roles: (?i)#.*(?:role|team|responsibilit|assignment|staffing)
    if re.search(r'(?i)#.*(?:role|team|responsibilit|assignment|staffing)', content):
        results["section_roles"] = 1.0
    
    # section_risks: (?i)#.*(?:risk|challenge|mitigation)
    if re.search(r'(?i)#.*(?:risk|challenge|mitigation)', content):
        results["section_risks"] = 1.0
    
    # --- Content checks ---
    
    # correct_budget_reference: The plan should reference the correct budget of 18.5M CNY.
    # Accept various formats: 18500000, 18,500,000, 18.5M, 1850万, etc.
    budget_found = False
    if re.search(r'18[,.]?500[,.]?000', content):
        budget_found = True
    if re.search(r'18\.5\s*[Mm]', content):
        budget_found = True
    if re.search(r'1850\s*万', content):
        budget_found = True
    if budget_found:
        results["correct_budget_reference"] = 1.0
    
    # correct_timeline_18_months: The plan should mention 18 months as the timeline.
    if re.search(r'\b18\b', content):
        results["correct_timeline_18_months"] = 1.0
    
    # no_outdated_12month_timeline: Check that 12 months is NOT adopted as the project timeline.
    # A correct plan may reference "12-month timeline" when explicitly criticising/superseding it.
    # We penalise only if 12 months appears to be adopted positively (e.g. "12-month project",
    # "timeline of 12 months", "plan for 12 months") without a superseding/outdated qualifier nearby.
    content_lower = content.lower()
    adopted_12month = bool(re.search(
        r'(?i)(project.*12.month|12.month.*project|timeline.*12.month(?!.*supersed|.*outdat|.*competi)|'
        r'plan.*12.month(?!.*supersed|.*outdat|.*competi)|adopt.*12.month|use.*12.month)',
        content
    ))
    if not adopted_12month:
        results["no_outdated_12month_timeline"] = 1.0
    
    # flags_api_rate_limit_inconsistency: Grading Criteria #8 — agent must flag the
    # contradictory rate limit in api_gateway_config.yaml (1000/min vs 1000/sec).
    if re.search(r'(?i)(per.?second.*per.?minute|per.?minute.*per.?second|'
                 r'rate.?limit.*inconsist|inconsist.*rate.?limit|'
                 r'1000.*second.*1000.*minute|1000.*minute.*1000.*second|'
                 r'60.?x\s+differ|60\s+times|sessions.*rate.?limit|'
                 r'api.?gateway.*config.*conflict|rate.?limit.*conflict)', content):
        results["flags_api_rate_limit_inconsistency"] = 1.0
    
    # kpi_response_time_target: The plan should mention the P1 response time target of 15 minutes.
    if re.search(r'\b15\b', content):
        results["kpi_response_time_target"] = 1.0
    
    # mentions_knowledge_graph_or_ai: regex_match
    if re.search(r'(?i)(knowledge.*graph|anomaly.*detect|NLP|natural.*language|large.*language.*model|LLM|AI.*model)', content):
        results["mentions_knowledge_graph_or_ai"] = 1.0
    
    # data_security_mentioned: regex_match
    if re.search(r'(?i)(data.*classif|data.*secur|encrypt|access.*control|RBAC|confidential)', content):
        results["data_security_mentioned"] = 1.0
    
    return results
```

## LLM Judge Rubric

### Criterion 1: Trap Detection and Conflict Resolution Quality (Weight: 40%)
**Score 1.0**: The plan explicitly identifies and thoroughly discusses all three traps: (1) the budget discrepancy between charter v2 (18.5M CNY) and budget CSV v1 (15.2M CNY) with the exact 3.3M CNY gap quantified and a clear recommendation that the charter is authoritative and the CSV needs updating; (2) the timeline/team size conflict between the 2023 competitor analysis (12 months/15 people) and the charter v2 (18 months/25 people), with explicit reasoning for why the charter supersedes the older document; (3) the API rate limit inconsistency (1000/minute vs. 1000/second) within the gateway config, with a clear call-out of the 60x difference and a recommendation for which value to adopt. Each conflict is presented with source attribution, version awareness, and actionable resolution guidance.
**Score 0.75**: The plan explicitly identifies and resolves at least two of the three traps with proper source attribution and quantified discrepancies. The third trap may be mentioned but without sufficient detail (e.g., noting a rate limit issue without quantifying the 60x difference), or may be absent entirely. Reasoning for authoritative source selection is generally sound.
**Score 0.5**: The plan identifies at least one trap with clear quantification and resolution, and may vaguely allude to one other conflict without fully articulating the discrepancy or providing a clear recommendation. Some conflicts are resolved implicitly (e.g., using the correct budget figure without explaining why the CSV differs) rather than explicitly called out.
**Score 0.25**: The plan uses some correct values (suggesting partial awareness of conflicts) but does not explicitly flag any discrepancies or explain the reasoning behind source selection. No dedicated conflict analysis is present; the agent appears to have silently chosen values without transparency.
**Score 0.0**: The plan shows no awareness of any data conflicts. It may adopt incorrect or inconsistent values from different sources without question, or it fabricates figures not found in any source document.

### Criterion 2: Analytical Depth and Data-Grounded Reasoning (Weight: 35%)
**Score 1.0**: The plan demonstrates deep, evidence-based analysis across all major data sources: incident data is analyzed with specific statistics (e.g., mean/median response and resolution times broken down by severity and category, resolution method patterns); the expert roster is characterized with concrete numbers on specialty distribution, availability rates, experience levels, and geographic spread; the system inventory is categorized with specific counts by status and integration type; AI models are assessed for deployment readiness with specifics from the catalog; stakeholder requirements are mapped to architecture components with traceability (e.g., REQ-XXX references). All quantitative claims are plausible and traceable to workspace files rather than hallucinated.
**Score 0.75**: The plan provides substantive analysis for most data sources with specific numbers and breakdowns, but one or two areas lack depth (e.g., incident analysis gives averages but no category breakdown, or expert roster is summarized without availability analysis). Claims are generally data-grounded with only minor gaps in traceability.
**Score 0.5**: The plan references most workspace files and provides some quantitative analysis, but the depth is uneven — some sections have specific data while others rely on generic or vague statements. There may be one or two instances where figures seem estimated rather than derived from actual data, or key analytical dimensions (e.g., resolution method patterns, expert availability) are omitted.
**Score 0.25**: The plan mentions data sources superficially but provides little meaningful analysis. Quantitative claims are sparse, generic, or appear fabricated. Most sections read as templated content rather than synthesis of actual project materials.
**Score 0.0**: The plan contains no meaningful data analysis. It reads as a generic implementation plan template with no evidence of having processed the workspace files. Numbers, if present, appear entirely hallucinated.

### Criterion 3: Professional Coherence, Completeness, and Strategic Value (Weight: 25%)
**Score 1.0**: The plan reads as a polished, steering-committee-ready document with logical flow between sections, consistent terminology, and clear narrative threading from current state through gap analysis to implementation strategy. Cross-references between sections are coherent (e.g., risks identified in analysis feed into the risk section, KPI targets align with identified gaps, architecture addresses stated requirements). The plan demonstrates strategic thinking — not just listing facts but synthesizing them into actionable recommendations with clear rationale. The document is well-organized with appropriate use of headers, tables, or structured formatting.
**Score 0.75**: The plan is well-structured and mostly coherent, with good logical flow between most sections. There are minor inconsistencies in cross-referencing or occasional gaps in strategic reasoning, but the overall document would be presentable to a steering committee with minor edits.
**Score 0.5**: The plan covers the required topics but reads more as a collection of separate sections than a cohesive document. Some logical connections between sections are missing (e.g., risks don't clearly map to earlier analysis, or architecture doesn't clearly address identified requirements). The writing is adequate but lacks strategic polish.
**Score 0.25**: The plan has significant structural or logical issues — sections may contradict each other, the flow is disjointed, or major gaps exist in the narrative. It would require substantial rework before being presentable to leadership.
**Score 0.0**: The plan is incoherent, severely incomplete, or structured so poorly that it fails to serve as a useful implementation planning document.