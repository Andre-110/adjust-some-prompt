| 序号 | 修改项 | 修改原因 |
|------|--------|----------|
| 1 | 更新 `workspace_files` 字段为实际文件列表 | 原为空列表 `[]`，与实际 Assets 目录不一致 |
| 2 | 修改 Prompt，引导 Agent 参考 workspace 中的规则文件和用户数据 | 原 Prompt 完全未提及 Assets 文件，Agent 不知道该参考已有规则 |
| 3 | 修正 Expected Behavior 中的折扣规则示例，使其与 Assets 文件一致 | 原文中的购买金额阈值（≥200/0.5%, ≥500/1%, ≥1000/2%）与 `discount_rules.json`（≥1000/2%, ≥3000/5%）不匹配；原文提到 "diamond" 级别但 Assets 中不存在 |
| 4 | Expected Behavior 增加关于 max discount cap 和 inactive user 的说明 | Assets 中有明确的 25% 上限和 inactive 不享受折扣的规则，Expected Behavior 未提及 |
| 5 | Expected Behavior 增加 Ground Truth 示例 | 原文缺少可验证的具体答案 |
| 6 | 添加 `grading_weights` 和 LLM Judge Rubric 部分 | 原任务文件缺少此部分 |
| 7 | `grading_type` 保留为 `automated`，添加 grading_weights 为 automated=1.0, llmjudge=0.0 | Easy 级别题目，automated checks 已覆盖充分 |