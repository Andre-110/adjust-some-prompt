---
id: task_00491_user_discount_calculator
name: User Discount Calculator
category: Data Analysis and Modeling
subcategory: Statistical Analysis and Modeling
difficulty: easy
grading_type: automated
grading_weights:
  automated: 1.0
  llmjudge: 0.0
timeout_seconds: 600
input_modality: text-only
external_dependency: none
workspace_files:
  - path: data/discount_rules.json
    role: input
    description: JSON file containing tier discount percentages, loyalty bonus rules, spending bonus thresholds, and maximum discount cap.
  - path: data/users.csv
    role: input
    description: CSV file with user records including membership tier, signup date, total spent, order count, and active status.
  - path: data/product_catalog.csv
    role: input
    description: CSV file with product listings including prices and categories.
  - path: config/promotion_schedule.json
    role: context
    description: JSON file with promotional campaigns and coupon codes (not required for core discount calculation).
  - path: docs/discount_policy.md
    role: context
    description: Internal policy document describing the discount rules in human-readable form.
skill_creation: false
---

## Prompt

I have some data files in my workspace that describe our discount rules and user base. Check out `data/discount_rules.json` for the tier-based discounts, loyalty bonus, and spending bonus rules, and `data/users.csv` for the user list. There's also a policy doc in `docs/discount_policy.md` if you need more context.

Write a Python program that calculates user discounts based on these rules — it should factor in membership level, cumulative spending, and how long someone has been a member. Make sure to handle the max discount cap and the rule that inactive users get no discount. Save it as `discount_calculator.py`.

## Expected Behavior

The agent should examine the workspace files (especially `data/discount_rules.json` and `docs/discount_policy.md`) to understand the discount rules, then create a file called `discount_calculator.py` that implements a discount calculation system with the following characteristics:

1. **Membership tier discounts**: The code should define the four membership tiers from the rules file — bronze (0%), silver (5%), gold (10%), platinum (15%) — with corresponding base discount percentages.

2. **Spending bonus thresholds**: Additional discounts should be applied based on cumulative spending: ≥$1,000 adds 2%, ≥$3,000 adds 5%. The highest qualifying threshold applies (they do not stack).

3. **Loyalty (membership duration) bonus**: Users who have been members for 2 or more years receive an additional 3% discount.

4. **Maximum discount cap**: The combined discount must not exceed 25%.

5. **Inactive user handling** (trap): Users with `is_active=False` in `data/users.csv` should receive 0% discount regardless of their tier, spending, or tenure. The agent should notice the `inactive_user_eligible: false` rule in the JSON and the eligibility section in the policy doc.

6. **The code should be syntactically valid Python** that can be executed without errors.

7. **The code should contain a function or class** that encapsulates the discount calculation logic, making it reusable.

8. The agent should also demonstrate or test the code by running it successfully.

**Ground Truth examples** (based on `data/users.csv` evaluated as of 2025-07-01):

- **USR-0005 (Mona Lee)**: gold (10%) + loyalty bonus (signup 2022-10-09, ~2.7 years → +3%) + spending bonus ($4,045.28 → +5%) = 18% discount.
- **USR-0020 (Hank Taylor)**: platinum (15%) + loyalty bonus (signup 2022-11-12, ~2.6 years → +3%) + spending bonus ($2,218.60 → +2%) = 20% discount.
- **USR-0010 (Karen Wilson)**: inactive user → 0% discount (despite being gold tier with $1,375.32 spent).
- **USR-0008 (Frank King)**: bronze (0%) + no loyalty bonus (signup 2022-11-09, ~2.6 years → +3%) + spending bonus ($3,524.01 → +5%) = 8% discount.

## Grading Criteria

- [ ] File `discount_calculator.py` exists in the workspace
- [ ] The file contains valid Python code (parseable by `ast.parse`)
- [ ] The code implements membership level / tier-based discounts
- [ ] The code implements purchase amount-based discount thresholds
- [ ] The code implements membership duration-based discount bonuses
- [ ] The code defines at least one function or class for discount calculation

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    import os
    import ast
    import re

    scores = {
        "file_exists": 0.0,
        "valid_python": 0.0,
        "membership_tiers": 0.0,
        "purchase_amount_thresholds": 0.0,
        "membership_duration": 0.0,
        "has_function_or_class": 0.0,
    }

    file_path = os.path.join(workspace_path, "discount_calculator.py")

    # Check if file exists
    if not os.path.isfile(file_path):
        return scores

    scores["file_exists"] = 1.0

    try:
        with open(file_path, "r", encoding="utf-8") as f:
            content = f.read()
    except Exception:
        return scores

    # Check valid Python
    try:
        tree = ast.parse(content)
        scores["valid_python"] = 1.0
    except SyntaxError:
        return scores

    content_lower = content.lower()

    # Check membership tier-based discounts
    # Look for keywords related to membership levels
    tier_keywords = ["silver", "gold", "platinum", "diamond", "vip", "bronze",
                     "regular", "normal", "member", "level", "tier", "grade"]
    tier_matches = sum(1 for kw in tier_keywords if kw in content_lower)
    if tier_matches >= 2:
        scores["membership_tiers"] = 1.0
    elif tier_matches >= 1:
        scores["membership_tiers"] = 0.5

    # Check purchase amount thresholds
    # Look for numeric comparisons that suggest amount-based tiers
    amount_keywords = ["amount", "purchase", "spend", "total", "price", "order",
                       "spent", "spending"]
    amount_patterns = re.findall(r'>=?\s*\d{2,}', content)
    amount_keyword_matches = sum(1 for kw in amount_keywords if kw in content_lower)
    if amount_keyword_matches >= 1 and len(amount_patterns) >= 2:
        scores["purchase_amount_thresholds"] = 1.0
    elif amount_keyword_matches >= 1 or len(amount_patterns) >= 2:
        scores["purchase_amount_thresholds"] = 0.5

    # Check membership duration bonus
    duration_keywords = ["year", "duration", "tenure", "seniority", "loyalty",
                         "membership_year", "member_year", "join", "age",
                         "signup", "sign_up"]
    duration_matches = sum(1 for kw in duration_keywords if kw in content_lower)
    if duration_matches >= 1:
        scores["membership_duration"] = 1.0

    # Check for function or class definition
    has_func = False
    has_class = False
    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef) or isinstance(node, ast.AsyncFunctionDef):
            has_func = True
        if isinstance(node, ast.ClassDef):
            has_class = True
    if has_func or has_class:
        scores["has_function_or_class"] = 1.0

    return scores
```

## LLM Judge Rubric

Not applicable. This task uses fully automated grading (automated weight = 1.0).