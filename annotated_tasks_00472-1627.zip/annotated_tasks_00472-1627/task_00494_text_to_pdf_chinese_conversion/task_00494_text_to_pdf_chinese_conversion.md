---
id: task_00494_text_to_pdf_chinese_conversion
name: Convert Chinese Text to PDF File
category: Data Processing and Management
subcategory: File Format Conversion
difficulty: easy
grading_type: automated
timeout_seconds: 600
input_modality: text-only
external_dependency: none
workspace_files:
  - path: config/dingtalk_channel.yaml
    role: context
    description: DingTalk channel configuration for message delivery
  - path: data/chat_history.json
    role: input
    description: Chat history containing the original Chinese message to convert
  - path: data/cron_jobs_log.json
    role: context
    description: Scheduled reminder jobs log
  - path: data/message_content.txt
    role: input
    description: Plain text file containing the Chinese message to convert
  - path: templates/pdf_styles.css
    role: context
    description: CSS style template for PDF generation
skill_creation: false
---

## Prompt

帮我把 `data/message_content.txt` 里面的那条中文消息转成 PDF 文件发给我。

## Expected Behavior

The agent should:

1. Read the text content from `data/message_content.txt` (which contains "可以在4点32分钟时提醒我写报告吗？"). It may also cross-reference `data/chat_history.json` to understand the context.
2. Handle the challenge of rendering Chinese characters in a PDF, which typically requires a CJK-compatible font (e.g., Noto Sans SC, WenQuanYi, or similar). The agent needs to obtain or locate such a font.
3. Optionally use the `templates/pdf_styles.css` stylesheet for formatting.
4. Use an appropriate tool or library (e.g., reportlab/fpdf with Python, pdfkit, or an HTML-to-PDF approach) to generate the PDF.
5. Produce a valid PDF file in the workspace that contains the Chinese text "可以在4点32分钟时提醒我写报告吗？".
6. Attempt to deliver/send the PDF to the user (e.g., by indicating the file path, using a message tool, or referencing the DingTalk channel config in `config/dingtalk_channel.yaml`).

The key deliverable is a valid PDF file somewhere in the workspace that contains the specified Chinese text.

## Grading Criteria

- [ ] A PDF file exists in the workspace
- [ ] The PDF file has a valid PDF header (starts with %PDF)
- [ ] The PDF file has non-trivial size (more than 1KB, indicating actual content)
- [ ] A CJK font file was obtained or is present in the workspace to support Chinese rendering
- [ ] The agent attempted to send/deliver the PDF to the user

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    import os
    import glob

    scores = {
        "pdf_file_exists": 0.0,
        "pdf_valid_header": 0.0,
        "pdf_nontrivial_size": 0.0,
        "cjk_font_present": 0.0,
        "delivery_attempted": 0.0,
    }

    # Find any PDF file in the workspace
    pdf_files = glob.glob(os.path.join(workspace_path, "**", "*.pdf"), recursive=True)

    if pdf_files:
        scores["pdf_file_exists"] = 1.0

        # Check the first PDF found for valid header and size
        pdf_path = pdf_files[0]
        try:
            file_size = os.path.getsize(pdf_path)
            # Check non-trivial size (> 1KB suggests real content)
            if file_size > 1024:
                scores["pdf_nontrivial_size"] = 1.0
            elif file_size > 100:
                scores["pdf_nontrivial_size"] = 0.5

            # Check valid PDF header
            with open(pdf_path, "rb") as f:
                header = f.read(5)
                if header == b"%PDF-":
                    scores["pdf_valid_header"] = 1.0
        except Exception:
            pass

    # Check if a CJK font file is present (TTF/OTF files with CJK-related names)
    font_files = glob.glob(os.path.join(workspace_path, "**", "*.ttf"), recursive=True)
    font_files += glob.glob(os.path.join(workspace_path, "**", "*.otf"), recursive=True)

    cjk_keywords = ["noto", "cjk", "sc", "tc", "chinese", "wenquanyi", "simsun",
                     "simhei", "songti", "heiti", "fang", "yahei", "mingti", "kai"]
    for font_file in font_files:
        basename = os.path.basename(font_file).lower()
        for keyword in cjk_keywords:
            if keyword in basename:
                scores["cjk_font_present"] = 1.0
                break
        if scores["cjk_font_present"] == 1.0:
            break

    # Check if the agent attempted to deliver/send the PDF via transcript
    for event in transcript:
        if event.get("type") != "message":
            continue
        msg = event.get("message", {})
        if msg.get("role") == "assistant":
            content = str(msg.get("content", "")).lower()
            # Check for mention of sending/delivering/file path
            if any(term in content for term in ["send", "deliver", "message",
                    "file path", "download", "attached", "dingtalk", "ding",
                    "here is", "generated", "created", "saved"]):
                scores["delivery_attempted"] = 1.0
                break
        # Also check for tool calls that indicate sending
        tool_calls = msg.get("tool_calls", [])
        if isinstance(tool_calls, list):
            for tc in tool_calls:
                func_name = ""
                if isinstance(tc, dict):
                    func = tc.get("function", {})
                    if isinstance(func, dict):
                        func_name = func.get("name", "")
                if any(kw in func_name.lower() for kw in ["message", "send", "deliver", "announce"]):
                    scores["delivery_attempted"] = 1.0
                    break

    return scores
```