| 序号 | 修改项 | 修改原因 |
|------|--------|----------|
| 1 | Expected Behavior — Event study description | 原文称 "a slight but detectable pre-trend violation at t-1"，但 `analysis_config.yaml` 中 `reference_period: -1` 意味着 t-1 是被省略的参考期，其系数不存在（机械性为零）。修改为说明 t-1 为省略的参考期，t-4 至 t-2 的系数应近似为零，post-treatment 系数应为正。 |
| 2 | Grading Criteria — ATT range | 原文 grading criteria 中 ATT 合理范围写为 10–20，与 grade() 函数中的 10–22 不一致。统一为 10–20（在 grading criteria 和 grade() 函数中均改为 10–20）。 |
| 3 | grade() 函数 — att_estimate_range 数值范围 | 将 `if 10.0 <= val <= 22.0` 改为 `if 10.0 <= val <= 20.0`，与 grading criteria 保持一致。 |
| 4 | grade() 函数 — did_coefficient_section regex | 原 regex 仅匹配 "regression results" 标题，过于严格。扩展为匹配包含 "regression"、"result"、"estimation"、"did"、"main finding"、"coefficient" 等关键词的标题，提高对合理变体的容忍度。 |
| 5 | grade() 函数 — rejects_wrong_policy_year 检查 | 原检查仅精确匹配 "policy was implemented in 2018" 一个短语。扩展为多个模式匹配（如 "post=1 for year>=2018"、"treatment began in 2018" 等），提高对各种表述方式的检测能力。 |
| 6 | grade() 函数 — correct_policy_year 评分 | 当 "2017" 仅出现在文本中但没有明确的 policy 上下文时，从给满分 1.0 改为给 0.5 分，以区分明确将 2017 标记为 policy year 与仅提及 2017 年份的情况。 |