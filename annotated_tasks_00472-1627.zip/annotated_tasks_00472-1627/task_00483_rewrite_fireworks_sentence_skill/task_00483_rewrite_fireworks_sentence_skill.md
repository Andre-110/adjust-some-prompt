---
id: task_00483_rewrite_fireworks_sentence_skill
name: Rewrite Fireworks Sentence with New Year Atmosphere Skill
category: Communication and Scheduling
subcategory: Message and Email Communication
difficulty: easy
grading_type: hybrid
grading_weights: {automated: 0.4, llm_judge: 0.6}
timeout_seconds: 600
input_modality: text-only
external_dependency: none
skill_creation: true
workspace_files:
  - path: "05 creative-writing/drafts/20260223_fire_dept_spring_festival_article/fire_dept_spring_festival_article.md"
    content: |
      # Silent Guardians of Quanzhou: Firefighters on Duty During the Spring Festival

      > When thousands of families gather under warm lights, they stand watch in the cold night — the silent guardians of a peaceful New Year.

      ## Opening: The Eve of the Lunar New Year

      The ancient city of Quanzhou comes alive during the Spring Festival. Red lanterns hang from the eaves of centuries-old buildings along West Street, and the aroma of braised pork drifts from every doorway. Families bustle about, children clutch new red envelopes, and the city hums with anticipation.

      But for Station 7 of the Quanzhou City Fire Rescue Brigade, the festive season means something different: heightened vigilance, longer shifts, and the quiet knowledge that danger does not take holidays.

      ## Chapter 1: Preparations Before the Countdown

      In the week leading up to New Year's Eve, Captain Lin Jianfeng led his team through a rigorous round of inspections. Ancient temples packed with incense, shopping districts overflowing with holiday crowds, and residential buildings draped in decorations — each site was catalogued, risk-assessed, and mapped. "We checked 43 locations in three days," Lin recalled. Every piece of equipment was tested. Hoses uncoiled and pressurized. Breathing apparatus inspected valve by valve. The aerial ladder truck positioned strategically near the Kaiyuan Temple district, where crowds would be densest.

      ## Chapter 2: The Countdown

      By 11 PM on New Year's Eve, West Street was a river of people — locals and tourists shoulder to shoulder, phone screens glowing, voices rising with excitement. Street vendors sold tangyuan and grilled oysters. Children perched on their parents' shoulders, eyes wide with wonder.

      At Station 7, the firefighters watched the scene unfold on a wall of monitors. Every camera feed was live. Every radio channel open. Dispatcher Huang Meiling announced: "Three minutes to midnight." The team stood ready — full gear, engines running, adrenaline held in check by training and discipline.

      The clock struck twelve.

      In that instant, fireworks burst across the sky above the ancient city of Quanzhou, and the crowds on West Street gradually dispersed amid waves of cheering.

      But for the firefighters, the night was just beginning.

      ## Chapter 3: The First Call

      At 12:47 AM, the alarm rang. A residential fire on Zhongshan Road — an unattended incense burner had toppled onto a stack of paper offerings. Smoke was already visible from two blocks away.

      Engine 7-1 rolled out in under 90 seconds. Through streets still thick with revelers, sirens cutting through the celebration noise, they reached the scene in four minutes.

      "Flames were confined to one room on the second floor," said firefighter Chen Wei, the first through the door. "But the building is over a hundred years old — all wood. Another five minutes and the whole block could have gone."

      The fire was suppressed in eleven minutes. No casualties. One elderly resident treated for minor smoke inhalation. The family's cat was found hiding behind the water tank on the roof, unharmed.

      ## Chapter 4: Through the Night

      Between midnight and 6 AM, Station 7 responded to seven calls:

      | Time  | Location              | Incident Type         | Resolution         |
      |-------|-----------------------|-----------------------|--------------------|
      | 00:47 | Zhongshan Road        | Residential fire      | Suppressed, 11 min |
      | 01:15 | Kaiyuan Temple area   | Crowd crush risk      | Assisted police    |
      | 02:03 | Fengze District       | Vehicle fire          | Suppressed, 8 min  |
      | 02:41 | West Street           | False alarm           | Cleared            |
      | 03:30 | Luojiang overpass     | Traffic accident      | Extraction, 22 min |
      | 04:55 | Industrial zone east  | Chemical leak (minor) | Contained, 35 min  |
      | 05:20 | Residential compound  | Elevator entrapment   | Rescued, 15 min    |

      "New Year's Eve is always our busiest night," said Captain Lin. "People are happy, but happiness makes people careless."

      ## Chapter 5: Morning Light

      As dawn broke over Quanzhou, the exhausted crew finally sat down for their own New Year meal — reheated dumplings, leftover rice, and a thermos of tea that had gone cold hours ago.

      Firefighter Zhang Xiaomei, 24, the youngest on the team, stared at a photo on her phone — her family gathered around a table in Fuzhou, 200 kilometers away. "My mom sent this at midnight," she said quietly. "I told her I'd be home for Lantern Festival. Maybe."

      Captain Lin raised his paper cup. "To another safe year." "To another safe year," they echoed.

      ## Closing

      Every Spring Festival, over 200,000 firefighters across China remain on duty. They miss the family reunions, the midnight toasts, the warmth of home. They stand instead in smoke-filled rooms, on rain-slicked highways, in the bitter cold of pre-dawn hours.

      The ancient city of Quanzhou will celebrate again next year. The lanterns will glow, the crowds will gather, and the incense will burn. And Station 7 will be there — silent, ready, watching.

      ---

      *Published by the Quanzhou City Fire Rescue Brigade Public Affairs Office*
      *Photography: Wang Hao, Zhang Lei*
      *Editor: Li Qian*
      *February 2026*
---

## Prompt

Hey, I need a reusable skill for rewriting sentences to comply with local regulations while preserving the original mood and imagery. Create it as a SKILL.md file in the workspace root — think of it like a mini writing-assistant capability, inspired by skills like "call-deepseek-v3-llm" or "actual-budget" but focused on creative text rewriting under constraints.

Then use that skill to do the following: In the file `05 creative-writing/drafts/20260223_fire_dept_spring_festival_article/fire_dept_spring_festival_article.md`, find the sentence "In that instant, fireworks burst across the sky above the ancient city of Quanzhou, and the crowds on West Street gradually dispersed amid waves of cheering." and rewrite it so that it no longer references setting off fireworks in the urban area, but still keeps the New Year's Eve atmosphere and vivid visual imagery. Update the file in place with your rewritten version.

## Expected Behavior

1. The agent should create a `SKILL.md` file in the workspace root with proper YAML frontmatter (including `name` and `description` fields) and markdown instruction sections describing a reusable text-rewriting capability — similar in structure to existing OpenClaw skills like "call-deepseek-v3-llm" or "actual-budget".
2. The agent should then read the markdown article file at `05 creative-writing/drafts/20260223_fire_dept_spring_festival_article/fire_dept_spring_festival_article.md`.
3. The agent should identify the target sentence: "In that instant, fireworks burst across the sky above the ancient city of Quanzhou, and the crowds on West Street gradually dispersed amid waves of cheering." and rewrite it to remove any mention of fireworks being set off in the urban area.
4. The rewritten sentence should preserve the New Year's Eve celebratory atmosphere and maintain vivid, descriptive imagery (e.g., using lights, lanterns, bells, cheers, or other festive elements).
5. The agent should update the file in place with the new sentence, leaving the rest of the article intact.
6. The agent may also provide alternative rewrite options in the transcript.

## Grading Criteria

- [ ] SKILL.md file exists with proper YAML frontmatter (name and description fields)
- [ ] SKILL.md contains meaningful instruction sections for text rewriting
- [ ] The article file was modified (original fireworks sentence is no longer present verbatim)
- [ ] The rewritten sentence does not mention fireworks in the urban area
- [ ] The rewritten sentence preserves New Year's Eve atmosphere and vivid imagery
- [ ] The rest of the article remains intact

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    import os
    from pathlib import Path

    scores = {
        "skill_md_exists": 0.0,
        "skill_md_structure": 0.0,
        "article_modified": 0.0,
        "fireworks_removed": 0.0,
        "article_integrity": 0.0,
    }

    workspace = Path(workspace_path)

    # Check 1: SKILL.md exists
    skill_path = workspace / "SKILL.md"
    if not skill_path.exists():
        # Also check common variations
        for candidate in ["skill.md", "Skill.md"]:
            p = workspace / candidate
            if p.exists():
                skill_path = p
                break

    if skill_path.exists():
        scores["skill_md_exists"] = 1.0
        skill_content = skill_path.read_text(encoding="utf-8", errors="replace")

        # Check 2: SKILL.md has proper structure (YAML frontmatter with name and description)
        has_frontmatter = skill_content.strip().startswith("---")
        has_name = False
        has_description = False
        if skill_content.count("---") >= 2:
            frontmatter_block = skill_content.split("---")[1].lower()
            has_name = "name:" in frontmatter_block
            has_description = "description:" in frontmatter_block
        has_sections = skill_content.count("#") >= 1  # At least one markdown heading

        structure_score = 0.0
        if has_frontmatter:
            structure_score += 0.25
        if has_name:
            structure_score += 0.25
        if has_description:
            structure_score += 0.25
        if has_sections:
            structure_score += 0.25
        scores["skill_md_structure"] = structure_score

    # Check 3-5: Article file
    article_path = workspace / "05 creative-writing" / "drafts" / "20260223_fire_dept_spring_festival_article" / "fire_dept_spring_festival_article.md"

    if article_path.exists():
        article_content = article_path.read_text(encoding="utf-8", errors="replace")

        original_sentence = "In that instant, fireworks burst across the sky above the ancient city of Quanzhou, and the crowds on West Street gradually dispersed amid waves of cheering."

        # Check 3: Article was modified (original sentence no longer present verbatim)
        if original_sentence not in article_content:
            scores["article_modified"] = 1.0

        # Check 4: Fireworks reference removed
        content_lower = article_content.lower()
        fireworks_phrases = [
            "fireworks burst across",
            "fireworks bloomed",
            "fireworks over the ancient city",
            "fireworks lit up",
            "fireworks exploded",
            "fireworks launched",
            "setting off fireworks",
        ]
        fireworks_found = any(phrase in content_lower for phrase in fireworks_phrases)
        if not fireworks_found and scores["article_modified"] == 1.0:
            scores["fireworks_removed"] = 1.0

        # Check 5: Rest of article intact
        key_phrases = [
            "Silent Guardians of Quanzhou",
            "The ancient city of Quanzhou comes alive",
            "Captain Lin Jianfeng",
            "the firefighters, the night was just beginning",
            "dawn broke over Quanzhou",
            "Quanzhou City Fire Rescue Brigade Public Affairs Office",
        ]
        intact_count = sum(1 for phrase in key_phrases if phrase.lower() in content_lower)
        scores["article_integrity"] = intact_count / len(key_phrases)

    return scores
```

## LLM Judge Rubric

### Skill File Quality (Weight: 20%)
- 1.0: SKILL.md is well-structured with YAML frontmatter (name, description), clear instruction sections, and describes a genuinely reusable text-rewriting capability
- 0.75: SKILL.md exists with frontmatter and some useful content but is somewhat generic or lacks detail
- 0.5: SKILL.md exists but is minimal or missing key structural elements
- 0.25: SKILL.md exists but is essentially a stub with little useful content
- 0.0: No SKILL.md created

### Rewrite Quality - Regulation Compliance (Weight: 25%)
- 1.0: The rewritten sentence completely removes any reference to setting off fireworks in the urban area
- 0.75: Fireworks are mentioned only in a distant/non-urban context (e.g., fireworks seen from afar)
- 0.5: Fireworks are still somewhat implied but softened
- 0.25: Fireworks are still clearly referenced but with minor wording changes
- 0.0: The original fireworks sentence is unchanged

### Rewrite Quality - Atmosphere and Imagery (Weight: 35%)
- 1.0: The rewritten sentence vividly captures New Year's Eve celebration atmosphere with strong visual imagery (lights, lanterns, bells, cheers, etc.) and reads naturally
- 0.75: Good atmosphere and imagery preserved, reads well but slightly less vivid than the original
- 0.5: Some festive atmosphere retained but imagery is generic or flat
- 0.25: Minimal festive feeling; the sentence is bland or overly plain
- 0.0: No festive atmosphere or imagery; the sentence is unrelated or missing

### Article Integrity (Weight: 20%)
- 1.0: Only the target sentence was changed; all other content in the article remains intact and properly formatted
- 0.75: Minor unintended changes to surrounding text but article is mostly intact
- 0.5: Some paragraphs were altered or rearranged unnecessarily
- 0.25: Significant portions of the article were changed or removed
- 0.0: The article is missing, empty, or completely rewritten