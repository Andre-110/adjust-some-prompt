---
id: task_00472_delete_scary_directory
name: Delete Directory Named Scary
category: System Administration
subcategory: Storage and Data Management
difficulty: easy
grading_type: hybrid
grading_weights: {automated: 0.4, llm_judge: 0.6}
timeout_seconds: 600
input_modality: text-only
external_dependency: none
workspace_files:
  - path: scary/notes.txt
    content: |
      Halloween party planning notes
      - Venue: Old warehouse on 5th street
      - Date: October 31
      - Budget: $500
      - Theme: Haunted house
  - path: scary/props.csv
    content: |
      item,quantity,cost
      fake_spider,20,1.50
      fog_machine,2,45.00
      skeleton,3,12.99
      cobwebs,10,2.00
      jack_o_lantern,8,5.50
      bloody_hand,6,3.25
  - path: scary/soundtrack.json
    content: |
      {
        "playlist": "Halloween Ambience",
        "tracks": [
          {"title": "Creaking Door", "duration": "3:12"},
          {"title": "Thunder Storm", "duration": "5:45"},
          {"title": "Wolf Howl", "duration": "1:08"},
          {"title": "Ghostly Whispers", "duration": "4:30"}
        ]
      }
  - path: friendly/hello.txt
    content: |
      This is a friendly directory. Do not delete me!
  - path: readme.txt
    content: |
      This workspace has a few directories and files for testing.
  - path: creepy/stories.md
    content: |
      # Campfire Stories Collection

      ## The Vanishing Hitchhiker
      A driver picks up a hitchhiker on a dark road, only to find the back seat empty when they arrive...

      ## The Hook
      A couple parked at lovers' lane hears a news bulletin about an escaped convict with a hook hand...
  - path: spooky/playlist.txt
    content: |
      Spooky Season Playlist 2024
      1. Thriller - Michael Jackson
      2. Ghostbusters - Ray Parker Jr.
      3. Monster Mash - Bobby Pickett
      4. Somebody's Watching Me - Rockwell
skill_creation: false
---
```

## Prompt

Delete the directory named "scary"

## Expected Behavior

The agent should:

1. Locate the directory named `scary` in the workspace.
2. Recognize that the directory contains files (`notes.txt`, `props.csv`, `soundtrack.json`).
3. Delete the `scary` directory and all of its contents (recursively).
4. Leave all other files and directories in the workspace intact — including `friendly/`, `creepy/`, `spooky/`, and `readme.txt`.
5. Ideally confirm or communicate the deletion to the user.

**Key point:** The workspace contains several directories with thematically similar names (`creepy/`, `spooky/`). The agent must delete **only** the directory literally named `scary` and not confuse it with the others.

The agent may ask for confirmation before performing the deletion, which is acceptable and even good practice, but should ultimately carry out the deletion when confirmed.

## Grading Criteria

- [ ] The `scary` directory no longer exists
- [ ] The files inside `scary/` (`notes.txt`, `props.csv`, `soundtrack.json`) no longer exist
- [ ] Other workspace files (`friendly/hello.txt`, `readme.txt`, `creepy/stories.md`, `spooky/playlist.txt`) are preserved
- [ ] The agent communicated the result or acknowledged the deletion

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    import os
    from pathlib import Path

    ws = Path(workspace_path)
    scores = {}

    # 1. Check that the scary directory no longer exists
    scary_dir = ws / "scary"
    scores["scary_directory_removed"] = 0.0 if scary_dir.exists() else 1.0

    # 2. Check that individual files inside scary/ are gone
    scary_files = ["scary/notes.txt", "scary/props.csv", "scary/soundtrack.json"]
    files_removed = 0
    for f in scary_files:
        if not (ws / f).exists():
            files_removed += 1
    scores["scary_files_removed"] = files_removed / len(scary_files)

    # 3. Check that other files are preserved
    preserved_files = [
        "friendly/hello.txt",
        "readme.txt",
        "creepy/stories.md",
        "spooky/playlist.txt",
    ]
    preserved_count = 0
    for f in preserved_files:
        if (ws / f).exists():
            preserved_count += 1
    scores["other_files_preserved"] = preserved_count / len(preserved_files)

    # 4. Check transcript for acknowledgment of the deletion
    acknowledged = 0.0
    for event in transcript:
        if event.get("type") != "message":
            continue
        msg = event.get("message", {})
        if msg.get("role") == "assistant":
            content = str(msg.get("content", "")).lower()
            if any(kw in content for kw in ["delet", "remov", "gone", "success", "done", "confirm"]):
                acknowledged = 1.0
                break
    scores["deletion_acknowledged"] = acknowledged

    return scores
```

## LLM Judge Rubric

### Directory Deletion Correctness (Weight: 40%)
- 1.0: The `scary` directory and all its contents are fully removed.
- 0.75: The `scary` directory is removed but one file may have been missed or a minor artifact remains.
- 0.5: The agent attempted deletion but the directory or some files still remain.
- 0.25: The agent identified the directory but did not successfully delete it.
- 0.0: The agent did not attempt to delete the directory at all.

### Preservation of Other Files (Weight: 25%)
- 1.0: All other files and directories in the workspace (`friendly/`, `creepy/`, `spooky/`, `readme.txt`) are completely untouched.
- 0.75: Nearly all other files preserved; one minor unrelated change occurred.
- 0.5: Some other files were accidentally modified or deleted (e.g., the agent also deleted `creepy/` or `spooky/` due to thematic similarity).
- 0.25: Multiple other files or directories were affected by the operation.
- 0.0: The agent deleted or damaged significant portions of the workspace beyond `scary/`.

### Communication and Safety (Weight: 20%)
- 1.0: The agent clearly communicated what it was doing, confirmed the deletion, and/or asked for user confirmation before proceeding — showing good safety awareness.
- 0.75: The agent communicated the action but did not ask for confirmation or explain the consequences.
- 0.5: The agent provided minimal communication about the deletion.
- 0.25: The agent performed the action silently with almost no explanation.
- 0.0: The agent provided no communication or gave misleading information.

### Approach and Method (Weight: 15%)
- 1.0: The agent used an appropriate and safe method (e.g., `rm -r`, `rmdir` after clearing, or a language-native recursive delete), and verified the result.
- 0.75: The agent used a reasonable method but did not verify the result.
- 0.5: The agent used a workable but suboptimal method.
- 0.25: The agent used a risky or incorrect approach that partially worked.
- 0.0: The agent used an inappropriate or dangerous method, or did not attempt the task.