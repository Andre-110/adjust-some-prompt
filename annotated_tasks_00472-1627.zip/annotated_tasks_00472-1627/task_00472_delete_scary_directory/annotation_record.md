| 序号 | 修改项 | 修改原因 |
|------|--------|----------|
| 1 | **workspace_files 中 scary/notes.txt 的 content** 与 Assets 实际文件内容不一致 | YAML 中是"spooky notes / Beware of the dark"，Assets 中是"Halloween party planning notes"。统一为 Assets 版本（更真实） |
| 2 | **workspace_files 中 scary/props.csv 的 content** 与 Assets 实际文件内容不一致 | YAML 中列名为 `name,type,quantity`，Assets 中列名为 `item,quantity,cost`，数据行也完全不同。统一为 Assets 版本 |
| 3 | **workspace_files 中 scary/soundtrack.json 的 content** 与 Assets 实际文件内容不一致 | YAML 中 key 为 `"tracks"` 含 2 条，Assets 中有 `"playlist"` key 含 4 条 track、duration 格式不同。统一为 Assets 版本 |
| 4 | **workspace_files 缺少 Assets 中实际存在的文件**：`creepy/stories.md`、`spooky/playlist.txt` | Assets 目录中有这两个文件但 workspace_files 未列出，导致不一致。将其补入 workspace_files |
| 5 | **workspace_files 中有 `friendly/hello.txt` 和 `readme.txt`**，但 Assets 目录中缺失 | YAML 中定义了这两个文件但 Assets 目录未提供。将其补入 Assets |
| 6 | **Grading Criteria 及 grade() 中 preserved_files 列表** 需更新 | 实际 workspace 中除 `friendly/hello.txt` 和 `readme.txt` 外，还有 `creepy/stories.md` 和 `spooky/playlist.txt` 需要保留。更新检查列表 |
| 7 | **Expected Behavior** 需更新 | 需反映实际 workspace 中的所有目录/文件，包括 `creepy/`、`spooky/` 等 |
| 8 | **grade() 中 scary_files 的检查** 列名 `props.csv` 的列名不影响存在性检查，无需改动，但保留以确认一致性 | — |