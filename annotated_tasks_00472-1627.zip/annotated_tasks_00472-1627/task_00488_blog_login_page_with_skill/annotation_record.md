| 序号 | 修改项 | 修改原因 |
|------|--------|----------|
| 1 | 更新 frontmatter 中 `workspace_files` 列表，添加全部 4 个 Assets 文件 | `workspace_files` 为空列表，但实际提供了 4 个环境文件，需保持一致 |
| 2 | 修改 Prompt，提及 workspace 中已有的项目文件（配置、主题变量等），让 Agent 知道这是已有项目的一部分 | Prompt 完全未提及 workspace 中的 Assets 文件，Agent 不知道这些文件存在，Assets 就成了无用的装饰 |
| 3 | 更新 Expected Behavior，增加关于利用已有 Assets 文件的说明 | Expected Behavior 应说明 Agent 可以（可选地）参考 blog-config.json 中的验证规则和 theme-variables.css 中的设计令牌 |
| 4 | 修正 Prompt 中登录页面路径，从 `~/Desktop/login/` 改为 workspace 内的 `login/` 目录 | README.md 中项目结构已列出 `login/` 在项目根目录下，且 grade() 函数已支持 `ws / "login"` 路径。使用 `~/Desktop/login/` 与项目结构不一致，且在评测环境中 Desktop 路径可能不可靠 |
| 5 | 更新 Grading Criteria 条目 2 的描述，与路径修改保持一致 | 路径改为 workspace 内 `login/` 后，Grading Criteria 描述也需同步 |