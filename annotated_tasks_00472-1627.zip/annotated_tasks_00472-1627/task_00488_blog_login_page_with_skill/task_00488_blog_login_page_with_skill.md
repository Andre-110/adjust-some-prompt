---
id: task_00488_blog_login_page_with_skill
name: Blog Login Page Creation with Skill
category: Workflow and Agent Orchestration
subcategory: Script and Terminal Automation
difficulty: easy
grading_type: automated
timeout_seconds: 600
input_modality: text-only
external_dependency: none
workspace_files:
  - path: blog-config.json
    role: context
    description: Blog site configuration including authentication settings (password rules, session timeout, lockout policy)
  - path: README.md
    role: context
    description: Project README describing the blog's structure, tech stack, and current status
  - path: theme-variables.css
    role: context
    description: CSS custom properties / design tokens for the blog's theme (colors, typography, spacing, shadows)
  - path: users.csv
    role: context
    description: Exported user accounts table for reference (usernames, roles, status)
skill_creation: true
---

## Prompt

Hey, I'm building a blog called DevNotes and I've already got some project files set up in the workspace — there's a `blog-config.json` with site and auth settings, a `theme-variables.css` with design tokens, a `users.csv` with existing accounts, and a `README.md` describing the project structure.

I need a reusable skill for scaffolding simple web page projects — something that knows how to create a folder structure with HTML, CSS, and JS files for common UI pages. Create it as a SKILL.md file in the workspace, inspired by skills like feishu-sheets or amazon-shopper that encapsulate a repeatable capability.

Then, use that skill to build me a blog login page. Create a folder called `login` in the workspace root and put these files inside:

- `index.html` — the login page structure with username and password fields
- `style.css` — nice styling for the login form
- `script.js` — form validation and login interaction logic (empty field checks, minimum length, password show/hide toggle, etc.)

Feel free to reference `blog-config.json` for password rules and `theme-variables.css` for design tokens if it helps. Make it look decent — dark theme or glassmorphism style would be cool. Thanks!

## Expected Behavior

The agent should:

1. **Create a SKILL.md** file in the workspace root that describes a reusable "web page scaffolding" skill. It should have YAML frontmatter with `name` and `description` fields, plus markdown sections with instructions on how to scaffold web UI projects (similar in spirit to existing skills like feishu-sheets or amazon-shopper that encapsulate domain capabilities).

2. **Create the directory** `login/` in the workspace root.

3. **Create `index.html`** inside the login folder containing a proper HTML document with a login form that includes username/email and password input fields, a submit button, and references to the CSS and JS files.

4. **Create `style.css`** inside the login folder with styling for the login form (dark theme or glassmorphism style preferred, but any reasonable styling is acceptable). Optionally, the agent may reference CSS custom properties from `theme-variables.css` for consistency with the blog's existing design system.

5. **Create `script.js`** inside the login folder with form validation logic — at minimum: empty field detection, and ideally password visibility toggle and minimum length checks. Optionally, the agent may reference `blog-config.json` for validation parameters (e.g., `passwordMinLength: 8`, `requireSpecialChar: true`), but hardcoded reasonable defaults are also acceptable.

6. The agent should recognize the existing workspace files as project context and produce output that fits naturally into the DevNotes blog project structure described in README.md.

## Grading Criteria

- [ ] SKILL.md exists with proper YAML frontmatter (name and description)
- [ ] login/ directory exists in the workspace
- [ ] index.html exists and contains a login form with input fields
- [ ] style.css exists and contains CSS rules
- [ ] script.js exists and contains validation logic
- [ ] index.html references both style.css and script.js

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    import os
    import re
    from pathlib import Path

    scores = {
        "skill_md_exists_and_valid": 0.0,
        "login_directory_exists": 0.0,
        "index_html_valid": 0.0,
        "style_css_valid": 0.0,
        "script_js_valid": 0.0,
        "html_references_assets": 0.0,
    }

    ws = Path(workspace_path)

    # 1. Check SKILL.md exists and has proper frontmatter
    skill_path = ws / "SKILL.md"
    if skill_path.exists():
        content = skill_path.read_text(errors="replace")
        has_frontmatter = content.strip().startswith("---")
        has_name = bool(re.search(r'(?i)name\s*:', content))
        has_description = bool(re.search(r'(?i)description\s*:', content))
        # Check for some instructional content beyond frontmatter
        has_body = len(content.strip()) > 100
        if has_frontmatter and has_name and has_description and has_body:
            scores["skill_md_exists_and_valid"] = 1.0
        elif has_frontmatter and (has_name or has_description):
            scores["skill_md_exists_and_valid"] = 0.5
        elif has_body:
            scores["skill_md_exists_and_valid"] = 0.25

    # Determine login folder path — check both workspace-relative and ~/Desktop/login
    login_candidates = [
        ws / "login",
        ws / "Desktop" / "login",
        Path.home() / "Desktop" / "login",
    ]
    login_dir = None
    for candidate in login_candidates:
        if candidate.is_dir():
            login_dir = candidate
            break

    # 2. Check login directory exists
    if login_dir is not None:
        scores["login_directory_exists"] = 1.0
    else:
        # No directory found; remaining checks will stay 0.0
        return scores

    # 3. Check index.html
    index_path = login_dir / "index.html"
    if index_path.exists():
        html_content = index_path.read_text(errors="replace").lower()
        has_form = "<form" in html_content or "<input" in html_content
        has_password_field = 'type="password"' in html_content or "type='password'" in html_content
        has_text_or_email = ('type="text"' in html_content or 'type="email"' in html_content
                            or "type='text'" in html_content or "type='email'" in html_content)
        has_button = "<button" in html_content or 'type="submit"' in html_content or "type='submit'" in html_content

        if has_form and has_password_field and (has_text_or_email or has_button):
            scores["index_html_valid"] = 1.0
        elif has_form and has_password_field:
            scores["index_html_valid"] = 0.75
        elif has_form:
            scores["index_html_valid"] = 0.5
        else:
            scores["index_html_valid"] = 0.25

    # 4. Check style.css
    css_path = login_dir / "style.css"
    if css_path.exists():
        css_content = css_path.read_text(errors="replace")
        # Check for meaningful CSS — at least some selectors and properties
        has_selectors = bool(re.search(r'[.#a-zA-Z][\w-]*\s*\{', css_content))
        has_properties = bool(re.search(r'(color|background|font|margin|padding|display|border|width|height)\s*:', css_content, re.IGNORECASE))
        line_count = len([l for l in css_content.strip().splitlines() if l.strip()])

        if has_selectors and has_properties and line_count >= 10:
            scores["style_css_valid"] = 1.0
        elif has_selectors and has_properties:
            scores["style_css_valid"] = 0.75
        elif has_selectors or has_properties:
            scores["style_css_valid"] = 0.5
        else:
            scores["style_css_valid"] = 0.25

    # 5. Check script.js
    js_path = login_dir / "script.js"
    if js_path.exists():
        js_content = js_path.read_text(errors="replace")
        # Check for validation-related patterns
        has_event_listener = bool(re.search(r'(addEventListener|onclick|onsubmit|\.on\()', js_content))
        has_validation = bool(re.search(r'(\.value|\.trim\(\)|\.length|required|validate|empty|alert|innerText|textContent|innerHTML)', js_content, re.IGNORECASE))
        has_query_selector = bool(re.search(r'(getElementById|querySelector|getElementsBy|document\.)', js_content))
        has_password_toggle = bool(re.search(r'(password|toggle|show|hide|visibility|eye)', js_content, re.IGNORECASE))

        count = sum([has_event_listener, has_validation, has_query_selector, has_password_toggle])
        if count >= 3:
            scores["script_js_valid"] = 1.0
        elif count == 2:
            scores["script_js_valid"] = 0.75
        elif count == 1:
            scores["script_js_valid"] = 0.5
        else:
            # File exists but minimal content
            scores["script_js_valid"] = 0.25

    # 6. Check that index.html references both style.css and script.js
    if index_path.exists():
        html_content = index_path.read_text(errors="replace").lower()
        refs_css = "style.css" in html_content
        refs_js = "script.js" in html_content
        if refs_css and refs_js:
            scores["html_references_assets"] = 1.0
        elif refs_css or refs_js:
            scores["html_references_assets"] = 0.5

    return scores
```