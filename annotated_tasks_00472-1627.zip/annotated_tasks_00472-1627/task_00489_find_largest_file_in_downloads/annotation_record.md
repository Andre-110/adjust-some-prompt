| 序号 | 修改项 | 修改原因 |
|------|--------|----------|
| 1 | 重写 `workspace_files` YAML 字段 | 原 workspace_files 列出了 5 个不存在的文件（report_2024.pdf, photo_vacation.jpg, project_backup.tar.gz, notes.txt, presentation.pptx），实际 Assets 目录包含 9 个完全不同的文件。修改为与实际 Assets 一致的文件列表。 |
| 2 | 移除 `content_size` 字段，改用 `role` 字段 | 原 content_size 值（如 15728640）与实际文件不匹配，且无法确保实际部署后的文件大小严格等于这些值。改为让 grade() 动态检测实际最大文件。 |
| 3 | 修改 Prompt | 原 Prompt "Find the name of the largest file in the Downloads directory." 过于考试化。改为更自然的用户请求："I have a bunch of files in my Downloads folder. Can you check which one is the biggest?" |
| 4 | 修改 Expected Behavior | 原 Expected Behavior 声称 project_backup.tar.gz 是最大文件（~15MB），但该文件不存在于 Assets 中。修改为描述实际 Assets 中的最大文件 annual_sales_report_2024.csv。 |
| 5 | 修改 grade() 函数：增加动态最大文件检测 | 原 grade() 硬编码检查 "project_backup.tar.gz"。新版本先动态扫描 downloads 目录找到实际最大文件，再与 agent 输出比对，增强了鲁棒性。 |
| 6 | 修改 grade() 函数：增加格式容忍 | 原 grade() 仅精确匹配文件名。新版本增加了下划线替换为空格的匹配、stem 匹配等容错逻辑。 |
| 7 | 新增 LLM Judge Rubric | 原任务文件缺少 LLM Judge Rubric 部分。新增包含 3 个评分维度（File Discovery 30%、Correct Identification 40%、Communication Quality 30%），权重之和 100%，并设置 automated:0.6 + llmjudge:0.4 = 1.0。 |
| 8 | 目录名大小写修正 | 原 workspace_files 使用 `Downloads/`（大写 D），实际 Assets 目录为 `downloads/`（小写 d）。统一为小写以匹配实际 Assets。 |