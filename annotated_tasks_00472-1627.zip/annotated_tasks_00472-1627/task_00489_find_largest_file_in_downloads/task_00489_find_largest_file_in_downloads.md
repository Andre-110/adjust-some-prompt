---
id: task_00489_find_largest_file_in_downloads
name: Find Largest File in Downloads Directory
category: System Administration
subcategory: Storage and Data Management
difficulty: easy
grading_type: automated
timeout_seconds: 600
input_modality: text-only
external_dependency: none
workspace_files:
  - path: downloads/annual_sales_report_2024.csv
    role: data
  - path: downloads/app_config.yaml
    role: data
  - path: downloads/backup.sh
    role: data
  - path: downloads/meeting_notes_Q4.pdf
    role: data
  - path: downloads/old_photos_archive.zip
    role: data
  - path: downloads/product_catalog_api_response.json
    role: data
  - path: downloads/README_setup.txt
    role: data
  - path: downloads/screenshot_2024-11-20.png
    role: data
  - path: downloads/server_access.log
    role: data
skill_creation: false
---

## Prompt

I have a bunch of files in my Downloads folder. Can you check which one is the biggest?

## Expected Behavior

The agent should:

1. Look for a `downloads` directory in the workspace.
2. List the files in that directory and determine their sizes (e.g., using `ls -lS`, `du`, `stat`, or similar commands).
3. Identify the largest file by size. In the prepared environment, `annual_sales_report_2024.csv` is the largest file (a CSV with hundreds of transaction records).
4. Report the filename of the largest file to the user clearly.

If the downloads directory does not exist, the agent should clearly communicate that to the user and ask for clarification, rather than silently failing.

## Grading Criteria

- [ ] Agent looked for or listed files in the downloads directory
- [ ] Agent correctly identified the largest file name (`annual_sales_report_2024.csv`)
- [ ] Agent communicated the result clearly in the transcript
- [ ] Agent handled the scenario gracefully (no crashes, clear communication)

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    import os
    from pathlib import Path

    scores = {
        "checked_downloads_dir": 0.0,
        "identified_largest_file": 0.0,
        "clear_communication": 0.0,
        "graceful_handling": 0.0,
    }

    # Collect all assistant messages from transcript
    assistant_texts = []
    all_tool_calls = []
    for event in transcript:
        if event.get("type") != "message":
            continue
        msg = event.get("message", {})
        if msg.get("role") == "assistant":
            content = msg.get("content", "")
            if isinstance(content, str):
                assistant_texts.append(content.lower())
            elif isinstance(content, list):
                for block in content:
                    if isinstance(block, dict):
                        if block.get("type") == "text":
                            assistant_texts.append(block.get("text", "").lower())
                        elif block.get("type") == "tool_use":
                            tool_input = block.get("input", {})
                            cmd = ""
                            if isinstance(tool_input, dict):
                                cmd = str(tool_input.get("command", "")) + str(tool_input.get("cmd", ""))
                            all_tool_calls.append(cmd.lower())

    combined_text = " ".join(assistant_texts)
    combined_tools = " ".join(all_tool_calls)

    # Dynamically determine the actual largest file in the downloads directory
    downloads_dir = os.path.join(workspace_path, "downloads")
    actual_largest = None
    if os.path.isdir(downloads_dir):
        max_size = -1
        for fname in os.listdir(downloads_dir):
            fpath = os.path.join(downloads_dir, fname)
            if os.path.isfile(fpath):
                fsize = os.path.getsize(fpath)
                if fsize > max_size:
                    max_size = fsize
                    actual_largest = fname

    # Fallback if directory not found
    if actual_largest is None:
        actual_largest = "annual_sales_report_2024.csv"

    # 1. Check if agent looked for / listed files in downloads directory
    downloads_keywords = ["downloads", "download"]
    ls_keywords = ["ls ", "find ", "du ", "stat ", "wc ", "ls\n"]
    checked_dir = False
    for kw in downloads_keywords:
        if kw in combined_text or kw in combined_tools:
            checked_dir = True
            break
    if checked_dir:
        scores["checked_downloads_dir"] = 1.0
    if not checked_dir:
        if "no download" in combined_text or "not found" in combined_text or "does not exist" in combined_text or "doesn't exist" in combined_text:
            scores["checked_downloads_dir"] = 0.5

    # 2. Check if agent identified the largest file correctly
    largest_lower = actual_largest.lower()
    largest_stem = os.path.splitext(actual_largest)[0].lower().replace("_", " ")
    if largest_lower in combined_text:
        scores["identified_largest_file"] = 1.0
    elif largest_lower.replace("_", " ") in combined_text:
        scores["identified_largest_file"] = 1.0
    elif actual_largest.lower().split(".")[0] in combined_text:
        scores["identified_largest_file"] = 0.75
    else:
        # Check if agent at least attempted to sort/find largest
        sort_keywords = ["sort", "largest", "biggest", "max", "most"]
        for kw in sort_keywords:
            if kw in combined_text or kw in combined_tools:
                scores["identified_largest_file"] = 0.25
                break

    # 3. Check for clear communication of the result
    communication_phrases = ["largest file", "biggest file", "the largest", "the biggest", "maximum size", "most space", "largest one"]
    for phrase in communication_phrases:
        if phrase in combined_text:
            scores["clear_communication"] = 1.0
            break
    if scores["clear_communication"] == 0.0:
        clarification_phrases = ["which directory", "specific path", "tell me", "where is", "could you", "can you tell"]
        for phrase in clarification_phrases:
            if phrase in combined_text:
                scores["clear_communication"] = 0.5
                break

    # 4. Graceful handling - no errors, agent didn't crash, provided some response
    if len(assistant_texts) > 0:
        scores["graceful_handling"] = 1.0
    error_keywords = ["traceback", "error:", "exception", "permission denied"]
    for kw in error_keywords:
        if kw in combined_text:
            scores["graceful_handling"] = max(scores["graceful_handling"] - 0.5, 0.0)

    return scores
```

## LLM Judge Rubric

### Dimensions

#### 1. File Discovery (Weight: 30%)
- **1.0**: Agent navigated to the downloads directory and listed all files with their sizes using appropriate commands.
- **0.75**: Agent listed files in the downloads directory but did not show sizes for all files.
- **0.5**: Agent found the downloads directory but only partially explored its contents.
- **0.25**: Agent attempted to look for files but used an incorrect path or method.
- **0.0**: Agent did not attempt to explore the downloads directory at all.

#### 2. Correct Identification (Weight: 40%)
- **1.0**: Agent correctly identified the largest file by name and reported its size.
- **0.75**: Agent correctly identified the largest file by name but did not report the exact size.
- **0.5**: Agent identified a file as largest but got the wrong file.
- **0.25**: Agent attempted to compare file sizes but did not reach a conclusion.
- **0.0**: Agent did not attempt to determine which file is largest.

#### 3. Communication Quality (Weight: 30%)
- **1.0**: Agent clearly stated which file is largest, its size, and presented the information in an easy-to-understand way.
- **0.75**: Agent stated the largest file name clearly but presentation could be improved.
- **0.5**: Agent provided the answer but it was buried in verbose output or unclear.
- **0.25**: Agent provided some information but the answer was ambiguous.
- **0.0**: Agent did not communicate any result to the user.

### Grading Weights
- automated: 0.6
- llmjudge: 0.4
```