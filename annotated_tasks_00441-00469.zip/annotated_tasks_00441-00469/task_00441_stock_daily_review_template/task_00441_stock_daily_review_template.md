---
id: task_00441_stock_daily_review_template
name: Stock Daily Review Template Generation
category: Finance and Quantitative Trading
subcategory: Trade Execution and Management
difficulty: easy
grading_type: hybrid
grading_weights: {automated: 0.4, llm_judge: 0.6}
timeout_seconds: 600
input_modality: text-only
external_dependency: none
workspace_files: []
skill_creation: false
---

## Prompt

Generate a stock daily review template as a table/document that includes sections for: market overview (major indices), industry/sector analysis, individual stock review, and trading insights/notes. Save the generated file to the /root/clawfile directory.

## Expected Behavior

The agent should:

1. Create the `/root/clawfile` directory (or a `clawfile` directory in the workspace if `/root` is not writable).
2. Generate a template file (Markdown, Excel, CSV, or similar) that contains clearly delineated sections for:
   - **Market Overview**: A section covering major market indices (e.g., Shanghai Composite, Shenzhen Component, ChiNext, or equivalent), market sentiment indicators such as number of stocks hitting daily limit up/down, trading volume, etc.
   - **Industry/Sector Analysis**: A section for reviewing performance of different industries or thematic sectors/plates.
   - **Individual Stock Review**: A section for reviewing specific stocks held or watched, including fields like stock name/code, entry/exit prices, profit/loss, and notes.
   - **Trading Insights/Notes**: A section for recording personal reflections, lessons learned, and strategy adjustments.
3. The template should be well-structured with clear headings and table formatting where appropriate.
4. The output file should be saved inside a `clawfile` directory.

## Grading Criteria

- [ ] A file exists inside a `clawfile` directory
- [ ] The file contains a market overview section (major indices)
- [ ] The file contains an industry/sector analysis section
- [ ] The file contains an individual stock review section
- [ ] The file contains a trading insights/notes section
- [ ] The template uses structured formatting (tables, headings, etc.)

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    import os
    import re
    from pathlib import Path

    scores = {
        "file_exists_in_clawfile": 0.0,
        "has_market_overview_section": 0.0,
        "has_sector_industry_section": 0.0,
        "has_individual_stock_section": 0.0,
        "has_insights_notes_section": 0.0,
        "has_structured_formatting": 0.0,
    }

    # Find the clawfile directory - check multiple possible locations
    clawfile_dir = None
    candidates = [
        os.path.join(workspace_path, "clawfile"),
        "/root/clawfile",
        os.path.join(workspace_path, "root", "clawfile"),
    ]
    for c in candidates:
        if os.path.isdir(c):
            clawfile_dir = c
            break

    if clawfile_dir is None:
        return scores

    # Find any file in the clawfile directory
    files = []
    for f in os.listdir(clawfile_dir):
        fpath = os.path.join(clawfile_dir, f)
        if os.path.isfile(fpath):
            files.append(fpath)

    if not files:
        return scores

    scores["file_exists_in_clawfile"] = 1.0

    # Read the content of the first (or all) file(s)
    content = ""
    for fpath in files:
        try:
            with open(fpath, "r", encoding="utf-8") as fh:
                content += fh.read() + "\n"
        except Exception:
            try:
                with open(fpath, "r", encoding="latin-1") as fh:
                    content += fh.read() + "\n"
            except Exception:
                pass

    if not content.strip():
        return scores

    content_lower = content.lower()

    # Check for market overview section
    market_keywords = [
        "market", "index", "indices", "overview", "composite", "component",
        "volume", "turnover", "sentiment",
        "\u5927\u76d8", "\u6307\u6570", "\u4e0a\u8bc1", "\u6df1\u8bc1",
        "\u521b\u4e1a\u677f", "\u6210\u4ea4", "\u6da8\u505c", "\u8dcc\u505c",
        "\u603b\u89c8", "\u5e02\u573a"
    ]
    if any(kw in content_lower or kw in content for kw in market_keywords):
        scores["has_market_overview_section"] = 1.0

    # Check for industry/sector section
    sector_keywords = [
        "industry", "sector", "plate", "theme", "rotation",
        "\u884c\u4e1a", "\u677f\u5757", "\u9898\u6750", "\u8f6e\u52a8",
        "\u70ed\u70b9"
    ]
    if any(kw in content_lower or kw in content for kw in sector_keywords):
        scores["has_sector_industry_section"] = 1.0

    # Check for individual stock review section
    stock_keywords = [
        "stock", "individual", "position", "ticker", "code", "entry", "exit",
        "profit", "loss", "p/l",
        "\u4e2a\u80a1", "\u590d\u76d8", "\u80a1\u7968", "\u4ee3\u7801",
        "\u4e70\u5165", "\u5356\u51fa", "\u6301\u4ed3", "\u76c8\u4e8f"
    ]
    if any(kw in content_lower or kw in content for kw in stock_keywords):
        scores["has_individual_stock_section"] = 1.0

    # Check for insights/notes section
    insights_keywords = [
        "insight", "note", "reflection", "lesson", "takeaway", "summary",
        "strategy", "adjustment", "review",
        "\u5fc3\u5f97", "\u603b\u7ed3", "\u53cd\u601d", "\u6559\u8bad",
        "\u7b56\u7565", "\u8c03\u6574", "\u611f\u609f"
    ]
    if any(kw in content_lower or kw in content for kw in insights_keywords):
        scores["has_insights_notes_section"] = 1.0

    # Check for structured formatting (markdown tables, headings, lists)
    formatting_patterns = [
        r"^\s*#{1,3}\s+",      # Markdown headings
        r"\|.+\|",              # Table rows
        r"^\s*[-*]\s+",        # List items
        r"^[-=]{3,}",          # Horizontal rules / underline headings
    ]
    for pattern in formatting_patterns:
        if re.search(pattern, content, re.MULTILINE):
            scores["has_structured_formatting"] = 1.0
            break

    return scores
```

## LLM Judge Rubric

### Template Completeness (Weight: 35%)
- 1.0: Template contains all four required sections (market overview, sector/industry, individual stock, insights) with meaningful fields and placeholders in each.
- 0.75: Template contains all four sections but one or two are sparse or lack useful fields.
- 0.5: Template is missing one of the four required sections but remaining sections are well done.
- 0.25: Template is missing two or more sections or sections are extremely minimal.
- 0.0: No recognizable template structure or file not created.

### Formatting and Structure Quality (Weight: 25%)
- 1.0: Excellent use of tables, headings, and structured formatting; the template is immediately usable for daily stock review.
- 0.75: Good formatting with tables and headings but minor inconsistencies or areas that could be improved.
- 0.5: Basic formatting present (some headings or tables) but not consistently applied throughout.
- 0.25: Minimal formatting; mostly plain text without clear structure.
- 0.0: No formatting at all; unstructured text dump.

### Practical Usefulness for Stock Review (Weight: 25%)
- 1.0: Template includes practical, actionable fields (e.g., index values, volume, limit-up/down counts, entry/exit prices, P&L tracking, strategy notes) that a trader would actually use daily.
- 0.75: Most fields are practical and relevant but a few important ones are missing.
- 0.5: Some useful fields but the template feels generic and not specifically tailored to stock daily review.
- 0.25: Very few practical fields; template is too abstract to be useful.
- 0.0: Template has no practical value for stock review purposes.

### File Output Compliance (Weight: 15%)
- 1.0: File is saved in the correct `clawfile` directory (either `/root/clawfile` or workspace `clawfile` with clear explanation if permissions prevented the original path).
- 0.75: File is saved in a `clawfile` directory but with minor path issues or no explanation of path deviation.
- 0.5: File is created but not in the `clawfile` directory.
- 0.25: File is created somewhere but location is unclear or hard to find.
- 0.0: No file was created.