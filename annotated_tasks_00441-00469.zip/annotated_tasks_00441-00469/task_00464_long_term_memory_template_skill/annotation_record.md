| 序号 | 修改项 | 修改原因 |
|------|--------|----------|
| 1 | frontmatter 补充 `grading_weights: {automated: 1.0}` | `grading_type: automated` 但 frontmatter 中缺少 `grading_weights` 字段；无 LLM Judge Rubric，automated 权重应为 1.0，automated + llmjudge 之和须等于 1.0 |
| 2 | `grade()` 中 `supporting_files` 评分改为 `min(1.0, found / 1.0)`（原为 `found / 2.0`） | Grading Criteria 第10条为"At least one additional supporting workspace file was created"，语义为创建 ≥1 个文件即满足；但原 `grade()` 用 `found/2.0`，要求创建2个文件才得满分，1个只得0.5分，与标准不一致；Prompt 中支持文件为可选项（"Feel free to also create"），Expected Behavior 也标注为"Optionally"，设定1个即满分更合理，修正为 `found/1.0` |