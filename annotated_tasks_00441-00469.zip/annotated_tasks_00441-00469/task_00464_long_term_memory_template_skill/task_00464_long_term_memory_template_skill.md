---
id: task_00464_long_term_memory_template_skill
name: Long-Term Memory Template Skill Creation
category: Knowledge and Memory Management
subcategory: Memory and Context Management
difficulty: easy
grading_type: automated
grading_weights: {automated: 1.0}
timeout_seconds: 600
input_modality: text-only
external_dependency: none
workspace_files: []
skill_creation: true
---

## Prompt

Hey, I want to set up a persistent memory system for my AI workspace. I've seen skills like agent-weave (parallel task execution), blackpix (distributed knowledge network), and capacities (note management) — and I want something similar but focused on long-term memory.

Can you first create a reusable OpenClaw skill as a SKILL.md file that encapsulates the ability to generate and maintain structured long-term memory files? The skill should describe how to create a MEMORY.md template with sections for user info, assistant identity, important dates, project context, lessons learned, and tools/configs.

Then, actually use that skill to create the MEMORY.md file itself in the workspace root. Keep the template concise and designed for ongoing updates over time. Feel free to also create any supporting files you think would be useful for a well-organized AI workspace (like identity files, soul files, agent guidelines, etc.).

## Expected Behavior

The agent should:

1. **Create a SKILL.md file** in the workspace with proper YAML frontmatter (including `name` and `description` fields) and markdown instruction sections describing how to generate and maintain long-term memory templates. This skill is inspired by existing OpenClaw skills like agent-weave, blackpix, and capacities.

2. **Create a MEMORY.md file** at the workspace root that serves as a long-term memory template. It should contain clearly delineated sections for:
   - User information (name, timezone, communication style, etc.)
   - Assistant identity / self-description
   - Important dates (birthdays, deadlines, recurring events)
   - Project context (active/archived projects, key decisions)
   - Lessons learned
   - Tools and configuration

3. **Optionally create supporting workspace files** such as AGENTS.md, IDENTITY.md, SOUL.md, HEARTBEAT.md, USER.md, TOOLS.md, or similar organizational files that complement the memory system.

4. The MEMORY.md should be concise, use markdown formatting, and be designed for sustainable incremental updates.

## Grading Criteria

- [ ] SKILL.md exists with valid YAML frontmatter containing name and description
- [ ] SKILL.md contains instructional content about memory template creation
- [ ] MEMORY.md exists at workspace root
- [ ] MEMORY.md contains a section for user information
- [ ] MEMORY.md contains a section for assistant identity
- [ ] MEMORY.md contains a section for important dates
- [ ] MEMORY.md contains a section for project context
- [ ] MEMORY.md contains a section for lessons learned
- [ ] MEMORY.md contains a section for tools or configuration
- [ ] At least one additional supporting workspace file was created

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    from pathlib import Path
    import re

    scores = {}
    ws = Path(workspace_path)

    # --- 1. SKILL.md existence and structure ---
    skill_path = ws / "SKILL.md"
    skill_score = 0.0
    skill_content_score = 0.0
    if skill_path.exists():
        content = skill_path.read_text(encoding="utf-8", errors="replace")
        # Check for YAML frontmatter with name and description
        fm_match = re.search(r"^---\s*\n(.*?)\n---", content, re.DOTALL)
        if fm_match:
            fm = fm_match.group(1)
            has_name = bool(re.search(r"(?i)name\s*:", fm))
            has_desc = bool(re.search(r"(?i)description\s*:", fm))
            if has_name and has_desc:
                skill_score = 1.0
            elif has_name or has_desc:
                skill_score = 0.5
        # Check for instructional content beyond frontmatter
        body = re.sub(r"^---\s*\n.*?\n---", "", content, count=1, flags=re.DOTALL).strip()
        if len(body) > 50:
            skill_content_score = 1.0
        elif len(body) > 10:
            skill_content_score = 0.5
    scores["skill_md_frontmatter"] = skill_score
    scores["skill_md_instructions"] = skill_content_score

    # --- 2. MEMORY.md existence ---
    memory_path = ws / "MEMORY.md"
    memory_exists = 0.0
    mem_content = ""
    if memory_path.exists():
        memory_exists = 1.0
        mem_content = memory_path.read_text(encoding="utf-8", errors="replace").lower()
    scores["memory_md_exists"] = memory_exists

    # --- 3. MEMORY.md section: user information ---
    user_patterns = [r"human", r"user", r"name\s*:", r"timezone", r"communication"]
    user_hits = sum(1 for p in user_patterns if re.search(p, mem_content))
    scores["memory_user_info"] = min(1.0, user_hits / 2.0)

    # --- 4. MEMORY.md section: assistant identity ---
    identity_patterns = [r"identity", r"who\s+i\s+am", r"assistant", r"persona", r"vibe", r"style"]
    identity_hits = sum(1 for p in identity_patterns if re.search(p, mem_content))
    scores["memory_identity"] = min(1.0, identity_hits / 2.0)

    # --- 5. MEMORY.md section: important dates ---
    dates_patterns = [r"date", r"birthday", r"deadline", r"recurring", r"calendar", r"anniversary"]
    dates_hits = sum(1 for p in dates_patterns if re.search(p, mem_content))
    scores["memory_dates"] = min(1.0, dates_hits / 1.0)

    # --- 6. MEMORY.md section: project context ---
    project_patterns = [r"project", r"context", r"active", r"archive", r"decision"]
    project_hits = sum(1 for p in project_patterns if re.search(p, mem_content))
    scores["memory_projects"] = min(1.0, project_hits / 2.0)

    # --- 7. MEMORY.md section: lessons learned ---
    lessons_patterns = [r"lesson", r"learned", r"takeaway", r"insight", r"mistake", r"retrospect"]
    lessons_hits = sum(1 for p in lessons_patterns if re.search(p, mem_content))
    scores["memory_lessons"] = min(1.0, lessons_hits / 1.0)

    # --- 8. MEMORY.md section: tools / configuration ---
    tools_patterns = [r"tool", r"config", r"setup", r"environment", r"stack", r"preference"]
    tools_hits = sum(1 for p in tools_patterns if re.search(p, mem_content))
    scores["memory_tools_config"] = min(1.0, tools_hits / 1.0)

    # --- 9. Supporting files created ---
    supporting_files = [
        "AGENTS.md", "IDENTITY.md", "SOUL.md", "HEARTBEAT.md",
        "USER.md", "TOOLS.md", "README.md"
    ]
    found = sum(1 for f in supporting_files if (ws / f).exists())
    scores["supporting_files"] = min(1.0, found / 1.0)

    return scores
```