| 序号 | 修改项 | 修改原因 |
|------|--------|----------|
| 1 | Prompt 增加更具体的上下文和自然度 | 原 Prompt 过于简短，像考试指令而非真实用户请求，缺乏自然度；同时未提及 workspace 中已有的参考文件 |
| 2 | `workspace_files` 字段补充实际文件列表 | 原 YAML frontmatter 中 `workspace_files: []` 为空，但实际存在 3 个 Assets 文件，需保持一致 |
| 3 | Expected Behavior 增加对 Assets 文件的说明 | 需说明 workspace 中已有的参考文件（notes.md、old_script.py、requirements-old.txt）与任务的关系，明确 Agent 可参考但不应直接复用 |
| 4 | Grading Criteria 增加一条关于测试文件内容质量的检查 | 原 Grading Criteria 中"至少一个 test file 存在"与 grade() 函数中对测试内容的检查有隐含的质量要求，但 Criteria 中未显式体现 |
| 5 | grade() 函数中 `find_files` 对 README 的匹配改为大小写不敏感 | 原实现使用 `find_files("README.md")` 精确匹配，但 Agent 可能生成 `readme.md` 或 `Readme.md`，需要格式容忍 |
| 6 | grade() 函数中 `.gitignore` 的查找增加隐藏文件兼容说明 | `find_files(".gitignore")` 逻辑本身是正确的（os.walk 会列出隐藏文件），但添加注释确认行为 |
| 7 | notes.md 中的外部链接保留但确认无敏感信息 | 链接指向公开的 Python 官方文档和 pytest 文档，无敏感信息，内容合理 |
| 8 | LLM Judge Rubric 缺失 | 原任务文件完全没有 `## LLM Judge Rubric` 部分，但 grading_type 为 automated，确认不需要 LLM Judge；但为规范性考虑，在 frontmatter 中明确 grading weights |