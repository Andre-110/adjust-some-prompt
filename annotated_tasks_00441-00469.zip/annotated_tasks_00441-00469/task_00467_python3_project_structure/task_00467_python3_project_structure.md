---
id: task_00467_python3_project_structure
name: Generate Python 3 Project Structure
category: System Administration
subcategory: Software and Environment Management
difficulty: easy
grading_type: automated
grading_weights:
  automated: 1.0
  llm_judge: 0.0
timeout_seconds: 600
input_modality: text-only
external_dependency: none
workspace_files:
  - path: notes.md
    role: context
    description: Planning notes with project preferences and decisions
  - path: old_script.py
    role: context
    description: A legacy prototype script from earlier exploration
  - path: requirements-old.txt
    role: context
    description: Legacy requirements from a previous prototype
skill_creation: false
---

## Prompt

I've been prototyping a small Python tool and now I want to set it up properly as a real project. There are some old notes and a throwaway script in my workspace from earlier — you can look at them for context on what I had in mind, but don't just reuse them as-is.

Please generate a clean Python 3 project structure for me. I'd like it to follow modern packaging conventions and include a `tests/` folder with at least one actual test case file. Put the whole thing in a subdirectory called `python-project/` so it stays organized.

## Expected Behavior

The agent should inspect the workspace context files (`notes.md`, `old_script.py`, `requirements-old.txt`) to understand the user's preferences (e.g., pytest as test runner, pyproject.toml preferred, Python 3.9+), then create a standard Python 3 project directory structure under `python-project/`.

The generated structure should include at minimum:

1. **A build/project configuration file** such as `pyproject.toml` (preferred per notes.md) or `setup.py`, with meaningful content (project name, version, dependencies, etc.)
2. **A source package directory** (e.g., `python-project/src/myproject/` or `python-project/myproject/`) containing an `__init__.py` file and at least one module file (e.g., `main.py`)
3. **A `tests/` directory** containing an `__init__.py` and at least one test file (e.g., `test_main.py`)
4. **A `README.md`** file describing the project
5. **A `.gitignore`** file with Python-relevant ignore patterns (e.g., `__pycache__`, `.pyc`, `venv`, `dist`, `.egg`)

The test file should contain at least one valid test function (e.g., `def test_something():`) or test class. The `__init__.py` files should exist to make the directories proper Python packages.

The agent should NOT simply copy `old_script.py` as-is into the new structure, but may incorporate or refactor ideas from it. The `requirements-old.txt` may inform dependency choices but should not be copied verbatim — a `pyproject.toml` with `[project.dependencies]` is preferred.

## Grading Criteria

- [ ] Project configuration file exists (pyproject.toml or setup.py) with meaningful content (>10 characters)
- [ ] Source package with `__init__.py` exists (excluding tests/)
- [ ] `tests/` directory exists with `__init__.py`
- [ ] At least one test file exists in `tests/` with a valid test function or test class
- [ ] `README.md` exists with descriptive content
- [ ] `.gitignore` exists with Python-relevant ignore patterns

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    import os
    from pathlib import Path

    scores = {
        "project_config_exists": 0.0,
        "source_package_exists": 0.0,
        "tests_directory_exists": 0.0,
        "test_file_exists": 0.0,
        "readme_exists": 0.0,
        "gitignore_exists": 0.0,
    }

    ws = Path(workspace_path)

    # Helper: search for a file by name anywhere in workspace
    def find_files(name_pattern: str, case_insensitive: bool = False):
        results = []
        for root, dirs, files in os.walk(ws):
            # Skip .git and .openclaw directories
            dirs[:] = [d for d in dirs if d != ".git" and d != ".openclaw"]
            for f in files:
                if case_insensitive:
                    if name_pattern.lower() in f.lower():
                        results.append(os.path.join(root, f))
                else:
                    if name_pattern in f:
                        results.append(os.path.join(root, f))
        return results

    def find_dirs(name: str):
        results = []
        for root, dirs, files in os.walk(ws):
            dirs[:] = [d for d in dirs if d != ".git" and d != ".openclaw"]
            for d in dirs:
                if d == name:
                    results.append(os.path.join(root, d))
        return results

    # 1. Check for project configuration file (pyproject.toml or setup.py)
    pyproject_files = find_files("pyproject.toml")
    setup_files = find_files("setup.py")
    if pyproject_files or setup_files:
        config_file = pyproject_files[0] if pyproject_files else setup_files[0]
        try:
            content = Path(config_file).read_text(encoding="utf-8")
            if len(content.strip()) > 10:
                scores["project_config_exists"] = 1.0
            else:
                scores["project_config_exists"] = 0.5
        except Exception:
            scores["project_config_exists"] = 0.25

    # 2. Check for source package with __init__.py
    # Look for __init__.py files that are NOT inside the tests/ directory
    init_files = find_files("__init__.py")
    source_inits = [
        f for f in init_files
        if "tests" not in Path(f).parts
    ]
    if source_inits:
        scores["source_package_exists"] = 1.0

    # 3. Check for tests/ directory with __init__.py
    tests_dirs = find_dirs("tests")
    if tests_dirs:
        tests_dir = Path(tests_dirs[0])
        init_in_tests = tests_dir / "__init__.py"
        if init_in_tests.exists():
            scores["tests_directory_exists"] = 1.0
        else:
            # tests/ exists but no __init__.py
            scores["tests_directory_exists"] = 0.5

    # 4. Check for at least one test file in tests/ with valid content
    if tests_dirs:
        tests_dir = Path(tests_dirs[0])
        test_files = list(tests_dir.glob("test_*.py"))
        if not test_files:
            test_files = list(tests_dir.glob("*_test.py"))
        if test_files:
            # Verify the test file has some content resembling a test
            try:
                content = test_files[0].read_text(encoding="utf-8")
                if "def test_" in content or "class Test" in content:
                    scores["test_file_exists"] = 1.0
                elif len(content.strip()) > 0:
                    scores["test_file_exists"] = 0.5
                else:
                    scores["test_file_exists"] = 0.25
            except Exception:
                scores["test_file_exists"] = 0.25

    # 5. Check for README.md (case-insensitive matching)
    readme_files = find_files("readme.md", case_insensitive=True)
    if readme_files:
        try:
            content = Path(readme_files[0]).read_text(encoding="utf-8")
            if len(content.strip()) > 5:
                scores["readme_exists"] = 1.0
            else:
                scores["readme_exists"] = 0.5
        except Exception:
            scores["readme_exists"] = 0.25

    # 6. Check for .gitignore (os.walk includes hidden files)
    gitignore_files = find_files(".gitignore")
    if gitignore_files:
        try:
            content = Path(gitignore_files[0]).read_text(encoding="utf-8")
            # Check for Python-relevant patterns
            python_patterns = ["__pycache__", ".pyc", "venv", ".egg", "dist"]
            matches = sum(1 for p in python_patterns if p in content)
            if matches >= 2:
                scores["gitignore_exists"] = 1.0
            elif matches >= 1:
                scores["gitignore_exists"] = 0.75
            elif len(content.strip()) > 0:
                scores["gitignore_exists"] = 0.5
            else:
                scores["gitignore_exists"] = 0.25
        except Exception:
            scores["gitignore_exists"] = 0.25

    return scores
```