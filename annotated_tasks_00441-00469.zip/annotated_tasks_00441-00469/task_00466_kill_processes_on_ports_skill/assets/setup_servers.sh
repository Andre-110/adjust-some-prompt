#!/bin/bash
# Launch simple Python HTTP servers on ports 3000-3004
for port in 3000 3001 3002 3003 3004; do
  python3 -m http.server $port &>/dev/null &
done
echo "Servers started on ports 3000-3004"