---
id: task_00466_kill_processes_on_ports_skill
name: Kill Processes on Ports 3000-3004 via Reusable Skill
category: System Administration
subcategory: System Operations and Monitoring
difficulty: easy
grading_type: automated
grading_weights: {automated: 1.0}
timeout_seconds: 600
input_modality: text-only
external_dependency: none
skill_creation: true
workspace_files:
  - path: setup_servers.sh
    content: |
      #!/bin/bash
      # Launch simple Python HTTP servers on ports 3000-3004
      for port in 3000 3001 3002 3003 3004; do
        python3 -m http.server $port &>/dev/null &
      done
      echo "Servers started on ports 3000-3004"
---

## Prompt

Hey, I need a reusable skill for cleaning up processes that are occupying specific network ports. Create it as a SKILL.md file — something inspired by tools like "sport-mode" (which does auto-cleanup) or "azure-infra" (chat-based infra assistance). The skill should use `lsof` to find processes on given ports and then kill them.

Once you've created the skill, go ahead and use it: find any processes occupying ports 3000 through 3004 and kill them all. If nothing is listening on those ports, just let me know that they're already clear.

## Expected Behavior

The agent should:

1. **Create a SKILL.md file** in the workspace root with proper YAML frontmatter (including `name` and `description` fields) and markdown instruction sections describing how to use `lsof` to identify and kill processes on specified ports. This is inspired by similar skills like `sport-mode` (auto-cleanup) and `azure-infra` (infrastructure assistance).

2. **Attempt to find and kill processes** on ports 3000-3004 using a command like `lsof -i :3000-3004 -t | sort -u | xargs -r kill -9` or equivalent.

3. **Report the outcome** — either confirming processes were killed, or noting that no processes were found on those ports (both are valid depending on environment state).

## Grading Criteria

- [ ] SKILL.md file exists in the workspace
- [ ] SKILL.md has valid YAML frontmatter with `name` and `description`
- [ ] SKILL.md contains meaningful instruction content about port cleanup
- [ ] Agent executed or attempted a command using `lsof` to find processes on ports 3000-3004
- [ ] Agent executed or attempted a kill command (or correctly reported no processes found)
- [ ] Agent communicated the result to the user

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    import os
    import re

    scores = {
        "skill_md_exists": 0.0,
        "skill_md_frontmatter": 0.0,
        "skill_md_content": 0.0,
        "lsof_command_used": 0.0,
        "kill_or_report": 0.0,
        "result_communicated": 0.0,
    }

    # 1. Check SKILL.md exists
    skill_path = os.path.join(workspace_path, "SKILL.md")
    if os.path.isfile(skill_path):
        scores["skill_md_exists"] = 1.0

        try:
            with open(skill_path, "r", encoding="utf-8") as f:
                content = f.read()
        except Exception:
            content = ""

        # 2. Check YAML frontmatter with name and description
        frontmatter_match = re.search(r"^---\s*\n(.*?)\n---", content, re.DOTALL)
        if frontmatter_match:
            fm = frontmatter_match.group(1)
            has_name = bool(re.search(r"(?i)name\s*:", fm))
            has_desc = bool(re.search(r"(?i)description\s*:", fm))
            if has_name and has_desc:
                scores["skill_md_frontmatter"] = 1.0
            elif has_name or has_desc:
                scores["skill_md_frontmatter"] = 0.5

        # 3. Check meaningful content about port cleanup
        body = content
        if frontmatter_match:
            body = content[frontmatter_match.end():]
        port_keywords = ["lsof", "port", "kill", "process", "cleanup", "clean"]
        keyword_hits = sum(1 for kw in port_keywords if kw.lower() in body.lower())
        if keyword_hits >= 3:
            scores["skill_md_content"] = 1.0
        elif keyword_hits >= 2:
            scores["skill_md_content"] = 0.75
        elif keyword_hits >= 1:
            scores["skill_md_content"] = 0.5

    # 4-6. Check transcript for lsof usage, kill attempt, and communication
    lsof_used = False
    kill_or_report = False
    result_communicated = False

    for event in transcript:
        if event.get("type") != "message":
            continue
        msg = event.get("message", {})
        role = msg.get("role", "")
        text_content = ""

        # Extract text from content (could be string or list)
        raw_content = msg.get("content", "")
        if isinstance(raw_content, str):
            text_content = raw_content
        elif isinstance(raw_content, list):
            for part in raw_content:
                if isinstance(part, dict):
                    part_type = part.get("type", "")
                    if part_type == "text":
                        text_content += part.get("text", "") + " "
                    elif part_type == "tool_use":
                        # Extract tool call input (e.g. bash command)
                        text_content += str(part.get("input", "")) + " "
                    elif part_type == "tool_result":
                        # Extract tool result content
                        sub_content = part.get("content", [])
                        if isinstance(sub_content, list):
                            for sub in sub_content:
                                if isinstance(sub, dict) and sub.get("type") == "text":
                                    text_content += sub.get("text", "") + " "
                        elif isinstance(sub_content, str):
                            text_content += sub_content + " "
                elif isinstance(part, str):
                    text_content += part + " "

        combined = text_content

        # Check for lsof command targeting ports 3000-3004
        if re.search(r"lsof.*3000", combined, re.IGNORECASE):
            lsof_used = True

        # Check for kill command or report that no processes found
        if re.search(r"kill\b", combined, re.IGNORECASE):
            kill_or_report = True
        if re.search(r"no.*(process|listen|occup)", combined, re.IGNORECASE):
            kill_or_report = True
        if re.search(r"already\s+clear", combined, re.IGNORECASE):
            kill_or_report = True
        if re.search(r"nothing.*(listen|running|found)", combined, re.IGNORECASE):
            kill_or_report = True

        # Check assistant communicated result
        if role == "assistant":
            if re.search(r"(kill|terminat|no.*(process|listen)|clear|done|complet|freed|cleaned)", combined, re.IGNORECASE):
                result_communicated = True

    if lsof_used:
        scores["lsof_command_used"] = 1.0
    if kill_or_report:
        scores["kill_or_report"] = 1.0
    if result_communicated:
        scores["result_communicated"] = 1.0

    return scores
```