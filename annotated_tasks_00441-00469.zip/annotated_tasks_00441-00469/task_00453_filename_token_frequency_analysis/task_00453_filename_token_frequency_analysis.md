---
id: task_00453_filename_token_frequency_analysis
name: Filename Token Frequency Analysis with Skill Creation
category: Data Analysis and Modeling
subcategory: Data Processing and Management
difficulty: medium
grading_type: automated
grading_weights: {automated: 1.0}
timeout_seconds: 600
input_modality: text-only
external_dependency: none
workspace_files:
  - path: src/components/user-profile-card.tsx
    content: "# placeholder: user-profile-card.tsx"
  - path: src/components/navigation-sidebar-menu.tsx
    content: "# placeholder: navigation-sidebar-menu.tsx"
  - path: src/components/data-table-pagination.tsx
    content: "# placeholder: data-table-pagination.tsx"
  - path: src/components/modal-dialog-confirm.tsx
    content: "# placeholder: modal-dialog-confirm.tsx"
  - path: src/components/dropdown-select-multi.tsx
    content: "# placeholder: dropdown-select-multi.tsx"
  - path: src/components/search-bar-autocomplete.tsx
    content: "# placeholder: search-bar-autocomplete.tsx"
  - path: src/components/file-upload-progress.tsx
    content: "# placeholder: file-upload-progress.tsx"
  - path: src/components/notification-toast-stack.tsx
    content: "# placeholder: notification-toast-stack.tsx"
  - path: src/components/chart-line-realtime.tsx
    content: "# placeholder: chart-line-realtime.tsx"
  - path: src/components/form-validation-wrapper.tsx
    content: "# placeholder: form-validation-wrapper.tsx"
  - path: src/components/auth-login-form.tsx
    content: "# placeholder: auth-login-form.tsx"
  - path: src/components/dashboard-widget-container.tsx
    content: "# placeholder: dashboard-widget-container.tsx"
  - path: src/components/breadcrumb-navigation-trail.tsx
    content: "# placeholder: breadcrumb-navigation-trail.tsx"
  - path: src/components/image-gallery-lightbox.tsx
    content: "# placeholder: image-gallery-lightbox.tsx"
  - path: src/components/date-range-picker.tsx
    content: "# placeholder: date-range-picker.tsx"
  - path: src/utils/string-format-helpers.ts
    content: "# placeholder: string-format-helpers.ts"
  - path: src/utils/date-time-utils.ts
    content: "# placeholder: date-time-utils.ts"
  - path: src/utils/api-response-parser.ts
    content: "# placeholder: api-response-parser.ts"
  - path: src/utils/local-storage-manager.ts
    content: "# placeholder: local-storage-manager.ts"
  - path: src/utils/error-handler-global.ts
    content: "# placeholder: error-handler-global.ts"
  - path: src/utils/validation-schema-builder.ts
    content: "# placeholder: validation-schema-builder.ts"
  - path: src/utils/csv-export-utility.ts
    content: "# placeholder: csv-export-utility.ts"
  - path: src/utils/deep-merge-objects.ts
    content: "# placeholder: deep-merge-objects.ts"
  - path: src/utils/debounce-throttle-functions.ts
    content: "# placeholder: debounce-throttle-functions.ts"
  - path: src/utils/color-palette-generator.ts
    content: "# placeholder: color-palette-generator.ts"
  - path: src/hooks/use-auth-context.ts
    content: "# placeholder: use-auth-context.ts"
  - path: src/hooks/use-fetch-data.ts
    content: "# placeholder: use-fetch-data.ts"
  - path: src/hooks/use-local-storage.ts
    content: "# placeholder: use-local-storage.ts"
  - path: src/hooks/use-debounced-value.ts
    content: "# placeholder: use-debounced-value.ts"
  - path: src/hooks/use-intersection-observer.ts
    content: "# placeholder: use-intersection-observer.ts"
  - path: src/hooks/use-media-query.ts
    content: "# placeholder: use-media-query.ts"
  - path: src/hooks/use-window-resize.ts
    content: "# placeholder: use-window-resize.ts"
  - path: src/hooks/use-click-outside.ts
    content: "# placeholder: use-click-outside.ts"
  - path: src/services/user-authentication-service.ts
    content: "# placeholder: user-authentication-service.ts"
  - path: src/services/payment-processing-gateway.ts
    content: "# placeholder: payment-processing-gateway.ts"
  - path: src/services/notification-email-sender.ts
    content: "# placeholder: notification-email-sender.ts"
  - path: src/services/file-storage-cloud-adapter.ts
    content: "# placeholder: file-storage-cloud-adapter.ts"
  - path: src/services/analytics-event-tracker.ts
    content: "# placeholder: analytics-event-tracker.ts"
  - path: src/services/cache-redis-manager.ts
    content: "# placeholder: cache-redis-manager.ts"
  - path: src/services/search-elasticsearch-client.ts
    content: "# placeholder: search-elasticsearch-client.ts"
  - path: src/services/queue-message-broker.ts
    content: "# placeholder: queue-message-broker.ts"
  - path: src/middleware/auth-token-validator.ts
    content: "# placeholder: auth-token-validator.ts"
  - path: src/middleware/rate-limit-controller.ts
    content: "# placeholder: rate-limit-controller.ts"
  - path: src/middleware/request-logger-morgan.ts
    content: "# placeholder: request-logger-morgan.ts"
  - path: src/middleware/cors-policy-handler.ts
    content: "# placeholder: cors-policy-handler.ts"
  - path: src/middleware/error-response-formatter.ts
    content: "# placeholder: error-response-formatter.ts"
  - path: tests/unit/user-profile-card.test.tsx
    content: "# placeholder: user-profile-card.test.tsx"
  - path: tests/unit/string-format-helpers.test.ts
    content: "# placeholder: string-format-helpers.test.ts"
  - path: tests/unit/date-time-utils.test.ts
    content: "# placeholder: date-time-utils.test.ts"
  - path: tests/unit/api-response-parser.test.ts
    content: "# placeholder: api-response-parser.test.ts"
  - path: tests/unit/validation-schema-builder.test.ts
    content: "# placeholder: validation-schema-builder.test.ts"
  - path: tests/unit/deep-merge-objects.test.ts
    content: "# placeholder: deep-merge-objects.test.ts"
  - path: tests/integration/auth-login-flow.test.ts
    content: "# placeholder: auth-login-flow.test.ts"
  - path: tests/integration/payment-checkout-flow.test.ts
    content: "# placeholder: payment-checkout-flow.test.ts"
  - path: tests/integration/file-upload-pipeline.test.ts
    content: "# placeholder: file-upload-pipeline.test.ts"
  - path: tests/integration/search-filter-sort.test.ts
    content: "# placeholder: search-filter-sort.test.ts"
  - path: tests/e2e/user-registration-journey.spec.ts
    content: "# placeholder: user-registration-journey.spec.ts"
  - path: tests/e2e/dashboard-navigation-smoke.spec.ts
    content: "# placeholder: dashboard-navigation-smoke.spec.ts"
  - path: tests/e2e/data-export-download.spec.ts
    content: "# placeholder: data-export-download.spec.ts"
  - path: config/webpack.config.production.js
    content: "# placeholder: webpack.config.production.js"
  - path: config/webpack.config.development.js
    content: "# placeholder: webpack.config.development.js"
  - path: config/jest.setup.integration.ts
    content: "# placeholder: jest.setup.integration.ts"
  - path: config/eslint-rules-custom.json
    content: "# placeholder: eslint-rules-custom.json"
  - path: config/tailwind.config.extended.js
    content: "# placeholder: tailwind.config.extended.js"
  - path: config/database-migration-settings.yaml
    content: "# placeholder: database-migration-settings.yaml"
  - path: config/redis-cluster-config.yaml
    content: "# placeholder: redis-cluster-config.yaml"
  - path: config/nginx-reverse-proxy.conf
    content: "# placeholder: nginx-reverse-proxy.conf"
  - path: docs/api-reference-guide.md
    content: "# placeholder: api-reference-guide.md"
  - path: docs/getting-started-quickstart.md
    content: "# placeholder: getting-started-quickstart.md"
  - path: docs/deployment-production-checklist.md
    content: "# placeholder: deployment-production-checklist.md"
  - path: docs/architecture-decision-records.md
    content: "# placeholder: architecture-decision-records.md"
  - path: docs/database-schema-design.md
    content: "# placeholder: database-schema-design.md"
  - path: docs/troubleshooting-common-issues.md
    content: "# placeholder: troubleshooting-common-issues.md"
  - path: docs/changelog-release-notes.md
    content: "# placeholder: changelog-release-notes.md"
  - path: docs/contributing-guidelines-style.md
    content: "# placeholder: contributing-guidelines-style.md"
  - path: scripts/database-seed-initial.sh
    content: "# placeholder: database-seed-initial.sh"
  - path: scripts/backup-restore-postgres.sh
    content: "# placeholder: backup-restore-postgres.sh"
  - path: scripts/deploy-production-rollback.sh
    content: "# placeholder: deploy-production-rollback.sh"
  - path: scripts/generate-ssl-certificates.sh
    content: "# placeholder: generate-ssl-certificates.sh"
  - path: scripts/cleanup-temp-files.sh
    content: "# placeholder: cleanup-temp-files.sh"
  - path: scripts/run-performance-benchmark.sh
    content: "# placeholder: run-performance-benchmark.sh"
  - path: scripts/migrate-data-legacy-format.sh
    content: "# placeholder: migrate-data-legacy-format.sh"
  - path: assets/images/logo-dark-theme.svg
    content: "# placeholder: logo-dark-theme.svg"
  - path: assets/images/logo-light-theme.svg
    content: "# placeholder: logo-light-theme.svg"
  - path: assets/images/hero-banner-homepage.png
    content: "# placeholder: hero-banner-homepage.png"
  - path: assets/images/placeholder-user-avatar.png
    content: "# placeholder: placeholder-user-avatar.png"
  - path: assets/images/background-pattern-dots.svg
    content: "# placeholder: background-pattern-dots.svg"
  - path: assets/fonts/inter-variable-latin.woff2
    content: "# placeholder: inter-variable-latin.woff2"
  - path: assets/fonts/fira-code-regular.woff2
    content: "# placeholder: fira-code-regular.woff2"
  - path: assets/fonts/roboto-mono-bold.woff2
    content: "# placeholder: roboto-mono-bold.woff2"
  - path: assets/icons/icon-chevron-down.svg
    content: "# placeholder: icon-chevron-down.svg"
  - path: assets/icons/icon-search-magnify.svg
    content: "# placeholder: icon-search-magnify.svg"
  - path: assets/icons/icon-bell-notification.svg
    content: "# placeholder: icon-bell-notification.svg"
  - path: assets/icons/icon-settings-gear.svg
    content: "# placeholder: icon-settings-gear.svg"
  - path: assets/icons/icon-user-circle.svg
    content: "# placeholder: icon-user-circle.svg"
  - path: assets/icons/icon-menu-hamburger.svg
    content: "# placeholder: icon-menu-hamburger.svg"
  - path: assets/icons/icon-close-cross.svg
    content: "# placeholder: icon-close-cross.svg"
  - path: assets/icons/icon-check-circle.svg
    content: "# placeholder: icon-check-circle.svg"
  - path: data/sample-users-dataset.json
    content: "# placeholder: sample-users-dataset.json"
  - path: data/product-categories-lookup.csv
    content: "# placeholder: product-categories-lookup.csv"
  - path: data/country-codes-iso3166.json
    content: "# placeholder: country-codes-iso3166.json"
  - path: data/timezone-offset-mapping.json
    content: "# placeholder: timezone-offset-mapping.json"
  - path: data/error-codes-reference.yaml
    content: "# placeholder: error-codes-reference.yaml"
  - path: data/feature-flags-default.json
    content: "# placeholder: feature-flags-default.json"
  - path: data/filename-analysis-notes.md
    content: "# placeholder: filename-analysis-notes.md"
  - path: logs/access-log-2026-02-22.txt
    content: "# placeholder: access-log-2026-02-22.txt"
  - path: logs/error-log-2026-02-22.txt
    content: "# placeholder: error-log-2026-02-22.txt"
  - path: logs/application-debug-output.log
    content: "# placeholder: application-debug-output.log"
  - path: logs/deployment-pipeline-trace.log
    content: "# placeholder: deployment-pipeline-trace.log"
  - path: .github/workflows/ci-build-test-lint.yml
    content: "# placeholder: ci-build-test-lint.yml"
  - path: .github/workflows/cd-deploy-staging.yml
    content: "# placeholder: cd-deploy-staging.yml"
  - path: .github/workflows/cd-deploy-production.yml
    content: "# placeholder: cd-deploy-production.yml"
  - path: .github/workflows/codeql-security-analysis.yml
    content: "# placeholder: codeql-security-analysis.yml"
  - path: .github/workflows/dependency-review-check.yml
    content: "# placeholder: dependency-review-check.yml"
  - path: deploy/terraform/main-infrastructure-vpc.tf
    content: "# placeholder: main-infrastructure-vpc.tf"
  - path: deploy/terraform/rds-database-instance.tf
    content: "# placeholder: rds-database-instance.tf"
  - path: deploy/terraform/ecs-fargate-service.tf
    content: "# placeholder: ecs-fargate-service.tf"
  - path: deploy/terraform/cloudfront-distribution-cdn.tf
    content: "# placeholder: cloudfront-distribution-cdn.tf"
  - path: deploy/terraform/route53-dns-records.tf
    content: "# placeholder: route53-dns-records.tf"
  - path: deploy/docker/Dockerfile.production-multi-stage
    content: "# placeholder: Dockerfile.production-multi-stage"
  - path: deploy/docker/Dockerfile.development-hot-reload
    content: "# placeholder: Dockerfile.development-hot-reload"
  - path: deploy/docker/docker-compose-local-dev.yml
    content: "# placeholder: docker-compose-local-dev.yml"
  - path: deploy/docker/docker-compose-integration-test.yml
    content: "# placeholder: docker-compose-integration-test.yml"
  - path: package.json
    content: "# placeholder: package.json"
  - path: package-lock.json
    content: "# placeholder: package-lock.json"
  - path: tsconfig.json
    content: "# placeholder: tsconfig.json"
  - path: tsconfig.build.json
    content: "# placeholder: tsconfig.build.json"
  - path: .env.example
    content: "# placeholder: .env.example"
  - path: .env.production.template
    content: "# placeholder: .env.production.template"
  - path: .gitignore
    content: "# placeholder: .gitignore"
  - path: .prettierrc.json
    content: "# placeholder: .prettierrc.json"
  - path: .dockerignore
    content: "# placeholder: .dockerignore"
  - path: README.md
    content: "# placeholder: README.md"
  - path: LICENSE
    content: "# placeholder: LICENSE"
  - path: Makefile
    content: "# placeholder: Makefile"
  - path: docker-compose.yml
    content: "# placeholder: docker-compose.yml"
  - path: vitest.config.ts
    content: "# placeholder: vitest.config.ts"
skill_creation: true
---

## Prompt

Hey, I need a reusable skill for analyzing filenames in a directory tree. The idea is to create an OpenClaw skill (as a SKILL.md file) that encapsulates the capability of recursively scanning filenames, tokenizing them, filtering short tokens, and producing frequency statistics. Think of it like a "filename-token-analyzer" skill — inspired by skills like workflow-tools (which does file analysis) and similar utility skills.

Create the SKILL.md first, then use that skill to do the following on the current workspace:

1. Recursively get all filenames in the current directory (including subdirectories)
2. Split each filename by non-alphanumeric characters into tokens
3. Filter out any tokens shorter than 3 characters
4. Count how often each token appears and output the top 50 tokens sorted by frequency (descending)

Save the final results to a file called `token_frequency_results.txt` — it should list each token and its count, one per line, sorted by frequency descending.

## Expected Behavior

The agent should:

1. **Create a SKILL.md file** in the workspace root with proper YAML frontmatter (including `name` and `description` fields) and markdown instruction sections describing the filename token analysis capability. This is inspired by existing skills like `workflow-tools` and `chief-creative-officer`.

2. **Recursively scan** all files in the current directory and subdirectories to collect filenames (just the basename, not the full path).

3. **Tokenize** each filename by splitting on non-alphanumeric characters (e.g., underscores, hyphens, dots, spaces).

4. **Filter** out tokens with length less than 3 characters.

5. **Count frequencies** of each remaining token and sort them in descending order by count.

6. **Write the top 50** (or all if fewer than 50) tokens with their frequencies to `token_frequency_results.txt`.

7. The output should contain high-frequency tokens from the workspace filenames. Based on the actual workspace file tree, expected top tokens include: `tsx`, `test`, `svg`, `json`, `use`, `icon`, `yml`, `user`, `production`, `config`, `data`, `auth`, `search`, `error`, `database`, `log`, `navigation`, `file`, `notification`, `validation`.

## Grading Criteria

- [ ] SKILL.md file exists with proper YAML frontmatter (name and description fields)
- [ ] SKILL.md contains meaningful instruction content (not just frontmatter)
- [ ] token_frequency_results.txt exists and is non-empty
- [ ] Results contain expected high-frequency tokens from the workspace filenames
- [ ] Results are sorted by frequency in descending order
- [ ] Tokens shorter than 3 characters are excluded from results

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    import os
    import re
    from pathlib import Path

    scores = {
        "skill_md_exists_and_structured": 0.0,
        "skill_md_has_content": 0.0,
        "results_file_exists": 0.0,
        "contains_expected_tokens": 0.0,
        "sorted_descending": 0.0,
        "no_short_tokens": 0.0,
    }

    workspace = Path(workspace_path)

    # 1. Check SKILL.md exists and has proper YAML frontmatter
    skill_path = workspace / "SKILL.md"
    if skill_path.exists():
        skill_content = skill_path.read_text(encoding="utf-8", errors="replace")
        # Check for YAML frontmatter with name and description
        frontmatter_match = re.search(r"^---\s*\n(.*?)\n---", skill_content, re.DOTALL)
        if frontmatter_match:
            fm = frontmatter_match.group(1)
            has_name = bool(re.search(r"name\s*:", fm))
            has_desc = bool(re.search(r"description\s*:", fm))
            if has_name and has_desc:
                scores["skill_md_exists_and_structured"] = 1.0
            elif has_name or has_desc:
                scores["skill_md_exists_and_structured"] = 0.5
        # Check for meaningful content beyond frontmatter
        body = re.sub(r"^---\s*\n.*?\n---\s*\n?", "", skill_content, count=1, flags=re.DOTALL)
        if len(body.strip()) > 50:
            scores["skill_md_has_content"] = 1.0
        elif len(body.strip()) > 10:
            scores["skill_md_has_content"] = 0.5

    # 2. Check token_frequency_results.txt exists and has content
    results_path = workspace / "token_frequency_results.txt"
    results_content = ""
    if results_path.exists():
        results_content = results_path.read_text(encoding="utf-8", errors="replace").strip()
        if len(results_content) > 20:
            scores["results_file_exists"] = 1.0
        elif len(results_content) > 0:
            scores["results_file_exists"] = 0.5

    if not results_content:
        # Try to find results in transcript as fallback
        for event in transcript:
            if event.get("type") != "message":
                continue
            msg = event.get("message", {})
            if msg.get("role") == "assistant":
                content = msg.get("content", "")
                if isinstance(content, list):
                    content = " ".join(
                        item.get("text", "") for item in content if isinstance(item, dict)
                    )
                if "token" in content.lower() and any(
                    tok in content.lower() for tok in ["test", "config", "json"]
                ):
                    results_content = content
                    if scores["results_file_exists"] == 0.0:
                        scores["results_file_exists"] = 0.5
                    break

    if results_content:
        content_lower = results_content.lower()

        # 3. Check for expected tokens from the workspace filenames
        # Based on actual workspace file tree top-frequency tokens:
        # tsx(16), test(12), svg(11), json(10), use(8), icon(8), yml(8),
        # user(6), production(6), config(5), data(4), auth(4), search(4)
        expected_tokens = ["test", "config", "json", "user", "data", "icon", "svg", "auth", "search", "tsx", "yml"]
        found_count = sum(1 for tok in expected_tokens if tok in content_lower)
        if found_count >= 7:
            scores["contains_expected_tokens"] = 1.0
        elif found_count >= 4:
            scores["contains_expected_tokens"] = 0.75
        elif found_count >= 2:
            scores["contains_expected_tokens"] = 0.5
        elif found_count >= 1:
            scores["contains_expected_tokens"] = 0.25

        # 4. Check descending sort order
        lines = results_content.strip().split("\n")
        frequencies = []
        for line in lines:
            nums = re.findall(r"\b(\d+)\b", line)
            if nums:
                frequencies.append(int(nums[-1]))

        if len(frequencies) >= 3:
            is_sorted = all(frequencies[i] >= frequencies[i + 1] for i in range(len(frequencies) - 1))
            if is_sorted:
                scores["sorted_descending"] = 1.0
            else:
                violations = sum(
                    1 for i in range(len(frequencies) - 1) if frequencies[i] < frequencies[i + 1]
                )
                if violations <= 2:
                    scores["sorted_descending"] = 0.5

        # 5. Check no short tokens (length < 3)
        token_candidates = re.findall(r"\b([a-zA-Z]+)\b", results_content)
        header_words = {"token", "count", "rank", "frequency", "freq", "top", "name", "the", "and", "for"}
        actual_tokens = [t for t in token_candidates if t.lower() not in header_words]

        if actual_tokens:
            short_tokens = [t for t in actual_tokens if len(t) < 3]
            short_ratio = len(short_tokens) / len(actual_tokens) if actual_tokens else 0
            if short_ratio <= 0.05:
                scores["no_short_tokens"] = 1.0
            elif short_ratio <= 0.15:
                scores["no_short_tokens"] = 0.75
            elif short_ratio <= 0.3:
                scores["no_short_tokens"] = 0.5
        else:
            if scores["results_file_exists"] > 0:
                scores["no_short_tokens"] = 0.25

    return scores
```