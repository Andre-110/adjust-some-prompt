# Filename Analysis Notes

## Naming Convention Reference

When analyzing filenames across a project, common patterns emerge:

### Separator Styles
- **kebab-case**: `my-component-name` (most common in web projects)
- **snake_case**: `my_component_name` (common in Python)
- **camelCase**: `myComponentName` (common in Java/JS)
- **dot-separated**: `config.production.json`

### Common Token Categories
1. **Technical terms**: config, utils, service, handler, middleware
2. **Action words**: create, update, delete, fetch, validate
3. **Domain terms**: user, product, order, payment, auth
4. **Modifiers**: global, local, custom, default, extended

## Token Frequency Expectations

In a typical web project, the most frequent filename tokens are usually:
- `config` / `test` / `utils` (infrastructure)
- Domain-specific terms like `user`, `data`, `auth`
- File type indicators like `component`, `service`, `hook`

## Methodology

To extract tokens from filenames:
1. Strip file extensions
2. Split on non-alphanumeric characters (hyphens, underscores, dots)
3. Normalize case (lowercase)
4. Filter short tokens (length < 3)
5. Count frequencies
