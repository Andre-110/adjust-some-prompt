---
id: task_00460_python_project_scaffold_with_tests
name: Python 3 Project Scaffold with Tests and Skill
category: System Administration
subcategory: Software and Environment Management
difficulty: easy
grading_type: automated
grading_weights: {automated: 1.0}
timeout_seconds: 600
input_modality: text-only
external_dependency: none
workspace_files: []
skill_creation: true
---

## Prompt

Hey, I need a reusable skill for scaffolding Python 3 projects. Create a SKILL.md file that describes how to generate a standard Python 3 project directory structure — inspired by skills like mqttasgi, fennecseo-audit, and local-vosk that each encapsulate a focused capability. The skill should cover creating a src-layout package, a tests/ directory with __init__.py and a sample test file, a pyproject.toml, README.md, LICENSE, and .gitignore.

Once you've written the SKILL.md, go ahead and use that skill to actually generate a complete Python 3 project called "python-project" right here in the workspace. Make sure it includes:

- A `src/myproject/` package directory with `__init__.py` and at least one module (e.g., `core.py`) containing a simple function
- A `tests/` directory with `__init__.py` and a sample test file (like `test_core.py`) that actually tests the function from core.py
- A `pyproject.toml` with basic project metadata
- A `README.md`
- A `LICENSE` file
- A `.gitignore`

I'd also love a `tests/conftest.py` if you can. Thanks!

## Expected Behavior

The agent should:

1. **Create a SKILL.md** in the workspace root that describes a reusable "Python Project Scaffolding" skill. It should have YAML frontmatter with `name:` and `description:` fields, followed by markdown sections with instructions on how to scaffold a Python 3 project (similar in spirit to how mqttasgi, fennecseo-audit, and local-vosk each encapsulate a focused capability).

2. **Generate the project structure** under `python-project/` including:
   - `python-project/src/myproject/__init__.py` — package init file
   - `python-project/src/myproject/core.py` — a module with at least one function
   - `python-project/tests/__init__.py` — test package init
   - `python-project/tests/test_core.py` — a sample test file that imports from myproject and contains at least one test function
   - `python-project/tests/conftest.py` — pytest configuration/fixtures file
   - `python-project/pyproject.toml` — build/project metadata
   - `python-project/README.md` — project readme
   - `python-project/LICENSE` — license file
   - `python-project/.gitignore` — git ignore rules

3. The test file should contain valid Python test code (functions starting with `test_`).

## Grading Criteria

- [ ] SKILL.md exists with proper YAML frontmatter (name and description)
- [ ] SKILL.md has meaningful instruction sections in markdown
- [ ] src/myproject/__init__.py exists
- [ ] src/myproject/core.py exists and contains a function definition
- [ ] tests/__init__.py exists
- [ ] tests/test_core.py exists and contains at least one test function
- [ ] tests/conftest.py exists
- [ ] pyproject.toml exists and contains project metadata
- [ ] README.md exists and is non-empty
- [ ] LICENSE file exists
- [ ] .gitignore file exists

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    import os
    import re
    from pathlib import Path

    ws = Path(workspace_path)
    scores = {}

    # 1. SKILL.md exists with YAML frontmatter containing name and description
    skill_md = ws / "SKILL.md"
    skill_score = 0.0
    if skill_md.exists():
        content = skill_md.read_text(errors="replace")
        # Check for YAML frontmatter with name and description
        fm_match = re.search(r'^---\s*\n(.*?)\n---', content, re.DOTALL)
        if fm_match:
            fm = fm_match.group(1)
            has_name = bool(re.search(r'^\s*name\s*:', fm, re.MULTILINE))
            has_desc = bool(re.search(r'^\s*description\s*:', fm, re.MULTILINE))
            if has_name and has_desc:
                skill_score = 1.0
            elif has_name or has_desc:
                skill_score = 0.5
    scores["skill_md_frontmatter"] = skill_score

    # 2. SKILL.md has meaningful instruction sections (headings + content)
    skill_content_score = 0.0
    if skill_md.exists():
        content = skill_md.read_text(errors="replace")
        headings = re.findall(r'^#{1,3}\s+.+', content, re.MULTILINE)
        if len(headings) >= 2 and len(content) > 200:
            skill_content_score = 1.0
        elif len(headings) >= 1 and len(content) > 100:
            skill_content_score = 0.5
    scores["skill_md_content"] = skill_content_score

    # 3. src/myproject/__init__.py exists
    init_py = ws / "python-project" / "src" / "myproject" / "__init__.py"
    scores["package_init"] = 1.0 if init_py.exists() else 0.0

    # 4. src/myproject/core.py exists and contains a function definition
    core_py = ws / "python-project" / "src" / "myproject" / "core.py"
    core_score = 0.0
    if core_py.exists():
        core_content = core_py.read_text(errors="replace")
        if re.search(r'^\s*def\s+\w+\s*\(', core_content, re.MULTILINE):
            core_score = 1.0
        else:
            core_score = 0.3  # file exists but no function
    scores["core_module"] = core_score

    # 5. tests/__init__.py exists
    tests_init = ws / "python-project" / "tests" / "__init__.py"
    scores["tests_init"] = 1.0 if tests_init.exists() else 0.0

    # 6. tests/test_core.py exists and contains at least one test function
    test_core = ws / "python-project" / "tests" / "test_core.py"
    test_score = 0.0
    if test_core.exists():
        test_content = test_core.read_text(errors="replace")
        test_funcs = re.findall(r'^\s*def\s+test_\w+\s*\(', test_content, re.MULTILINE)
        if len(test_funcs) >= 1:
            test_score = 1.0
        else:
            test_score = 0.3  # file exists but no test functions
    scores["test_file"] = test_score

    # 7. tests/conftest.py exists
    conftest = ws / "python-project" / "tests" / "conftest.py"
    scores["conftest"] = 1.0 if conftest.exists() else 0.0

    # 8. pyproject.toml exists and contains project metadata
    pyproject = ws / "python-project" / "pyproject.toml"
    pyproject_score = 0.0
    if pyproject.exists():
        pp_content = pyproject.read_text(errors="replace")
        has_project = bool(re.search(r'\[project\]', pp_content))
        has_build = bool(re.search(r'\[build-system\]', pp_content))
        if has_project and has_build:
            pyproject_score = 1.0
        elif has_project or has_build:
            pyproject_score = 0.5
        else:
            pyproject_score = 0.2  # file exists but minimal content
    scores["pyproject_toml"] = pyproject_score

    # 9. README.md exists and is non-empty
    readme = ws / "python-project" / "README.md"
    readme_score = 0.0
    if readme.exists():
        readme_content = readme.read_text(errors="replace").strip()
        if len(readme_content) > 20:
            readme_score = 1.0
        elif len(readme_content) > 0:
            readme_score = 0.5
    scores["readme"] = readme_score

    # 10. LICENSE file exists
    license_file = ws / "python-project" / "LICENSE"
    scores["license_file"] = 1.0 if license_file.exists() else 0.0

    # 11. .gitignore file exists
    gitignore = ws / "python-project" / ".gitignore"
    scores["gitignore"] = 1.0 if gitignore.exists() else 0.0

    return scores
```