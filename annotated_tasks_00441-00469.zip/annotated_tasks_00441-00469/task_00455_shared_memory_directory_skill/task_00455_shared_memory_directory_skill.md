---
id: task_00455_shared_memory_directory_skill
name: Shared Memory Directory with Skill Creation
category: Knowledge and Memory Management
subcategory: Memory and Context Management
difficulty: easy
grading_type: automated
grading_weights: {automated: 1.0}
timeout_seconds: 600
input_modality: text-only
external_dependency: none
workspace_files: []
skill_creation: true
---

## Prompt

Hey, I want to set up a shared memory directory that multiple AI assistants can use to exchange information and coordinate. Before you do that though, I'd like you to create a reusable OpenClaw skill (as a SKILL.md file) that encapsulates the process of setting up shared memory spaces — think of it like a "shared-memory-setup" skill inspired by skills like milkee or checkmate. The skill should describe how to create shared directories, what conventions to follow, and what documentation to include.

Once you've got the skill defined, go ahead and use it: create a `~/.openclaw/shared/` directory and put a `README.md` inside it that explains the purpose of the shared memory space, suggests a directory structure (like facts.md, preferences.md, projects/, inbox/, etc.), and lays out usage conventions for multiple assistants (like read-before-write, no sensitive data, sign your entries, etc.).

## Expected Behavior

The agent should:

1. **Create a SKILL.md file** in the workspace root that defines a reusable "shared-memory-setup" skill. The file should have YAML frontmatter with at least `name` and `description` fields, followed by markdown sections with instructions on how to set up shared memory directories, what files to include, and what conventions to follow. This is inspired by existing skills like milkee, checkmate, and call-claude-sonnet-4-agent.

2. **Create the directory `~/.openclaw/shared/`** (relative to the workspace, so the path would be `.openclaw/shared/`).

3. **Create a `README.md` file inside `.openclaw/shared/`** that includes:
   - A description of the purpose (shared information exchange between multiple assistants)
   - Suggested directory structure or files (e.g., facts.md, preferences.md, projects/, inbox/)
   - Usage conventions (e.g., read before writing, no sensitive data, sign entries)

## Grading Criteria

- [ ] SKILL.md exists with proper YAML frontmatter (name and description fields)
- [ ] SKILL.md contains meaningful instruction sections in markdown
- [ ] The `.openclaw/shared/` directory exists
- [ ] `.openclaw/shared/README.md` exists
- [ ] README.md describes the purpose of the shared memory space
- [ ] README.md suggests a directory structure or file organization
- [ ] README.md includes usage conventions for multiple assistants

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    import os
    import re

    scores = {
        "skill_md_exists_and_frontmatter": 0.0,
        "skill_md_has_instructions": 0.0,
        "shared_directory_exists": 0.0,
        "readme_exists": 0.0,
        "readme_describes_purpose": 0.0,
        "readme_suggests_structure": 0.0,
        "readme_includes_conventions": 0.0,
    }

    # 1. Check SKILL.md exists and has proper YAML frontmatter
    skill_path = os.path.join(workspace_path, "SKILL.md")
    if os.path.isfile(skill_path):
        try:
            with open(skill_path, "r", encoding="utf-8") as f:
                skill_content = f.read()
            # Check for YAML frontmatter with name and description
            fm_match = re.match(r"^---\s*\n(.*?)\n---", skill_content, re.DOTALL)
            if fm_match:
                fm_text = fm_match.group(1).lower()
                has_name = "name:" in fm_text
                has_desc = "description:" in fm_text
                if has_name and has_desc:
                    scores["skill_md_exists_and_frontmatter"] = 1.0
                elif has_name or has_desc:
                    scores["skill_md_exists_and_frontmatter"] = 0.5
        except Exception:
            pass

        # 2. Check SKILL.md has meaningful instruction sections
        try:
            # Look for markdown headings (##) indicating instruction sections
            headings = re.findall(r"^#{1,3}\s+.+", skill_content, re.MULTILINE)
            # Content length check (at least some substance beyond frontmatter)
            content_after_fm = re.sub(r"^---.*?---\s*", "", skill_content, count=1, flags=re.DOTALL)
            if len(headings) >= 2 and len(content_after_fm.strip()) > 100:
                scores["skill_md_has_instructions"] = 1.0
            elif len(headings) >= 1 and len(content_after_fm.strip()) > 50:
                scores["skill_md_has_instructions"] = 0.5
        except Exception:
            pass

    # 3. Check .openclaw/shared/ directory exists
    shared_dir = os.path.join(workspace_path, ".openclaw", "shared")
    if os.path.isdir(shared_dir):
        scores["shared_directory_exists"] = 1.0

    # 4. Check README.md exists in shared directory
    readme_path = os.path.join(shared_dir, "README.md")
    readme_content = ""
    if os.path.isfile(readme_path):
        scores["readme_exists"] = 1.0
        try:
            with open(readme_path, "r", encoding="utf-8") as f:
                readme_content = f.read().lower()
        except Exception:
            pass

    if readme_content:
        # 5. README describes purpose of shared memory
        purpose_keywords = ["shared", "memory", "assistant", "agent", "exchange", "information",
                            "communicate", "coordinate", "collaboration", "share"]
        purpose_hits = sum(1 for kw in purpose_keywords if kw in readme_content)
        if purpose_hits >= 3:
            scores["readme_describes_purpose"] = 1.0
        elif purpose_hits >= 1:
            scores["readme_describes_purpose"] = 0.5

        # 6. README suggests directory structure or file organization
        structure_keywords = ["facts", "preferences", "projects", "inbox", "directory",
                              "structure", "folder", "file", ".md", "organize"]
        structure_hits = sum(1 for kw in structure_keywords if kw in readme_content)
        if structure_hits >= 3:
            scores["readme_suggests_structure"] = 1.0
        elif structure_hits >= 1:
            scores["readme_suggests_structure"] = 0.5

        # 7. README includes usage conventions
        convention_keywords = ["convention", "rule", "read before", "sensitive", "sign",
                               "write", "guideline", "best practice", "do not", "avoid",
                               "before writing", "attribution"]
        convention_hits = sum(1 for kw in convention_keywords if kw in readme_content)
        if convention_hits >= 3:
            scores["readme_includes_conventions"] = 1.0
        elif convention_hits >= 1:
            scores["readme_includes_conventions"] = 0.5

    return scores
```