| 序号 | 修改项 | 修改原因 |
|------|--------|----------|
| 1 | frontmatter 补充 `grading_weights: {automated: 1.0}` | `grading_type: automated` 但 frontmatter 中缺少 `grading_weights` 字段；无 LLM Judge Rubric，automated 权重应为 1.0，automated + llmjudge 之和须等于 1.0 |