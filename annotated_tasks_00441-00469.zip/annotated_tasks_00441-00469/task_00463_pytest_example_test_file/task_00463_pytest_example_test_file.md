---
id: task_00463_pytest_example_test_file
name: Generate a Simple Pytest Example Test File
category: System Administration
subcategory: Software and Environment Management
difficulty: easy
grading_type: automated
grading_weights: {automated: 1.0}
timeout_seconds: 600
input_modality: text-only
external_dependency: none
workspace_files: []
skill_creation: false
---

## Prompt

Generate a simple Python pytest example test file that I can use for testing purposes.

## Expected Behavior

The agent should create a Python test file (e.g., `test_example.py`) in the workspace that contains valid pytest test functions. The file should demonstrate several common pytest patterns including:

1. **Basic assertions** — simple tests using `assert` statements (e.g., arithmetic checks, string containment, list length).
2. **Exception capture** — at least one test using `pytest.raises` to verify that an expected exception is raised (e.g., `ZeroDivisionError`).
3. **Multiple test functions** — the file should contain at least 3 distinct test functions to serve as a useful example.
4. **Proper naming** — all test functions should follow the `test_` prefix convention so pytest can discover them.

The resulting file should be syntactically valid Python that can be executed by `pytest` without errors.

## Grading Criteria

- [ ] A test file with a name matching `test_*.py` exists in the workspace
- [ ] The file contains at least 3 test functions following the `test_` naming convention
- [ ] The file contains basic `assert` statements
- [ ] The file contains at least one exception/error handling test (e.g., `pytest.raises`)
- [ ] The file is syntactically valid Python

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    import os
    import re
    import ast
    from pathlib import Path

    scores = {
        "test_file_exists": 0.0,
        "has_multiple_test_functions": 0.0,
        "has_basic_assertions": 0.0,
        "has_exception_test": 0.0,
        "valid_python_syntax": 0.0,
    }

    workspace = Path(workspace_path)

    # Find any test_*.py file in the workspace (non-recursive top-level or recursive)
    test_files = list(workspace.glob("test_*.py"))
    if not test_files:
        # Also check tests/ subdirectory
        test_files = list(workspace.glob("tests/test_*.py"))
    if not test_files:
        # Broad recursive search
        test_files = list(workspace.rglob("test_*.py"))

    if not test_files:
        return scores

    # Use the first matching test file
    test_file = test_files[0]
    scores["test_file_exists"] = 1.0

    try:
        content = test_file.read_text(encoding="utf-8")
    except Exception:
        return scores

    # Check valid Python syntax
    try:
        tree = ast.parse(content)
        scores["valid_python_syntax"] = 1.0
    except SyntaxError:
        # If syntax is invalid, we can still do regex checks but mark syntax as 0
        tree = None

    # Count test functions (def test_...)
    test_func_pattern = re.compile(r"^\s*def\s+(test_\w+)\s*\(", re.MULTILINE)
    test_functions = test_func_pattern.findall(content)

    if len(test_functions) >= 3:
        scores["has_multiple_test_functions"] = 1.0
    elif len(test_functions) == 2:
        scores["has_multiple_test_functions"] = 0.5
    elif len(test_functions) == 1:
        scores["has_multiple_test_functions"] = 0.25

    # Check for basic assert statements
    assert_pattern = re.compile(r"^\s*assert\s+", re.MULTILINE)
    if assert_pattern.search(content):
        scores["has_basic_assertions"] = 1.0

    # Check for exception handling test (pytest.raises or try/except in test context)
    if "pytest.raises" in content:
        scores["has_exception_test"] = 1.0
    elif re.search(r"with\s+.*raises", content):
        scores["has_exception_test"] = 0.75
    elif "Exception" in content or "Error" in content:
        scores["has_exception_test"] = 0.25

    return scores
```