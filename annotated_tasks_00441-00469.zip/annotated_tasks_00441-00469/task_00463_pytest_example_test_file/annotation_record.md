| 序号 | 修改项 | 修改原因 |
|------|--------|----------|
| 1 | frontmatter 补充 `grading_weights: {automated: 1.0}` | `grading_type: automated` 但 frontmatter 中缺少 `grading_weights` 字段；无 LLM Judge Rubric，automated 权重应为 1.0，automated + llmjudge 之和须等于 1.0 |
| 2 | `assets/pyproject.toml`：将 `build-backend` 从 `"setuptools.backends._legacy:_Backend"` 修正为 `"setuptools.build_meta"` | 原值引用了 setuptools 的内部私有 API，是非标准写法，实际构建会失败；标准写法为 `setuptools.build_meta`，符合 PEP 517 规范；与 task_00460 中同一问题一致，Agent 若参考此文件可能生成错误的项目配置 |