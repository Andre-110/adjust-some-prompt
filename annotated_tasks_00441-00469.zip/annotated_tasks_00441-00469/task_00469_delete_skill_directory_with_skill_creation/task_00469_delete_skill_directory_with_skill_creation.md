---
id: task_00469_delete_skill_directory_with_skill_creation
name: Delete Installed Skill Directory with Verification
category: System Administration
subcategory: Storage and Data Management
difficulty: easy
grading_type: automated
grading_weights: {automated: 1.0}
timeout_seconds: 600
input_modality: text-only
external_dependency: none
skill_creation: true
workspace_files:
  - path: .openclaw/workspace/skills/tushare-finance/skill.json
    content: |
      {
        "name": "tushare-finance",
        "version": "1.0.0",
        "description": "A skill for fetching financial data via the Tushare API."
      }
  - path: .openclaw/workspace/skills/tushare-finance/main.py
    content: |
      # Tushare Finance Skill - Main Entry Point
      def run():
          print("Fetching financial data...")
  - path: .openclaw/workspace/skills/tushare-finance/README.md
    content: |
      # Tushare Finance Skill
      This skill provides access to financial market data through the Tushare API.
---

## Prompt

Hey, I need a reusable skill for managing installed skills in my OpenClaw workspace — specifically for safely removing skill directories and verifying they're gone. Create it as a SKILL.md file in the workspace root, inspired by skills like auteng-docs-curl-publish (which publishes docs via curl), citrineos-assistant (which manages CitrineOS installations), and telnyx-network (which manages network infrastructure). The skill should encapsulate the capability of deleting a skill directory from the workspace and confirming the deletion.

Once you've created the SKILL.md, use it to delete the installed tushare-finance skill from my workspace (remove the `.openclaw/workspace/skills/tushare-finance` directory) and verify it has been deleted.

## Expected Behavior

The agent should:

1. Create a `SKILL.md` file in the workspace root that describes a reusable skill for removing installed skills from the OpenClaw workspace. The file should have YAML frontmatter with at least `name` and `description` fields, followed by markdown instruction sections explaining how to safely delete a skill directory and verify the deletion. This is inspired by similar management/infrastructure skills like citrineos-assistant and telnyx-network.

2. Delete the entire `.openclaw/workspace/skills/tushare-finance` directory (including all files: skill.json, main.py, README.md).

3. Verify that the directory no longer exists and communicate the result.

4. After completion, the `tushare-finance` directory and its contents should not exist, and the SKILL.md file should be present in the workspace.

## Grading Criteria

- [ ] SKILL.md file exists in the workspace root
- [ ] SKILL.md has valid YAML frontmatter with name and description fields
- [ ] SKILL.md contains meaningful instruction content (not just frontmatter)
- [ ] The tushare-finance directory has been deleted
- [ ] The tushare-finance skill files (skill.json, main.py, README.md) no longer exist
- [ ] The agent confirms deletion in the transcript

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    import os
    import re
    from pathlib import Path

    scores = {
        "skill_md_exists": 0.0,
        "skill_md_frontmatter": 0.0,
        "skill_md_content": 0.0,
        "tushare_directory_deleted": 0.0,
        "tushare_files_deleted": 0.0,
        "agent_confirms_deletion": 0.0,
    }

    workspace = Path(workspace_path)

    # 1. Check SKILL.md exists
    skill_md_path = workspace / "SKILL.md"
    if skill_md_path.exists():
        scores["skill_md_exists"] = 1.0

        content = skill_md_path.read_text(encoding="utf-8", errors="replace")

        # 2. Check YAML frontmatter with name and description
        frontmatter_match = re.search(r"^---\s*\n(.*?)\n---", content, re.DOTALL)
        if frontmatter_match:
            fm = frontmatter_match.group(1)
            has_name = bool(re.search(r"^\s*name\s*:", fm, re.MULTILINE))
            has_desc = bool(re.search(r"^\s*description\s*:", fm, re.MULTILINE))
            if has_name and has_desc:
                scores["skill_md_frontmatter"] = 1.0
            elif has_name or has_desc:
                scores["skill_md_frontmatter"] = 0.5

        # 3. Check meaningful content beyond frontmatter
        body = re.sub(r"^---\s*\n.*?\n---\s*\n?", "", content, count=1, flags=re.DOTALL)
        body_stripped = body.strip()
        if len(body_stripped) > 100:
            scores["skill_md_content"] = 1.0
        elif len(body_stripped) > 30:
            scores["skill_md_content"] = 0.5

    # 4. Check tushare-finance directory is deleted
    tushare_dir = workspace / ".openclaw" / "workspace" / "skills" / "tushare-finance"
    if not tushare_dir.exists():
        scores["tushare_directory_deleted"] = 1.0

    # 5. Check individual tushare files are deleted
    files_to_check = [
        tushare_dir / "skill.json",
        tushare_dir / "main.py",
        tushare_dir / "README.md",
    ]
    deleted_count = sum(1 for f in files_to_check if not f.exists())
    scores["tushare_files_deleted"] = deleted_count / len(files_to_check)

    # 6. Check agent confirms deletion in transcript
    for event in transcript:
        if event.get("type") != "message":
            continue
        msg = event.get("message", {})
        if msg.get("role") == "assistant":
            # Handle both string and list content
            text = ""
            raw = msg.get("content", "")
            if isinstance(raw, str):
                text = raw
            elif isinstance(raw, list):
                for block in raw:
                    if isinstance(block, dict) and block.get("type") == "text":
                        text += block.get("text", "") + " "
            text_lower = text.lower()
            if any(kw in text_lower for kw in ["deleted", "removed", "no longer exists", "successfully", "verified", "gone"]):
                scores["agent_confirms_deletion"] = 1.0
                break

    return scores
```