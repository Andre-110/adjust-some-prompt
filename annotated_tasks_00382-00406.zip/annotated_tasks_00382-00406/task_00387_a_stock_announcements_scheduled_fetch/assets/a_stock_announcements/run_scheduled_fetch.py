#!/usr/bin/env python3
"""
Scheduled A-Stock Announcements Fetcher
Runs every 15 minutes during trading hours to pull latest
company announcements from configured data sources.

Sources:
  - cninfo (CNINFO disclosure platform API)
  - eastmoney (East Money announcement feed)

Usage:
  python3 run_scheduled_fetch.py              # fetch latest (default: last 15min window)
  python3 run_scheduled_fetch.py --full-day   # fetch entire day
  python3 run_scheduled_fetch.py --backfill 3 # backfill last N days
"""

import os
import sys
import json
import time
import logging
import hashlib
import argparse
from datetime import datetime, timedelta
from pathlib import Path

# ── project paths ──────────────────────────────────────────────
BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
LOG_DIR = BASE_DIR / "logs"
CONFIG_PATH = BASE_DIR / "config.yaml"
STATE_PATH = BASE_DIR / "data" / ".fetch_state.json"

DATA_DIR.mkdir(exist_ok=True)
LOG_DIR.mkdir(exist_ok=True)

# ── logging ────────────────────────────────────────────────────
log_file = LOG_DIR / f"fetch_{datetime.utcnow().strftime('%Y%m%d')}.log"
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s - %(message)s",
    handlers=[
        logging.FileHandler(log_file, encoding="utf-8"),
        logging.StreamHandler(sys.stdout),
    ],
)
logger = logging.getLogger("a_stock_fetch")

# ── config loader ──────────────────────────────────────────────
def load_config():
    """Load YAML config; fall back to defaults if missing."""
    try:
        import yaml
        with open(CONFIG_PATH, "r", encoding="utf-8") as f:
            cfg = yaml.safe_load(f)
        logger.info("Loaded config from %s", CONFIG_PATH)
        return cfg
    except FileNotFoundError:
        logger.warning("Config not found at %s — using defaults", CONFIG_PATH)
        return {
            "sources": {
                "cninfo": {
                    "enabled": True,
                    "base_url": "http://www.cninfo.com.cn/new/hisAnnouncement/query",
                    "page_size": 30,
                    "timeout": 20,
                },
                "eastmoney": {
                    "enabled": False,
                    "base_url": "https://np-anotice-stock.eastmoney.com/api/security/ann",
                    "page_size": 50,
                    "timeout": 20,
                },
            },
            "storage": {"format": "jsonl", "deduplicate": True},
            "filters": {
                "categories": [],
                "stock_codes": [],
                "keywords": [],
            },
            "notifications": {"enabled": False, "channel": "telegram"},
        }
    except Exception as exc:
        logger.error("Failed to parse config: %s", exc)
        sys.exit(1)


# ── state management ───────────────────────────────────────────
def load_state():
    if STATE_PATH.exists():
        with open(STATE_PATH, "r") as f:
            return json.load(f)
    return {"last_fetch_ts": None, "seen_hashes": []}


def save_state(state):
    # keep only last 5000 hashes to bound file size
    state["seen_hashes"] = state["seen_hashes"][-5000:]
    with open(STATE_PATH, "w") as f:
        json.dump(state, f, ensure_ascii=False, indent=2)


def announcement_hash(ann: dict) -> str:
    raw = f"{ann.get('stock_code','')}-{ann.get('title','')}-{ann.get('publish_time','')}"
    return hashlib.md5(raw.encode()).hexdigest()


# ── source: cninfo ─────────────────────────────────────────────
def fetch_cninfo(cfg: dict, start_dt: datetime, end_dt: datetime):
    """Fetch announcements from CNINFO disclosure API."""
    import requests

    src = cfg["sources"]["cninfo"]
    if not src.get("enabled"):
        logger.info("cninfo source disabled — skipping")
        return []

    date_str = start_dt.strftime("%Y-%m-%d")
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
        "Accept": "application/json",
        "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
        "Referer": "http://www.cninfo.com.cn/new/commonUrl?url=disclosure/list/notice",
    }

    results = []
    page = 1
    max_pages = 10

    while page <= max_pages:
        payload = {
            "pageNum": page,
            "pageSize": src.get("page_size", 30),
            "column": "szse",
            "tabName": "fulltext",
            "plate": "",
            "stock": "",
            "searchkey": "",
            "secid": "",
            "category": "",
            "trade": "",
            "seDate": f"{date_str}~{date_str}",
            "sortName": "",
            "sortType": "",
            "isHLtitle": "true",
        }

        logger.info("cninfo: fetching page %d for %s", page, date_str)
        try:
            resp = requests.post(
                src["base_url"],
                data=payload,
                headers=headers,
                timeout=src.get("timeout", 20),
            )
            resp.raise_for_status()
            data = resp.json()
        except requests.RequestException as e:
            logger.error("cninfo request failed (page %d): %s", page, e)
            break

        announcements = data.get("announcements", [])
        if not announcements:
            break

        for item in announcements:
            pub_ts = item.get("announcementTime", 0)
            if pub_ts:
                pub_dt = datetime.fromtimestamp(pub_ts / 1000)
            else:
                pub_dt = start_dt

            # filter by time window
            if pub_dt < start_dt or pub_dt > end_dt:
                continue

            ann = {
                "source": "cninfo",
                "stock_code": (item.get("secCode") or "").strip(),
                "stock_name": (item.get("secName") or "").strip(),
                "title": (item.get("announcementTitle") or "").strip(),
                "category": item.get("announcementType", ""),
                "publish_time": pub_dt.strftime("%Y-%m-%d %H:%M:%S"),
                "url": f"http://static.cninfo.com.cn/{item.get('adjunctUrl', '')}",
                "fetched_at": datetime.utcnow().isoformat(),
            }
            results.append(ann)

        has_more = data.get("hasMore", False)
        if not has_more:
            break
        page += 1
        time.sleep(0.5)

    logger.info("cninfo: fetched %d announcements", len(results))
    return results


# ── source: eastmoney ──────────────────────────────────────────
def fetch_eastmoney(cfg: dict, start_dt: datetime, end_dt: datetime):
    """Fetch announcements from East Money API."""
    import requests

    src = cfg["sources"]["eastmoney"]
    if not src.get("enabled"):
        logger.info("eastmoney source disabled — skipping")
        return []

    date_str = start_dt.strftime("%Y-%m-%d")
    params = {
        "sr": -1,
        "page_size": src.get("page_size", 50),
        "page_index": 1,
        "ann_type": "A",
        "client_source": "web",
        "f_node": "0",
        "s_node": "0",
        "begin_time": date_str,
        "end_time": date_str,
    }

    results = []
    try:
        resp = requests.get(
            src["base_url"],
            params=params,
            timeout=src.get("timeout", 20),
        )
        resp.raise_for_status()
        data = resp.json()
    except Exception as e:
        logger.error("eastmoney request failed: %s", e)
        return results

    for item in data.get("data", {}).get("list", []):
        ann = {
            "source": "eastmoney",
            "stock_code": item.get("codes", [{}])[0].get("stock_code", "") if item.get("codes") else "",
            "stock_name": item.get("codes", [{}])[0].get("short_name", "") if item.get("codes") else "",
            "title": item.get("title", ""),
            "category": item.get("columns", [{}])[0].get("column_name", "") if item.get("columns") else "",
            "publish_time": item.get("display_time", ""),
            "url": f"https://data.eastmoney.com/notices/detail/{item.get('art_code', '')}.html",
            "fetched_at": datetime.utcnow().isoformat(),
        }
        results.append(ann)

    logger.info("eastmoney: fetched %d announcements", len(results))
    return results


# ── filters ────────────────────────────────────────────────────
def apply_filters(announcements: list, filters: dict) -> list:
    """Apply optional category/stock/keyword filters."""
    if not any(filters.values()):
        return announcements

    filtered = []
    cats = set(filters.get("categories", []))
    codes = set(filters.get("stock_codes", []))
    keywords = [kw.lower() for kw in filters.get("keywords", [])]

    for ann in announcements:
        if cats and ann.get("category") not in cats:
            continue
        if codes and ann.get("stock_code") not in codes:
            continue
        if keywords and not any(kw in ann.get("title", "").lower() for kw in keywords):
            continue
        filtered.append(ann)

    logger.info("Filters applied: %d → %d", len(announcements), len(filtered))
    return filtered


# ── storage ────────────────────────────────────────────────────
def store_announcements(announcements: list, cfg: dict, state: dict):
    """Append announcements to daily JSONL file, deduplicating by hash."""
    if not announcements:
        logger.info("Nothing to store")
        return 0

    dedupe = cfg.get("storage", {}).get("deduplicate", True)
    today = datetime.utcnow().strftime("%Y%m%d")
    out_path = DATA_DIR / f"announcements_{today}.jsonl"

    new_count = 0
    with open(out_path, "a", encoding="utf-8") as f:
        for ann in announcements:
            h = announcement_hash(ann)
            if dedupe and h in state["seen_hashes"]:
                continue
            state["seen_hashes"].append(h)
            f.write(json.dumps(ann, ensure_ascii=False) + "\n")
            new_count += 1

    logger.info("Stored %d new announcements → %s", new_count, out_path)
    return new_count


# ── notifications ──────────────────────────────────────────────
def send_notification(count: int, cfg: dict):
    """Stub for notification dispatch (telegram/webhook/etc)."""
    notif = cfg.get("notifications", {})
    if not notif.get("enabled") or count == 0:
        return
    channel = notif.get("channel", "telegram")
    logger.info(
        "Would notify via %s: %d new announcements fetched", channel, count
    )
    # In production this would call the OpenClaw message tool or a webhook


# ── main ───────────────────────────────────────────────────────
def main():
    parser = argparse.ArgumentParser(description="A-Stock Announcements Fetcher")
    parser.add_argument("--full-day", action="store_true", help="Fetch entire day")
    parser.add_argument("--backfill", type=int, default=0, help="Backfill N days")
    args = parser.parse_args()

    cfg = load_config()
    state = load_state()

    now = datetime.utcnow()

    if args.backfill > 0:
        for days_ago in range(args.backfill, 0, -1):
            day = now - timedelta(days=days_ago)
            start = day.replace(hour=0, minute=0, second=0)
            end = day.replace(hour=23, minute=59, second=59)
            logger.info("=== Backfill: %s ===", start.strftime("%Y-%m-%d"))
            all_ann = fetch_cninfo(cfg, start, end) + fetch_eastmoney(cfg, start, end)
            all_ann = apply_filters(all_ann, cfg.get("filters", {}))
            store_announcements(all_ann, cfg, state)
            time.sleep(2)
    elif args.full_day:
        start = now.replace(hour=0, minute=0, second=0)
        end = now
        logger.info("=== Full day fetch: %s ===", start.strftime("%Y-%m-%d"))
        all_ann = fetch_cninfo(cfg, start, end) + fetch_eastmoney(cfg, start, end)
        all_ann = apply_filters(all_ann, cfg.get("filters", {}))
        count = store_announcements(all_ann, cfg, state)
        send_notification(count, cfg)
    else:
        # default: last 15-minute window
        start = now - timedelta(minutes=15)
        end = now
        logger.info("=== 15min fetch: %s → %s ===", start.strftime("%H:%M"), end.strftime("%H:%M"))
        all_ann = fetch_cninfo(cfg, start, end) + fetch_eastmoney(cfg, start, end)
        all_ann = apply_filters(all_ann, cfg.get("filters", {}))
        count = store_announcements(all_ann, cfg, state)
        send_notification(count, cfg)

    state["last_fetch_ts"] = now.isoformat()
    save_state(state)
    logger.info("Done. State saved.")


if __name__ == "__main__":
    main()
