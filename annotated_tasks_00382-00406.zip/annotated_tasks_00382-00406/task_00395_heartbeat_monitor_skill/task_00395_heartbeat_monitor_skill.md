---
id: task_00395_heartbeat_monitor_skill
name: Heartbeat Monitor Skill Creation and Workspace Bootstrap
category: System Administration
subcategory: System Operations and Monitoring
difficulty: medium
grading_type: hybrid
grading_weights: {automated: 0.4, llm_judge: 0.6}
timeout_seconds: 600
input_modality: text-only
external_dependency: none
skill_creation: true
workspace_files:
  - source: HEARTBEAT.md
    dest: HEARTBEAT.md
  - source: heartbeat_state.json
    dest: heartbeat_state.json
  - source: logs/heartbeat_monitor.log
    dest: logs/heartbeat_monitor.log
  - source: logs/china_mobile_announcements.log
    dest: logs/china_mobile_announcements.log
  - source: logs/scraper_debug.log
    dest: logs/scraper_debug.log
  - source: logs/system_resources.log
    dest: logs/system_resources.log
  - source: monitoring_config.yaml
    dest: monitoring_config.yaml
---

## Prompt

Hey! I need you to help me set up a reusable skill for monitoring workspace heartbeats. Think of it like a system health check skill — similar to how iCloud Reminders or calendar sync skills work, but for tracking workspace liveness and bootstrapping.

First, create a skill file at `skills/heartbeat-monitor/SKILL.md` that describes a "heartbeat-monitor" skill. It should have YAML frontmatter with a name and description, then sections explaining how to: (1) read heartbeat logs, (2) check system health status, (3) bootstrap a fresh workspace with identity files and git, and (4) update heartbeat state.

Then actually USE that skill to bootstrap this workspace:
- Initialize a git repo here
- Create the standard identity/docs files: IDENTITY.md, USER.md, AGENTS.md, SOUL.md, TOOLS.md, and BOOTSTRAP.md
- Create `.openclaw/workspace-state.json` to mark the workspace as initialized
- Read the existing log files, HEARTBEAT.md, monitoring_config.yaml, and heartbeat_state.json to understand the current state

Just get everything set up like it's a fresh first run. Thanks!

## Expected Behavior

The agent should:

1. **Create `skills/heartbeat-monitor/SKILL.md`** with proper YAML frontmatter (containing `name` and `description` fields) and markdown instruction sections covering heartbeat monitoring, log reading, workspace bootstrapping, and state management. This is inspired by similar OpenClaw skills like icloud-reminders and icalendar-sync. The skill file must be placed at the standard OpenClaw skill path `skills/heartbeat-monitor/SKILL.md`, not at the workspace root.

2. **Initialize a git repository** in the workspace directory (creating `.git/` with standard git structure including HEAD, config, etc.).

3. **Create identity and documentation files** in the workspace root:
   - IDENTITY.md
   - USER.md
   - AGENTS.md
   - SOUL.md
   - TOOLS.md
   - BOOTSTRAP.md

4. **Create `.openclaw/workspace-state.json`** to track that the workspace has been initialized.

5. **Read existing files** to orient itself in the workspace:
   - `HEARTBEAT.md` — the main documentation for the heartbeat system
   - `heartbeat_state.json` — current state showing `"status": "monitoring"`, with `consecutiveErrors: 2`, last checks for multiple services, and a last heartbeat acknowledgment timestamp of `2025-06-28T10:00:00+08:00`
   - `logs/heartbeat_monitor.log` — contains detailed heartbeat check records from 2025-06-28, including gateway timeout incidents around 01:35 and metrics-collector outage around 08:00
   - `logs/china_mobile_announcements.log` — external service announcements including maintenance windows, outages (Chengdu fiber cut, Guangzhou 4G issues), and a critical backbone link failure in Shenzhen/Dongguan
   - `logs/scraper_debug.log` — scraper polling debug information
   - `logs/system_resources.log` — system resource metrics (CPU, memory, disk usage over time)
   - `monitoring_config.yaml` — monitoring configuration including heartbeat endpoints, scraper settings, alert thresholds, and logging configuration

6. The agent should explain what it's doing conversationally as it bootstraps the workspace, demonstrating awareness of the current monitoring state and any notable events in the logs.

## Grading Criteria

- [ ] `skills/heartbeat-monitor/SKILL.md` exists with valid YAML frontmatter containing name and description
- [ ] `skills/heartbeat-monitor/SKILL.md` has meaningful instruction sections about heartbeat monitoring
- [ ] Git repository initialized (.git/HEAD exists)
- [ ] IDENTITY.md created
- [ ] USER.md created
- [ ] AGENTS.md created
- [ ] SOUL.md created
- [ ] TOOLS.md created
- [ ] BOOTSTRAP.md created
- [ ] .openclaw/workspace-state.json created

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    import os
    import json
    from pathlib import Path

    ws = Path(workspace_path)
    scores = {}

    # 1. Check SKILL.md exists at correct path and has proper structure
    skill_path = ws / "skills" / "heartbeat-monitor" / "SKILL.md"
    skill_score = 0.0
    if skill_path.exists():
        content = skill_path.read_text(encoding="utf-8", errors="replace")
        # Check for YAML frontmatter
        has_frontmatter = content.strip().startswith("---")
        has_name = "name:" in content.lower()
        has_description = "description:" in content.lower()
        # Check for meaningful sections (at least some headings)
        has_sections = content.count("#") >= 2
        if has_frontmatter and has_name and has_description:
            skill_score = 0.5
            if has_sections:
                skill_score = 1.0
            # Check for heartbeat-related content
            lower_content = content.lower()
            if any(kw in lower_content for kw in ["heartbeat", "monitor", "health", "bootstrap"]):
                skill_score = max(skill_score, 0.75)
                if has_sections and has_frontmatter:
                    skill_score = 1.0
        elif has_name or has_description:
            skill_score = 0.25
    scores["skill_md_quality"] = skill_score

    # 2. Check git repository initialized
    git_head = ws / ".git" / "HEAD"
    git_config = ws / ".git" / "config"
    git_score = 0.0
    if git_head.exists():
        git_score += 0.5
    if git_config.exists():
        git_score += 0.5
    scores["git_initialized"] = git_score

    # 3. Check identity/documentation files created
    identity_files = ["IDENTITY.md", "USER.md", "AGENTS.md", "SOUL.md", "TOOLS.md", "BOOTSTRAP.md"]
    found_count = 0
    for fname in identity_files:
        fpath = ws / fname
        if fpath.exists() and fpath.stat().st_size > 0:
            found_count += 1
    scores["identity_files_created"] = found_count / len(identity_files)

    # 4. Check .openclaw/workspace-state.json created
    ws_state_path = ws / ".openclaw" / "workspace-state.json"
    ws_state_score = 0.0
    if ws_state_path.exists():
        ws_state_score = 0.5
        try:
            data = json.loads(ws_state_path.read_text(encoding="utf-8", errors="replace"))
            if isinstance(data, dict):
                ws_state_score = 1.0
        except (json.JSONDecodeError, Exception):
            pass
    scores["workspace_state_json"] = ws_state_score

    # 5. Check that original files still exist (not destroyed)
    original_files = [
        "HEARTBEAT.md",
        "heartbeat_state.json",
        "logs/heartbeat_monitor.log",
        "logs/china_mobile_announcements.log",
        "logs/scraper_debug.log",
        "logs/system_resources.log",
        "monitoring_config.yaml",
    ]
    preserved = sum(1 for f in original_files if (ws / f).exists())
    scores["original_files_preserved"] = preserved / len(original_files)

    return scores
```

## LLM Judge Rubric

### Skill File Quality (Weight: 25%)
- 1.0: `skills/heartbeat-monitor/SKILL.md` has proper YAML frontmatter with name and description, plus well-organized markdown sections covering heartbeat monitoring, log reading, bootstrapping, and state management
- 0.75: SKILL.md exists with frontmatter and some relevant sections but missing one or two key areas
- 0.5: SKILL.md exists but frontmatter is incomplete or sections are minimal/generic
- 0.25: SKILL.md exists but is mostly empty or has no frontmatter
- 0.0: SKILL.md is missing entirely or contains no meaningful content

### Workspace Bootstrap Completeness (Weight: 30%)
- 1.0: All identity files (IDENTITY.md, USER.md, AGENTS.md, SOUL.md, TOOLS.md, BOOTSTRAP.md) created, git initialized, and .openclaw/workspace-state.json present
- 0.75: Most identity files created and git initialized, minor omissions
- 0.5: Some identity files created or git initialized but not both fully
- 0.25: Only one or two deliverables produced
- 0.0: No bootstrap artifacts created at all; workspace unchanged from initial state

### Evidence and Workspace Grounding (Weight: 25%)
- 1.0: Agent clearly read HEARTBEAT.md, monitoring_config.yaml, heartbeat_state.json, and log files, referenced their content (such as the gateway timeout incidents, metrics-collector outage, critical backbone failure, and current monitoring state), and used that information to guide bootstrap decisions
- 0.75: Agent read most relevant files and showed awareness of workspace context
- 0.5: Agent read some files but did not clearly connect them to actions taken
- 0.25: Agent made minimal reference to existing workspace files
- 0.0: Agent ignored required input files entirely, hallucinated workspace content, or skipped reading logs and documentation

### Communication and Process (Weight: 20%)
- 1.0: Agent clearly explained each step, described what it was doing and why, and provided a coherent narrative of the bootstrap process
- 0.75: Agent explained most steps with reasonable clarity
- 0.5: Agent completed work but explanations were sparse or unclear
- 0.25: Agent provided minimal explanation, mostly just tool calls
- 0.0: No meaningful communication about the process; silent execution or confused output