| 序号 | 修改项 | 修改原因 |
|------|--------|----------|
| 1 | 将 `workspace_files` 中所有条目的 `path:` 字段改为 `dest:` 字段 | 任务规范明确禁止使用旧字段 `path:`，应使用 `dest:` 格式 |
| 2 | 将 YAML frontmatter 中内联的 `content:` 替换为引用实际 Assets 文件，并将 `HEARTBEAT.md` 的 `dest` 保留，移除 `content` 块 | Assets 目录已提供真实文件，内联 content 与 Assets 文件内容不一致（frontmatter 中 heartbeat_state.json 为 `"status": "uninitialized"`，而 Assets 文件中为 `"status": "monitoring"` 等丰富数据），应以 Assets 目录中的真实文件为准 |
| 3 | 在 `workspace_files` 中补充 Assets 目录中存在但未列出的文件：`logs/scraper_debug.log`、`logs/system_resources.log`、`monitoring_config.yaml` | 维度 F 要求 workspace_files 列出的文件与 Assets 目录保持一致；这些文件在 Assets 中存在，也是监控场景的重要上下文文件，应当映射到 workspace |
| 4 | 修正 SKILL.md 路径为 `skills/heartbeat-monitor/SKILL.md`（Prompt、Expected Behavior、Grading Criteria、grade() 函数中同步修改） | 任务规范维度 A 的 skill 路径规范要求技能文件放在 `skills/<skill名>/SKILL.md`，不应放在 workspace 根下的裸 `SKILL.md` |
| 5 | 在 Expected Behavior 中补充说明 Assets 中 heartbeat_state.json 的实际状态为 `"monitoring"`（非 `"uninitialized"`），以及日志中存在的告警事件 | 维度 B 要求 Expected Behavior 与 Assets 数据一致；原 Expected Behavior 未提及 Assets 中的实际数据特征 |
| 6 | 在 Expected Behavior 中补充关于 `monitoring_config.yaml` 等额外文件的说明 | Assets 中存在多个配置和日志文件，agent 应读取这些文件来理解工作区上下文 |
| 7 | 修正 grade() 函数中 SKILL.md 的检查路径为 `skills/heartbeat-monitor/SKILL.md` | 与修正后的 skill 路径规范一致 |
| 8 | 在 grade() 函数中增加对新增 workspace 文件（`monitoring_config.yaml`、`logs/scraper_debug.log`、`logs/system_resources.log`）的保留检查 | 原 `original_files_preserved` 检查列表不包含这些文件 |
| 9 | 修正 Grading Criteria 中 SKILL.md 条目的路径描述 | 与 skill 路径规范保持一致 |
| 10 | 在 HEARTBEAT.md 的内容中补充对 `monitoring_config.yaml`、`logs/scraper_debug.log`、`logs/system_resources.log` 的说明 | HEARTBEAT.md 作为主说明文件应反映 workspace 中实际存在的全部文件 |
| 11 | 将 HEARTBEAT.md 内容中 heartbeat_state.json 的描述更新为与 Assets 实际内容一致 | 原 HEARTBEAT.md 的内联 content 中描述的 heartbeat_state.json 字段（status/last_check/session_count）与 Assets 中实际的字段结构（lastChecks/consecutiveErrors 等）不匹配 |