| 序号 | 修改项 | 修改原因 |
|------|--------|----------|
| 1 | 删除 `workspace_files` 中所有 `path:` 字段，替换为正确的 `dest:` 字段（脚本文件和 cron 配置均只写 `dest`） | `path:` 为禁用旧字段，规范要求使用 `dest:`（包内路径去掉前缀后与 workspace 路径相同时只写 `dest` 即可） |
| 2 | `workspace_files` 中两个 `content:` 内联文件的内容替换：将原来简化版 shell 脚本内容替换为 Assets 目录中的完整增强版脚本内容（与 `task_00390_poly_arb_monitor_enhanced/scripts/poly-arb-monitor-enhanced.sh` 保持一致） | YAML frontmatter 中内联的脚本为早期简化版，与 Assets 目录中实际提供的完整增强版脚本不一致，两者逻辑差异极大（字段路径、读取方式、功能均不同），会造成 Prompt、Expected Behavior 与实际环境文件脱节 |
| 3 | 新增 `workspace_files` 条目：`dest: config/arb-config.json`（含 `content:` 内联完整配置）、`dest: logs/arb-transactions.log`（含 `content:` 样例事务日志）、`dest: data/balances.json`（保留，用于兼容脚本中 `data/` 目录引用）| 完整版脚本读取 `config/arb-config.json`（使用 `jq` 解析多层字段 `.rpc.primary`、`.wallet.address`、`.tokens.usdc.contract` 等）、`logs/arb-transactions.log`（JSON 格式逐行日志），这些文件在原 `workspace_files` 中完全缺失，导致脚本必然以 exit 1 失败 |
| 4 | 修正 `Expected Behavior` 中对基础设施的描述，使其与完整版脚本实际所需字段一致（`config/arb-config.json` 需包含 `.rpc.primary`、`.rpc.fallback`、`.wallet.address`、`.tokens.usdc.contract`、`.thresholds.*` 等字段，而非简单的 `wallet_address`/`rpc_url` 扁平字段） | 原 Expected Behavior 描述的是简化版脚本的需求，与完整增强版脚本的实际读取路径不符 |
| 5 | 修正 `grade()` 函数中 `config/arb-config.json` 的校验逻辑：将检查 `config["wallet_address"]` / `config["rpc_url"]` 改为检查 `config["wallet"]["address"]` / `config["rpc"]["primary"]`（嵌套字段） | 完整版脚本通过 `jq -r '.wallet.address'` 等读取嵌套 JSON，原 grade() 检查扁平字段会导致评分逻辑与实际环境永远不匹配 |
| 6 | 修正 `grade()` 函数中 `logs/transactions.log` 路径改为 `logs/arb-transactions.log` | 完整版脚本使用的事务日志文件名为 `arb-transactions.log`，原 grade() 检查的 `transactions.log` 不存在 |
| 7 | 在 `grade()` 中增加对 `data/monitor-state.json` 的存在性检查作为脚本执行证据，并在 `script_executed` 检测中增加对 `monitor-state.json` 的判断 | 完整版脚本写出的是 `data/monitor-state.json`（通过 jq 生成），而非 `data/monitor-report.json`；原 grade() 对执行证据的判断基于错误的输出文件名 |
| 8 | 将 `monitor_report_exists` score key 重命名为 `monitor_state_exists`，并相应修改检查路径为 `data/monitor-state.json` | 与上条原因一致，key 名称应与实际产出文件对齐 |
| 9 | 修正 LLM Judge Rubric 中对输出文件的描述：将 `data/monitor-report.json` 改为 `data/monitor-state.json` | 保持与实际脚本产出一致 |
| 10 | `Grading Criteria` 第4条修正为检查 `data/monitor-state.json`（而非 `monitor-report.json`） | 同上 |
| 11 | 补充 `cron/schedule.conf` 中引用的脚本路径与完整版脚本路径一致性说明（`cron/schedule.conf` 仍保留，内容不变，路径引用本身正确） | 核查后 cron 配置中路径 `scripts/poly-arb-monitor-enhanced.sh` 与实际文件一致，无需修改，记录为已核查 |