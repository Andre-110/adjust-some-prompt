#!/usr/bin/env bash
###############################################################################
# poly-arb-monitor-enhanced.sh
# Enhanced monitoring script for POL/USDC arbitrage bot
# Checks wallet balances (POL native + USDC ERC-20) and monitors tx logs
# Triggered by cron job: a2ce4b5b-63bf-4235-a84d-5a66cf18532f
###############################################################################

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(dirname "$SCRIPT_DIR")"
CONFIG_FILE="${ROOT_DIR}/config/arb-config.json"
TX_LOG_DIR="${ROOT_DIR}/logs"
ALERT_LOG="${TX_LOG_DIR}/monitor-alerts.log"
STATE_FILE="${ROOT_DIR}/data/monitor-state.json"

# Colors for terminal output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

log_info()  { echo -e "${CYAN}[INFO]${NC}  $(date '+%Y-%m-%d %H:%M:%S') $*"; }
log_warn()  { echo -e "${YELLOW}[WARN]${NC}  $(date '+%Y-%m-%d %H:%M:%S') $*"; }
log_error() { echo -e "${RED}[ERROR]${NC} $(date '+%Y-%m-%d %H:%M:%S') $*"; }
log_ok()    { echo -e "${GREEN}[OK]${NC}    $(date '+%Y-%m-%d %H:%M:%S') $*"; }

# --------------------------------------------------------------------------- #
# Load config
# --------------------------------------------------------------------------- #
if [[ ! -f "$CONFIG_FILE" ]]; then
    log_error "Config file not found: $CONFIG_FILE"
    exit 1
fi

RPC_URL=$(jq -r '.rpc.primary' "$CONFIG_FILE")
FALLBACK_RPC=$(jq -r '.rpc.fallback' "$CONFIG_FILE")
WALLET_ADDR=$(jq -r '.wallet.address' "$CONFIG_FILE")
USDC_CONTRACT=$(jq -r '.tokens.usdc.contract' "$CONFIG_FILE")
POL_DECIMALS=$(jq -r '.tokens.pol.decimals' "$CONFIG_FILE")
USDC_DECIMALS=$(jq -r '.tokens.usdc.decimals' "$CONFIG_FILE")
MIN_POL_BALANCE=$(jq -r '.thresholds.min_pol_balance' "$CONFIG_FILE")
MIN_USDC_BALANCE=$(jq -r '.thresholds.min_usdc_balance' "$CONFIG_FILE")
MAX_PENDING_TX=$(jq -r '.thresholds.max_pending_tx' "$CONFIG_FILE")
PROFIT_ALERT_THRESHOLD=$(jq -r '.thresholds.profit_alert_usd' "$CONFIG_FILE")

# --------------------------------------------------------------------------- #
# RPC call helper with fallback
# --------------------------------------------------------------------------- #
rpc_call() {
    local method="$1"
    local params="$2"
    local payload="{\"jsonrpc\":\"2.0\",\"method\":\"${method}\",\"params\":${params},\"id\":1}"

    local result
    result=$(curl -s -m 10 -X POST "$RPC_URL" \
        -H "Content-Type: application/json" \
        -d "$payload" 2>/dev/null) || true

    if [[ -z "$result" || "$(echo "$result" | jq -r '.error // empty')" != "" ]]; then
        log_warn "Primary RPC failed, trying fallback..."
        result=$(curl -s -m 10 -X POST "$FALLBACK_RPC" \
            -H "Content-Type: application/json" \
            -d "$payload" 2>/dev/null) || {
            log_error "Both RPC endpoints failed for $method"
            return 1
        }
    fi

    echo "$result"
}

# --------------------------------------------------------------------------- #
# Check POL (native) balance
# --------------------------------------------------------------------------- #
check_pol_balance() {
    log_info "Checking POL native balance for ${WALLET_ADDR:0:10}...${WALLET_ADDR: -6}"

    local response
    response=$(rpc_call "eth_getBalance" "[\"$WALLET_ADDR\", \"latest\"]") || return 1

    local hex_balance
    hex_balance=$(echo "$response" | jq -r '.result')

    if [[ "$hex_balance" == "null" || -z "$hex_balance" ]]; then
        log_error "Failed to retrieve POL balance"
        return 1
    fi

    # Convert hex to decimal, then to human-readable
    local wei_balance
    wei_balance=$(python3 -c "print(int('$hex_balance', 16))")
    local pol_balance
    pol_balance=$(python3 -c "print(f'{int(\"$hex_balance\", 16) / 10**$POL_DECIMALS:.6f}')")

    log_info "POL Balance: $pol_balance POL"

    # Check threshold
    local below_min
    below_min=$(python3 -c "print('yes' if float('$pol_balance') < float('$MIN_POL_BALANCE') else 'no')")

    if [[ "$below_min" == "yes" ]]; then
        log_warn "⚠️  POL balance ($pol_balance) below minimum threshold ($MIN_POL_BALANCE)"
        echo "$(date -u '+%Y-%m-%dT%H:%M:%SZ') ALERT POL_LOW_BALANCE current=$pol_balance threshold=$MIN_POL_BALANCE" >> "$ALERT_LOG"
        return 2
    else
        log_ok "POL balance is healthy"
    fi

    echo "$pol_balance"
}

# --------------------------------------------------------------------------- #
# Check USDC (ERC-20) balance
# --------------------------------------------------------------------------- #
check_usdc_balance() {
    log_info "Checking USDC balance for ${WALLET_ADDR:0:10}...${WALLET_ADDR: -6}"

    # balanceOf(address) selector = 0x70a08231
    local padded_addr
    padded_addr=$(printf '%064s' "${WALLET_ADDR:2}" | tr ' ' '0')
    local calldata="0x70a08231${padded_addr}"

    local response
    response=$(rpc_call "eth_call" "[{\"to\":\"$USDC_CONTRACT\",\"data\":\"$calldata\"}, \"latest\"]") || return 1

    local hex_balance
    hex_balance=$(echo "$response" | jq -r '.result')

    if [[ "$hex_balance" == "null" || -z "$hex_balance" || "$hex_balance" == "0x" ]]; then
        log_error "Failed to retrieve USDC balance"
        return 1
    fi

    local usdc_balance
    usdc_balance=$(python3 -c "print(f'{int(\"$hex_balance\", 16) / 10**$USDC_DECIMALS:.2f}')")

    log_info "USDC Balance: $usdc_balance USDC"

    local below_min
    below_min=$(python3 -c "print('yes' if float('$usdc_balance') < float('$MIN_USDC_BALANCE') else 'no')")

    if [[ "$below_min" == "yes" ]]; then
        log_warn "⚠️  USDC balance ($usdc_balance) below minimum threshold ($MIN_USDC_BALANCE)"
        echo "$(date -u '+%Y-%m-%dT%H:%M:%SZ') ALERT USDC_LOW_BALANCE current=$usdc_balance threshold=$MIN_USDC_BALANCE" >> "$ALERT_LOG"
        return 2
    else
        log_ok "USDC balance is healthy"
    fi

    echo "$usdc_balance"
}

# --------------------------------------------------------------------------- #
# Monitor transaction logs
# --------------------------------------------------------------------------- #
monitor_tx_logs() {
    log_info "Scanning transaction logs..."

    local tx_log="${TX_LOG_DIR}/arb-transactions.log"
    if [[ ! -f "$tx_log" ]]; then
        log_warn "Transaction log not found: $tx_log"
        return 0
    fi

    # Count recent transactions (last 1 hour)
    local one_hour_ago
    one_hour_ago=$(date -u -d '1 hour ago' '+%Y-%m-%dT%H:%M:%S' 2>/dev/null || date -u -v-1H '+%Y-%m-%dT%H:%M:%S' 2>/dev/null || echo "")

    local total_tx=0
    local failed_tx=0
    local pending_tx=0
    local total_profit=0

    while IFS= read -r line; do
        # Parse JSON log entries
        local status
        status=$(echo "$line" | jq -r '.status // "unknown"' 2>/dev/null) || continue
        local timestamp
        timestamp=$(echo "$line" | jq -r '.timestamp // ""' 2>/dev/null) || continue

        total_tx=$((total_tx + 1))

        case "$status" in
            "failed"|"reverted")
                failed_tx=$((failed_tx + 1))
                ;;
            "pending")
                pending_tx=$((pending_tx + 1))
                ;;
            "confirmed")
                local profit
                profit=$(echo "$line" | jq -r '.profit_usd // 0' 2>/dev/null)
                total_profit=$(python3 -c "print(round(float('$total_profit') + float('$profit'), 4))")
                ;;
        esac
    done < "$tx_log"

    log_info "Transaction Summary (recent):"
    log_info "  Total:    $total_tx"
    log_info "  Confirmed: $((total_tx - failed_tx - pending_tx))"
    log_info "  Failed:   $failed_tx"
    log_info "  Pending:  $pending_tx"
    log_info "  Profit:   \$$total_profit"

    # Alert on too many pending
    if [[ $pending_tx -gt $MAX_PENDING_TX ]]; then
        log_warn "⚠️  Too many pending transactions: $pending_tx (max: $MAX_PENDING_TX)"
        echo "$(date -u '+%Y-%m-%dT%H:%M:%SZ') ALERT HIGH_PENDING_TX count=$pending_tx threshold=$MAX_PENDING_TX" >> "$ALERT_LOG"
    fi

    # Alert on high failure rate
    if [[ $total_tx -gt 0 ]]; then
        local fail_rate
        fail_rate=$(python3 -c "print(round($failed_tx / $total_tx * 100, 1))")
        if python3 -c "exit(0 if float('$fail_rate') > 20 else 1)"; then
            log_warn "⚠️  High failure rate: ${fail_rate}%"
            echo "$(date -u '+%Y-%m-%dT%H:%M:%SZ') ALERT HIGH_FAIL_RATE rate=${fail_rate}% failed=$failed_tx total=$total_tx" >> "$ALERT_LOG"
        fi
    fi

    # Profit alert
    if python3 -c "exit(0 if float('$total_profit') > float('$PROFIT_ALERT_THRESHOLD') else 1)" 2>/dev/null; then
        log_ok "🎯 Profit target exceeded! Total: \$$total_profit (threshold: \$$PROFIT_ALERT_THRESHOLD)"
    fi

    # Update state
    jq -n \
        --arg ts "$(date -u '+%Y-%m-%dT%H:%M:%SZ')" \
        --argjson total "$total_tx" \
        --argjson failed "$failed_tx" \
        --argjson pending "$pending_tx" \
        --arg profit "$total_profit" \
        '{
            last_check: $ts,
            transactions: { total: $total, failed: $failed, pending: $pending },
            cumulative_profit_usd: $profit
        }' > "$STATE_FILE"
}

# --------------------------------------------------------------------------- #
# Check gas prices
# --------------------------------------------------------------------------- #
check_gas_price() {
    log_info "Checking current gas price..."

    local response
    response=$(rpc_call "eth_gasPrice" "[]") || return 1

    local hex_gas
    hex_gas=$(echo "$response" | jq -r '.result')
    local gas_gwei
    gas_gwei=$(python3 -c "print(f'{int(\"$hex_gas\", 16) / 1e9:.2f}')")

    log_info "Current gas price: $gas_gwei Gwei"

    local max_gas
    max_gas=$(jq -r '.thresholds.max_gas_gwei // 100' "$CONFIG_FILE")

    if python3 -c "exit(0 if float('$gas_gwei') > float('$max_gas') else 1)" 2>/dev/null; then
        log_warn "⚠️  Gas price ($gas_gwei Gwei) exceeds maximum ($max_gas Gwei)"
        echo "$(date -u '+%Y-%m-%dT%H:%M:%SZ') ALERT HIGH_GAS price=${gas_gwei}gwei threshold=${max_gas}gwei" >> "$ALERT_LOG"
    fi
}

# --------------------------------------------------------------------------- #
# Main
# --------------------------------------------------------------------------- #
main() {
    log_info "=========================================="
    log_info "POL/USDC Arbitrage Monitor (Enhanced)"
    log_info "Cron Job: a2ce4b5b-63bf-4235-a84d-5a66cf18532f"
    log_info "=========================================="

    local exit_code=0

    check_pol_balance || exit_code=$?
    echo ""
    check_usdc_balance || exit_code=$?
    echo ""
    check_gas_price || true
    echo ""
    monitor_tx_logs || true

    log_info "=========================================="
    log_info "Monitor run complete"
    log_info "=========================================="

    return $exit_code
}

main "$@"
