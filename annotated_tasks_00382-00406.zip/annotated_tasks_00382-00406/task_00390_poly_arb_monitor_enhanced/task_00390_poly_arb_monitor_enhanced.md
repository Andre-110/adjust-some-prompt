---
id: task_00390_poly_arb_monitor_enhanced
name: Enhanced POL/USDC Arbitrage Monitor Setup
category: Finance and Quantitative Trading
subcategory: Market Data and Monitoring
difficulty: medium
grading_type: hybrid
grading_weights: {automated: 0.4, llm_judge: 0.6}
timeout_seconds: 600
input_modality: text-only
external_dependency: none
workspace_files:
  - source: scripts/poly-arb-monitor-enhanced.sh
    dest: scripts/poly-arb-monitor-enhanced.sh
  - source: cron/schedule.conf
    dest: cron/schedule.conf
  - source: config/arb-config.json
    dest: config/arb-config.json
  - source: logs/arb-transactions.log
    dest: logs/arb-transactions.log
  - source: data/balances.json
    dest: data/balances.json
skill_creation: false
---

## Prompt

Hey, I have an enhanced monitoring script at `scripts/poly-arb-monitor-enhanced.sh` that checks POL/USDC balances and monitors transaction logs for my arbitrage bot. There's also a cron schedule config at `cron/schedule.conf`. The script needs several infrastructure files to run — a `config/arb-config.json` with wallet and RPC configuration, a `logs/arb-transactions.log` with transaction history, and a `data/` directory.

Can you set up all the missing infrastructure so the script can run successfully? Specifically I need:

1. Review `config/arb-config.json` and make sure it contains valid wallet address, RPC endpoints, token contract addresses, and threshold settings that match what the script expects
2. Ensure `logs/arb-transactions.log` exists with sample JSON-format transaction entries the script can parse
3. Ensure the `data/` directory exists (the script will write `data/monitor-state.json` there)
4. Then actually run the monitoring script and make sure it completes without errors
5. Give me a summary of what you set up and the monitoring results

The cron task ID is `a2ce4b5b-63bf-4235-a84d-5a66cf18532f` for reference.

## Expected Behavior

The agent should:

1. **Inspect the existing script** at `scripts/poly-arb-monitor-enhanced.sh` and the cron config at `cron/schedule.conf` to understand what infrastructure is needed.
2. **Verify or create `config/arb-config.json`** containing the nested fields the script reads via `jq`:
   - `.rpc.primary` and `.rpc.fallback` — RPC endpoint URLs
   - `.wallet.address` — the monitored wallet address
   - `.tokens.usdc.contract` — USDC ERC-20 contract address
   - `.tokens.pol.decimals` and `.tokens.usdc.decimals` — token decimals
   - `.thresholds.min_pol_balance`, `.thresholds.min_usdc_balance`, `.thresholds.max_pending_tx`, `.thresholds.profit_alert_usd`, `.thresholds.max_gas_gwei` — alert thresholds
3. **Verify or create `logs/arb-transactions.log`** with JSON-format transaction entries (one per line), each containing at minimum `status` and `profit_usd` fields.
4. **Ensure the `data/` directory exists** so the script can write `data/monitor-state.json`.
5. **Run the monitoring script** (`scripts/poly-arb-monitor-enhanced.sh`) and confirm it completes (exit code 0 or 2 for balance-below-threshold warnings).
6. **Verify the output**: The script should produce `data/monitor-state.json` with `last_check`, `transactions`, and `cumulative_profit_usd` fields.
7. **Provide a summary** explaining the infrastructure setup, monitoring results (transaction totals, profit, any alerts), and confirmation of execution.

## Grading Criteria

- [ ] `config/arb-config.json` exists and contains valid JSON with nested fields `.rpc.primary`, `.wallet.address`, `.tokens.usdc.contract`, and `.thresholds.*`
- [ ] `logs/arb-transactions.log` exists and contains at least one JSON-format transaction entry
- [ ] `data/balances.json` exists and contains valid JSON with `POL` and `USDC` fields
- [ ] `data/monitor-state.json` exists (produced by running the script's `monitor_tx_logs` function)
- [ ] The monitoring script was executed (evidence in transcript or output log)
- [ ] Agent provided a summary of the setup and monitoring results

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    import os
    import json
    from pathlib import Path

    ws = Path(workspace_path)
    scores = {
        "config_file_valid": 0.0,
        "transaction_log_exists": 0.0,
        "balances_file_valid": 0.0,
        "monitor_state_exists": 0.0,
        "script_executed": 0.0,
    }

    # 1. Check config/arb-config.json (nested structure matching what jq reads)
    config_path = ws / "config" / "arb-config.json"
    if config_path.exists():
        try:
            with open(config_path, "r") as f:
                config = json.load(f)
            has_rpc = (
                isinstance(config.get("rpc"), dict)
                and isinstance(config["rpc"].get("primary"), str)
                and len(config["rpc"]["primary"]) > 5
            )
            has_wallet = (
                isinstance(config.get("wallet"), dict)
                and isinstance(config["wallet"].get("address"), str)
                and len(config["wallet"]["address"]) > 5
            )
            has_tokens = isinstance(config.get("tokens"), dict)
            has_thresholds = isinstance(config.get("thresholds"), dict)
            if has_rpc and has_wallet and has_tokens and has_thresholds:
                scores["config_file_valid"] = 1.0
            elif has_wallet and has_rpc:
                scores["config_file_valid"] = 0.6
            elif has_wallet or has_rpc:
                scores["config_file_valid"] = 0.3
        except (json.JSONDecodeError, Exception):
            scores["config_file_valid"] = 0.1  # file exists but invalid JSON

    # 2. Check logs/arb-transactions.log (JSON-per-line format)
    tx_log_path = ws / "logs" / "arb-transactions.log"
    if tx_log_path.exists():
        try:
            with open(tx_log_path, "r") as f:
                lines = [l.strip() for l in f.readlines() if l.strip()]
            valid_json_lines = 0
            for line in lines:
                try:
                    obj = json.loads(line)
                    if "status" in obj:
                        valid_json_lines += 1
                except Exception:
                    pass
            if valid_json_lines >= 3:
                scores["transaction_log_exists"] = 1.0
            elif valid_json_lines >= 1:
                scores["transaction_log_exists"] = 0.7
            elif len(lines) >= 1:
                scores["transaction_log_exists"] = 0.3
        except Exception:
            scores["transaction_log_exists"] = 0.1

    # 3. Check data/balances.json
    balances_path = ws / "data" / "balances.json"
    if balances_path.exists():
        try:
            with open(balances_path, "r") as f:
                balances = json.load(f)
            has_pol = "POL" in balances
            has_usdc = "USDC" in balances
            if has_pol and has_usdc:
                scores["balances_file_valid"] = 1.0
            elif has_pol or has_usdc:
                scores["balances_file_valid"] = 0.5
        except (json.JSONDecodeError, Exception):
            scores["balances_file_valid"] = 0.1

    # 4. Check data/monitor-state.json (produced by running the script)
    state_path = ws / "data" / "monitor-state.json"
    if state_path.exists():
        try:
            with open(state_path, "r") as f:
                content = f.read().strip()
            if len(content) > 10:
                try:
                    state = json.loads(content)
                    if "last_check" in state or "transactions" in state or "cumulative_profit_usd" in state:
                        scores["monitor_state_exists"] = 1.0
                    else:
                        scores["monitor_state_exists"] = 0.7
                except json.JSONDecodeError:
                    scores["monitor_state_exists"] = 0.5
        except Exception:
            scores["monitor_state_exists"] = 0.2

    # 5. Check if script was executed
    script_ran = False
    for event in transcript:
        if event.get("type") != "message":
            continue
        msg = event.get("message", {})
        if msg.get("role") == "assistant":
            content = msg.get("content", "")
            if isinstance(content, str):
                if "poly-arb-monitor-enhanced" in content and (
                    "bash" in content or "sh " in content or "exec" in content
                ):
                    script_ran = True
            elif isinstance(content, list):
                for part in content:
                    if isinstance(part, dict):
                        text = part.get("text", "") or ""
                        if "poly-arb-monitor-enhanced" in text:
                            script_ran = True
        if msg.get("role") == "tool":
            content = msg.get("content", "")
            if isinstance(content, str) and (
                "Monitor run complete" in content or "Monitoring complete" in content
            ):
                script_ran = True

    # Output log as evidence of execution
    output_log = ws / "logs" / "monitor-output.log"
    if output_log.exists():
        try:
            with open(output_log, "r") as f:
                if "Monitor run complete" in f.read():
                    script_ran = True
        except Exception:
            pass

    # monitor-state.json existing is strong evidence the script ran
    if scores["monitor_state_exists"] >= 0.5:
        script_ran = True

    scores["script_executed"] = 1.0 if script_ran else 0.0

    return scores
```

## LLM Judge Rubric

### Infrastructure Setup Completeness (Weight: 30%)
- 1.0: All required infrastructure files are present and correctly structured — `config/arb-config.json` with nested rpc/wallet/tokens/thresholds fields, `logs/arb-transactions.log` with JSON-format entries, and `data/` directory ready for script output
- 0.75: All components present but one has minor issues (e.g., missing a nested field, only one transaction entry)
- 0.5: Two of three components set up correctly
- 0.25: Only one component set up, or files exist with clearly wrong structure
- 0.0: No infrastructure prepared, or files are empty/missing entirely

### Script Execution and Results (Weight: 25%)
- 1.0: Script was executed successfully, produced `data/monitor-state.json` with transaction summary and cumulative profit, output shows balance checks and transaction log monitoring completed without fatal errors
- 0.75: Script was executed and mostly succeeded but had minor warnings or incomplete output
- 0.5: Script was executed but encountered errors, or state file was not generated
- 0.25: Attempted to run the script but it failed due to remaining missing infrastructure
- 0.0: Script was never executed or no evidence of execution attempt

### Evidence and Workspace Grounding (Weight: 25%)
- 1.0: All created/verified files contain realistic, well-structured data for a blockchain monitoring context (plausible wallet addresses, RPC URLs, transaction hashes, token balances, contract addresses)
- 0.75: Files contain reasonable data but some values are clearly placeholder or unrealistic
- 0.5: Files exist but contain minimal or generic data not well-suited to the monitoring context
- 0.25: Files exist but content is largely irrelevant or malformed
- 0.0: Required output files are missing, empty, or the response ignores the workspace files and script entirely

### Summary and Communication (Weight: 20%)
- 1.0: Clear summary explaining what infrastructure was verified/created, the monitoring results (transaction totals, confirmed/failed/pending counts, cumulative profit, any threshold alerts), and confirmation of successful execution
- 0.75: Good summary covering most aspects but missing one element (e.g., doesn't mention specific transaction counts or profit)
- 0.5: Brief summary that covers the basics but lacks detail
- 0.25: Minimal or vague response about what was done
- 0.0: No summary provided or response is completely off-topic