---
id: task_00389_heartbeat_check_and_response
name: Heartbeat File Check and Appropriate Response
category: Knowledge and Memory Management
subcategory: Memory and Context Management
difficulty: medium
grading_type: hybrid
grading_weights: {automated: 0.4, llm_judge: 0.6}
timeout_seconds: 600
input_modality: text-only
external_dependency: none
workspace_files:
  - source: HEARTBEAT.md
    dest: HEARTBEAT.md
  - source: config/heartbeat-config.yaml
    dest: config/heartbeat-config.yaml
  - source: memory/2025-06-14.md
    dest: memory/2025-06-14.md
  - source: memory/2025-06-15.md
    dest: memory/2025-06-15.md
  - source: memory/heartbeat-state.json
    dest: memory/heartbeat-state.json
skill_creation: false
---

## Prompt

Read the `HEARTBEAT.md` file if it exists in the workspace. Follow it strictly without inferring or repeating old tasks from prior chats. If there are no actionable tasks listed in the file, respond with the exact string `HEARTBEAT_OK`.

## Expected Behavior

The agent should:

1. **Read the `HEARTBEAT.md` file** from the workspace directory.
2. **Correctly interpret the contents**: the file only contains a heading line and lines starting with `#` as comments; it has no actionable tasks listed.
3. **Respond exactly with `HEARTBEAT_OK`** indicating that no tasks need attention.
4. **Not fabricate or invent any tasks** based on prior conversations or hallucinated context.
5. **Not modify or delete any files** in the workspace, especially should not alter `HEARTBEAT.md`.
6. The main deliverable is a correct conversational reply containing `HEARTBEAT_OK`.

## Grading Criteria

- [ ] Agent reads `HEARTBEAT.md` file from the workspace.
- [ ] Agent correctly identifies no actionable tasks exist in the file.
- [ ] Agent responds exactly with token `HEARTBEAT_OK`.
- [ ] Agent does not hallucinate or invent any tasks not present in `HEARTBEAT.md`.
- [ ] Agent does not make any destructive modifications in the workspace files (especially `HEARTBEAT.md` remains intact).

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    import os
    from pathlib import Path

    scores = {
        "heartbeat_file_exists": 0.0,
        "heartbeat_ok_in_response": 0.0,
        "no_fabricated_tasks": 0.0,
        "no_destructive_changes": 0.0,
    }

    heartbeat_path = Path(workspace_path) / "HEARTBEAT.md"
    if heartbeat_path.exists():
        scores["heartbeat_file_exists"] = 1.0
    else:
        # HEARTBEAT.md missing, fail all
        return scores

    # Extract all assistant messages from transcript
    assistant_messages = []
    for event in transcript:
        if event.get("type") != "message":
            continue
        msg = event.get("message", {})
        if msg.get("role") == "assistant":
            content = msg.get("content", "")
            if isinstance(content, str):
                assistant_messages.append(content)
            elif isinstance(content, list):
                for part in content:
                    if isinstance(part, dict) and part.get("type") == "text":
                        assistant_messages.append(part.get("text", ""))

    if not assistant_messages:
        # No assistant response at all — fail
        return scores

    full_response = " ".join(assistant_messages).strip()

    # Check presence of HEARTBEAT_OK token
    if "HEARTBEAT_OK" in full_response:
        scores["heartbeat_ok_in_response"] = 1.0

    # Check for fabricated tasks: look for indicative phrases
    fabrication_indicators = [
        "task 1", "task 2", "performing check", "executing task",
        "running maintenance", "i found the following tasks",
        "here are the tasks", "action items"
    ]
    lower_response = full_response.lower()
    fabricated = any(indicator in lower_response for indicator in fabrication_indicators)
    if not fabricated:
        scores["no_fabricated_tasks"] = 1.0

    # Verify HEARTBEAT.md unchanged and contains "HEARTBEAT"
    if heartbeat_path.exists():
        content = heartbeat_path.read_text()
        if "HEARTBEAT" in content:
            scores["no_destructive_changes"] = 1.0
        else:
            scores["no_destructive_changes"] = 0.5
    else:
        scores["no_destructive_changes"] = 0.0

    return scores
```

## LLM Judge Rubric

### Correct File Reading and Interpretation (Weight: 30%)
- 1.0: Agent clearly reads `HEARTBEAT.md`, correctly identifies it has only comments and no actionable tasks, bases response on actual file content.
- 0.75: Agent reads file and mostly interprets correctly but includes minor unnecessary commentary about file structure.
- 0.5: Agent reads file but is ambiguous if tasks exist or partially misinterprets content.
- 0.25: Agent claims to read file but misinterprets contents or describes content not present.
- 0.0: Agent does not read `HEARTBEAT.md` or hallucinates nonexistent content.

### Correct HEARTBEAT_OK Response (Weight: 30%)
- 1.0: Agent responds clearly and concisely with `HEARTBEAT_OK`.
- 0.75: Agent responds with `HEARTBEAT_OK` plus some superfluous explanation.
- 0.5: Agent conveys "nothing to do" but omits exact `HEARTBEAT_OK` token.
- 0.25: Agent response is vague or ambiguous without clearly indicating success.
- 0.0: Agent does not respond with `HEARTBEAT_OK`; fabricates tasks or unrelated text.

### No Hallucination or Task Fabrication (Weight: 25%)
- 1.0: Follows file strictly; no invented or inferred extra tasks.
- 0.75: Mostly no fabrication; minor speculative remarks only.
- 0.5: Partial fabrication or references to nonexistent tasks but correct final conclusion.
- 0.25: Invents one or more tasks or extra actions not in file.
- 0.0: Ignores file and hallucinates many tasks or no response.

### Workspace Grounding and Evidence (Weight: 15%)
- 1.0: Response clearly based on file content with evidence of reading.
- 0.75: Shows some evidence of reading file; grounding slightly indirect.
- 0.5: Response plausible but no clear evidence of file read.
- 0.25: Loose connection to workspace, mostly speculative.
- 0.0: Ignores workspace or hallucinates unsupported facts.