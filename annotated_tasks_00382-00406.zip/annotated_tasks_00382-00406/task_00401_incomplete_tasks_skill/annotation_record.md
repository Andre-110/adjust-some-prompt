| 序号 | 修改项 | 修改原因 |
|------|--------|----------|
| 1 | `workspace_files` 字段格式：将所有 `path:` 改为 `source:` + `dest:` 规范格式 | 原文件使用已禁止的 `path:` 字段，不符合数据规范要求 |
| 2 | `workspace_files` 中 `tasks.json` 的内联 `content` 内容与 Assets 目录中 `data/tasks.json` 严重不一致，删除内联 content，改为引用 Assets 文件 | Prompt 让 Agent 读取 `tasks.json`，但 YAML frontmatter 中内联的 tasks.json 数据（12条，DevOps风格）与 Assets 目录中 `data/tasks.json`（24条，个人+工作混合风格）完全不同。这会导致 Expected Behavior、grade() 和实际环境文件三者矛盾 |
| 3 | 补充 Assets 目录下所有文件到 `workspace_files` 列表 | 原 `workspace_files` 仅列出 `tasks.json` 一个文件，但 Assets 目录包含 6 个文件（data/tasks.json, data/task-config.yaml, data/task-stats.csv, data/tags-index.json, data/archive/2025-06.json, memory/2025-07-17.md, skills/task-manager/SKILL.md），缺失文件未映射到 workspace |
| 4 | 重写 Expected Behavior，基于 Assets 中实际的 `data/tasks.json` 内容 | 原 Expected Behavior 基于内联的 12 条 tasks 数据，与 Assets 中真实的 24 条任务数据完全不符。需根据 Assets 数据重新计算 incomplete tasks 列表 |
| 5 | 重写 Grading Criteria，与新的 Expected Behavior 对齐 | 原 Grading Criteria 中引用的 task ID 和数量（8个 incomplete tasks）与 Assets 数据不匹配 |
| 6 | 重写 grade() 函数，使用正确的 task ID、关键词和数量 | 原 grade() 中硬编码的 incomplete task IDs 和 keywords 与 Assets 数据不一致 |
| 7 | 重写 LLM Judge Rubric，更新 task ID 引用和数量 | 原 Rubric 引用的 8 个 incomplete tasks 与 Assets 数据不符 |
| 8 | Prompt 中 `tasks.json` 路径修正为 `data/tasks.json` | Assets 中文件实际位于 `data/tasks.json`，而非 workspace 根目录的 `tasks.json` |
| 9 | skill 路径规范修正：Expected Behavior 和 grade() 中 SKILL.md 路径改为 `skills/<skill名>/SKILL.md` | 原 grade() 检查 workspace 根下的 `SKILL.md`，不符合 OpenClaw 规范。同时 Assets 中已有 `skills/task-manager/SKILL.md` 可能造成混淆，需明确新创建的 skill 路径 |
| 10 | grade() 中 `no_completed_tasks_leaked` 逻辑优化 | 原逻辑过于简单：仅检查 completed task 关键词是否出现就扣分，但 Agent 可能在分析过程中合理提及 completed tasks 用于对比说明，应只检查是否被错误归类为 incomplete |
| 11 | grade() 中 SKILL.md 文件读取路径改为检查 `skills/` 子目录 | 与 skill 路径规范一致 |
| 12 | `workspace_files` 中需处理已有 `skills/task-manager/SKILL.md` 的存在 | Assets 中已有一个现成的 task-manager SKILL.md，Prompt 要求创建新 skill，需确保两者关系清晰。该已有 skill 是环境背景的一部分，Agent 应创建新的 incomplete-tasks 相关 skill |