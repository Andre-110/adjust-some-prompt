---
id: task_00401_incomplete_tasks_skill
name: Incomplete Tasks Listing Skill
category: Communication and Scheduling
subcategory: Task and Plan Management
difficulty: medium
grading_type: hybrid
grading_weights: {automated: 0.4, llm_judge: 0.6}
timeout_seconds: 600
input_modality: text-only
external_dependency: none
skill_creation: true
workspace_files:
  - source: data/tasks.json
    dest: data/tasks.json
  - source: data/task-config.yaml
    dest: data/task-config.yaml
  - source: data/task-stats.csv
    dest: data/task-stats.csv
  - source: data/tags-index.json
    dest: data/tags-index.json
  - source: data/archive/2025-06.json
    dest: data/archive/2025-06.json
  - source: memory/2025-07-17.md
    dest: memory/2025-07-17.md
  - source: skills/task-manager/SKILL.md
    dest: skills/task-manager/SKILL.md
---

## Prompt

Hey, I need a reusable skill for scanning task data and extracting incomplete items. Create it as a SKILL.md file under the skills directory — something inspired by autonomous-execution and task management patterns. It should know how to read a tasks file, filter out anything that's done, and present the remaining items sorted by priority and due date.

Once you've created the skill, go ahead and use it: list out all my incomplete tasks from data/tasks.json, organized by priority with due dates shown. I want to see what I still need to get done.

## Expected Behavior

The agent should:

1. **Create a SKILL.md file** at `skills/incomplete-tasks/SKILL.md` (or a similarly named skill directory) in the workspace with proper YAML frontmatter (including `name` and `description` fields) and markdown instruction sections describing how to scan task data, filter by completion status, and present results sorted by priority and due date. This skill is inspired by the autonomous-execution and task management skill patterns. Note: a `skills/task-manager/SKILL.md` already exists in the workspace; the agent should create a *new* skill focused specifically on incomplete-task extraction, not overwrite the existing one.

2. **Read `data/tasks.json`** from the workspace to find all tasks. The file contains 24 tasks (including subtasks) with statuses: `completed`, `in_progress`, `pending`, and no `cancelled` tasks.

3. **Filter out completed tasks** — tasks with `status: "completed"` should be excluded. The completed tasks are:
   - t-001: Prepare Q3 marketing budget proposal (completed)
   - t-001a: Collect vendor quotes for digital ads (completed)
   - t-001b: Review influencer rate cards (completed)
   - t-002a: Reproduce the issue on iOS 18 simulator (completed)
   - t-006: Submit expense report for Shanghai trip (completed)
   - t-007a: Research venue options (completed)
   - t-011: Weekly team standup notes - W28 (completed)

   That is 7 completed tasks.

4. **Identify all 17 incomplete tasks** (those with status `in_progress` or `pending`):

   **High priority:**
   - t-002: Fix login timeout bug on mobile app (high, 2025-07-18, in_progress)
   - t-002b: Patch token refresh interceptor (high, 2025-07-17, in_progress)
   - t-004: Renew apartment lease (high, 2025-07-25, pending)
   - t-004b: Email landlord with renewal decision (high, 2025-07-23, pending)
   - t-009: Buy birthday gift for Mom (high, 2025-07-21, pending)
   - t-010: Code review for PR #438 - Payment gateway refactor (high, 2025-07-17, pending)
   - t-013: Prepare slides for client demo on Friday (high, 2025-07-18, in_progress)
   - t-013a: Record screen capture demos for slides (high, 2025-07-17, pending)

   **Medium priority:**
   - t-002c: Write regression tests for token refresh (medium, 2025-07-18, pending)
   - t-003: Book dentist appointment (medium, 2025-07-20, pending)
   - t-004a: Compare current rent with market rates (medium, 2025-07-19, pending)
   - t-007: Plan team offsite for August (medium, 2025-07-28, in_progress)
   - t-007b: Get quotes from top 3 venues (medium, 2025-07-20, in_progress)

   **Low priority:**
   - t-005: Read 'Designing Data-Intensive Applications' (low, 2025-08-01, in_progress)
   - t-007c: Plan team activities and agenda (low, 2025-07-25, pending)
   - t-008: Update personal website portfolio (low, 2025-08-10, pending)
   - t-012: Cancel unused Adobe Creative Cloud subscription (low, 2025-07-31, pending)

5. **Present the results** organized by priority (high → medium → low), with due dates visible, in a clear readable format (e.g., a table or structured list).

## Grading Criteria

- [ ] A new SKILL.md exists under `skills/` (e.g., `skills/incomplete-tasks/SKILL.md`) with valid YAML frontmatter containing name and description
- [ ] SKILL.md contains instruction sections about task filtering and presentation
- [ ] All 17 incomplete tasks are identified (none missed, no completed tasks included)
- [ ] Tasks are organized/sorted by priority level
- [ ] Due dates are shown for each task
- [ ] All 8 high-priority incomplete tasks are listed (t-002, t-002b, t-004, t-004b, t-009, t-010, t-013, t-013a)
- [ ] All 5 medium-priority incomplete tasks are listed (t-002c, t-003, t-004a, t-007, t-007b)
- [ ] All 4 low-priority incomplete tasks are listed (t-005, t-007c, t-008, t-012)

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    import os
    import json
    import re
    import glob

    scores = {
        "skill_md_exists_and_structured": 0.0,
        "skill_md_has_instructions": 0.0,
        "incomplete_tasks_mentioned": 0.0,
        "no_completed_tasks_leaked": 0.0,
        "priority_organization": 0.0,
    }

    # 1. Check SKILL.md exists under skills/ directory (not the existing task-manager one)
    skill_content = ""
    skill_found = False

    # Search for any SKILL.md under skills/ that is NOT the pre-existing task-manager one
    skills_dir = os.path.join(workspace_path, "skills")
    if os.path.isdir(skills_dir):
        for root, dirs, files in os.walk(skills_dir):
            for fname in files:
                if fname.upper() == "SKILL.MD":
                    full_path = os.path.join(root, fname)
                    # Skip the pre-existing task-manager skill
                    if "task-manager" in full_path:
                        continue
                    try:
                        with open(full_path, "r", encoding="utf-8") as f:
                            skill_content = f.read()
                        skill_found = True
                        break
                    except Exception:
                        pass
            if skill_found:
                break

    # Also check workspace root as fallback
    if not skill_found:
        root_skill = os.path.join(workspace_path, "SKILL.md")
        if os.path.isfile(root_skill):
            try:
                with open(root_skill, "r", encoding="utf-8") as f:
                    skill_content = f.read()
                skill_found = True
            except Exception:
                pass

    if skill_found and skill_content.strip():
        has_frontmatter = skill_content.strip().startswith("---")
        has_name = bool(re.search(r'(?i)name\s*:', skill_content[:500]))
        has_description = bool(re.search(r'(?i)description\s*:', skill_content[:500]))
        if has_frontmatter and has_name and has_description:
            scores["skill_md_exists_and_structured"] = 1.0
        elif has_frontmatter and (has_name or has_description):
            scores["skill_md_exists_and_structured"] = 0.5
        elif has_frontmatter:
            scores["skill_md_exists_and_structured"] = 0.25

    # 2. Check SKILL.md has instruction content about task filtering
    if skill_content:
        instruction_keywords = ["filter", "incomplete", "status", "priority", "sort", "task", "complete", "pending", "in_progress"]
        matches = sum(1 for kw in instruction_keywords if kw.lower() in skill_content.lower())
        if matches >= 6:
            scores["skill_md_has_instructions"] = 1.0
        elif matches >= 4:
            scores["skill_md_has_instructions"] = 0.7
        elif matches >= 2:
            scores["skill_md_has_instructions"] = 0.3

    # Gather all assistant messages from transcript
    assistant_text = ""
    for event in transcript:
        if event.get("type") != "message":
            continue
        msg = event.get("message", {})
        if msg.get("role") == "assistant":
            content = msg.get("content", "")
            if isinstance(content, str):
                assistant_text += content + "\n"
            elif isinstance(content, list):
                for part in content:
                    if isinstance(part, dict) and part.get("type") == "text":
                        assistant_text += part.get("text", "") + "\n"

    # Also check for any output files the agent may have created
    output_text = assistant_text
    for fname in ["incomplete_tasks.md", "incomplete_tasks.txt", "output.md", "output.txt", "results.md"]:
        fpath = os.path.join(workspace_path, fname)
        if os.path.isfile(fpath):
            try:
                with open(fpath, "r", encoding="utf-8") as f:
                    output_text += "\n" + f.read()
            except Exception:
                pass

    if not output_text.strip():
        return scores

    # 3. Check incomplete tasks are mentioned
    # 17 incomplete tasks from data/tasks.json
    incomplete_task_ids = [
        "t-002", "t-002b", "t-002c", "t-003", "t-004", "t-004a", "t-004b",
        "t-005", "t-007", "t-007b", "t-007c", "t-008", "t-009", "t-010",
        "t-012", "t-013", "t-013a"
    ]
    incomplete_keywords = [
        "login timeout", "token refresh interceptor", "regression tests",
        "dentist", "apartment lease", "rent with market", "landlord",
        "Data-Intensive Applications", "team offsite", "venue quotes",
        "team activities", "personal website portfolio", "birthday gift",
        "PR #438", "payment gateway", "Adobe Creative Cloud",
        "client demo", "screen capture"
    ]

    found_ids = sum(1 for tid in incomplete_task_ids if tid.lower() in output_text.lower())
    found_keywords = sum(1 for kw in incomplete_keywords if kw.lower() in output_text.lower())

    if found_ids >= 15:
        scores["incomplete_tasks_mentioned"] = 1.0
    elif found_ids >= 12:
        scores["incomplete_tasks_mentioned"] = 0.85
    elif found_ids >= 9:
        scores["incomplete_tasks_mentioned"] = 0.7
    elif found_keywords >= 10:
        scores["incomplete_tasks_mentioned"] = 0.65
    elif found_ids >= 5 or found_keywords >= 7:
        scores["incomplete_tasks_mentioned"] = 0.5
    elif found_ids >= 3 or found_keywords >= 4:
        scores["incomplete_tasks_mentioned"] = 0.35
    elif found_ids >= 1 or found_keywords >= 2:
        scores["incomplete_tasks_mentioned"] = 0.2

    # 4. Check no completed tasks are incorrectly listed as incomplete
    completed_titles = [
        "Q3 marketing budget proposal",
        "Collect vendor quotes for digital ads",
        "Review influencer rate cards",
        "Reproduce the issue on iOS 18 simulator",
        "Submit expense report for Shanghai trip",
        "Research venue options",
        "Weekly team standup notes"
    ]
    completed_ids = ["t-001", "t-001a", "t-001b", "t-002a", "t-006", "t-007a", "t-011"]

    # Check if completed tasks appear in contexts suggesting they are incomplete
    # We look for these in sections/lists that seem to enumerate incomplete items
    leaked = 0
    text_lower = output_text.lower()

    for cid in completed_ids:
        # Look for the ID appearing near "incomplete", "pending", "todo", "in_progress" context
        # Simple heuristic: if the completed task ID appears in the output, count as potential leak
        # But exclude if it's clearly marked as completed
        pattern = re.escape(cid.lower())
        matches_in_text = list(re.finditer(pattern, text_lower))
        for m in matches_in_text:
            # Check surrounding context (100 chars)
            start = max(0, m.start() - 100)
            end = min(len(text_lower), m.end() + 100)
            context = text_lower[start:end]
            # If it appears in context without "completed" nearby, likely leaked
            if "completed" not in context and "done" not in context and "finished" not in context:
                leaked += 1
                break

    if leaked == 0:
        scores["no_completed_tasks_leaked"] = 1.0
    elif leaked <= 1:
        scores["no_completed_tasks_leaked"] = 0.7
    elif leaked <= 3:
        scores["no_completed_tasks_leaked"] = 0.4
    else:
        scores["no_completed_tasks_leaked"] = 0.0

    # 5. Check priority-based organization
    has_high = bool(re.search(r'high\s*priority|priority.*high|\bhigh\b.*\bpriority\b|###?\s*.*high', text_lower))
    has_medium = bool(re.search(r'medium\s*priority|priority.*medium|\bmedium\b.*\bpriority\b|###?\s*.*medium', text_lower))
    has_low = bool(re.search(r'low\s*priority|priority.*low|\blow\b.*\bpriority\b|###?\s*.*low', text_lower))

    # Also check for table headers or grouped listing patterns
    if not has_high:
        has_high = bool(re.search(r'\|\s*high\s*\|', text_lower)) or bool(re.search(r'\*\*high\*\*', text_lower))
    if not has_medium:
        has_medium = bool(re.search(r'\|\s*medium\s*\|', text_lower)) or bool(re.search(r'\*\*medium\*\*', text_lower))
    if not has_low:
        has_low = bool(re.search(r'\|\s*low\s*\|', text_lower)) or bool(re.search(r'\*\*low\*\*', text_lower))

    priority_count = sum([has_high, has_medium, has_low])
    if priority_count == 3:
        scores["priority_organization"] = 1.0
    elif priority_count == 2:
        scores["priority_organization"] = 0.6
    elif priority_count == 1:
        scores["priority_organization"] = 0.3

    return scores
```

## LLM Judge Rubric

### Skill File Quality (Weight: 20%)
- 1.0: A new SKILL.md is created under `skills/` (e.g., `skills/incomplete-tasks/SKILL.md`) with YAML frontmatter (name, description), clear sections explaining how to read task data, filter by completion status, sort by priority/date, and present results. Reusable and self-contained. Does not overwrite the existing `skills/task-manager/SKILL.md`.
- 0.75: New SKILL.md exists under `skills/` with frontmatter and reasonable instructions but missing some detail or polish.
- 0.5: SKILL.md exists but is minimal — frontmatter is incomplete or instructions are vague, or it was placed at the workspace root instead of under `skills/`.
- 0.25: SKILL.md exists but is essentially a stub with little useful content, or the existing task-manager SKILL.md was overwritten.
- 0.0: No new SKILL.md is created, output is empty, or has no relation to task management.

### Completeness of Incomplete Task Listing (Weight: 30%)
- 1.0: All 17 incomplete tasks from `data/tasks.json` are listed with their titles, and no completed tasks are incorrectly included. The 17 tasks include: t-002, t-002b, t-002c, t-003, t-004, t-004a, t-004b, t-005, t-007, t-007b, t-007c, t-008, t-009, t-010, t-012, t-013, t-013a.
- 0.75: 13-16 incomplete tasks listed correctly, no completed tasks leaked.
- 0.5: 8-12 incomplete tasks listed, or all 17 listed but some completed tasks are also incorrectly included.
- 0.25: Only 1-7 incomplete tasks listed, or significant errors in the listing.
- 0.0: No incomplete tasks listed, output is empty, or the response is disconnected from the data/tasks.json data.

### Organization and Sorting (Weight: 25%)
- 1.0: Tasks are clearly grouped by priority (high, medium, low) and within each group sorted or displayed with due dates. Easy to scan and understand urgency.
- 0.75: Tasks are grouped by priority with due dates shown, but ordering within groups is not optimal.
- 0.5: Some priority grouping is present but inconsistent, or due dates are partially missing.
- 0.25: Tasks are listed but with no meaningful organization by priority or date.
- 0.0: No organization at all, or output is missing.

### Evidence and Workspace Grounding (Weight: 25%)
- 1.0: The response clearly draws from the actual `data/tasks.json` data — task IDs, titles, statuses, due dates, and priorities all match the workspace file. The agent demonstrably read the file and used the correct data (2025 dates, real task titles like "Renew apartment lease", "Buy birthday gift for Mom", etc.).
- 0.75: Most details match the workspace data with minor discrepancies.
- 0.5: Some details match but there are noticeable inaccuracies or hallucinated task details not in the file.
- 0.25: Vague response that could be generic; weak evidence of reading the actual file.
- 0.0: Response ignores the workspace data entirely, hallucinates tasks not in the file, or provides no deliverable.