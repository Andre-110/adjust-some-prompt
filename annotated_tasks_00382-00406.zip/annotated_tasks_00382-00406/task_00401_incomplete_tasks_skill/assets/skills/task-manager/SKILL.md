# Task Manager Skill

Smart task management system with hierarchical tasks, scheduled migration, auto-cleanup, smart retention, and archiving.

## Data Location

- **Active tasks:** `data/tasks.json`
- **Archives:** `data/archive/YYYY-MM.json`
- **Config:** `data/task-config.yaml`

## Task Schema

Each task has:
- `id` — unique identifier (e.g. `t-001`)
- `title` — short description
- `description` — detailed notes
- `status` — one of: `pending`, `in_progress`, `completed`, `cancelled`
- `priority` — `high`, `medium`, `low`
- `dueDate` — ISO date string
- `completedAt` — ISO datetime or null
- `tags` — array of category labels
- `parent` — parent task id or null
- `subtasks` — array of child task ids

## Commands

### List incomplete tasks
Read `data/tasks.json` and filter for `status != "completed"` and `status != "cancelled"`.
Display grouped by priority, then by due date.

### Add task
Append to `data/tasks.json` tasks array with a new unique id.

### Complete task
Set `status` to `completed` and `completedAt` to current timestamp.

### Archive
Monthly: move completed tasks older than 30 days to `data/archive/YYYY-MM.json`.

## Migration Rules

- Tasks completed > 30 days ago → auto-archive
- Overdue tasks with no activity > 14 days → flag for review
- Cancelled tasks → archive after 7 days

## Display Format

When listing tasks, use this format:
```
[PRIORITY] Title (due: YYYY-MM-DD) [STATUS]
  └─ Subtask title [STATUS]
```
