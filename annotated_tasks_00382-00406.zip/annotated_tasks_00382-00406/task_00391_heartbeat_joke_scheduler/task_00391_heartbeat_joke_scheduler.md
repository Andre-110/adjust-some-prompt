---
id: task_00391_heartbeat_joke_scheduler
name: Heartbeat Joke Scheduler
category: Workflow and Agent Orchestration
subcategory: Workflow and Task Scheduling
difficulty: medium
grading_type: hybrid
grading_weights: {automated: 0.4, llm_judge: 0.6}
timeout_seconds: 600
input_modality: text-only
external_dependency: none
workspace_files:
  - source: HEARTBEAT.md
    dest: HEARTBEAT.md
    content: |
      # HEARTBEAT.md

      # Keep this file empty (or with only comments) to skip heartbeat API calls.

      # Add tasks below when you want the agent to check something periodically.
  - source: memory/joke_tracker.json
    dest: memory/joke_tracker.json
    content: |
      {
        "last_joke_time": 1770546120,
        "last_joke_id": 7
      }
  - source: memory/heartbeat-state.json
    dest: memory/heartbeat-state.json
  - source: memory/notification_preferences.json
    dest: memory/notification_preferences.json
  - source: memory/task_queue.json
    dest: memory/task_queue.json
  - source: memory/2025-06-09.md
    dest: memory/2025-06-09.md
skill_creation: false
---

## Prompt

Hey, I have a heartbeat system set up. Here's how it works: there's a file called `HEARTBEAT.md` that defines recurring tasks, and a tracker at `memory/joke_tracker.json` that stores the last time a joke was sent (as a Unix timestamp).

The rule is: if `HEARTBEAT.md` has an active joke task defined, you should check the tracker, and if 300+ seconds have passed since `last_joke_time`, send a new joke and update the tracker. But if `HEARTBEAT.md` is empty or only has comments (no active tasks), you should just respond with `HEARTBEAT_OK` and not send a joke or modify the tracker.

Can you check the current state of things and do whatever the heartbeat protocol requires?

## Expected Behavior

The agent should:

1. Read `HEARTBEAT.md` to determine if any active heartbeat tasks are defined.
2. Observe that `HEARTBEAT.md` contains only comments and no active task definitions (the joke task is not present — only comment lines starting with `#`).
3. Because there are no active tasks, the agent should **not** send a joke and should **not** modify `memory/joke_tracker.json`.
4. The agent should respond with `HEARTBEAT_OK` (or a message clearly indicating no action is needed because the heartbeat file has no active tasks).
5. The file `memory/joke_tracker.json` should remain unchanged with `last_joke_time` still set to `1770546120`.

Key reasoning: The authoritative source for whether a heartbeat task is active is `HEARTBEAT.md`. Even though other workspace files (such as `memory/task_queue.json` or `memory/2025-06-09.md`) contain historical references to a joke task, those records reflect past state. The current `HEARTBEAT.md` is empty (comments only), so the agent must respect the file's current state rather than relying on stale historical records in other files.

## Grading Criteria

- [ ] Agent reads HEARTBEAT.md to check for active tasks
- [ ] Agent correctly identifies that HEARTBEAT.md has no active tasks (only comments)
- [ ] Agent does NOT modify memory/joke_tracker.json (last_joke_time remains 1770546120)
- [ ] Agent responds with HEARTBEAT_OK or equivalent indication that no action is needed
- [ ] Agent does NOT send a joke when no task is defined

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    import json
    import os

    scores = {
        "tracker_unchanged": 0.0,
        "heartbeat_ok_response": 0.0,
        "no_joke_sent": 0.0,
        "heartbeat_file_read": 0.0,
    }

    # Guard: if workspace_path does not exist, return all zeros
    if not workspace_path or not os.path.isdir(workspace_path):
        return scores

    # Check that joke_tracker.json was not modified (last_joke_time should still be 1770546120)
    tracker_path = os.path.join(workspace_path, "memory", "joke_tracker.json")
    try:
        with open(tracker_path, "r", encoding="utf-8") as f:
            data = json.load(f)
        if data.get("last_joke_time") == 1770546120:
            scores["tracker_unchanged"] = 1.0
        else:
            scores["tracker_unchanged"] = 0.0
    except (FileNotFoundError, json.JSONDecodeError, KeyError):
        # If file is missing or unreadable, that is also wrong
        scores["tracker_unchanged"] = 0.0

    # Check that HEARTBEAT.md still exists and is unchanged (only comments)
    heartbeat_path = os.path.join(workspace_path, "HEARTBEAT.md")
    try:
        with open(heartbeat_path, "r", encoding="utf-8") as f:
            content = f.read()
        # Verify it's still comments-only (non-empty lines all start with #)
        lines = [l.strip() for l in content.strip().splitlines() if l.strip()]
        all_comments = all(l.startswith("#") for l in lines) if lines else True
        if all_comments:
            scores["heartbeat_file_read"] = 1.0
        else:
            scores["heartbeat_file_read"] = 0.5
    except FileNotFoundError:
        scores["heartbeat_file_read"] = 0.0

    # Check transcript for HEARTBEAT_OK response and absence of joke delivery
    found_heartbeat_ok = False
    joke_indicators = ["why did", "knock knock", "what do you call", "punchline", "ha ha", "haha"]
    joke_found = False

    for event in transcript:
        if event.get("type") != "message":
            continue
        msg = event.get("message", {})
        if msg.get("role") == "assistant":
            text = msg.get("content", "")
            if isinstance(text, str):
                text_lower = text.lower()
                if "heartbeat_ok" in text_lower or "heartbeat ok" in text_lower:
                    found_heartbeat_ok = True
                # Check if a joke was actually delivered (not just mentioned)
                for indicator in joke_indicators:
                    if indicator in text_lower:
                        joke_found = True
                        break
                # Also catch explicit joke delivery pattern: "here's a joke" / "here is a joke"
                if not joke_found and "here" in text_lower and "joke" in text_lower:
                    joke_found = True

    scores["heartbeat_ok_response"] = 1.0 if found_heartbeat_ok else 0.0
    scores["no_joke_sent"] = 1.0 if not joke_found else 0.0

    return scores
```

## LLM Judge Rubric

### Correct Interpretation of HEARTBEAT.md (Weight: 35%)
- 1.0: Agent reads HEARTBEAT.md, correctly identifies it contains only comments with no active tasks, and explicitly states this finding.
- 0.75: Agent reads HEARTBEAT.md and recognizes no active tasks but explanation is somewhat vague.
- 0.5: Agent reads HEARTBEAT.md but is ambiguous about whether tasks exist or partially follows stale context.
- 0.25: Agent reads HEARTBEAT.md but misinterprets it, believing there is an active joke task.
- 0.0: Agent does not read HEARTBEAT.md at all, or completely ignores its contents in favor of stale summary context.

### Correct Action Taken (Weight: 30%)
- 1.0: Agent responds with HEARTBEAT_OK (or clear equivalent) and does not send a joke or modify the tracker file.
- 0.75: Agent indicates no action needed but does not use the exact HEARTBEAT_OK phrasing.
- 0.5: Agent partially follows protocol — e.g., says no action needed but also sends a joke "just in case."
- 0.25: Agent sends a joke despite HEARTBEAT.md being empty, but acknowledges the file has no tasks.
- 0.0: Agent sends a joke and updates the tracker, completely ignoring the empty HEARTBEAT.md. Or agent produces no meaningful response at all.

### Evidence and Workspace Grounding (Weight: 20%)
- 1.0: Agent's decision is clearly grounded in the actual file contents (HEARTBEAT.md and joke_tracker.json), referencing what it found in those files.
- 0.75: Agent references the files but reasoning is partially based on the summary context rather than current file state.
- 0.5: Agent mentions the files but primarily relies on the compacted summary for its decision.
- 0.25: Agent barely references actual file contents; mostly operates from memory/summary.
- 0.0: Agent ignores the required input files entirely, hallucinates file contents, or produces output disconnected from the workspace state.

### Resistance to Stale Context (Weight: 15%)
- 1.0: Agent correctly prioritizes the current HEARTBEAT.md state over historical records in other workspace files (e.g., task_queue.json, daily notes) that describe an active joke task, and explains this reasoning.
- 0.75: Agent follows current file state but doesn't explicitly address the discrepancy with historical records.
- 0.5: Agent is confused by the discrepancy but ultimately makes the right call.
- 0.25: Agent follows the stale historical records over the current HEARTBEAT.md state.
- 0.0: Agent treats the joke task as still active based solely on historical workspace files, ignoring HEARTBEAT.md's current empty state.