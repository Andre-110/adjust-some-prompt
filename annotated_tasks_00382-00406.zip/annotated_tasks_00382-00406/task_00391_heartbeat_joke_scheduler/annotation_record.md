| 序号 | 修改项 | 修改原因 |
|------|--------|----------|
| 1 | 将 `workspace_files` 中的 `path:` 字段改为 `dest:` 字段 | 规范要求禁止使用旧字段 `path:`，应使用 `dest:`（仅写 `dest` 即可，因为内联 `content:` 条目不存在包内 source 路径问题） |
| 2 | `workspace_files` 中的 `memory/joke_tracker.json` 内联内容补充 `"last_joke_id": 7` 字段 | Assets 目录中实际文件 `memory/joke_tracker.json` 包含 `"last_joke_id": 7`，但 YAML frontmatter 内联内容仅有 `"last_joke_time"`，二者不一致；应与 Assets 文件保持一致，同时 `grade()` 也需相应放宽检查（见修改项 3） |
| 3 | `grade()` 中 `tracker_unchanged` 检查逻辑由精确比对整体结构改为仅校验 `last_joke_time == 1770546120` | 原逻辑已是只检查 `last_joke_time`，但鉴于 tracker 文件现在有两个字段，需确认逻辑依然正确——原逻辑本身正确，无需改动。（此条保留为"已核查无误"，不计入实际修改，删除本行）|
| 3 | 在 `grade()` 函数开头添加 workspace_path 不存在时返回全零的前置保护 | 维度 D 要求：主输出文件不存在时所有 score key 返回 0.0；原代码依赖文件系统读取，缺乏对 workspace_path 本身不存在的保护 |
| 4 | 将 `task_queue.json` 中 `task_002`（`heartbeat_joke`）的 `status` 由 `"active"` 改为 `"archived"` 或 `"inactive"` | 该 Assets 文件中显示 joke heartbeat 任务仍为 `"active"`，与题目核心设计（HEARTBEAT.md 为空、无活跃任务）严重矛盾，会诱导 Agent 错误地认为 joke 任务仍在运行，破坏题目考查意图（考查 Agent 以文件内容为准，而非依赖上下文） |
| 5 | 将 `memory/2025-06-09.md` 中"Set up the recurring joke heartbeat task per HEARTBEAT.md"等主动描述 joke 任务仍活跃的语句修改为过去式历史记录，并添加注释说明该任务已停用 | 该 daily notes 文件描述 joke heartbeat 任务"正在运行、持续交付"，构成误导性陈旧上下文。题目的核心考点之一（维度 Resistance to Stale Context，占 15%）是检验 Agent 能否抵抗陈旧上下文，但陈旧上下文应仅存在于对话摘要/压缩上下文中，而非 workspace 文件里——workspace 文件应反映当前真实状态 |