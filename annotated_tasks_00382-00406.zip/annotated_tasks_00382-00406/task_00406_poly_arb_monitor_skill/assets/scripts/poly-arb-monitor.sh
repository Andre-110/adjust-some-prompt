#!/usr/bin/env bash
#
# poly-arb-monitor.sh — Enhanced POL/USDC Arbitrage Monitor
# Checks wallet balances, monitors transaction logs, and alerts on anomalies.
#
# Usage: ./poly-arb-monitor.sh [--config <path>] [--verbose]
# Cron ID: a2ce4b5b-63bf-4235-a84d-5a66cf18532f
#

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"
CONFIG_FILE="${PROJECT_ROOT}/config/arb-config.yaml"
LOG_DIR="${PROJECT_ROOT}/logs"
DATA_DIR="${PROJECT_ROOT}/data"
TIMESTAMP=$(date -u +"%Y-%m-%dT%H:%M:%SZ")

# ---------- Argument parsing ----------
VERBOSE=false
while [[ $# -gt 0 ]]; do
  case "$1" in
    --config) CONFIG_FILE="$2"; shift 2 ;;
    --verbose) VERBOSE=true; shift ;;
    *) echo "Unknown option: $1"; exit 1 ;;
  esac
done

# ---------- Helpers ----------
log_info()  { echo "[${TIMESTAMP}] [INFO]  $*" | tee -a "${LOG_DIR}/monitor.log"; }
log_warn()  { echo "[${TIMESTAMP}] [WARN]  $*" | tee -a "${LOG_DIR}/monitor.log"; }
log_error() { echo "[${TIMESTAMP}] [ERROR] $*" | tee -a "${LOG_DIR}/monitor.log"; }

check_dependency() {
  command -v "$1" >/dev/null 2>&1 || { log_error "Missing dependency: $1"; exit 1; }
}

# ---------- Dependencies ----------
check_dependency curl
check_dependency jq
check_dependency python3

# ---------- Load config ----------
if [[ ! -f "$CONFIG_FILE" ]]; then
  log_error "Config file not found: $CONFIG_FILE"
  exit 1
fi

# Parse YAML config using python
read_yaml() {
  python3 -c "
import yaml, sys
with open('${CONFIG_FILE}') as f:
    cfg = yaml.safe_load(f)
path = '$1'.split('.')
val = cfg
for p in path:
    val = val[p]
print(val)
" 2>/dev/null
}

RPC_URL=$(read_yaml "network.rpc_url")
WALLET_ADDR=$(read_yaml "wallet.address")
POL_CONTRACT=$(read_yaml "tokens.POL.contract")
USDC_CONTRACT=$(read_yaml "tokens.USDC.contract")
BALANCE_THRESHOLD_POL=$(read_yaml "alerts.min_balance_pol")
BALANCE_THRESHOLD_USDC=$(read_yaml "alerts.min_balance_usdc")
PROFIT_THRESHOLD=$(read_yaml "alerts.min_profit_usd")
WEBHOOK_URL=$(read_yaml "alerts.webhook_url")

log_info "=== Enhanced Arbitrage Monitor Started ==="
log_info "Wallet: ${WALLET_ADDR}"
log_info "RPC: ${RPC_URL}"

# ---------- Balance check via eth_call ----------
get_erc20_balance() {
  local contract="$1"
  local wallet="$2"
  local padded_addr
  padded_addr=$(printf '%064s' "${wallet#0x}" | tr ' ' '0')
  
  local data="0x70a08231000000000000000000000000${padded_addr}"
  
  local response
  response=$(curl -s --max-time 10 -X POST "${RPC_URL}" \
    -H "Content-Type: application/json" \
    -d "{
      \"jsonrpc\": \"2.0\",
      \"method\": \"eth_call\",
      \"params\": [{
        \"to\": \"${contract}\",
        \"data\": \"${data}\"
      }, \"latest\"],
      \"id\": 1
    }")
  
  local hex_balance
  hex_balance=$(echo "$response" | jq -r '.result // "0x0"')
  
  # Convert hex to decimal
  python3 -c "print(int('${hex_balance}', 16))" 2>/dev/null || echo "0"
}

# ---------- Fetch balances ----------
log_info "Checking POL balance..."
POL_RAW=$(get_erc20_balance "$POL_CONTRACT" "$WALLET_ADDR")
POL_BALANCE=$(python3 -c "print(f'{int(${POL_RAW}) / 1e18:.6f}')")

log_info "Checking USDC balance..."
USDC_RAW=$(get_erc20_balance "$USDC_CONTRACT" "$WALLET_ADDR")
USDC_BALANCE=$(python3 -c "print(f'{int(${USDC_RAW}) / 1e6:.2f}')")

log_info "POL Balance:  ${POL_BALANCE}"
log_info "USDC Balance: ${USDC_BALANCE}"

# ---------- Balance alerts ----------
POL_LOW=$(python3 -c "print('true' if float(${POL_BALANCE}) < float(${BALANCE_THRESHOLD_POL}) else 'false')")
USDC_LOW=$(python3 -c "print('true' if float(${USDC_BALANCE}) < float(${BALANCE_THRESHOLD_USDC}) else 'false')")

if [[ "$POL_LOW" == "true" ]]; then
  log_warn "POL balance below threshold! Current: ${POL_BALANCE}, Min: ${BALANCE_THRESHOLD_POL}"
fi

if [[ "$USDC_LOW" == "true" ]]; then
  log_warn "USDC balance below threshold! Current: ${USDC_BALANCE}, Min: ${BALANCE_THRESHOLD_USDC}"
fi

# ---------- Transaction log analysis ----------
TX_LOG="${LOG_DIR}/transactions.log"
SUMMARY_FILE="${DATA_DIR}/balance-snapshot.json"

if [[ -f "$TX_LOG" ]]; then
  log_info "Analyzing transaction log..."
  
  TOTAL_TXS=$(wc -l < "$TX_LOG" | tr -d ' ')
  FAILED_TXS=$(grep -c '"status":"failed"' "$TX_LOG" 2>/dev/null || echo "0")
  SUCCESSFUL_TXS=$((TOTAL_TXS - FAILED_TXS))
  
  # Calculate profit from last 24h
  RECENT_PROFIT=$(python3 -c "
import json, sys
from datetime import datetime, timedelta

cutoff = datetime.utcnow() - timedelta(hours=24)
total = 0.0
count = 0

with open('${TX_LOG}') as f:
    for line in f:
        line = line.strip()
        if not line:
            continue
        try:
            tx = json.loads(line)
            ts = datetime.fromisoformat(tx.get('timestamp', '').replace('Z', '+00:00').replace('+00:00', ''))
            if ts.replace(tzinfo=None) >= cutoff and tx.get('status') == 'success':
                total += float(tx.get('profit_usd', 0))
                count += 1
        except (json.JSONDecodeError, ValueError):
            continue

print(f'{total:.4f}')
" 2>/dev/null || echo "0.0000")
  
  log_info "Total transactions: ${TOTAL_TXS}"
  log_info "Successful: ${SUCCESSFUL_TXS}, Failed: ${FAILED_TXS}"
  log_info "24h profit (USD): ${RECENT_PROFIT}"
  
  PROFIT_LOW=$(python3 -c "print('true' if float(${RECENT_PROFIT}) < float(${PROFIT_THRESHOLD}) else 'false')")
  if [[ "$PROFIT_LOW" == "true" ]]; then
    log_warn "24h profit below threshold! Current: \$${RECENT_PROFIT}, Min: \$${PROFIT_THRESHOLD}"
  fi
else
  log_warn "Transaction log not found: ${TX_LOG}"
  TOTAL_TXS=0
  FAILED_TXS=0
  SUCCESSFUL_TXS=0
  RECENT_PROFIT="0.0000"
fi

# ---------- Gas price check ----------
log_info "Checking current gas price..."
GAS_RESPONSE=$(curl -s --max-time 10 -X POST "${RPC_URL}" \
  -H "Content-Type: application/json" \
  -d '{"jsonrpc":"2.0","method":"eth_gasPrice","params":[],"id":1}')

GAS_GWEI=$(python3 -c "
import json
resp = json.loads('${GAS_RESPONSE}' if '${GAS_RESPONSE}' else '{\"result\":\"0x0\"}')
hex_val = resp.get('result', '0x0')
print(f'{int(hex_val, 16) / 1e9:.2f}')
" 2>/dev/null || echo "0.00")

log_info "Current gas price: ${GAS_GWEI} Gwei"

# ---------- Write snapshot ----------
cat > "$SUMMARY_FILE" <<EOF
{
  "timestamp": "${TIMESTAMP}",
  "wallet": "${WALLET_ADDR}",
  "balances": {
    "POL": ${POL_BALANCE},
    "USDC": ${USDC_BALANCE}
  },
  "transactions_24h": {
    "total": ${TOTAL_TXS},
    "successful": ${SUCCESSFUL_TXS},
    "failed": ${FAILED_TXS},
    "profit_usd": ${RECENT_PROFIT}
  },
  "gas_gwei": ${GAS_GWEI},
  "alerts": {
    "pol_low": ${POL_LOW},
    "usdc_low": ${USDC_LOW},
    "profit_low": ${PROFIT_LOW:-false}
  }
}
EOF

log_info "Snapshot saved to ${SUMMARY_FILE}"

# ---------- Webhook alert ----------
if [[ "$POL_LOW" == "true" || "$USDC_LOW" == "true" || "${PROFIT_LOW:-false}" == "true" ]]; then
  if [[ -n "$WEBHOOK_URL" && "$WEBHOOK_URL" != "null" ]]; then
    log_info "Sending alert webhook..."
    curl -s --max-time 10 -X POST "$WEBHOOK_URL" \
      -H "Content-Type: application/json" \
      -d @"$SUMMARY_FILE" >/dev/null 2>&1 || log_warn "Webhook delivery failed"
  fi
fi

log_info "=== Monitor Run Complete ==="
