---
id: task_00406_poly_arb_monitor_skill
name: POL/USDC Arbitrage Monitor Skill Creation
category: System Administration
subcategory: System Operations and Monitoring
difficulty: medium
grading_type: hybrid
grading_weights: {automated: 0.4, llm_judge: 0.6}
timeout_seconds: 600
input_modality: text-only
external_dependency: none
workspace_files:
  - source: config/arb-config.yaml
    dest: config/arb-config.yaml
  - source: config/cron-tasks.json
    dest: config/cron-tasks.json
  - source: scripts/poly-arb-monitor.sh
    dest: scripts/poly-arb-monitor.sh
skill_creation: true
---

## Prompt

Hey, I need a reusable monitoring skill for crypto arbitrage wallets. Inspired by skills like `social-trend-report` (automated trend monitoring with report generation), `grafana-plugin` (reading live dashboard values), and `agentic-ai-gold` (self-improving agent framework), I want you to create a skill file at `skills/poly-arb-monitor/SKILL.md` that encapsulates the capability of checking on-chain token balances (specifically POL and USDC), logging the results, and producing a structured snapshot report.

Once you've created the skill, use it to actually run the enhanced monitoring check right now. Here's the context:

- This is a scheduled cron task (ID: `a2ce4b5b-63bf-4235-a84d-5a66cf18532f`, name: `poly-arb-monitor-enhanced`)
- Current time: Tuesday, February 10th, 2026 — 8:00 PM Asia/Shanghai
- You should check POL/USDC balances for the monitoring wallet
- Write a balance snapshot to `data/balance-snapshot.json` with at least the token names, balances, a timestamp, and threshold status
- Write monitoring output to `logs/monitor.log`
- If tools like `jq` or `pip` aren't available, work around it with whatever is available (e.g., pure Python + curl)
- Produce a brief monitoring report summarizing the balance status (include a table with token, balance, threshold, and status)

Reference files are available in your workspace:
- `config/arb-config.yaml` — network, wallet, token, and alert configuration
- `config/cron-tasks.json` — cron task definitions (find the task ID `a2ce4b5b-63bf-4235-a84d-5a66cf18532f` here)
- `scripts/poly-arb-monitor.sh` — existing monitoring shell script for reference

Make sure the workspace is initialized as a git repo too so we can track changes over time.

## Expected Behavior

The agent should:

1. **Create a skill file at `skills/poly-arb-monitor/SKILL.md`** with YAML frontmatter containing `name` and `description` fields, plus markdown instruction sections describing how to perform on-chain balance monitoring, logging, and snapshot generation. The skill should be inspired by the referenced skills (social-trend-report, grafana-plugin, agentic-ai-gold).

2. **Initialize a git repository** in the workspace so that monitoring artifacts can be version-tracked.

3. **Create `data/balance-snapshot.json`** containing a JSON object with at least: token identifiers (POL, USDC), balance values, a timestamp, and threshold/status information.

4. **Create `logs/monitor.log`** containing monitoring output — log entries related to the balance check execution.

5. **Produce a monitoring report** (in the assistant's response or in a file) that includes a summary table with columns for Token, Balance, Threshold, and Status, covering both POL and USDC.

6. Handle missing system tools gracefully (e.g., fall back to Python if `jq` is unavailable).

## Grading Criteria

- [ ] `skills/poly-arb-monitor/SKILL.md` exists with proper YAML frontmatter (name and description fields) and instruction sections
- [ ] Git repository initialized (.git/HEAD exists)
- [ ] `data/balance-snapshot.json` exists and contains valid JSON with token balance data
- [ ] `logs/monitor.log` exists and contains monitoring log entries
- [ ] Monitoring report includes both POL and USDC status information
- [ ] Balance snapshot includes timestamp and threshold/status fields

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    import os
    import json
    from pathlib import Path

    ws = Path(workspace_path)
    scores = {
        "skill_md_exists_and_valid": 0.0,
        "git_initialized": 0.0,
        "balance_snapshot_valid": 0.0,
        "monitor_log_exists": 0.0,
        "snapshot_has_threshold_and_timestamp": 0.0,
    }

    # 1. Check skills/poly-arb-monitor/SKILL.md exists and has proper structure
    skill_path = ws / "skills" / "poly-arb-monitor" / "SKILL.md"
    if skill_path.exists():
        content = skill_path.read_text(errors="replace")
        has_frontmatter = content.strip().startswith("---")
        has_name = "name:" in content.lower()
        has_description = "description:" in content.lower()
        # Check for instruction sections (markdown headings)
        has_sections = content.count("#") >= 2
        if has_frontmatter and has_name and has_description and has_sections:
            scores["skill_md_exists_and_valid"] = 1.0
        elif has_frontmatter and (has_name or has_description):
            scores["skill_md_exists_and_valid"] = 0.5
        elif has_name or has_description:
            scores["skill_md_exists_and_valid"] = 0.25

    # 2. Check git initialized
    git_head = ws / ".git" / "HEAD"
    if git_head.exists():
        head_content = git_head.read_text(errors="replace").strip()
        if "ref:" in head_content or len(head_content) == 40:
            scores["git_initialized"] = 1.0

    # 3. Check balance snapshot
    snapshot_path = ws / "data" / "balance-snapshot.json"
    snapshot_data = None
    raw_lower = ""
    if snapshot_path.exists():
        try:
            raw = snapshot_path.read_text(errors="replace")
            snapshot_data = json.loads(raw)
            raw_lower = raw.lower()
            has_pol = "pol" in raw_lower
            has_usdc = "usdc" in raw_lower
            if has_pol and has_usdc:
                scores["balance_snapshot_valid"] = 1.0
            elif has_pol or has_usdc:
                scores["balance_snapshot_valid"] = 0.5
        except (json.JSONDecodeError, Exception):
            scores["balance_snapshot_valid"] = 0.1

    # 4. Check monitor log
    log_path = ws / "logs" / "monitor.log"
    if log_path.exists():
        log_content = log_path.read_text(errors="replace").strip()
        if len(log_content) > 10:
            scores["monitor_log_exists"] = 1.0
        elif len(log_content) > 0:
            scores["monitor_log_exists"] = 0.5

    # 5. Check snapshot has timestamp and threshold/status fields
    if snapshot_data is not None:
        has_timestamp = "timestamp" in raw_lower or "time" in raw_lower or "date" in raw_lower
        has_threshold = "threshold" in raw_lower or "status" in raw_lower
        if has_timestamp and has_threshold:
            scores["snapshot_has_threshold_and_timestamp"] = 1.0
        elif has_timestamp or has_threshold:
            scores["snapshot_has_threshold_and_timestamp"] = 0.5

    return scores
```

## LLM Judge Rubric

### Skill Definition Quality (Weight: 25%)
Evaluates whether `skills/poly-arb-monitor/SKILL.md` is well-structured, has proper YAML frontmatter with name and description, contains clear instruction sections, and is genuinely inspired by the referenced skills (social-trend-report, grafana-plugin, agentic-ai-gold).

- 1.0: SKILL.md is created at the correct path (`skills/poly-arb-monitor/SKILL.md`), has complete YAML frontmatter, multiple well-written instruction sections, and clearly draws from the referenced skill patterns (monitoring, reporting, self-improvement).
- 0.75: SKILL.md has frontmatter and reasonable sections but only loosely connects to the referenced skills, or is placed at a slightly non-standard path.
- 0.5: SKILL.md exists with basic structure but is thin on content or missing key sections.
- 0.25: SKILL.md exists but is poorly structured or missing frontmatter.
- 0.0: SKILL.md is missing, empty, or has no meaningful monitoring-related content.

### Monitoring Report Completeness (Weight: 30%)
Evaluates whether the agent produced a clear monitoring report covering POL and USDC balances with a summary table including Token, Balance, Threshold, and Status columns.

- 1.0: Report includes a well-formatted table with all four columns (Token, Balance, Threshold, Status) for both POL and USDC, plus contextual information (wallet address, timestamp).
- 0.75: Report covers both tokens with most required columns but is missing one detail (e.g., no threshold column).
- 0.5: Report mentions both tokens but lacks table format or is missing multiple fields.
- 0.25: Report mentions only one token or provides very sparse information.
- 0.0: No monitoring report produced, or report is completely unrelated to POL/USDC balance monitoring.

### Evidence and Workspace Grounding (Weight: 25%)
Evaluates whether the agent's outputs are grounded in actual workspace artifacts — `balance-snapshot.json`, `monitor.log`, `skills/poly-arb-monitor/SKILL.md`, and git initialization — rather than hallucinated or disconnected from the task's required files.

- 1.0: All key files (`skills/poly-arb-monitor/SKILL.md`, `data/balance-snapshot.json`, `logs/monitor.log`, `.git`) are created with meaningful, consistent content that aligns with the monitoring task.
- 0.75: Most files are present and consistent; minor gaps in content alignment.
- 0.5: Some required files are present but content is generic or inconsistent with the task.
- 0.25: Only one or two required files exist; significant content gaps.
- 0.0: Required output files are missing, empty, or the agent hallucinated results without creating the specified deliverables.

### Adaptability and Problem Solving (Weight: 20%)
Evaluates whether the agent handled environment constraints gracefully (e.g., missing jq, pip, pyyaml) and found workable alternatives to complete the monitoring task.

- 1.0: Agent identified missing tools, clearly communicated the issue, and successfully used alternatives (e.g., pure Python) to complete all deliverables.
- 0.75: Agent worked around most constraints with minor issues in execution.
- 0.5: Agent acknowledged constraints but only partially completed the task due to environment limitations.
- 0.25: Agent struggled with constraints and produced incomplete results.
- 0.0: Agent failed to handle missing tools or did not attempt any workaround.