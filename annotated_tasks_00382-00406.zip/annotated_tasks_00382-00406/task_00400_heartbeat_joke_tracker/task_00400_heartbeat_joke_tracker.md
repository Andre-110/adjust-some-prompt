---
id: task_00400_heartbeat_joke_tracker
name: Heartbeat Task - Joke Tracker Protocol
category: Workflow and Agent Orchestration
subcategory: Workflow and Task Scheduling
difficulty: medium
grading_type: hybrid
grading_weights: {automated: 0.4, llm_judge: 0.6}
timeout_seconds: 600
input_modality: text-only
external_dependency: none
workspace_files:
  - source: HEARTBEAT.md
    dest: HEARTBEAT.md
    content: |
      # HEARTBEAT.md

      # Keep this file empty (or with only comments) to skip heartbeat API calls.

      # Add tasks below when you want the agent to check something periodically.
  - source: memory/joke_tracker.json
    dest: memory/joke_tracker.json
    content: |
      {
        "last_joke_time": 1770546120,
        "last_joke_id": 3,
        "jokes_told_today": 7
      }
  - source: memory/2025-06-09.md
    dest: memory/2025-06-09.md
    role: trap
    description: "Historical memory log. Records past joke deliveries based on a previous HEARTBEAT.md configuration. Should not be interpreted as current instructions."
  - source: memory/heartbeat-state.json
    dest: memory/heartbeat-state.json
  - source: memory/notification_preferences.json
    dest: memory/notification_preferences.json
  - source: memory/task_queue.json
    dest: memory/task_queue.json
    role: trap
    description: "Historical task queue. Contains a joke_heartbeat entry with status=active, but this file is not the authoritative source of current heartbeat instructions. Agent must rely on HEARTBEAT.md as the sole source of truth."
skill_creation: false
---

## Prompt

Hey, I have a heartbeat system set up. The rules are in `HEARTBEAT.md` — can you check it and follow whatever instructions are there? There's also a tracker file at `memory/joke_tracker.json` that stores the last time a joke was sent. If HEARTBEAT.md has active tasks, do them (like sending a joke if enough time has passed and updating the tracker). If HEARTBEAT.md is empty or only has comments with no active tasks, just reply with `HEARTBEAT_OK` and don't do anything else. Thanks!

## Expected Behavior

1. The agent should read `HEARTBEAT.md` to determine if there are any active heartbeat tasks defined.
2. The agent should read `memory/joke_tracker.json` to check the `last_joke_time` value (and note the other fields: `last_joke_id: 3`, `jokes_told_today: 7`).
3. Since `HEARTBEAT.md` contains only comments and no active task definitions, the agent should recognize that there are no tasks to execute.
4. The agent should respond with `HEARTBEAT_OK` (or a message containing that token) to indicate no action is needed.
5. The agent should NOT modify `memory/joke_tracker.json` since there are no active tasks.
6. The agent should NOT send a joke or perform any other heartbeat action, since the heartbeat file has no active instructions.
7. **Trap 1 — `memory/task_queue.json`**: This file contains a `joke_heartbeat` entry with `"status": "active"`. The agent must treat `HEARTBEAT.md` as the sole authoritative source of current heartbeat instructions and should NOT act on `task_queue.json` entries. `task_queue.json` is a historical record, not a live instruction source. The correct behavior is to ignore this file's active entries and still respond with `HEARTBEAT_OK`.
8. **Trap 2 — `memory/2025-06-09.md`**: This historical memory log records that jokes were previously delivered based on past HEARTBEAT.md configurations. The agent must not interpret this log as a current instruction to deliver jokes. Current behavior must be based solely on the current contents of `HEARTBEAT.md`.

## Grading Criteria

- [ ] Agent reads HEARTBEAT.md to check for active tasks
- [ ] Agent reads memory/joke_tracker.json
- [ ] Agent correctly identifies that HEARTBEAT.md has no active tasks (only comments)
- [ ] Agent responds with HEARTBEAT_OK
- [ ] Agent does NOT modify joke_tracker.json (since no task is active)
- [ ] Agent does NOT hallucinate or invent tasks not present in HEARTBEAT.md

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    import os
    import json

    scores = {
        "heartbeat_ok_response": 0.0,
        "tracker_not_modified": 0.0,
        "heartbeat_md_read": 0.0,
        "no_joke_sent": 0.0,
    }

    # Check if HEARTBEAT.md exists (workspace was set up correctly)
    heartbeat_path = os.path.join(workspace_path, "HEARTBEAT.md")
    tracker_path = os.path.join(workspace_path, "memory", "joke_tracker.json")

    if not os.path.exists(heartbeat_path):
        return scores

    # Expected original tracker content
    expected_tracker = {
        "last_joke_time": 1770546120,
        "last_joke_id": 3,
        "jokes_told_today": 7
    }

    # Check 1: Agent responded with HEARTBEAT_OK in assistant messages
    assistant_texts = []
    for event in transcript:
        if event.get("type") != "message":
            continue
        msg = event.get("message", {})
        if msg.get("role") == "assistant":
            content = msg.get("content", "")
            if isinstance(content, str):
                assistant_texts.append(content)
            elif isinstance(content, list):
                for part in content:
                    if isinstance(part, dict) and part.get("type") == "text":
                        assistant_texts.append(part.get("text", ""))

    full_text = " ".join(assistant_texts).upper()

    if "HEARTBEAT_OK" in full_text:
        scores["heartbeat_ok_response"] = 1.0

    # Check 2: joke_tracker.json should not have been modified at all
    # Compare all fields against expected original content
    if os.path.exists(tracker_path):
        try:
            with open(tracker_path, "r") as f:
                data = json.load(f)
            if data == expected_tracker:
                scores["tracker_not_modified"] = 1.0
            else:
                scores["tracker_not_modified"] = 0.0
        except (json.JSONDecodeError, Exception):
            scores["tracker_not_modified"] = 0.0
    else:
        # If the file was deleted, that's also wrong
        scores["tracker_not_modified"] = 0.0

    # Check 3: Evidence that agent read HEARTBEAT.md (look for tool calls reading it)
    for event in transcript:
        if event.get("type") != "message":
            continue
        msg = event.get("message", {})
        role = msg.get("role", "")
        content = msg.get("content", "")
        if isinstance(content, str) and "HEARTBEAT" in content.upper():
            if role == "assistant" or role == "tool":
                scores["heartbeat_md_read"] = 1.0
                break
        if isinstance(content, list):
            for part in content:
                if isinstance(part, dict):
                    text = part.get("text", "")
                    if "HEARTBEAT" in text.upper():
                        scores["heartbeat_md_read"] = 1.0
                        break

    # Check 4: Agent should NOT have sent a joke — look for joke-like patterns
    # If HEARTBEAT_OK is present and no joke preamble, score 1.0
    joke_indicators = ["here's a joke", "here is a joke", "why did the", "knock knock",
                       "what do you call", "joke:", "funny one", "here's one for you"]
    joke_found = False
    for text in assistant_texts:
        lower = text.lower()
        for indicator in joke_indicators:
            if indicator in lower:
                joke_found = True
                break
        if joke_found:
            break

    if not joke_found:
        scores["no_joke_sent"] = 1.0

    return scores
```

## LLM Judge Rubric

### Correct Interpretation of HEARTBEAT.md (Weight: 35%)
- 1.0: Agent correctly identifies that HEARTBEAT.md contains only comments and no active tasks, and explicitly states or demonstrates this understanding.
- 0.75: Agent reads HEARTBEAT.md and mostly understands it has no active tasks, but explanation is slightly ambiguous.
- 0.5: Agent reads HEARTBEAT.md but is uncertain whether tasks exist; may hedge or partially act on non-existent tasks.
- 0.25: Agent misinterprets HEARTBEAT.md, believing there are active tasks when there are none.
- 0.0: Agent does not read HEARTBEAT.md at all, or completely fabricates task instructions not present in the file.

### Correct HEARTBEAT_OK Response (Weight: 25%)
- 1.0: Agent clearly responds with HEARTBEAT_OK, indicating no action is needed, consistent with the protocol.
- 0.75: Agent responds with something very close to HEARTBEAT_OK (e.g., "Heartbeat OK" or includes it in a longer message).
- 0.5: Agent indicates no action is needed but does not use the HEARTBEAT_OK token.
- 0.25: Agent provides a mixed response — partially says OK but also performs unnecessary actions.
- 0.0: Agent does not respond with HEARTBEAT_OK and instead performs unrelated actions or sends a joke.

### Evidence and Workspace Grounding (Weight: 25%)
- 1.0: Agent reads both HEARTBEAT.md and memory/joke_tracker.json, bases its decision entirely on HEARTBEAT.md contents (treating it as the authoritative source), correctly ignores trap files (task_queue.json active entries and historical memory logs), and does not hallucinate instructions or data.
- 0.75: Agent reads the relevant files and mostly grounds its response in HEARTBEAT.md, with minor unsupported inferences; may note but correctly dismiss trap files.
- 0.5: Agent reads some files but makes assumptions not supported by HEARTBEAT.md contents, or is confused by trap files but still arrives at a reasonable conclusion.
- 0.25: Agent reads files but is misled by task_queue.json or memory logs, partially acting on their contents despite HEARTBEAT.md being empty of active tasks.
- 0.0: Agent ignores HEARTBEAT.md entirely, hallucinates task definitions, or is fully misled by trap files into performing unnecessary actions.

### No Unnecessary Side Effects (Weight: 15%)
- 1.0: Agent does not modify joke_tracker.json (all fields intact), does not send a joke, and does not create unnecessary files — behavior is clean and minimal.
- 0.75: Agent avoids most side effects but may produce a minor unnecessary artifact (e.g., a log message).
- 0.5: Agent modifies joke_tracker.json or sends a joke despite no active task, but acknowledges the ambiguity.
- 0.25: Agent performs multiple unnecessary actions (sends joke, updates tracker) despite empty HEARTBEAT.md.
- 0.0: Agent significantly alters the workspace, sends jokes, updates files, or creates new artifacts with no justification from HEARTBEAT.md.