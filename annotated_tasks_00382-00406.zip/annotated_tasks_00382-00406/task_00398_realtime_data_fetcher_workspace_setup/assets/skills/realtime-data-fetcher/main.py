#!/usr/bin/env python3
"""Real-time Data Fetcher - CLI entry point for financial data retrieval."""

import argparse
import json
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from src.data_fetcher import DataFetcher
from src.financial_data import GoldFetcher, SilverFetcher, CryptoFetcher
from src.cache import DataCache


def load_config():
    config_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "config.json")
    with open(config_path, "r") as f:
        return json.load(f)


def cmd_gold(args, config):
    """Fetch current gold price."""
    fetcher = GoldFetcher(config)
    cache = DataCache(config.get("cache_ttl_seconds", 300))

    cache_key = f"gold_{args.currency}"
    cached = cache.get(cache_key)
    if cached and not args.no_cache:
        print(f"[cached] Gold price: {cached['price']} {cached['currency']}")
        return

    result = fetcher.fetch(currency=args.currency)
    if result:
        cache.set(cache_key, result)
        print(f"Gold (XAU): {result['price']} {result['currency']}")
        print(f"Source: {result['source']}")
        print(f"Timestamp: {result['timestamp']}")
    else:
        print("Error: Failed to fetch gold price from all sources", file=sys.stderr)
        sys.exit(1)


def cmd_metal(args, config):
    """Fetch current metal price."""
    symbol_map = {"silver": SilverFetcher, "gold": GoldFetcher}
    fetcher_cls = symbol_map.get(args.symbol.lower())
    if not fetcher_cls:
        print(f"Error: Unsupported metal '{args.symbol}'. Supported: {list(symbol_map.keys())}", file=sys.stderr)
        sys.exit(1)

    fetcher = fetcher_cls(config)
    result = fetcher.fetch(currency=args.currency)
    if result:
        print(f"{args.symbol.title()}: {result['price']} {result['currency']}")
        print(f"Source: {result['source']}")
        print(f"Timestamp: {result['timestamp']}")
    else:
        print(f"Error: Failed to fetch {args.symbol} price", file=sys.stderr)
        sys.exit(1)


def cmd_crypto(args, config):
    """Fetch cryptocurrency price."""
    fetcher = CryptoFetcher(config)
    result = fetcher.fetch(symbol=args.symbol, currency=args.currency)
    if result:
        print(f"{args.symbol.upper()}: {result['price']} {result['currency']}")
        print(f"24h Change: {result.get('change_24h', 'N/A')}%")
        print(f"Source: {result['source']}")
        print(f"Timestamp: {result['timestamp']}")
    else:
        print(f"Error: Failed to fetch {args.symbol} price", file=sys.stderr)
        sys.exit(1)


def main():
    parser = argparse.ArgumentParser(description="Real-time Data Fetcher")
    parser.add_argument("--no-cache", action="store_true", help="Bypass cache")
    subparsers = parser.add_subparsers(dest="command", help="Data type to fetch")

    gold_parser = subparsers.add_parser("gold", help="Fetch gold price")
    gold_parser.add_argument("--currency", default="USD", help="Currency (default: USD)")

    metal_parser = subparsers.add_parser("metal", help="Fetch metal price")
    metal_parser.add_argument("--symbol", required=True, help="Metal symbol (gold, silver)")
    metal_parser.add_argument("--currency", default="USD", help="Currency (default: USD)")

    crypto_parser = subparsers.add_parser("crypto", help="Fetch cryptocurrency price")
    crypto_parser.add_argument("--symbol", default="BTC", help="Crypto symbol (default: BTC)")
    crypto_parser.add_argument("--currency", default="USD", help="Currency (default: USD)")

    args = parser.parse_args()
    if not args.command:
        parser.print_help()
        sys.exit(1)

    config = load_config()

    commands = {"gold": cmd_gold, "metal": cmd_metal, "crypto": cmd_crypto}
    commands[args.command](args, config)


if __name__ == "__main__":
    main()
