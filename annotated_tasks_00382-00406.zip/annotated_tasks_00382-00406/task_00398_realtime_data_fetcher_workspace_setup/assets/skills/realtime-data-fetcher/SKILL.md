# Real-time Data Fetcher

A skill for retrieving live external data from financial markets, commodity prices, cryptocurrency exchanges, and other real-time data sources.

## Features

- **Multi-source fallback**: Configurable primary and fallback data sources
- **Financial data**: Gold, silver, platinum, cryptocurrency prices
- **Caching**: Optional local cache with configurable TTL
- **Rate limiting**: Respects API rate limits with automatic backoff

## Usage

```bash
# Fetch gold price in USD
python3 main.py gold --currency USD

# Fetch Bitcoin price
python3 main.py crypto --symbol BTC --currency USD

# Fetch silver price
python3 main.py metal --symbol silver
```

## Configuration

Edit `config.json` to set API keys and data source preferences:

```json
{
  "alpha_vantage_api_key": "YOUR_KEY_HERE",
  "default_currency": "USD",
  "cache_ttl_seconds": 300,
  "sources": { ... }
}
```

## API Keys

- **Alpha Vantage** (recommended): Free tier at https://alphavantage.co — 25 requests/day
- **metals.live**: No key required, but rate-limited and occasionally times out
- **CoinGecko**: Free tier available, 10-30 calls/min

## Dependencies

```bash
pip install -r requirements.txt
```

## Architecture

```
realtime-data-fetcher/
├── SKILL.md
├── config.json          # API keys and source configuration
├── main.py              # CLI entry point
├── requirements.txt     # Python dependencies
└── src/
    ├── cache.py         # Local caching layer
    ├── data_fetcher.py  # Base fetcher with retry/fallback
    └── financial_data.py # Financial market data modules
```
