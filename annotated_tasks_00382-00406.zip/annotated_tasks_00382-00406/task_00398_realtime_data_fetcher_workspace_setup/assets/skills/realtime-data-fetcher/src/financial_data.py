"""Financial data fetchers for metals and cryptocurrencies."""

import datetime
from typing import Optional, Dict, Any

from .data_fetcher import DataFetcher


class GoldFetcher(DataFetcher):
    """Fetch gold (XAU) prices from multiple sources."""

    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.sources = config.get("sources", {}).get("gold", {})
        self.api_key = config.get("alpha_vantage_api_key", "")

    def fetch(self, currency: str = "USD") -> Optional[Dict]:
        """Fetch gold price with multi-source fallback."""
        fetchers = []

        primary = self.sources.get("primary", "alpha_vantage")
        fallbacks = self.sources.get("fallback", [])
        order = [primary] + [f for f in fallbacks if f != primary]

        for source in order:
            if source == "alpha_vantage" and self.api_key:
                fetchers.append(lambda c=currency: self._fetch_alpha_vantage(c))
            elif source == "metals_live":
                fetchers.append(lambda c=currency: self._fetch_metals_live(c))
            elif source == "coingecko":
                fetchers.append(lambda c=currency: self._fetch_coingecko_gold(c))

        return self.fetch_with_fallback(fetchers)

    def _fetch_alpha_vantage(self, currency: str) -> Optional[Dict]:
        """Fetch gold price from Alpha Vantage CURRENCY_EXCHANGE_RATE."""
        url = self.endpoints.get("alpha_vantage", "https://www.alphavantage.co/query")
        params = {
            "function": "CURRENCY_EXCHANGE_RATE",
            "from_currency": "XAU",
            "to_currency": currency,
            "apikey": self.api_key
        }
        data = self._request(url, params=params)
        if data and "Realtime Currency Exchange Rate" in data:
            rate_data = data["Realtime Currency Exchange Rate"]
            return {
                "price": float(rate_data.get("5. Exchange Rate", 0)),
                "currency": currency,
                "source": "alpha_vantage",
                "timestamp": rate_data.get("6. Last Refreshed",
                                           datetime.datetime.utcnow().isoformat()),
                "bid": float(rate_data.get("8. Bid Price", 0)),
                "ask": float(rate_data.get("9. Ask Price", 0))
            }
        if data and "Note" in data:
            print(f"  Alpha Vantage rate limit: {data['Note']}")
        return None

    def _fetch_metals_live(self, currency: str) -> Optional[Dict]:
        """Fetch gold price from metals.live API."""
        url = f"{self.endpoints.get('metals_live', 'https://api.metals.live/v1')}/spot/gold"
        data = self._request(url)
        if data and isinstance(data, list) and len(data) > 0:
            latest = data[-1] if isinstance(data, list) else data
            return {
                "price": float(latest.get("price", 0)),
                "currency": "USD",
                "source": "metals_live",
                "timestamp": datetime.datetime.utcnow().isoformat()
            }
        return None

    def _fetch_coingecko_gold(self, currency: str) -> Optional[Dict]:
        """Fetch gold price via CoinGecko's commodity endpoint."""
        url = f"{self.endpoints.get('coingecko', 'https://api.coingecko.com/api/v3')}/simple/price"
        params = {
            "ids": "tether-gold",
            "vs_currencies": currency.lower()
        }
        data = self._request(url, params=params)
        if data and "tether-gold" in data:
            price = data["tether-gold"].get(currency.lower(), 0)
            return {
                "price": float(price),
                "currency": currency,
                "source": "coingecko",
                "timestamp": datetime.datetime.utcnow().isoformat()
            }
        return None


class SilverFetcher(DataFetcher):
    """Fetch silver (XAG) prices."""

    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.sources = config.get("sources", {}).get("silver", {})
        self.api_key = config.get("alpha_vantage_api_key", "")

    def fetch(self, currency: str = "USD") -> Optional[Dict]:
        fetchers = []
        primary = self.sources.get("primary", "alpha_vantage")
        fallbacks = self.sources.get("fallback", [])
        order = [primary] + [f for f in fallbacks if f != primary]

        for source in order:
            if source == "alpha_vantage" and self.api_key:
                fetchers.append(lambda c=currency: self._fetch_alpha_vantage(c))
            elif source == "metals_live":
                fetchers.append(lambda c=currency: self._fetch_metals_live(c))

        return self.fetch_with_fallback(fetchers)

    def _fetch_alpha_vantage(self, currency: str) -> Optional[Dict]:
        url = self.endpoints.get("alpha_vantage", "https://www.alphavantage.co/query")
        params = {
            "function": "CURRENCY_EXCHANGE_RATE",
            "from_currency": "XAG",
            "to_currency": currency,
            "apikey": self.api_key
        }
        data = self._request(url, params=params)
        if data and "Realtime Currency Exchange Rate" in data:
            rate_data = data["Realtime Currency Exchange Rate"]
            return {
                "price": float(rate_data.get("5. Exchange Rate", 0)),
                "currency": currency,
                "source": "alpha_vantage",
                "timestamp": rate_data.get("6. Last Refreshed",
                                           datetime.datetime.utcnow().isoformat())
            }
        return None

    def _fetch_metals_live(self, currency: str) -> Optional[Dict]:
        url = f"{self.endpoints.get('metals_live', 'https://api.metals.live/v1')}/spot/silver"
        data = self._request(url)
        if data and isinstance(data, list) and len(data) > 0:
            latest = data[-1]
            return {
                "price": float(latest.get("price", 0)),
                "currency": "USD",
                "source": "metals_live",
                "timestamp": datetime.datetime.utcnow().isoformat()
            }
        return None


class CryptoFetcher(DataFetcher):
    """Fetch cryptocurrency prices from CoinGecko and Alpha Vantage."""

    COINGECKO_IDS = {
        "BTC": "bitcoin", "ETH": "ethereum", "SOL": "solana",
        "DOGE": "dogecoin", "ADA": "cardano", "XRP": "ripple",
        "DOT": "polkadot", "AVAX": "avalanche-2", "MATIC": "matic-network"
    }

    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.sources = config.get("sources", {}).get("crypto", {})
        self.api_key = config.get("alpha_vantage_api_key", "")

    def fetch(self, symbol: str = "BTC", currency: str = "USD") -> Optional[Dict]:
        fetchers = []
        primary = self.sources.get("primary", "coingecko")
        fallbacks = self.sources.get("fallback", [])
        order = [primary] + [f for f in fallbacks if f != primary]

        for source in order:
            if source == "coingecko":
                fetchers.append(lambda s=symbol, c=currency: self._fetch_coingecko(s, c))
            elif source == "alpha_vantage" and self.api_key:
                fetchers.append(lambda s=symbol, c=currency: self._fetch_alpha_vantage(s, c))

        return self.fetch_with_fallback(fetchers)

    def _fetch_coingecko(self, symbol: str, currency: str) -> Optional[Dict]:
        coin_id = self.COINGECKO_IDS.get(symbol.upper())
        if not coin_id:
            print(f"  Unknown symbol: {symbol}")
            return None

        url = f"{self.endpoints.get('coingecko', 'https://api.coingecko.com/api/v3')}/simple/price"
        params = {
            "ids": coin_id,
            "vs_currencies": currency.lower(),
            "include_24hr_change": "true"
        }
        data = self._request(url, params=params)
        if data and coin_id in data:
            coin_data = data[coin_id]
            return {
                "price": float(coin_data.get(currency.lower(), 0)),
                "currency": currency,
                "change_24h": coin_data.get(f"{currency.lower()}_24h_change"),
                "source": "coingecko",
                "timestamp": datetime.datetime.utcnow().isoformat()
            }
        return None

    def _fetch_alpha_vantage(self, symbol: str, currency: str) -> Optional[Dict]:
        url = self.endpoints.get("alpha_vantage", "https://www.alphavantage.co/query")
        params = {
            "function": "CURRENCY_EXCHANGE_RATE",
            "from_currency": symbol.upper(),
            "to_currency": currency,
            "apikey": self.api_key
        }
        data = self._request(url, params=params)
        if data and "Realtime Currency Exchange Rate" in data:
            rate_data = data["Realtime Currency Exchange Rate"]
            return {
                "price": float(rate_data.get("5. Exchange Rate", 0)),
                "currency": currency,
                "source": "alpha_vantage",
                "timestamp": rate_data.get("6. Last Refreshed",
                                           datetime.datetime.utcnow().isoformat())
            }
        return None
