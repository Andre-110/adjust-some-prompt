"""Base data fetcher with retry and multi-source fallback logic."""

import time
import requests
from typing import Optional, Dict, Any, List


class FetchError(Exception):
    """Raised when all data sources fail."""
    pass


class DataFetcher:
    """Base class for data fetchers with retry and fallback support."""

    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.timeout = config.get("request_timeout_seconds", 15)
        self.max_retries = config.get("max_retries", 3)
        self.endpoints = config.get("api_endpoints", {})

    def _request(self, url: str, params: Optional[Dict] = None,
                 headers: Optional[Dict] = None) -> Optional[Dict]:
        """Make an HTTP GET request with retry logic."""
        for attempt in range(self.max_retries):
            try:
                resp = requests.get(
                    url,
                    params=params,
                    headers=headers or {},
                    timeout=self.timeout
                )
                resp.raise_for_status()
                return resp.json()
            except requests.exceptions.Timeout:
                print(f"  Timeout on attempt {attempt + 1}/{self.max_retries}: {url}")
                if attempt < self.max_retries - 1:
                    time.sleep(2 ** attempt)
            except requests.exceptions.ConnectionError as e:
                print(f"  Connection error on attempt {attempt + 1}: {e}")
                if attempt < self.max_retries - 1:
                    time.sleep(2 ** attempt)
            except requests.exceptions.HTTPError as e:
                if e.response.status_code == 429:
                    retry_after = int(e.response.headers.get("Retry-After", 60))
                    print(f"  Rate limited. Waiting {retry_after}s...")
                    time.sleep(retry_after)
                else:
                    print(f"  HTTP error: {e}")
                    return None
        return None

    def fetch_with_fallback(self, fetchers: List[callable]) -> Optional[Dict]:
        """Try multiple fetch strategies in order, return first success."""
        for fetcher in fetchers:
            try:
                result = fetcher()
                if result:
                    return result
            except Exception as e:
                print(f"  Source failed: {e}")
                continue
        return None
