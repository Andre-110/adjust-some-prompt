"""Simple in-memory cache with TTL support for data fetcher results."""

import time
from typing import Optional, Dict, Any


class DataCache:
    """In-memory cache with per-key TTL."""

    def __init__(self, default_ttl: int = 300):
        self._store: Dict[str, Dict[str, Any]] = {}
        self.default_ttl = default_ttl

    def get(self, key: str) -> Optional[Dict]:
        """Retrieve cached value if not expired."""
        if key in self._store:
            entry = self._store[key]
            if time.time() - entry["cached_at"] < entry["ttl"]:
                return entry["data"]
            else:
                del self._store[key]
        return None

    def set(self, key: str, data: Dict, ttl: Optional[int] = None):
        """Store value in cache with TTL."""
        self._store[key] = {
            "data": data,
            "cached_at": time.time(),
            "ttl": ttl or self.default_ttl
        }

    def invalidate(self, key: str):
        """Remove a specific key from cache."""
        self._store.pop(key, None)

    def clear(self):
        """Clear all cached entries."""
        self._store.clear()

    def stats(self) -> Dict[str, int]:
        """Return cache statistics."""
        now = time.time()
        valid = sum(1 for e in self._store.values() if now - e["cached_at"] < e["ttl"])
        return {"total": len(self._store), "valid": valid, "expired": len(self._store) - valid}
