---
id: task_00398_realtime_data_fetcher_workspace_setup
name: Real-time Data Fetcher Skill Configuration and Workspace Bootstrap
category: Workflow and Agent Orchestration
subcategory: Integration and Data Flow
difficulty: hard
grading_type: hybrid
grading_weights: {automated: 0.4, llm_judge: 0.6}
timeout_seconds: 600
input_modality: text-only
external_dependency: none
workspace_files:
  - source: skills/realtime-data-fetcher/config.json
    dest: skills/realtime-data-fetcher/config.json
  - source: skills/realtime-data-fetcher/main.py
    dest: skills/realtime-data-fetcher/main.py
  - source: skills/realtime-data-fetcher/SKILL.md
    dest: skills/realtime-data-fetcher/SKILL.md
  - source: skills/realtime-data-fetcher/requirements.txt
    dest: skills/realtime-data-fetcher/requirements.txt
  - source: skills/realtime-data-fetcher/src/__init__.py
    dest: skills/realtime-data-fetcher/src/__init__.py
  - source: skills/realtime-data-fetcher/src/cache.py
    dest: skills/realtime-data-fetcher/src/cache.py
  - source: skills/realtime-data-fetcher/src/data_fetcher.py
    dest: skills/realtime-data-fetcher/src/data_fetcher.py
  - source: skills/realtime-data-fetcher/src/financial_data.py
    dest: skills/realtime-data-fetcher/src/financial_data.py
skill_creation: false
---

## Prompt

I just got my Alpha Vantage API key: `DEMO_AV_KEY_X9K2M7P4Q1`. Can you plug that into the Real-time Data Fetcher skill config and set it up properly? The config is at `skills/realtime-data-fetcher/config.json` — update the `alpha_vantage_api_key` field with this key.

Also, this is a fresh workspace — I need you to bootstrap it. Create the core workspace files: `SOUL.md` (with a brief identity/purpose statement), `TOOLS.md` (listing available tools and skills), `HEARTBEAT.md` (with monitoring status set to paused), and `IDENTITY.md` (with a short self-description). Initialize a git repo too so we can track changes.

After updating the config, run `python3 skills/realtime-data-fetcher/main.py gold` to verify the skill can start up and load the config correctly.

## Expected Behavior

The agent should:

1. **Update the Data Fetcher config**: Read `skills/realtime-data-fetcher/config.json`, update the `alpha_vantage_api_key` field from its current placeholder value to `DEMO_AV_KEY_X9K2M7P4Q1`, and write the updated config back while preserving the rest of the JSON structure (sources, endpoints, cache settings, etc.).

2. **Bootstrap workspace files**: Create the following core files in the workspace root:
   - `SOUL.md` — containing purpose/identity content for the agent
   - `TOOLS.md` — listing available tools and installed skills (should mention the realtime-data-fetcher skill and any others found)
   - `HEARTBEAT.md` — with monitoring status indicated as paused
   - `IDENTITY.md` — with a self-description

3. **Initialize a git repository**: Run `git init` in the workspace root, resulting in a `.git/` directory with standard git structure (HEAD, config, etc.).

4. **Test the data fetcher**: Execute `python3 skills/realtime-data-fetcher/main.py gold` and observe the output. Note: this command will attempt to fetch live gold prices from Alpha Vantage using the configured key. The agent should report whatever output or error occurs (the test may fail due to network restrictions in the sandbox, but the important thing is that the config loads and the script starts without import errors).

5. **Communicate results**: Inform the user that the API key has been configured, workspace has been bootstrapped, and share the test result.

**Potential traps / considerations:**
- The config.json uses a flat key `alpha_vantage_api_key` at the top level, not a nested `api_keys.alpha_vantage` structure. The agent must read the actual file to discover this.
- The `main.py` in Assets imports from `src/` subpackage (`src.data_fetcher`, `src.financial_data`, `src.cache`). All these files must be present in the workspace for the test to run without import errors.
- The test command `python3 skills/realtime-data-fetcher/main.py gold` uses the `gold` subcommand (argparse), which will attempt a real API call. In a sandboxed environment without network access, this will fail at the HTTP request stage — that is expected and acceptable.

## Grading Criteria

- [ ] Alpha Vantage API key correctly written to config.json (`alpha_vantage_api_key` field set to `DEMO_AV_KEY_X9K2M7P4Q1`)
- [ ] SOUL.md created with meaningful content
- [ ] TOOLS.md created with meaningful content
- [ ] HEARTBEAT.md created with paused status indication
- [ ] IDENTITY.md created with self-description
- [ ] Git repository initialized (.git/HEAD exists)
- [ ] Data fetcher test executed or attempted

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    import os
    import json
    from pathlib import Path

    ws = Path(workspace_path)
    scores = {
        "config_api_key": 0.0,
        "soul_md_created": 0.0,
        "tools_md_created": 0.0,
        "heartbeat_md_created": 0.0,
        "identity_md_created": 0.0,
        "git_initialized": 0.0,
        "data_fetcher_test": 0.0,
    }

    # 1. Check config.json has the API key
    config_path = ws / "skills" / "realtime-data-fetcher" / "config.json"
    if config_path.exists():
        try:
            with open(config_path) as f:
                config = json.load(f)
            api_key = config.get("alpha_vantage_api_key", "")
            if api_key == "DEMO_AV_KEY_X9K2M7P4Q1":
                scores["config_api_key"] = 1.0
            elif api_key and len(api_key) > 5 and api_key != "YOUR_KEY_HERE":
                # Some key was set, partial credit
                scores["config_api_key"] = 0.5
        except (json.JSONDecodeError, Exception):
            scores["config_api_key"] = 0.0

    # 2. Check SOUL.md
    soul_path = ws / "SOUL.md"
    if soul_path.exists():
        content = soul_path.read_text().strip()
        if len(content) > 20:
            scores["soul_md_created"] = 1.0
        elif len(content) > 0:
            scores["soul_md_created"] = 0.5

    # 3. Check TOOLS.md
    tools_path = ws / "TOOLS.md"
    if tools_path.exists():
        content = tools_path.read_text().strip()
        if len(content) > 20:
            scores["tools_md_created"] = 1.0
        elif len(content) > 0:
            scores["tools_md_created"] = 0.5

    # 4. Check HEARTBEAT.md with paused indication
    hb_path = ws / "HEARTBEAT.md"
    if hb_path.exists():
        content = hb_path.read_text().strip().lower()
        if len(content) > 5:
            if "pause" in content or "stopped" in content or "inactive" in content or "disabled" in content:
                scores["heartbeat_md_created"] = 1.0
            else:
                # File exists but no paused indication
                scores["heartbeat_md_created"] = 0.5

    # 5. Check IDENTITY.md
    id_path = ws / "IDENTITY.md"
    if id_path.exists():
        content = id_path.read_text().strip()
        if len(content) > 20:
            scores["identity_md_created"] = 1.0
        elif len(content) > 0:
            scores["identity_md_created"] = 0.5

    # 6. Check git initialized
    git_head = ws / ".git" / "HEAD"
    if git_head.exists():
        content = git_head.read_text().strip()
        if "ref:" in content or len(content) > 5:
            scores["git_initialized"] = 1.0

    # 7. Check if data fetcher test was attempted (search transcript for evidence)
    if transcript:
        transcript_text = str(transcript).lower()
        if "main.py" in transcript_text and "gold" in transcript_text:
            scores["data_fetcher_test"] = 1.0
        elif "main.py" in transcript_text or "data fetcher" in transcript_text:
            scores["data_fetcher_test"] = 0.5

    return scores
```

## LLM Judge Rubric

### API Key Configuration (Weight: 25%)
- 1.0: The Alpha Vantage API key `DEMO_AV_KEY_X9K2M7P4Q1` is correctly inserted into `skills/realtime-data-fetcher/config.json` in the `alpha_vantage_api_key` field, and the rest of the config structure (sources, endpoints, cache settings) is preserved intact.
- 0.75: The API key is written to the config file but some other config fields are altered or missing.
- 0.5: The agent attempts to update the config but makes errors (wrong field name, malformed JSON, writes to wrong path, etc.).
- 0.25: The agent acknowledges the API key but does not successfully write it to the config file.
- 0.0: No attempt to configure the API key, or the config file is missing/empty.

### Workspace Bootstrap Completeness (Weight: 30%)
- 1.0: All four core files (SOUL.md, TOOLS.md, HEARTBEAT.md, IDENTITY.md) are created with meaningful, relevant content. HEARTBEAT.md specifically indicates paused status.
- 0.75: Three of four files created with good content, or all four created but one has minimal content.
- 0.5: Two of four files created with reasonable content.
- 0.25: Only one file created, or files created with trivially short/placeholder content.
- 0.0: No workspace bootstrap files created, or deliverables are entirely missing.

### Git Repository Initialization (Weight: 20%)
- 1.0: Git repository is properly initialized with `.git/HEAD` pointing to a valid ref, and standard git structure is present.
- 0.75: Git repo initialized but with minor issues (e.g., unusual config).
- 0.5: Agent attempts git init but it is incomplete or errors occur.
- 0.25: Agent mentions git initialization but does not execute it.
- 0.0: No git initialization attempted or evidence of `.git/` directory.

### Evidence and Workspace Grounding (Weight: 25%)
- 1.0: All actions are grounded in actual file reads/writes in the workspace. The agent reads the existing config.json to discover its structure, modifies the correct field (`alpha_vantage_api_key`), creates files at the correct paths, and references actual workspace structure including the `src/` subpackage.
- 0.75: Most actions are grounded but one or two steps rely on assumptions rather than reading actual workspace state.
- 0.5: Some actions are grounded but the agent makes unsupported assumptions about workspace contents (e.g., assumes a different config structure without reading) or skips verification steps.
- 0.25: Agent provides mostly generic responses without engaging with the actual workspace files or paths.
- 0.0: Agent ignores the required workspace files, hallucinates file contents, or produces output disconnected from the stated task and file paths.