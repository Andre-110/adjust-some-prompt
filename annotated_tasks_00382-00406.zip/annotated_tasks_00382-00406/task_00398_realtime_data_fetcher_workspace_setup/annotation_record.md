| 序号 | 修改项 | 修改原因 |
|------|--------|----------|
| 1 | 将 Prompt 中的真实 API Key `VF8DPF9CNNDN2NYA` 替换为虚构 Key `DEMO_AV_KEY_X9K2M7P4Q1` | 维度A/F：Prompt 中包含看似真实的 Alpha Vantage API Key，属于敏感信息泄露风险。已在 Prompt、Expected Behavior、grade()、LLM Judge Rubric 中同步替换 |
| 2 | 修正 `workspace_files` 字段格式：将 `path:` 改为 `dest:`，删除 `content:` 内联内容（改为引用 Assets 目录中的实际文件） | 按数据规范，禁止使用旧字段 `path:`，应使用 `dest:` 格式。同时 content 内联与 Assets 目录存在冲突 |
| 3 | 修正 YAML frontmatter 中 `workspace_files` 的 `config.json` 内联内容与 Assets 目录中实际 `config.json` 结构不一致的问题 | 维度F/B：YAML 内联的 config.json 使用 `api_keys.alpha_vantage` 字段结构，而 Assets 实际文件使用 `alpha_vantage_api_key` 顶层字段。二者不一致会导致 grade() 和 Agent 行为混乱。统一为 Assets 版本的结构 |
| 4 | 修正 `main.py` 内联内容与 Assets 目录中实际 `main.py` 完全不同的问题 | 维度F：YAML 内联的 main.py 是简单脚本（直接 `sys.argv` 解析），而 Assets 中是完整的 argparse + 子命令结构并导入 `src/` 子包。统一使用 Assets 版本 |
| 5 | 修正 Prompt 中的测试命令 `python3 skills/realtime-data-fetcher/main.py gold` | 维度A/F：Assets 中实际的 main.py 使用 argparse 子命令模式，裸 `gold` 参数是子命令而非位置参数，命令本身可用，但输出不会包含 `api_key_set` 字段（那是内联版 main.py 才有的输出）。修正 Prompt 和 Expected Behavior 中对测试输出的期望 |
| 6 | 修正 `grade()` 函数中 API Key 检查路径，从 `api_keys.alpha_vantage` 改为 `alpha_vantage_api_key`（与 Assets config.json 结构对齐） | 维度D/F：grade() 原来按内联 config 的嵌套结构检查，与 Assets 实际文件结构不匹配 |
| 7 | 在 `grade()` 中增加 `data_fetcher_test` score key，与 Grading Criteria 第7条对齐 | 维度D：原 grade() 缺少对「Data fetcher test executed or attempted」的检查，score key 与 Grading Criteria 不对齐 |
| 8 | 补充 `workspace_files` 中 Assets 目录里存在但未列出的文件（`src/__init__.py`, `src/cache.py`, `src/data_fetcher.py`, `src/financial_data.py`） | 维度F：Assets 目录中包含 `src/` 子包的 4 个文件，但 workspace_files 未列出，Agent 运行 main.py 时会因缺少这些模块而报错 |
| 9 | 删除 YAML 中对 `skills/daily-evolution/SKILL.md` 和 `skills/ssh-manager/SKILL.md` 的内联引用（Assets 目录中不存在这些文件） | 维度F：workspace_files 列出了这两个 skill 文件但 Assets 目录中没有对应文件，不完整。由于它们是装饰性文件且不影响核心题目逻辑，选择从 workspace_files 中移除，避免文件缺失错误。若需要可作为补充 Assets 添加回来 |
| 10 | 删除 YAML 中 `BOOTSTRAP.md` 的内联引用（Assets 目录中不存在） | 维度F：同上，Assets 目录中无此文件。BOOTSTRAP.md 只是提示性文件，不影响核心评分 |