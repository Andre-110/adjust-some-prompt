| 序号 | 修改项 | 修改原因 |
|------|--------|----------|
| 1 | 将 `workspace_files` 中所有 `path:` 字段改为 `dest:` 字段 | 任务规范明确禁止使用旧字段 `path:`，应统一使用 `dest:` 格式 |
| 2 | 统一 `workspace_files` 中内联 `config.json` 的内容与 Assets 目录中实际的 `config.json` 保持一致 | 内联 `content` 中的 config.json 为简化版（version: 2, 无 plugins 节点, memory.provider="none"），而 Assets 目录中为完整真实版（version: "1.8.2", 有 plugins 节点, 无顶层 memory 节点）。两者结构严重矛盾，会导致 Agent 读到的配置与评分标准不一致。统一采用 Assets 目录版本为准，删除内联 content |
| 3 | 统一 `workspace_files` 中内联 `memory/notes.md` 与 Assets 目录的记忆文件保持一致 | 内联版本只有3行简单笔记，Assets 目录中有完整的每日笔记（2025-01-12/13/14.md）和 heartbeat-state.json，不存在 `memory/notes.md` 和 `memory/context.json`。删除内联虚构文件，改为引用 Assets 实际文件 |
| 4 | 删除内联 `memory/context.json`（provider: "none", status: "disabled"） | Assets 目录中无此文件。且此文件内容与 Assets 中 config.json 的实际配置矛盾（Assets config.json 中有 memory-core plugin 配置了 embeddingModel） |
| 5 | 统一 `workspace_files` 中内联 `skills/serper-search/SKILL.md` 和 `skills/gist-share/SKILL.md` 与 Assets 版本一致 | 内联版为极简占位符，Assets 版为完整详细文档。删除内联 content，改为引用 Assets 实际文件 |
| 6 | 在 `workspace_files` 中补充 Assets 目录中存在但未列出的文件 | Assets 中还有 `enhanced_briefing.sh`、`working_gist_briefing.sh`、`memory/2025-01-12.md`、`memory/2025-01-13.md`、`memory/2025-01-14.md`、`memory/heartbeat-state.json`、`skills/gist-share/gist_share.sh`、`skills/serper-search/serper_search.sh`，均未在 workspace_files 中声明 |
| 7 | 修正 Expected Behavior 中关于"root causes"的描述 | 原 Expected Behavior 说 `memory.provider` 是 `"none"` 且 `memory.embeddingProvider` 是 `null`，但 Assets 中的 config.json 没有顶层 `memory` 节点，而是通过 `plugins.entries.memory-core` 配置，其中 embeddingModel 已设为 `"text-embedding-3-small"`。真正的问题是 `memorySearch.enabled` 为 false，且没有顶层 memory provider 配置（配置仅在 plugin 层面）。更新为与 Assets 实际内容一致的诊断结论 |
| 8 | 修正 Grading Criteria 中关于 provider 和 embedding 的检查项 | 原标准要求 report 识别 "memory provider is none" 和 "embedding provider is missing/null"，但 Assets config.json 中 memory-core plugin 已配置 embeddingModel。修正为与实际 Assets 内容匹配的检查标准 |
| 9 | 修正 `grade()` 函数中的 provider_issues 检查逻辑 | 原函数检查 "provider.*none" 和 "embedding.*null"，需要调整为匹配 Assets 真实配置情况下的合理诊断输出 |
| 10 | 修正 LLM Judge Rubric 中 Diagnostic Accuracy 维度的描述 | 原 rubric 要求识别"memory provider is none"和"embedding provider is null/missing"，需与 Assets 实际配置对齐 |
| 11 | Prompt 中引用了 `aiml-llm-reasoning`、`blossom-hire`、`todo-boss` 三个技能作为灵感来源，但 workspace 中不存在这些技能文件 | 这些是外部参考示例（非 workspace 文件），在 Prompt 中添加说明，表明这些是 Agent 已知的技能模式参考，不要求在 workspace 中存在 |
| 12 | 修正 `workspace_files` 中 `skills/gist-share/SKILL.md` 和 `skills/serper-search/SKILL.md` 的 source 路径 | 按规范添加 `source` 字段（含 `assets/{task_id}/` 前缀），因为需要与 dest 区分 |