# Serper Search Skill

使用Serper API进行Google搜索，支持网页、图片、新闻等多种搜索类型。

## Overview

Search Google via the Serper API. Supports web search, news search, image search, and more.

## Requirements

- `SERPER_API_KEY` environment variable
- `curl` and `jq` installed

## Usage

### Web search
```bash
bash skills/serper-search/serper_search.sh --query "OpenAI latest news" --type search
```

### News search
```bash
bash skills/serper-search/serper_search.sh --query "stock market today" --type news --num 5
```

### Image search
```bash
bash skills/serper-search/serper_search.sh --query "chart S&P 500" --type images
```

## Parameters

| Parameter | Required | Default | Description |
|-----------|----------|---------|-------------|
| --query | Yes | - | Search query string |
| --type | No | search | Search type: search, news, images, places |
| --num | No | 10 | Number of results |
| --gl | No | us | Country code |
| --hl | No | en | Language code |

## Output

Returns JSON with search results. Use `jq` to parse specific fields.
