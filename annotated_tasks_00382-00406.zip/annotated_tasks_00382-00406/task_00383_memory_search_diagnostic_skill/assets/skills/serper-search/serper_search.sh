#!/bin/bash
# serper_search.sh - Google search via Serper API
set -euo pipefail

QUERY=""
TYPE="search"
NUM=10
GL="us"
HL="en"
API_KEY="${SERPER_API_KEY:-}"

while [[ $# -gt 0 ]]; do
  case $1 in
    --query) QUERY="$2"; shift 2 ;;
    --type) TYPE="$2"; shift 2 ;;
    --num) NUM="$2"; shift 2 ;;
    --gl) GL="$2"; shift 2 ;;
    --hl) HL="$2"; shift 2 ;;
    *) echo "Unknown parameter: $1"; exit 1 ;;
  esac
done

if [ -z "$API_KEY" ]; then
  echo "Error: SERPER_API_KEY not set" >&2
  exit 1
fi

if [ -z "$QUERY" ]; then
  echo "Error: --query is required" >&2
  exit 1
fi

ENDPOINT="https://google.serper.dev/${TYPE}"

PAYLOAD=$(jq -n \
  --arg q "$QUERY" \
  --argjson num "$NUM" \
  --arg gl "$GL" \
  --arg hl "$HL" \
  '{q: $q, num: $num, gl: $gl, hl: $hl}')

curl -s -X POST "$ENDPOINT" \
  -H "X-API-KEY: $API_KEY" \
  -H "Content-Type: application/json" \
  -d "$PAYLOAD"
