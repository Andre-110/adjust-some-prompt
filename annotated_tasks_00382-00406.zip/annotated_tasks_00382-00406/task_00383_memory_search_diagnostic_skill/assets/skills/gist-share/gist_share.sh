#!/bin/bash
# gist_share.sh - Share content via GitHub Gist
# Usage: bash gist_share.sh --content "text" --filename "name.txt" [--description "desc"] [--public true|false] [--token TOKEN]

set -euo pipefail

CONTENT=""
FILE_PATH=""
FILENAME="shared.txt"
DESCRIPTION="Shared via OpenClaw"
PUBLIC="false"
TOKEN="${GITHUB_TOKEN:-}"

while [[ $# -gt 0 ]]; do
  case $1 in
    --content) CONTENT="$2"; shift 2 ;;
    --file) FILE_PATH="$2"; shift 2 ;;
    --filename) FILENAME="$2"; shift 2 ;;
    --description) DESCRIPTION="$2"; shift 2 ;;
    --public) PUBLIC="$2"; shift 2 ;;
    --token) TOKEN="$2"; shift 2 ;;
    *) echo "Unknown parameter: $1"; exit 1 ;;
  esac
done

if [ -z "$TOKEN" ]; then
  echo "Error: No GitHub token provided. Set GITHUB_TOKEN or pass --token" >&2
  exit 1
fi

# Read from file if --file was specified
if [ -n "$FILE_PATH" ]; then
  if [ ! -f "$FILE_PATH" ]; then
    echo "Error: File not found: $FILE_PATH" >&2
    exit 1
  fi
  CONTENT=$(cat "$FILE_PATH")
  [ -z "$FILENAME" ] && FILENAME=$(basename "$FILE_PATH")
fi

if [ -z "$CONTENT" ]; then
  echo "Error: No content provided. Use --content or --file" >&2
  exit 1
fi

# Use jq for proper JSON escaping to avoid parse errors
PAYLOAD=$(jq -n \
  --arg desc "$DESCRIPTION" \
  --argjson public "$PUBLIC" \
  --arg filename "$FILENAME" \
  --arg content "$CONTENT" \
  '{
    description: $desc,
    public: $public,
    files: {
      ($filename): {
        content: $content
      }
    }
  }')

RESPONSE=$(curl -s -X POST \
  -H "Authorization: token $TOKEN" \
  -H "Accept: application/vnd.github.v3+json" \
  -H "Content-Type: application/json" \
  -d "$PAYLOAD" \
  "https://api.github.com/gists")

GIST_URL=$(echo "$RESPONSE" | jq -r '.html_url // empty')

if [ -z "$GIST_URL" ] || [ "$GIST_URL" = "null" ]; then
  ERROR_MSG=$(echo "$RESPONSE" | jq -r '.message // "Unknown error"')
  echo "Error creating gist: $ERROR_MSG" >&2
  exit 1
fi

echo "$GIST_URL"
