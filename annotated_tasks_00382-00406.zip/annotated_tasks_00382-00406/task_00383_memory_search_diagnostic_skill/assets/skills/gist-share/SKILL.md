# Gist Share Skill

通过GitHub Gist服务分享文件和内容，支持文本、文件分享。

## Overview

Create and share content via GitHub Gist. Supports text content, files, and multi-file gists. Returns a shareable URL.

## Requirements

- `GITHUB_TOKEN` environment variable or pass token directly
- `curl` and `jq` installed

## Usage

### Share text content
```bash
bash skills/gist-share/gist_share.sh --content "Hello World" --filename "note.txt" --description "Quick note"
```

### Share a file
```bash
bash skills/gist-share/gist_share.sh --file /path/to/file.csv --description "Data export"
```

### Share as private gist (default)
```bash
bash skills/gist-share/gist_share.sh --content "$CONTENT" --filename "report.md" --public false
```

## Parameters

| Parameter | Required | Default | Description |
|-----------|----------|---------|-------------|
| --content | Yes* | - | Text content to share |
| --file | Yes* | - | File path to share (alternative to --content) |
| --filename | No | "shared.txt" | Filename in the gist |
| --description | No | "Shared via OpenClaw" | Gist description |
| --public | No | false | Whether gist is public |
| --token | No | $GITHUB_TOKEN | GitHub PAT token |

*Either --content or --file is required.

## Output

Returns the Gist URL on success (e.g., `https://gist.github.com/username/hash`).
Returns exit code 1 and error message on failure.

## Fallback

If Gist creation fails, the calling script should fall back to sending content directly in the message body.
