#!/bin/bash
# enhanced_briefing.sh - DEPRECATED: Old briefing script with 0x0.st sharing
# This script had JSON parsing issues and relied on 0x0.st which blocked our IP.
# Replaced by working_gist_briefing.sh
#
# Kept for reference only. DO NOT USE.

set -euo pipefail

DATE=$(date +"%Y-%m-%d")
BRIEFING_FILE="/tmp/briefing_${DATE}.md"

echo "=== Enhanced Financial Briefing (DEPRECATED) ==="
echo "WARNING: This script is deprecated. Use working_gist_briefing.sh instead."

# Old news fetching - had unescaped JSON issues
fetch_and_format() {
  local query=$1
  # BUG: This concatenation caused JSON parse errors when headlines contained quotes
  local payload='{"q": "'$query'", "num": 5}'
  
  curl -s -X POST 'https://google.serper.dev/news' \
    -H "X-API-KEY: ${SERPER_API_KEY}" \
    -H 'Content-Type: application/json' \
    -d "$payload"
}

# Build content
echo "# Financial Briefing - $DATE" > "$BRIEFING_FILE"
echo "" >> "$BRIEFING_FILE"

HK_NEWS=$(fetch_and_format "Hong Kong stock market" 2>/dev/null || echo '{"error": "fetch failed"}')
echo "## Hong Kong Market" >> "$BRIEFING_FILE"
echo "$HK_NEWS" | jq -r '.news[:3][] | "- \(.title): \(.snippet)"' >> "$BRIEFING_FILE" 2>/dev/null || echo "- No data" >> "$BRIEFING_FILE"

# Old upload to 0x0.st - BLOCKED
echo "Uploading to 0x0.st..."
SHARE_URL=$(curl -s -F "file=@${BRIEFING_FILE}" https://0x0.st 2>/dev/null || echo "UPLOAD_FAILED")

if [[ "$SHARE_URL" == *"0x0.st"* ]]; then
  echo "Shared: $SHARE_URL"
else
  echo "ERROR: 0x0.st upload failed (IP likely blocked)"
  echo "Response: $SHARE_URL"
fi

rm -f "$BRIEFING_FILE"
