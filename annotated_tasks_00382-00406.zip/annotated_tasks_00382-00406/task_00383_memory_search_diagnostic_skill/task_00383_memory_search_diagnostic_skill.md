---
id: task_00383_memory_search_diagnostic_skill
name: Memory Search Diagnostic Skill Creation
category: Knowledge and Memory Management
subcategory: Memory and Context Management
difficulty: medium
grading_type: hybrid
grading_weights: {automated: 0.4, llm_judge: 0.6}
timeout_seconds: 600
input_modality: text-only
external_dependency: none
skill_creation: true
workspace_files:
  - source: config.json
    dest: config.json
  - source: enhanced_briefing.sh
    dest: enhanced_briefing.sh
  - source: working_gist_briefing.sh
    dest: working_gist_briefing.sh
  - source: memory/2025-01-12.md
    dest: memory/2025-01-12.md
  - source: memory/2025-01-13.md
    dest: memory/2025-01-13.md
  - source: memory/2025-01-14.md
    dest: memory/2025-01-14.md
  - source: memory/heartbeat-state.json
    dest: memory/heartbeat-state.json
  - source: skills/serper-search/SKILL.md
    dest: skills/serper-search/SKILL.md
  - source: skills/serper-search/serper_search.sh
    dest: skills/serper-search/serper_search.sh
  - source: skills/gist-share/SKILL.md
    dest: skills/gist-share/SKILL.md
  - source: skills/gist-share/gist_share.sh
    dest: skills/gist-share/gist_share.sh
---

## Prompt

Hey, I need you to help me figure out the status of the memory_search feature in my system. I know it's supposed to be there but it doesn't seem to be working.

First, I'd like you to create a reusable diagnostic skill — call it something like "system-health-check" — as a SKILL.md file. It should be a skill that can diagnose whether key system features (like memory search, embedding providers, workspace paths, etc.) are properly configured and enabled. Take inspiration from well-known skill patterns like structured workflows with retries, posting structured data to services, and status tracking with reporting (e.g., skills like `aiml-llm-reasoning`, `blossom-hire`, `todo-boss` — these are general references for design patterns, not files in this workspace). The skill should define a clear process for checking system configuration, identifying issues, and producing a structured diagnostic report.

Then, use that skill's approach to actually diagnose my memory_search setup. Check the config files, look at the memory directory, figure out why memory search isn't working, and write a clear diagnostic report to `diagnostic_report.md` in the workspace root. The report should cover:
- Current memory_search enabled/disabled status
- What provider and plugin configuration exists for memory
- Whether an embedding provider/model is available
- What workspace paths exist for memory
- A clear explanation of what needs to be fixed
- Recommended next steps to enable memory search

## Expected Behavior

The agent should:

1. **Create a new skill** at `skills/system-health-check/SKILL.md` with proper YAML frontmatter (containing `name` and `description` fields) and markdown instruction sections describing a systematic diagnostic process. The skill should be inspired by the referenced skill design patterns (structured workflows, status tracking, reporting).

2. **Read and analyze configuration files** — specifically `config.json` and files under `memory/` — to determine the current state of the memory_search feature.

3. **Identify the root causes** of memory search being non-functional:
   - `agents.defaults.memorySearch.enabled` is set to `false` in config.json — this is the primary reason memory search is not working
   - Although a `memory-core` plugin is configured under `plugins.entries` with `embeddingModel: "text-embedding-3-small"` and valid `indexPath`/`watchPaths`, the top-level agent configuration has memory search explicitly disabled
   - The system has memory files in the `memory/` directory (daily notes, heartbeat state) but they are not being indexed/searched because the feature is turned off

4. **Write a diagnostic report** to `diagnostic_report.md` that includes:
   - The current disabled status of memory search (`memorySearch.enabled: false`)
   - The memory-core plugin configuration details (indexPath, watchPaths, embeddingModel)
   - The fact that despite having plugin-level memory configuration, the agent-level memory search is disabled
   - The existence of memory directory files (daily notes, heartbeat state)
   - Clear recommended steps to enable memory search (set `memorySearch.enabled` to `true`, verify plugin configuration is complete, trigger re-indexing of memory files)

5. The report should be well-structured, factual, and actionable — not just a vague summary. It should reference actual values from the config files.

## Grading Criteria

- [ ] SKILL.md created at `skills/system-health-check/SKILL.md` with valid YAML frontmatter
- [ ] SKILL.md contains `name` and `description` in frontmatter
- [ ] SKILL.md has meaningful instruction sections for diagnostic workflow
- [ ] `diagnostic_report.md` exists in workspace root
- [ ] Report identifies that `memorySearch.enabled` is `false`
- [ ] Report describes the memory-core plugin configuration or memory-related settings from config.json
- [ ] Report includes recommended next steps or fix instructions (e.g., enable memorySearch, verify plugin config, re-index)
- [ ] Report references actual config values from workspace files

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    import os
    import re

    scores = {
        "skill_md_exists": 0.0,
        "skill_md_structure": 0.0,
        "diagnostic_report_exists": 0.0,
        "report_identifies_disabled": 0.0,
        "report_identifies_memory_config": 0.0,
        "report_has_recommendations": 0.0,
    }

    # Check SKILL.md exists
    skill_path = os.path.join(workspace_path, "skills", "system-health-check", "SKILL.md")
    if not os.path.isfile(skill_path):
        # Also check alternate common paths
        for alt in ["skills/system-health-check/skill.md", "skills/system_health_check/SKILL.md"]:
            alt_path = os.path.join(workspace_path, alt)
            if os.path.isfile(alt_path):
                skill_path = alt_path
                break
        else:
            return scores

    scores["skill_md_exists"] = 1.0

    # Check SKILL.md structure: YAML frontmatter with name and description
    try:
        with open(skill_path, "r", encoding="utf-8") as f:
            skill_content = f.read()

        has_frontmatter = skill_content.strip().startswith("---")
        frontmatter_match = re.search(r"^---\s*\n(.*?)\n---", skill_content, re.DOTALL)
        if frontmatter_match:
            fm = frontmatter_match.group(1)
            has_name = bool(re.search(r"name\s*:", fm))
            has_desc = bool(re.search(r"description\s*:", fm))
            if has_name and has_desc:
                scores["skill_md_structure"] = 1.0
            elif has_name or has_desc:
                scores["skill_md_structure"] = 0.5
        elif has_frontmatter:
            scores["skill_md_structure"] = 0.25
    except Exception:
        pass

    # Check diagnostic_report.md exists
    report_path = os.path.join(workspace_path, "diagnostic_report.md")
    if not os.path.isfile(report_path):
        # Check common alternatives
        for alt_name in ["diagnostic-report.md", "DIAGNOSTIC_REPORT.md", "report.md"]:
            alt_rp = os.path.join(workspace_path, alt_name)
            if os.path.isfile(alt_rp):
                report_path = alt_rp
                break
        else:
            return scores

    scores["diagnostic_report_exists"] = 1.0

    try:
        with open(report_path, "r", encoding="utf-8") as f:
            report = f.read().lower()
    except Exception:
        return scores

    # Check report identifies memory search is disabled
    disabled_patterns = [
        r"memorysearch.*disabled",
        r"memory.search.*disabled",
        r"memory_search.*disabled",
        r"enabled.*false",
        r"memorysearch.*false",
        r"not\s+enabled",
        r"currently\s+disabled",
        r"disabled",
    ]
    for pat in disabled_patterns:
        if re.search(pat, report, re.IGNORECASE):
            scores["report_identifies_disabled"] = 1.0
            break

    # Check report identifies memory configuration details
    # (plugin config, embedding model, index path, or notes about provider setup)
    config_score = 0.0
    if re.search(r"memory[-_]?core|plugin.*memory|memory.*plugin", report):
        config_score += 0.35
    if re.search(r"embedding.*model|text-embedding|embedding.*configured|embeddingmodel", report):
        config_score += 0.35
    if re.search(r"index[-_]?path|watch[-_]?path|memory[-_]?index|/root/\.openclaw/memory", report):
        config_score += 0.3
    scores["report_identifies_memory_config"] = min(config_score, 1.0)

    # Check report has recommendations / next steps
    rec_patterns = [
        r"recommend",
        r"next\s+step",
        r"to\s+fix",
        r"to\s+enable",
        r"action\s+item",
        r"suggestion",
        r"resolution",
        r"how\s+to\s+enable",
        r"steps?\s+to",
        r"you\s+(need|should|must|can)",
        r"set.*enabled.*true",
        r"re[-_]?index",
    ]
    for pat in rec_patterns:
        if re.search(pat, report, re.IGNORECASE):
            scores["report_has_recommendations"] = 1.0
            break

    return scores
```

## LLM Judge Rubric

### Skill Quality and Design (Weight: 25%)
- 1.0: SKILL.md is well-structured with proper YAML frontmatter (name, description), clear diagnostic workflow sections, and is genuinely reusable for checking multiple system features. Inspired by referenced skill patterns (structured workflows, status tracking).
- 0.75: SKILL.md exists with frontmatter and reasonable instructions but is somewhat narrow or lacks clear workflow structure.
- 0.5: SKILL.md exists but is minimal — missing frontmatter fields, vague instructions, or not clearly a reusable skill.
- 0.25: SKILL.md exists but is essentially a stub or placeholder with no meaningful diagnostic process defined.
- 0.0: No SKILL.md created, or file is empty/unrelated to the task.

### Diagnostic Accuracy (Weight: 30%)
- 1.0: Report correctly identifies that memorySearch.enabled is false as the primary issue, and accurately describes the memory-core plugin configuration (embeddingModel, indexPath, watchPaths). References actual config values from the workspace files.
- 0.75: Report identifies that memorySearch is disabled and mentions some plugin/memory configuration details, but may miss one aspect or have minor inaccuracies.
- 0.5: Report identifies at least one key issue correctly (e.g., memorySearch disabled) but misses the plugin configuration details or includes inaccurate claims about the config.
- 0.25: Report vaguely mentions memory search not working but doesn't pinpoint specific configuration values or misattributes the problem.
- 0.0: No diagnostic report produced, or report is empty, or findings are entirely fabricated without reference to the actual config files.

### Evidence and Workspace Grounding (Weight: 25%)
- 1.0: The diagnostic report clearly references actual values from config.json (e.g., memorySearch.enabled: false, memory-core plugin settings, embeddingModel value) and mentions memory directory files. Conclusions are directly traceable to workspace data.
- 0.75: Report references most relevant config values but may miss some details from the memory directory or plugin configuration.
- 0.5: Report mentions config files but doesn't cite specific values, or partially grounds findings in actual data.
- 0.25: Report makes claims that are loosely related to the workspace but doesn't demonstrate reading the actual files.
- 0.0: Report ignores the provided workspace files entirely, hallucinates configuration values, or skips producing the deliverable.

### Actionable Recommendations (Weight: 20%)
- 1.0: Report provides clear, specific, and correct steps to enable memory search (e.g., set memorySearch.enabled to true, verify memory-core plugin configuration is complete, trigger re-indexing of memory files). Steps are ordered logically.
- 0.75: Report provides mostly correct recommendations but may be missing one step or slightly vague on details.
- 0.5: Report includes some recommendations but they are incomplete or partially incorrect.
- 0.25: Report mentions something should be fixed but doesn't provide actionable steps.
- 0.0: No recommendations provided, or recommendations are entirely wrong/irrelevant.