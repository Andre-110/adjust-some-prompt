---
id: task_00397_poly_arb_monitor_skill
name: Polygon Arbitrage Monitor Skill Creation and Execution
category: Finance and Quantitative Trading
subcategory: Trade Execution and Management
difficulty: medium
grading_type: hybrid
grading_weights: {automated: 0.4, llm_judge: 0.6}
timeout_seconds: 600
input_modality: text-only
external_dependency: none
skill_creation: true
workspace_files:
  - source: config/arb-config.json
    dest: config/arb-config.json
  - source: logs/transactions.log
    dest: logs/transactions.log
  - source: cron/schedule.conf
    dest: cron/schedule.conf
  - source: poly-arb-monitor.sh
    dest: poly-arb-monitor.sh
---

## Prompt

Hey, I need a reusable skill for monitoring Polygon blockchain arbitrage operations. Create it as a SKILL.md file under `skills/poly-arb-monitor/SKILL.md` — something like the ttt or limesurvey skills but for crypto arb monitoring. It should encapsulate the ability to check POL/USDC token balances via RPC, parse transaction logs for errors and profits, and produce a structured monitoring report.

Once you've created the skill, use it to actually run the enhanced monitoring check. The config is in `config/arb-config.json`, transaction logs are in `logs/transactions.log`, and the cron schedule is in `cron/schedule.conf`. There's also a reference monitoring script at `poly-arb-monitor.sh` you can look at. The cron task ID is `a2ce4b5b-63bf-4235-a84d-5a66cf18532f`.

Check the POL/USDC balances (it's fine if RPC calls fail — just report 0 or the error gracefully), analyze the transaction logs for any errors/warnings and calculate overall statistics (total transactions, success/failure counts, gas usage), and write the full monitoring report to `logs/monitor.log`. Initialize a git repo in the workspace too so we can track changes over time.

## Expected Behavior

The agent should:

1. **Create a SKILL.md file** at `skills/poly-arb-monitor/SKILL.md` with proper YAML frontmatter (including `name` and `description` fields) and markdown instruction sections describing how to perform Polygon arbitrage monitoring. This skill should be inspired by existing skills like ttt, limesurvey, and natural-language-planner but focused on crypto monitoring capabilities.

2. **Read the configuration** from `config/arb-config.json` to obtain wallet address (`0x7a3B9e4C2f1D8E6A5c0B7d9F3e2A1C4D5E6F7890`), RPC endpoints, token contract details, monitoring thresholds, and cron task information.

3. **Attempt to query POL/USDC balances** via the configured RPC endpoints. Since RPC endpoints may be unavailable in the sandbox, the agent should handle failures gracefully and report zero balances or error messages.

4. **Parse the transaction logs** in `logs/transactions.log` (pipe-delimited format with columns: timestamp, tx_hash, status, gas_used, pair, action, amount) to identify:
   - Total transaction count (15 entries)
   - Successful transactions (12 with status SUCCESS)
   - Failed/reverted transactions (1 FAILED + 2 REVERTED = 3 failures)
   - Total gas used across all transactions
   - BUY vs SELL action breakdown

5. **Write a monitoring report** to `logs/monitor.log` containing balance information, transaction log analysis, and any alerts (such as failure rate warnings if applicable).

6. **Initialize a git repository** in the workspace for version tracking.

7. The monitoring report should reference the cron task ID (`a2ce4b5b-63bf-4235-a84d-5a66cf18532f`) and include a timestamp.

## Grading Criteria

- [ ] SKILL.md exists at `skills/poly-arb-monitor/SKILL.md` with proper YAML frontmatter (name and description fields)
- [ ] SKILL.md contains meaningful instruction sections for monitoring
- [ ] logs/monitor.log exists and contains monitoring output
- [ ] logs/monitor.log references balance information (POL/USDC)
- [ ] logs/monitor.log contains transaction log analysis (transaction counts, failure statuses, gas usage)
- [ ] Git repository initialized (.git/HEAD exists)
- [ ] Configuration file was read and used (wallet address or task ID appears in output)
- [ ] SKILL.md is located in the correct skills directory path (not at workspace root)

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    import os
    import re
    from pathlib import Path

    scores = {
        "skill_md_exists_and_structured": 0.0,
        "monitor_log_exists": 0.0,
        "monitor_log_content_quality": 0.0,
        "git_initialized": 0.0,
        "transaction_log_analysis": 0.0,
        "config_integration": 0.0,
    }

    ws = Path(workspace_path)

    # 1. Check SKILL.md exists at correct skills path and has proper structure
    skill_path = ws / "skills" / "poly-arb-monitor" / "SKILL.md"
    # Also accept slight naming variations in the skill directory
    if not skill_path.exists():
        skills_dir = ws / "skills"
        if skills_dir.exists():
            for d in skills_dir.iterdir():
                if d.is_dir() and "poly" in d.name.lower() and "arb" in d.name.lower():
                    candidate = d / "SKILL.md"
                    if candidate.exists():
                        skill_path = candidate
                        break
    # Fallback: check workspace root (penalized)
    root_skill = ws / "SKILL.md"
    used_root = False
    if not skill_path.exists() and root_skill.exists():
        skill_path = root_skill
        used_root = True

    if skill_path.exists():
        content = skill_path.read_text(errors="replace")
        has_frontmatter = content.strip().startswith("---")
        has_name = bool(re.search(r"name\s*:", content[:500]))
        has_description = bool(re.search(r"description\s*:", content[:500]))
        has_sections = len(re.findall(r"^#{1,3}\s+", content, re.MULTILINE)) >= 2
        if has_frontmatter and has_name and has_description and has_sections:
            scores["skill_md_exists_and_structured"] = 0.7 if used_root else 1.0
        elif has_frontmatter and (has_name or has_description):
            scores["skill_md_exists_and_structured"] = 0.4 if used_root else 0.6
        elif has_frontmatter:
            scores["skill_md_exists_and_structured"] = 0.2 if used_root else 0.3
        else:
            scores["skill_md_exists_and_structured"] = 0.05 if used_root else 0.1

    # 2. Check logs/monitor.log exists
    monitor_log_path = ws / "logs" / "monitor.log"
    if monitor_log_path.exists():
        monitor_content = monitor_log_path.read_text(errors="replace")
        if len(monitor_content.strip()) > 20:
            scores["monitor_log_exists"] = 1.0
        elif len(monitor_content.strip()) > 0:
            scores["monitor_log_exists"] = 0.5
    else:
        monitor_content = ""

    # 3. Check monitor log content quality - balance references
    if monitor_content:
        has_pol = bool(re.search(r"(?i)(pol|wpol)", monitor_content))
        has_usdc = bool(re.search(r"(?i)usdc", monitor_content))
        has_balance = bool(re.search(r"(?i)(balance|0\.0+)", monitor_content))
        quality_score = 0.0
        if has_pol:
            quality_score += 0.33
        if has_usdc:
            quality_score += 0.33
        if has_balance:
            quality_score += 0.34
        scores["monitor_log_content_quality"] = round(min(quality_score, 1.0), 2)

    # 4. Check git initialized
    git_head = ws / ".git" / "HEAD"
    if git_head.exists():
        head_content = git_head.read_text(errors="replace").strip()
        if "ref:" in head_content or len(head_content) == 40:
            scores["git_initialized"] = 1.0
        else:
            scores["git_initialized"] = 0.5

    # 5. Check transaction log analysis in monitor output
    if monitor_content:
        has_profit = bool(re.search(r"(?i)(profit|earn|gain|arb)", monitor_content))
        has_error_mention = bool(re.search(r"(?i)(error|revert|fail|warn|slippage|REVERTED|FAILED)", monitor_content))
        has_tx_count = bool(re.search(r"(?i)(transaction|swap|trade|tx|count|total|gas)", monitor_content))
        analysis_score = 0.0
        if has_profit:
            analysis_score += 0.4
        if has_error_mention:
            analysis_score += 0.3
        if has_tx_count:
            analysis_score += 0.3
        scores["transaction_log_analysis"] = round(min(analysis_score, 1.0), 2)

    # 6. Check config integration - wallet address or task ID in output
    if monitor_content:
        has_wallet = bool(re.search(r"0x7a3B9e", monitor_content, re.IGNORECASE))
        has_task_id = bool(re.search(r"a2ce4b5b", monitor_content))
        has_cron_ref = bool(re.search(r"(?i)(cron|schedule|monitor)", monitor_content))
        config_score = 0.0
        if has_wallet:
            config_score += 0.4
        if has_task_id:
            config_score += 0.4
        if has_cron_ref:
            config_score += 0.2
        scores["config_integration"] = round(min(config_score, 1.0), 2)

    return scores
```

## LLM Judge Rubric

### Skill File Quality and Reusability (Weight: 25%)
Evaluates whether the agent created a well-structured, reusable SKILL.md at the correct path (`skills/poly-arb-monitor/SKILL.md`) that encapsulates Polygon arbitrage monitoring capabilities, inspired by existing skills like ttt and limesurvey.

- 1.0: SKILL.md at correct skills path has proper YAML frontmatter with name/description, multiple clear instruction sections covering balance checking, log parsing, and report generation. Could be reused by another agent.
- 0.75: SKILL.md exists with frontmatter and reasonable sections but missing some detail, not fully reusable, or placed at workspace root instead of skills directory.
- 0.5: SKILL.md exists but is minimal — missing frontmatter fields or has only superficial instructions.
- 0.25: SKILL.md exists but is essentially empty or a placeholder with no meaningful monitoring instructions.
- 0.0: No SKILL.md created, or file is completely unrelated to the monitoring task.

### Monitoring Report Completeness (Weight: 30%)
Evaluates whether logs/monitor.log contains a comprehensive monitoring report with balance information, transaction analysis, and alerts.

- 1.0: Report includes POL/USDC balance status, transaction log summary (total counts, success/failure breakdown, gas usage), timestamp, and cron task reference. Well-formatted and informative.
- 0.75: Report covers most areas (balances and transaction analysis) but missing one element like timestamp or cron reference.
- 0.5: Report exists but only covers balances OR transaction analysis, not both.
- 0.25: Report exists but contains minimal or generic content without specific data from the workspace files.
- 0.0: No monitor.log produced, or file is empty/irrelevant.

### Evidence and Workspace Grounding (Weight: 25%)
Evaluates whether the agent actually read and used the provided workspace files (config, transaction logs, cron schedule, monitoring script) rather than hallucinating data.

- 1.0: Clear evidence the agent read config/arb-config.json, parsed logs/transactions.log (referencing specific entries like transaction counts, failure statuses, or gas figures), and acknowledged the cron schedule. May have also referenced the monitoring script.
- 0.75: Agent used most workspace files but missed one source or made minor factual errors about the data.
- 0.5: Agent read some files but output shows partial hallucination or ignoring of available data.
- 0.25: Agent acknowledged files exist but did not meaningfully parse or use their content.
- 0.0: No evidence of reading workspace files; output is entirely generic or hallucinated without reference to the actual config, logs, or schedule provided.

### Technical Execution and Error Handling (Weight: 20%)
Evaluates the agent's technical approach — handling RPC failures gracefully, using Python when shell tools are unavailable, initializing git, and producing working code.

- 1.0: Agent handled RPC failures gracefully (reported zero balances or errors without crashing), adapted tools as needed (e.g., Python instead of jq), initialized git, and produced clean output.
- 0.75: Good technical execution with minor issues — e.g., git initialized but RPC error handling was rough.
- 0.5: Partial execution — some steps completed but agent got stuck on RPC failures or tool unavailability without recovering.
- 0.25: Attempted the task but significant technical failures — crashed on errors, no fallback strategies.
- 0.0: No meaningful technical execution attempted, or all steps failed without any recovery.