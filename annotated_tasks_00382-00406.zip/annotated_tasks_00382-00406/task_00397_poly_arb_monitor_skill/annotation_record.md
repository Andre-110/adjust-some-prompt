| 序号 | 修改项 | 修改原因 |
|------|--------|----------|
| 1 | 修正 `workspace_files` 字段格式：将 `path:` 改为 `dest:`，并补充 Assets 目录中实际存在的文件 | 原任务使用已废弃的 `path:` 字段，违反数据规范要求；且 `workspace_files` 列表与 Assets 目录中的实际文件不一致（Assets 中为 `config/arb-config.json`，内联为 `config/monitor-config.json`；Assets 中有 `poly-arb-monitor.sh` 在根目录，内联中无此文件） |
| 2 | 统一配置文件内容：将内联 `config/monitor-config.json` 替换为 Assets 中的 `config/arb-config.json` 的内容，并统一文件名为 `config/arb-config.json` | 内联 YAML 中的配置文件（`monitor-config.json`）与 Assets 目录中的配置文件（`arb-config.json`）内容严重不一致（钱包地址不同、结构不同、USDC 合约地址不同），会导致 Agent 混淆。以 Assets 版本为准进行统一 |
| 3 | 更新 Prompt 中的配置文件路径引用：`config/monitor-config.json` → `config/arb-config.json` | 与统一后的配置文件名保持一致 |
| 4 | 更新 Expected Behavior 中的配置文件路径引用 | 与统一后的配置文件名保持一致 |
| 5 | 更新 `grade()` 函数中的 `config_integration` 检查：钱包地址正则从 `0x742d35` 改为 `0x7a3B9e` | 统一使用 Assets 中 `arb-config.json` 的钱包地址 `0x7a3B9e4C2f1D8E6A5c0B7d9F3e2A1C4D5E6F7890` |
| 6 | 更新 `workspace_files` 中 `logs/transactions.log` 的内联内容为 Assets 中的 pipe-delimited 格式版本 | 内联版本（自然语言日志格式）与 Assets 目录中的实际文件（pipe-delimited CSV 格式）内容完全不同，Agent 实际会看到 Assets 版本 |
| 7 | 添加 `poly-arb-monitor.sh` 到 `workspace_files` 列表 | Assets 目录中存在此脚本但 `workspace_files` 中未列出，且 `cron/schedule.conf` 引用了此脚本路径 |
| 8 | 更新 Expected Behavior 中关于日志解析的描述 | 需要反映 Assets 中 transactions.log 的实际格式（pipe-delimited 而非自然语言格式），包括具体的状态字段（SUCCESS/REVERTED/FAILED） |
| 9 | 更新 `grade()` 函数中 `transaction_log_analysis` 的关键词匹配 | 增加对 REVERTED/FAILED 状态的匹配，与实际 Assets 日志格式对齐 |
| 10 | 修正 SKILL.md 路径：从 `ws / "SKILL.md"` 改为 `ws / "skills" / "poly-arb-monitor" / "SKILL.md"` | 按照 skill 路径规范，技能文件应放在 `skills/<skill名>/SKILL.md`，而非 workspace 根目录下裸放 |
| 11 | 更新 Prompt 和 Expected Behavior 中 SKILL.md 的路径说明 | 与 skill 路径规范一致：`skills/poly-arb-monitor/SKILL.md` |
| 12 | 修正 `cron/schedule.conf` 中引用的脚本路径 | 原路径 `/workspace/scripts/poly-arb-monitor.sh` 与 Assets 中脚本实际位置 `poly-arb-monitor.sh`（根目录）不一致，改为 `/workspace/poly-arb-monitor.sh` |
| 13 | 添加 Grading Criteria 条目：SKILL.md 位于正确的 skills 目录路径 | 补充对 skill 路径规范的评分点 |