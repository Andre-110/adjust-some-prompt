#!/usr/bin/env bash
# poly-arb-monitor.sh — Enhanced POL/USDC Arbitrage Monitor
# Checks wallet balances on Polygon PoS and monitors transaction logs
# Cron task: a2ce4b5b-63bf-4235-a84d-5a66cf18532f

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CONFIG_FILE="${SCRIPT_DIR}/config/arb-config.json"
LOG_DIR="${SCRIPT_DIR}/logs"
TX_LOG="${LOG_DIR}/transactions.log"
MONITOR_LOG="${LOG_DIR}/monitor.log"
ALERT_THRESHOLD_POL=50
ALERT_THRESHOLD_USDC=100

# Colors for terminal output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

log() {
  local level="$1"
  shift
  echo "[$(date -u '+%Y-%m-%dT%H:%M:%SZ')] [$level] $*" | tee -a "$MONITOR_LOG"
}

# Load configuration
if [[ ! -f "$CONFIG_FILE" ]]; then
  log "ERROR" "Configuration file not found: $CONFIG_FILE"
  exit 1
fi

WALLET_ADDRESS=$(jq -r '.wallet.address' "$CONFIG_FILE")
RPC_ENDPOINT=$(jq -r '.rpc.primary' "$CONFIG_FILE")
RPC_FALLBACK=$(jq -r '.rpc.fallback' "$CONFIG_FILE")
POL_CONTRACT=$(jq -r '.contracts.POL' "$CONFIG_FILE")
USDC_CONTRACT=$(jq -r '.contracts.USDC' "$CONFIG_FILE")
DECIMALS_POL=$(jq -r '.decimals.POL' "$CONFIG_FILE")
DECIMALS_USDC=$(jq -r '.decimals.USDC' "$CONFIG_FILE")

# ERC-20 balanceOf(address) selector: 0x70a08231
BALANCE_OF_SELECTOR="0x70a08231"

# Pad address to 32 bytes for eth_call data field
pad_address() {
  local addr="${1#0x}"
  printf "0x70a08231%064s" "$addr" | tr ' ' '0'
}

# Query ERC-20 balance via eth_call
query_balance() {
  local token_contract="$1"
  local rpc_url="$2"
  local call_data
  call_data=$(pad_address "$WALLET_ADDRESS")

  local payload
  payload=$(cat <<EOF
{
  "jsonrpc": "2.0",
  "method": "eth_call",
  "params": [
    {
      "to": "${token_contract}",
      "data": "${call_data}"
    },
    "latest"
  ],
  "id": 1
}
EOF
)

  local response
  response=$(curl -s -X POST -H "Content-Type: application/json" \
    --max-time 10 \
    -d "$payload" \
    "$rpc_url" 2>/dev/null)

  if [[ $? -ne 0 ]] || [[ -z "$response" ]]; then
    return 1
  fi

  local result
  result=$(echo "$response" | jq -r '.result // empty')
  if [[ -z "$result" ]] || [[ "$result" == "null" ]]; then
    local err
    err=$(echo "$response" | jq -r '.error.message // "unknown error"')
    log "WARN" "RPC error: $err"
    return 1
  fi

  echo "$result"
}

# Convert hex wei to decimal with proper decimals
hex_to_decimal() {
  local hex_value="${1#0x}"
  local decimals="$2"
  # Use python for big number math
  python3 -c "
val = int('$hex_value', 16)
dec = $decimals
whole = val // (10 ** dec)
frac = val % (10 ** dec)
print(f'{whole}.{frac:0{dec}d}')
"
}

# Check native MATIC/POL balance
check_native_balance() {
  local rpc_url="$1"
  local payload
  payload=$(cat <<EOF
{
  "jsonrpc": "2.0",
  "method": "eth_getBalance",
  "params": ["${WALLET_ADDRESS}", "latest"],
  "id": 1
}
EOF
)

  local response
  response=$(curl -s -X POST -H "Content-Type: application/json" \
    --max-time 10 \
    -d "$payload" \
    "$rpc_url" 2>/dev/null)

  echo "$response" | jq -r '.result // empty'
}

# Monitor recent transaction log entries
monitor_tx_log() {
  if [[ ! -f "$TX_LOG" ]]; then
    log "WARN" "Transaction log not found: $TX_LOG"
    return 0
  fi

  local now_epoch
  now_epoch=$(date +%s)
  local lookback=3600  # 1 hour

  local recent_count=0
  local failed_count=0
  local total_gas_used=0

  while IFS='|' read -r timestamp tx_hash status gas_used pair action amount; do
    # Skip header or empty lines
    [[ "$timestamp" == "timestamp" ]] && continue
    [[ -z "$timestamp" ]] && continue

    local tx_epoch
    tx_epoch=$(date -d "$timestamp" +%s 2>/dev/null || echo 0)

    if (( tx_epoch > now_epoch - lookback )); then
      ((recent_count++))
      if [[ "$status" == "FAILED" ]] || [[ "$status" == "REVERTED" ]]; then
        ((failed_count++))
        log "ALERT" "Failed TX in last hour: $tx_hash ($pair $action) — Status: $status"
      fi
      total_gas_used=$((total_gas_used + ${gas_used:-0}))
    fi
  done < "$TX_LOG"

  log "INFO" "TX Log Summary (last 1h): ${recent_count} txns, ${failed_count} failed, ${total_gas_used} total gas"

  # Alert on high failure rate
  if (( recent_count > 0 )) && (( failed_count * 100 / recent_count > 30 )); then
    log "ALERT" "High failure rate: ${failed_count}/${recent_count} (>30%) in last hour"
    return 2
  fi
}

# Check for stuck/pending transactions
check_pending_txns() {
  local rpc_url="$1"
  local payload
  payload=$(cat <<EOF
{
  "jsonrpc": "2.0",
  "method": "eth_getTransactionCount",
  "params": ["${WALLET_ADDRESS}", "pending"],
  "id": 1
}
EOF
)
  local pending
  pending=$(curl -s -X POST -H "Content-Type: application/json" \
    --max-time 10 \
    -d "$payload" \
    "$rpc_url" 2>/dev/null | jq -r '.result // empty')

  payload=$(cat <<EOF
{
  "jsonrpc": "2.0",
  "method": "eth_getTransactionCount",
  "params": ["${WALLET_ADDRESS}", "latest"],
  "id": 2
}
EOF
)
  local confirmed
  confirmed=$(curl -s -X POST -H "Content-Type: application/json" \
    --max-time 10 \
    -d "$payload" \
    "$rpc_url" 2>/dev/null | jq -r '.result // empty')

  if [[ -n "$pending" ]] && [[ -n "$confirmed" ]]; then
    local pending_dec=$((16#${pending#0x}))
    local confirmed_dec=$((16#${confirmed#0x}))
    local stuck=$((pending_dec - confirmed_dec))
    if (( stuck > 0 )); then
      log "ALERT" "Stuck transactions detected: ${stuck} pending (nonce gap: confirmed=${confirmed_dec}, pending=${pending_dec})"
    else
      log "INFO" "No stuck transactions (nonce: ${confirmed_dec})"
    fi
  fi
}

# ========== MAIN ==========

log "INFO" "=== Enhanced Poly-Arb Monitor Starting ==="
log "INFO" "Wallet: ${WALLET_ADDRESS}"
log "INFO" "RPC: ${RPC_ENDPOINT}"

mkdir -p "$LOG_DIR"

# 1. Check POL (wrapped) balance
log "INFO" "Checking POL balance..."
rpc_active="$RPC_ENDPOINT"
pol_hex=$(query_balance "$POL_CONTRACT" "$rpc_active") || {
  log "WARN" "Primary RPC failed, trying fallback..."
  rpc_active="$RPC_FALLBACK"
  pol_hex=$(query_balance "$POL_CONTRACT" "$rpc_active") || {
    log "ERROR" "Both RPCs failed for POL balance query"
    pol_hex=""
  }
}

if [[ -n "$pol_hex" ]]; then
  pol_balance=$(hex_to_decimal "$pol_hex" "$DECIMALS_POL")
  pol_whole=${pol_balance%%.*}
  log "INFO" "POL Balance: ${pol_balance}"
  if (( pol_whole < ALERT_THRESHOLD_POL )); then
    log "ALERT" "POL balance below threshold: ${pol_balance} < ${ALERT_THRESHOLD_POL}"
  fi
fi

# 2. Check USDC balance
log "INFO" "Checking USDC balance..."
usdc_hex=$(query_balance "$USDC_CONTRACT" "$rpc_active") || {
  log "ERROR" "RPC failed for USDC balance query"
  usdc_hex=""
}

if [[ -n "$usdc_hex" ]]; then
  usdc_balance=$(hex_to_decimal "$usdc_hex" "$DECIMALS_USDC")
  usdc_whole=${usdc_balance%%.*}
  log "INFO" "USDC Balance: ${usdc_balance}"
  if (( usdc_whole < ALERT_THRESHOLD_USDC )); then
    log "ALERT" "USDC balance below threshold: ${usdc_balance} < ${ALERT_THRESHOLD_USDC}"
  fi
fi

# 3. Check native MATIC balance (for gas)
log "INFO" "Checking native balance (gas)..."
native_hex=$(check_native_balance "$rpc_active")
if [[ -n "$native_hex" ]]; then
  native_balance=$(hex_to_decimal "$native_hex" 18)
  log "INFO" "Native (MATIC/POL) Balance: ${native_balance}"
  native_whole=${native_balance%%.*}
  if (( native_whole < 5 )); then
    log "ALERT" "Low gas balance: ${native_balance} — may affect arb execution"
  fi
fi

# 4. Monitor transaction logs
log "INFO" "Scanning transaction logs..."
monitor_tx_log
tx_status=$?

# 5. Check for stuck transactions
log "INFO" "Checking pending transactions..."
check_pending_txns "$rpc_active"

# 6. Summary
echo ""
log "INFO" "=== Monitor Summary ==="
log "INFO" "  POL:    ${pol_balance:-N/A}"
log "INFO" "  USDC:   ${usdc_balance:-N/A}"
log "INFO" "  Native: ${native_balance:-N/A}"
log "INFO" "  TX Log: $([ $tx_status -eq 0 ] && echo 'OK' || echo 'ALERTS')"
log "INFO" "=== Monitor Complete ==="
