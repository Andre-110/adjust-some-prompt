---
id: task_00386_heartbeat_joke_scheduler
name: Heartbeat Joke Scheduler Check
category: Workflow and Agent Orchestration
subcategory: Workflow and Task Scheduling
difficulty: medium
grading_type: hybrid
grading_weights: {automated: 0.4, llm_judge: 0.6}
timeout_seconds: 600
input_modality: text-only
external_dependency: none
workspace_files:
  - source: HEARTBEAT.md
    dest: HEARTBEAT.md
  - source: memory/joke_tracker.json
    dest: memory/joke_tracker.json
---

## Prompt

Hey, I have a heartbeat system set up. There's a `HEARTBEAT.md` file in the workspace that defines any recurring tasks the agent should do, and a `memory/joke_tracker.json` that tracks the last time a joke was sent (as a Unix timestamp and an index).

Can you check `HEARTBEAT.md` to see if there are any active heartbeat tasks defined? Then check `memory/joke_tracker.json` for the current state. Based on what you find, do whatever the heartbeat file says — or if there are no active tasks, just respond with `HEARTBEAT_OK`.

## Expected Behavior

1. The agent should read `HEARTBEAT.md` and observe that it contains only comments and no active task definitions. The file explicitly states: "Keep this file empty (or with only comments) to skip heartbeat API calls."
2. The agent should read `memory/joke_tracker.json` to check the current tracker state, including both `last_joke_time` and `last_joke_index`.
3. Since `HEARTBEAT.md` has no active tasks (only comments), the agent should recognize that no heartbeat action is required.
4. The agent should respond with `HEARTBEAT_OK` (or a message clearly indicating no action is needed because no active tasks are defined).
5. The agent should NOT send a joke, since the heartbeat task definition has been removed/cleared.
6. The `memory/joke_tracker.json` file should remain unmodified (no new timestamp or index written) since no joke was delivered.

## Grading Criteria

- [ ] Agent reads `HEARTBEAT.md` to check for active tasks
- [ ] Agent reads `memory/joke_tracker.json` to check tracker state (both `last_joke_time` and `last_joke_index`)
- [ ] Agent correctly identifies that `HEARTBEAT.md` has no active tasks (only comments)
- [ ] Agent responds with `HEARTBEAT_OK` or equivalent "no action needed" message
- [ ] Agent does NOT send a joke or update the tracker file
- [ ] `memory/joke_tracker.json` remains unchanged (both `last_joke_time` still 1770546120 and `last_joke_index` still 3)

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    import json
    import os

    scores = {
        "tracker_unchanged": 0.0,
        "heartbeat_ok_response": 0.0,
        "no_joke_sent": 0.0,
        "read_heartbeat_file": 0.0,
    }

    # Check if joke_tracker.json was not modified (timestamps and index unchanged)
    tracker_path = os.path.join(workspace_path, "memory", "joke_tracker.json")
    if os.path.exists(tracker_path):
        try:
            with open(tracker_path, "r", encoding="utf-8") as f:
                data = json.load(f)
            if (data.get("last_joke_time") == 1770546120 and
                data.get("last_joke_index") == 3):
                scores["tracker_unchanged"] = 1.0
            else:
                scores["tracker_unchanged"] = 0.0
        except (json.JSONDecodeError, Exception):
            scores["tracker_unchanged"] = 0.0
    else:
        scores["tracker_unchanged"] = 0.0

    # Check that HEARTBEAT.md still exists and has no active tasks
    heartbeat_path = os.path.join(workspace_path, "HEARTBEAT.md")
    if os.path.exists(heartbeat_path):
        try:
            with open(heartbeat_path, "r", encoding="utf-8") as f:
                content = f.read()
            # Count non-empty, non-comment lines as potential active tasks
            non_comment_lines = [
                line.strip() for line in content.strip().splitlines()
                if line.strip() and not line.strip().startswith("#")
            ]
            if len(non_comment_lines) == 0:
                scores["read_heartbeat_file"] = 1.0
            elif len(non_comment_lines) <= 2:
                scores["read_heartbeat_file"] = 0.5
            else:
                scores["read_heartbeat_file"] = 0.0
        except Exception:
            scores["read_heartbeat_file"] = 0.0
    else:
        scores["read_heartbeat_file"] = 0.0

    # Check transcript for HEARTBEAT_OK response and absence of joke delivery
    found_heartbeat_ok = False
    found_joke = False

    for event in transcript:
        if event.get("type") != "message":
            continue
        msg = event.get("message", {})
        if msg.get("role") == "assistant":
            text = msg.get("content", "")
            if isinstance(text, str):
                if "HEARTBEAT_OK" in text.upper().replace(" ", "").replace("_", "_"):
                    found_heartbeat_ok = True
                # Heuristic checks if joke delivered
                lower_text = text.lower()
                # Check if agent explicitly delivered a joke
                if ("here's a joke" in lower_text or
                    "here is a joke" in lower_text or
                    "joke for you" in lower_text or
                    "why did the" in lower_text or
                    "knock knock" in lower_text):
                    found_joke = True

    if found_heartbeat_ok:
        scores["heartbeat_ok_response"] = 1.0
    else:
        # Check for equivalent "no action needed" phrasing
        for event in transcript:
            if event.get("type") != "message":
                continue
            msg = event.get("message", {})
            if msg.get("role") == "assistant":
                text = msg.get("content", "")
                if isinstance(text, str):
                    lower_text = text.lower()
                    if ("no active task" in lower_text or
                        "no tasks" in lower_text or
                        "no action" in lower_text or
                        "nothing to do" in lower_text or
                        "skip" in lower_text):
                        scores["heartbeat_ok_response"] = 0.75
                        break

    if not found_joke:
        scores["no_joke_sent"] = 1.0
    else:
        scores["no_joke_sent"] = 0.0

    return scores
```

## LLM Judge Rubric

### Correct Interpretation of HEARTBEAT.md (Weight: 35%)
- 1.0: Agent correctly reads `HEARTBEAT.md`, identifies that it contains only comments with no active tasks, and explicitly states that no heartbeat action is required.
- 0.75: Agent reads `HEARTBEAT.md` and concludes no action is needed, but explanation is vague or incomplete about why.
- 0.5: Agent reads `HEARTBEAT.md` but is uncertain whether tasks exist; hedges or partially acts.
- 0.25: Agent reads `HEARTBEAT.md` but misinterprets the comments as active tasks.
- 0.0: Agent does not read `HEARTBEAT.md`, or completely ignores its contents and proceeds with an assumed task.

### Appropriate Response — HEARTBEAT_OK (Weight: 25%)
- 1.0: Agent responds with "HEARTBEAT_OK" or a clear equivalent indicating no heartbeat action was taken because no tasks are defined.
- 0.75: Agent indicates no action needed but does not use the HEARTBEAT_OK convention.
- 0.5: Agent's response is ambiguous about whether action was taken.
- 0.25: Agent responds but also performs unnecessary actions (e.g., sends a joke despite no active task).
- 0.0: Agent sends a joke or takes heartbeat action when none was required, or provides no relevant response.

### Evidence and Workspace Grounding (Weight: 25%)
- 1.0: Agent reads both `HEARTBEAT.md` and `memory/joke_tracker.json`, references their actual content, and bases its decision on the file contents rather than assumptions or prior context.
- 0.75: Agent reads both files but only references one in its reasoning.
- 0.5: Agent reads only one of the two files and bases its decision partially on assumptions.
- 0.25: Agent references the files but does not actually read them; relies on cached/assumed content.
- 0.0: Agent ignores the workspace files entirely, hallucinates file contents, or makes decisions without consulting any files.

### No Unnecessary Side Effects (Weight: 15%)
- 1.0: Agent does not modify `memory/joke_tracker.json` or any other file, correctly leaving the workspace unchanged since no action was needed.
- 0.75: Agent reads files but makes a trivial or cosmetic change that doesn't affect functionality.
- 0.5: Agent updates `memory/joke_tracker.json` unnecessarily but does not send a joke.
- 0.25: Agent sends a joke and updates the tracker despite no active task.
- 0.0: Agent makes multiple unnecessary modifications, creates new files, or significantly alters the workspace state without justification.