---
id: task_00384_openclaw_runtime_audit_skill
name: OpenClaw Runtime Audit and Session Cleanup Skill
category: System Administration
subcategory: Software and Environment Management
difficulty: medium
grading_type: hybrid
grading_weights: {automated: 0.4, llm_judge: 0.6}
timeout_seconds: 600
input_modality: text-only
external_dependency: none
skill_creation: true
workspace_files:
  # --- session log files (inline, not present as separate asset files) ---
  - dest: sessions/session_001.jsonl
    content: |
      {"ts":"2026-01-01T00:00:00Z","event":"start"}
      {"ts":"2026-01-01T00:01:00Z","event":"end"}
  - dest: sessions/session_002.jsonl
    content: |
      {"ts":"2026-01-15T00:00:00Z","event":"start"}
      {"ts":"2026-01-15T00:05:00Z","event":"end"}
  - dest: sessions/session_003.jsonl
    content: |
      {"ts":"2026-02-01T00:00:00Z","event":"start"}
  - dest: sessions/session_004.jsonl
    content: |
      {"ts":"2026-02-05T10:00:00Z","event":"start"}
      {"ts":"2026-02-05T10:30:00Z","event":"heartbeat"}
  - dest: sessions/session_005.jsonl
    content: |
      {"ts":"2026-02-09T08:00:00Z","event":"start"}
      {"ts":"2026-02-09T09:00:00Z","event":"heartbeat"}
  - dest: sessions/old_batch_01.jsonl
    content: |
      {"ts":"2025-11-01T00:00:00Z","event":"start"}
  - dest: sessions/old_batch_02.jsonl
    content: |
      {"ts":"2025-12-01T00:00:00Z","event":"start"}
  - dest: sessions/old_batch_03.jsonl
    content: |
      {"ts":"2025-10-15T00:00:00Z","event":"start"}
  # --- asset files from task directory ---
  - source: main.py
    dest: main.py
  - source: .openclaw/config/gateway.yaml
    dest: .openclaw/config/gateway.yaml
  - source: .openclaw/runtime/state.json
    dest: .openclaw/runtime/state.json
  - source: .openclaw/runtime/gateway.pid
    dest: .openclaw/runtime/gateway.pid
  - source: .openclaw/logs/gateway.log
    dest: .openclaw/logs/gateway.log
  - source: .openclaw/logs/gateway-2026-02-09.log
    dest: .openclaw/logs/gateway-2026-02-09.log
  - source: scripts/daemon.sh
    dest: scripts/daemon.sh
---

## Prompt

Hey, I've got a couple of things I need help with. First, I'd love a reusable skill for auditing an OpenClaw runtime environment — something that can inspect the running context (main program location, PIDs, config), check for accumulated session log files, and produce a clear status report. Create it as a SKILL.md file at `skills/runtime-audit/SKILL.md` in the workspace, inspired by skills like k8s-memory-tune and ztp (think: trigger words, structured audit steps, clear output format).

Then, actually use that skill to do the following:

1. I noticed there are a huge number of .jsonl files in the sessions/ directory. Check how many there are, figure out which ones are old or safe to remove, and write a cleanup report.

2. Also, check the current runtime context — where's the main program, what are the PIDs, what config is being used — so that if something goes wrong during cleanup, I can quickly restore things manually.

Write your findings to a file called `audit_report.md` in the workspace root. The report should include a table or structured summary of the runtime environment (version, PIDs, entry point, working directory, config file) and a section about the session files (count, which are old, cleanup recommendations).

## Expected Behavior

The agent should:

1. **Create a SKILL.md file** at `skills/runtime-audit/SKILL.md` (relative to workspace root) that defines a reusable "runtime-audit" skill. It should have YAML frontmatter with `name` and `description` fields, and markdown body sections describing trigger words, audit steps (inspect runtime state, check session files, produce report), and output format. This is inspired by similar skills like k8s-memory-tune (structured diagnostics) and ztp (security/audit validation).

2. **Inspect the runtime context** by reading `.openclaw/runtime/state.json` and `.openclaw/config/gateway.yaml` to identify:
   - Main program entry point: `main.py` (located at `/home/admin/.openclaw/workspace/main.py` per state.json)
   - PID: **48291** (from `.openclaw/runtime/gateway.pid` and `state.json`)
   - Runtime version: **2026.2.6-3** (from `state.json`)
   - Config version field: **2026.3.13** (from `.openclaw/config/gateway.yaml`)
   - Working directory: `/home/admin/.openclaw/workspace`
   - Config path: `/home/admin/.openclaw/config/gateway.yaml`
   - The agent may also reference `scripts/daemon.sh` to understand how the gateway is started/stopped and confirm the PID file location.

3. **Audit the sessions/ directory** to count .jsonl files (there are **8** in the workspace: session_001 through session_005, old_batch_01 through old_batch_03), identify older ones (old_batch files from 2025-10 to 2025-12, session_001 from 2026-01-01, session_002 from 2026-01-15), and determine which are safe to clean up. The agent may also reference the log files under `.openclaw/logs/` which note session directory sizes and expiry warnings as corroborating evidence.

4. **Write `audit_report.md`** in the workspace root containing:
   - A runtime environment summary (version, PID, entry point, working directory, config path) — values must match those from the workspace files above
   - A session files audit section (total count = 8, list of files with timestamps, cleanup recommendations)

5. **Respond conversationally** to the user summarizing the findings, including the runtime info table and session cleanup assessment.

**Traps / edge notes:**
- The workspace contains both a `main.py` (application source) and `scripts/daemon.sh` (process control). The agent should read both but recognize that `state.json` is the authoritative source for current runtime state.
- There is no old-format `.openclaw/runtime.json`; the correct file is `.openclaw/runtime/state.json`.
- `config.yaml` at workspace root does **not** exist; the config is at `.openclaw/config/gateway.yaml`.

## Grading Criteria

- [ ] SKILL.md exists at `skills/runtime-audit/SKILL.md` with proper YAML frontmatter (name and description fields)
- [ ] SKILL.md contains meaningful audit instruction sections in the body
- [ ] audit_report.md exists in the workspace root
- [ ] audit_report.md contains runtime environment info (PID 48291, version 2026.2.6-3, entry point main.py)
- [ ] audit_report.md contains session file audit information (count = 8, file listing)
- [ ] audit_report.md includes cleanup recommendations
- [ ] Agent's conversational reply summarizes runtime context and session status

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    import os
    import re

    scores = {
        "skill_md_exists_and_structured": 0.0,
        "audit_report_exists": 0.0,
        "audit_report_runtime_info": 0.0,
        "audit_report_session_info": 0.0,
        "audit_report_cleanup_recs": 0.0,
        "conversational_reply": 0.0,
    }

    # 1. Check SKILL.md exists at skills/runtime-audit/SKILL.md and has proper structure
    skill_path = os.path.join(workspace_path, "skills", "runtime-audit", "SKILL.md")
    if os.path.isfile(skill_path):
        try:
            content = open(skill_path, "r", encoding="utf-8").read()
            has_frontmatter = content.strip().startswith("---")
            has_name = bool(re.search(r"(?i)name\s*:", content))
            has_description = bool(re.search(r"(?i)description\s*:", content))
            has_body = len(content.strip()) > 200
            if has_frontmatter and has_name and has_description and has_body:
                scores["skill_md_exists_and_structured"] = 1.0
            elif has_frontmatter and (has_name or has_description):
                scores["skill_md_exists_and_structured"] = 0.6
            elif has_name or has_description:
                scores["skill_md_exists_and_structured"] = 0.3
        except Exception:
            pass

    # 2. Check audit_report.md exists
    report_path = os.path.join(workspace_path, "audit_report.md")
    if os.path.isfile(report_path):
        scores["audit_report_exists"] = 1.0
        try:
            report = open(report_path, "r", encoding="utf-8").read().lower()
        except Exception:
            report = ""

        # 3. Check runtime info in report — values from .openclaw/runtime/state.json
        runtime_keywords = ["pid", "48291", "main.py", "2026.2.6-3", "version"]
        runtime_hits = sum(1 for kw in runtime_keywords if kw.lower() in report)
        scores["audit_report_runtime_info"] = min(1.0, runtime_hits / 4.0)

        # 4. Check session file audit info
        session_keywords = ["session", "jsonl", "old_batch", "count", "file"]
        session_hits = sum(1 for kw in session_keywords if kw.lower() in report)
        scores["audit_report_session_info"] = min(1.0, session_hits / 3.0)

        # 5. Check cleanup recommendations
        cleanup_keywords = ["clean", "remov", "delet", "safe", "recommend", "archive"]
        cleanup_hits = sum(1 for kw in cleanup_keywords if kw.lower() in report)
        scores["audit_report_cleanup_recs"] = min(1.0, cleanup_hits / 2.0)

    # 6. Check conversational reply in transcript
    for event in transcript:
        if event.get("type") != "message":
            continue
        msg = event.get("message", {})
        if msg.get("role") == "assistant":
            text = str(msg.get("content", "")).lower()
            if any(kw in text for kw in ["pid", "48291", "main.py", "session", "jsonl"]):
                scores["conversational_reply"] = 1.0
                break

    return scores
```

## LLM Judge Rubric

### Skill File Quality (Weight: 25%)
- 1.0: SKILL.md is placed at `skills/runtime-audit/SKILL.md`, has proper YAML frontmatter with name and description, well-organized markdown body with trigger words, step-by-step audit instructions, and output format specification. Clearly inspired by referenced skills (k8s-memory-tune, ztp).
- 0.75: SKILL.md exists with frontmatter and reasonable body content but missing some structural elements (e.g., no trigger words or incomplete steps), or placed at a non-standard path.
- 0.5: SKILL.md exists but is minimal — has frontmatter but body is sparse or generic.
- 0.25: SKILL.md exists but lacks proper frontmatter or is mostly empty.
- 0.0: SKILL.md is missing entirely or contains no meaningful skill definition.

### Runtime Context Accuracy (Weight: 25%)
- 1.0: audit_report.md accurately reports PID (48291), runtime version (2026.2.6-3), entry point (main.py), working directory (/home/admin/.openclaw/workspace), and config file path (/home/admin/.openclaw/config/gateway.yaml), all matching the workspace data files (.openclaw/runtime/state.json, .openclaw/runtime/gateway.pid, .openclaw/config/gateway.yaml).
- 0.75: Report contains most runtime details correctly but is missing one element or uses slightly incorrect values.
- 0.5: Report has some runtime info but with errors or significant omissions (e.g., wrong PID or version).
- 0.25: Report mentions runtime context vaguely without specific values from the workspace files.
- 0.0: No audit_report.md produced, or runtime section is entirely absent or fabricated without reference to workspace files.

### Session Audit and Cleanup Recommendations (Weight: 25%)
- 1.0: Report lists all 8 .jsonl files in sessions/, identifies old ones by date (old_batch_01/02/03 from 2025, session_001/002 from early 2026), provides clear and reasonable cleanup recommendations with justification.
- 0.75: Report covers session files with counts and age analysis but cleanup recommendations are generic.
- 0.5: Report mentions session files but analysis is incomplete (e.g., missing file count or age breakdown).
- 0.25: Report briefly mentions sessions but provides no meaningful analysis.
- 0.0: No session audit section in the report, or deliverable is missing entirely.

### Evidence and Workspace Grounding (Weight: 25%)
- 1.0: All claims in the report and conversation are directly supported by data from workspace files (state.json, gateway.pid, gateway.yaml, sessions/ directory contents). No hallucinated facts.
- 0.75: Most claims are grounded in workspace data with minor unsupported details.
- 0.5: Some claims are grounded but others appear assumed or hallucinated.
- 0.25: Minimal grounding — agent appears to have guessed most information rather than reading workspace files.
- 0.0: Agent ignored required workspace inputs, hallucinated runtime details, or skipped producing the deliverable entirely.