#!/usr/bin/env python3
"""
OpenClaw Gateway - Main Entry Point
Starts the gateway daemon, loads config, and manages session lifecycle.
"""

import os
import sys
import json
import signal
import logging
import asyncio
from pathlib import Path
from datetime import datetime

VERSION = "2026.2.6-3"
PID_FILE = os.path.expanduser("~/.openclaw/runtime/gateway.pid")
CONFIG_PATH = os.path.expanduser("~/.openclaw/config/gateway.yaml")
LOG_DIR = os.path.expanduser("~/.openclaw/logs")
SESSION_DIR = os.path.join(os.path.dirname(__file__), "sessions")

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    handlers=[
        logging.FileHandler(os.path.join(LOG_DIR, "gateway.log")),
        logging.StreamHandler(sys.stdout),
    ],
)
logger = logging.getLogger("openclaw.gateway")


def write_pid():
    """Write current PID to file for process management."""
    os.makedirs(os.path.dirname(PID_FILE), exist_ok=True)
    with open(PID_FILE, "w") as f:
        f.write(str(os.getpid()))
    logger.info(f"PID {os.getpid()} written to {PID_FILE}")


def load_config():
    """Load gateway configuration from YAML."""
    try:
        import yaml
        with open(CONFIG_PATH) as f:
            return yaml.safe_load(f)
    except Exception as e:
        logger.warning(f"Failed to load config: {e}, using defaults")
        return {
            "gateway": {"bind": "127.0.0.1:3457", "heartbeat_interval": 1800},
            "sessions": {"max_concurrent": 10, "cleanup_after_hours": 72},
            "model": {"default": "claude-opus-4-6-20260205"},
        }


def cleanup_sessions(config):
    """Purge old session files based on retention policy."""
    max_age_hours = config.get("sessions", {}).get("cleanup_after_hours", 72)
    cutoff = datetime.now().timestamp() - (max_age_hours * 3600)
    cleaned = 0
    for f in Path(SESSION_DIR).glob("*.jsonl"):
        if f.stat().st_mtime < cutoff:
            f.unlink()
            cleaned += 1
    if cleaned:
        logger.info(f"Cleaned up {cleaned} expired session files")


async def heartbeat_loop(config):
    """Periodic heartbeat check."""
    interval = config.get("gateway", {}).get("heartbeat_interval", 1800)
    while True:
        await asyncio.sleep(interval)
        logger.debug("Heartbeat tick")


async def main():
    logger.info(f"OpenClaw Gateway v{VERSION} starting...")
    config = load_config()
    write_pid()

    def handle_sigusr1(signum, frame):
        logger.info("Received SIGUSR1 - reloading config")
        nonlocal config
        config = load_config()

    signal.signal(signal.SIGUSR1, handle_sigusr1)

    bind = config.get("gateway", {}).get("bind", "127.0.0.1:3457")
    logger.info(f"Gateway listening on {bind}")

    await heartbeat_loop(config)


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("Gateway shutting down gracefully")
    finally:
        if os.path.exists(PID_FILE):
            os.unlink(PID_FILE)
