#!/bin/bash
# OpenClaw Daemon Control Script
# Usage: ./daemon.sh {start|stop|restart|status}

WORKSPACE="/home/admin/.openclaw/workspace"
PID_FILE="/home/admin/.openclaw/runtime/gateway.pid"
MAIN_SCRIPT="$WORKSPACE/main.py"
LOG_DIR="/home/admin/.openclaw/logs"

case "$1" in
    start)
        if [ -f "$PID_FILE" ]; then
            PID=$(cat "$PID_FILE")
            if kill -0 "$PID" 2>/dev/null; then
                echo "Gateway already running (PID $PID)"
                exit 1
            fi
        fi
        echo "Starting OpenClaw Gateway..."
        cd "$WORKSPACE"
        nohup python3 "$MAIN_SCRIPT" >> "$LOG_DIR/gateway.log" 2>&1 &
        echo $! > "$PID_FILE"
        echo "Gateway started (PID $!)"
        ;;
    stop)
        if [ -f "$PID_FILE" ]; then
            PID=$(cat "$PID_FILE")
            echo "Stopping Gateway (PID $PID)..."
            kill "$PID" 2>/dev/null
            rm -f "$PID_FILE"
            echo "Gateway stopped"
        else
            echo "No PID file found"
        fi
        ;;
    restart)
        $0 stop
        sleep 2
        $0 start
        ;;
    status)
        if [ -f "$PID_FILE" ]; then
            PID=$(cat "$PID_FILE")
            if kill -0 "$PID" 2>/dev/null; then
                echo "Gateway running (PID $PID)"
                UPTIME=$(ps -p "$PID" -o etime= 2>/dev/null)
                echo "Uptime: $UPTIME"
            else
                echo "PID file exists but process not running"
            fi
        else
            echo "Gateway not running"
        fi
        ;;
    *)
        echo "Usage: $0 {start|stop|restart|status}"
        exit 1
        ;;
esac
