| 序号 | 修改项 | 修改原因 |
|------|--------|----------|
| 1 | 将 `workspace_files` 中所有 `path:` 字段改写为 `dest:` 字段 | 规范明确禁止使用旧字段 `path:`，应使用 `dest:` 表示 workspace 内路径 |
| 2 | 删除 `workspace_files` 中原有的 `content:` 内联文件条目（session_001～005、old_batch_01～03、main.py、config.yaml、`.openclaw/runtime.json`），改为指向 Assets 目录中的真实文件 | Assets 目录中已存在真实的、内容更丰富的文件（如 `main.py` 内容完全不同，`runtime.json` 对应实为 `state.json`）；内联 content 与 Assets 实际文件产生严重冲突，应以 Assets 为准 |
| 3 | 新增 `workspace_files` 条目以覆盖 Assets 中实际存在但未被列出的文件：`.openclaw/config/gateway.yaml`、`.openclaw/logs/gateway-2026-02-09.log`、`.openclaw/logs/gateway.log`、`.openclaw/runtime/gateway.pid`、`.openclaw/runtime/state.json`、`scripts/daemon.sh` | Assets 目录中存在这些文件，但原 `workspace_files` 完全未列出，导致 Agent 无法感知并使用它们 |
| 4 | 将 `workspace_files` 中原 `.openclaw/runtime.json`（content 内联）改为指向 Assets 的 `.openclaw/runtime/state.json` | 原任务文件中写的是 `.openclaw/runtime.json`，但 Assets 实际文件为 `.openclaw/runtime/state.json`，路径不一致；两者内容也不同（PID、version 等字段值均有差异），需统一到 Assets 真实文件 |
| 5 | 修正 Expected Behavior 第 2 步中的 PID 和版本号 | 原文写 PID 为 707/719、version 为 2026.3.13，但 Assets 中 `.openclaw/runtime/state.json` 显示 PID 为 48291，version 为 `2026.2.6-3`；`config.yaml`（Assets）中 version 为 `2026.3.13` 但属于配置文件字段，与运行时 state 不同。Expected Behavior 应以 Assets 真实文件为准，区分 config 版本与运行时版本 |
| 6 | 修正 Expected Behavior 第 3 步中 .jsonl 文件总数 | 原 `workspace_files` 内联定义了 8 个 `.jsonl` 文件，但经整理后任务实际交付的 sessions 文件仍为 8 个（session_001～005 + old_batch_01～03），计数本身无误，保持 8 个；但需说明 Agent 应依据实际 workspace 内容计数，不硬编码 |
| 7 | 修正 `grade()` 中 `skill_path` 的检查路径，从 workspace 根下的 `SKILL.md` 改为 `skills/runtime-audit/SKILL.md` | 维度 A 规范要求技能文件放在 `skills/<skill名>/SKILL.md`，而原 `grade()` 直接检查 workspace 根下的 `SKILL.md`，与规范不符 |
| 8 | 修正 `grade()` 中对运行时信息的核查关键词，将 PID `"707"` 和 `"719"` 改为 `"48291"`，将版本号 `"2026.3.13"` 改为 `"2026.2.6-3"`（运行时版本），并新增对 `state.json` 中字段的检查 | 原 grade() 硬编码了已被修正的 PID/版本，应与 Assets 中 `state.json` 真实数据一致 |
| 9 | 修正 LLM Judge Rubric "Runtime Context Accuracy" 维度中对 PID/version 的描述，与 Assets 真实数据保持一致 | 同上，原文写 `PIDs (707, 719)`、`version (2026.3.13)`，应改为 PID `48291`（来自 `state.json`/`gateway.pid`）、runtime version `2026.2.6-3` |
| 10 | 在 Expected Behavior 中补充说明 SKILL.md 应放置于 `skills/runtime-audit/SKILL.md` 路径 | 原 Expected Behavior 只说"in the workspace root"，与维度 A skill 路径规范冲突，需明确路径 |
| 11 | 修正 Expected Behavior，注明 Agent 还应利用 `scripts/daemon.sh` 了解启停方式，以及从 `.openclaw/logs/` 获取运行状态佐证 | Assets 中存在这些文件但 Expected Behavior 完全未提及，导致评估不完整 |
| 12 | 将 `workspace_files` 中 sessions 相关文件补充 `source` + `dest` 映射（content 内联方式保留用于 session jsonl 文件，因 Assets 中无对应文件） | Assets 目录中未见 sessions/ 下的任何 .jsonl 文件，因此 session 文件仍需内联 content 方式提供；其余 Assets 文件则用 dest 引用 |
| 13 | 删除 `workspace_files` 中内联的 `config.yaml`（旧 content），改为引用 Assets 中的 `.openclaw/config/gateway.yaml` | 原内联 config.yaml 放在 workspace 根，但 Assets 实际文件为 `.openclaw/config/gateway.yaml`，两份 config 内容也不同，需统一 |
| 14 | `grading_weights: {automated: 0.4, llm_judge: 0.6}` 之和为 1.0，无需修改；LLM Rubric 四个维度各 25%，之和为 100%，无需修改 | 验证通过，无修改 |