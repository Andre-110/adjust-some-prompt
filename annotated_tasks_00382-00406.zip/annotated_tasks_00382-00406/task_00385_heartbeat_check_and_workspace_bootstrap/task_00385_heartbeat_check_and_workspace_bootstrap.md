---
id: task_00385_heartbeat_check_and_workspace_bootstrap
name: Heartbeat Check and Workspace Bootstrap
category: Workflow and Agent Orchestration
subcategory: Workflow and Task Scheduling
difficulty: medium
grading_type: hybrid
grading_weights: {automated: 0.4, llm_judge: 0.6}
timeout_seconds: 600
input_modality: text-only
external_dependency: none
workspace_files:
  - source: config/gateway.yaml
    dest: config/gateway.yaml
  - source: scripts/gold_price_config.json
    dest: scripts/gold_price_config.json
  - source: scripts/gold_price_monitor.js
    dest: scripts/gold_price_monitor.js
  - source: data/gold/gold_price_2026-02-09T04-00-00-000Z.json
    dest: data/gold/gold_price_2026-02-09T04-00-00-000Z.json
  - source: data/gold/gold_price_2026-02-09T04-30-00-000Z.json
    dest: data/gold/gold_price_2026-02-09T04-30-00-000Z.json
  - source: data/gold/gold_price_2026-02-09T05-00-00-000Z.json
    dest: data/gold/gold_price_2026-02-09T05-00-00-000Z.json
  - source: data/gold/gold_price_2026-02-09T05-30-00-000Z.json
    dest: data/gold/gold_price_2026-02-09T05-30-00-000Z.json
  - source: data/gold/gold_price_2026-02-09T06-00-00-000Z.json
    dest: data/gold/gold_price_2026-02-09T06-00-00-000Z.json
  - source: data/gold/gold_price_2026-02-09T06-30-00-000Z.json
    dest: data/gold/gold_price_2026-02-09T06-30-00-000Z.json
  - source: data/gold/gold_price_2026-02-09T07-00-00-000Z.json
    dest: data/gold/gold_price_2026-02-09T07-00-00-000Z.json
  - source: data/gold/gold_price_2026-02-09T07-30-00-000Z.json
    dest: data/gold/gold_price_2026-02-09T07-30-00-000Z.json
  - source: data/gold/gold_price_2026-02-09T08-00-00-000Z.json
    dest: data/gold/gold_price_2026-02-09T08-00-00-000Z.json
  - source: data/gold/gold_price_2026-02-09T08-30-00-000Z.json
    dest: data/gold/gold_price_2026-02-09T08-30-00-000Z.json
  - source: data/gold/gold_price_2026-02-09T09-00-00-000Z.json
    dest: data/gold/gold_price_2026-02-09T09-00-00-000Z.json
  - source: data/gold/gold_price_2026-02-09T09-30-00-000Z.json
    dest: data/gold/gold_price_2026-02-09T09-30-00-000Z.json
  - source: data/gold/gold_price_2026-02-09T10-00-00-000Z.json
    dest: data/gold/gold_price_2026-02-09T10-00-00-000Z.json
  - source: data/gold/gold_price_2026-02-09T10-30-00-000Z.json
    dest: data/gold/gold_price_2026-02-09T10-30-00-000Z.json
  - source: data/gold/gold_price_2026-02-09T11-00-00-000Z.json
    dest: data/gold/gold_price_2026-02-09T11-00-00-000Z.json
  - source: data/gold/gold_price_2026-02-09T11-30-00-000Z.json
    dest: data/gold/gold_price_2026-02-09T11-30-00-000Z.json
  - source: data/gold/gold_price_tavily_anomaly.json
    dest: data/gold/gold_price_tavily_anomaly.json
  - source: data/news/news_2026-02-09T20-00-43-542.json
    dest: data/news/news_2026-02-09T20-00-43-542.json
  - source: data/news/news_2026-02-10T02-01-07-620.json
    dest: data/news/news_2026-02-10T02-01-07-620.json
skill_creation: false
---

## Prompt

I have an automated system alert for "Gold Price Abnormal Volatility Detection - Run Automation Scripts". I need you to check if there's a HEARTBEAT.md file in the workspace. If it exists, read it and follow its instructions strictly — don't infer or repeat old tasks. If it doesn't exist, create a proper workspace bootstrap with the following files:

1. **HEARTBEAT.md** — A heartbeat configuration file that defines scheduled monitoring tasks: gold price checks every 30 minutes, Gmail email checks every 30 minutes, and news updates every hour. Include a note about the known Tavily API false positive (+77% parsing error).

2. **IDENTITY.md** — A brief identity document describing this as an automated monitoring agent for gold prices, email, and news.

3. **AGENTS.md** — Document the agent capabilities: gold price monitoring, email checking, news fetching, and security verification.

4. **BOOTSTRAP.md** — A bootstrap guide explaining how the workspace is set up, referencing the scripts in `scripts/` and configuration files in `config/`.

5. Initialize a git repository in the workspace for version control.

Also create a `.openclaw/workspace-state.json` file that tracks the current state: gold price stable in $4,950-$4,980 range, volatility at 0.25% (low risk), OpenClaw bound to loopback with token auth, and all systems operational.

If HEARTBEAT.md already exists and has no new tasks, just reply with "HEARTBEAT_OK".

## Expected Behavior

The agent should:

1. Check whether HEARTBEAT.md exists in the workspace.
2. Since it does not exist initially, create the full workspace bootstrap including:
   - **HEARTBEAT.md** with scheduled task definitions (gold monitoring every 30 min, email checks every 30 min, news hourly) and a note about the Tavily false positive (+77% parsing error is a known data quality issue, not a real price spike).
   - **IDENTITY.md** describing the monitoring agent's purpose.
   - **AGENTS.md** documenting agent capabilities.
   - **BOOTSTRAP.md** referencing the workspace `scripts/` and `config/` directories for monitoring setup.
3. Initialize a git repository (`.git/` directory with HEAD, config, etc.).
4. Create `.openclaw/workspace-state.json` with current system state including gold price range ($4,950–$4,980), volatility (0.25%, low risk), security config (loopback binding, token auth), and operational status.
5. After setup is complete, respond with "HEARTBEAT_OK" to indicate the workspace is ready and no immediate action is needed.

## Grading Criteria

- [ ] HEARTBEAT.md exists and contains scheduled task definitions
- [ ] IDENTITY.md exists with agent identity description
- [ ] AGENTS.md exists with capability documentation
- [ ] BOOTSTRAP.md exists with setup instructions
- [ ] Git repository initialized (.git/HEAD exists)
- [ ] .openclaw/workspace-state.json exists with proper state tracking
- [ ] workspace-state.json contains gold price and security information
- [ ] Agent responds with HEARTBEAT_OK

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    import os
    import json

    scores = {
        "heartbeat_md_exists": 0.0,
        "identity_and_agents_docs": 0.0,
        "git_initialized": 0.0,
        "workspace_state_json": 0.0,
        "heartbeat_ok_response": 0.0
    }

    # Early exit: if HEARTBEAT.md does not exist, return all zeros
    heartbeat_path = os.path.join(workspace_path, "HEARTBEAT.md")
    if not os.path.isfile(heartbeat_path):
        return scores

    # 1. Check HEARTBEAT.md exists and has meaningful content
    try:
        content = open(heartbeat_path, "r", encoding="utf-8").read()
        if len(content) > 20:
            scores["heartbeat_md_exists"] = 0.5
            lower = content.lower()
            has_gold = any(kw in lower for kw in ["gold", "price", "monitor"])
            has_email = any(kw in lower for kw in ["email", "gmail", "mail"])
            has_interval = any(kw in lower for kw in ["30", "minute", "hour", "interval", "schedule"])
            if has_gold and has_email:
                scores["heartbeat_md_exists"] = 0.75
            if has_gold and has_email and has_interval:
                scores["heartbeat_md_exists"] = 1.0
    except Exception:
        pass

    # 2. Check IDENTITY.md, AGENTS.md, and BOOTSTRAP.md exist
    identity_path = os.path.join(workspace_path, "IDENTITY.md")
    agents_path = os.path.join(workspace_path, "AGENTS.md")
    bootstrap_path = os.path.join(workspace_path, "BOOTSTRAP.md")

    doc_count = 0
    for p in [identity_path, agents_path, bootstrap_path]:
        if os.path.isfile(p):
            try:
                c = open(p, "r", encoding="utf-8").read()
                if len(c) > 10:
                    doc_count += 1
            except Exception:
                pass

    if doc_count >= 3:
        scores["identity_and_agents_docs"] = 1.0
    elif doc_count == 2:
        scores["identity_and_agents_docs"] = 0.7
    elif doc_count == 1:
        scores["identity_and_agents_docs"] = 0.4
    else:
        scores["identity_and_agents_docs"] = 0.0

    # 3. Check git initialized
    git_head = os.path.join(workspace_path, ".git", "HEAD")
    git_config = os.path.join(workspace_path, ".git", "config")
    if os.path.isfile(git_head):
        scores["git_initialized"] = 0.5
        if os.path.isfile(git_config):
            scores["git_initialized"] = 1.0

    # 4. Check .openclaw/workspace-state.json
    state_path = os.path.join(workspace_path, ".openclaw", "workspace-state.json")
    if os.path.isfile(state_path):
        try:
            content = open(state_path, "r", encoding="utf-8").read()
            data = json.loads(content)
            scores["workspace_state_json"] = 0.25
            state_str = json.dumps(data).lower()
            has_gold_info = any(kw in state_str for kw in ["gold", "price", "4950", "4980", "volatil"])
            has_security = any(kw in state_str for kw in ["loopback", "token", "auth", "security", "bind"])
            if has_gold_info:
                scores["workspace_state_json"] = 0.5
            if has_gold_info and has_security:
                scores["workspace_state_json"] = 1.0
        except (json.JSONDecodeError, Exception):
            scores["workspace_state_json"] = 0.1

    # 5. Check transcript for HEARTBEAT_OK response
    for event in transcript:
        if event.get("type") != "message":
            continue
        msg = event.get("message", {})
        if msg.get("role") == "assistant":
            text = msg.get("content", "")
            if isinstance(text, str) and "HEARTBEAT_OK" in text.upper().replace(" ", "_"):
                scores["heartbeat_ok_response"] = 1.0
                break
            elif isinstance(text, list):
                for block in text:
                    if isinstance(block, dict):
                        t = block.get("text", "")
                        if "HEARTBEAT_OK" in t.upper().replace(" ", "_"):
                            scores["heartbeat_ok_response"] = 1.0
                            break

    return scores
```

## LLM Judge Rubric

### Workspace Bootstrap Completeness (Weight: 30%)
- 1.0: All required files created (HEARTBEAT.md, IDENTITY.md, AGENTS.md, BOOTSTRAP.md, workspace-state.json) with meaningful, relevant content
- 0.75: Most files created (4 out of 5) with good content
- 0.5: At least 3 key files created with reasonable content
- 0.25: Only 1-2 files created or content is minimal/placeholder
- 0.0: No workspace files created, or files are empty/irrelevant

### HEARTBEAT.md Quality and Task Definitions (Weight: 25%)
- 1.0: HEARTBEAT.md clearly defines all three scheduled tasks (gold price every 30 min, email every 30 min, news hourly) with the Tavily false positive note and proper formatting
- 0.75: All three tasks defined but missing the Tavily note or minor formatting issues
- 0.5: Two of three tasks defined with reasonable detail
- 0.25: Only one task defined or very vague descriptions
- 0.0: HEARTBEAT.md missing, empty, or contains no task scheduling information

### Evidence and Workspace Grounding (Weight: 25%)
- 1.0: All outputs reference actual workspace paths (`scripts/`, `config/`), gold price data ($4,950-$4,980 range), security settings (loopback, token auth), and known issues (Tavily +77% false positive) consistent with the provided context
- 0.75: Most references are grounded in the provided context with minor omissions
- 0.5: Some references to actual workspace data but significant context is missing or hallucinated
- 0.25: Minimal grounding; mostly generic content not tied to the specific workspace setup
- 0.0: No grounding in workspace data; content is hallucinated, ignores required inputs, or deliverables are missing entirely

### Git Initialization and State Management (Weight: 20%)
- 1.0: Git repository properly initialized and workspace-state.json contains accurate current state (gold price range, volatility percentage, security config, operational status)
- 0.75: Git initialized and state file exists but missing some state fields
- 0.5: Either git initialized or state file created, but not both
- 0.25: Partial attempt at one of the two
- 0.0: Neither git repository nor state file created