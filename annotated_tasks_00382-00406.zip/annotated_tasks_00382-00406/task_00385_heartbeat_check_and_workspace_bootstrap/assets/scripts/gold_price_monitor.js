/**
 * Gold Price Monitor
 * Fetches current gold price from multiple sources and checks for anomalies.
 * Run every 30 minutes via OpenClaw cron or heartbeat.
 * 
 * Usage: node gold_price_monitor.js
 * Config: ../config/gold_price_config.json
 */

const fs = require('fs');
const path = require('path');
const https = require('https');

const CONFIG_PATH = path.join(__dirname, '..', 'config', 'gold_price_config.json');
const DATA_DIR = path.join(__dirname, '..', 'data', 'gold');

function loadConfig() {
  const raw = fs.readFileSync(CONFIG_PATH, 'utf8');
  return JSON.parse(raw);
}

async function fetchKitcoPrice() {
  // Primary source: Kitco live gold price
  return new Promise((resolve, reject) => {
    const options = {
      hostname: 'www.kitco.com',
      path: '/gold-price-today-usa/',
      method: 'GET',
      headers: { 'User-Agent': 'OpenClaw-GoldMonitor/1.0' }
    };
    
    const req = https.request(options, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try {
          // Parse gold price from page content
          const priceMatch = data.match(/\$[\d,]+\.\d{2}/);
          if (priceMatch) {
            const price = parseFloat(priceMatch[0].replace(/[$,]/g, ''));
            resolve({ source: 'kitco', price, raw: priceMatch[0] });
          } else {
            reject(new Error('Could not parse Kitco price'));
          }
        } catch (e) {
          reject(e);
        }
      });
    });
    req.on('error', reject);
    req.end();
  });
}

async function fetchTavilyPrice(apiKey) {
  // Secondary source: Tavily search API
  // WARNING: Known issue - Tavily sometimes returns concatenated price strings
  // resulting in false +77% readings. Always cross-reference with primary source.
  return new Promise((resolve, reject) => {
    const postData = JSON.stringify({
      api_key: apiKey,
      query: 'current gold price per ounce USD',
      search_depth: 'basic',
      include_answer: true
    });

    const options = {
      hostname: 'api.tavily.com',
      path: '/search',
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(postData)
      }
    };

    const req = https.request(options, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try {
          const result = JSON.parse(data);
          const answer = result.answer || '';
          const priceMatch = answer.match(/\$?([\d,]+\.?\d*)/);
          if (priceMatch) {
            const price = parseFloat(priceMatch[1].replace(/,/g, ''));
            resolve({ source: 'tavily', price, raw: answer });
          } else {
            reject(new Error('Could not parse Tavily price'));
          }
        } catch (e) {
          reject(e);
        }
      });
    });
    req.on('error', reject);
    req.write(postData);
    req.end();
  });
}

function checkAnomaly(currentPrice, config) {
  const threshold = config.alertThreshold || 5.0;
  const baselinePrice = config.baselinePrice || 4965;
  const changePct = Math.abs((currentPrice - baselinePrice) / baselinePrice * 100);
  
  return {
    isAnomaly: changePct > threshold,
    changePercent: changePct,
    threshold,
    baselinePrice,
    currentPrice
  };
}

function saveDataPoint(data) {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
  
  const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
  const filename = `gold_price_${timestamp}.json`;
  const filepath = path.join(DATA_DIR, filename);
  
  fs.writeFileSync(filepath, JSON.stringify(data, null, 2));
  console.log(`Saved: ${filepath}`);
  return filepath;
}

async function main() {
  const config = loadConfig();
  console.log(`[${new Date().toISOString()}] Gold Price Monitor starting...`);
  console.log(`Alert threshold: ${config.alertThreshold}%`);
  
  try {
    const kitcoResult = await fetchKitcoPrice();
    console.log(`Kitco price: $${kitcoResult.price}`);
    
    const anomaly = checkAnomaly(kitcoResult.price, config);
    
    const dataPoint = {
      timestamp: new Date().toISOString(),
      source: kitcoResult.source,
      metal: 'gold',
      unit: 'oz',
      currency: 'USD',
      price: kitcoResult.price,
      changePercent: anomaly.changePercent,
      alertTriggered: anomaly.isAnomaly,
      volatilityIndex: anomaly.changePercent
    };
    
    saveDataPoint(dataPoint);
    
    if (anomaly.isAnomaly) {
      console.log(`⚠️ ALERT: Gold price anomaly detected! Change: ${anomaly.changePercent.toFixed(2)}%`);
      console.log(`Current: $${anomaly.currentPrice} | Baseline: $${anomaly.baselinePrice}`);
    } else {
      console.log(`✅ Gold price within normal range. Change: ${anomaly.changePercent.toFixed(2)}%`);
    }
  } catch (err) {
    console.error(`Error fetching gold price: ${err.message}`);
  }
}

main().catch(console.error);
