| 序号 | 修改项 | 修改原因 |
|------|--------|----------|
| 1 | 删除 `workspace_files` 中所有使用 `path:` 字段的条目，替换为符合规范的 `dest:` 写法 | 原始 YAML 使用了被明确禁止的 `path:` 字段，且路径为 Windows 绝对路径（`E:/OpenClaw/...`），不符合「包内 source → workspace dest」映射规范 |
| 2 | 将 `workspace_files` 中原三条内联 `content:` 条目替换为指向 Assets 目录真实文件的 `dest:` 条目，并补充缺失文件映射 | Assets 目录中已存在完整的实体文件（config.yaml、scripts/gold_price_monitor.js、scripts/gold_price_config.json 等），`workspace_files` 应映射这些文件而非用 `content:` 内联简化版占位内容；原内联脚本内容（`// Placeholder`）与 Assets 中真实的完整 JS 文件不一致 |
| 3 | 补充 Assets 目录下所有数据文件的 `workspace_files` 映射条目（`data/gold/*.json`、`data/news/*.json`、`data/gold/gold_price_tavily_anomaly.json`） | 原 `workspace_files` 完全未列出 `data/` 子目录下的文件，导致 Agent 无法访问黄金价格历史数据和新闻数据，而这些文件对题目完成至关重要 |
| 4 | 删除 `workspace_files` 中 `path: "E:/openclaw-gmail-setup/check_emails_fixed.js"` 条目 | 该路径为 Windows 本机绝对路径，指向题目 Assets 目录之外的文件，不存在对应 Asset 实体文件，且 Prompt 中未直接要求 Agent 读取此文件；在 HEARTBEAT.md 中提及 Gmail 检查任务即可，无需将本机路径文件注入 workspace |
| 5 | 修改 Prompt 中对"E drive scripts and configuration files"的引用方式 | Prompt 中的 `BOOTSTRAP.md` 要求"referencing the E drive scripts"，这是 Windows 本机绝对路径，不应出现在 workspace 规范任务中；修改为引用 workspace 内的 `scripts/` 和 `config/` 相对路径 |
| 6 | 修改 Expected Behavior 第 2 步中"BOOTSTRAP.md referencing E drive scripts"的表述 | 与 Prompt 修改对应，统一为 workspace 相对路径引用，避免与实际 Assets 文件路径不一致 |
| 7 | 删除 Expected Behavior 第 2 步中"**SOUL.md**, **TOOLS.md**, **USER.md** or similar supporting documents"的要求 | Grading Criteria 和 `grade()` 函数均不检查这三个文件，且 Prompt 中也未要求创建它们，此处描述超出题目实际考查范围，会造成期望行为与评分标准不一致 |
| 8 | 修正 `data/gold/gold_price_2026-02-09T04-30-00-000Z.json` 中 `changePercent` 字段值 | 该时间点 `change: -8.33`，价格从约 4965 基线计算，变化百分比应为约 `-0.168%`，但文件中写的是 `-0.0257`（即 `-0.0257%`），而 `volatilityIndex` 为 `2.57`，两者数量级明显不一致（volatilityIndex 各处均为 changePercent 的绝对值×100 或直接等于 |changePercent| 的百分数形式）；修正 `changePercent` 为 `-0.257`（与 `volatilityIndex: 2.57` 一致，即表示 0.257%） |
| 9 | 修正 `data/gold/gold_price_2026-02-09T09-00-00-000Z.json` 中 `changePercent` 字段值 | `change: 12.69`，`volatilityIndex: 2.69`，但 `changePercent: 0.0269`——与其他条目的规律（`volatilityIndex` = `|changePercent| × 100`，即 `changePercent` 以小数百分比表示）不符；应为 `0.269`（与 `volatilityIndex: 2.69` 一致） |
| 10 | 修正 `data/gold/gold_price_2026-02-09T09-30-00-000Z.json` 中 `changePercent` 与 `change` 符号不一致问题 | `change: 6.61`（正值，价格上涨），但 `changePercent: -0.0061`（负值），方向矛盾；且 `volatilityIndex: 0.61`，按规律应为 `changePercent: 0.061`（正值，与 `volatilityIndex` 一致） |
| 11 | 修正 `data/gold/gold_price_2026-02-09T06-30-00-000Z.json` 中 `change` 与 `changePercent` 符号不一致问题 | `change: -6.27`（负值），但 `changePercent: 0.1839`（正值），方向矛盾；按 `volatilityIndex: 18.39` 规律，`changePercent` 应为 `-0.1839` |
| 12 | 在 `grade()` 函数开头添加空白零分前置检查 | 原函数在 workspace 完全为空（无任何文件）时仍会逐项检查并返回全 0，但缺少显式的「主输出不存在时直接返回全 0」保护；补充 `HEARTBEAT.md` 不存在时的早退逻辑，符合维度 D 规范 |
| 13 | 将 `grading_weights` 中 `automated: 0.4, llm_judge: 0.6` 确认为正确（之和为 1.0），无需修改 | 审校确认，权重之和为 1.0，符合维度 E 要求 |
| 14 | 将难度标记 `difficulty: medium` 保留，确认与题目复杂度匹配 | 题目要求创建多个文件、初始化 git、写 JSON 状态文件，属于多步骤工作流题，medium 难度合适 |
