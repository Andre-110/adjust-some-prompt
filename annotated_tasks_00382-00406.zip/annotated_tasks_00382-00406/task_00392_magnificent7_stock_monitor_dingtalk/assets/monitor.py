#!/usr/bin/env python3
"""
Magnificent 7 Stock Price Monitor
==================================
Monitors AAPL, MSFT, GOOGL, AMZN, NVDA, META, TSLA for anomalous price
movements (±3% or more) and sends DingTalk alerts.

Usage:
    python monitor.py [--dry-run] [--verbose]

Dependencies:
    pip install yfinance requests

TODO:
    - Implement fetch_current_prices() using yfinance
    - Implement calculate_change() with previous close comparison
    - Implement send_dingtalk_alert() with signed webhook
    - Add error handling and retry logic
    - Add market hours check
"""

import json
import sys
import os
import time
import hmac
import hashlib
import base64
import urllib.parse
from datetime import datetime, timezone
from pathlib import Path

# Paths
CONFIG_DIR = Path(__file__).parent / "config"
DATA_DIR = Path(__file__).parent / "data"
STOCKS_CONFIG = CONFIG_DIR / "stocks.json"
DINGTALK_CONFIG = CONFIG_DIR / "dingtalk.json"
PRICE_HISTORY = DATA_DIR / "price_history.json"


def load_config(path):
    """Load a JSON config file."""
    with open(path, "r") as f:
        return json.load(f)


def fetch_current_prices(symbols):
    """
    Fetch current stock prices from Yahoo Finance.

    Args:
        symbols: List of ticker symbols

    Returns:
        dict: {symbol: {"price": float, "prev_close": float, "change_pct": float}}

    TODO: Implement using yfinance library
        import yfinance as yf
        tickers = yf.Tickers(" ".join(symbols))
        ...
    """
    # SKELETON - needs implementation
    raise NotImplementedError("fetch_current_prices not yet implemented")


def calculate_change(current_price, previous_close):
    """
    Calculate percentage change from previous close.

    Args:
        current_price: Current price
        previous_close: Previous closing price

    Returns:
        float: Percentage change (e.g., 3.5 for +3.5%)
    """
    # SKELETON - needs implementation
    if previous_close == 0:
        return 0.0
    return ((current_price - previous_close) / previous_close) * 100


def detect_anomalies(price_data, threshold_pct=3.0):
    """
    Detect stocks with price changes exceeding the threshold.

    Args:
        price_data: Dict of {symbol: {price, prev_close, change_pct}}
        threshold_pct: Absolute percentage threshold (default 3.0)

    Returns:
        list: List of anomaly dicts
    """
    anomalies = []
    for symbol, data in price_data.items():
        if abs(data.get("change_pct", 0)) >= threshold_pct:
            anomalies.append({
                "symbol": symbol,
                "price": data["price"],
                "prev_close": data["prev_close"],
                "change_pct": data["change_pct"],
                "direction": "UP" if data["change_pct"] > 0 else "DOWN",
                "detected_at": datetime.now(timezone.utc).isoformat()
            })
    return anomalies


def generate_dingtalk_sign(secret):
    """
    Generate DingTalk webhook signature.

    Args:
        secret: The signing secret from DingTalk bot config

    Returns:
        tuple: (timestamp_ms, sign)
    """
    timestamp = str(round(time.time() * 1000))
    string_to_sign = f"{timestamp}\n{secret}"
    hmac_code = hmac.new(
        secret.encode("utf-8"),
        string_to_sign.encode("utf-8"),
        digestmod=hashlib.sha256
    ).digest()
    sign = urllib.parse.quote_plus(base64.b64encode(hmac_code))
    return timestamp, sign


def format_alert_message(anomalies):
    """
    Format anomaly data into a DingTalk markdown message.

    Args:
        anomalies: List of anomaly dicts

    Returns:
        dict: DingTalk message payload
    """
    # SKELETON - needs implementation
    # Should return {"msgtype": "markdown", "markdown": {"title": ..., "text": ...}}
    raise NotImplementedError("format_alert_message not yet implemented")


def send_dingtalk_alert(message_payload, config):
    """
    Send alert message via DingTalk webhook.

    Args:
        message_payload: DingTalk message dict
        config: DingTalk config with webhook_url, secret, etc.

    TODO: Implement HTTP POST with signature
        import requests
        url = config["webhook_url"]
        if config.get("sign_enabled"):
            ts, sign = generate_dingtalk_sign(config["secret"])
            url += f"&timestamp={ts}&sign={sign}"
        resp = requests.post(url, json=message_payload, timeout=10)
        ...
    """
    # SKELETON - needs implementation
    raise NotImplementedError("send_dingtalk_alert not yet implemented")


def save_price_snapshot(price_data):
    """Save current price data to history file for trend tracking."""
    DATA_DIR.mkdir(parents=True, exist_ok=True)

    history = []
    if PRICE_HISTORY.exists():
        with open(PRICE_HISTORY, "r") as f:
            history = json.load(f)

    snapshot = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "prices": price_data
    }
    history.append(snapshot)

    # Keep last 500 snapshots
    history = history[-500:]

    with open(PRICE_HISTORY, "w") as f:
        json.dump(history, f, indent=2)


def is_market_open():
    """
    Check if US stock market is currently open.

    TODO: Implement market hours check with holiday calendar
    """
    # SKELETON - needs implementation
    return True


def main():
    dry_run = "--dry-run" in sys.argv
    verbose = "--verbose" in sys.argv

    if verbose:
        print("[INFO] Loading configurations...")

    stocks_config = load_config(STOCKS_CONFIG)
    dingtalk_config = load_config(DINGTALK_CONFIG)

    symbols = [s["symbol"] for s in stocks_config["watchlist"]["magnificent_seven"]]
    threshold = stocks_config["watchlist"]["magnificent_seven"][0]["threshold_pct"]

    if verbose:
        print(f"[INFO] Monitoring: {', '.join(symbols)}")
        print(f"[INFO] Threshold: ±{threshold}%")

    # Check market hours
    if not is_market_open():
        if verbose:
            print("[INFO] Market is closed. Skipping check.")
        return

    # Fetch prices
    price_data = fetch_current_prices(symbols)

    # Save snapshot
    save_price_snapshot(price_data)

    # Detect anomalies
    anomalies = detect_anomalies(price_data, threshold)

    if anomalies:
        if verbose:
            for a in anomalies:
                print(f"[ALERT] {a['symbol']}: {a['change_pct']:+.2f}% (${a['price']:.2f})")

        message = format_alert_message(anomalies)

        if dry_run:
            print("[DRY RUN] Would send DingTalk alert:")
            print(json.dumps(message, indent=2, ensure_ascii=False))
        else:
            send_dingtalk_alert(message, dingtalk_config)
            if verbose:
                print("[INFO] DingTalk alert sent successfully.")
    else:
        if verbose:
            print("[INFO] No anomalies detected. All stocks within normal range.")


if __name__ == "__main__":
    main()
