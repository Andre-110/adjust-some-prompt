---
id: task_00392_magnificent7_stock_monitor_dingtalk
name: Magnificent 7 Stock Price Monitor with DingTalk Alert
category: Workflow and Agent Orchestration
subcategory: Integration and Data Flow
difficulty: hard
grading_type: hybrid
grading_weights: {automated: 0.4, llm_judge: 0.6}
timeout_seconds: 600
input_modality: text-only
external_dependency: none
workspace_files:
  - source: config/stocks.json
    dest: config/stocks.json
  - source: config/dingtalk.json
    dest: config/dingtalk.json
  - source: config/cron_schedule.yaml
    dest: config/cron_schedule.yaml
  - source: data/price_history.json
    dest: data/price_history.json
  - source: data/test_prices.json
    dest: data/test_prices.json
  - source: monitor.py
    dest: monitor.py
  - source: templates/dingtalk_alert.json
    dest: templates/dingtalk_alert.json
  - source: templates/dingtalk_daily_summary.json
    dest: templates/dingtalk_daily_summary.json
---

## Prompt

Hey, I need you to monitor the "Magnificent 7" US tech stocks — AAPL, MSFT, GOOGL, AMZN, NVDA, META, and TSLA. Check their current prices using Yahoo Finance (or any reliable source), detect any abnormal price movements of ±3% or more compared to the previous close, and generate a monitoring report. The stock list and threshold config are in `config/stocks.json` (tickers are under `watchlist.magnificent_seven[].symbol`, threshold under `watchlist.magnificent_seven[].threshold_pct`). If any stock has abnormal movement, try to send a DingTalk notification using the webhook config in `config/dingtalk.json`. If DingTalk isn't configured or sending fails, just save the alert report. Put the full monitoring report in `output/report.md` with a table of all 7 stocks and their status, and save any detected anomalies to `output/anomalies.json`. If real-time price data is unavailable, you may use the latest snapshot in `data/test_prices.json` or `data/price_history.json` as a fallback.

## Expected Behavior

The agent should:

1. Read the stock ticker list and threshold configuration from `config/stocks.json`. Note: tickers are stored under `watchlist.magnificent_seven` as an array of objects with fields `symbol`, `name`, and `threshold_pct` (all set to 3.0). The check interval and market hours are also defined in this file.
2. Fetch current or recent stock price data for all 7 Magnificent 7 tickers (AAPL, MSFT, GOOGL, AMZN, NVDA, META, TSLA) using Yahoo Finance API, web search, or another reliable data source. If real-time data is unavailable (e.g., market closed or API error), fall back to `data/test_prices.json` (single snapshot) or the most recent entry in `data/price_history.json`.
3. Compare each stock's current/latest price against its previous close to calculate the percentage change.
4. Detect any stocks with price movements exceeding the ±3% threshold.
5. Generate a monitoring report at `output/report.md` containing:
   - A header with the monitoring timestamp
   - A markdown table listing all 7 stocks with columns for ticker, current price, previous close, percentage change, and status (normal/abnormal)
   - A summary of any anomalies detected
6. Save detected anomalies (if any) to `output/anomalies.json` as a JSON array of objects with fields like ticker (or symbol), current_price (or price), prev_close, change_pct, and status (or direction).
7. Attempt to send a DingTalk notification using the config in `config/dingtalk.json` (which includes webhook_url, secret, sign_enabled, etc.). If sending fails or the webhook is not reachable, note that DingTalk notification was skipped and proceed gracefully. The alert message template is available at `templates/dingtalk_alert.json` for reference.
8. Include timestamp information in the report header.
9. **Fallback data & anomaly baseline**: If using `data/test_prices.json` (timestamp `2026-02-10T05:21:00Z`) as the data source, the expected anomalies are:
   - **NVDA**: change_pct = +4.2% (price $138.17, prev_close $132.60) → **ABNORMAL (UP)**
   - **TSLA**: change_pct = −3.5% (price $345.67, prev_close $358.20) → **ABNORMAL (DOWN)**
   - All other 5 tickers (AAPL, MSFT, GOOGL, AMZN, META) are within the ±3% threshold → **NORMAL**

   **Trap**: If using `data/price_history.json`, the agent must use the **latest snapshot** (last entry, timestamp `2026-02-10T05:21:00Z`) rather than an earlier or arbitrary entry. Earlier snapshots have different anomaly patterns (e.g., the snapshot at `2026-02-10T04:36:00Z` has NVDA +4.02% and TSLA −3.63% as anomalies, but these are not the most current data). Using a non-latest snapshot would produce incorrect anomaly detection results.

## Grading Criteria

- [ ] Agent reads config/stocks.json to get ticker list and threshold (correctly parsing `watchlist.magnificent_seven`)
- [ ] Agent fetches price data for all 7 Magnificent 7 stocks (via real-time API or fallback to workspace data files)
- [ ] output/report.md exists and contains a monitoring report with a markdown table
- [ ] Report table includes all 7 tickers (AAPL, MSFT, GOOGL, AMZN, NVDA, META, TSLA)
- [ ] output/anomalies.json exists and is valid JSON
- [ ] Anomalies file contains entries only for stocks exceeding the ±3% threshold (or is an empty array if none)
- [ ] Agent checks DingTalk config and handles missing/failed webhook gracefully
- [ ] Report includes timestamp information

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    import os
    import json
    import re
    from pathlib import Path

    scores = {
        "report_exists_and_structured": 0.0,
        "report_covers_all_tickers": 0.0,
        "anomalies_json_valid": 0.0,
        "config_read_and_threshold_used": 0.0,
        "dingtalk_handling": 0.0,
    }

    wp = Path(workspace_path)

    # 1. Check output/report.md exists and has table structure
    report_path = wp / "output" / "report.md"
    report_content = ""
    if report_path.exists():
        report_content = report_path.read_text(encoding="utf-8", errors="replace")
        # Check for markdown table (pipe characters) and some header
        has_table = "|" in report_content and "---" in report_content
        has_header = bool(re.search(r"(#|monitor|report|stock)", report_content, re.IGNORECASE))
        has_timestamp = bool(re.search(r"(202[0-9]|time|date|timestamp|\d{4}-\d{2}-\d{2}|\d{1,2}:\d{2})", report_content, re.IGNORECASE))
        if has_table and has_header:
            scores["report_exists_and_structured"] = 0.8
            if has_timestamp:
                scores["report_exists_and_structured"] = 1.0
        elif has_table or has_header:
            scores["report_exists_and_structured"] = 0.4

    # 2. Check report covers all 7 tickers
    tickers = ["AAPL", "MSFT", "GOOGL", "AMZN", "NVDA", "META", "TSLA"]
    if report_content:
        found_tickers = [t for t in tickers if t in report_content.upper()]
        scores["report_covers_all_tickers"] = len(found_tickers) / len(tickers)

    # 3. Check output/anomalies.json exists and is valid JSON
    anomalies_path = wp / "output" / "anomalies.json"
    if anomalies_path.exists():
        try:
            anomalies_text = anomalies_path.read_text(encoding="utf-8", errors="replace")
            anomalies_data = json.loads(anomalies_text)
            if isinstance(anomalies_data, list):
                scores["anomalies_json_valid"] = 0.6
                # Check structure of entries
                if len(anomalies_data) == 0:
                    # Empty array is valid if no anomalies
                    scores["anomalies_json_valid"] = 0.8
                else:
                    valid_entries = 0
                    for entry in anomalies_data:
                        if isinstance(entry, dict):
                            has_ticker = any(k in entry for k in ["ticker", "symbol"])
                            has_change = any(k in entry for k in ["change_pct", "change", "pct_change", "percent_change", "change_percent"])
                            if has_ticker and has_change:
                                valid_entries += 1
                    if valid_entries == len(anomalies_data) and valid_entries > 0:
                        scores["anomalies_json_valid"] = 1.0
                    elif valid_entries > 0:
                        scores["anomalies_json_valid"] = 0.7
            elif isinstance(anomalies_data, dict):
                scores["anomalies_json_valid"] = 0.4
        except (json.JSONDecodeError, Exception):
            scores["anomalies_json_valid"] = 0.1

    # 4. Check that config was read (look for evidence in transcript and workspace files)
    config_read = False
    threshold_mentioned = False

    # Check transcript for evidence of config reading
    for event in transcript:
        # Check all event types (messages, tool calls, tool results, etc.)
        content_str = json.dumps(event) if isinstance(event, dict) else str(event)
        if any(kw in content_str for kw in ["stocks.json", "watchlist", "magnificent_seven", "symbol"]):
            config_read = True
        if any(kw in content_str for kw in ["3%", "3.0", "threshold", "threshold_pct"]):
            threshold_mentioned = True

    # Also check if agent produced output grounded in workspace data
    # (if report references actual tickers from config, that's evidence of config read)
    if report_content:
        ticker_count = sum(1 for t in tickers if t in report_content.upper())
        if ticker_count >= 7:
            config_read = True  # Covered all tickers → likely read from config

    if config_read and threshold_mentioned:
        scores["config_read_and_threshold_used"] = 1.0
    elif config_read or threshold_mentioned:
        scores["config_read_and_threshold_used"] = 0.5

    # 5. Check DingTalk handling (graceful skip when not configured or fails)
    dingtalk_handled = False
    for event in transcript:
        content_str = json.dumps(event) if isinstance(event, dict) else str(event)
        if any(kw in content_str.lower() for kw in ["dingtalk", "ding talk", "webhook", "notification", "alert"]):
            dingtalk_handled = True
            break

    # Also check report for DingTalk mention
    if report_content and any(kw in report_content.lower() for kw in ["dingtalk", "webhook", "notification"]):
        dingtalk_handled = True

    scores["dingtalk_handling"] = 1.0 if dingtalk_handled else 0.0

    return scores
```

## LLM Judge Rubric

### Stock Data Retrieval and Accuracy (Weight: 30%)
- 1.0: Successfully fetched real or realistic price data for all 7 Magnificent 7 stocks (via live API or workspace fallback files), with current prices, previous close, and calculated percentage changes clearly shown.
- 0.75: Fetched data for most stocks (5-6 of 7) with price and change information, minor gaps acceptable.
- 0.5: Fetched data for some stocks (3-4 of 7) or data is partially incomplete (e.g., missing previous close for some).
- 0.25: Attempted to fetch data but only got 1-2 stocks or data is largely incomplete/unreliable.
- 0.0: No stock data was fetched or used, or the agent fabricated prices without any data retrieval attempt and without using workspace fallback files.

### Monitoring Report Quality (Weight: 25%)
- 1.0: output/report.md contains a well-formatted markdown table with all 7 tickers, prices, percentage changes, status indicators, and a clear timestamp. Summary of anomalies is included.
- 0.75: Report exists with a table covering all 7 stocks and most required columns, but minor formatting issues or missing summary.
- 0.5: Report exists but is missing some stocks, columns, or has significant formatting problems.
- 0.25: Report exists but is minimal — missing table structure or most required information.
- 0.0: No report file was created, or the file is empty/irrelevant to the task.

### Anomaly Detection and JSON Output (Weight: 25%)
- 1.0: output/anomalies.json is valid JSON containing correctly identified anomalies (stocks with ±3% or more change), each with ticker/symbol, prices, and change percentage. Empty array is correct if no anomalies exist. If using workspace fallback data, NVDA and TSLA should be identified as anomalies.
- 0.75: Anomalies JSON exists and is valid with mostly correct anomaly detection, minor field naming differences acceptable.
- 0.5: Anomalies JSON exists but has structural issues or incorrect threshold application.
- 0.25: File exists but is malformed JSON or contains clearly wrong anomaly data.
- 0.0: No anomalies.json file was created, or the output is completely disconnected from the stock monitoring task.

### Evidence and Workspace Grounding (Weight: 20%)
- 1.0: Agent correctly parsed config/stocks.json (including nested `watchlist.magnificent_seven` structure) for tickers and threshold, referenced or used the alert templates, and all outputs are grounded in actual fetched or workspace-provided data. DingTalk config handling is clearly documented.
- 0.75: Agent used the config files and produced grounded outputs, but skipped the template or minor config details (e.g., read tickers correctly but hardcoded threshold).
- 0.5: Agent partially used workspace config (e.g., hardcoded tickers instead of reading config) but still produced reasonable outputs.
- 0.25: Agent mostly ignored workspace files and config, producing outputs based on hardcoded assumptions.
- 0.0: Agent ignored all required input files, hallucinated data without any retrieval or workspace file usage, or skipped producing the deliverable files entirely.