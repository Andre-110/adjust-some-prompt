| 序号 | 修改项 | 修改原因 |
|------|--------|----------|
| 1 | 重写 `workspace_files` 字段，将 `path:` 改为 `dest:` 格式，并将路径从 `home/` 前缀改为 `home_sim/` 以匹配实际 Assets 目录结构 | 原任务文件使用已废弃的 `path:` 字段且路径前缀为 `home/`，但实际 Assets 目录结构为 `home_sim/`；需统一为 `dest:` 格式且路径与真实文件一致 |
| 2 | 在 `workspace_files` 中补充 Assets 目录中存在但原任务文件未列出的文件（`.bash_aliases`、`.zsh_history`、`.config/code-relay/config.json`、`.config/code-relay/credentials`、`etc_environment_backup`、`notes/code-relay-setup.md`、`projects/code-relay-app/.env`） | 原 `workspace_files` 仅列出 7 个文件，但实际 Assets 目录中有 14 个文件，遗漏严重，Agent 无法访问这些关键文件（尤其是 `notes/code-relay-setup.md` 和 `projects/code-relay-app/.env` 对解题至关重要） |
| 3 | 删除 `workspace_files` 中各条目的 `content:` 内联字段 | 既然已有独立的 Assets 文件，不应在 YAML 中重复内联内容；且原内联内容与实际 Assets 文件内容不一致（如 `.bashrc`、`.zshrc`、`.profile`、`environment.d/10-defaults.conf` 的内联版本均为简化版，与 Assets 中的完整版不同），会造成混淆 |
| 4 | 重写 Expected Behavior，将正确答案从 `~/code-relay/.env` 改为 `~/.zshrc`（即 `home_sim/.zshrc`） | 根据实际 Assets 内容，`notes/code-relay-setup.md` 明确记录 Step 6 是"Set environment variables in shell config → Added to ~/.zshrc"，且 `.zshrc` 中确实有对应的 Code-Relay 环境变量配置（日期为 2026-02-09）。原 Expected Behavior 指向的 `home/code-relay/.env` 在 Assets 中不存在（实际存在的是 `home_sim/projects/code-relay-app/.env`，但那是开发用 `.env`，不是 step 6 配置的文件）。原任务文件中内联的 `home/notes/setup-log.md` 在 Assets 中不存在，实际的 `notes/code-relay-setup.md` 讲的是完全不同的故事 |
| 5 | 重写 Grading Criteria 以匹配新的正确答案 | 原评分标准基于错误答案 `code-relay/.env`，需全面更新 |
| 6 | 重写 `grade()` 函数以匹配新的正确答案和实际 Assets 路径 | 原 `grade()` 检查的文件路径和正则模式均基于旧答案，需全面更新 |
| 7 | 重写 LLM Judge Rubric 以匹配新的正确答案 | 原 rubric 基于错误答案，需更新评分描述 |
| 8 | 将 `workspace_files` 中移除原内联的 `home/notes/setup-log.md` 和 `home/notes/browser-history.txt` | 这两个文件在实际 Assets 目录中不存在；Assets 中实际的笔记文件是 `notes/code-relay-setup.md`，浏览器历史不存在 |
| 9 | 添加 `role: trap` 标记给 `projects/code-relay-app/.env` | 该文件是开发环境的 `.env`，可能误导 Agent 认为这就是"最后配置的环境变量文件"，应标记为陷阱并在 Expected Behavior 中说明 |
| 10 | 修正难度从 `medium` 为 `hard` | 题目涉及多个环境配置文件的区分、陷阱文件的排除、需要综合多个线索（setup notes、shell history、文件内容及日期）进行推理，且需要理解 shell 配置与 `.env` 文件的区别，复杂度偏高 |
| 11 | 将 Prompt 中引用路径调整为与新 workspace 文件结构一致 | Prompt 本身不引用具体路径（仅给出 URL），此项无需修改，但确认 Prompt 与 Assets 一致 |
| 12 | `skill_creation: false` 保留不变 | 无需修改 |