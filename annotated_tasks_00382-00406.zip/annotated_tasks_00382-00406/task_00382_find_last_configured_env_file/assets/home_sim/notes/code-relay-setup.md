# Code-Relay Setup Notes
# Date: 2026-02-09

## Setup Guide Progress

Following: https://api.code-relay.com/about

- [x] Step 1: Create account and verify email
- [x] Step 2: Install code-relay CLI (`curl -fsSL https://get.code-relay.com | bash`)
- [x] Step 3: Run `code-relay auth login` to authenticate
- [x] Step 4: Create project (`code-relay project init myapp-backend`)
- [x] Step 5: Configure relay region (ap-east-1)
- [x] Step 6: Set environment variables in shell config
      -> Added to ~/.zshrc (since I'm using zsh as default shell)
      -> Variables: CODE_RELAY_API_KEY, CODE_RELAY_ENDPOINT, CODE_RELAY_PROJECT_ID,
         CODE_RELAY_ENV, CODE_RELAY_LOG_LEVEL, CODE_RELAY_TIMEOUT
      -> Ran `source ~/.zshrc` to apply
- [x] Step 7: Test connection (`code-relay ping`)
- [ ] Step 8: Deploy first relay (haven't done this yet)

## Issues Encountered
- Initially tried adding to .bashrc but realized I'm using zsh
- Had to switch shell config file to .zshrc
- Region auto-detect picked us-west-2, manually set to ap-east-1
