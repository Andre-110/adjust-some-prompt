# ~/.zshrc

# Oh My Zsh configuration
export ZSH="$HOME/.oh-my-zsh"
ZSH_THEME="agnoster"

plugins=(git docker kubectl zsh-autosuggestions zsh-syntax-highlighting)

source $ZSH/oh-my-zsh.sh

# User configuration
export LANG=en_US.UTF-8
export EDITOR='vim'

# Compilation flags
export ARCHFLAGS="-arch x86_64"

# NVM
export NVM_DIR="$HOME/.nvm"
[ -s "$NVM_DIR/nvm.sh" ] && \. "$NVM_DIR/nvm.sh"

# Go
export GOPATH="$HOME/go"
export PATH="$GOPATH/bin:$PATH"

# Python pyenv
export PYENV_ROOT="$HOME/.pyenv"
export PATH="$PYENV_ROOT/bin:$PATH"
eval "$(pyenv init --path)"
eval "$(pyenv init -)"

# Rust
source "$HOME/.cargo/env"

# Kubectl aliases
alias k='kubectl'
alias kgp='kubectl get pods'

# ──────────────────────────────────────────────────────────
# Code-Relay API Configuration
# Added following https://api.code-relay.com/about#linux-step6
# Date: 2026-02-09
# ──────────────────────────────────────────────────────────
export CODE_RELAY_API_KEY="cr_live_a8f29d3e7b1c4056_9k2mXpLq"
export CODE_RELAY_ENDPOINT="https://api.code-relay.com/v2"
export CODE_RELAY_PROJECT_ID="proj_8827ac"
export CODE_RELAY_ENV="production"
export CODE_RELAY_LOG_LEVEL="info"
export CODE_RELAY_TIMEOUT="30"
# End Code-Relay config

# Docker buildkit
export DOCKER_BUILDKIT=1

# FZF
[ -f ~/.fzf.zsh ] && source ~/.fzf.zsh
