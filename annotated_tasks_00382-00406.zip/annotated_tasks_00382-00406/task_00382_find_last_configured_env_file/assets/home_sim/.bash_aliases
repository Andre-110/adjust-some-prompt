# ~/.bash_aliases

alias update='sudo apt update && sudo apt upgrade -y'
alias ports='ss -tulnp'
alias myip='curl -s ifconfig.me'
alias gs='git status'
alias gc='git commit'
alias gp='git push'
alias dc='docker compose'
alias cr='code-relay'
