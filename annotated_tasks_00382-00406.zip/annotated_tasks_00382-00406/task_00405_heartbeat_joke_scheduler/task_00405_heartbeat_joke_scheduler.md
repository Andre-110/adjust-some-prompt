---
id: task_00405_heartbeat_joke_scheduler
name: Heartbeat Joke Scheduler Check
category: Workflow and Agent Orchestration
subcategory: Workflow and Task Scheduling
difficulty: medium
grading_type: hybrid
grading_weights: {automated: 0.4, llm_judge: 0.6}
timeout_seconds: 600
input_modality: text-only
external_dependency: none
workspace_files:
  - source: HEARTBEAT.md
    dest: HEARTBEAT.md
    content: |
      # HEARTBEAT.md

      # Keep this file empty (or with only comments) to skip heartbeat API calls.

      # Add tasks below when you want the agent to check something periodically.
  - source: memory/joke_tracker.json
    dest: memory/joke_tracker.json
    content: |
      {
        "last_joke_time": 1770546120,
        "last_joke_id": 7
      }
skill_creation: false
---

## Prompt

Hey, I have a heartbeat system set up. There's a `HEARTBEAT.md` file in the workspace that defines any recurring tasks the agent should do, and a `memory/joke_tracker.json` that tracks the last time a joke was sent (as a Unix timestamp).

Can you check `HEARTBEAT.md` to see if there are any active heartbeat tasks defined? If there are active tasks (like sending a joke every 5 minutes), do what they say — check the tracker, see if enough time has passed, send a joke if needed, and update the tracker. If `HEARTBEAT.md` is empty or only has comments (no active tasks), just respond with `HEARTBEAT_OK` and don't do anything else.

## Expected Behavior

1. The agent should read `HEARTBEAT.md` to determine whether any active heartbeat tasks are defined.
2. The agent should observe that `HEARTBEAT.md` contains only comments and no active task definitions (the joke task lines have been removed; only comment lines starting with `#` remain).
3. Since there are no active tasks, the agent should respond with `HEARTBEAT_OK` and should NOT send a joke or modify `memory/joke_tracker.json`.
4. The `memory/joke_tracker.json` file should remain unchanged with `last_joke_time` still set to `1770546120`.
5. The agent should NOT hallucinate or infer tasks that are not present in the file — it must respect the actual file contents.

## Grading Criteria

- [ ] Agent reads HEARTBEAT.md to check for active tasks
- [ ] Agent correctly identifies that HEARTBEAT.md has no active tasks (only comments)
- [ ] Agent responds with HEARTBEAT_OK (or equivalent acknowledgment of no action needed)
- [ ] Agent does NOT modify memory/joke_tracker.json
- [ ] Agent does NOT send a joke or perform any heartbeat action
- [ ] Agent does NOT hallucinate tasks that aren't defined in the file

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    import json
    import os

    scores = {
        "heartbeat_md_unchanged": 0.0,
        "joke_tracker_unchanged": 0.0,
        "heartbeat_ok_response": 0.0,
        "no_joke_sent": 0.0,
    }

    # Check that HEARTBEAT.md still exists and has no active (non-comment, non-empty) lines
    heartbeat_path = os.path.join(workspace_path, "HEARTBEAT.md")
    if os.path.exists(heartbeat_path):
        try:
            with open(heartbeat_path, "r", encoding="utf-8") as f:
                content = f.read()
            # All non-blank lines should be comments (start with #) or blank
            lines = content.strip().splitlines()
            active_lines = [l for l in lines if l.strip() and not l.strip().startswith("#")]
            if len(active_lines) == 0:
                scores["heartbeat_md_unchanged"] = 1.0
            else:
                scores["heartbeat_md_unchanged"] = 0.5
        except Exception:
            scores["heartbeat_md_unchanged"] = 0.0
    else:
        scores["heartbeat_md_unchanged"] = 0.0

    # Check that joke_tracker.json was NOT modified (last_joke_time should still be 1770546120)
    tracker_path = os.path.join(workspace_path, "memory", "joke_tracker.json")
    if os.path.exists(tracker_path):
        try:
            with open(tracker_path, "r", encoding="utf-8") as f:
                data = json.load(f)
            if data.get("last_joke_time") == 1770546120:
                scores["joke_tracker_unchanged"] = 1.0
            else:
                scores["joke_tracker_unchanged"] = 0.0
        except Exception:
            scores["joke_tracker_unchanged"] = 0.0
    else:
        # File missing means it was deleted, which is wrong
        scores["joke_tracker_unchanged"] = 0.0

    # Check transcript for HEARTBEAT_OK response
    heartbeat_ok_found = False
    joke_found = False
    for event in transcript:
        if event.get("type") != "message":
            continue
        msg = event.get("message", {})
        if msg.get("role") == "assistant":
            text = msg.get("content", "")
            if isinstance(text, str):
                if "HEARTBEAT_OK" in text.upper().replace(" ", ""):
                    heartbeat_ok_found = True
                # Heuristic: if the assistant tells a joke, it likely contains
                # punchline-like patterns or explicitly says "joke"
                lower_text = text.lower()
                # Only flag if it looks like the agent is actively delivering a joke
                # as part of the heartbeat task
                if ("here's a joke" in lower_text or
                    "here is a joke" in lower_text or
                    "joke for you" in lower_text or
                    "why did the" in lower_text or
                    "knock knock" in lower_text):
                    joke_found = True

    if heartbeat_ok_found:
        scores["heartbeat_ok_response"] = 1.0
    else:
        # Partial credit if they said no active tasks but didn't use exact phrase
        for event in transcript:
            if event.get("type") != "message":
                continue
            msg = event.get("message", {})
            if msg.get("role") == "assistant":
                text = msg.get("content", "")
                if isinstance(text, str):
                    lower = text.lower()
                    if ("no active task" in lower or
                        "no tasks" in lower or
                        "only comments" in lower or
                        "nothing to do" in lower or
                        "no action" in lower):
                        scores["heartbeat_ok_response"] = 0.5
                        break

    if not joke_found:
        scores["no_joke_sent"] = 1.0
    else:
        scores["no_joke_sent"] = 0.0

    return scores
```

## LLM Judge Rubric

### Correct Interpretation of HEARTBEAT.md (Weight: 35%)
- 1.0: Agent reads HEARTBEAT.md, correctly identifies it contains only comments and no active tasks, and explicitly states this finding.
- 0.75: Agent reads HEARTBEAT.md and concludes no action is needed, but explanation is vague or incomplete.
- 0.5: Agent reads HEARTBEAT.md but is uncertain about whether tasks exist; hedges or partially acts.
- 0.25: Agent reads HEARTBEAT.md but misinterprets it, believing there are active tasks when there are none.
- 0.0: Agent does not read HEARTBEAT.md, or hallucinates task content that is not in the file.

### Appropriate Response and No Unnecessary Action (Weight: 30%)
- 1.0: Agent responds with HEARTBEAT_OK (or clear equivalent) and takes no further heartbeat action — no joke sent, no tracker updated.
- 0.75: Agent correctly takes no action but does not use the HEARTBEAT_OK response format.
- 0.5: Agent mostly refrains from action but makes minor unnecessary changes or ambiguous statements.
- 0.25: Agent sends a joke or updates the tracker despite no active task being defined.
- 0.0: Agent performs full heartbeat actions (joke + tracker update) ignoring that HEARTBEAT.md has no active tasks.

### Evidence and Workspace Grounding (Weight: 20%)
- 1.0: Agent's decisions are clearly grounded in the actual content of HEARTBEAT.md and joke_tracker.json as they exist on disk; no hallucinated data.
- 0.75: Agent references the files but makes minor assumptions not supported by file content.
- 0.5: Agent partially references files but also relies on prior context or assumptions about what the files should contain.
- 0.25: Agent mostly ignores file content and acts based on prior conversation context or assumptions.
- 0.0: Agent does not read any workspace files, hallucinates file contents, or produces output completely disconnected from the actual workspace state.

### Clarity and Conciseness (Weight: 15%)
- 1.0: Response is clear, concise, and directly communicates the outcome without unnecessary verbosity.
- 0.75: Response is clear but slightly verbose or includes minor unnecessary information.
- 0.5: Response is understandable but includes significant unnecessary content or is confusingly structured.
- 0.25: Response is unclear or buries the key conclusion in excessive text.
- 0.0: Response is incoherent, missing, or does not address the heartbeat check at all.