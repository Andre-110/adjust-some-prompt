---
id: task_00403_split_archive_extraction_skill
name: Split Archive Extraction Skill and macOS Image Assembly
category: System Administration
subcategory: Storage and Data Management
difficulty: medium
grading_type: hybrid
grading_weights: {automated: 0.4, llm_judge: 0.6}
timeout_seconds: 600
input_modality: text-only
external_dependency: none
skill_creation: true
workspace_files:
  - source: downloads/macOS_Tahoe_26.0/macOS_Tahoe_26.0.7z.001
    dest: downloads/macOS_Tahoe_26.0/macOS_Tahoe_26.0.7z.001
  - source: downloads/macOS_Tahoe_26.0/macOS_Tahoe_26.0.7z.002
    dest: downloads/macOS_Tahoe_26.0/macOS_Tahoe_26.0.7z.002
  - source: downloads/macOS_Tahoe_26.0/macOS_Tahoe_26.0.7z.003
    dest: downloads/macOS_Tahoe_26.0/macOS_Tahoe_26.0.7z.003
  - source: downloads/macOS_Tahoe_26.0/macOS_Tahoe_26.0.7z.004
    dest: downloads/macOS_Tahoe_26.0/macOS_Tahoe_26.0.7z.004
  - source: downloads/macOS_Tahoe_26.0/README.txt
    dest: downloads/macOS_Tahoe_26.0/README.txt
  - source: downloads/macOS_Tahoe_26.0/checksums.sha256
    dest: downloads/macOS_Tahoe_26.0/checksums.sha256
  - source: downloads/.download_history.log
    dest: downloads/.download_history.log
---

## Prompt

Hey, I've got a macOS Tahoe 26.0 image sitting in `downloads/macOS_Tahoe_26.0/` — it's been split into four 7z volumes (.001 through .004). I need two things from you:

1. First, create a reusable OpenClaw skill file at `skills/split-archive-extraction/SKILL.md`. The skill should be about handling split archive volumes — detecting them, verifying all parts are present, and extracting/reassembling them. Think of it like a handy reference guide an agent can follow any time it encounters split archives. Take inspiration from skills like "agentic-ai-gold" or "ethereum-history" — clean YAML frontmatter with name and description, then clear markdown instruction sections.

2. Then, actually use that skill: inspect the split volumes in the downloads folder, verify all four parts are present, check their integrity as best you can (a `checksums.sha256` file is also available in that folder), and write a status report to `extraction_report.md` in the workspace root. The report should list each volume file found, its size, whether all expected parts are accounted for, and what command(s) would be needed to extract/reassemble them. If the files are too small to be real volumes (like placeholders), note that in the report too.

## Expected Behavior

The agent should:

1. **Create `skills/split-archive-extraction/SKILL.md`** with proper YAML frontmatter (containing `name:` and `description:` fields) and markdown body sections covering how to detect, verify, and extract split archive volumes. The skill should be structured similarly to existing OpenClaw skills (like agentic-ai-gold, ethereum-history, agentmemory) — a reusable reference document.

2. **Inspect the downloads directory** to find and list the four split archive volumes (`macOS_Tahoe_26.0.7z.001` through `.004`), the README, and the `checksums.sha256` file.

3. **Create `extraction_report.md`** in the workspace root containing:
   - A listing of each volume file found with its filename and size
   - Confirmation of whether all four expected parts are present
   - Observation that the files appear to be placeholders (each much smaller than the ~3.5 GB stated in README.txt) rather than real multi-GB volumes
   - Reference to the `checksums.sha256` file and note that SHA-256 integrity checks can be performed with `sha256sum -c checksums.sha256`
   - The appropriate extraction command(s) (e.g., `7z x macOS_Tahoe_26.0.7z.001`)

4. **Communicate findings** back to the user, acknowledging the split volumes were found and summarizing the status.

## Grading Criteria

- [ ] `skills/split-archive-extraction/SKILL.md` exists with valid YAML frontmatter containing name and description
- [ ] `skills/split-archive-extraction/SKILL.md` has meaningful instruction sections about split archive handling
- [ ] `extraction_report.md` exists in workspace root
- [ ] `extraction_report.md` lists all four volume files
- [ ] `extraction_report.md` notes file sizes or placeholder status
- [ ] `extraction_report.md` includes extraction command(s)
- [ ] Agent correctly identified all four .7z split volumes in the downloads folder

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    import os
    import re

    scores = {
        "skill_md_exists_and_structured": 0.0,
        "skill_md_content_quality": 0.0,
        "extraction_report_exists": 0.0,
        "extraction_report_completeness": 0.0,
        "volume_detection_in_report": 0.0,
    }

    # Early exit: if neither key output exists, return all zeros
    skill_path = os.path.join(workspace_path, "skills", "split-archive-extraction", "SKILL.md")
    report_path = os.path.join(workspace_path, "extraction_report.md")
    if not os.path.isfile(skill_path) and not os.path.isfile(report_path):
        return scores

    # 1. Check SKILL.md exists and has proper YAML frontmatter
    if os.path.isfile(skill_path):
        try:
            with open(skill_path, "r", encoding="utf-8") as f:
                skill_content = f.read()
        except Exception:
            skill_content = ""

        if skill_content.strip():
            has_frontmatter = skill_content.strip().startswith("---")
            has_name = bool(re.search(r"(?i)^name\s*:", skill_content, re.MULTILINE))
            has_description = bool(re.search(r"(?i)^description\s*:", skill_content, re.MULTILINE))
            has_closing_frontmatter = len(re.findall(r"^---\s*$", skill_content, re.MULTILINE)) >= 2

            frontmatter_score = 0.0
            if has_frontmatter:
                frontmatter_score += 0.25
            if has_name:
                frontmatter_score += 0.25
            if has_description:
                frontmatter_score += 0.25
            if has_closing_frontmatter:
                frontmatter_score += 0.25
            scores["skill_md_exists_and_structured"] = frontmatter_score

            # 2. Check SKILL.md content quality - mentions split archives, extraction, verification
            content_lower = skill_content.lower()
            quality_hits = 0
            quality_terms = ["split", "archive", "extract", "volume", "7z", "verify", "reassembl", "part"]
            for term in quality_terms:
                if term in content_lower:
                    quality_hits += 1
            scores["skill_md_content_quality"] = min(1.0, quality_hits / 4.0)

    # 3. Check extraction_report.md exists
    if os.path.isfile(report_path):
        try:
            with open(report_path, "r", encoding="utf-8") as f:
                report_content = f.read()
        except Exception:
            report_content = ""

        if report_content.strip():
            scores["extraction_report_exists"] = 1.0

            # 4. Check report completeness
            report_lower = report_content.lower()
            completeness = 0.0
            # Mentions extraction command
            if "7z" in report_lower or "p7zip" in report_lower or "7zip" in report_lower:
                completeness += 0.33
            # Mentions sizes or placeholder
            if "placeholder" in report_lower or "size" in report_lower or "4k" in report_lower or "small" in report_lower or "kb" in report_lower:
                completeness += 0.34
            # Mentions all parts present or count
            if "four" in report_lower or "4 " in report_content or "all" in report_lower:
                completeness += 0.33
            scores["extraction_report_completeness"] = min(1.0, completeness)

            # 5. Check that report lists the volume files
            volume_count = 0
            for i in range(1, 5):
                suffix = f".00{i}"
                if suffix in report_content:
                    volume_count += 1
            scores["volume_detection_in_report"] = volume_count / 4.0

    return scores
```

## LLM Judge Rubric

### Skill Document Quality (Weight: 25%)
- 1.0: `skills/split-archive-extraction/SKILL.md` is well-structured with proper YAML frontmatter (name, description), has multiple clear instruction sections covering detection, verification, and extraction of split archives, and is written as a genuinely reusable reference.
- 0.75: SKILL.md exists with frontmatter and covers the main topics but is somewhat thin or missing one aspect.
- 0.5: SKILL.md exists but has incomplete frontmatter or only superficially covers split archive handling.
- 0.25: SKILL.md exists but is poorly structured or barely relevant to split archive handling.
- 0.0: SKILL.md is missing, empty, placed at the wrong path, or completely unrelated to the task.

### Extraction Report Accuracy (Weight: 30%)
- 1.0: `extraction_report.md` accurately lists all four volume files with sizes, correctly identifies them as placeholders, confirms all parts are present, and provides the correct extraction command(s).
- 0.75: Report covers most elements but is missing one detail (e.g., doesn't mention placeholder status or omits one file).
- 0.5: Report exists and lists some files but is missing significant details like commands or size observations.
- 0.25: Report exists but is largely incomplete or contains incorrect information.
- 0.0: Report is missing, empty, or contains fabricated information not grounded in the actual workspace files.

### Evidence and Workspace Grounding (Weight: 25%)
- 1.0: Agent clearly inspected the actual files in `downloads/macOS_Tahoe_26.0/`, referenced real filenames and sizes from the workspace, and all claims in deliverables match observable workspace state.
- 0.75: Agent inspected the files and most claims are grounded, with minor discrepancies.
- 0.5: Agent appears to have checked the files but some claims seem assumed rather than verified.
- 0.25: Agent made minimal effort to inspect actual files; deliverables are mostly generic.
- 0.0: Agent ignored the workspace files entirely, hallucinated file details, or produced no deliverables referencing the actual data.

### Communication and User Interaction (Weight: 20%)
- 1.0: Agent acknowledged the user's message, clearly communicated findings about the split volumes, and provided helpful next-step guidance.
- 0.75: Agent communicated findings but was missing some context or next steps.
- 0.5: Agent provided a basic response but didn't fully address the user's situation.
- 0.25: Agent's communication was minimal or unclear.
- 0.0: Agent did not communicate with the user or provided irrelevant responses.