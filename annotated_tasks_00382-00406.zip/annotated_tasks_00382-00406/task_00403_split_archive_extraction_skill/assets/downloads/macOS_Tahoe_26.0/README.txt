macOS Tahoe 26.0 - Full Install Image
======================================

This archive contains the official macOS Tahoe 26.0 installer disk image.

Split into 4 volumes using 7-Zip:
  macOS_Tahoe_26.0.7z.001  (3.5 GB)
  macOS_Tahoe_26.0.7z.002  (3.5 GB)
  macOS_Tahoe_26.0.7z.003  (3.5 GB)
  macOS_Tahoe_26.0.7z.004  (2.1 GB)

Total uncompressed: ~14.8 GB (InstallAssistant.dmg)

To extract:
  7z x macOS_Tahoe_26.0.7z.001

Or on Linux:
  sudo apt install p7zip-full
  7z x macOS_Tahoe_26.0.7z.001

After extraction you will have:
  InstallAssistant.dmg  (14.8 GB)

Checksums provided in checksums.sha256

Source: Apple Software Restore image, build 26A100
Date: 2026-01-28
