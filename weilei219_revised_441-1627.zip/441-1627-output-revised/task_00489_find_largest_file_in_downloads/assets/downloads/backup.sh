#!/bin/bash
# backup.sh - Daily backup script
# Last modified: 2024-10-05

BACKUP_DIR="/mnt/backups"
SOURCE_DIR="/home/user/documents"
DATE=$(date +%Y-%m-%d)
ARCHIVE="${BACKUP_DIR}/backup_${DATE}.tar.gz"

echo "Starting backup: ${DATE}"
tar -czf "${ARCHIVE}" "${SOURCE_DIR}" 2>/dev/null

if [ $? -eq 0 ]; then
    echo "Backup successful: ${ARCHIVE}"
    find "${BACKUP_DIR}" -name "backup_*.tar.gz" -mtime +30 -delete
    echo "Old backups cleaned up."
else
    echo "ERROR: Backup failed!" >&2
    exit 1
fi
