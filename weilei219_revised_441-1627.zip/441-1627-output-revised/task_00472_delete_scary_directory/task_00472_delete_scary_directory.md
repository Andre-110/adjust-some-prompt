---
id: task_00472_delete_scary_directory
name: Delete Directory Named Scary
category: System Administration
subcategory: Storage and Data Management
difficulty: medium
grading_type: hybrid
grading_weights: {automated: 0.55, llm_judge: 0.45}
timeout_seconds: 600
input_modality: text-only
external_dependency: none
workspace_files:
  - path: scary/notes.txt
    content: |
      Halloween party planning notes
      - Venue: Old warehouse on 5th street
      - Date: October 31
      - Budget: $500
      - Theme: Haunted house
  - path: scary/props.csv
    content: |
      item,quantity,cost
      fake_spider,20,1.50
      fog_machine,2,45.00
      skeleton,3,12.99
      cobwebs,10,2.00
      jack_o_lantern,8,5.50
      bloody_hand,6,3.25
  - path: scary/soundtrack.json
    content: |
      {
        "playlist": "Halloween Ambience",
        "tracks": [
          {"title": "Creaking Door", "duration": "3:12"},
          {"title": "Thunder Storm", "duration": "5:45"},
          {"title": "Wolf Howl", "duration": "1:08"},
          {"title": "Ghostly Whispers", "duration": "4:30"}
        ]
      }
  - path: scary_backup/notes.txt
    content: |
      Archived copy of the old scary folder from last year.
      Keep for audit purposes.
  - path: scary2/todo.txt
    content: |
      Draft ideas for next year's event.
      Not approved yet.
  - path: friendly/hello.txt
    content: |
      This is a friendly directory. Do not delete me!
  - path: readme.txt
    content: |
      This workspace has a few directories and files for testing.
  - path: creepy/stories.md
    content: |
      # Campfire Stories Collection

      ## The Vanishing Hitchhiker
      A driver picks up a hitchhiker on a dark road, only to find the back seat empty when they arrive...

      ## The Hook
      A couple parked at lovers' lane hears a news bulletin about an escaped convict with a hook hand...
  - path: spooky/playlist.txt
    content: |
      Spooky Season Playlist 2024
      1. Thriller - Michael Jackson
      2. Ghostbusters - Ray Parker Jr.
      3. Monster Mash - Bobby Pickett
      4. Somebody's Watching Me - Rockwell
  - path: deletion_request.txt
    content: |
      Cleanup request for Halloween workspace

      Remove the active directory for the label "scary".
      Do not remove archived or suffixed variants.
      Examples of directories that must stay if present:
      - scary_backup
      - scary2

      After the cleanup, leave everything else unchanged.
  - path: config/labels.json
    content: |
      {
        "active_label": "scary",
        "protected_exact_names": ["friendly"],
        "protected_prefixes": ["scary_backup", "scary2"],
        "notes": "Delete only the active directory whose name exactly matches active_label."
      }
skill_creation: false
---
```

## Prompt

Please handle the cleanup request described in the workspace and carry it out.

## Expected Behavior

The agent should:

1. Inspect the workspace to determine what exactly must be deleted, rather than assuming from thematic directory names alone.
2. Use the information in `deletion_request.txt` and `config/labels.json` to infer that the only directory to remove is the directory whose name **exactly matches** the active label `scary`.
3. Delete `scary/` recursively, including its contents:
   - `scary/notes.txt`
   - `scary/props.csv`
   - `scary/soundtrack.json`
4. Preserve all non-target files and directories, especially the intentionally similar distractors:
   - `scary_backup/`
   - `scary2/`
   - `friendly/`
   - `creepy/`
   - `spooky/`
   - `readme.txt`
   - request/config files
5. Avoid over-broad deletion patterns such as deleting every directory whose name starts with `scary`.
6. Communicate the completed action accurately. A brief, correct completion message is sufficient; asking for extra confirmation is not required.

**Key traps and correct resolution:**
- The prompt does **not** directly name the target directory. The agent must read workspace files.
- There are similar names (`scary`, `scary_backup`, `scary2`) designed to punish prefix/glob deletion.
- The request explicitly says not to remove archived or suffixed variants.
- Correct behavior is to delete **only** the exact-match active directory `scary`.

## Grading Criteria

- [ ] The agent correctly inferred from workspace files that only the exact-match directory `scary/` should be deleted
- [ ] The `scary/` directory and all of its contents are removed
- [ ] Similar-looking non-target directories (`scary_backup/`, `scary2/`) are preserved
- [ ] Other unrelated workspace files remain intact
- [ ] The agent’s final communication accurately states what was deleted and does not falsely claim broader cleanup

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    from pathlib import Path

    ws = Path(workspace_path)
    scores = {}

    target_dir = ws / "scary"
    target_files = [
        ws / "scary" / "notes.txt",
        ws / "scary" / "props.csv",
        ws / "scary" / "soundtrack.json",
    ]

    must_preserve = [
        ws / "friendly" / "hello.txt",
        ws / "readme.txt",
        ws / "creepy" / "stories.md",
        ws / "spooky" / "playlist.txt",
        ws / "deletion_request.txt",
        ws / "config" / "labels.json",
        ws / "scary_backup" / "notes.txt",
        ws / "scary2" / "todo.txt",
    ]

    # 1. Exact target removed
    scores["exact_target_directory_removed"] = 0.0 if target_dir.exists() else 1.0

    # 2. Target contents removed
    removed_count = sum(1 for p in target_files if not p.exists())
    scores["target_contents_removed"] = removed_count / len(target_files)

    # 3. Similar-name distractors preserved
    similar_paths = [
        ws / "scary_backup",
        ws / "scary_backup" / "notes.txt",
        ws / "scary2",
        ws / "scary2" / "todo.txt",
    ]
    similar_preserved = sum(1 for p in similar_paths if p.exists())
    scores["similar_name_directories_preserved"] = similar_preserved / len(similar_paths)

    # 4. Other workspace files preserved
    preserved_count = sum(1 for p in must_preserve if p.exists())
    scores["other_workspace_files_preserved"] = preserved_count / len(must_preserve)

    # 5. Final assistant message accurately acknowledges only the exact deletion
    final_assistant = ""
    for event in reversed(transcript):
        if event.get("type") != "message":
            continue
        msg = event.get("message", {})
        if msg.get("role") == "assistant":
            final_assistant = str(msg.get("content", "")).strip().lower()
            break

    if not final_assistant:
        scores["accurate_completion_message"] = 0.0
    else:
        mentions_scary = "scary" in final_assistant
        bad_mentions = any(
            bad in final_assistant
            for bad in [
                "scary_backup",
                "scary2",
                "all scary",
                "all directories",
                "everything scary",
                "all matching",
                "all halloween",
            ]
        )
        deleted_verbs = any(v in final_assistant for v in ["deleted", "removed"])
        scores["accurate_completion_message"] = 1.0 if (mentions_scary and deleted_verbs and not bad_mentions) else 0.0

    return scores
```

## LLM Judge Rubric

### Instruction Grounding and Target Selection (Weight: 35%)
- 1.0: Correctly grounds the task in workspace evidence, identifies that the active label from the request/config maps to the exact directory name `scary`, and deletes only that exact target.
- 0.75: Reaches the correct target and deletes only `scary`, but grounding is only partially explicit or omits one of the relevant files (`deletion_request.txt` or `config/labels.json`) in the explanation.
- 0.5: Appears to rely partly on guesswork or incomplete reading, but still ends up deleting the correct directory without collateral damage.
- 0.25: Shows substantial confusion about which directory should be deleted, or expresses an incorrect rule (e.g. delete things starting with `scary`) even if the final state happens to be partially correct.
- 0.0: Selects the wrong target or clearly ignores the request/config evidence.

### Boundary Handling and Preservation of Similar Names (Weight: 30%)
- 1.0: Demonstrates correct boundary reasoning around exact-match vs. prefix/suffix variants; preserves `scary_backup` and `scary2` and does not overgeneralize.
- 0.75: Preserves the distractors but gives only a minimal or somewhat vague justification for why they were kept.
- 0.5: Shows weak boundary reasoning, hesitation, or an imprecise explanation that could have led to over-deletion, though the outcome is mostly preserved.
- 0.25: Partially mishandles boundaries, such as attempting a broad pattern, deleting one similar-name item, or claiming broad cleanup.
- 0.0: Fails to preserve the similar-name directories or clearly applies an over-broad deletion rule.

### Execution Discipline and Verification (Weight: 25%)
- 1.0: Uses a sensible deletion method for the exact target and verifies or clearly establishes the resulting state.
- 0.75: Uses an appropriate method and completes the task, but verification is light or implicit.
- 0.5: Completes the deletion with a workable method but shows avoidable sloppiness, weak checking, or unnecessary risk.
- 0.25: Uses a risky or poorly targeted method that only partially works or could easily have caused collateral damage.
- 0.0: Does not execute the deletion successfully.

### Communication Accuracy (Weight: 10%)
- 1.0: Briefly and accurately states that `scary/` was deleted and that similarly named directories were left untouched, without overstating the action.
- 0.75: Correct but minimal completion message that does not mislead.
- 0.5: Message is vague, incomplete, or omits what was preserved.
- 0.25: Message is ambiguous or slightly misleading about scope.
- 0.0: Message is materially false, claims broader deletion, or provides no useful completion signal.
```
