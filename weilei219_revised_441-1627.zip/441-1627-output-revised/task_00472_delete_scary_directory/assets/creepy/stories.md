# Campfire Stories Collection

## The Vanishing Hitchhiker
A driver picks up a hitchhiker on a dark road, only to find the back seat empty when they arrive...

## The Hook
A couple parked at lovers' lane hears a news bulletin about an escaped convict with a hook hand...
