This workspace has a few directories and files for testing.
