---
id: task_00483_rewrite_fireworks_sentence_skill
name: Rewrite Fireworks Sentence with New Year Atmosphere Skill
category: Communication and Scheduling
subcategory: Message and Email Communication
difficulty: medium
grading_type: hybrid
grading_weights: {automated: 0.45, llm_judge: 0.55}
timeout_seconds: 600
input_modality: text-only
external_dependency: none
skill_creation: true
workspace_files:
  - path: "05 creative-writing/drafts/20260223_fire_dept_spring_festival_article/fire_dept_spring_festival_article.md"
    content: |
      # Silent Guardians of Quanzhou: Firefighters on Duty During the Spring Festival

      > When thousands of families gather under warm lights, they stand watch in the cold night — the silent guardians of a peaceful New Year.

      ## Opening: The Eve of the Lunar New Year

      The ancient city of Quanzhou comes alive during the Spring Festival. Red lanterns hang from the eaves of centuries-old buildings along West Street, and the aroma of braised pork drifts from every doorway. Families bustle about, children clutch new red envelopes, and the city hums with anticipation.

      But for Station 7 of the Quanzhou City Fire Rescue Brigade, the festive season means something different: heightened vigilance, longer shifts, and the quiet knowledge that danger does not take holidays.

      ## Chapter 1: Preparations Before the Countdown

      In the week leading up to New Year's Eve, Captain Lin Jianfeng led his team through a rigorous round of inspections. Ancient temples packed with incense, shopping districts overflowing with holiday crowds, and residential buildings draped in decorations — each site was catalogued, risk-assessed, and mapped. "We checked 43 locations in three days," Lin recalled. Every piece of equipment was tested. Hoses uncoiled and pressurized. Breathing apparatus inspected valve by valve. The aerial ladder truck positioned strategically near the Kaiyuan Temple district, where crowds would be densest.

      ## Chapter 2: The Countdown

      By 11 PM on New Year's Eve, West Street was a river of people — locals and tourists shoulder to shoulder, phone screens glowing, voices rising with excitement. Street vendors sold tangyuan and grilled oysters. Children perched on their parents' shoulders, eyes wide with wonder.

      At Station 7, the firefighters watched the scene unfold on a wall of monitors. Every camera feed was live. Every radio channel open. Dispatcher Huang Meiling announced: "Three minutes to midnight." The team stood ready — full gear, engines running, adrenaline held in check by training and discipline.

      The clock struck twelve.

      In that instant, fireworks burst across the sky above the ancient city of Quanzhou, and the crowds on West Street gradually dispersed amid waves of cheering.

      But for the firefighters, the night was just beginning.

      ## Chapter 3: The First Call

      At 12:47 AM, the alarm rang. A residential fire on Zhongshan Road — an unattended incense burner had toppled onto a stack of paper offerings. Smoke was already visible from two blocks away.

      Engine 7-1 rolled out in under 90 seconds. Through streets still thick with revelers, sirens cutting through the celebration noise, they reached the scene in four minutes.

      "Flames were confined to one room on the second floor," said firefighter Chen Wei, the first through the door. "But the building is over a hundred years old — all wood. Another five minutes and the whole block could have gone."

      The fire was suppressed in eleven minutes. No casualties. One elderly resident treated for minor smoke inhalation. The family's cat was found hiding behind the water tank on the roof, unharmed.

      ## Chapter 4: Through the Night

      Between midnight and 6 AM, Station 7 responded to seven calls:

      | Time  | Location              | Incident Type         | Resolution         |
      |-------|-----------------------|-----------------------|--------------------|
      | 00:47 | Zhongshan Road        | Residential fire      | Suppressed, 11 min |
      | 01:15 | Kaiyuan Temple area   | Crowd crush risk      | Assisted police    |
      | 02:03 | Fengze District       | Vehicle fire          | Suppressed, 8 min  |
      | 02:41 | West Street           | False alarm           | Cleared            |
      | 03:30 | Luojiang overpass     | Traffic accident      | Extraction, 22 min |
      | 04:55 | Industrial zone east  | Chemical leak (minor) | Contained, 35 min  |
      | 05:20 | Residential compound  | Elevator entrapment   | Rescued, 15 min    |

      "New Year's Eve is always our busiest night," said Captain Lin. "People are happy, but happiness makes people careless."

      ## Chapter 5: Morning Light

      As dawn broke over Quanzhou, the exhausted crew finally sat down for their own New Year meal — reheated dumplings, leftover rice, and a thermos of tea that had gone cold hours ago.

      Firefighter Zhang Xiaomei, 24, the youngest on the team, stared at a photo on her phone — her family gathered around a table in Fuzhou, 200 kilometers away. "My mom sent this at midnight," she said quietly. "I told her I'd be home for Lantern Festival. Maybe."

      Captain Lin raised his paper cup. "To another safe year." "To another safe year," they echoed.

      ## Closing

      Every Spring Festival, over 200,000 firefighters across China remain on duty. They miss the family reunions, the midnight toasts, the warmth of home. They stand instead in smoke-filled rooms, on rain-slicked highways, in the bitter cold of pre-dawn hours.

      The ancient city of Quanzhou will celebrate again next year. The lanterns will glow, the crowds will gather, and the incense will burn. And Station 7 will be there — silent, ready, watching.

      ---

      *Published by the Quanzhou City Fire Rescue Brigade Public Affairs Office*
      *Photography: Wang Hao, Zhang Lei*
      *Editor: Li Qian*
      *February 2026*
  - path: "05 creative-writing/reference/quanzhou_festival_publicity_compliance_note.md"
    content: |
      # Quanzhou Spring Festival Publicity Compliance Note (Internal Reference)

      **Applies to:** public-facing stories, captions, and publicity copy about Spring Festival activities in Quanzhou urban districts.

      ## Purpose
      Keep celebratory reporting vivid and human while avoiding language that normalizes or depicts prohibited unsafe behavior in built-up urban areas.

      ## Use these rules when rewriting copy
      1. **Do not depict fireworks, firecrackers, or pyrotechnic releases as occurring in urban built-up areas.**
         - This includes direct or indirect wording such as *fireworks*, *firecrackers*, *pyrotechnics*, *sky rockets*, *aerial bursts*, *spark showers*, or similar expressions when the scene is clearly in the city.
      2. **Do not replace fireworks with another hazardous ignition image** in the same urban celebration scene.
         - Avoid substitutes like *flames streaked overhead*, *explosions lit the street*, *rockets shot upward*, etc.
      3. **Atmosphere should be preserved through safe celebratory details.**
         - Preferred imagery includes lanterns, decorative lights, illuminated rooftops, temple bells, countdown voices, drumbeats, phone screens, music, and cheers.
      4. **Keep factual framing intact.**
         - Do not change who was present, where the scene occurs, or the sequence of events.
         - Do not imply that the crowd panicked or that an emergency happened at midnight unless the original text says so.
      5. **Keep edits minimal and local.**
         - For article polishing, rewrite only the sentence(s) needed for compliance unless another sentence becomes ungrammatical as a direct result.

      ## Editorial test
      A compliant rewrite should still sound like New Year's Eve in Quanzhou, but a reader should **not** be able to picture people setting off fireworks or similar pyrotechnics over the city.
---

## Prompt

I’m preparing a reusable writing aid for our team.

Please create a `SKILL.md` file in the workspace root for **rewriting festive publicity copy under compliance constraints**. It should be a real reusable skill document, not just a placeholder: include YAML frontmatter, when to use it, a concise workflow, decision rules, and at least one input/output example.

Then update the article at:

`05 creative-writing/drafts/20260223_fire_dept_spring_festival_article/fire_dept_spring_festival_article.md`

Use the reference note at:

`05 creative-writing/reference/quanzhou_festival_publicity_compliance_note.md`

Important: make the article compliant with that note while keeping it publishable as a vivid New Year story. Keep edits as local as possible, but don’t ignore other wording if the note would still consider it non-compliant or if your rewrite introduces a new hazard image. Update the article in place.

## Expected Behavior

1. The agent should create `SKILL.md` in the workspace root with valid YAML frontmatter including at least `name` and `description`.
2. The skill should be meaningfully reusable for constrained rewriting, not a stub. It should include:
   - when to use / when not to use
   - a short workflow or procedure
   - decision rules derived from a policy/reference text
   - at least one concrete input/output example
3. The agent should read both:
   - `05 creative-writing/drafts/20260223_fire_dept_spring_festival_article/fire_dept_spring_festival_article.md`
   - `05 creative-writing/reference/quanzhou_festival_publicity_compliance_note.md`
4. The agent should apply the compliance note rather than merely deleting the word “fireworks”.
   - Ground truth from the note:
     - urban fireworks / firecrackers / pyrotechnics imagery is not allowed
     - replacing fireworks with another hazardous ignition/explosion image is also not allowed
     - safe festive imagery should be used instead
     - factual framing and event sequence should remain intact
     - edits should stay as local as possible
5. The key sentence in Chapter 2 must be rewritten so that a reader can no longer picture fireworks or similar pyrotechnic activity over the city at midnight.
6. Correct solutions may use safe imagery such as lantern light, illuminated rooftops, bells, countdown voices, cheers, glowing phone screens, or other clearly non-hazardous celebratory details.
7. Trap cases that should be scored down:
   - replacing “fireworks” with near-synonyms or indirect pyrotechnic imagery such as “pyrotechnics,” “sky rockets,” “aerial bursts,” “spark showers,” “explosive blooms,” etc.
   - introducing substitute danger imagery such as flames, blasts, explosions, or rockets overhead
   - changing unrelated facts, times, people, or surrounding paragraphs
   - creating a generic SKILL.md with no policy extraction or example
8. The rest of the article should remain intact except for minimal edits needed to satisfy the note. In the provided asset, the intended compliant edit scope is the midnight sentence only; altering more than that is usually unnecessary and should be penalized unless clearly justified.

## Grading Criteria

- [ ] `SKILL.md` exists in the workspace root
- [ ] `SKILL.md` has YAML frontmatter with `name` and `description`
- [ ] `SKILL.md` includes reusable guidance: usage conditions, workflow, policy-derived decision rules, and at least one example
- [ ] The article was modified in place
- [ ] The original midnight fireworks sentence is no longer present verbatim
- [ ] The revised article contains no `firework` word stem anywhere
- [ ] The rewritten midnight sentence avoids other pyrotechnic / hazardous-overhead imagery
- [ ] The rewrite preserves factual framing and keeps the article otherwise intact
- [ ] The rewritten sentence still conveys a vivid, safe New Year atmosphere

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    import re
    from pathlib import Path

    scores = {
        "skill_md_exists": 0.0,
        "skill_md_structure": 0.0,
        "skill_md_reusability": 0.0,
        "article_modified": 0.0,
        "fireworks_removed": 0.0,
        "hazard_imagery_removed": 0.0,
        "article_integrity": 0.0,
    }

    workspace = Path(workspace_path)
    skill_candidates = [workspace / "SKILL.md", workspace / "skill.md", workspace / "Skill.md"]
    skill_path = next((p for p in skill_candidates if p.exists()), None)

    if skill_path is not None:
        scores["skill_md_exists"] = 1.0
        skill_content = skill_path.read_text(encoding="utf-8", errors="replace")
        skill_lower = skill_content.lower()

        has_frontmatter = skill_content.lstrip().startswith("---")
        has_name = False
        has_description = False
        if has_frontmatter:
            parts = skill_content.split("---", 2)
            if len(parts) >= 3:
                frontmatter_block = parts[1].lower()
                has_name = re.search(r"(^|\n)\s*name\s*:", frontmatter_block) is not None
                has_description = re.search(r"(^|\n)\s*description\s*:", frontmatter_block) is not None

        heading_count = len(re.findall(r"(?m)^\s{0,3}#{1,6}\s+\S+", skill_content))
        structure_score = 0.0
        if has_frontmatter:
            structure_score += 0.25
        if has_name:
            structure_score += 0.25
        if has_description:
            structure_score += 0.25
        if heading_count >= 2:
            structure_score += 0.25
        scores["skill_md_structure"] = structure_score

        reusability_hits = 0
        if any(term in skill_lower for term in ["when to use", "use this", "appropriate when", "use cases"]):
            reusability_hits += 1
        if any(term in skill_lower for term in ["workflow", "procedure", "steps", "process"]):
            reusability_hits += 1
        if any(term in skill_lower for term in ["decision rule", "rules", "policy", "compliance", "constraint"]):
            reusability_hits += 1
        if any(term in skill_lower for term in ["example", "input", "output"]):
            reusability_hits += 1
        scores["skill_md_reusability"] = reusability_hits / 4.0

    article_path = workspace / "05 creative-writing" / "drafts" / "20260223_fire_dept_spring_festival_article" / "fire_dept_spring_festival_article.md"
    reference_path = workspace / "05 creative-writing" / "reference" / "quanzhou_festival_publicity_compliance_note.md"

    if article_path.exists() and reference_path.exists():
        article_content = article_path.read_text(encoding="utf-8", errors="replace")
        article_lower = article_content.lower()

        original_sentence = "In that instant, fireworks burst across the sky above the ancient city of Quanzhou, and the crowds on West Street gradually dispersed amid waves of cheering."
        normalized_article = re.sub(r"\s+", " ", article_content).strip()
        normalized_original = re.sub(r"\s+", " ", original_sentence).strip()

        if normalized_original not in normalized_article:
            scores["article_modified"] = 1.0

        # independent of article_modified: broad stem check per QC suggestion
        if re.search(r"\bfirework[s]?\b", article_lower) is None:
            scores["fireworks_removed"] = 1.0

        # check the rewritten midnight sentence area for unsafe substitute imagery
        midnight_anchor = "The clock struck twelve."
        next_anchor = "But for the firefighters, the night was just beginning."
        segment_score = 0.0
        if midnight_anchor in article_content and next_anchor in article_content:
            start = article_content.index(midnight_anchor) + len(midnight_anchor)
            end = article_content.index(next_anchor, start)
            middle_segment = article_content[start:end].strip()
            middle_lower = middle_segment.lower()

            prohibited_patterns = [
                r"\bpyrotechn",
                r"\bfirecracker",
                r"\bsky\s*rocket",
                r"\brocket[s]?\b",
                r"\baerial\s+burst",
                r"\bspark\s+shower",
                r"\bexplosi",
                r"\bblast[s]?\b",
                r"\bflames?\b.{0,40}\b(overhead|sky|above)",
                r"\bburst[s]?\b.{0,20}\bsky\b",
            ]
            unsafe_found = any(re.search(pattern, middle_lower) for pattern in prohibited_patterns)
            if not unsafe_found:
                segment_score = 1.0
        scores["hazard_imagery_removed"] = segment_score

        current_lines = article_content.splitlines()
        original_lines = [
            "# Silent Guardians of Quanzhou: Firefighters on Duty During the Spring Festival",
            "",
            "> When thousands of families gather under warm lights, they stand watch in the cold night — the silent guardians of a peaceful New Year.",
            "",
            "## Opening: The Eve of the Lunar New Year",
            "",
            "The ancient city of Quanzhou comes alive during the Spring Festival. Red lanterns hang from the eaves of centuries-old buildings along West Street, and the aroma of braised pork drifts from every doorway. Families bustle about, children clutch new red envelopes, and the city hums with anticipation.",
            "",
            "But for Station 7 of the Quanzhou City Fire Rescue Brigade, the festive season means something different: heightened vigilance, longer shifts, and the quiet knowledge that danger does not take holidays.",
            "",
            "## Chapter 1: Preparations Before the Countdown",
            "",
            "In the week leading up to New Year's Eve, Captain Lin Jianfeng led his team through a rigorous round of inspections. Ancient temples packed with incense, shopping districts overflowing with holiday crowds, and residential buildings draped in decorations — each site was catalogued, risk-assessed, and mapped. \"We checked 43 locations in three days,\" Lin recalled. Every piece of equipment was tested. Hoses uncoiled and pressurized. Breathing apparatus inspected valve by valve. The aerial ladder truck positioned strategically near the Kaiyuan Temple district, where crowds would be densest.",
            "",
            "## Chapter 2: The Countdown",
            "",
            "By 11 PM on New Year's Eve, West Street was a river of people — locals and tourists shoulder to shoulder, phone screens glowing, voices rising with excitement. Street vendors sold tangyuan and grilled oysters. Children perched on their parents' shoulders, eyes wide with wonder.",
            "",
            "At Station 7, the firefighters watched the scene unfold on a wall of monitors. Every camera feed was live. Every radio channel open. Dispatcher Huang Meiling announced: \"Three minutes to midnight.\" The team stood ready — full gear, engines running, adrenaline held in check by training and discipline.",
            "",
            "The clock struck twelve.",
            "",
            "In that instant, fireworks burst across the sky above the ancient city of Quanzhou, and the crowds on West Street gradually dispersed amid waves of cheering.",
            "",
            "But for the firefighters, the night was just beginning.",
            "",
            "## Chapter 3: The First Call",
            "",
            "At 12:47 AM, the alarm rang. A residential fire on Zhongshan Road — an unattended incense burner had toppled onto a stack of paper offerings. Smoke was already visible from two blocks away.",
            "",
            "Engine 7-1 rolled out in under 90 seconds. Through streets still thick with revelers, sirens cutting through the celebration noise, they reached the scene in four minutes.",
            "",
            "\"Flames were confined to one room on the second floor,\" said firefighter Chen Wei, the first through the door. \"But the building is over a hundred years old — all wood. Another five minutes and the whole block could have gone.\"",
            "",
            "The fire was suppressed in eleven minutes. No casualties. One elderly resident treated for minor smoke inhalation. The family's cat was found hiding behind the water tank on the roof, unharmed.",
            "",
            "## Chapter 4: Through the Night",
            "",
            "Between midnight and 6 AM, Station 7 responded to seven calls:",
            "",
            "| Time  | Location              | Incident Type         | Resolution         |",
            "|-------|-----------------------|-----------------------|--------------------|",
            "| 00:47 | Zhongshan Road        | Residential fire      | Suppressed, 11 min |",
            "| 01:15 | Kaiyuan Temple area   | Crowd crush risk      | Assisted police    |",
            "| 02:03 | Fengze District       | Vehicle fire          | Suppressed, 8 min  |",
            "| 02:41 | West Street           | False alarm           | Cleared            |",
            "| 03:30 | Luojiang overpass     | Traffic accident      | Extraction, 22 min |",
            "| 04:55 | Industrial zone east  | Chemical leak (minor) | Contained, 35 min  |",
            "| 05:20 | Residential compound  | Elevator entrapment   | Rescued, 15 min    |",
            "",
            "\"New Year's Eve is always our busiest night,\" said Captain Lin. \"People are happy, but happiness makes people careless.\"",
            "",
            "## Chapter 5: Morning Light",
            "",
            "As dawn broke over Quanzhou, the exhausted crew finally sat down for their own New Year meal — reheated dumplings, leftover rice, and a thermos of tea that had gone cold hours ago.",
            "",
            "Firefighter Zhang Xiaomei, 24, the youngest on the team, stared at a photo on her phone — her family gathered around a table in Fuzhou, 200 kilometers away. \"My mom sent this at midnight,\" she said quietly. \"I told her I'd be home for Lantern Festival. Maybe.\"",
            "",
            "Captain Lin raised his paper cup. \"To another safe year.\" \"To another safe year,\" they echoed.",
            "",
            "## Closing",
            "",
            "Every Spring Festival, over 200,000 firefighters across China remain on duty. They miss the family reunions, the midnight toasts, the warmth of home. They stand instead in smoke-filled rooms, on rain-slicked highways, in the bitter cold of pre-dawn hours.",
            "",
            "The ancient city of Quanzhou will celebrate again next year. The lanterns will glow, the crowds will gather, and the incense will burn. And Station 7 will be there — silent, ready, watching.",
            "",
            "---",
            "",
            "*Published by the Quanzhou City Fire Rescue Brigade Public Affairs Office*",
            "*Photography: Wang Hao, Zhang Lei*",
            "*Editor: Li Qian*",
            "*February 2026*",
        ]

        if len(current_lines) == len(original_lines):
            same_count = 0
            changed_indexes = []
            for idx, (cur, orig) in enumerate(zip(current_lines, original_lines)):
                if cur == orig:
                    same_count += 1
                else:
                    changed_indexes.append(idx)
            if changed_indexes and all(original_lines[i] == "In that instant, fireworks burst across the sky above the ancient city of Quanzhou, and the crowds on West Street gradually dispersed amid waves of cheering." for i in changed_indexes):
                scores["article_integrity"] = 1.0
            else:
                scores["article_integrity"] = same_count / len(original_lines)
        else:
            # fallback for line-count changes: check key anchors to avoid brittle failure
            key_phrases = [
                "Silent Guardians of Quanzhou",
                "The ancient city of Quanzhou comes alive during the Spring Festival.",
                "Captain Lin Jianfeng led his team",
                "Dispatcher Huang Meiling announced",
                "But for the firefighters, the night was just beginning.",
                "At 12:47 AM, the alarm rang.",
                "Between midnight and 6 AM, Station 7 responded to seven calls:",
                "As dawn broke over Quanzhou",
                "Quanzhou City Fire Rescue Brigade Public Affairs Office",
            ]
            intact_count = sum(1 for phrase in key_phrases if phrase in article_content)
            scores["article_integrity"] = intact_count / len(key_phrases)

    return scores
```

## LLM Judge Rubric

### Skill File Quality and Reusability (Weight: 25%)
- 1.0: `SKILL.md` is a genuinely reusable skill with YAML frontmatter (`name`, `description`), clear scope, when-to-use / when-not-to-use guidance, a concise workflow, explicit policy-to-edit decision rules, and at least one concrete input/output example that demonstrates constrained rewriting.
- 0.75: `SKILL.md` is structurally sound and useful, but one important element is underdeveloped (for example, weak decision rules, missing when-not-to-use guidance, or a shallow example).
- 0.5: `SKILL.md` exists and has some structure, but it is mostly generic writing advice and does not clearly operationalize policy-based rewriting.
- 0.25: `SKILL.md` is a stub or template with minimal actionable content.
- 0.0: No usable `SKILL.md` was created.

### Compliance Reasoning and Constraint Application (Weight: 25%)
- 1.0: The rewrite clearly applies the reference note correctly: no urban fireworks or pyrotechnic imagery remains, no substitute hazardous ignition imagery is introduced, and the factual setting/sequence stay intact.
- 0.75: The rewrite is broadly compliant, but there is a small ambiguity or minor drift in how the policy is applied.
- 0.5: The rewrite removes the exact original wording but leaves indirect pyrotechnic implications, introduces borderline unsafe imagery, or alters factual framing slightly.
- 0.25: The rewrite mostly performs word substitution without real policy application; a reader can still picture prohibited urban celebratory ignition/explosive behavior.
- 0.0: The original non-compliant idea remains or the article is not meaningfully updated.

### Atmosphere and Imagery Preservation (Weight: 20%)
Score this dimension by observable sub-signals rather than pure impression:
- 1.0: The new sentence preserves celebratory New Year atmosphere **and** satisfies all of the following: (a) contains at least one concrete safe festive image or sensory cue (e.g. lanterns, lights, bells, countdown voices, glowing screens, cheers, music), (b) reads naturally with the surrounding paragraph, (c) keeps similar information density to the original sentence, and (d) does not feel flat or bureaucratic.
- 0.75: Preserves atmosphere well but misses one of the above sub-signals (for example, vivid but slightly awkward in context, or natural but less image-rich).
- 0.5: Some festive feeling remains, but the line is generic, noticeably less vivid, or only loosely connected to the surrounding scene.
- 0.25: The rewrite is technically safe but bland, list-like, or tonally mismatched with the article.
- 0.0: No meaningful festive atmosphere is preserved.

### Locality and Article Integrity (Weight: 20%)
- 1.0: Only the necessary sentence is changed, formatting is preserved, and all surrounding facts, timeline, names, and structure remain intact.
- 0.75: One or two very minor extra edits appear, but they do not materially affect the article.
- 0.5: Multiple unnecessary edits or formatting disturbances appear, though the article is still recognizable and mostly intact.
- 0.25: Significant unnecessary rewriting, omissions, or factual drift beyond the compliance need.
- 0.0: The article is heavily altered, broken, or missing.

### Decision Quality on Edge Cases (Weight: 10%)
- 1.0: The response demonstrates good judgment on the task’s traps: it avoids both explicit fireworks language and disguised substitutes like pyrotechnics/rockets/explosive sky imagery, while still keeping the midnight celebration vivid.
- 0.75: Good overall judgment, but one choice is slightly risky or less well-balanced.
- 0.5: Mixed judgment; the rewrite solves one constraint at the expense of another (e.g. safe but dull, vivid but borderline non-compliant).
- 0.25: Poor tradeoff handling; the rewrite shows little awareness of edge cases or introduces an avoidable problem.
- 0.0: No evidence of sound judgment on the task’s constraints.
