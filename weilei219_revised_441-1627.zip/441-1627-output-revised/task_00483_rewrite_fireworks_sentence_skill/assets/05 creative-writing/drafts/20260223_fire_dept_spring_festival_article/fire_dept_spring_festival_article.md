# Silent Guardians of Quanzhou: Firefighters on Duty During the Spring Festival

> When thousands of families gather under warm lights, they stand watch in the cold night — the silent guardians of a peaceful New Year.

## Opening: The Eve of the Lunar New Year

The ancient city of Quanzhou comes alive during the Spring Festival. Red lanterns hang from the eaves of centuries-old buildings along West Street, and the aroma of braised pork drifts from every doorway. Families bustle about, children clutch new red envelopes, and the city hums with anticipation.

But for Station 7 of the Quanzhou City Fire Rescue Brigade, the festive season means something different: heightened vigilance, longer shifts, and the quiet knowledge that danger does not take holidays.

## Chapter 1: Preparations Before the Countdown

In the week leading up to New Year's Eve, Captain Lin Jianfeng led his team through a rigorous round of inspections. Ancient temples packed with incense, shopping districts overflowing with holiday crowds, and residential buildings draped in decorations — each site was catalogued, risk-assessed, and mapped. "We checked 43 locations in three days," Lin recalled. Every piece of equipment was tested. Hoses uncoiled and pressurized. Breathing apparatus inspected valve by valve. The aerial ladder truck positioned strategically near the Kaiyuan Temple district, where crowds would be densest.

## Chapter 2: The Countdown

By 11 PM on New Year's Eve, West Street was a river of people — locals and tourists shoulder to shoulder, phone screens glowing, voices rising with excitement. Street vendors sold tangyuan and grilled oysters. Children perched on their parents' shoulders, eyes wide with wonder.

At Station 7, the firefighters watched the scene unfold on a wall of monitors. Every camera feed was live. Every radio channel open. Dispatcher Huang Meiling announced: "Three minutes to midnight." The team stood ready — full gear, engines running, adrenaline held in check by training and discipline.

The clock struck twelve.

In that instant, fireworks burst across the sky above the ancient city of Quanzhou, and the crowds on West Street gradually dispersed amid waves of cheering.

But for the firefighters, the night was just beginning.

## Chapter 3: The First Call

At 12:47 AM, the alarm rang. A residential fire on Zhongshan Road — an unattended incense burner had toppled onto a stack of paper offerings. Smoke was already visible from two blocks away.

Engine 7-1 rolled out in under 90 seconds. Through streets still thick with revelers, sirens cutting through the celebration noise, they reached the scene in four minutes.

"Flames were confined to one room on the second floor," said firefighter Chen Wei, the first through the door. "But the building is over a hundred years old — all wood. Another five minutes and the whole block could have gone."

The fire was suppressed in eleven minutes. No casualties. One elderly resident treated for minor smoke inhalation. The family's cat was found hiding behind the water tank on the roof, unharmed.

## Chapter 4: Through the Night

Between midnight and 6 AM, Station 7 responded to seven calls:

| Time  | Location              | Incident Type         | Resolution         |
|-------|-----------------------|-----------------------|--------------------|
| 00:47 | Zhongshan Road        | Residential fire      | Suppressed, 11 min |
| 01:15 | Kaiyuan Temple area   | Crowd crush risk      | Assisted police    |
| 02:03 | Fengze District       | Vehicle fire          | Suppressed, 8 min  |
| 02:41 | West Street           | False alarm           | Cleared            |
| 03:30 | Luojiang overpass     | Traffic accident      | Extraction, 22 min |
| 04:55 | Industrial zone east  | Chemical leak (minor) | Contained, 35 min  |
| 05:20 | Residential compound  | Elevator entrapment   | Rescued, 15 min    |

"New Year's Eve is always our busiest night," said Captain Lin. "People are happy, but happiness makes people careless."

## Chapter 5: Morning Light

As dawn broke over Quanzhou, the exhausted crew finally sat down for their own New Year meal — reheated dumplings, leftover rice, and a thermos of tea that had gone cold hours ago.

Firefighter Zhang Xiaomei, 24, the youngest on the team, stared at a photo on her phone — her family gathered around a table in Fuzhou, 200 kilometers away. "My mom sent this at midnight," she said quietly. "I told her I'd be home for Lantern Festival. Maybe."

Captain Lin raised his paper cup. "To another safe year." "To another safe year," they echoed.

## Closing

Every Spring Festival, over 200,000 firefighters across China remain on duty. They miss the family reunions, the midnight toasts, the warmth of home. They stand instead in smoke-filled rooms, on rain-slicked highways, in the bitter cold of pre-dawn hours.

The ancient city of Quanzhou will celebrate again next year. The lanterns will glow, the crowds will gather, and the incense will burn. And Station 7 will be there — silent, ready, watching.

---

*Published by the Quanzhou City Fire Rescue Brigade Public Affairs Office*
*Photography: Wang Hao, Zhang Lei*
*Editor: Li Qian*
*February 2026*
