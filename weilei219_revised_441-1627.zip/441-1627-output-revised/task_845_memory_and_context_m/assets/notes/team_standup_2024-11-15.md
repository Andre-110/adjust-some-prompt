# Team Standup Notes — November 15, 2024

**Facilitator:** Alex Rivera  
**Attendees:** Alex R., Priya M., Jason T., Lisa K., Omar B., Sarah C.  
**Time:** 9:15 AM – 9:35 AM UTC  

---

## Sprint 47 — Day 5 of 10

### Alex Rivera (Engineering Manager)
- Sprint velocity looking good — 34 of 55 story points completed
- Reminder: sprint demo is next Friday, need volunteers to present
- Action item: everyone update JIRA tickets by EOD

### Priya Mehta (Frontend)
- Completed the notification preferences panel (FEAT-1234)
- Starting work on the dashboard redesign mockups today
- Blocked on design assets from the UX team — pinged them yesterday, no response yet
- **Note:** memory system had a brief outage Tuesday around 3 PM UTC, back up within 20 minutes. No user-facing impact since we had the loading fallback in place.

### Jason Torres (Backend)
- Finished the batch export API endpoint (FEAT-1198)
- Working on rate limiting for the public API — should be done by Wednesday
- Found a bug in the CSV export where dates were formatted inconsistently (BUG-892) — quick fix, will push today
- Need to coordinate with DevOps on the staging environment refresh

### Lisa Kim (QA)
- Regression test suite passed for the 2.3.1 release candidate
- Found 2 minor UI bugs in the settings page — filed BUG-893 and BUG-894
- Starting performance testing for the batch export feature tomorrow
- Question: are we still targeting 99th percentile latency under 2 seconds for the export?

### Omar Bashir (DevOps)
- Kubernetes cluster upgrade to 1.28 completed over the weekend — no issues
- Monitoring dashboards updated with new alerting thresholds
- Working on the CI/CD pipeline optimization — build times down from 12 min to 8 min
- Will schedule staging environment refresh for Thursday

### Sarah Chen (ML/Platform)
- Reviewing research papers on retrieval fusion strategies (ongoing)
- Updated the embedding model evaluation script
- Will present findings at next week's architecture review meeting

---

## Discussion Items

### Office Snack Preferences Survey Results
Alex shared the results of last week's snack survey:
- **Top choices:** Trail mix (8 votes), Dark chocolate (7 votes), Hummus & veggies (6 votes), Granola bars (5 votes)
- **Controversial:** Jason's suggestion of "just more coffee" received 4 votes but Lisa pointed out we already have 3 coffee machines
- Omar requested spicy chips be added to the rotation
- **Decision:** Alex will order trail mix, dark chocolate, and hummus for next week. Rotating selection monthly.
- Priya volunteered to manage the snack calendar for December

### Sprint Demo Prep
- Jason will demo the batch export API
- Priya will demo the notification preferences panel
- Lisa will present the QA metrics dashboard she's been building
- Demo order: Priya → Jason → Lisa (15 min each)

### Holiday Schedule
- Reminder: Thanksgiving break Nov 28-29 (US team)
- Sprint 48 will be shortened to accommodate
- Alex will adjust sprint capacity accordingly

---

## Action Items
| Owner | Action | Due |
|-------|--------|-----|
| All | Update JIRA tickets | EOD today |
| Alex | Order snacks | Nov 18 |
| Jason | Fix BUG-892 | Nov 15 |
| Omar | Staging refresh | Nov 21 |
| Sarah | Fusion research presentation | Nov 22 |
| Priya | Follow up with UX team | Nov 15 |

---

*Next standup: Monday, November 18, 2024 at 9:15 AM UTC*
