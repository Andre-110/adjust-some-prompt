# LLM Provider Vendor Comparison

**Prepared by:** Jason Torres, Backend Engineering  
**Date:** 2024-11-05  
**Purpose:** Evaluate LLM providers for our assistant platform's next contract renewal  

---

## Overview

We're evaluating four LLM providers for our 2025 contract. Key considerations include pricing, context window size, latency, and fine-tuning capabilities. Note that larger context windows could theoretically reduce our dependency on the memory retrieval system by stuffing more context directly into prompts, but this approach has cost and latency trade-offs.

---

## Provider Comparison

| Feature | NovaMind AI | CortexLabs | DeepStream | SynthIQ |
|---------|-------------|------------|------------|---------|
| **Model Tier** | Nova-7B / Nova-70B | Cortex-Pro / Cortex-Ultra | DS-Medium / DS-Large | SIQ-Standard / SIQ-Premium |
| **Context Window** | 32K / 128K tokens | 16K / 64K tokens | 64K / 200K tokens | 32K / 100K tokens |
| **Input Cost (per 1M tokens)** | $0.80 / $3.50 | $1.20 / $5.00 | $0.60 / $4.20 | $1.00 / $3.80 |
| **Output Cost (per 1M tokens)** | $2.40 / $10.50 | $3.60 / $15.00 | $1.80 / $12.60 | $3.00 / $11.40 |
| **Avg Latency (TTFT)** | 180ms / 420ms | 250ms / 600ms | 150ms / 380ms | 200ms / 500ms |
| **Avg Latency (per token)** | 12ms / 18ms | 15ms / 22ms | 10ms / 16ms | 14ms / 20ms |
| **Fine-tuning Available** | Yes (both tiers) | Yes (Ultra only) | Yes (both tiers) | No |
| **Fine-tuning Cost** | $25/hr GPU time | $40/hr GPU time | $18/hr GPU time | N/A |
| **Min Fine-tuning Data** | 500 examples | 1,000 examples | 200 examples | N/A |
| **SLA Uptime** | 99.9% | 99.5% | 99.9% | 99.7% |
| **Data Residency** | US, EU | US only | US, EU, APAC | US, EU |
| **Batch API** | Yes | No | Yes | Yes |
| **Streaming** | Yes | Yes | Yes | Yes |

---

## Detailed Notes

### NovaMind AI
- Strong all-around option with competitive pricing
- 128K context window on Nova-70B is generous
- Fine-tuning workflow is well-documented
- Good developer experience — SDK supports Python, Node.js, Go
- **Concern:** Recent reports of occasional quality degradation during peak hours

### CortexLabs
- Most expensive option across the board
- Fine-tuning only available on Ultra tier ($40/hr is steep)
- Best-in-class safety filtering (important for enterprise)
- Limited data residency options (US only)
- **Concern:** 99.5% SLA is lower than competitors; we've seen outages

### DeepStream
- Cheapest input pricing and competitive fine-tuning costs
- Largest context window at 200K tokens on DS-Large
- Lowest latency across both tiers
- Most flexible data residency options
- **Concern:** Newer provider, less track record. API breaking changes in last 6 months.
- Fine-tuning with only 200 examples is appealing for quick iteration

### SynthIQ
- Mid-range pricing with no fine-tuning option
- 100K context window on Premium is solid
- Good reliability track record
- **Concern:** No fine-tuning means we can't customize for our domain
- Best option if we want a "set and forget" provider

---

## Context Window vs. Memory Retrieval Trade-off

An important consideration: with larger context windows (128K–200K tokens), we could potentially reduce reliance on the memory retrieval system by including more raw context in each prompt. However:

1. **Cost implications:** Stuffing 100K tokens per query at $3.50–$4.20/M input tokens = $0.35–$0.42 per query. At 2,300 queries/day, that's $800–$970/day just for input tokens.
2. **Latency:** Larger contexts increase TTFT significantly (roughly linear with context size)
3. **Quality:** "Lost in the middle" problem — LLMs tend to ignore information in the middle of very long contexts
4. **Not a replacement:** Context stuffing doesn't help with structured queries (relationships, entity lookups) that the graph DB handles well

**Conclusion:** Larger context windows are complementary to, not a replacement for, a good memory retrieval system.

---

## Fine-tuning Cost Estimates

If we fine-tune for our domain (memory-augmented Q&A):

| Provider | Training Data | Est. Training Time | Est. Cost |
|----------|--------------|-------------------|-----------|
| NovaMind (70B) | 5,000 examples | 8 hours | $200 |
| CortexLabs (Ultra) | 5,000 examples | 6 hours | $240 |
| DeepStream (Large) | 5,000 examples | 10 hours | $180 |
| SynthIQ | N/A | N/A | N/A |

Fine-tuning could improve the LLM's ability to synthesize results from multiple memory sources, but this is a separate concern from the retrieval/fusion layer itself.

---

## Recommendation

**Short-term (Q1 2025):** Continue with current provider (NovaMind Nova-70B). Pricing is competitive and fine-tuning is available.

**Evaluate for Q2:** DeepStream DS-Large for the 200K context window and lower pricing. Wait for their API to stabilize.

**Not recommended:** CortexLabs (too expensive, limited fine-tuning) and SynthIQ (no fine-tuning option limits our ability to optimize).

---

*Note: This comparison is for the LLM inference layer only. Memory retrieval architecture decisions are tracked separately in the platform engineering proposals.*
