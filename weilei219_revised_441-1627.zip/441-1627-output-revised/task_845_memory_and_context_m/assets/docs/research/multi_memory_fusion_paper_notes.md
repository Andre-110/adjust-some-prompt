# Research Notes: Multi-Memory Fusion Strategies for AI Assistants

**Reviewed by:** Sarah Chen, Platform Engineering  
**Date:** 2024-10-28  
**Papers Reviewed:** 5 papers + 2 blog posts from industry practitioners  

---

## 1. Retrieval-Augmented Generation (RAG) Fusion Approaches

### Overview
Traditional RAG uses a single retrieval source (typically a vector store). Multi-source RAG extends this by querying multiple heterogeneous memory systems and fusing results before passing to the LLM context.

### Key Insight
The fundamental challenge is that different memory systems have different **recall profiles**:
- Vector stores excel at semantic similarity but miss structured relationships
- Graph databases capture explicit relationships but require precise entity references
- Keyword/file search catches exact matches that embedding models may miss

No single system achieves >75% recall across all query types in the benchmarks reviewed.

---

## 2. Reciprocal Rank Fusion (RRF)

### Method
RRF combines ranked lists from multiple retrieval systems using the formula:

```
RRF_score(d) = Σ 1 / (k + rank_i(d))
```

Where `k` is a constant (typically 60) and `rank_i(d)` is the rank of document `d` in the i-th retrieval system's results.

### Findings
- **Recall improvement: 15–23%** over single-source retrieval in controlled benchmarks
- Works best when retrieval systems have **complementary** coverage (low overlap)
- Degrades when one system returns mostly noise (need quality filtering before fusion)
- Simple to implement — no training data required
- Computational overhead is minimal (microseconds for rank fusion)

### Applicability to Our System
High. Our three systems have relatively low overlap (15–25% based on content analysis). RRF would be a strong baseline fusion strategy.

---

## 3. Learned Routing with Classifier Models

### Method
Train a lightweight classifier to predict which memory system(s) are most likely to contain the answer for a given query. Can route to one system (efficiency) or multiple (recall).

### Findings
- Achieves **89% routing accuracy** after training on **10,000 labeled query-route pairs**
- Lightweight models (logistic regression or small neural net) add <5ms latency
- Requires labeled training data — cold start problem
- Can be combined with RRF: route to top-2 predicted systems, then fuse results
- Degrades on out-of-distribution queries (new topics not seen in training)

### Applicability to Our System
Medium-term. We have query logs that could be labeled retrospectively. The 40% follow-up query rate in our logs provides natural signal for when routing was wrong.

---

## 4. Parallel Retrieval with Re-ranking

### Method
Query all memory systems in parallel, collect results, then apply a cross-encoder or LLM-based re-ranker to select the best results.

### Findings
- **Adds 80–150ms latency** depending on the slowest retrieval system and re-ranker complexity
- Achieves highest recall (often 90%+) but at significant latency cost
- Re-ranking quality depends heavily on the re-ranker model
- Can be optimized with:
  - Timeout-based cutoffs (return whatever is ready by deadline)
  - Caching frequent queries
  - Async retrieval with streaming results

### Latency Breakdown (from benchmarks)
| Component | Latency |
|-----------|---------|
| Parallel retrieval (max of all systems) | 40–120ms |
| Result deduplication | 5–10ms |
| Cross-encoder re-ranking (top 30 results) | 30–80ms |
| **Total** | **80–150ms** |

### Applicability to Our System
Feasible within our 500ms latency budget, but tight. Our slowest system (files) has P99 of 420ms, which would need optimization or timeout handling.

---

## 5. Graph-Enhanced RAG

### Method
Use graph traversal to enrich vector search results with structured context. After retrieving semantically similar documents, extract entities and traverse the knowledge graph to find related context.

### Findings
- Particularly effective for **multi-hop reasoning** queries
- Improves answer completeness by 25–35% for relationship-heavy queries
- Adds 20–60ms latency for graph enrichment step
- Requires entity linking between vector store documents and graph nodes
- Works poorly when graph coverage is sparse for the query domain

### Applicability to Our System
High for relationship queries. Our graph has good coverage (12,400 nodes, 38,700 edges). Entity linking between vector docs and graph nodes would need to be built.

---

## 6. Trade-offs Summary

| Strategy | Recall Gain | Latency Added | Implementation Complexity | Training Data Needed |
|----------|-------------|---------------|--------------------------|---------------------|
| RRF | +15–23% | +5–15ms | Low | None |
| Learned Router | +10–18% | +3–5ms | Medium | 10K+ samples |
| Parallel + Re-rank | +25–35% | +80–150ms | High | None (but benefits from fine-tuning) |
| Graph-Enhanced RAG | +25–35% (relationship queries) | +20–60ms | Medium | Entity linking setup |

### Recommended Approach (from literature)
Most papers recommend a **staged approach**:
1. Start with RRF as baseline (quick win, no training data)
2. Add learned routing to reduce unnecessary parallel queries
3. Implement graph enrichment for relationship-heavy query types
4. Use parallel retrieval with re-ranking for high-value queries where latency is acceptable

---

## 7. Relevant References

1. "Reciprocal Rank Fusion Outperforms Condorcet and Individual Rank Learning Methods" — Cormack et al., SIGIR 2009
2. "Retrieval-Augmented Generation for Knowledge-Intensive NLP Tasks" — Lewis et al., NeurIPS 2020
3. "Adaptive Retrieval-Augmented Generation with Multi-Source Fusion" — Zhang et al., EMNLP 2023
4. "Graph-Enhanced Retrieval for Question Answering" — Yasunaga et al., NAACL 2022
5. "Learning to Route in Mixture-of-Experts Retrieval Systems" — Wang et al., ACL 2024

---

## Open Questions for Our Implementation

- How do we handle the cold start for learned routing? Can we use the follow-up query logs as weak supervision?
- What's the right timeout strategy for parallel retrieval given our 500ms budget?
- Should we invest in entity linking between vector docs and graph nodes first?
- Can we use Redis (available but unused) as a fusion cache layer?
- How do we evaluate fusion quality? Need to establish a benchmark dataset.
