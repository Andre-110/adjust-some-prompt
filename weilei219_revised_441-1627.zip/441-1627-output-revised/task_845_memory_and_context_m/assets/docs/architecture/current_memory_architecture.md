# Current Memory System Architecture

**Document Version:** 2.4  
**Last Updated:** 2024-11-10  
**Owner:** Platform Engineering Team  

---

## Overview

The memory system serves as the persistent knowledge layer for our AI assistant platform. It currently operates as **three independent memory stores** with no automated cross-referencing or fusion between them. Each store is optimized for a different retrieval pattern.

The system handles approximately **2,300 queries per day** across all three stores, with peak load occurring between 9:00–11:00 AM and 2:00–4:00 PM UTC.

### System Diagram (Logical)

```
┌──────────────┐     ┌──────────────┐     ┌──────────────┐
│  Vector DB   │     │   Graph DB   │     │  File Notes  │
│  (ChromaDB)  │     │   (Neo4j)    │     │  (/notes/)   │
└──────┬───────┘     └──────┬───────┘     └──────┬───────┘
       │                    │                    │
       └────────────────────┼────────────────────┘
                            │
                    ┌───────┴───────┐
                    │ Query Router  │
                    │ (rule-based)  │
                    └───────┬───────┘
                            │
                    ┌───────┴───────┐
                    │   User/Agent  │
                    └───────────────┘
```

Each query is routed to **exactly one** memory store based on simple heuristic rules. There is no parallel retrieval or result fusion.

---

## Vector Memory (ChromaDB)

### Configuration
- **Database:** ChromaDB v0.4.15
- **Embedding Model:** all-MiniLM-L6-v2 (sentence-transformers)
- **Embedding Dimensions:** 768
- **Distance Metric:** Cosine similarity
- **Index Type:** HNSW (Hierarchical Navigable Small World)
- **Collection Count:** 14 collections (organized by domain)

### Performance Metrics
| Metric | Value |
|--------|-------|
| Average Recall@10 | 72% |
| Average Recall@5 | 62% |
| Average Precision@5 | 58% |
| Average Latency | 45ms |
| P99 Latency | 112ms |
| Total Embedded Documents | 34,200 |
| Average Document Length | 480 tokens |

### Known Limitations
- Recall degrades as corpus size increases (observed ~2% decline per 5,000 new documents)
- Poor performance on procedural/how-to queries (recall drops to ~55%)
- Creative and open-ended queries have lowest recall (~41%)
- No metadata filtering currently implemented
- Embedding model has a 256-token input limit; longer documents are chunked with 50-token overlap

---

## Graph Memory (Neo4j)

### Configuration
- **Database:** Neo4j Community Edition 5.12
- **Total Nodes:** 12,400
- **Total Edges (Relationships):** 38,700
- **Node Labels:** Person, Project, Technology, Decision, Meeting, Document, Process, Client
- **Relationship Types:** WORKS_ON, DECIDED_BY, USES, RELATED_TO, ATTENDED, AUTHORED, DEPENDS_ON, REPORTS_TO, CONTRACTED_WITH
- **Storage Format:** Entity-relationship triples

### Performance Metrics
| Metric | Value |
|--------|-------|
| Entity Lookup Accuracy | 92% |
| Path Finding Accuracy | 78% |
| Neighborhood Query Accuracy | 74% |
| Pattern Match Accuracy | 61% |
| Average Latency (1-hop) | 18ms |
| Average Latency (2-hop) | 55ms |
| Average Latency (3+ hop) | 120ms |

### Known Limitations
- Pattern matching queries are slow and unreliable for complex patterns
- No natural language interface; requires Cypher query construction
- Entity resolution is imperfect — approximately 3.2% duplicate nodes detected
- Relationship weights/confidence scores not implemented
- Graph is updated via batch process every 6 hours (not real-time)

---

## File Notes

### Configuration
- **Storage:** Markdown files in `/notes/` directory
- **Total Files:** 847
- **Search Method:** Keyword search only (no semantic search)
- **Index:** Basic inverted index rebuilt nightly
- **File Types:** Meeting notes, decision logs, process documentation, personal notes, project briefs

### Performance Metrics
| Metric | Value |
|--------|-------|
| Keyword Match Recall | ~58% (estimated) |
| Title Match Recall | ~71% |
| Average Latency | 180ms |
| P99 Latency | 420ms |
| Index Freshness | Updated nightly at 02:00 UTC |

### Known Limitations
- Keyword search only — no semantic understanding
- No tag standardization across files
- Many files have inconsistent naming conventions
- Search does not handle synonyms or abbreviations
- Recently added files (last 24h) may not appear in search results due to nightly indexing

---

## Current Fusion Strategy

**Status: No automated fusion**

The current "fusion strategy" is **manual lookup by user**. When the initial query to one memory system does not return satisfactory results, the user must:

1. Identify which alternative system might have the answer
2. Manually reformulate the query for that system's interface
3. Mentally synthesize results from multiple lookups

There is **no automated cross-referencing** between the three memory stores. Each query hits exactly one system, determined by the rule-based router (see `config/memory_routing.json`).

### Impact
- User satisfaction surveys indicate an average score of **2.8/5.0** for recall quality
- Approximately **62%** of users report having to manually search a second system
- An estimated **35-40%** of queries would benefit from multi-source retrieval
- Average time to find complete information: **3.2 minutes** (vs. target of <30 seconds)

---

## Query Volume and Distribution

| Memory System | Daily Queries | % of Total |
|---------------|--------------|------------|
| Vector DB | 1,150 | 50% |
| Graph DB | 690 | 30% |
| File Notes | 460 | 20% |
| **Total** | **2,300** | **100%** |

Peak concurrent requests: ~45 (observed during 10:00 AM UTC)

---

## Infrastructure

- **Deployment:** Kubernetes (3-node cluster)
- **Total Memory Allocation:** 24 GB (of 32 GB budget)
- **CPU Allocation:** 12 vCPUs (of 16 budget)
- **Monthly Cost:** ~$1,850 (of $2,400 ceiling)
- **Uptime (last 30 days):** 99.7%

---

## Revision History

| Date | Version | Change |
|------|---------|--------|
| 2024-11-10 | 2.4 | Updated node/edge counts for graph DB |
| 2024-09-22 | 2.3 | Added file notes corpus size after migration |
| 2024-07-15 | 2.2 | Updated vector recall metrics |
| 2024-05-01 | 2.1 | Added infrastructure section |
| 2024-03-10 | 2.0 | Major rewrite after Neo4j upgrade |
