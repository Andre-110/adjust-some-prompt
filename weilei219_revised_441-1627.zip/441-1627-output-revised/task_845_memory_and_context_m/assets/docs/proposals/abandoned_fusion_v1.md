# Memory Fusion Proposal v1 — Sequential Multi-Source Retrieval

**Author:** David Park, Platform Engineering  
**Date:** 2024-03-15  
**Status:** ~~PROPOSED~~ **REJECTED**

---

## Executive Summary

This proposal outlines a straightforward approach to improving memory recall by sequentially querying all three memory systems (Vector DB → Graph DB → File Notes) and concatenating the results. This approach requires minimal architectural changes and can be implemented within 2 sprints.

## Motivation

Users frequently report incomplete answers when the system only queries a single memory store. Our current graph database contains **3,200 nodes** and **9,800 edges**, which provides good entity coverage but misses semantic context. By combining results from all three systems, we can achieve near-complete recall.

## Proposed Architecture

```
User Query
    │
    ▼
┌─────────────┐
│ Vector Search │  ──→  Results A (semantic matches)
│   (~45ms)     │
└──────┬────────┘
       │
       ▼
┌─────────────┐
│ Graph Query   │  ──→  Results B (entity/relationship matches)
│   (~120ms)    │
└──────┬────────┘
       │
       ▼
┌─────────────┐
│ File Search   │  ──→  Results C (keyword matches)
│   (~180ms)    │
└──────┬────────┘
       │
       ▼
┌─────────────────┐
│ Concatenate A+B+C │  ──→  Combined Results
│ (dedup by ID)     │
└───────────────────┘
```

### Sequential Flow
1. Query Vector DB with semantic embedding → collect top 10 results
2. Query Graph DB with extracted entities → collect matching nodes/paths
3. Query File Notes with keywords → collect matching files
4. Concatenate all results, remove duplicates by document ID
5. Return combined result set (up to 30 items)

## Expected Performance

Based on our analysis of the current corpus:
- **Expected Recall:** ~95% (union of all three systems covers nearly everything)
- **Expected Latency:** ~345ms (sum of averages: 45 + 120 + 180)
- **Expected Result Set Size:** 15-30 items per query

The 95% recall estimate comes from the fact that our three systems collectively index all content in the knowledge base. By querying all three, we should capture virtually every relevant result.

## Implementation Plan

1. **Sprint 1:** Build sequential query orchestrator
   - Implement query pipeline with error handling
   - Add deduplication logic based on document IDs
   - Basic concatenation (vector results first, then graph, then files)

2. **Sprint 2:** Testing and optimization
   - Benchmark against current single-source approach
   - Tune result limits per source
   - Add basic timeout handling

## Cost Impact

- Additional compute: ~4 vCPUs for orchestrator service
- Additional latency: ~300ms per query (sequential overhead)
- No new database licenses required
- Estimated monthly cost increase: ~$200

## Risks

- Latency may exceed acceptable thresholds for real-time use
- Concatenation without ranking may produce noisy results
- Graph DB queries require entity extraction which may fail for vague queries

---

## Review Feedback

### Review by: Maria Santos, Tech Lead — 2024-03-22

> The sequential approach is too slow. Adding 300ms to every query is not acceptable for our real-time use case. We need the total latency to stay under 500ms including LLM processing time.

### Review by: James Liu, ML Engineer — 2024-03-24

> The 95% recall claim is unrealistic. It assumes perfect deduplication and that all three systems have non-overlapping coverage. In practice, concatenation without re-ranking will surface a lot of irrelevant results, hurting precision significantly. We need a smarter fusion strategy.

### Review by: Platform Architecture Board — 2024-03-28

> **Decision: REJECTED**

---

## ⚠️ REJECTED

**REJECTED: Sequential approach adds 400ms+ latency (P99 would be even higher), exceeding our latency budget. Simple concatenation without re-ranking produces noisy results with poor precision. The 95% recall claim was not validated and is likely overstated — it doesn't account for query reformulation failures across systems. The graph node count of 3,200 is also already outdated as we're in the middle of a major graph expansion. Revisit with a better fusion strategy that considers parallel retrieval, intelligent routing, and result re-ranking.**

*This proposal is archived for reference. Do not implement.*
