# Calculator Demo

A minimal Python project used to demonstrate `pytest` testing patterns.

## Project Structure

```
├── src/
│   ├── calculator.py      # Core calculator functions
│   └── string_utils.py    # String helper utilities
├── tests/                 # Test directory (add your tests here)
├── pyproject.toml         # Project config & pytest settings
└── README.md
```

## Running Tests

```bash
pip install -e ".[dev]"
pytest
```

## Task

Generate a simple pytest example test file under `tests/` that covers the calculator module.
