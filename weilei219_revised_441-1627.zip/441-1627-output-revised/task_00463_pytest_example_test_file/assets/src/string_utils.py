"""String utility functions — helper module (not the main focus)."""


def reverse_string(s: str) -> str:
    """Return the reversed version of a string."""
    return s[::-1]


def is_palindrome(s: str) -> bool:
    """Check whether a string is a palindrome (case-insensitive)."""
    cleaned = s.lower().replace(" ", "")
    return cleaned == cleaned[::-1]


def word_count(text: str) -> int:
    """Count the number of words in a text."""
    return len(text.split())


def capitalize_words(text: str) -> str:
    """Capitalize the first letter of each word."""
    return text.title()
