---
id: task_00463_pytest_example_test_file
name: Generate a Simple Pytest Example Test File
category: System Administration
subcategory: Software and Environment Management
difficulty: medium
grading_type: automated
grading_weights: {automated: 1.0}
timeout_seconds: 600
input_modality: text-only
external_dependency: none
workspace_files: []
skill_creation: false
---

## Prompt

I have a small Python project in this workspace. Please add a pytest test file under `tests/` for the existing calculator module.

Use the project files that are already present rather than inventing your own demo code. The test file should target `src/calculator.py`, be discoverable by pytest, and be runnable in this project as-is. I want something that looks like a realistic starter test file for this repo, not a generic standalone pytest example.

A few notes:
- Make sure the tests actually exercise calculator behavior from the repo.
- Include at least one test for the error behavior of division by zero.
- Prefer clear, maintainable tests over filler.
- You may choose the exact filename and structure.

## Expected Behavior

The agent should create a pytest test file under `tests/` that is meaningfully tied to the repository's existing calculator module and can run successfully in the provided project.

A strong solution should do all of the following:

1. **Place the file in the correct location**
   - Create a file under `tests/` with a pytest-discoverable name such as `tests/test_calculator.py`.

2. **Import and test the real project module**
   - The test file should import from the actual calculator implementation in `src/calculator.py`.
   - Acceptable import styles include:
     - `from src.calculator import add, subtract, multiply, divide, power`
     - `import src.calculator as calculator`
   - The tests should not be generic toy examples unrelated to the repository.

3. **Cover multiple real calculator functions**
   - The tests should exercise at least 3 different functions from:
     - `add`
     - `subtract`
     - `multiply`
     - `divide`
     - `power`
   - Assertion values must match the real implementation in `src/calculator.py`.

4. **Handle the division-by-zero trap correctly**
   - `src/calculator.py` raises **`ValueError`** when `divide(..., 0)` is called.
   - A correct exception test should therefore use `pytest.raises(ValueError)`.
   - Using `ZeroDivisionError` is incorrect and should fail under real pytest execution.

5. **Be executable by pytest**
   - The generated tests should be syntactically valid and should pass when `pytest tests/ -v` is run in the project.
   - This means imports, assertions, exception types, and file placement must all be correct.

6. **Demonstrate at least minimal test quality**
   - The file should contain at least 3 pytest test functions.
   - At least one meaningful edge or boundary-oriented assertion is desirable, such as:
     - `divide(0, 1) == 0`
     - `power(0, 0) == 1`
     - sign handling like `multiply(-2, 3) == -6`
   - Higher-quality solutions may use `@pytest.mark.parametrize` for compactness and readability, but this is optional.

## Grading Criteria

- [ ] A pytest-discoverable test file exists under `tests/`
- [ ] The test file imports and uses the real `src.calculator` module
- [ ] The test file contains at least 3 pytest test functions
- [ ] The tests correctly cover at least 3 different calculator functions
- [ ] The file includes at least one correct `pytest.raises(ValueError)` test for division by zero
- [ ] The assertions match the real calculator behavior
- [ ] The tests pass under actual `pytest tests/ -v` execution
- [ ] The test file shows at least one quality signal, such as a boundary case or use of parametrization

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    import ast
    import subprocess
    import sys
    from pathlib import Path

    scores = {
        "test_file_in_tests_dir": 0.0,
        "imports_real_calculator_module": 0.0,
        "has_minimum_test_functions": 0.0,
        "covers_multiple_calculator_functions": 0.0,
        "correct_valueerror_exception_test": 0.0,
        "correct_behavior_assertions": 0.0,
        "pytest_execution_passes": 0.0,
        "test_quality_signal": 0.0,
    }

    workspace = Path(workspace_path)
    tests_dir = workspace / "tests"
    if not tests_dir.exists():
        return scores

    test_files = sorted(tests_dir.glob("test_*.py"))
    if not test_files:
        return scores

    scores["test_file_in_tests_dir"] = 1.0

    target_file = None
    parsed_trees = {}

    for test_file in test_files:
        try:
            content = test_file.read_text(encoding="utf-8")
            tree = ast.parse(content)
            parsed_trees[test_file] = tree
        except Exception:
            continue

    if not parsed_trees:
        return scores

    def imports_src_calculator(tree: ast.AST) -> bool:
        for node in ast.walk(tree):
            if isinstance(node, ast.ImportFrom):
                if node.module == "src.calculator":
                    return True
            elif isinstance(node, ast.Import):
                for alias in node.names:
                    if alias.name == "src.calculator":
                        return True
        return False

    def get_called_names(expr):
        names = set()
        for node in ast.walk(expr):
            if isinstance(node, ast.Call):
                func = node.func
                if isinstance(func, ast.Name):
                    names.add(func.id)
                elif isinstance(func, ast.Attribute):
                    names.add(func.attr)
        return names

    calculator_functions = {"add", "subtract", "multiply", "divide", "power"}
    covered_functions = set()
    has_valueerror_raises = False
    has_zero_division_raises = False
    behavior_hits = set()
    quality_signal = False
    max_test_func_count = 0
    imported_any = False

    expected_checks = {
        ("add", (2, 3), 5),
        ("subtract", (5, 3), 2),
        ("multiply", (4, 3), 12),
        ("divide", (8, 2), 4),
        ("power", (2, 3), 8),
        ("divide", (0, 1), 0),
        ("power", (0, 0), 1),
        ("multiply", (-2, 3), -6),
        ("subtract", (3, 5), -2),
    }

    for test_file, tree in parsed_trees.items():
        if imports_src_calculator(tree):
            imported_any = True
            if target_file is None:
                target_file = test_file

        test_func_count = 0

        for node in ast.walk(tree):
            if isinstance(node, ast.FunctionDef) and node.name.startswith("test_"):
                test_func_count += 1

                if any(tok in node.name.lower() for tok in ["edge", "boundary", "zero", "negative"]):
                    quality_signal = True

                called = get_called_names(node)
                covered_functions.update(called & calculator_functions)

                for subnode in ast.walk(node):
                    if isinstance(subnode, ast.Assert):
                        test_expr = subnode.test
                        if (
                            isinstance(test_expr, ast.Compare)
                            and len(test_expr.ops) == 1
                            and isinstance(test_expr.ops[0], ast.Eq)
                            and len(test_expr.comparators) == 1
                            and isinstance(test_expr.left, ast.Call)
                        ):
                            call = test_expr.left
                            expected = test_expr.comparators[0]

                            func_name = None
                            if isinstance(call.func, ast.Name):
                                func_name = call.func.id
                            elif isinstance(call.func, ast.Attribute):
                                func_name = call.func.attr

                            if func_name in calculator_functions and len(call.args) == 2:
                                try:
                                    arg_vals = tuple(ast.literal_eval(arg) for arg in call.args)
                                    expected_val = ast.literal_eval(expected)
                                    if (func_name, arg_vals, expected_val) in expected_checks:
                                        behavior_hits.add((func_name, arg_vals, expected_val))
                                        if (func_name, arg_vals, expected_val) in {
                                            ("divide", (0, 1), 0),
                                            ("power", (0, 0), 1),
                                            ("multiply", (-2, 3), -6),
                                            ("subtract", (3, 5), -2),
                                        }:
                                            quality_signal = True
                                except Exception:
                                    pass

                    if isinstance(subnode, ast.With):
                        for item in subnode.items:
                            ctx = item.context_expr
                            if isinstance(ctx, ast.Call):
                                func = ctx.func
                                if isinstance(func, ast.Attribute) and func.attr == "raises":
                                    if func.value.__class__.__name__ == "Name" and getattr(func.value, "id", None) == "pytest":
                                        if ctx.args:
                                            exc_arg = ctx.args[0]
                                            if isinstance(exc_arg, ast.Name):
                                                if exc_arg.id == "ValueError":
                                                    has_valueerror_raises = True
                                                if exc_arg.id == "ZeroDivisionError":
                                                    has_zero_division_raises = True
                                            elif isinstance(exc_arg, ast.Attribute):
                                                if exc_arg.attr == "ValueError":
                                                    has_valueerror_raises = True
                                                if exc_arg.attr == "ZeroDivisionError":
                                                    has_zero_division_raises = True

            elif isinstance(node, ast.AsyncFunctionDef) and node.name.startswith("test_"):
                test_func_count += 1

            elif isinstance(node, ast.Call):
                func = node.func
                if isinstance(func, ast.Name) and func.id in calculator_functions:
                    covered_functions.add(func.id)
                elif isinstance(func, ast.Attribute) and func.attr in calculator_functions:
                    covered_functions.add(func.attr)

            elif isinstance(node, ast.Call):
                func = node.func
                if isinstance(func, ast.Attribute) and func.attr == "parametrize":
                    quality_signal = True

        max_test_func_count = max(max_test_func_count, test_func_count)

    if imported_any:
        scores["imports_real_calculator_module"] = 1.0

    if max_test_func_count >= 3:
        scores["has_minimum_test_functions"] = 1.0
    elif max_test_func_count == 2:
        scores["has_minimum_test_functions"] = 0.5
    elif max_test_func_count == 1:
        scores["has_minimum_test_functions"] = 0.25

    if len(covered_functions) >= 4:
        scores["covers_multiple_calculator_functions"] = 1.0
    elif len(covered_functions) >= 3:
        scores["covers_multiple_calculator_functions"] = 0.8
    elif len(covered_functions) == 2:
        scores["covers_multiple_calculator_functions"] = 0.4
    elif len(covered_functions) == 1:
        scores["covers_multiple_calculator_functions"] = 0.2

    if has_valueerror_raises:
        scores["correct_valueerror_exception_test"] = 1.0
    elif has_zero_division_raises:
        scores["correct_valueerror_exception_test"] = 0.0

    if len(behavior_hits) >= 4:
        scores["correct_behavior_assertions"] = 1.0
    elif len(behavior_hits) == 3:
        scores["correct_behavior_assertions"] = 0.75
    elif len(behavior_hits) == 2:
        scores["correct_behavior_assertions"] = 0.5
    elif len(behavior_hits) == 1:
        scores["correct_behavior_assertions"] = 0.25

    if quality_signal:
        scores["test_quality_signal"] = 1.0

    try:
        result = subprocess.run(
            [sys.executable, "-m", "pytest", "tests", "-v"],
            cwd=str(workspace),
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=120,
        )
        if result.returncode == 0:
            scores["pytest_execution_passes"] = 1.0
    except Exception:
        pass

    return scores
```

## LLM Judge Rubric

Use this rubric only as a supplemental qualitative reference if manual review is needed.

### 1. Task Alignment
- **1.0**: Creates a pytest-discoverable file under `tests/` that clearly targets `src/calculator.py` and fits the repository structure.
- **0.75**: Creates a suitable test file under `tests/` and mostly targets the calculator module, with only minor structural issues.
- **0.5**: Produces a pytest-like file, but repository alignment is partial (e.g., weak or inconsistent use of the real calculator module).
- **0.25**: Produces generic pytest example content with minimal connection to the repo.
- **0.0**: Does not create an appropriate pytest test file.

### 2. Correct Use of Existing Code
- **1.0**: Correctly imports and exercises the real calculator functions from `src/calculator.py`; no invented replacement implementation.
- **0.75**: Mostly uses the real calculator module correctly, with only minor inconsistencies.
- **0.5**: Mixes real-module usage with generic or partially incorrect code.
- **0.25**: Barely references the real module or uses obviously wrong imports.
- **0.0**: Does not use the project’s calculator module.

### 3. Behavioral Correctness
- **1.0**: Assertions are correct for the real implementation, including the division-by-zero behavior using `ValueError`; tests would plausibly pass.
- **0.75**: Most assertions are correct, with at most one minor mistake that does not undermine overall understanding.
- **0.5**: Some correct assertions, but notable mistakes exist in expected values or exception behavior.
- **0.25**: Assertions are mostly generic, weak, or mismatched to the implementation.
- **0.0**: Core assertions are wrong or contradict the actual code.

### 4. Coverage and Test Design
- **1.0**: Covers at least 4 calculator behaviors/functions, including a correct error-path test, and shows thoughtful case selection.
- **0.75**: Covers at least 3 relevant functions including the error path, but with limited breadth or weaker case selection.
- **0.5**: Covers only a small subset of the module or omits an important path.
- **0.25**: Minimal token coverage with little engineering value.
- **0.0**: No meaningful module coverage.

### 5. Quality and Maintainability
- **1.0**: Clear naming, sensible organization, and at least one quality signal such as edge-case coverage or parametrization.
- **0.75**: Generally clean and maintainable, but lacks a stronger quality signal.
- **0.5**: Serviceable but simplistic or repetitive.
- **0.25**: Poorly organized, unclear naming, or filler-heavy.
- **0.0**: Unusable or severely low quality.

### 6. Executability
- **1.0**: The produced file is syntactically valid and likely runs cleanly under pytest in this repo.
- **0.75**: Minor issues may exist, but the file is largely runnable.
- **0.5**: Significant doubts about whether pytest would run successfully.
- **0.25**: Major execution issues are likely.
- **0.0**: Not executable as pytest code.
