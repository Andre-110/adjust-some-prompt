# 修改记录

| 序号 | 修改项 | 修改原因 |
|------|--------|----------|
| 1 | 重写 Prompt，明确要求在 `tests/` 下为现有 `src/calculator.py` 生成可运行的 pytest 测试文件，并自然提到除零异常行为 | 对应问题 1、2；原 Prompt 过于泛化，与 README 脱节，且难度不足 |
| 2 | 重写 Expected Behavior，明确真实模块导入、至少覆盖 3 个 calculator 函数、`divide(..., 0)` 应使用 `ValueError`、测试需可通过 pytest | 对应问题 1、3、4；修正示例异常类型错误并提升可验证性 |
| 3 | 重写 Grading Criteria，新增“真实模块使用”“覆盖多个函数”“正确异常类型”“真实 pytest 运行通过”“测试质量信号”等维度 | 对应问题 1、3、5；提升区分度，避免仅凭模板化测试拿满分 |
| 4 | 重写 Automated Checks：仅接受 `tests/test_*.py`，校验是否导入 `src.calculator`、是否覆盖多个真实函数、是否含 `pytest.raises(ValueError)`、是否断言真实行为，并实际执行 `pytest tests/ -v` | 对应问题 1、3、4；修复原有宽松误判和未运行 pytest 的缺陷 |
| 5 | 删除原 `has_exception_test` 中基于出现 `Error`/`Exception` 字符串给分的宽松兜底逻辑 | 对应问题 3；避免错误文件被误给分 |
| 6 | 增加 LLM Judge Rubric 的细化评分锚点，覆盖任务对齐、真实代码使用、行为正确性、覆盖与设计、可维护性、可执行性 | 对应问题 5；增强人工评审区分度 |
| 7 | 通过更严格的 Prompt、Expected Behavior、Rubric 与 grade() 共同提升任务难度，使其更接近强模型约 60 分的目标 | 对应问题 1；原题难度严重不足 |
