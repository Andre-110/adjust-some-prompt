# 修改记录

| 序号 | 修改项 | 修改原因 |
|------|--------|----------|
| 1 | 将任务难度从 easy 调整为 medium，并重写 Prompt，强调需要基于 workspace 做判断、迁移原型行为、避免盲目继承旧材料 | 对应关键问题 3、6；原题过于模板化，强模型几乎必然满分，需实质提升难度并减少手把手提示 |
| 2 | 重写 Expected Behavior，加入 `python-project/` 位置约束、`pyproject.toml`/Python 3.9+/pytest 约束、旧脚本核心功能迁移、旧依赖选择性继承、测试必须验证真实行为等陷阱与 Ground Truth | 对应关键问题 1、2、3、4、5；将 workspace 材料从装饰变为可验证约束 |
| 3 | 重写 Grading Criteria，增加内容质量与工程判断维度，明确不能只靠文件存在性得分 | 对应关键问题 1、2、5；提升评分门槛与区分度 |
| 4 | 重写 automated `grade()`，严格检查 `python-project/` 子目录、`pyproject.toml` 中 `[project]`/`name`/`version`/`requires-python >=3.9`、pytest 声明、真实源码模块、原型行为迁移、相关测试、README 章节质量、`.gitignore` 模式数量，并检查未盲目引入 `flask`/`gunicorn` | 对应关键问题 1、2、4、5；修复原有浅层检查逻辑，确保基于 assets 实际内容计算 |
| 5 | 调整 grading_weights，增加 `llm_judge` 权重到 0.2 | 对应关键问题 6；让 README/迁移质量/工程判断等语义维度可被评估 |
| 6 | 新增细化的 LLM Judge Rubric，为 1.0/0.75/0.5/0.25/0.0 提供可操作锚点，覆盖上下文利用、原型迁移、测试质量、交付可用性 | 对应关键问题 6 及 Rubric 区分度不足问题 |
