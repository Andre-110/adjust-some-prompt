#!/usr/bin/env python3
"""Quick prototype script - not part of final project structure.

This was used to test API connectivity during early exploration.
Should be removed or migrated into the proper package once scaffolding is done.
"""

import json
import sys


def load_config(path: str) -> dict:
    """Load a JSON configuration file."""
    with open(path, "r") as f:
        return json.load(f)


def main():
    if len(sys.argv) < 2:
        print("Usage: python old_script.py <config.json>")
        sys.exit(1)

    config = load_config(sys.argv[1])
    print(f"Loaded config with {len(config)} keys")
    for key, value in config.items():
        print(f"  {key}: {value}")


if __name__ == "__main__":
    main()
