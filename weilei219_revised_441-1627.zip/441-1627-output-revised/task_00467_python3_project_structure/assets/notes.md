# Project Planning Notes

## Goals
- Set up a clean Python 3 project scaffold
- Include proper testing infrastructure
- Follow PEP 8 and modern best practices

## Decisions
- Use `pytest` as the test runner (not unittest)
- Minimum Python version: 3.9
- Package manager: pip with pyproject.toml preferred over setup.py
- CI: GitHub Actions (to be configured later)

## TODO
- [ ] Finalize project name
- [ ] Create the project structure
- [ ] Add linting config (ruff or flake8)
- [ ] Set up pre-commit hooks
- [ ] Write initial README

## References
- https://packaging.python.org/en/latest/tutorials/packaging-projects/
- https://docs.pytest.org/en/stable/goodpractices.html
