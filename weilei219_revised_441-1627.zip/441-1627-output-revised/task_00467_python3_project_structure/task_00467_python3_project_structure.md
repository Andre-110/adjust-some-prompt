---
id: task_00467_python3_project_structure
name: Generate Python 3 Project Structure
category: System Administration
subcategory: Software and Environment Management
difficulty: medium
grading_type: automated
grading_weights:
  automated: 0.8
  llm_judge: 0.2
timeout_seconds: 600
input_modality: text-only
external_dependency: none
workspace_files:
  - path: notes.md
    role: context
    description: Planning notes with project preferences and decisions
  - path: old_script.py
    role: context
    description: A legacy prototype script from earlier exploration
  - path: requirements-old.txt
    role: context
    description: Legacy requirements from a previous prototype
skill_creation: false
---

## Prompt

I’ve got a messy prototype in this workspace and want it turned into a real Python project that I can keep working on.

Please create the project under a subdirectory named `python-project/`. I want a proper modern Python package layout, tests, and basic project docs/config so the result looks like something I could reasonably continue from.

A few things to keep in mind:
- There are old notes and legacy files in the workspace that reflect earlier decisions and experiments.
- Some of that old material is still relevant, and some of it probably should not be carried forward unchanged.
- I do want the new project to preserve the useful behavior from the prototype in a cleaner package form, rather than just being an empty scaffold.
- Don’t leave the final answer as a loose collection of files in the repo root.

Use your judgment about what belongs in the new package and what should be left behind.

## Expected Behavior

The agent should read the workspace context files and synthesize them into a coherent project under `python-project/`, instead of generating a generic scaffold.

A strong solution will correctly infer and implement the following:

1. **Location and structure must match the request**
   - All newly created project files should live under `python-project/`.
   - The project should contain a real package directory plus tests and project metadata files.
   - A valid structure could use either `python-project/src/<package>/...` or `python-project/<package>/...`, but the package must contain `__init__.py` and at least one real module file beyond `__init__.py`.

2. **Project configuration should reflect workspace preferences**
   - `notes.md` explicitly indicates:
     - use `pyproject.toml` rather than `setup.py`
     - minimum Python version is 3.9
     - `pytest` is the desired test runner
   - Therefore the expected high-quality output includes a `python-project/pyproject.toml` with:
     - a non-empty `[project]` table
     - `name`
     - `version`
     - `requires-python` compatible with Python 3.9+
     - runtime dependencies only if justified
     - `pytest` declared in an appropriate development/test dependency area or tool configuration consistent with pyproject-based workflows

3. **Legacy prototype behavior should be migrated, not copied blindly**
   - `old_script.py` contains meaningful functionality:
     - loading a JSON config file
     - a CLI-like `main()` flow that reads a config path and reports loaded keys
   - The new project should preserve that core behavior in a package module (for example via `load_config`, `main`, or clearly equivalent functions), rather than creating placeholder code.
   - The agent should not merely dump `old_script.py` unchanged into the new project root; the code should be integrated into the package layout and reasonably refactored.

4. **The old requirements file should be used selectively**
   - `requirements-old.txt` mixes prototype/runtime/test/dev/server dependencies.
   - A good answer should **not** blindly copy all of them into the new project.
   - In particular, dependencies unrelated to the migrated functionality from `old_script.py` (such as web/server stack items like `flask` and `gunicorn`) should not appear in the new project config unless the generated code truly uses them.
   - Since the retained prototype behavior only needs JSON + stdlib, a strong answer will usually keep runtime dependencies minimal.

5. **Tests should validate migrated behavior, not just exist**
   - The tests should be relevant to the actual package behavior derived from `old_script.py`.
   - Good examples include testing JSON config loading and/or the CLI/reporting behavior.
   - Merely creating an empty `tests/` directory or a dummy `assert True` test is insufficient for full credit.

6. **README and `.gitignore` should be substantively useful**
   - `README.md` should do more than name the project: it should explain what the tool does and how to install/run/test it.
   - `.gitignore` should include several Python-relevant patterns such as cache, virtualenv, build artifacts, and test/cache outputs.

### Intended traps / judgment points

- The user asked for a modern project structure, so `pyproject.toml` is preferred; using only `setup.py` is a weaker interpretation.
- The workspace notes matter: omitting Python 3.9+ or `pytest` means the agent failed to use available context.
- `requirements-old.txt` is not a list to be copied wholesale; blindly including `flask`/`gunicorn` indicates poor judgment.
- The prototype behavior matters: generating only boilerplate files with placeholder code is not enough.
- The location requirement matters: placing files outside `python-project/` should lose credit.
- The test should reflect actual migrated behavior, not only file existence.

## Grading Criteria

- [ ] `python-project/` exists and contains the generated project rather than scattering key deliverables at workspace root
- [ ] `python-project/pyproject.toml` exists and contains a valid `[project]` table with at least `name`, `version`, and Python 3.9+ requirement
- [ ] `pyproject.toml` reflects workspace preferences by using `pytest` in a test/dev configuration and not relying solely on `setup.py`
- [ ] A real source package exists under `python-project/` with `__init__.py` and at least one non-trivial module file
- [ ] The source code migrates the core functionality of `old_script.py` (`load_config`, CLI flow, or equivalent JSON-config loading behavior) instead of being an empty scaffold
- [ ] Tests under `python-project/tests/` validate migrated behavior from the prototype rather than only containing placeholder assertions
- [ ] `requirements-old.txt` is used selectively: unrelated dependencies such as `flask` and `gunicorn` are not blindly copied into the new project config unless actually justified by generated code
- [ ] `README.md` contains substantive sections such as overview, installation, usage, and testing
- [ ] `.gitignore` contains multiple Python-relevant ignore patterns for caches, virtualenvs, build artifacts, and tooling outputs

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    import re
    from pathlib import Path

    scores = {
        "project_in_subdir": 0.0,
        "pyproject_quality": 0.0,
        "workspace_preferences_used": 0.0,
        "source_package_quality": 0.0,
        "legacy_behavior_migrated": 0.0,
        "tests_validate_behavior": 0.0,
        "dependency_judgment": 0.0,
        "readme_quality": 0.0,
        "gitignore_quality": 0.0,
    }

    ws = Path(workspace_path)
    project_root = ws / "python-project"

    if not project_root.exists() or not project_root.is_dir():
        return scores

    def safe_read(path: Path) -> str:
        try:
            return path.read_text(encoding="utf-8")
        except Exception:
            return ""

    def find_first_package_root(base: Path):
        candidates = []
        for init_file in base.rglob("__init__.py"):
            if any(part in {".git", ".openclaw", "tests", "__pycache__"} for part in init_file.parts):
                continue
            parent = init_file.parent
            py_files = [p for p in parent.glob("*.py") if p.name != "__init__.py"]
            if py_files:
                candidates.append((parent, py_files))
        if not candidates:
            return None, []
        candidates.sort(key=lambda item: len(item[0].parts))
        return candidates[0]

    def has_python39_plus_requirement(text: str) -> bool:
        m = re.search(r'(?mi)^\s*requires-python\s*=\s*["\']([^"\']+)["\']', text)
        if not m:
            return False
        value = m.group(1).strip()
        return (">=3.9" in value) or (">= 3.9" in value)

    def extract_project_block(text: str) -> str:
        m = re.search(r'(?ms)^\[project\]\s*(.*?)(?=^\[|\Z)', text)
        return m.group(1) if m else ""

    def extract_dependencies_from_array(text: str, key_name: str):
        pattern = rf'(?ms)^\s*{re.escape(key_name)}\s*=\s*\[(.*?)\]'
        m = re.search(pattern, text)
        if not m:
            return []
        block = m.group(1)
        return [dep.strip().strip('"').strip("'") for dep in re.findall(r'["\']([^"\']+)["\']', block)]

    # 1. Project is actually inside python-project/
    key_files = [
        project_root / "pyproject.toml",
        project_root / "README.md",
        project_root / ".gitignore",
        project_root / "tests",
    ]
    present_count = sum(1 for p in key_files if p.exists())
    if present_count >= 3:
        scores["project_in_subdir"] = 1.0
    elif present_count >= 2:
        scores["project_in_subdir"] = 0.5

    # 2. pyproject.toml quality
    pyproject_path = project_root / "pyproject.toml"
    pyproject_text = safe_read(pyproject_path)
    if pyproject_text:
        project_block = extract_project_block(pyproject_text)
        has_name = re.search(r'(?mi)^\s*name\s*=\s*["\'][^"\']+["\']', project_block or "") is not None
        has_version = re.search(r'(?mi)^\s*version\s*=\s*["\'][^"\']+["\']', project_block or "") is not None
        has_req = has_python39_plus_requirement(pyproject_text)
        if project_block and has_name and has_version and has_req:
            scores["pyproject_quality"] = 1.0
        elif project_block and sum([has_name, has_version, has_req]) >= 2:
            scores["pyproject_quality"] = 0.6
        elif project_block:
            scores["pyproject_quality"] = 0.3

    # 3. Workspace preferences used: pyproject + pytest + Python 3.9+
    pytest_declared = False
    if pyproject_text:
        lowered = pyproject_text.lower()
        pytest_declared = "pytest" in lowered
        uses_setup_only = not pyproject_path.exists() and (project_root / "setup.py").exists()
        if has_python39_plus_requirement(pyproject_text) and pytest_declared and not uses_setup_only:
            scores["workspace_preferences_used"] = 1.0
        elif (has_python39_plus_requirement(pyproject_text) and pytest_declared) or (pytest_declared and "[project]" in lowered):
            scores["workspace_preferences_used"] = 0.5

    # 4. Source package quality
    package_dir, module_files = find_first_package_root(project_root)
    if package_dir:
        if any(p.suffix == ".py" and p.name != "__init__.py" for p in module_files):
            scores["source_package_quality"] = 1.0
        else:
            scores["source_package_quality"] = 0.4

    # 5. Legacy behavior migrated
    if package_dir:
        package_py_files = [p for p in package_dir.rglob("*.py")]
        combined_source = "\n".join(safe_read(p) for p in package_py_files)
        has_load_config = re.search(r'\bdef\s+load_config\s*\(', combined_source) is not None
        uses_json = re.search(r'^\s*import\s+json\b|^\s*from\s+json\s+import\b', combined_source, re.M) is not None
        has_main = re.search(r'\bdef\s+main\s*\(', combined_source) is not None
        mentions_config_path = ("config" in combined_source.lower()) and ("path" in combined_source.lower())
        if (has_load_config and uses_json) and (has_main or mentions_config_path):
            scores["legacy_behavior_migrated"] = 1.0
        elif (has_load_config and uses_json) or (has_main and mentions_config_path):
            scores["legacy_behavior_migrated"] = 0.5

    # 6. Tests validate behavior
    tests_dir = project_root / "tests"
    if tests_dir.exists() and tests_dir.is_dir():
        test_files = list(tests_dir.glob("test_*.py")) + list(tests_dir.glob("*_test.py"))
        combined_tests = "\n".join(safe_read(p) for p in test_files)
        has_real_test_func = re.search(r'\bdef\s+test_[A-Za-z0-9_]+\s*\(', combined_tests) is not None
        references_load_config = "load_config" in combined_tests
        references_main = re.search(r'\bmain\b', combined_tests) is not None
        references_json_or_config = ("json" in combined_tests.lower()) or ("config" in combined_tests.lower())
        has_placeholder_only = "assert True" in combined_tests and not (references_load_config or references_main or references_json_or_config)
        if has_real_test_func and not has_placeholder_only and ((references_load_config and references_json_or_config) or (references_main and references_json_or_config)):
            scores["tests_validate_behavior"] = 1.0
        elif has_real_test_func and not has_placeholder_only and (references_load_config or references_main or references_json_or_config):
            scores["tests_validate_behavior"] = 0.5

    # 7. Dependency judgment
    if pyproject_text:
        lower_pyproject = pyproject_text.lower()
        forbidden = ["flask", "gunicorn"]
        found_forbidden = [name for name in forbidden if re.search(rf'\b{name}\b', lower_pyproject)]
        project_deps = extract_dependencies_from_array(pyproject_text, "dependencies")
        if not found_forbidden and len(project_deps) <= 3:
            scores["dependency_judgment"] = 1.0
        elif not found_forbidden:
            scores["dependency_judgment"] = 0.6
        else:
            scores["dependency_judgment"] = 0.0

    # 8. README quality
    readme_path = project_root / "README.md"
    readme_text = safe_read(readme_path)
    if readme_text:
        headings = re.findall(r'(?m)^##\s+\S+', readme_text)
        has_install = re.search(r'(?i)\binstall', readme_text) is not None
        has_usage = re.search(r'(?i)\busage|\brun\b', readme_text) is not None
        has_testing = re.search(r'(?i)\btest', readme_text) is not None
        if len(headings) >= 2 and has_install and has_usage and has_testing and len(readme_text.splitlines()) >= 8:
            scores["readme_quality"] = 1.0
        elif len(headings) >= 1 and sum([has_install, has_usage, has_testing]) >= 2:
            scores["readme_quality"] = 0.5

    # 9. .gitignore quality
    gitignore_text = safe_read(project_root / ".gitignore")
    if gitignore_text:
        patterns = [
            "__pycache__",
            "*.py[cod]",
            ".pytest_cache",
            ".venv",
            "venv",
            "dist/",
            "build/",
            "*.egg-info/",
        ]
        matches = sum(1 for p in patterns if p in gitignore_text)
        if matches >= 5:
            scores["gitignore_quality"] = 1.0
        elif matches >= 3:
            scores["gitignore_quality"] = 0.5

    return scores
```

## LLM Judge Rubric

Evaluate the generated project as an engineering handoff artifact, not merely as a set of files.

### Dimension 1: Use of workspace context
- **1.0**: Clearly incorporates the key constraints from `notes.md`, `old_script.py`, and `requirements-old.txt`. Uses `pyproject.toml`, sets Python 3.9+, uses `pytest`, migrates legacy JSON-config behavior, and selectively excludes irrelevant legacy dependencies.
- **0.75**: Uses most workspace context correctly but misses one notable item, such as weak dependency judgment or only partial migration of legacy behavior.
- **0.5**: Uses some context, but important constraints are ignored or only weakly reflected. Example: uses `pyproject.toml` and `pytest` but does not meaningfully migrate the old prototype behavior.
- **0.25**: Mostly generic scaffolding with minimal evidence of reading the workspace files.
- **0.0**: Ignores workspace context entirely or directly contradicts it.

### Dimension 2: Quality of migration/refactor from prototype
- **1.0**: The new package preserves the prototype’s useful behavior in a cleaner modular form, with sensible naming and packaging. It is not a raw copy and shows reasonable refactoring judgment.
- **0.75**: Preserves the main behavior and packages it properly, but the refactor is somewhat shallow or awkward.
- **0.5**: Some legacy behavior appears, but the result is incomplete, poorly integrated, or mostly boilerplate.
- **0.25**: Barely migrates the prototype; functionality is mostly placeholder-level.
- **0.0**: No meaningful migration of the prototype.

### Dimension 3: Testing relevance and quality
- **1.0**: Tests meaningfully exercise migrated behavior, include plausible assertions, and align with the actual package API/CLI behavior.
- **0.75**: Tests are relevant and non-trivial, but coverage or assertions are somewhat limited.
- **0.5**: At least one real test exists, but it is shallow, weakly connected to the migrated behavior, or misses obvious edge cases.
- **0.25**: Tests are mostly placeholder-level or only weakly relevant.
- **0.0**: No meaningful tests.

### Dimension 4: Project usability and handoff quality
- **1.0**: README, config, and layout make the project easy to continue. Installation, usage, and testing guidance are clear; dependency choices are restrained and sensible.
- **0.75**: Generally usable, with only minor omissions in docs/config clarity.
- **0.5**: Usable in principle, but docs/config are thin or somewhat inconsistent.
- **0.25**: Barely usable as a handoff artifact.
- **0.0**: Poorly organized or misleading project output.

### Overall scoring guidance
- Reserve top scores for solutions that show real synthesis and engineering judgment.
- Generic scaffolds with superficial edits should not receive high marks even if the file tree looks complete.
- A solution that blindly copies legacy dependencies or fails to migrate the prototype should score low.
