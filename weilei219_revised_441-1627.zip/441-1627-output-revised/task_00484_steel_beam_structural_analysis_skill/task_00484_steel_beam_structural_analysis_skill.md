---
id: task_00484_steel_beam_structural_analysis_skill
name: Steel Beam Structural Analysis Skill
category: Data Analysis and Modeling
subcategory: Statistical Analysis and Modeling
difficulty: hard
grading_type: hybrid
grading_weights: {automated: 0.4, llm_judge: 0.6}
timeout_seconds: 600
input_modality: text-only
external_dependency: none
skill_creation: true
workspace_files:
  - path: input_params.json
    content: |
      {
        "beam_length_mm": 2500,
        "section_width_mm": 120,
        "section_height_mm": 60,
        "concentrated_load_N": 1500,
        "material": "Q235 structural steel",
        "elastic_modulus_GPa": 206,
        "yield_strength_MPa": 235
      }
  - path: requirements.txt
    content: |
      numpy
      scipy
      pyyaml
  - path: skills/data-enricher/SKILL.md
    content: |
      ---
      name: data-enricher
      description: Enriches raw records by reading input sources, validating fields, applying deterministic transformations, and producing structured outputs with documented assumptions.
      ---

      # Data Enricher Skill

      ## Purpose
      Turn incomplete or messy source data into a validated and enriched dataset.

      ## Inputs
      - Source files containing raw records
      - Validation rules
      - Optional lookup tables or reference datasets

      ## Outputs
      - Enriched structured data
      - Validation notes
      - Summary of assumptions and transformations

      ## Steps
      1. Inspect all relevant source files.
      2. Identify conflicts, missing values, and schema differences.
      3. Choose authoritative values and document the rationale.
      4. Apply transformations consistently.
      5. Save outputs and provide a concise summary of decisions.

      ## Quality Checks
      - Confirm required fields are present.
      - Flag unresolved conflicts.
      - Ensure outputs are internally consistent.
  - path: data/beam_case_study.json
    content: |
      {
        "case_id": "BEAM-2025-0047",
        "title": "Rectangular Steel Beam - Central Point Load Analysis",
        "date": "2025-07-15",
        "engineer": "J. Morrison",
        "status": "pending_analysis",
        "beam": {
          "material": "Structural Steel (Q235B)",
          "length_mm": 2500,
          "width_mm": 120,
          "height_mm": 60,
          "cross_section": "solid_rectangular",
          "youngs_modulus_GPa": 210,
          "yield_strength_MPa": 235,
          "density_kg_m3": 7850,
          "poissons_ratio": 0.3
        },
        "loading": {
          "type": "concentrated_vertical",
          "magnitude_N": 1500,
          "position": "midspan",
          "position_mm": 1250,
          "direction": "downward"
        },
        "support_conditions": {
          "type": "simply_supported",
          "left_support": {
            "type": "pin",
            "location_mm": 0,
            "constraints": ["vertical_displacement", "horizontal_displacement"]
          },
          "right_support": {
            "type": "roller",
            "location_mm": 2500,
            "constraints": ["vertical_displacement"]
          }
        },
        "requirements": {
          "safety_factor_min": 2.0,
          "max_deflection_ratio": "L/250",
          "analysis_type": "elastic",
          "code_reference": "GB 50017-2017"
        },
        "notes": "Standard classroom demonstration case. Rectangular cross-section for simplified hand calculation. Elastic modulus set to 210 GPa per project specification."
      }
  - path: data/beam_formulas_reference.md
    content: |
      # Beam Analysis Quick Reference — Common Loading Cases

      ## 1. Simply Supported Beam, Central Point Load (P at L/2)

      | Quantity | Formula |
      |---|---|
      | Reaction forces | R_A = R_B = P/2 |
      | Max bending moment | M_max = P·L / 4 (at midspan) |
      | Shear force (left half) | V = +P/2 |
      | Shear force (right half) | V = −P/2 |
      | Max deflection | δ_max = P·L³ / (48·E·I) (at midspan) |
      | Max bending stress | σ_max = M_max · c / I where c = h/2 |

      ## 2. Simply Supported Beam, Uniformly Distributed Load (w per unit length)

      | Quantity | Formula |
      |---|---|
      | Reaction forces | R_A = R_B = w·L/2 |
      | Max bending moment | M_max = w·L² / 8 (at midspan) |
      | Max shear force | V_max = w·L/2 (at supports) |
      | Max deflection | δ_max = 5·w·L⁴ / (384·E·I) (at midspan) |

      ## 3. Cantilever Beam, Point Load at Free End

      | Quantity | Formula |
      |---|---|
      | Reaction force | R = P |
      | Reaction moment | M_R = P·L |
      | Max bending moment | M_max = P·L (at fixed end) |
      | Max shear force | V_max = P (constant) |
      | Max deflection | δ_max = P·L³ / (3·E·I) (at free end) |

      ## 4. Fixed-Fixed Beam, Central Point Load

      | Quantity | Formula |
      |---|---|
      | Reaction forces | R_A = R_B = P/2 |
      | Max bending moment | M_max = P·L / 8 (at midspan and supports) |
      | Max deflection | δ_max = P·L³ / (192·E·I) |

      ## Section Properties — Rectangular Cross-Section (b × h)

      | Property | Formula |
      |---|---|
      | Area | A = b · h |
      | Second moment of area (I_x) | I = b·h³ / 12 |
      | Section modulus (S_x) | S = b·h² / 6 |
      | Distance to extreme fiber | c = h / 2 |

      ## Safety Factor

      n = σ_yield / σ_max

      If n ≥ required safety factor → design is adequate.

      ## Deflection Serviceability Limit

      Typical allowable deflection: L/250 to L/360 depending on code and application.
  - path: data/previous_analysis_log.txt
    content: |
      [2025-07-15 09:12:03] INFO  Session started: Structural beam analysis demo
      [2025-07-15 09:12:15] INFO  User requested: Define a steel beam example for structural analysis demonstration
      [2025-07-15 09:12:18] INFO  Parameters agreed:
                                  - Material: Q235B structural steel
                                  - Length: 2500 mm
                                  - Width: 120 mm
                                  - Height: 60 mm
                                  - Load: 1500 N vertical concentrated at midspan
      [2025-07-15 09:12:22] INFO  Cross-section type: Solid rectangular
      [2025-07-15 09:12:25] INFO  Support condition: Simply supported (pin + roller)
      [2025-07-15 09:12:30] INFO  Case file written to data/beam_case_study.json
      [2025-07-15 09:13:01] INFO  User confirmed parameters. Ready for full structural analysis.
      [2025-07-15 09:13:05] PENDING  Awaiting analysis execution request...
      [2025-07-15 09:15:42] INFO  User requested: Demonstrate the structural force analysis for this case
      [2025-07-15 09:15:43] INFO  Analysis type: Elastic beam theory (Euler-Bernoulli)
      [2025-07-15 09:15:44] PENDING  Analysis not yet performed. Initiating workflow...
  - path: data/project_load_combinations.yaml
    content: |
      # Load Combinations per GB 50009-2012 (Code for Loads)
      # Project: Workshop Mezzanine Floor Retrofit - Phase 2
      # Document: LC-2025-003 Rev.A

      project:
        name: "Workshop Mezzanine Floor Retrofit"
        location: "Building C, Industrial Park Zone 3"
        code: "GB 50009-2012"
        design_life_years: 50

      dead_loads:
        self_weight_steel: 0.785
        concrete_slab: 3.0
        floor_finish: 0.5
        MEP_services: 0.25
        ceiling: 0.15

      live_loads:
        office_area: 2.0
        storage_area: 5.0
        corridor: 3.5
        equipment_point: 1.5

      combinations:
        - id: "LC-01"
          description: "Dead + Live (basic)"
          formula: "1.2D + 1.4L"
          gamma_D: 1.2
          gamma_L: 1.4
          psi_L: 1.0
          governs: false
        - id: "LC-02"
          description: "Dead + Live (favorable dead)"
          formula: "1.0D + 1.4L"
          gamma_D: 1.0
          gamma_L: 1.4
          psi_L: 1.0
          governs: true
        - id: "LC-03"
          description: "Dead only"
          formula: "1.35D"
          gamma_D: 1.35
          gamma_L: 0.0
          psi_L: 0.0
          governs: false
        - id: "LC-04"
          description: "Dead + Live + Wind (combination)"
          formula: "1.2D + 0.7×1.4L + 0.6×1.4W"
          gamma_D: 1.2
          gamma_L: 0.98
          gamma_W: 0.84
          governs: false
        - id: "LC-05"
          description: "Serviceability - characteristic"
          formula: "1.0D + 1.0L"
          gamma_D: 1.0
          gamma_L: 1.0
          limit_state: "serviceability"
          deflection_limit: "L/250"

      notes:
        - "Point load of 1500N used for local beam check (equipment placement scenario)"
        - "Beam specimen: 2500×120×60 mm rectangular solid steel, Q235B"
        - "See beam_case_study.json for detailed single-beam analysis parameters"
  - path: data/steel_material_properties.csv
    content: |
      grade,standard,yield_strength_MPa,tensile_strength_MPa,youngs_modulus_GPa,elongation_pct,density_kg_m3,poissons_ratio,thermal_expansion_1e6_per_C,typical_use
      Q195,GB/T 700,195,315,206,33,7850,0.30,12.0,Light structures and general fabrication
      Q215,GB/T 700,215,335,206,31,7850,0.30,12.0,Riveted structures and general use
      Q235A,GB/T 700,235,370,206,26,7850,0.30,12.0,General structural steel beams and columns
      Q235B,GB/T 700,235,370,206,26,7850,0.30,12.0,Building frames and bridges - improved toughness
      Q275,GB/T 700,275,410,206,22,7850,0.30,12.0,Heavy-duty structural members
      Q345B,GB/T 1591,345,470,206,22,7850,0.30,12.0,High-strength structural applications
      Q390B,GB/T 1591,390,490,206,20,7850,0.30,12.0,Large-span bridges and heavy equipment
      Q420B,GB/T 1591,420,520,206,19,7850,0.30,12.0,Offshore and high-load structures
      Q460C,GB/T 1591,460,550,206,17,7850,0.30,12.0,High-performance structural steel
      SS400,JIS G3101,245,400,200,21,7860,0.30,11.7,General Japanese structural steel
      A36,ASTM A36,250,400,200,23,7850,0.29,11.7,US general structural steel
      S235JR,EN 10025,235,360,210,26,7850,0.30,12.0,European general structural steel
      S275JR,EN 10025,275,410,210,23,7850,0.30,12.0,European medium-strength structural steel
      S355JR,EN 10025,355,470,210,22,7850,0.30,12.0,European high-strength structural steel
---

## Prompt

I need a reusable beam-analysis skill plus a one-off analysis for the beam files already in this workspace.

Please do all of the following:

1. Create a `SKILL.md` in the workspace that documents a reusable skill for elastic beam analysis.
2. Create `beam_analysis.py` that reads the available project files from disk (do not just hardcode the final results) and performs the analysis.
3. Run the logic by writing `output/analysis_report.txt`.

Use the workspace files as your source of truth, but do not assume they are perfectly consistent. If different files disagree, make a reasoned choice and document it in the report.

What I need in the report:
- the beam/support/loading case you decided to analyze
- the governing load combination or loading basis you used, with a short justification
- any parameter conflicts you found across files, especially material properties
- the chosen values used in calculation
- key results: reactions, max shear, max bending moment, section properties, max bending stress, deflection, safety factor
- a pass/fail style conclusion against both strength and serviceability requirements
- brief comments on whether the result is sensitive to the parameter conflict(s)

A few notes:
- There are intentionally multiple reference files in `data/`; not all are equally relevant.
- Some files contain project-level load-combination context, while others contain the local beam check inputs.
- The output should be an engineering-style summary, not just raw numbers.
- For the skill file, use a structure comparable in quality to the example skill under `skills/`, but adapt it to this beam-analysis use case rather than copying it verbatim.

## Expected Behavior

A strong solution should do more than restate the prompt. It should inspect the workspace files, determine which ones are relevant to the local beam analysis, and make explicit choices where documents conflict.

Expected high-level behavior:

1. **SKILL.md**
   - Includes YAML frontmatter with at least `name` and `description`.
   - Contains clearly labeled sections such as:
     - `## Purpose`
     - `## Inputs`
     - `## Outputs`
     - `## Steps`
     - `## Quality Checks`
   - Describes a reusable process for beam analysis, including validation of conflicting inputs and documenting assumptions.

2. **beam_analysis.py**
   - Reads parameters from workspace files, especially:
     - `input_params.json`
     - `data/beam_case_study.json`
     - `data/project_load_combinations.yaml`
     - optionally `data/steel_material_properties.csv` for material cross-checking
   - Implements the simply supported, midspan point-load beam formulas appropriate to the selected local check.
   - Does not rely on hardcoded final answers.
   - Produces `output/analysis_report.txt`.

3. **Reasoning about conflicting inputs**
   - There is a deliberate conflict in elastic modulus:
     - `input_params.json` gives **206 GPa**
     - `data/beam_case_study.json` gives **210 GPa**
     - `data/steel_material_properties.csv` lists **Q235B as 206 GPa**
   - The agent should notice and explain this conflict.
   - For a high-quality answer, the chosen value should be justified from file provenance and material consistency, not guessed.
   - Ground-truth expectation for the best answer:
     - treat this as a **local beam check for the 1500 N equipment point load**
     - recognize that `data/project_load_combinations.yaml` provides project context but its `equipment_point: 1.5` kN and notes indicate the same local point load scenario
     - use the **service/local check load basis of 1500 N**, not invent distributed floor loading from unrelated area loads
     - identify **LC-05** as the serviceability context and/or explain that the local point-load note is the relevant basis for this elastic demonstration
     - select **E = 206 GPa** as the better-supported value because it matches `input_params.json` and the Q235B row in `data/steel_material_properties.csv`, while `beam_case_study.json` is the lone conflicting source
   - Acceptable but weaker answer:
     - uses **E = 210 GPa** but explicitly identifies the conflict and justifies using the project case study value
   - Unacceptable reasoning:
     - ignores the conflict entirely
     - mixes project area loads into this local point-load beam check without justification
     - claims a governing fact contradicted by the files

4. **Numerical ground truth**
   For the preferred interpretation (1500 N local point load, E = 206 GPa, L = 2500 mm, b = 120 mm, h = 60 mm, Fy = 235 MPa):
   - Reactions: `R_A = R_B = 750 N`
   - Max shear magnitude: `750 N`
   - Max moment: `937500 N·mm` = `937.5 N·m`
   - Second moment of area: `2160000 mm^4`
   - Section modulus: `72000 mm^3`
   - Max bending stress: about `13.02 MPa`
   - Max deflection: about `1.108 mm`
   - Safety factor: about `18.05`
   - Allowable deflection from `L/250`: `10.0 mm`
   - Conclusion: passes both strength and serviceability by a large margin

   For the alternate-but-defensible interpretation using **E = 210 GPa**:
   - Stress and moment-related values stay the same
   - Deflection is about `1.087 mm`
   - Safety factor remains about `18.05`

5. **Traps / edge cases**
   - `data/project_load_combinations.yaml` contains many project loads that are not directly applicable to this single local beam check; the correct move is to avoid inventing a new beam line load from them unless clearly justified.
   - `data/previous_analysis_log.txt` is only contextual and should not override structured inputs.
   - The report should distinguish **strength check** from **serviceability check**.
   - Because stress does not depend on E for this case, a good report may note that the E conflict affects **deflection only**, not bending stress or safety factor.

## Grading Criteria

- [ ] `SKILL.md` exists with YAML frontmatter including `name` and `description`
- [ ] `SKILL.md` includes reusable sections for `Purpose`, `Inputs`, `Outputs`, `Steps`, and `Quality Checks`
- [ ] `beam_analysis.py` exists and reads workspace data files rather than only embedding final results
- [ ] `output/analysis_report.txt` exists and is substantive
- [ ] Report identifies the analyzed beam/support/load case correctly
- [ ] Report identifies the local 1500 N point-load basis and avoids unjustified use of unrelated project area loads
- [ ] Report explicitly identifies the Young's modulus conflict and states which value was chosen and why
- [ ] Report includes reactions, shear, moment, section properties, stress, deflection, and safety factor
- [ ] Report checks both strength and serviceability and gives a clear conclusion
- [ ] Numerical values are consistent with the chosen interpretation and close to the true results

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    import os
    import re
    import json
    import csv
    import math
    import glob
    from pathlib import Path

    scores = {}
    ws = workspace_path

    def read_text(path):
        try:
            with open(path, "r", encoding="utf-8") as f:
                return f.read()
        except Exception:
            return ""

    def parse_number(text):
        if text is None:
            return None
        try:
            return float(str(text).replace(",", "").strip())
        except Exception:
            return None

    def approx_in_ranges(val, ranges):
        if val is None:
            return False
        for lo, hi in ranges:
            if lo <= val <= hi:
                return True
        return False

    def extract_value_near_keywords(text, keywords, unit_patterns=None):
        if not text:
            return None
        unit_patterns = unit_patterns or [r""]
        for kw in keywords:
            for up in unit_patterns:
                pattern = rf'(?is){kw}[^\n\r\d\-]*([-+]?\d[\d,]*\.?\d*)\s*{up}'
                m = re.search(pattern, text)
                if m:
                    return parse_number(m.group(1))
        return None

    # Ground truth derived from assets / workspace inputs
    input_params_path = os.path.join(ws, "input_params.json")
    case_study_path = os.path.join(ws, "data", "beam_case_study.json")
    material_table_path = os.path.join(ws, "data", "steel_material_properties.csv")

    try:
        with open(input_params_path, "r", encoding="utf-8") as f:
            input_params = json.load(f)
    except Exception:
        input_params = {}

    try:
        with open(case_study_path, "r", encoding="utf-8") as f:
            case_study = json.load(f)
    except Exception:
        case_study = {}

    q235b_E = None
    try:
        with open(material_table_path, "r", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            for row in reader:
                if row.get("grade", "").strip().upper() == "Q235B":
                    q235b_E = parse_number(row.get("youngs_modulus_GPa"))
                    break
    except Exception:
        q235b_E = None

    L = parse_number(input_params.get("beam_length_mm")) or 2500.0
    b = parse_number(input_params.get("section_width_mm")) or 120.0
    h = parse_number(input_params.get("section_height_mm")) or 60.0
    P = parse_number(input_params.get("concentrated_load_N")) or 1500.0
    Fy = parse_number(input_params.get("yield_strength_MPa")) or 235.0
    E_input = parse_number(input_params.get("elastic_modulus_GPa")) or 206.0
    E_case = parse_number((((case_study or {}).get("beam") or {}).get("youngs_modulus_GPa"))) or 210.0
    E_table = q235b_E or 206.0

    I = b * (h ** 3) / 12.0
    S = b * (h ** 2) / 6.0
    R = P / 2.0
    M_nmm = P * L / 4.0
    M_nm = M_nmm / 1000.0
    stress = M_nmm / S
    sf = Fy / stress
    defl_206 = P * (L ** 3) / (48.0 * (E_input * 1000.0) * I)
    defl_210 = P * (L ** 3) / (48.0 * (E_case * 1000.0) * I)
    allowable_defl = L / 250.0

    # 1. SKILL.md structure
    skill_candidates = [os.path.join(ws, "SKILL.md")] + \
        glob.glob(os.path.join(ws, "skills", "*", "SKILL.md")) + \
        glob.glob(os.path.join(ws, "*", "SKILL.md"))
    root_skill_path = os.path.join(ws, "SKILL.md")
    skill_path = root_skill_path if os.path.isfile(root_skill_path) else next((p for p in skill_candidates if os.path.isfile(p)), None)
    skill_score = 0.0
    if skill_path:
        content = read_text(skill_path)
        has_frontmatter = content.strip().startswith("---")
        has_name = bool(re.search(r'(?im)^\s*name\s*:', content))
        has_description = bool(re.search(r'(?im)^\s*description\s*:', content))
        required_sections = ["purpose", "inputs", "outputs", "steps", "quality checks"]
        section_hits = sum(1 for sec in required_sections if re.search(rf'(?im)^##\s*{re.escape(sec)}\s*$', content))
        if has_frontmatter and has_name and has_description:
            skill_score += 0.4
        skill_score += 0.12 * section_hits
        scores["skill_md_structure"] = round(min(skill_score, 1.0), 2)
    else:
        scores["skill_md_structure"] = 0.0

    # 2. beam_analysis.py quality by source-reading evidence
    script_path = os.path.join(ws, "beam_analysis.py")
    script_score = 0.0
    script_content = ""
    if os.path.isfile(script_path):
        script_content = read_text(script_path)
        if len(script_content) > 200:
            script_score += 0.2
        source_refs = [
            "input_params.json",
            "beam_case_study.json",
            "project_load_combinations.yaml",
            "steel_material_properties.csv",
            "json",
            "yaml",
            "csv",
            "open(",
        ]
        ref_hits = sum(1 for s in source_refs if s.lower() in script_content.lower())
        if ref_hits >= 4:
            script_score += 0.45
        elif ref_hits >= 2:
            script_score += 0.25

        calc_terms = ["moment", "shear", "stress", "deflection", "safety", "young", "modulus"]
        calc_hits = sum(1 for t in calc_terms if t in script_content.lower())
        if calc_hits >= 5:
            script_score += 0.35
        elif calc_hits >= 3:
            script_score += 0.2
    scores["beam_analysis_script"] = round(min(script_score, 1.0), 2)

    # 3. Report existence
    report_candidates = [
        os.path.join(ws, "output", "analysis_report.txt"),
        os.path.join(ws, "output", "analysis_report.md"),
        os.path.join(ws, "analysis_report.txt"),
    ]
    report_path = next((p for p in report_candidates if os.path.isfile(p)), None)
    report_content = read_text(report_path) if report_path else ""
    scores["report_exists"] = 1.0 if len(report_content.strip()) >= 300 else (0.5 if len(report_content.strip()) >= 120 else 0.0)

    report_lower = report_content.lower()

    # 4. Report completeness / reasoning coverage
    completeness_checks = {
        "boundary_conditions": any(term in report_lower for term in ["simply supported", "simply-supported", "pin", "roller"]),
        "load_basis": any(term in report_lower for term in ["1500 n", "1.5 kn", "equipment point", "local beam check", "lc-05", "serviceability"]),
        "e_conflict": ("206" in report_content and "210" in report_content and any(term in report_lower for term in ["conflict", "inconsisten", "disagree", "selected", "chosen", "adopted"])),
        "chosen_values": any(term in report_lower for term in ["chosen values", "adopted values", "used in calculation", "selected values"]),
        "strength_check": any(term in report_lower for term in ["strength", "yield", "stress"]),
        "serviceability_check": any(term in report_lower for term in ["serviceability", "deflection", "l/250", "10.0 mm", "10 mm"]),
        "conclusion": any(term in report_lower for term in ["pass", "fails", "safe", "adequate", "acceptable", "not acceptable"]),
    }
    scores["report_completeness"] = round(sum(1 for v in completeness_checks.values() if v) / len(completeness_checks), 2)

    # 5. Numerical accuracy and conflict handling
    numerical_score = 0.0

    reaction_val = extract_value_near_keywords(report_content, [r"reaction(?:s)?", r"r_a", r"r_b"], [r"(?:n\b|n[^a-z])"])
    if reaction_val is not None and 730.0 <= reaction_val <= 770.0:
        numerical_score += 0.12

    shear_val = extract_value_near_keywords(report_content, [r"max(?:imum)? shear(?: force)?", r"shear(?: force)?"], [r"(?:n\b|n[^a-z])"])
    if shear_val is not None and 730.0 <= shear_val <= 770.0:
        numerical_score += 0.12

    moment_val = None
    moment_nmm = extract_value_near_keywords(report_content, [r"max(?:imum)? bending moment", r"bending moment", r"moment"], [r"(?:n[\s\.\·\*\-]*mm|nmm)"])
    moment_nm = extract_value_near_keywords(report_content, [r"max(?:imum)? bending moment", r"bending moment", r"moment"], [r"(?:n[\s\.\·\*\-]*m\b|nm\b)"])
    if moment_nmm is not None and 930000.0 <= moment_nmm <= 945000.0:
        numerical_score += 0.16
        moment_val = moment_nmm
    elif moment_nm is not None and 930.0 <= moment_nm <= 945.0:
        numerical_score += 0.16
        moment_val = moment_nm

    I_val = extract_value_near_keywords(report_content, [r"second moment of area", r"\bi\b"], [r"(?:mm\^?4|mm4)"])
    if I_val is not None and 2150000.0 <= I_val <= 2170000.0:
        numerical_score += 0.1

    S_val = extract_value_near_keywords(report_content, [r"section modulus", r"\bs\b"], [r"(?:mm\^?3|mm3)"])
    if S_val is not None and 71900.0 <= S_val <= 72100.0:
        numerical_score += 0.1

    stress_val = extract_value_near_keywords(report_content, [r"max(?:imum)? bending stress", r"bending stress", r"max(?:imum)? stress", r"stress"], [r"(?:mpa)"])
    if stress_val is not None and 12.8 <= stress_val <= 13.3:
        numerical_score += 0.14

    defl_val = extract_value_near_keywords(report_content, [r"max(?:imum)? deflection", r"deflection"], [r"(?:mm)"])
    if defl_val is not None and (1.07 <= defl_val <= 1.12):
        numerical_score += 0.14

    sf_val = extract_value_near_keywords(report_content, [r"safety factor", r"factor of safety", r"\bfos\b"], [r""])
    if sf_val is not None and 17.8 <= sf_val <= 18.3:
        numerical_score += 0.12

    conflict_bonus = 0.0
    if "206" in report_content and "210" in report_content and any(term in report_lower for term in ["conflict", "inconsisten", "disagree"]):
        if any(term in report_lower for term in ["deflection only", "affects deflection", "stress does not depend on e", "moment does not depend on e", "safety factor remains"]):
            conflict_bonus = 0.1
        else:
            conflict_bonus = 0.05

    scores["numerical_accuracy"] = round(min(numerical_score + conflict_bonus, 1.0), 2)

    return scores
```

## LLM Judge Rubric

### Skill File Quality (Weight: 20%)
- 1.0: `SKILL.md` has valid YAML frontmatter and a clearly reusable structure with `Purpose`, `Inputs`, `Outputs`, `Steps`, and `Quality Checks`. It explains how to inspect source files, resolve conflicting inputs, perform calculations, and document assumptions/results in a way that could be reused for similar beam tasks.
- 0.75: `SKILL.md` is solid and mostly reusable, but one section is thin, partially generic, or misses explicit guidance on conflict handling or quality checks.
- 0.5: `SKILL.md` exists and is somewhat organized, but it is generic, incomplete, or only weakly reusable for actual beam-analysis work.
- 0.25: `SKILL.md` exists but is mostly a stub, with minimal structure or little beam-specific guidance.
- 0.0: Missing or unusable.

### beam_analysis.py Calculation Correctness and Engineering Logic (Weight: 30%)
- 1.0: Script clearly reads project files, selects an appropriate local point-load beam case, applies correct simply supported beam formulas, and computes results consistent with the chosen assumptions. Logic is coherent and not just hardcoded output generation.
- 0.75: Script is mostly correct and grounded in file inputs, but has a minor gap such as incomplete validation, limited source cross-checking, or slightly brittle implementation.
- 0.5: Script exists and attempts calculations, but there are meaningful issues such as over-hardcoding, weak linkage to source files, partially incorrect formulas, or unclear handling of assumptions.
- 0.25: Script is largely superficial, mostly hardcoded, or contains major engineering or implementation mistakes.
- 0.0: Missing or fundamentally nonfunctional.

### analysis_report.txt Completeness and Accuracy (Weight: 30%)
- 1.0: Report is engineering-style, clearly identifies the analyzed case, chosen loading basis, support conditions, assumptions, selected parameters, and all requested outputs. It separately evaluates strength and serviceability and gives a defensible conclusion supported by the numbers.
- 0.75: Report is reasonably complete and mostly accurate, but lacks one important element such as explicit loading-basis justification, full parameter summary, or clear separation of strength vs serviceability.
- 0.5: Report includes some relevant results but is incomplete, loosely organized, or has several ambiguities in what was analyzed and why.
- 0.25: Report is very thin, mostly raw numbers, or missing major required components.
- 0.0: Missing or unusable.

### E-Value Conflict Detection and Resolution (Weight: 10%)
- 1.0: Explicitly identifies the 206 vs 210 GPa conflict, cites the conflicting sources, chooses one value with a reasoned provenance-based justification, and notes that the conflict affects deflection but not bending stress for this case.
- 0.75: Identifies the conflict and chooses a value with some justification, but does not clearly explain the consequence of the choice.
- 0.5: Mentions multiple E values or hints at inconsistency, but the resolution is weak, implicit, or poorly justified.
- 0.25: Uses one E value with no meaningful acknowledgment of the conflict.
- 0.0: Misses the conflict entirely or states facts contradicted by the files.

### Conclusion Quality and Decision-Making (Weight: 10%)
- 1.0: Final conclusion is concise, correct, and decision-oriented, explicitly referencing both required strength margin and allowable deflection/serviceability, with no unsupported claims.
- 0.75: Conclusion is mostly correct but slightly vague or not fully tied back to both checks.
- 0.5: Conclusion is partially supported but simplistic, overly generic, or missing one decision dimension.
- 0.25: Conclusion is weak, hand-wavy, or not well supported by the report.
- 0.0: No meaningful conclusion or a clearly wrong conclusion.

## Asset: assets/data/beam_case_study.json
```json
{
  "case_id": "BEAM-2025-0047",
  "title": "Rectangular Steel Beam - Central Point Load Analysis",
  "date": "2025-07-15",
  "engineer": "J. Morrison",
  "status": "pending_analysis",
  "beam": {
    "material": "Structural Steel (Q235B)",
    "length_mm": 2500,
    "width_mm": 120,
    "height_mm": 60,
    "cross_section": "solid_rectangular",
    "youngs_modulus_GPa": 210,
    "yield_strength_MPa": 235,
    "density_kg_m3": 7850,
    "poissons_ratio": 0.3
  },
  "loading": {
    "type": "concentrated_vertical",
    "magnitude_N": 1500,
    "position": "midspan",
    "position_mm": 1250,
    "direction": "downward"
  },
  "support_conditions": {
    "type": "simply_supported",
    "left_support": {
      "type": "pin",
      "location_mm": 0,
      "constraints": ["vertical_displacement", "horizontal_displacement"]
    },
    "right_support": {
      "type": "roller",
      "location_mm": 2500,
      "constraints": ["vertical_displacement"]
    }
  },
  "requirements": {
    "safety_factor_min": 2.0,
    "max_deflection_ratio": "L/250",
    "analysis_type": "elastic",
    "code_reference": "GB 50017-2017"
  },
  "notes": "Standard classroom demonstration case. Rectangular cross-section for simplified hand calculation. Elastic modulus set to 210 GPa per project specification."
}
```

## Asset: assets/data/beam_formulas_reference.md
```md
# Beam Analysis Quick Reference — Common Loading Cases

## 1. Simply Supported Beam, Central Point Load (P at L/2)

| Quantity | Formula |
|---|---|
| Reaction forces | R_A = R_B = P/2 |
| Max bending moment | M_max = P·L / 4 (at midspan) |
| Shear force (left half) | V = +P/2 |
| Shear force (right half) | V = −P/2 |
| Max deflection | δ_max = P·L³ / (48·E·I) (at midspan) |
| Max bending stress | σ_max = M_max · c / I where c = h/2 |

## 2. Simply Supported Beam, Uniformly Distributed Load (w per unit length)

| Quantity | Formula |
|---|---|
| Reaction forces | R_A = R_B = w·L/2 |
| Max bending moment | M_max = w·L² / 8 (at midspan) |
| Max shear force | V_max = w·L/2 (at supports) |
| Max deflection | δ_max = 5·w·L⁴ / (384·E·I) (at midspan) |

## 3. Cantilever Beam, Point Load at Free End

| Quantity | Formula |
|---|---|
| Reaction force | R = P |
| Reaction moment | M_R = P·L |
| Max bending moment | M_max = P·L (at fixed end) |
| Max shear force | V_max = P (constant) |
| Max deflection | δ_max = P·L³ / (3·E·I) (at free end) |

## 4. Fixed-Fixed Beam, Central Point Load

| Quantity | Formula |
|---|---|
| Reaction forces | R_A = R_B = P/2 |
| Max bending moment | M_max = P·L / 8 (at midspan and supports) |
| Max deflection | δ_max = P·L³ / (192·E·I) |

## Section Properties — Rectangular Cross-Section (b × h)

| Property | Formula |
|---|---|
| Area | A = b · h |
| Second moment of area (I_x) | I = b·h³ / 12 |
| Section modulus (S_x) | S = b·h² / 6 |
| Distance to extreme fiber | c = h / 2 |

## Safety Factor

n = σ_yield / σ_max

If n ≥ required safety factor → design is adequate.

## Deflection Serviceability Limit

Typical allowable deflection: L/250 to L/360 depending on code and application.
```

## Asset: assets/data/previous_analysis_log.txt
```txt
[2025-07-15 09:12:03] INFO  Session started: Structural beam analysis demo
[2025-07-15 09:12:15] INFO  User requested: Define a steel beam example for structural analysis demonstration
[2025-07-15 09:12:18] INFO  Parameters agreed:
                            - Material: Q235B structural steel
                            - Length: 2500 mm
                            - Width: 120 mm
                            - Height: 60 mm
                            - Load: 1500 N vertical concentrated at midspan
[2025-07-15 09:12:22] INFO  Cross-section type: Solid rectangular
[2025-07-15 09:12:25] INFO  Support condition: Simply supported (pin + roller)
[2025-07-15 09:12:30] INFO  Case file written to data/beam_case_study.json
[2025-07-15 09:13:01] INFO  User confirmed parameters. Ready for full structural analysis.
[2025-07-15 09:13:05] PENDING  Awaiting analysis execution request...
[2025-07-15 09:15:42] INFO  User requested: Demonstrate the structural force analysis for this case
[2025-07-15 09:15:43] INFO  Analysis type: Elastic beam theory (Euler-Bernoulli)
[2025-07-15 09:15:44] PENDING  Analysis not yet performed. Initiating workflow...
```

## Asset: assets/data/project_load_combinations.yaml
```yaml
# Load Combinations per GB 50009-2012 (Code for Loads)
# Project: Workshop Mezzanine Floor Retrofit - Phase 2
# Document: LC-2025-003 Rev.A

project:
  name: "Workshop Mezzanine Floor Retrofit"
  location: "Building C, Industrial Park Zone 3"
  code: "GB 50009-2012"
  design_life_years: 50

dead_loads:
  self_weight_steel: 0.785
  concrete_slab: 3.0
  floor_finish: 0.5
  MEP_services: 0.25
  ceiling: 0.15

live_loads:
  office_area: 2.0
  storage_area: 5.0
  corridor: 3.5
  equipment_point: 1.5

combinations:
  - id: "LC-01"
    description: "Dead + Live (basic)"
    formula: "1.2D + 1.4L"
    gamma_D: 1.2
    gamma_L: 1.4
    psi_L: 1.0
    governs: false

  - id: "LC-02"
    description: "Dead + Live (favorable dead)"
    formula: "1.0D + 1.4L"
    gamma_D: 1.0
    gamma_L: 1.4
    psi_L: 1.0
    governs: true

  - id: "LC-03"
    description: "Dead only"
    formula: "1.35D"
    gamma_D: 1.35
    gamma_L: 0.0
    psi_L: 0.0
    governs: false

  - id: "LC-04"
    description: "Dead + Live + Wind (combination)"
    formula: "1.2D + 0.7×1.4L + 0.6×1.4W"
    gamma_D: 1.2
    gamma_L: 0.98
    gamma_W: 0.84
    governs: false

  - id: "LC-05"
    description: "Serviceability - characteristic"
    formula: "1.0D + 1.0L"
    gamma_D: 1.0
    gamma_L: 1.0
    limit_state: "serviceability"
    deflection_limit: "L/250"

notes:
  - "Point load of 1500N used for local beam check (equipment placement scenario)"
  - "Beam specimen: 2500×120×60 mm rectangular solid steel, Q235B"
  - "See beam_case_study.json for detailed single-beam analysis parameters"
```

## Asset: assets/data/steel_material_properties.csv
```csv
grade,standard,yield_strength_MPa,tensile_strength_MPa,youngs_modulus_GPa,elongation_pct,density_kg_m3,poissons_ratio,thermal_expansion_1e6_per_C,typical_use
Q195,GB/T 700,195,315,206,33,7850,0.30,12.0,Light structures and general fabrication
Q215,GB/T 700,215,335,206,31,7850,0.30,12.0,Riveted structures and general use
Q235A,GB/T 700,235,370,206,26,7850,0.30,12.0,General structural steel beams and columns
Q235B,GB/T 700,235,370,206,26,7850,0.30,12.0,Building frames and bridges - improved toughness
Q275,GB/T 700,275,410,206,22,7850,0.30,12.0,Heavy-duty structural members
Q345B,GB/T 1591,345,470,206,22,7850,0.30,12.0,High-strength structural applications
Q390B,GB/T 1591,390,490,206,20,7850,0.30,12.0,Large-span bridges and heavy equipment
Q420B,GB/T 1591,420,520,206,19,7850,0.30,12.0,Offshore and high-load structures
Q460C,GB/T 1591,460,550,206,17,7850,0.30,12.0,High-performance structural steel
SS400,JIS G3101,245,400,200,21,7860,0.30,11.7,General Japanese structural steel
A36,ASTM A36,250,400,200,23,7850,0.29,11.7,US general structural steel
S235JR,EN 10025,235,360,210,26,7850,0.30,12.0,European general structural steel
S275JR,EN 10025,275,410,210,23,7850,0.30,12.0,European medium-strength structural steel
S355JR,EN 10025,355,470,210,22,7850,0.30,12.0,European high-strength structural steel
```
