# Beam Analysis Quick Reference — Common Loading Cases

## 1. Simply Supported Beam, Central Point Load (P at L/2)

| Quantity | Formula |
|---|---|
| Reaction forces | R_A = R_B = P/2 |
| Max bending moment | M_max = P·L / 4 (at midspan) |
| Shear force (left half) | V = +P/2 |
| Shear force (right half) | V = −P/2 |
| Max deflection | δ_max = P·L³ / (48·E·I) (at midspan) |
| Max bending stress | σ_max = M_max · c / I where c = h/2 |

## 2. Simply Supported Beam, Uniformly Distributed Load (w per unit length)

| Quantity | Formula |
|---|---|
| Reaction forces | R_A = R_B = w·L/2 |
| Max bending moment | M_max = w·L² / 8 (at midspan) |
| Max shear force | V_max = w·L/2 (at supports) |
| Max deflection | δ_max = 5·w·L⁴ / (384·E·I) (at midspan) |

## 3. Cantilever Beam, Point Load at Free End

| Quantity | Formula |
|---|---|
| Reaction force | R = P |
| Reaction moment | M_R = P·L |
| Max bending moment | M_max = P·L (at fixed end) |
| Max shear force | V_max = P (constant) |
| Max deflection | δ_max = P·L³ / (3·E·I) (at free end) |

## 4. Fixed-Fixed Beam, Central Point Load

| Quantity | Formula |
|---|---|
| Reaction forces | R_A = R_B = P/2 |
| Max bending moment | M_max = P·L / 8 (at midspan and supports) |
| Max deflection | δ_max = P·L³ / (192·E·I) |

## Section Properties — Rectangular Cross-Section (b × h)

| Property | Formula |
|---|---|
| Area | A = b · h |
| Second moment of area (I_x) | I = b·h³ / 12 |
| Section modulus (S_x) | S = b·h² / 6 |
| Distance to extreme fiber | c = h / 2 |

## Safety Factor

n = σ_yield / σ_max

If n ≥ required safety factor → design is adequate.

## Deflection Serviceability Limit

Typical allowable deflection: L/250 to L/360 depending on code and application.
