---
id: task_00466_kill_processes_on_ports_skill
name: Kill Processes on Ports 3000-3004 via Reusable Skill
category: System Administration
subcategory: System Operations and Monitoring
difficulty: medium
grading_type: hybrid
grading_weights: {automated: 0.7, llm: 0.3}
timeout_seconds: 600
input_modality: text-only
external_dependency: none
skill_creation: true
setup_command: bash setup_servers.sh
workspace_files:
  - path: setup_servers.sh
    content: |
      #!/bin/bash
      set -euo pipefail

      # Launch simple Python HTTP servers on ports 3000-3004 if they are not
      # already listening. Keep setup idempotent so repeated runs are safe.
      for port in 3000 3001 3002 3003 3004; do
        if lsof -nP -iTCP:${port} -sTCP:LISTEN >/dev/null 2>&1; then
          continue
        fi
        python3 -m http.server "${port}" >/dev/null 2>&1 &
      done
      echo "Servers ensured on ports 3000-3004"
---

## Prompt

I want a reusable port-cleanup skill added to this workspace.

Please create a `SKILL.md` at the workspace root with YAML frontmatter and practical instructions for freeing ports that are in use. Make it genuinely reusable rather than hardcoded to just one case.

After creating the skill, use it to clean up anything listening on ports **3000 through 3004** in the current environment.

A few constraints:
- The skill should be usable for arbitrary ports or port ranges, not only 3000-3004.
- Prefer a safe default workflow: inspect first, avoid duplicate PID handling, and only force-kill when justified.
- Mention at least one environment caveat or limitation that a teammate would need to know.
- Verify the result after cleanup instead of assuming the kill succeeded.

When you're done, tell me what you found and the final status of ports 3000-3004.

## Expected Behavior

The agent should complete two deliverables: a reusable skill document and a real cleanup operation against the prepared environment.

1. **Create `SKILL.md` in the workspace root**
   - It must include valid YAML frontmatter with at least:
     - `name`
     - `description`
   - The body should describe a reusable workflow for freeing occupied ports.
   - High-quality answers should not simply say "run lsof and kill".
   - The document should make the workflow reusable by covering all or most of:
     - parameterizing one or more ports / ranges rather than hardcoding 3000-3004
     - inspecting listeners first
     - deduplicating PIDs before killing
     - preferring graceful termination before force-kill
     - verifying ports are clear after cleanup
     - at least one caveat such as permissions, macOS/Linux differences, missing `lsof`, or risks of killing shared processes
     - at least one executable command example

2. **Actually clean up listeners on ports 3000-3004**
   - The environment setup starts listeners on ports 3000, 3001, 3002, 3003, and 3004 before grading.
   - The agent should use `lsof` (or an equivalent command sequence centered on `lsof`) to identify PIDs listening on those ports.
   - The agent should then terminate those listeners.
   - Stronger solutions will:
     - avoid duplicate PID kills (for example via `sort -u`)
     - use a staged approach such as `kill` before `kill -9`, or otherwise justify force-kill
     - re-check the ports afterward

3. **Report an accurate result**
   - The final assistant response should communicate what was found and whether ports 3000-3004 are clear after verification.
   - A high-quality response should mention specific ports and/or PIDs, not just say "done".

### Traps / edge cases intentionally present

- The setup is executed before grading, so there should be real listeners to clean up.
- A weak solution may create a generic document with keywords only; this should not receive high credit.
- A weak solution may run a kill command without verification; this should lose credit.
- A weak solution may use `kill -9` immediately on all PIDs without any caution or explanation; this should lose credit relative to a staged or justified approach.
- A weak solution may hardcode the exact ports in the skill and fail to describe a reusable interface; this should lose credit.
- A weak solution may mention success in prose without confirming the ports are actually clear; this should lose credit.
- Ground truth for grading is based on the actual contents of `SKILL.md`, the actual transcripted commands/results, and the actual post-task port state for 3000-3004.

## Grading Criteria

### Automated
- [ ] `SKILL.md` exists at workspace root
- [ ] `SKILL.md` has valid YAML frontmatter with `name` and `description`
- [ ] `SKILL.md` documents a reusable workflow rather than a one-off hardcoded command
- [ ] `SKILL.md` includes executable command examples using `lsof`
- [ ] `SKILL.md` includes safety/limitations guidance and verification guidance
- [ ] The agent inspected ports 3000-3004 with `lsof`
- [ ] The agent attempted actual termination of discovered listener PIDs
- [ ] The agent verified afterward that ports 3000-3004 were clear
- [ ] Ports 3000-3004 are actually clear at grading time
- [ ] The final assistant message accurately reports the result

### LLM Judge
The judge should score the overall quality of the submission using the rubric below, focusing especially on the practical quality of `SKILL.md` and the operational judgment shown in the cleanup process.

## LLM Judge Rubric

### Dimension 1: Reusable skill design
- **1.0**: `SKILL.md` is clearly reusable beyond this task; it explains how to handle arbitrary ports and/or ranges, includes a coherent workflow, and would plausibly help a teammate solve similar incidents.
- **0.75**: Mostly reusable; some parameterization is present, but parts remain narrowly tailored to 3000-3004 or underexplained.
- **0.5**: Partially reusable; includes some relevant guidance but reads mostly like notes for this exact case.
- **0.25**: Barely reusable; largely a one-off command dump with minimal explanation.
- **0.0**: Missing or unusable as a skill document.

### Dimension 2: Command quality and operational judgment
- **1.0**: Uses an inspect → terminate → verify workflow; handles duplicate PIDs or avoids redundant kills; prefers graceful termination or explicitly justifies stronger signals.
- **0.75**: Operationally sound but missing one refinement, such as deduplication or explicit rationale for signal choice.
- **0.5**: Basically works but uses a blunt or poorly explained approach.
- **0.25**: Risky or sloppy approach; little evidence of judgment.
- **0.0**: No meaningful cleanup workflow.

### Dimension 3: Edge cases, caveats, and safety guidance
- **1.0**: Clearly states at least one real caveat/limitation and at least one safety concern or failure mode, with actionable guidance.
- **0.75**: Mentions caveats or safety concerns, but shallowly.
- **0.5**: Brief caveat mention without practical usefulness.
- **0.25**: Token mention only.
- **0.0**: No caveats or safety guidance.

### Dimension 4: Result reporting accuracy
- **1.0**: Final response accurately summarizes findings and final verified state, with specific ports and/or PIDs.
- **0.75**: Accurate but less specific.
- **0.5**: Generally correct but vague or missing verification details.
- **0.25**: Potentially misleading or unsupported by the transcript.
- **0.0**: Incorrect result reporting.

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    import os
    import re
    import subprocess

    scores = {
        "skill_md_exists": 0.0,
        "skill_md_frontmatter": 0.0,
        "skill_md_reusable_content": 0.0,
        "skill_md_examples_and_safety": 0.0,
        "inspected_with_lsof": 0.0,
        "termination_attempted": 0.0,
        "verified_after_cleanup": 0.0,
        "ports_actually_cleared": 0.0,
        "result_communicated": 0.0,
    }

    skill_path = os.path.join(workspace_path, "SKILL.md")
    content = ""

    if os.path.isfile(skill_path):
        scores["skill_md_exists"] = 1.0
        try:
            with open(skill_path, "r", encoding="utf-8") as f:
                content = f.read()
        except Exception:
            content = ""

    frontmatter_match = re.search(r"^---\s*\n(.*?)\n---\s*\n?", content, re.DOTALL)
    body = content
    if frontmatter_match:
        fm = frontmatter_match.group(1)
        body = content[frontmatter_match.end():]
        has_name = bool(re.search(r"(?im)^\s*name\s*:\s*.+$", fm))
        has_desc = bool(re.search(r"(?im)^\s*description\s*:\s*.+$", fm))
        if has_name and has_desc:
            scores["skill_md_frontmatter"] = 1.0
        elif has_name or has_desc:
            scores["skill_md_frontmatter"] = 0.5

    body_lower = body.lower()

    # Reusable content: reward parameterization, workflow, and verification guidance.
    reusable_signals = 0
    if re.search(r"\b(arbitrary|any|one or more|range|ranges|port[s]?)\b", body_lower):
        reusable_signals += 1
    if re.search(r"\b(inspect|identify|find).{0,40}\b(lsof|listener|pid)\b", body_lower, re.DOTALL):
        reusable_signals += 1
    if re.search(r"\b(sort\s+-u|dedup|duplicate pid|unique pid)\b", body_lower):
        reusable_signals += 1
    if re.search(r"\b(verify|re-check|recheck|confirm).{0,50}\b(clear|free|listening|listener|lsof)\b", body_lower, re.DOTALL):
        reusable_signals += 1
    if re.search(r"\b(graceful|sigterm|term\b|kill\s+-15|kill before kill -9|force-kill when justified)\b", body_lower):
        reusable_signals += 1

    if reusable_signals >= 4:
        scores["skill_md_reusable_content"] = 1.0
    elif reusable_signals == 3:
        scores["skill_md_reusable_content"] = 0.75
    elif reusable_signals == 2:
        scores["skill_md_reusable_content"] = 0.5
    elif reusable_signals == 1:
        scores["skill_md_reusable_content"] = 0.25

    # Examples and safety/caveats.
    has_lsof_example = bool(re.search(r"(?im)^\s*(```[\s\S]*?lsof[\s\S]*?```|[-*]\s*`[^`]*lsof[^`]*`|`[^`]*lsof[^`]*`)", body))
    has_kill_example = bool(re.search(r"`[^`]*\bkill(?:\s+-\d+)?\b[^`]*`|```[\s\S]*?\bkill(?:\s+-\d+)?\b[\s\S]*?```", body, re.IGNORECASE))
    has_caveat = bool(re.search(r"\b(permission|sudo|macos|linux|missing lsof|not installed|shared process|risk|caution|careful|root)\b", body_lower))
    has_verify_guidance = bool(re.search(r"\b(verify|re-check|recheck|confirm)\b", body_lower))

    example_safety_score = 0
    if has_lsof_example:
        example_safety_score += 1
    if has_kill_example:
        example_safety_score += 1
    if has_caveat:
        example_safety_score += 1
    if has_verify_guidance:
        example_safety_score += 1

    if example_safety_score == 4:
        scores["skill_md_examples_and_safety"] = 1.0
    elif example_safety_score == 3:
        scores["skill_md_examples_and_safety"] = 0.75
    elif example_safety_score == 2:
        scores["skill_md_examples_and_safety"] = 0.5
    elif example_safety_score == 1:
        scores["skill_md_examples_and_safety"] = 0.25

    tool_commands = []
    assistant_messages = []
    tool_results_text = []

    for event in transcript:
        if event.get("type") != "message":
            continue
        msg = event.get("message", {})
        role = msg.get("role", "")
        raw_content = msg.get("content", "")

        text_parts = []
        if isinstance(raw_content, str):
            text_parts.append(raw_content)
        elif isinstance(raw_content, list):
            for part in raw_content:
                if isinstance(part, dict):
                    ptype = part.get("type", "")
                    if ptype == "text":
                        text_parts.append(part.get("text", ""))
                    elif ptype == "tool_use":
                        inp = part.get("input", "")
                        if isinstance(inp, dict):
                            cmd_text = " ".join(str(v) for v in inp.values())
                        else:
                            cmd_text = str(inp)
                        tool_commands.append(cmd_text)
                    elif ptype == "tool_result":
                        sub = part.get("content", "")
                        if isinstance(sub, str):
                            tool_results_text.append(sub)
                        elif isinstance(sub, list):
                            for item in sub:
                                if isinstance(item, dict) and item.get("type") == "text":
                                    tool_results_text.append(item.get("text", ""))
                                elif isinstance(item, str):
                                    tool_results_text.append(item)
                elif isinstance(part, str):
                    text_parts.append(part)

        if role == "assistant":
            assistant_messages.append(" ".join(text_parts))

    all_tool_commands = "\n".join(tool_commands)
    all_tool_results = "\n".join(tool_results_text)
    all_assistant = "\n".join(assistant_messages)

    inspect_patterns = [
        r"\blsof\b[^\n]*\b3000\b",
        r"\blsof\b[^\n]*:3000-3004\b",
        r"\blsof\b[^\n]*\b3001\b",
        r"\blsof\b[^\n]*\b3002\b",
        r"\blsof\b[^\n]*\b3003\b",
        r"\blsof\b[^\n]*\b3004\b",
    ]
    if any(re.search(p, all_tool_commands, re.IGNORECASE) for p in inspect_patterns):
        scores["inspected_with_lsof"] = 1.0

    termination_patterns = [
        r"\bkill\b",
        r"\bxargs\b[^\n]*\bkill\b",
        r"\bpkill\b",
    ]
    if any(re.search(p, all_tool_commands, re.IGNORECASE) for p in termination_patterns):
        scores["termination_attempted"] = 1.0

    verify_patterns = [
        r"\blsof\b[^\n]*:3000-3004\b",
        r"\blsof\b[^\n]*\b3000\b",
    ]
    lsof_command_count = len(re.findall(r"\blsof\b", all_tool_commands, re.IGNORECASE))
    if lsof_command_count >= 2 and any(re.search(p, all_tool_commands, re.IGNORECASE) for p in verify_patterns):
        scores["verified_after_cleanup"] = 1.0

    def port_clear(port: int) -> bool:
        try:
            result = subprocess.run(
                ["lsof", "-nP", f"-iTCP:{port}", "-sTCP:LISTEN", "-t"],
                capture_output=True,
                text=True,
                timeout=10,
                check=False,
            )
            return result.returncode != 0 or result.stdout.strip() == ""
        except Exception:
            return False

    clear_ports = [port_clear(p) for p in range(3000, 3005)]
    cleared_count = sum(1 for x in clear_ports if x)

    if cleared_count == 5:
        scores["ports_actually_cleared"] = 1.0
    elif cleared_count >= 3:
        scores["ports_actually_cleared"] = 0.5

    final_assistant = assistant_messages[-1] if assistant_messages else ""
    mentions_port_range = bool(re.search(r"3000|3001|3002|3003|3004", final_assistant))
    mentions_status = bool(re.search(r"\b(clear|cleared|free|freed|killed|terminated|no longer listening|still listening)\b", final_assistant, re.IGNORECASE))
    grounded_in_results = bool(
        re.search(r"\b(pid|pids)\b", final_assistant, re.IGNORECASE)
        or re.search(r"3000|3001|3002|3003|3004", final_assistant)
    )

    if mentions_port_range and mentions_status and grounded_in_results:
        scores["result_communicated"] = 1.0
    elif mentions_status:
        scores["result_communicated"] = 0.5

    return scores
```
