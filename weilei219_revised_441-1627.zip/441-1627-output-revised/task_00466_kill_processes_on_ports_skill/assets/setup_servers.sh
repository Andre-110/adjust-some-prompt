#!/bin/bash
set -euo pipefail

# Launch simple Python HTTP servers on ports 3000-3004 if they are not already
# listening. This makes the setup idempotent and avoids duplicate server trees
# across repeated task initialization.
for port in 3000 3001 3002 3003 3004; do
  if lsof -nP -iTCP:${port} -sTCP:LISTEN >/dev/null 2>&1; then
    continue
  fi
  python3 -m http.server "${port}" >/dev/null 2>&1 &
done

echo "Servers ensured on ports 3000-3004"
