#!/usr/bin/env python3
"""Metrics collector on port 3003"""
import http.server
import socketserver

PORT = 3003
Handler = http.server.SimpleHTTPRequestHandler

with socketserver.TCPServer(("0.0.0.0", PORT), Handler) as httpd:
    print(f"Metrics collector running on port {PORT}")
    httpd.serve_forever()
