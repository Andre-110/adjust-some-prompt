#!/usr/bin/env python3
"""WebSocket relay on port 3002"""
import http.server
import socketserver

PORT = 3002
Handler = http.server.SimpleHTTPRequestHandler

with socketserver.TCPServer(("0.0.0.0", PORT), Handler) as httpd:
    print(f"WebSocket relay running on port {PORT}")
    httpd.serve_forever()
