#!/usr/bin/env python3
"""API backend service on port 3001"""
import http.server
import socketserver

PORT = 3001
Handler = http.server.SimpleHTTPRequestHandler

with socketserver.TCPServer(("0.0.0.0", PORT), Handler) as httpd:
    print(f"API backend running on port {PORT}")
    httpd.serve_forever()
