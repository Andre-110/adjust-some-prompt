#!/usr/bin/env python3
"""Debug inspector on port 3004"""
import http.server
import socketserver

PORT = 3004
Handler = http.server.SimpleHTTPRequestHandler

with socketserver.TCPServer(("0.0.0.0", PORT), Handler) as httpd:
    print(f"Debug inspector running on port {PORT}")
    httpd.serve_forever()
