#!/usr/bin/env python3
"""Simple HTTP service on port 3000 - frontend dev server"""
import http.server
import socketserver

PORT = 3000
Handler = http.server.SimpleHTTPRequestHandler

with socketserver.TCPServer(("0.0.0.0", PORT), Handler) as httpd:
    print(f"Frontend dev server running on port {PORT}")
    httpd.serve_forever()
