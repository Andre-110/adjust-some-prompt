# StarryK — User Profile

## User Profile

- **Nickname:** StarryK
- **Gender:** Female
- **Age:** 28
- **Occupation:** Software Engineer at a mid-size fintech company in Shanghai
- **Education:** B.S. in Computer Science, Fudan University, Class of 2019

## Interests & Preferences

- Enjoys specialty coffee; prefers **light roast Ethiopian beans**
- Weekend hiking enthusiast
- Avid sci-fi reader — favorite author: **Liu Cixin**
- Communication style: prefers concise, to-the-point responses

## Health & Habits

- Runs **3× per week**
- Mild lactose intolerance (avoids dairy-heavy foods)
- Typical bedtime: around **12:30 AM**

## Relationship Positioning

- Treats AI as a **productivity partner** and **journaling companion**
- Open to discussing both professional and personal topics

## Current Status

- Working on a **microservices migration** project at her company
- Project deadline: **end of Q2 2025**
