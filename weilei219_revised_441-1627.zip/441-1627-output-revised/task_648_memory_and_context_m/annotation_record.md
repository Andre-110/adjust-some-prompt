# 修改记录

| 序号 | 修改项 | 修改原因 |
|------|--------|----------|
| 1 | 重写 Prompt，删除对“存在干扰文件/需判断权威性”的直白提示，改成更自然的用户请求 | 对应关键问题 5、6；减少出题人视角泄露并提升自主判断难度 |
| 2 | 修订 source_query 中的标题为英文 canonical headings | 对应关键问题 7；消除中英文标题不一致带来的混淆 |
| 3 | 重写 Expected Behavior，明确正确 ground truth、冲突来源、pending_questions 的正确更新逻辑，并加入“不能清空列表”要求 | 对应关键问题 1、3、4、5；补强难度并覆盖空数组绕过、年龄误判、pending 更新逻辑 |
| 4 | 重构 Grading Criteria，按基础结构/陷阱回避/pending_questions/重写质量分组，强调高权重能力点 | 对应关键问题 2、6；解决等权重导致区分度不足 |
| 5 | 全面修复 Automated Checks：改为精确校验 JSON 顶层键、非空 pending_questions、保留 running tracking、移除 tech/cat 已答问题，并删除宽松 `len>=2` 兜底 | 对应关键问题 1、4；修复空数组绕过与假阳性问题 |
| 6 | 修复年龄检查逻辑，改为基于 Age 上下文的匹配，避免数字 28/27 在日期或其他场景中误判 | 对应关键问题 3；降低年龄检查假阳性/假阴性 |
| 7 | 为 Spring Cloud / Ragdoll / 关系定位等关键陷阱增加更严格检查 | 对应关键问题 2、6；提升对事实冲突与陷阱回避能力的区分度 |
| 8 | 新增完整 LLM Judge Rubric，并为 1.0/0.75/0.5/0.25/0.0 提供可操作锚点 | 对应关键问题 6；补足 history_entry 与 memory_update 的定性质量评估 |
