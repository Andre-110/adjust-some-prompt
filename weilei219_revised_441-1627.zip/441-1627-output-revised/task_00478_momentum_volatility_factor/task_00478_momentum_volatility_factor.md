---
id: task_00478_momentum_volatility_factor
name: Momentum Volatility Composite Factor Calculation
category: Finance and Quantitative Trading
subcategory: Trading Strategies and Backtesting
difficulty: hard
grading_type: automated
timeout_seconds: 600
input_modality: text-only
external_dependency: none
skill_creation: false
workspace_files:
  - path: data/stock_prices.csv
    role: input
    description: Daily OHLCV price data for a stock (60 trading days)
  - path: data/sample_prices.csv
    role: noise
    description: Alternate price file that looks similar but is not the authoritative source for this task
  - path: data/factor_spec.json
    role: context
    description: JSON specification of the factor formula and parameters
  - path: data/market_metadata.json
    role: noise
    description: Market metadata for the stock (not needed for computation)
  - path: data/sector_performance.csv
    role: noise
    description: Sector-level performance summary (not needed for computation)
---

## Prompt

Please implement a small research utility for a factor called `momentum_volatility`.

Use the trading data in the workspace to compute the factor and save the result as:

- script: `momentum_volatility.py`
- output: `data/momentum_volatility.csv`

The factor family is a momentum-over-volatility style signal. The high-level formulation is:

`(Close / Ref(Close, N) - 1) / Std(Return, N)`

However, the exact operational parameters for this task should be taken from `data/factor_spec.json` if there is any ambiguity between files. Use the authoritative daily price source for the production calculation, not any example or sample file.

Your output CSV should contain a `Date` column and one factor column for `momentum_volatility`. Make a reasonable implementation choice for boundary rows where the lookback window is not fully available, but keep the output analytically usable and internally consistent.

## Expected Behavior

A correct submission should:

1. Create `momentum_volatility.py` that reads the authoritative input data and computes the `momentum_volatility` factor using the parameterization specified in `data/factor_spec.json`.
2. Produce `data/momentum_volatility.csv` with:
   - a `Date` column
   - one numeric factor column corresponding to `momentum_volatility`
3. Use a rolling volatility computed from daily close-to-close returns rather than from raw price levels.
4. Handle lookback-boundary rows consistently. Either:
   - retain the full date series and leave early unavailable factor rows blank/NaN, or
   - output only the valid rows after the factor becomes computable.
5. Produce factor values that are numerically consistent with the provided data and specification, with no infinite values and no obvious misuse of the sample/noise assets.

## Grading Criteria

- [ ] `momentum_volatility.py` exists and runs
- [ ] The implementation uses the authoritative source data and follows parameters from `data/factor_spec.json`
- [ ] `data/momentum_volatility.csv` is created and has the required columns
- [ ] The factor is computed from 20-period momentum divided by rolling standard deviation of returns
- [ ] Numeric results match the ground-truth factor series from `data/stock_prices.csv`
- [ ] The output handles boundary rows in a consistent, analytically valid way
- [ ] The submission avoids common traps such as using the sample file, using price volatility instead of return volatility, or using the wrong rolling window / ddof choice

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    import csv
    import json
    import math
    import statistics
    import subprocess
    import sys
    from pathlib import Path

    scores = {
        "script_exists_and_runs": 0.0,
        "authoritative_data_source": 0.0,
        "output_csv_exists": 0.0,
        "output_csv_structure": 0.0,
        "row_handling": 0.0,
        "key_point_accuracy": 0.0,
        "series_accuracy": 0.0,
        "trap_avoidance": 0.0,
    }

    ws = Path(workspace_path)
    script_path = ws / "momentum_volatility.py"
    output_path = ws / "data" / "momentum_volatility.csv"
    stock_path = ws / "data" / "stock_prices.csv"
    spec_path = ws / "data" / "factor_spec.json"

    if not script_path.exists():
        return scores

    scores["script_exists_and_runs"] = 0.5

    try:
        subprocess.run(
            [sys.executable, str(script_path)],
            cwd=str(ws),
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=120,
            check=True,
            text=True,
        )
        scores["script_exists_and_runs"] = 1.0
    except Exception:
        return scores

    try:
        script_text = script_path.read_text(encoding="utf-8", errors="ignore").lower()
    except Exception:
        script_text = ""

    authoritative_mentions = 0
    if "stock_prices.csv" in script_text:
        authoritative_mentions += 1
    if "factor_spec.json" in script_text:
        authoritative_mentions += 1
    if "sample_prices.csv" not in script_text:
        authoritative_mentions += 1
    scores["authoritative_data_source"] = authoritative_mentions / 3.0

    if not output_path.exists():
        return scores
    scores["output_csv_exists"] = 1.0

    try:
        with open(output_path, "r", encoding="utf-8", newline="") as f:
            reader = csv.DictReader(f)
            headers = reader.fieldnames or []
            out_rows = list(reader)
    except Exception:
        return scores

    headers_lower = [h.strip().lower() for h in headers]
    has_date = "date" in headers_lower
    factor_candidates = [
        h for h in headers
        if h.strip().lower() in {
            "momentum_volatility", "factor", "mv_factor", "momentum_vol", "mom_vol"
        }
    ]
    if has_date and factor_candidates:
        scores["output_csv_structure"] = 1.0
    elif has_date and len(headers) >= 2:
        scores["output_csv_structure"] = 0.5
    else:
        scores["output_csv_structure"] = 0.0

    if not out_rows:
        return scores

    factor_col = factor_candidates[0] if factor_candidates else None
    if factor_col is None:
        non_date_cols = [h for h in headers if h.strip().lower() != "date"]
        if len(non_date_cols) == 1:
            factor_col = non_date_cols[0]
        elif len(headers) >= 2:
            factor_col = headers[-1]
        else:
            return scores

    try:
        with open(spec_path, "r", encoding="utf-8") as f:
            spec = json.load(f)
    except Exception:
        return scores

    lookback = int(spec.get("lookback_period", 20))
    ddof = int(spec.get("volatility_ddof", 0))
    min_periods = int(spec.get("min_periods", lookback))
    if min_periods != lookback:
        min_periods = lookback

    try:
        with open(stock_path, "r", encoding="utf-8", newline="") as f:
            reader = csv.DictReader(f)
            stock_rows = list(reader)
    except Exception:
        return scores

    dates = [r["Date"] for r in stock_rows]
    closes = [float(r["Close"]) for r in stock_rows]

    returns = [None]
    for i in range(1, len(closes)):
        returns.append(closes[i] / closes[i - 1] - 1.0)

    truth = []
    for i in range(len(closes)):
        if i < lookback:
            truth.append(None)
            continue
        mom = closes[i] / closes[i - lookback] - 1.0
        window = returns[i - lookback + 1:i + 1]
        if len(window) < min_periods or any(v is None for v in window):
            truth.append(None)
            continue
        mean_w = sum(window) / len(window)
        denom_n = len(window) - ddof
        if denom_n <= 0:
            truth.append(None)
            continue
        var = sum((v - mean_w) ** 2 for v in window) / denom_n
        vol = math.sqrt(var)
        if vol == 0 or not math.isfinite(vol):
            truth.append(None)
            continue
        truth.append(mom / vol)

    truth_by_date = {d: v for d, v in zip(dates, truth)}

    parsed = []
    bad_numeric = 0
    for row in out_rows:
        d = row.get("Date") or row.get("date")
        if d is None:
            continue
        raw = row.get(factor_col, "")
        raw_s = str(raw).strip()
        if raw_s == "" or raw_s.lower() in {"nan", "none", "null"}:
            parsed.append((d, None))
        else:
            try:
                val = float(raw_s)
                if math.isfinite(val):
                    parsed.append((d, val))
                else:
                    parsed.append((d, None))
                    bad_numeric += 1
            except Exception:
                parsed.append((d, None))
                bad_numeric += 1

    parsed_dates = [d for d, _ in parsed]
    valid_truth_dates = [d for d, v in zip(dates, truth) if v is not None]

    full_series_ok = len(parsed) == len(dates) and parsed_dates == dates
    dropna_series_ok = (
        len(parsed) == len(valid_truth_dates)
        and parsed_dates == valid_truth_dates
        and all(v is not None for _, v in parsed)
    )

    if full_series_ok or dropna_series_ok:
        scores["row_handling"] = 1.0
    elif len(parsed) >= len(valid_truth_dates) - 2:
        scores["row_handling"] = 0.5

    pred_by_date = {d: v for d, v in parsed}

    key_dates = ["2024-10-01", "2024-10-15", "2024-10-31", "2024-11-22"]
    key_matches = 0
    key_total = 0
    for kd in key_dates:
        tv = truth_by_date.get(kd)
        if tv is None:
            continue
        key_total += 1
        pv = pred_by_date.get(kd)
        if pv is None:
            continue
        rel_err = abs(pv - tv) / max(1e-12, abs(tv))
        if rel_err <= 1e-4:
            key_matches += 1
    if key_total:
        scores["key_point_accuracy"] = key_matches / key_total

    aligned_truth = []
    aligned_pred = []
    exact_count = 0
    near_count = 0
    wrong_sign_count = 0

    for d in dates:
        tv = truth_by_date[d]
        if tv is None:
            continue
        pv = pred_by_date.get(d)
        if pv is None:
            continue
        aligned_truth.append(tv)
        aligned_pred.append(pv)
        rel_err = abs(pv - tv) / max(1e-12, abs(tv))
        if rel_err <= 1e-6:
            exact_count += 1
        if rel_err <= 1e-4:
            near_count += 1
        if pv == 0:
            if tv != 0:
                wrong_sign_count += 1
        elif (pv > 0) != (tv > 0):
            wrong_sign_count += 1

    def corr(xs, ys):
        if len(xs) < 2:
            return None
        mx = statistics.fmean(xs)
        my = statistics.fmean(ys)
        dx = [x - mx for x in xs]
        dy = [y - my for y in ys]
        vx = sum(v * v for v in dx)
        vy = sum(v * v for v in dy)
        if vx <= 0 or vy <= 0:
            return None
        cov = sum(a * b for a, b in zip(dx, dy))
        return cov / math.sqrt(vx * vy)

    if aligned_truth:
        coverage = len(aligned_truth) / len(valid_truth_dates)
        c = corr(aligned_truth, aligned_pred)

        score = 0.0
        if coverage >= 0.95:
            score += 0.25
        elif coverage >= 0.80:
            score += 0.15
        elif coverage >= 0.60:
            score += 0.05

        if c is not None:
            if c >= 0.9999:
                score += 0.35
            elif c >= 0.99:
                score += 0.25
            elif c >= 0.95:
                score += 0.10

        near_ratio = near_count / len(valid_truth_dates)
        if near_ratio >= 0.95:
            score += 0.40
        elif near_ratio >= 0.75:
            score += 0.25
        elif near_ratio >= 0.50:
            score += 0.10

        scores["series_accuracy"] = min(score, 1.0)

    trap_score = 1.0
    if "sample_prices.csv" in script_text:
        trap_score -= 0.5
    if bad_numeric > 0:
        trap_score -= 0.25
    if aligned_truth:
        if wrong_sign_count / len(aligned_truth) > 0.05:
            trap_score -= 0.25
        # Detect common implementation trap: using sample std (ddof=1) instead of spec ddof=0.
        alt_truth = []
        for i in range(len(closes)):
            if i < lookback:
                alt_truth.append(None)
                continue
            mom = closes[i] / closes[i - lookback] - 1.0
            window = returns[i - lookback + 1:i + 1]
            if len(window) < lookback or any(v is None for v in window):
                alt_truth.append(None)
                continue
            mean_w = sum(window) / len(window)
            var = sum((v - mean_w) ** 2 for v in window) / (len(window) - 1)
            vol = math.sqrt(var)
            alt_truth.append(None if vol == 0 or not math.isfinite(vol) else mom / vol)

        alt_aligned_truth = []
        alt_aligned_pred = []
        for d in dates:
            tv = alt_truth[dates.index(d)]
            pv = pred_by_date.get(d)
            if tv is None or pv is None:
                continue
            alt_aligned_truth.append(tv)
            alt_aligned_pred.append(pv)

        c_main = corr(aligned_truth, aligned_pred) if len(aligned_truth) >= 2 else None
        c_alt = corr(alt_aligned_truth, alt_aligned_pred) if len(alt_aligned_truth) >= 2 else None
        if c_alt is not None and c_main is not None and c_alt > c_main + 1e-6 and scores["series_accuracy"] < 0.95:
            trap_score -= 0.25

    scores["trap_avoidance"] = max(0.0, trap_score)
    return scores
```
