---
id: task_00494_text_to_pdf_chinese_conversion
name: Convert Chinese Text to PDF File
category: Data Processing and Management
subcategory: File Format Conversion
difficulty: hard
grading_type: automated
timeout_seconds: 600
input_modality: text-only
external_dependency: none
workspace_files:
  - path: config/dingtalk_channel.yaml
    role: context
    description: DingTalk channel configuration for message delivery
  - path: data/chat_history.json
    role: input
    description: Chat history containing the original Chinese message to convert
  - path: data/cron_jobs_log.json
    role: input
    description: Scheduled reminder jobs log relevant to the reminder timing
  - path: data/message_content.txt
    role: input
    description: Plain text file containing the quoted Chinese message
  - path: templates/pdf_styles.css
    role: context
    description: CSS style template for PDF generation
skill_creation: false
---

## Prompt

帮我整理成一个正式一点的 PDF，并按钉钉通道的要求发出来。

我只要和这次“写报告提醒”相关的内容，不要把不相干的信息塞进去。你自己判断该以哪份数据为准：`data/message_content.txt`、`data/chat_history.json`、`data/cron_jobs_log.json` 里都有线索，但它们不一定完全从同一个角度记录这件事。

PDF 里至少要让我一眼看清这几件事：
- 原始消息内容
- 发送人
- 原始消息时间
- 实际提醒时间
- 接收人 staff_id
- 使用的投递通道

排版别太随便；如果现有样式能用就用上。完成后按配置里约定的格式给出发送标签，不要只说“已经保存了”。

## Expected Behavior

The agent should complete a multi-source reconciliation and PDF delivery task, not merely convert a single line of text.

Correct resolution path and ground truth:

1. **Use multiple assets, not just the text file**
   - `data/message_content.txt` contains the quoted reminder request text:
     - `可以在4点32分钟时提醒我写报告吗？`
   - `data/chat_history.json` contains:
     - the original message record with sender and original timestamp
     - a follow-up request to convert that message into PDF
   - `data/cron_jobs_log.json` contains reminder job execution metadata, including recipient and delivery channel.
   - The task requires combining these sources into one coherent PDF.

2. **Identify the correct “original message”**
   - In `chat_history.json`, the second message quotes the first via `quote_ref`.
   - The original message to document is therefore the conversation item:
     - `message_id`: `213f5a2f_fee_19bfa17909e_69ade71`
     - `from`: `杨庭顺`
     - `staff_id`: `manager1071`
     - `timestamp`: `2026-02-23T04:30:00+08:00`
     - `content`: `可以在4点32分钟时提醒我写报告吗？`
   - The agent should not mistake the second message (`帮忙把这条信息转成PDF格式文件发出来。`) for the target content.

3. **Resolve “actual reminder time” from cron logs**
   - `cron_jobs_log.json` contains two candidate jobs with nearly identical payloads.
   - The most appropriate “actual reminder time” should be taken from the scheduled execution time (`schedule.at`) associated with the reminder jobs, not from the original chat timestamp.
   - Valid job schedule times present in the asset are:
     - `2026-02-22T20:32:21.935Z`
     - `2026-02-22T20:32:39.144Z`
   - Since both are for the same recipient/channel/payload and represent closely related reminder attempts, a strong solution should recognize the ambiguity and choose a defensible interpretation:
     - preferably the **later updated job** (`quick-ca`, `updatedAtMs` larger) with schedule.at `2026-02-22T20:32:39.144Z`, or
     - otherwise explicitly indicate that two related reminder jobs exist.
   - For automated grading, full credit is awarded if the PDF includes at least one of the exact schedule times above and correctly identifies recipient/channel.

4. **Required PDF content**
   The PDF should contain, in readable Chinese text, all of the following factual content:
   - original message text: `可以在4点32分钟时提醒我写报告吗？`
   - sender name: `杨庭顺`
   - original message timestamp: `2026-02-23T04:30:00+08:00`
   - recipient staff_id from cron delivery: `manager1071`
   - delivery channel: `clawdbot-dingtalk`
   - at least one actual reminder time from cron schedule:
     - `2026-02-22T20:32:21.935Z` or `2026-02-22T20:32:39.144Z`

5. **Formatting expectation**
   - The PDF should be more than a raw one-line dump.
   - If using an HTML-to-PDF route, the agent should ideally apply `templates/pdf_styles.css`.
   - If using a direct PDF library, the output should still be structured into labeled fields or sections.
   - The PDF must be valid and text-extractable enough for the required strings to be found.

6. **Chinese rendering quality**
   - The important quality signal is that the PDF actually contains the intended Chinese text in extractable/readable form.
   - The agent may use a workspace font, a system font, or a rendering pipeline that embeds/handles CJK correctly.
   - The task should not require downloading a font if an existing valid solution works.

7. **Delivery requirement**
   - The agent must attempt delivery using the DingTalk tag format defined in `config/dingtalk_channel.yaml`:
     - `[DING:FILE path="/absolute/local/path"]`
   - Merely saying the PDF was created or saved is insufficient.
   - The path in the send tag should point to an existing PDF file in the workspace.

Key traps to avoid:
- Do **not** use only `message_content.txt` and ignore sender/timestamps/channel data.
- Do **not** treat the second chat message (“帮忙把这条信息转成PDF格式文件发出来。”) as the message to render.
- Do **not** use vague delivery language; a proper DingTalk file tag is required.
- Do **not** rely on font filename heuristics; actual PDF content correctness matters.

## Grading Criteria

- [ ] A valid PDF file is created in the workspace
- [ ] The PDF contains the exact original Chinese message text from `data/message_content.txt`
- [ ] The PDF includes the correct sender and original message timestamp from `data/chat_history.json`
- [ ] The PDF includes the correct recipient staff_id and delivery channel from `data/cron_jobs_log.json`
- [ ] The PDF includes at least one valid actual reminder time from the cron schedule data
- [ ] The PDF is structured/formal enough to include multiple labeled facts rather than only a bare message line
- [ ] The assistant outputs a DingTalk delivery tag exactly following `send_tag_format`, and the referenced absolute path exists

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    import os
    import re
    import json
    import glob

    scores = {
        "pdf_file_exists": 0.0,
        "pdf_valid_header": 0.0,
        "pdf_text_contains_message": 0.0,
        "pdf_contains_sender_and_original_time": 0.0,
        "pdf_contains_delivery_metadata": 0.0,
        "pdf_contains_actual_reminder_time": 0.0,
        "delivery_attempted": 0.0,
    }

    target_message = "可以在4点32分钟时提醒我写报告吗？"
    target_sender = "杨庭顺"
    target_original_time = "2026-02-23T04:30:00+08:00"
    target_recipient = "manager1071"
    target_channel = "clawdbot-dingtalk"
    valid_schedule_times = {
        "2026-02-22T20:32:21.935Z",
        "2026-02-22T20:32:39.144Z",
    }

    # Find PDF files in workspace
    pdf_files = glob.glob(os.path.join(workspace_path, "**", "*.pdf"), recursive=True)

    extracted_by_pdf = {}

    def extract_text_from_pdf(pdf_path: str) -> str:
        texts = []

        try:
            import pdfplumber  # type: ignore
            with pdfplumber.open(pdf_path) as pdf:
                for page in pdf.pages:
                    txt = page.extract_text() or ""
                    if txt:
                        texts.append(txt)
        except Exception:
            pass

        if "".join(texts).strip():
            return "\n".join(texts)

        try:
            from pypdf import PdfReader  # type: ignore
            reader = PdfReader(pdf_path)
            for page in reader.pages:
                txt = page.extract_text() or ""
                if txt:
                    texts.append(txt)
        except Exception:
            pass

        return "\n".join(texts)

    best_pdf = None

    if pdf_files:
        scores["pdf_file_exists"] = 1.0

        for pdf_path in pdf_files:
            try:
                with open(pdf_path, "rb") as f:
                    header = f.read(5)
                    if header == b"%PDF-":
                        scores["pdf_valid_header"] = 1.0
                extracted_text = extract_text_from_pdf(pdf_path)
                extracted_by_pdf[pdf_path] = extracted_text
            except Exception:
                extracted_by_pdf[pdf_path] = ""

        # Prefer a PDF that contains the target message; otherwise use the first one
        for path, txt in extracted_by_pdf.items():
            if target_message in txt:
                best_pdf = path
                break
        if best_pdf is None and pdf_files:
            best_pdf = pdf_files[0]

    best_text = extracted_by_pdf.get(best_pdf, "") if best_pdf else ""

    if target_message in best_text:
        scores["pdf_text_contains_message"] = 1.0

    if target_sender in best_text and target_original_time in best_text:
        scores["pdf_contains_sender_and_original_time"] = 1.0
    elif target_sender in best_text or target_original_time in best_text:
        scores["pdf_contains_sender_and_original_time"] = 0.5

    delivery_hits = 0
    if target_recipient in best_text:
        delivery_hits += 1
    if target_channel in best_text:
        delivery_hits += 1
    if delivery_hits == 2:
        scores["pdf_contains_delivery_metadata"] = 1.0
    elif delivery_hits == 1:
        scores["pdf_contains_delivery_metadata"] = 0.5

    reminder_time_hits = sum(1 for t in valid_schedule_times if t in best_text)
    if reminder_time_hits >= 1:
        scores["pdf_contains_actual_reminder_time"] = 1.0

    # Strict DingTalk delivery tag check
    tag_pattern = re.compile(r'\[DING:FILE path="([^"]+\.pdf)"\]')
    found_valid_delivery_tag = False

    for event in transcript:
        if event.get("type") != "message":
            continue
        msg = event.get("message", {})
        if msg.get("role") != "assistant":
            continue
        content = str(msg.get("content", ""))

        for match in tag_pattern.finditer(content):
            raw_path = match.group(1)
            if os.path.isabs(raw_path) and os.path.exists(raw_path):
                try:
                    common = os.path.commonpath([workspace_path, raw_path])
                    if common == workspace_path:
                        found_valid_delivery_tag = True
                        break
                except Exception:
                    pass
        if found_valid_delivery_tag:
            break

    if found_valid_delivery_tag:
        scores["delivery_attempted"] = 1.0

    return scores
```

## LLM Judge Rubric

Evaluate the final answer and produced artifact holistically, with emphasis on evidence-backed reconciliation across files, delivery compliance, and edge-case handling.

### 1.0
- Correctly identifies the quoted original message rather than the later “convert to PDF” request.
- Produces a valid PDF whose extracted text clearly includes all core facts:
  - original message text
  - sender
  - original message timestamp
  - recipient staff_id
  - delivery channel
  - at least one actual reminder schedule time
- Output is organized and formal, not a bare dump.
- Uses or meaningfully approximates the provided style/template intent.
- Provides a DingTalk send tag exactly in the configured format with a valid absolute PDF path.
- If the cron log ambiguity is noticed, the resolution is explicitly justified or both candidate reminder times are clearly represented.

### 0.75
- PDF is valid and includes the original message text plus most metadata.
- Minor omission or ambiguity in one field (for example, only one of recipient/channel is surfaced clearly, or cron ambiguity is not discussed but one valid schedule time is included).
- Delivery tag is present and valid.
- Formatting is acceptable though not polished.

### 0.5
- PDF contains the correct Chinese message and some relevant metadata, but important cross-file reconciliation is incomplete.
- Typical failures:
  - omits sender or original timestamp
  - omits recipient/channel
  - uses only partial cron information
  - weak structure or sparse formatting
- Delivery attempt may be malformed, vague, or missing strict tag compliance.

### 0.25
- Produces a PDF, but it behaves like a simple text-to-PDF conversion rather than a reconciled report.
- May contain only the message text, or may confuse the target content with the “convert this to PDF” instruction.
- Metadata is mostly absent or wrong.
- No proper DingTalk send tag.

### 0.0
- No usable PDF, unreadable/incorrect PDF content, or final output fails the core request.
- Chinese content is missing or wrong.
- Delivery format is not attempted in any meaningful way.
