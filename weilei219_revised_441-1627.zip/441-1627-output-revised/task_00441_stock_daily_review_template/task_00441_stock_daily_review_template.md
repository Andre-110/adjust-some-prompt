---
id: task_00441_stock_daily_review_template
name: Stock Daily Review Template Generation
category: Finance and Quantitative Trading
subcategory: Trade Execution and Management
difficulty: easy
grading_type: hybrid
grading_weights: {automated: 0.4, llm_judge: 0.6}
timeout_seconds: 600
input_modality: text-only
external_dependency: none
workspace_files: []
skill_creation: false
---

## Prompt

请根据 `assets/` 中已经提供的交易与市场数据，生成一份 **2025-01-23 的股票日终复盘文档**，而不是空白模板。

复盘文档需要放在 `clawfile` 文件夹中，文件格式用 Markdown。内容至少覆盖以下四部分，但不要只写标题，必须填入可核对的实际数据：

1. **Market Overview**：总结 2025-01-23 当天主要指数、波动率、成交量等市场表现。
2. **Industry / Sector Analysis**：结合当日板块表现，指出相对强弱板块，并联系你的持仓或观察名单说明原因。
3. **Individual Stock / Portfolio Review**：基于当前持仓，概括组合情况，并点名几个值得复盘的标的；如果某只股票同时出现在持仓、交易记录或观察名单中，优先纳入分析。
4. **Trading Insights / Notes**：写出当日交易复盘、风险点、下一步观察重点。

额外要求：
- 文档必须明确体现 **2025-01-23** 这一天，而不是泛泛的“日常模板”。
- 需要实际使用并整合多个资产文件中的信息；如果不同文件提供的信息侧重点不同，请自行取舍并保持叙述一致。
- 不要求面面俱到，但关键数字、交易事件和结论不能明显与资产数据冲突。
- 可以简洁，但不能编造成没有依据的数据。
- 将最终文件保存到 `clawfile` 文件夹中即可。

## Expected Behavior

The agent should:

1. Create a `clawfile` directory in the writable workspace (or use `/root/clawfile` if available and writable).
2. Read and integrate information from the provided assets, especially:
   - `assets/data/market_index_history.csv`
   - `assets/data/portfolio_holdings.csv`
   - `assets/data/recent_trades_log.csv`
   - `assets/data/sector_performance.json`
   - optionally `assets/config/trading_watchlist.yaml`
3. Produce a **filled** Markdown daily review for **2025-01-23**, not a blank template.
4. Include the following sections with substantive content:
   - **Market Overview** with correct 2025-01-23 market data. The expected key facts available from assets are:
     - S&P 500 close: **4785.30** (**-0.35%**)
     - Nasdaq close: **14965.80** (**-0.36%**)
     - DJIA close: **37380.50** (**-0.17%**)
     - Russell 2000 close: **2028.40** (**-0.60%**)
     - VIX close: **13.45**
     - Volume: **11.0 billion**
   - **Industry / Sector Analysis** that reflects the sector JSON for report date 2025-01-23. Strong examples include:
     - strongest daily sectors among listed sectors: **Financials +0.35%**, **Communication Services +0.25%**, **Healthcare +0.18%**
     - weak sectors: **Energy -0.85%**, **Technology -0.42%**, **Real Estate -0.30%**, **Utilities -0.10%**
     - analysis should not invert the direction of these sectors.
   - **Individual Stock / Portfolio Review** that uses holdings data correctly. Important ground-truth values include:
     - total portfolio market value: **491,913.00**
     - total unrealized P&L: **61,248.00**
     - largest holding by weight: **NVDA (24.8%)**
     - top unrealized P&L contributors: **NVDA 16,375.00**, **MSFT 15,816.00**, **AAPL 13,175.00**
     - negative unrealized P&L holdings: **JNJ -420.00**, **NEE -328.00**
   - **Trading Insights / Notes** that references the actual same-day trade:
     - **T012**, date **2025-01-23**
     - ticker **NEE**
     - action **SELL**
     - quantity **30**
     - price **67.80**
     - strategy **stop_loss**
     - note indicating utilities weakness / rotation out of the position
5. Maintain consistency across sections. For example:
   - If describing Utilities as weak, that should align with NEE stop-loss and Utilities sector data.
   - If highlighting Technology as a core exposure, that should align with NVDA/MSFT/AAPL weights and P&L.
   - If using watchlist names such as LLY, GS, PLTR, META, FCX, ensure they are not falsely described as current holdings unless supported by holdings data.
6. Save the final file inside a `clawfile` directory.

## Grading Criteria

- [ ] A Markdown file exists inside a `clawfile` directory
- [ ] The document is clearly a filled **2025-01-23** daily review rather than a blank template
- [ ] The market overview includes correct 2025-01-23 index data from the asset file
- [ ] The sector analysis reflects actual sector winners/laggards from the JSON data
- [ ] The portfolio review uses holdings data accurately, including portfolio totals or correct major holdings
- [ ] The trading notes correctly capture the 2025-01-23 NEE stop-loss trade (T012)
- [ ] The write-up is internally consistent and does not confuse watchlist names, holdings, and executed trades
- [ ] The document uses readable structure (headings, bullets, or tables)

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    import os
    import re
    import csv
    import json
    from pathlib import Path

    scores = {
        "markdown_file_exists_in_clawfile": 0.0,
        "dated_filled_review": 0.0,
        "market_data_accuracy": 0.0,
        "sector_data_accuracy": 0.0,
        "portfolio_data_accuracy": 0.0,
        "trade_data_accuracy": 0.0,
        "structured_markdown": 0.0,
    }

    def find_clawfile_dir():
        candidates = [
            os.path.join(workspace_path, "clawfile"),
            "/root/clawfile",
            os.path.join(workspace_path, "root", "clawfile"),
        ]
        for c in candidates:
            if os.path.isdir(c):
                return c
        return None

    def read_text(path: str):
        for enc in ("utf-8", "latin-1"):
            try:
                with open(path, "r", encoding=enc) as f:
                    return f.read()
            except Exception:
                pass
        return ""

    clawfile_dir = find_clawfile_dir()
    if clawfile_dir is None:
        return scores

    md_files = []
    for name in os.listdir(clawfile_dir):
        path = os.path.join(clawfile_dir, name)
        if os.path.isfile(path) and name.lower().endswith(".md"):
            md_files.append(path)

    if not md_files:
        return scores

    scores["markdown_file_exists_in_clawfile"] = 1.0

    contents = []
    for path in md_files:
        text = read_text(path)
        if text.strip():
            contents.append(text)

    if not contents:
        return scores

    content = "\n\n".join(contents)
    content_lower = content.lower()

    if ("2025-01-23" in content or "2025/01/23" in content or "jan 23, 2025" in content_lower or "january 23, 2025" in content_lower):
        section_hits = 0
        for pat in [
            r"^\s*#{1,6}\s*market overview",
            r"^\s*#{1,6}\s*(industry|sector)",
            r"^\s*#{1,6}\s*(individual stock|portfolio review|individual stock / portfolio review)",
            r"^\s*#{1,6}\s*(trading insights|notes|trading insights / notes)",
        ]:
            if re.search(pat, content, re.IGNORECASE | re.MULTILINE):
                section_hits += 1
        if section_hits >= 3:
            scores["dated_filled_review"] = 1.0

    asset_market = os.path.join(workspace_path, "assets", "data", "market_index_history.csv")
    asset_holdings = os.path.join(workspace_path, "assets", "data", "portfolio_holdings.csv")
    asset_trades = os.path.join(workspace_path, "assets", "data", "recent_trades_log.csv")
    asset_sectors = os.path.join(workspace_path, "assets", "data", "sector_performance.json")

    market_ok = False
    try:
        with open(asset_market, "r", encoding="utf-8") as f:
            rows = list(csv.DictReader(f))
        row = next(r for r in rows if r["date"] == "2025-01-23")
        required_pairs = [
            row["sp500_close"],
            row["sp500_change_pct"],
            row["nasdaq_close"],
            row["nasdaq_change_pct"],
            row["djia_close"],
            row["djia_change_pct"],
            row["vix_close"],
            row["volume_billion"],
        ]
        hit_count = 0
        for val in required_pairs:
            if val in content:
                hit_count += 1
        if hit_count >= 6:
            market_ok = True
    except Exception:
        market_ok = False
    scores["market_data_accuracy"] = 1.0 if market_ok else 0.0

    sector_ok = False
    try:
        with open(asset_sectors, "r", encoding="utf-8") as f:
            sector_data = json.load(f)
        sectors = {s["name"]: s["daily_change_pct"] for s in sector_data["sectors"]}
        required_sector_pairs = [
            ("Financials", sectors["Financials"]),
            ("Energy", sectors["Energy"]),
            ("Technology", sectors["Technology"]),
            ("Utilities", sectors["Utilities"]),
        ]
        pair_hits = 0
        for name, val in required_sector_pairs:
            val_str = f"{val:.2f}"
            if name.lower() in content_lower and (val_str in content or f"{val:+.2f}" in content):
                pair_hits += 1
        if pair_hits >= 3:
            sector_ok = True
    except Exception:
        sector_ok = False
    scores["sector_data_accuracy"] = 1.0 if sector_ok else 0.0

    portfolio_ok = False
    try:
        with open(asset_holdings, "r", encoding="utf-8") as f:
            rows = list(csv.DictReader(f))
        total_mv = sum(float(r["market_value"]) for r in rows)
        total_pnl = sum(float(r["unrealized_pnl"]) for r in rows)
        largest = max(rows, key=lambda r: float(r["weight_pct"]))
        negative_names = sorted([r["ticker"] for r in rows if float(r["unrealized_pnl"]) < 0])
        checks = 0

        total_mv_str = f"{total_mv:.2f}"
        total_pnl_str = f"{total_pnl:.2f}"
        if total_mv_str in content:
            checks += 1
        if total_pnl_str in content:
            checks += 1
        if largest["ticker"].lower() in content_lower and largest["weight_pct"] in content:
            checks += 1
        if all(t.lower() in content_lower for t in negative_names):
            checks += 1
        if "nvda" in content_lower and "16375.00" in content:
            checks += 1

        if checks >= 4:
            portfolio_ok = True
    except Exception:
        portfolio_ok = False
    scores["portfolio_data_accuracy"] = 1.0 if portfolio_ok else 0.0

    trade_ok = False
    try:
        with open(asset_trades, "r", encoding="utf-8") as f:
            rows = list(csv.DictReader(f))
        trade = next(r for r in rows if r["trade_id"] == "T012")
        required_trade_terms = [
            trade["trade_id"].lower(),
            trade["date"].lower(),
            trade["ticker"].lower(),
            trade["action"].lower(),
            trade["quantity"].lower(),
            trade["price"].lower(),
            trade["strategy"].lower(),
        ]
        if all(term in content_lower for term in required_trade_terms):
            trade_ok = True
    except Exception:
        trade_ok = False
    scores["trade_data_accuracy"] = 1.0 if trade_ok else 0.0

    if (
        re.search(r"^\s*#{1,6}\s+", content, re.MULTILINE)
        and (
            re.search(r"\|[^\n]+\|", content) is not None
            or re.search(r"^\s*[-*]\s+", content, re.MULTILINE) is not None
        )
    ):
        scores["structured_markdown"] = 1.0

    return scores
```

## LLM Judge Rubric

### Data Accuracy and Source Consistency (Weight: 25%)
- 1.0: Key facts are accurately drawn from the provided assets across market data, sector data, holdings, and the 2025-01-23 trade log. No material contradictions. Important numbers such as index closes/changes, portfolio totals or major holdings, and the NEE T012 stop-loss trade are correct.
- 0.75: Mostly accurate use of source data with only minor omissions or small non-critical inaccuracies; the main same-day trade and overall market/portfolio picture are still correct.
- 0.5: Some real asset data is used, but there are notable inaccuracies, partial fabrication, or confusion between holdings, watchlist names, and trades.
- 0.25: Output appears loosely based on the assets but contains major factual mistakes, invented figures, or multiple source-confusion errors.
- 0.0: Little to no evidence of using the provided data; output is generic, fabricated, or substantially inconsistent with the assets.

### Analytical Quality and Decision-Making (Weight: 25%)
- 1.0: Goes beyond copying numbers; identifies meaningful relationships and trade-offs across files (e.g., weak Utilities aligns with NEE stop-loss, strong Financials supports JPM/GS discussion, heavy Technology exposure creates concentration risk despite strong unrealized gains).
- 0.75: Includes some real interpretation and prioritization, but analysis is somewhat shallow or misses one important cross-file connection.
- 0.5: Mostly descriptive summary of facts with limited synthesis or weak prioritization.
- 0.25: Minimal analysis; largely a list of disconnected facts or generic investing advice.
- 0.0: No meaningful analysis or decision-making content.

### Coverage of Required Review Sections (Weight: 20%)
- 1.0: Clearly covers Market Overview, Industry/Sector Analysis, Individual Stock/Portfolio Review, and Trading Insights/Notes, with substantive filled content in each.
- 0.75: Covers all sections but one is noticeably thin or only partially filled.
- 0.5: Missing one major section or one section is effectively empty.
- 0.25: Missing two or more major sections, or most sections are placeholder-like.
- 0.0: Not structured as a usable daily review.

### Internal Consistency and Boundary Handling (Weight: 15%)
- 1.0: Correctly distinguishes among current holdings, watchlist names, and executed trades; avoids claiming unsupported facts; handles edge cases such as mentioning GS/LLY/PLTR/META as watchlist or trade-related rather than current holdings unless explicitly supported.
- 0.75: Mostly consistent, with only one minor boundary error or wording ambiguity.
- 0.5: A few inconsistencies or unsupported leaps, but the overall review remains understandable.
- 0.25: Repeated confusion between data sources or several unsupported claims.
- 0.0: Internal logic is badly inconsistent or contradicts the provided files in multiple places.

### Formatting and File Output Compliance (Weight: 15%)
- 1.0: A readable Markdown document is saved in a `clawfile` directory, with clear headings and organization that make the review immediately usable.
- 0.75: File placement and formatting are mostly correct, with minor readability or organization issues.
- 0.5: File exists but formatting is rough, or path compliance is imperfect.
- 0.25: Hard to find or poorly formatted output.
- 0.0: No output file or unusable format.
