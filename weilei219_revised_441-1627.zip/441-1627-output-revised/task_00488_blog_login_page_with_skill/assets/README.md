# DevNotes Blog

A personal tech blog built from scratch.

## Project Structure

```
├── blog-config.json      # Site configuration
├── theme-variables.css   # CSS custom properties / design tokens
├── users.csv             # User accounts export (for migration)
├── login/                # Login page (TODO)
├── dashboard/            # Admin dashboard (planned)
└── api/                  # Backend API (planned)
```

## Getting Started

1. Set up the database using `blog-config.json` credentials
2. Create the login page in `/login` directory
3. Build out the dashboard and API

## Authentication

The blog uses username/password authentication. See `blog-config.json` for auth settings:
- Max 5 login attempts before lockout
- 15-minute lockout duration
- Passwords require minimum 8 characters with special characters
- Sessions expire after 1 hour

## Tech Stack

- Frontend: Vanilla HTML/CSS/JS (no framework)
- Backend: Node.js + Express (planned)
- Database: PostgreSQL
- Auth: Session-based with bcrypt password hashing

## Status

🟡 In Progress — Login page needs to be built
