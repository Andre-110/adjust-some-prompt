---
id: task_00488_blog_login_page_with_skill
name: Blog Login Page Creation with Skill
category: Workflow and Agent Orchestration
subcategory: Script and Terminal Automation
difficulty: medium
grading_type: hybrid
grading_weights: {automated: 0.8, llm: 0.2}
timeout_seconds: 600
input_modality: text-only
external_dependency: none
workspace_files:
  - path: blog-config.json
    role: context
    description: Blog site configuration including authentication settings (password rules, session timeout, lockout policy)
  - path: README.md
    role: context
    description: Project README describing the blog's structure, tech stack, and current status
  - path: theme-variables.css
    role: context
    description: CSS custom properties / design tokens for the blog's theme (colors, typography, spacing, shadows)
  - path: users.csv
    role: context
    description: Exported user accounts table for reference (usernames, roles, status)
skill_creation: true
---

## Prompt

I’m setting up the missing `/login` area for my DevNotes blog and I want something I could realistically keep in the repo instead of a one-off mockup.

Please create a reusable `SKILL.md` in the workspace root for scaffolding small vanilla web UI pages, then create a `login/` folder with `index.html`, `style.css`, and `script.js`.

A few expectations so this fits the existing project instead of feeling generic:

- The login page should behave consistently with the project files already in the workspace.
- Don’t treat the config/theme files as optional inspiration — the implementation should actually align with them.
- The frontend should include client-side validation and a visible lockout countdown experience after too many failed attempts.
- Password validation should follow the project’s configured rules rather than arbitrary hardcoded ones.
- Styling should use the existing theme token system rather than standalone ad hoc colors.
- The page should feel like a real login screen for this blog, not just a bare form.

You should decide the exact UI/interaction details, but make sure the result is internally consistent with the repo context and reusable enough that another agent could apply the skill again for a different simple page later.

## Expected Behavior

The agent should produce a context-aware, reusable deliverable rather than a generic login page.

1. **Create `SKILL.md` in the workspace root**
   - It must be a structured reusable skill for scaffolding vanilla web UI pages.
   - It should include YAML frontmatter with at least `name` and `description`.
   - The markdown body should be meaningfully structured so another agent could reuse it, including:
     - purpose / when to use
     - inputs or parameters
     - workflow / steps
     - output expectations
     - at least one example
   - The skill should not just describe this one login page; it should generalize to similar small page-scaffolding tasks.

2. **Create `login/index.html`**
   - Must be a valid login page with:
     - username or email field
     - password field
     - submit button
     - a visible place for validation/error messaging
     - a visible place for lockout/countdown status
     - references to the local CSS and JS files
     - inclusion of the shared theme token file from the workspace root (for example via `<link href="../theme-variables.css">`)

3. **Create `login/style.css`**
   - Must provide real styling, not a placeholder.
   - Must use the existing token system from `theme-variables.css`.
   - Full credit requires substantial use of CSS custom properties (for colors, spacing, typography, borders, or shadows) via `var(--...)`.
   - To make token usage meaningful, the CSS should avoid relying on raw hex/rgb/hsl color literals for the core UI styling.
   - The page should look coherent with the blog context.

4. **Create `login/script.js`**
   - Must implement actual login-form interaction logic.
   - Validation logic must align with the auth settings in `blog-config.json`, specifically:
     - minimum password length
     - special-character requirement
     - max login attempts
     - lockout duration
   - Full credit requires using the config dynamically from `blog-config.json` at runtime or embedding/parsing the actual config data from that file’s values in a clearly traceable way; generic arbitrary defaults are not sufficient.
   - Must implement:
     - empty field detection
     - password visibility toggle with real type switching between `"password"` and `"text"`
     - failed-attempt tracking
     - lockout state with visible countdown
   - The countdown should visibly update over time rather than just showing a static message.

5. **Cross-file consistency**
   - The deliverable should fit the DevNotes repo context described by the existing files.
   - A strong solution will clearly reflect the workspace assets:
     - auth policy from `blog-config.json`
     - theme tokens from `theme-variables.css`
     - project framing from `README.md`
   - The task does **not** require a working backend or real authentication against `users.csv`; that file is contextual only.

### Intended traps / edge cases / ground truth

This task is intentionally stricter than “make a login page”:

- A generic login page that ignores workspace files is **not** correct.
- Hardcoding a length check like `password.length >= 8` without any attempt to align the broader auth policy is only partial credit.
- Mentioning lockout in text without implementing countdown updates is only partial credit.
- Referencing theme variables in one or two places while still styling the page mainly with raw colors is only partial credit.
- A fake password toggle that only mentions “show/hide” but does not switch the input `type` between `"password"` and `"text"` is not sufficient.
- `SKILL.md` must be a reusable skill, not a thin project note or a copy of the prompt.

Ground truth from the provided assets:
- `blog-config.json` auth values are:
  - `passwordMinLength = 8`
  - `requireSpecialChar = true`
  - `maxLoginAttempts = 5`
  - `lockoutDuration = 900` seconds
  - `sessionTimeout = 3600` seconds
- `theme-variables.css` defines the token system that should be used by the login page.
- The login page belongs in `/login` as described in the repo README.

## Grading Criteria

### Automated scoring dimensions

- [ ] `SKILL.md` is present and structurally reusable, with frontmatter plus sections for purpose, parameters/inputs, steps/workflow, outputs, and examples
- [ ] `login/` exists with all required files
- [ ] `index.html` includes a complete login form, theme token file reference, local asset references, and dedicated status areas
- [ ] `style.css` substantially uses shared CSS variables and avoids raw color literals for primary UI styling
- [ ] `script.js` implements real validation, real password toggle logic, failed-attempt tracking, and lockout countdown behavior
- [ ] `script.js` aligns with `blog-config.json` auth policy, including 8-char minimum, special-character rule, 5-attempt lockout, and 900-second lockout duration
- [ ] Cross-file integration is coherent enough that the page looks intentionally built for this repo, not a generic snippet

### LLM-evaluated dimensions

- [ ] `SKILL.md` is genuinely reusable by another agent
- [ ] The implementation shows sound decision-making around edge cases and tradeoffs
- [ ] The login page feels context-aware and cohesive rather than templated

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    import json
    import re
    from pathlib import Path

    ws = Path(workspace_path)

    scores = {
        "skill_md_structured_reusable": 0.0,
        "login_directory_and_files": 0.0,
        "index_html_complete": 0.0,
        "style_css_token_usage": 0.0,
        "script_js_interaction_logic": 0.0,
        "script_js_config_alignment": 0.0,
        "cross_file_context_integration": 0.0,
    }

    def read_text(path: Path) -> str:
        try:
            return path.read_text(encoding="utf-8", errors="replace")
        except Exception:
            return ""

    def normalize(s: str) -> str:
        return s.lower()

    def find_skill_file() -> Path | None:
        candidates = [ws / "SKILL.md"] + list(ws.glob("skills/*/SKILL.md")) + list(ws.glob("*/SKILL.md"))
        for p in candidates:
            if p.is_file():
                return p
        return None

    skill_path = find_skill_file()
    if skill_path:
        content = read_text(skill_path)
        lc = normalize(content)
        has_frontmatter = content.strip().startswith("---")
        has_name = bool(re.search(r'(?im)^\s*name\s*:\s*.+$', content))
        has_description = bool(re.search(r'(?im)^\s*description\s*:\s*.+$', content))

        section_hits = 0
        if re.search(r'(?im)^#{1,6}\s*(purpose|when to use|use cases?)\b', content):
            section_hits += 1
        if re.search(r'(?im)^#{1,6}\s*(inputs?|parameters?)\b', content):
            section_hits += 1
        if re.search(r'(?im)^#{1,6}\s*(steps?|workflow|procedure|process)\b', content):
            section_hits += 1
        if re.search(r'(?im)^#{1,6}\s*(outputs?|deliverables?)\b', content):
            section_hits += 1
        if re.search(r'(?im)^#{1,6}\s*(examples?)\b', content):
            section_hits += 1

        body_len = len(re.sub(r'(?s)^---.*?---', '', content).strip())
        mentions_reuse = any(x in lc for x in ["reusable", "reuse", "parameter", "inputs", "example", "output"])

        if has_frontmatter and has_name and has_description and section_hits >= 4 and body_len >= 400 and mentions_reuse:
            scores["skill_md_structured_reusable"] = 1.0
        elif has_frontmatter and has_name and has_description and section_hits >= 3 and body_len >= 250:
            scores["skill_md_structured_reusable"] = 0.75
        elif has_frontmatter and (has_name or has_description) and section_hits >= 2 and body_len >= 150:
            scores["skill_md_structured_reusable"] = 0.5
        elif body_len >= 100:
            scores["skill_md_structured_reusable"] = 0.25

    login_dir = ws / "login"
    index_path = login_dir / "index.html"
    css_path = login_dir / "style.css"
    js_path = login_dir / "script.js"

    file_count = sum(int(p.is_file()) for p in [index_path, css_path, js_path])
    if login_dir.is_dir() and file_count == 3:
        scores["login_directory_and_files"] = 1.0
    elif login_dir.is_dir() and file_count >= 2:
        scores["login_directory_and_files"] = 0.5
    elif login_dir.is_dir() or file_count >= 1:
        scores["login_directory_and_files"] = 0.25

    html = normalize(read_text(index_path)) if index_path.is_file() else ""
    css = read_text(css_path) if css_path.is_file() else ""
    js = read_text(js_path) if js_path.is_file() else ""

    config_path = ws / "blog-config.json"
    config = {}
    auth = {}
    if config_path.is_file():
        try:
            config = json.loads(read_text(config_path))
            auth = config.get("auth", {}) if isinstance(config, dict) else {}
        except Exception:
            auth = {}

    min_len = auth.get("passwordMinLength", 8)
    require_special = auth.get("requireSpecialChar", True)
    max_attempts = auth.get("maxLoginAttempts", 5)
    lockout_duration = auth.get("lockoutDuration", 900)
    session_timeout = auth.get("sessionTimeout", 3600)

    if html:
        has_form = "<form" in html
        has_user_field = (
            'type="text"' in html or "type='text'" in html or
            'type="email"' in html or "type='email'" in html or
            'name="username"' in html or "name='username'" in html or
            'name="email"' in html or "name='email'" in html
        )
        has_password_field = 'type="password"' in html or "type='password'" in html
        has_submit = "<button" in html or 'type="submit"' in html or "type='submit'" in html
        refs_css = "style.css" in html
        refs_js = "script.js" in html
        refs_theme = "../theme-variables.css" in html or "theme-variables.css" in html
        has_message_area = any(x in html for x in ["error-message", "status-message", "form-message", "validation-message", "aria-live"])
        has_lockout_area = any(x in html for x in ["lockout", "countdown", "attempts-remaining"])

        count = sum([
            has_form, has_user_field, has_password_field, has_submit,
            refs_css, refs_js, refs_theme, has_message_area, has_lockout_area
        ])
        if count >= 8:
            scores["index_html_complete"] = 1.0
        elif count >= 6:
            scores["index_html_complete"] = 0.75
        elif count >= 4:
            scores["index_html_complete"] = 0.5
        elif count >= 2:
            scores["index_html_complete"] = 0.25

    if css:
        css_lc = normalize(css)
        var_refs = re.findall(r'var\(--[\w-]+\)', css_lc)
        unique_var_refs = set(var_refs)
        raw_color_literals = re.findall(r'(?i)(#[0-9a-f]{3,8}\b|rgba?\([^)]+\)|hsla?\([^)]+\))', css)
        # Allow a small number of raw literals for exceptional cases, but require token-heavy styling.
        has_selector_count = len(re.findall(r'(^|\n)\s*[^@\n{}][^{}]*\{', css)) >= 5
        has_theme_import = '@import' in css_lc and 'theme-variables.css' in css_lc
        token_heavy = len(unique_var_refs) >= 8
        low_raw_color_count = len(raw_color_literals) <= 2

        if has_selector_count and token_heavy and low_raw_color_count:
            scores["style_css_token_usage"] = 1.0
        elif has_selector_count and len(unique_var_refs) >= 5 and len(raw_color_literals) <= 4:
            scores["style_css_token_usage"] = 0.75
        elif has_selector_count and len(unique_var_refs) >= 2:
            scores["style_css_token_usage"] = 0.5
        elif has_selector_count or has_theme_import:
            scores["style_css_token_usage"] = 0.25

    if js:
        js_lc = normalize(js)
        has_submit_handler = bool(re.search(r'(addEventListener\s*\(\s*[\'"]submit[\'"]|onsubmit\s*=)', js, re.IGNORECASE))
        has_empty_checks = bool(re.search(r'(trim\(\)\s*===?\s*[\'"]\s*[\'"]|!\s*[a-zA-Z_$][\w$]*\s*\.trim\(\)|empty|required)', js, re.IGNORECASE))
        has_dom_access = bool(re.search(r'(getElementById|querySelector|getElementsBy|document\.)', js))
        has_attempt_tracking = bool(re.search(r'(attempts?|failedAttempts|loginAttempts)', js, re.IGNORECASE))
        has_countdown_logic = bool(re.search(r'(setInterval|setTimeout)', js)) and bool(re.search(r'(countdown|remaining|seconds|timeleft|timeLeft|lockout)', js, re.IGNORECASE))
        has_lockout_logic = bool(re.search(r'(lockout|disabled\s*=|isLocked|lockedUntil)', js, re.IGNORECASE))

        toggle_has_both_types = '"password"' in js or "'password'" in js
        toggle_has_text = '"text"' in js or "'text'" in js
        toggle_has_type_switch = bool(re.search(r'\.type\s*=', js)) or bool(re.search(r'setattribute\s*\(\s*[\'"]type[\'"]', js_lc))
        toggle_has_trigger = bool(re.search(r'(addEventListener\s*\(\s*[\'"]click[\'"]|onclick\s*=)', js, re.IGNORECASE))
        has_password_toggle = toggle_has_both_types and toggle_has_text and toggle_has_type_switch and toggle_has_trigger

        count = sum([
            has_submit_handler,
            has_empty_checks,
            has_dom_access,
            has_attempt_tracking,
            has_countdown_logic,
            has_lockout_logic,
            has_password_toggle,
        ])
        if count >= 6:
            scores["script_js_interaction_logic"] = 1.0
        elif count >= 5:
            scores["script_js_interaction_logic"] = 0.75
        elif count >= 3:
            scores["script_js_interaction_logic"] = 0.5
        elif count >= 1:
            scores["script_js_interaction_logic"] = 0.25

        # Config alignment: require evidence of the actual project auth policy.
        reads_config_file = "blog-config.json" in js_lc and (
            "fetch(" in js_lc or "xmlhttprequest" in js_lc or "passwordminlength" in js_lc or "maxloginattempts" in js_lc
        )

        min_len_pattern = re.compile(rf'(?<!\d){re.escape(str(min_len))}(?!\d)')
        lockout_pattern = re.compile(rf'(?<!\d){re.escape(str(lockout_duration))}(?!\d)')
        attempts_pattern = re.compile(rf'(?<!\d){re.escape(str(max_attempts))}(?!\d)')
        session_pattern = re.compile(rf'(?<!\d){re.escape(str(session_timeout))}(?!\d)')

        mentions_min_len_key = "passwordminlength" in js_lc
        enforces_length = (
            mentions_min_len_key or
            bool(min_len_pattern.search(js_lc)) or
            bool(re.search(r'length\s*<\s*8|length\s*>=\s*8', js_lc))
        )

        special_char_logic = (
            "requirespecialchar" in js_lc or
            bool(re.search(r'[\\]/[^/\n]*[\^\$\*\+\?\(\)\[\]\{\}\|\\][^/\n]*/', js)) or
            bool(re.search(r'[^a-z0-9\s]', js_lc)) or
            "specialchars" in js_lc or
            "special character" in js_lc
        )

        enforces_attempts = "maxloginattempts" in js_lc or bool(attempts_pattern.search(js_lc))
        enforces_lockout = "lockoutduration" in js_lc or bool(lockout_pattern.search(js_lc))
        mentions_session = "sessiontimeout" in js_lc or bool(session_pattern.search(js_lc))

        config_hits = sum([
            reads_config_file,
            enforces_length,
            bool(require_special and special_char_logic) or (not require_special),
            enforces_attempts,
            enforces_lockout,
            mentions_session,
        ])

        if reads_config_file and config_hits >= 5:
            scores["script_js_config_alignment"] = 1.0
        elif config_hits >= 4:
            scores["script_js_config_alignment"] = 0.75
        elif config_hits >= 3:
            scores["script_js_config_alignment"] = 0.5
        elif config_hits >= 1:
            scores["script_js_config_alignment"] = 0.25

    context_hits = 0
    if html and ("devnotes" in html or "blog" in html):
        context_hits += 1
    if html and ("../theme-variables.css" in html or "theme-variables.css" in html):
        context_hits += 1
    if css and len(set(re.findall(r'var\(--[\w-]+\)', normalize(css)))) >= 5:
        context_hits += 1
    if js and ("blog-config.json" in normalize(js) or "passwordminlength" in normalize(js) or "maxloginattempts" in normalize(js)):
        context_hits += 1
    if js and ("lockout" in normalize(js) and ("countdown" in normalize(js) or "remaining" in normalize(js))):
        context_hits += 1

    if context_hits >= 5:
        scores["cross_file_context_integration"] = 1.0
    elif context_hits >= 4:
        scores["cross_file_context_integration"] = 0.75
    elif context_hits >= 3:
        scores["cross_file_context_integration"] = 0.5
    elif context_hits >= 1:
        scores["cross_file_context_integration"] = 0.25

    return scores
```

## LLM Judge Rubric

Use this rubric to evaluate the overall quality of the submission, especially areas automated checks cannot fully capture. Score each dimension independently at 1.0 / 0.75 / 0.5 / 0.25 / 0.0.

### 1. SKILL.md Reusability and Structure
- **1.0**: `SKILL.md` is clearly reusable by another agent, with strong frontmatter and well-organized sections for purpose, inputs/parameters, workflow, outputs, constraints, and examples. It generalizes beyond this one login page and gives actionable guidance rather than vague prose.
- **0.75**: Mostly reusable and structured, but one important element is underdeveloped (for example examples are thin, parameters are incomplete, or workflow is not detailed enough).
- **0.5**: Has some structure and some reusable content, but reads partly like project notes for this specific task rather than a transferable skill.
- **0.25**: Minimal markdown with weak structure; another agent would struggle to use it reliably.
- **0.0**: Missing or effectively unusable.

### 2. Context Awareness and Asset Use
- **1.0**: The solution clearly incorporates repo context: auth behavior matches `blog-config.json`, styling reflects `theme-variables.css`, and the page fits the DevNotes blog framing.
- **0.75**: Uses most of the relevant context correctly, but one area is superficial or partially mismatched.
- **0.5**: Some evidence of reading the workspace, but large parts still feel generic or partially inconsistent with the assets.
- **0.25**: Barely uses the provided assets in a meaningful way.
- **0.0**: Generic solution that ignores workspace context.

### 3. Interaction Logic Quality
- **1.0**: Validation, password toggle, failed-attempt tracking, and lockout countdown are all implemented coherently, with visible user feedback and no obvious logical holes.
- **0.75**: Core logic works, but one interaction is rough or partially incomplete (for example countdown UX is weak, or lockout resets are unclear).
- **0.5**: Several required interactions exist, but the implementation is shallow, inconsistent, or likely brittle.
- **0.25**: Only basic validation exists; advanced interactions are mostly nominal.
- **0.0**: Little to no meaningful interaction logic.

### 4. Styling System Discipline
- **1.0**: Styling is cohesive and intentionally based on the token system, with strong variable usage and little/no dependence on ad hoc raw colors for the main UI.
- **0.75**: Mostly token-based, but some parts still rely on arbitrary styling decisions that weaken system consistency.
- **0.5**: Uses a few variables but is not meaningfully driven by the shared theme system.
- **0.25**: Styling exists but is mostly generic and disconnected from the design tokens.
- **0.0**: No meaningful styling.

### 5. Judgment on Tradeoffs and Edge Cases
- **1.0**: The submission handles edge cases thoughtfully: empty fields, repeated failures, lockout state persistence within the page session, countdown updates, and clear messaging. Choices are sensible and internally consistent.
- **0.75**: Good overall judgment, but one edge case or UX detail is under-handled.
- **0.5**: Some edge cases are considered, but important gaps remain or decisions feel arbitrary.
- **0.25**: Little evidence of careful reasoning about edge cases.
- **0.0**: No meaningful handling of edge cases.

### Overall guidance
- Reserve top scores for submissions that are clearly context-aware, genuinely reusable, and careful about implementation details.
- Generic “HTML/CSS/JS login page” outputs should not score highly even if they are superficially complete.
- If the solution appears to hardcode generic behavior while only name-dropping the config/theme files, score Context Awareness and Tradeoffs conservatively.
