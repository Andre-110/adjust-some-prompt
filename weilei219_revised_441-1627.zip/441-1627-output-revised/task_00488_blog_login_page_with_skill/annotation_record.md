# 修改记录

| 序号 | 修改项 | 修改原因 |
|------|--------|----------|
| 1 | 将任务难度从 easy 提升为 medium，并将 grading_type 改为 hybrid，加入 LLM Judge Rubric | 对应关键问题 2、4；原题难度不足且完全依赖自动检查，无法有效区分强弱模型，也无法评估 SKILL.md 质量 |
| 2 | 重写 Prompt，去掉“if it helps”式可选提示，改为要求实现与仓库上下文一致的登录页、动态规则对齐、锁定倒计时与主题 token 使用 | 对应关键问题 2、5；原 prompt 将上下文资产弱化为可选参考，且任务过于手把手、难度偏低 |
| 3 | 重写 Expected Behavior，明确 lockout countdown、动态配置对齐、主题 token 约束、SKILL.md 结构化要求，并补充 traps / edge cases / ground truth | 对应关键问题 1、2、4；需要把真实能力点和陷阱显式纳入题目与评测目标 |
| 4 | 重写 Grading Criteria，增加对 config 对齐、token 使用、交互复杂度、跨文件一致性和 SKILL.md 可复用性的评分维度 | 对应关键问题 1、2、4；原评分项过于平均且无法区分关键能力 |
| 5 | 全面修复并强化 grade()：新增对 blog-config.json 密码规则、锁定策略、theme 变量使用的实际检查 | 对应关键问题 1；原自动评测没有验证模型是否真正使用 workspace 资产 |
| 6 | 修复 script.js 中 password toggle 的检查逻辑，要求真实存在 click 触发 + type 在 "password"/"text" 之间切换 | 对应关键问题 3；原正则把任何 password 相关代码误判为已实现 toggle |
| 7 | 强化 SKILL.md 自动检查，要求结构化 section、较充实正文和可复用特征，不再仅以字符数和 frontmatter 为主 | 对应关键问题 4；原 SKILL.md 验收过于空洞，无法评估 skill_creation 能力 |
| 8 | 新增细化的 LLM Judge Rubric，为 1.0/0.75/0.5/0.25/0.0 各档提供可操作锚点，覆盖复用性、上下文理解、交互质量、样式系统纪律、边界处理 | 对应关键问题 4；原题完全缺少 rubric，软性质量无法判断 |
