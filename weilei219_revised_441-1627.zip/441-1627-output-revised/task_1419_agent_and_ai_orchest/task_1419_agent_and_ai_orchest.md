---
id: task_1419_agent_and_ai_orchest
name: Multi-Agent Orchestration System Design
category: Automation
grading_type: hybrid
difficulty: hard
timeout_seconds: 720
grading_weights:
  automated: 0.45
  llm_judge: 0.55
workspace_files:
- source: task_1419_agent_and_ai_orchest/research/frameworks_comparison.csv
  dest: research/frameworks_comparison.csv
- source: task_1419_agent_and_ai_orchest/research/architecture_patterns.json
  dest: research/architecture_patterns.json
- source: task_1419_agent_and_ai_orchest/research/benchmark_results.csv
  dest: research/benchmark_results.csv
- source: task_1419_agent_and_ai_orchest/config/current_infra.yaml
  dest: config/current_infra.yaml
- source: task_1419_agent_and_ai_orchest/config/team_requirements.yaml
  dest: config/team_requirements.yaml
- source: task_1419_agent_and_ai_orchest/logs/pilot_run_crewai.log
  dest: logs/pilot_run_crewai.log
- source: task_1419_agent_and_ai_orchest/logs/pilot_run_autogen.log
  dest: logs/pilot_run_autogen.log
- source: task_1419_agent_and_ai_orchest/research/cost_analysis.csv
  dest: research/cost_analysis.csv
- source: task_1419_agent_and_ai_orchest/research/failure_modes.json
  dest: research/failure_modes.json
- source: task_1419_agent_and_ai_orchest/docs/legacy_orchestrator_notes.md
  dest: docs/legacy_orchestrator_notes.md
- source: task_1419_agent_and_ai_orchest/docs/vendor_pitch_agentcloud.md
  dest: docs/vendor_pitch_agentcloud.md
- source: task_1419_agent_and_ai_orchest/research/token_usage_breakdown.json
  dest: research/token_usage_breakdown.json
- source: task_1419_agent_and_ai_orchest/config/model_capabilities.yaml
  dest: config/model_capabilities.yaml
- source: task_1419_agent_and_ai_orchest/docs/agent_teams_api_spec.yaml
  dest: docs/agent_teams_api_spec.yaml
source_query: 调研并设计一个"agent teams"多代理协作方案：让主agent可以将子任务分派给多个agent并汇总结果，说明总体架构、任务拆分与协调流程，以及可选的实现框架/落地思路。
source_line_number: 1419
subcategory: Agent and AI Orchestration
---
## Prompt

We need to lock our approach for an internal “agent teams” orchestration layer, and leadership wants a decision memo they can actually review.

Please read the materials in `research/`, `config/`, `logs/`, and `docs/`, then write `agent_teams_design.md` with a concrete recommendation for:
- the framework or framework combination we should adopt
- the orchestration pattern we should use
- how to structure agent teams for the four supported task types (`research`, `code_review`, `data_analysis`, `report_generation`)
- expected operating cost at our likely scale
- production failure handling and rollout considerations

A few constraints:
- some documents are clearly more current or trustworthy than others, but nobody has labeled them for you
- there are multiple budget numbers in the workspace and they are not interchangeable
- the recommendation has to fit our existing platform constraints, not an idealized greenfield stack
- if you include cost estimates, show enough numeric detail that another engineer could audit where the numbers came from

Write this as a technical design doc for engineering leadership. It should end with a clear recommendation, the tradeoffs you rejected, and any assumptions or unresolved risks that still matter.

## Expected Behavior

The agent must synthesize multiple workspace files into a design document that makes a defendable recommendation under conflicting evidence and operational constraints. A strong answer is not just “pick a popular framework”; it must resolve contradictions, choose which data sources to trust, and map the design onto the stated infra/SLA limits.

### Required judgment path and ground truth

#### 1) Resolve stale vs current sources correctly
`docs/legacy_orchestrator_notes.md` is intentionally stale and conflicts with newer structured data. The correct behavior is to treat it as historical context rather than as a recommendation source. Best-in-class answers will explicitly call out that it is outdated (or legacy/stale) and explain at least two contradictions, such as:
- it recommends BabyAGI, which is not among the current preferred candidates in `config/team_requirements.yaml`
- it claims AutoGen does **not** support hierarchical orchestration, contradicted by `research/frameworks_comparison.csv` (`supports_hierarchical: True`)
- it claims a practical limit of 3 agents, contradicted by current requirements of 3–10 agents and framework test data up to 12/15/20+ agents

Important nuance: mentioning BabyAGI is **not** automatically wrong. The highest-quality behavior is to mention it only in a rejection context tied to the stale notes. Simply omitting BabyAGI is weaker than explicitly identifying why the legacy recommendation should not drive the decision.

#### 2) Catch the token-unit trap instead of bypassing it
`research/token_usage_breakdown.json` contains a deliberate unit inconsistency:
- `researcher_agent` and `coder_agent` values are labeled as `"tokens"` but are actually k-tokens
- `summary_totals` also inherits this bad scale and is therefore not trustworthy as-is

That means correct cost analysis should **not** use the JSON summary totals at face value. A correct answer should either:
- explicitly identify the mismatch and normalize the per-agent values, ideally cross-checking against the pilot logs, or
- use the pilot logs directly for the most trustworthy per-run token totals

Ground truth from the logs:
- CrewAI pilot total = **35,437 tokens**, cost **$0.42**, time **62.3s**, retries **1**
- AutoGen pilot total = **56,090 tokens**, cost **$0.67**, time **48.2s**, retries **0**

Ground truth from the CrewAI log by role:
- orchestrator/main_orchestrator = **6,027**
- researcher_agent = **14,820**
- coder_agent = **8,240**
- reviewer_agent = **6,350**

Ground truth from the AutoGen log by role:
- orchestrator = **5,790**
- researcher = **20,320**
- coder = **21,450**
- reviewer = **8,530**

If a response uses the JSON `summary_totals` values directly (for example research total around 39.75 or similarly tiny scaled numbers) without acknowledging the unit problem, that is incorrect. Correct cost projections should land in a plausible monthly range consistent with `research/cost_analysis.csv` and the budget constraints, not based on corrupted token totals.

#### 3) Reject marketing material as decision authority
`docs/vendor_pitch_agentcloud.md` is a sales pitch, not an engineering source of truth. Correct handling is to either reject AgentCloud outright or evaluate it critically and still decline it due to mismatch with requirements and budget priorities. Strong answers should note at least one of:
- pricing starts at **$50,000/year**, which is a large share of total budget headroom and not aligned with the open-source/Python preference
- current environment already specifies Kubernetes + RabbitMQ + observability stack, so a proprietary “no-code” platform is a poor fit
- claims like “quantum-ready” / “Self-Healing Agent Fabric™” are not decision-grade evidence

Again, nuance matters: mentioning AgentCloud is fine if it is explicitly rejected with evidence.

#### 4) Make a recommendation that survives the real tradeoffs
There is no single perfect answer, but the recommendation must be plausible given the assets.

A strong recommendation will usually select **CrewAI, AutoGen, LangGraph, or a justified combination**. The best-supported tradeoff patterns are:

- **CrewAI**: better aligns with hierarchical task decomposition and lower token usage / lower cost in the pilot, but it exceeded the simple-task 45s SLA in the pilot and had a researcher timeout retry
- **AutoGen**: faster pilot completion and better research benchmark success rate, but materially higher token usage and evidence of conversation-flow inefficiency
- **LangGraph**: strongest structured performance profile in several benchmark rows (especially latency and data analysis), graph-based control model, but not the one exercised in the pilot logs

The document should not simply choose the single best row from one CSV. It should reconcile benchmarks, pilot behavior, and operational fit.

#### 5) Architecture choice must address both fit and failure modes
The architecture should usually be **hierarchical** or a **hybrid hierarchical + pipeline / graph** approach, because the system needs:
- a primary orchestrator
- 3–10 agents per team
- clear result aggregation
- support for sync and async execution
- graceful degradation and auditability

However, a strong answer must also acknowledge the downside of hierarchical coordination (single-point-of-failure / bottleneck) and explain mitigations. Referencing the pattern file without discussing the tradeoff is incomplete.

#### 6) Cost and infra reasoning must use the right constraints
There are multiple budget figures:
- `config/current_infra.yaml` → `monthly_budget_usd: 5000` under infrastructure constraints
- `config/team_requirements.yaml` → `monthly_llm_api_budget_usd: 5000`, `infrastructure_budget_usd: 2000`, `total_monthly_budget_usd: 7000`

These numbers are not identical in meaning. Strong answers distinguish them instead of collapsing them into one generic “$5k budget”.

Also required:
- account for Kubernetes deployment
- use RabbitMQ rather than inventing another primary message bus unless clearly justified
- respect `max_concurrent_requests: 50`
- include observability consistent with Prometheus/Grafana and audit logging requirements
- map task types to the SLA split:
  - simple tasks: **45s**, **95%** success target
  - complex tasks: **180s**, **85%** success target

#### 7) Concrete team design for all four task types
The design must specify team structures for:
- research
- code_review
- data_analysis
- report_generation

These should reflect the requirement ranges and not default every task to the same team shape. For example, `code_review` and `report_generation` are simpler 3–4 agent tasks, while `research` and `data_analysis` are more complex 4–6 / 4–5 agent tasks.

### What distinguishes stronger from weaker answers

- **Stronger**: explicitly identifies stale/legacy notes, token-unit mismatch, and vendor pitch quality; cites concrete metrics from logs/CSVs; distinguishes budget types; maps infra constraints to architecture; explains why one framework is recommended despite imperfect pilot/benchmark tradeoffs; gives auditable cost math.
- **Weaker but still partially correct**: reaches a plausible framework choice but does not explicitly explain contradictions or uses only a subset of the evidence.
- **Incorrect**: recommends BabyAGI or AgentCloud, claims AutoGen lacks hierarchical support, designs around max 3 agents only, uses corrupted token totals without noticing the unit issue, or ignores the stated infra/SLA constraints.

## Grading Criteria

- [ ] The document is saved to `agent_teams_design.md` and is written as a technical design doc with a clear final recommendation and rejected alternatives.
- [ ] The framework recommendation is grounded in specific data from `research/frameworks_comparison.csv`, `research/benchmark_results.csv`, and the pilot logs, with concrete metrics rather than generic claims.
- [ ] The document explicitly identifies `docs/legacy_orchestrator_notes.md` as stale/legacy/outdated evidence and explains why BabyAGI is rejected; merely omitting BabyAGI is not full credit.
- [ ] The document correctly states that AutoGen supports hierarchical orchestration and does not inherit the legacy “max 3 agents” limit, instead aligning with current 3–10 agent requirements.
- [ ] The document explicitly catches the token unit mismatch in `research/token_usage_breakdown.json` or clearly chooses to distrust that file’s totals and uses the pilot logs for token/cost grounding.
- [ ] The document includes at least two correct concrete numeric references from the pilot logs or benchmark data (e.g. 35,437 tokens, 56,090 tokens, 62.3s, 48.2s, 87% success rate, 86% success rate).
- [ ] The document explicitly rejects or critically dismisses AgentCloud as a primary recommendation, using evidence tied to cost, credibility, or stack fit.
- [ ] The design includes concrete team compositions for each of the four task types with roles/responsibilities and different team shapes where appropriate.
- [ ] The architecture recommendation references the patterns in `research/architecture_patterns.json`, explains why the chosen pattern fits, and also names the main tradeoff/failure risk of that pattern plus mitigations.
- [ ] The cost section includes auditable monthly estimates that stay within the relevant budget constraints and distinguishes at least the LLM API budget from total monthly budget.
- [ ] The design explicitly accounts for existing platform constraints from `config/current_infra.yaml` and `config/team_requirements.yaml`, including Kubernetes, RabbitMQ, 50 max concurrent requests, monitoring, audit logging, idempotency, sync/async execution, and SLA targets.
- [ ] The failure/risk section maps at least three failure modes from `research/failure_modes.json` to specific mitigations in the proposed architecture.

## Automated Checks

```python
import os
import re
import csv
import json
from pathlib import Path

def _read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="replace")

def _extract_money_values(text: str):
    values = set()
    for m in re.finditer(r'\$?\s*([0-9]{1,3}(?:,[0-9]{3})+|[0-9]+)(?:\.[0-9]+)?', text):
        raw = m.group(1).replace(",", "")
        try:
            values.add(int(raw))
        except ValueError:
            pass
    return values

def _window_has_negation(text_lower: str, term: str, neg_terms, window=160):
    found = False
    for m in re.finditer(re.escape(term.lower()), text_lower):
        found = True
        start = max(0, m.start() - window)
        end = min(len(text_lower), m.end() + window)
        window_text = text_lower[start:end]
        if any(neg in window_text for neg in neg_terms):
            return True
    return not found  # if term absent, this helper should not award explicit-trap credit

def grade(transcript: list, workspace_path: str) -> dict:
    output_file = Path(workspace_path) / "agent_teams_design.md"
    scores = {
        "file_exists": 0.0,
        "uses_concrete_metrics": 0.0,
        "legacy_notes_explicitly_rejected": 0.0,
        "babyagi_rejection_context": 0.0,
        "autogen_hierarchical_correct": 0.0,
        "token_trap_detected": 0.0,
        "agentcloud_rejected_with_context": 0.0,
        "cost_numbers_plausible": 0.0,
        "task_type_coverage": 0.0,
        "infrastructure_constraints_coverage": 0.0,
        "failure_modes_mapped": 0.0,
        "clear_recommendation_and_rejected_options": 0.0,
    }

    if not output_file.is_file():
        return scores

    scores["file_exists"] = 1.0
    content = _read_text(output_file)
    content_lower = content.lower()

    # Load benchmark values so checks are tied to actual assets
    benchmark_path = Path(workspace_path) / "research" / "benchmark_results.csv"
    benchmark_values = set()
    if benchmark_path.is_file():
        with benchmark_path.open("r", encoding="utf-8", errors="replace", newline="") as f:
            reader = csv.DictReader(f)
            for row in reader:
                for key in ["success_rate_pct", "avg_completion_time_sec", "avg_token_usage", "cost_per_task_usd"]:
                    val = str(row.get(key, "")).strip()
                    if val:
                        benchmark_values.add(val)

    known_metric_strings = {
        "35,437", "35437", "56,090", "56090",
        "62.3", "48.2", "0.42", "0.67",
        "85", "87", "86", "78", "80", "75", "92", "91",
        "44.4", "45.3", "30.8", "33.8", "22465", "28402", "14828", "19021"
    }.union(benchmark_values)

    metric_hits = 0
    for val in known_metric_strings:
        if val and val in content:
            metric_hits += 1
    if metric_hits >= 2:
        scores["uses_concrete_metrics"] = 1.0

    if any(term in content_lower for term in ["legacy", "outdated", "stale"]) and "babyagi" in content_lower:
        scores["legacy_notes_explicitly_rejected"] = 1.0

    babyagi_neg_terms = [
        "not recommend", "do not recommend", "reject", "rejected", "outdated",
        "stale", "legacy", "not suitable", "should not", "not a fit"
    ]
    if _window_has_negation(content_lower, "babyagi", babyagi_neg_terms):
        scores["babyagi_rejection_context"] = 1.0

    if "autogen" in content_lower and "hierarchical" in content_lower:
        # Do not award if it explicitly repeats the false claim
        bad_patterns = [
            r'autogen.{0,80}does\s+not\s+support\s+hierarchical',
            r'autogen.{0,80}not\s+support.{0,20}hierarchical'
        ]
        if not any(re.search(p, content_lower, re.DOTALL) for p in bad_patterns):
            scores["autogen_hierarchical_correct"] = 1.0

    token_terms = ["unit mismatch", "k-token", "k tokens", "thousand", "normalized", "normalize", "pilot log", "summary_totals"]
    if any(term in content_lower for term in token_terms) and (
        "35,437" in content or "35437" in content or "56,090" in content or "56090" in content
    ):
        scores["token_trap_detected"] = 1.0

    agentcloud_neg_terms = [
        "not recommend", "do not recommend", "reject", "rejected", "sales pitch",
        "marketing", "proprietary", "too expensive", "not a fit"
    ]
    if _window_has_negation(content_lower, "agentcloud", agentcloud_neg_terms):
        scores["agentcloud_rejected_with_context"] = 1.0

    money_values = _extract_money_values(content)
    if any(360 <= v <= 5000 for v in money_values):
        scores["cost_numbers_plausible"] = 1.0

    task_terms = ["research", "code_review", "data_analysis", "report_generation"]
    alt_task_terms = ["research", "code review", "data analysis", "report generation"]
    if all(term in content_lower for term in task_terms) or all(term in content_lower for term in alt_task_terms):
        scores["task_type_coverage"] = 1.0

    infra_terms = [
        "kubernetes", "rabbitmq", "50", "prometheus", "grafana",
        "audit", "idempot", "synchronous", "asynchronous"
    ]
    infra_hits = sum(1 for term in infra_terms if term in content_lower)
    if infra_hits >= 7:
        scores["infrastructure_constraints_coverage"] = 1.0

    failure_hits = 0
    for term in ["infinite_loop", "context_overflow", "hallucination_cascade", "deadlock", "resource_starvation", "inconsistent_output_format"]:
        if term in content_lower:
            failure_hits += 1
    # allow human-readable variants too
    for term in ["infinite loop", "context overflow", "hallucination cascade", "resource starvation", "output format"]:
        if term in content_lower:
            failure_hits += 1
    if failure_hits >= 3 and any(t in content_lower for t in ["mitigation", "retry", "fallback", "rate limit", "schema", "cycle detection", "timeout"]):
        scores["failure_modes_mapped"] = 1.0

    rec_terms = ["recommend", "recommended", "final recommendation"]
    reject_terms = ["rejected", "not chosen", "not recommend", "alternatives considered", "tradeoffs"]
    if any(t in content_lower for t in rec_terms) and any(t in content_lower for t in reject_terms):
        scores["clear_recommendation_and_rejected_options"] = 1.0

    return scores
```

## LLM Judge Rubric

### Criterion 1: Contradiction Resolution and Trap Handling (Weight: 35%)
**Score 1.0**: The document explicitly identifies all three trap sources and resolves them correctly. It treats `legacy_orchestrator_notes.md` as stale/legacy evidence, explains why BabyAGI is rejected, explicitly notes that AutoGen does support hierarchical orchestration, and rejects the obsolete “3 agents max” conclusion. It identifies the token unit problem in `token_usage_breakdown.json` (including that `summary_totals` is also unsafe) and cross-checks with the pilot logs or otherwise shows a correct normalization path. It treats AgentCloud as vendor marketing rather than decision-grade evidence and rejects it with budget/fit reasoning. Reasoning is transparent and tied to actual files and contradictions.
**Score 0.75**: Correctly resolves all major traps in outcome, but one trap is only partially explained. Example: correctly rejects BabyAGI and AgentCloud and uses the right token totals, but does not explicitly say `summary_totals` is corrupted; or states the legacy notes are stale but does not articulate more than one contradiction. Still clearly grounded in the workspace.
**Score 0.5**: Reaches mostly correct conclusions but at least one trap is handled only implicitly or by accident. Example: chooses CrewAI/LangGraph and avoids AgentCloud, but never explicitly identifies the legacy notes as stale; or uses correct pilot-log totals without clearly explaining the JSON unit mismatch. This level is for “right answer, weak contradiction handling,” not for trap failures.
**Score 0.25**: Avoids one obvious bad recommendation by common sense but shows little evidence of actual contradiction resolution. Example: does not recommend BabyAGI but also appears not to have read the legacy notes; uses vague cost reasoning with no sign of catching the token trap; mentions AgentCloud only superficially. Trap avoidance seems incidental rather than reasoned.
**Score 0.0**: Falls for one or more core traps in a material way: recommends BabyAGI or AgentCloud, repeats the false claim that AutoGen lacks hierarchical support, enforces a 3-agent max based on stale notes, or uses corrupted token data without noticing the unit issue and produces clearly unsound cost conclusions.

### Criterion 2: Evidence-Based Analysis and Quantitative Grounding (Weight: 30%)
**Score 1.0**: The recommendation is built from a multi-source quantitative argument. It cites concrete benchmark and pilot metrics, distinguishes empirical pilot behavior from broader benchmark trends, and uses auditable cost logic. It includes specific numbers such as success rates, latency, token usage, per-task cost, or monthly cost ranges, and those numbers align with the provided assets. It also distinguishes among the different budget constraints instead of flattening them into a single number.
**Score 0.75**: Uses several correct concrete data points and the reasoning is mostly evidence-based, but some parts of the argument are still qualitative or underspecified. Cost logic is directionally correct but not fully auditable, or benchmark vs pilot evidence is not clearly separated.
**Score 0.5**: Includes some real numbers from the workspace, but the argument is incomplete or selectively grounded. The design may quote one CSV and one log yet still lean heavily on generic framework knowledge. Cost/math may be plausible but not clearly derived.
**Score 0.25**: Mostly generic architecture advice with only light data seasoning. References to the workspace are sparse, unspecific, or possibly cherry-picked. Numerical claims are too vague to verify or do not materially support the recommendation.
**Score 0.0**: No meaningful evidence from the workspace, invented numbers, or quantitatively incorrect reasoning that conflicts with the assets.

### Criterion 3: Infrastructure and Operational Constraint Alignment (Weight: 20%)
**Score 1.0**: The design clearly maps onto the existing environment and operational rules. It explicitly accounts for Kubernetes deployment, RabbitMQ as the messaging backbone, max 50 concurrent requests, Prometheus/Grafana monitoring, audit logging, idempotency/deduplication, sync and async execution, and the SLA split (45s/95% for simple tasks, 180s/85% for complex tasks). These are not merely listed; they are connected to concrete design choices such as queueing, concurrency control, retry strategy, routing, or observability.
**Score 0.75**: Covers most of the above constraints correctly, but one or two are not operationalized in detail. For example, it mentions RabbitMQ, concurrency, and audit logging, but does not clearly map SLAs to execution modes or leaves idempotency somewhat abstract.
**Score 0.5**: Acknowledges some platform constraints but misses several important ones or treats them as generic implementation notes. The architecture could probably be adapted to the environment, but the document does not convincingly show that work.
**Score 0.25**: Only superficial operational alignment. The document reads like a greenfield design and largely ignores the stated environment, concurrency limit, or audit/monitoring requirements.
**Score 0.0**: The proposed system materially conflicts with the provided constraints or ignores them entirely.

### Criterion 4: Design Quality, Tradeoff Reasoning, and Completeness (Weight: 15%)
**Score 1.0**: The document is coherent, decision-oriented, and complete. It includes team design for all four task types, architecture and coordination flow, failure-mode mitigation tied to the chosen pattern, a final recommendation, rejected alternatives, and unresolved risks/assumptions. Tradeoffs are explicit and defensible rather than hidden.
**Score 0.75**: Well-structured and useful, with only minor gaps such as underdeveloped rollout notes or shallow alternative analysis. The main recommendation is still clear and actionable.
**Score 0.5**: Covers the major sections but feels more like assembled notes than a decisive design doc. Some sections are thin, repetitive, or disconnected from the recommendation.
**Score 0.25**: Significant gaps in coverage or structure. The reader can infer a recommendation, but the document is not strong enough for leadership review without substantial rework.
**Score 0.0**: Incomplete, incoherent, or missing key design components.