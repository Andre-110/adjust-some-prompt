# API Security Guidelines

**Document Owner:** Security Engineering Team  
**Version:** 3.1  
**Last Updated:** 2024-01-05  
**Classification:** Internal  

---

## 1. Introduction

This document outlines the security guidelines and best practices for all API development on the DigitalTwin platform. All engineering teams must adhere to these guidelines when designing, implementing, and deploying API endpoints.

---

## 2. Authentication

### 2.1 General Requirements
- All API endpoints MUST require authentication unless explicitly approved as public by the security team.
- Use OAuth 2.0 / OpenID Connect for user-facing APIs.
- Use service tokens (JWT) for service-to-service communication.
- Never embed credentials in URLs or query parameters.

### 2.2 Token Management
- Access tokens should have a short expiry (recommended: 15 minutes).
- Refresh tokens should be single-use and rotated on each use.
- Implement token revocation for incident response scenarios.
- Store tokens securely; never log token values.

### 2.3 API Keys
- API keys should be treated as secrets and stored in a vault.
- Rotate API keys at least every 90 days.
- Scope API keys to the minimum required permissions.
- Never commit API keys to source control.

---

## 3. Authorization

### 3.1 Role-Based Access Control
- Implement RBAC for all API endpoints.
- Follow the principle of least privilege.
- Validate permissions on every request at the API layer.
- Do not rely solely on client-side permission checks.

### 3.2 Resource-Level Authorization
- Verify that the authenticated user has access to the specific resource being requested.
- Implement object-level authorization checks (prevent IDOR vulnerabilities).
- Use parameterized resource identifiers; never trust client-supplied resource IDs without validation.

---

## 4. Input Validation

### 4.1 General Rules
- Validate all input on the server side.
- Use allowlists rather than denylists for input validation.
- Validate data types, lengths, ranges, and formats.
- Reject unexpected fields in request bodies.

### 4.2 SQL Injection Prevention
- Use parameterized queries or prepared statements exclusively.
- Never concatenate user input into SQL queries.
- Use an ORM where possible.

### 4.3 XSS Prevention
- Encode all output that includes user-supplied data.
- Use Content-Security-Policy headers.
- Validate and sanitize HTML input if rich text is required.

---

## 5. Rate Limiting

### 5.1 Requirements
- All API endpoints MUST implement rate limiting.
- Default rate limits: 120 requests/minute for authenticated users, 30 requests/minute for unauthenticated endpoints.
- Implement graduated rate limiting for sensitive endpoints (login, password reset, data export).
- Return `429 Too Many Requests` with `Retry-After` header when limits are exceeded.

### 5.2 Bulk Operations
- Bulk data operations must have separate, stricter rate limits.
- Implement pagination with maximum page sizes.
- Require explicit authorization for bulk export operations.
- Log all bulk operations for audit purposes.

---

## 6. Transport Security

### 6.1 TLS Requirements
- All API communication MUST use TLS 1.2 or higher.
- Disable TLS 1.0 and TLS 1.1.
- Use strong cipher suites only (AES-256-GCM preferred).
- Implement HSTS with a minimum max-age of 1 year.

### 6.2 Certificate Management
- Use certificates from trusted CAs.
- Implement automated certificate rotation.
- Monitor certificate expiry and alert 30 days before expiration.

---

## 7. Error Handling

### 7.1 Error Responses
- Return generic error messages to clients.
- Never expose internal implementation details, stack traces, or database schema in error responses.
- Log detailed error information server-side for debugging.
- Use standard HTTP status codes consistently.

### 7.2 Error Response Format
```json
{
  "error": {
    "code": "VALIDATION_ERROR",
    "message": "The request could not be processed.",
    "request_id": "req-abc123"
  }
}
```

---

## 8. Logging and Monitoring

### 8.1 What to Log
- All authentication events (success and failure)
- Authorization failures
- Input validation failures
- Rate limit violations
- All data access operations (especially PII)
- Administrative actions

### 8.2 What NOT to Log
- Passwords or credentials
- Full credit card numbers
- Authentication tokens
- Personal health information (log anonymized references only)

### 8.3 Log Format
Use structured JSON logging with the following fields:
- timestamp (ISO 8601)
- service_name
- request_id
- actor (user ID or service account)
- action
- resource
- result (success/failure)
- ip_address
- user_agent

---

## 9. CORS Configuration

### 9.1 Requirements
- Explicitly define allowed origins; never use wildcard (`*`) with credentials.
- Restrict allowed methods to those actually needed.
- Restrict allowed headers to those actually needed.
- Set appropriate `Access-Control-Max-Age` values.
- Review CORS configuration quarterly.

---

## 10. API Versioning

- Use URL path versioning (e.g., `/api/v1/resource`).
- Maintain backward compatibility within a major version.
- Deprecate old versions with at least 6 months notice.
- Document breaking changes clearly.

---

## 11. Data Protection

### 11.1 PII Handling
- Minimize PII in API responses; return only what the client needs.
- Implement field-level encryption for sensitive data.
- Support data subject access requests (DSAR) via API.
- Implement right-to-erasure endpoints.

### 11.2 Data Classification
- Classify all API response fields by sensitivity level.
- Apply appropriate access controls based on data classification.
- Encrypt sensitive fields in transit and at rest.

---

## 12. Security Headers

All API responses MUST include the following headers:

```
Strict-Transport-Security: max-age=31536000; includeSubDomains
Content-Security-Policy: default-src 'none'
X-Content-Type-Options: nosniff
X-Frame-Options: DENY
Referrer-Policy: strict-origin-when-cross-origin
Cache-Control: no-store
Permissions-Policy: geolocation=(), camera=(), microphone=()
```

---

## 13. Dependency Management

- Keep all dependencies up to date.
- Run automated vulnerability scanning on all dependencies (Snyk, Dependabot).
- Do not use dependencies with known critical vulnerabilities.
- Pin dependency versions in production.

---

## 14. Review and Compliance

- All new API endpoints must undergo security review before deployment.
- Conduct annual penetration testing of all API endpoints.
- Review this document quarterly and update as needed.
- Non-compliance with these guidelines must be reported to the security team.

---

*For questions or exceptions, contact security-engineering@digitaltwin.internal*
