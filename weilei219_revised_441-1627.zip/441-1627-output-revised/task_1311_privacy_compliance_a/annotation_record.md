# 修改记录

| 序号 | 修改项 | 修改原因 |
|------|--------|----------|
| 1 | 重写 Expected Behavior，补充 consent/collection mismatch，并澄清 china_pipl_notes.txt 仅可作为次要风险补充 | 对应问题 3、问题 5；修复评分口径与期望行为不一致、PIPL 处理口径矛盾 |
| 2 | 强化 Grading Criteria，加入 dev-0147 五文件攻击链、F-006 回归冲突、同意撤回不匹配等能力点 | 对应问题 4、问题 5；提高跨文件推理要求并补齐关键能力点 |
| 3 | 全面重写 Automated Checks，将原有标题/关键词存在性检查改为内容质量检查 | 对应问题 1；修复大量“只写标题即可得分”的宽松检查 |
| 4 | 修复 outdated encryption、MD5、HSM、backup retention 等 trap 检查逻辑，要求批判性语境和跨文件冲突识别 | 对应问题 1、问题 2、问题 6；避免只要提到词语或数字就得分 |
| 5 | 新增 `flags_consent_withdrawal_mismatch` 自动检查，并要求结合 consent 与 inventory/integration 语境判断 | 对应问题 5；补齐 Grading Criteria 与 Automated Checks 脱节 |
| 6 | 细化 LLM Judge Rubric，明确 Criterion 1 满分必须包含 dev-0147 五文件联动推理链 | 对应问题 4；增强强弱模型区分度 |
| 7 | 细化 Rubric 中 trap 与边界处理锚点，加入“不过度相信旧政策/不把不确定证据说成确定事实”的要求 | 对应问题 3、问题 4；提升评分稳定性和可操作性 |
| 8 | 轻度改写 Prompt，保留自然用户语气但更强调“确认性证据 vs 推断性风险 vs 文档冲突”的判断要求 | 根据总体建议优化难度与区分度，避免模型仅按模板罗列内容即可高分 |
