---
id: task_922_document_management
name: Assemble Chapter 19 Blueprint from Story Bible Sources
category: Knowledge Management
grading_type: combined
grading_weights:
  automated: 0.8
  llm_judge: 0.2
difficulty: hard
timeout_seconds: 600
workspace_files:
- source: task_922_document_management/project/story_bible/series_schema.json
  dest: project/story_bible/series_schema.json
- source: task_922_document_management/project/story_bible/chapter_outline.yaml
  dest: project/story_bible/chapter_outline.yaml
- source: task_922_document_management/project/story_bible/beat_sheet_ch19.md
  dest: project/story_bible/beat_sheet_ch19.md
- source: task_922_document_management/project/story_bible/sensory_palette.json
  dest: project/story_bible/sensory_palette.json
- source: task_922_document_management/project/story_bible/previous_blueprint_ch18.json
  dest: project/story_bible/previous_blueprint_ch18.json
- source: task_922_document_management/project/config/validation_rules.yaml
  dest: project/config/validation_rules.yaml
- source: task_922_document_management/project/notes/editor_feedback_ch19.md
  dest: project/notes/editor_feedback_ch19.md
- source: task_922_document_management/project/notes/continuity_tracker.csv
  dest: project/notes/continuity_tracker.csv
- source: task_922_document_management/project/notes/worldbuilding_glossary.json
  dest: project/notes/worldbuilding_glossary.json
- source: task_922_document_management/project/archive/old_ch19_draft_v1.json
  dest: project/archive/old_ch19_draft_v1.json
- source: task_922_document_management/project/archive/deprecated_schema_v0.json
  dest: project/archive/deprecated_schema_v0.json
- source: task_922_document_management/project/config/export_settings.toml
  dest: project/config/export_settings.toml
source_query: 'Create a valid JSON blueprint for chapter 19 with fields: goal, conflict,
  emotion, must (list), forbid (list), stageTag, beats (3–6 items with beat, protagonist_action,
  obstacle, sensory_anchor, dialogue_goal), sensory_anchors (list), dialogue_plan
  (list), hook, and comfort_element {type, descriptio'
source_line_number: 922
subcategory: Document Management
---
## Prompt

We're deep into production on *The Cipher Sequence* and I'm behind on assembling the chapter blueprints. I need you to build the complete blueprint JSON for **Chapter 19** and save it to `chapter19_blueprint.json` in the working directory root.

Everything you need is scattered across the story bible and project notes. The master chapter outline in `project/story_bible/chapter_outline.yaml` is the canonical source for chapter-level narrative decisions — goal, conflict, emotion, stageTag, must/forbid lists, hook, and comfort element details. The detailed beat-by-beat breakdown lives in `project/story_bible/beat_sheet_ch19.md`, and the curated sensory/dialogue lists are in `project/story_bible/sensory_palette.json`.

The output needs to validate against our schema at `project/story_bible/series_schema.json`. You can also reference the completed Chapter 18 blueprint at `project/story_bible/previous_blueprint_ch18.json` to see what a valid output looks like structurally. The validation constraints are also documented in `project/config/validation_rules.yaml` if you want to double-check field requirements.

There are some editor notes, an old draft, and other reference materials floating around in the project folders — feel free to look at anything that helps, but when sources disagree, the master outline and current schema are authoritative. The old draft in the archive folder is outdated and shouldn't be treated as a template.

The final JSON needs every required field populated, properly typed, and consistent with the schema. No shortcuts — I'll be running this through the automated validator before it goes to the writing team.

## Expected Behavior

The agent must synthesize information from multiple canonical source files to produce a single valid JSON blueprint for Chapter 19. The key challenge is resolving conflicts between authoritative and non-authoritative sources.

### Correct Assembly Process

1. **Goal field**: The agent should use the master outline (`project/story_bible/chapter_outline.yaml`) which specifies `"Recover the stolen cipher before the midnight exchange"`. The old draft (`project/archive/old_ch19_draft_v1.json`) contains the outdated, oversimplified goal `"Find the cipher"` — this must be ignored.

2. **stageTag field**: The master outline (`project/story_bible/chapter_outline.yaml`) specifies `"climax"` for Chapter 19. The editor feedback file (`project/notes/editor_feedback_ch19.md`) argues persuasively that the stageTag should be `"falling"`, but the master outline is explicitly designated as the canonical source. The correct value is `"climax"`.

3. **comfort_element field**: Per the schema (`project/story_bible/series_schema.json`), this must be an object with `type` and `description` subfields. The master outline specifies `type: "familiar_object"` and `description: "The worn leather journal that belonged to the protagonists mentor"`. The old draft (`project/archive/old_ch19_draft_v1.json`) has comfort_element as a plain string, which violates the schema. The agent must use the object format.

4. **conflict field**: From the master outline: `"The protagonist must navigate a flooded underground market while being tracked by a former ally"`.

5. **emotion field**: From the master outline: `"desperate resolve"`.

6. **must field**: Array from the master outline with at least 2 items: `["reveal Maren identity", "reference the broken compass from ch12", "include a ticking clock element"]`.

7. **forbid field**: Array from the master outline with at least 1 item: `["use of supernatural elements", "direct violence against civilians"]`.

8. **hook field**: From the master outline: `"A single lantern flickered at the far end of the flooded corridor"`.

9. **beats field**: Array of 5 beat objects from `project/story_bible/beat_sheet_ch19.md`, each containing `beat`, `protagonist_action`, `obstacle`, `sensory_anchor`, and `dialogue_goal`. The beats are: "Descent into the Market", "The Recognition", "The Chase", "The Confrontation", and "The Escape".

10. **sensory_anchors field**: Array from `project/story_bible/sensory_palette.json` containing 6 sensory anchor strings.

11. **dialogue_plan field**: Array from `project/story_bible/sensory_palette.json` containing 5 dialogue plan strings.

### Trap Handling

- **Trap 1 (contradictory stageTag)**: `project/notes/editor_feedback_ch19.md` argues for `"falling"` but `project/story_bible/chapter_outline.yaml` (canonical) says `"climax"`. Agent must use `"climax"`.
- **Trap 2 (outdated goal)**: `project/archive/old_ch19_draft_v1.json` has simplified goal `"Find the cipher"` but the canonical outline has the full goal. Agent must use the outline's version.
- **Trap 3 (format error in comfort_element)**: `project/archive/old_ch19_draft_v1.json` has comfort_element as a string. The schema requires an object with `type` and `description`. Agent must produce the object format from the canonical outline.

## Grading Criteria

- [ ] Output file `chapter19_blueprint.json` exists and is valid JSON
- [ ] `goal` field equals `"Recover the stolen cipher before the midnight exchange"` (not the outdated "Find the cipher")
- [ ] `conflict` field matches the master outline value about navigating a flooded underground market while being tracked by a former ally
- [ ] `emotion` field equals `"desperate resolve"`
- [ ] `stageTag` field equals `"climax"` (not `"falling"` from editor feedback)
- [ ] `must` field is an array with at least 2 items, including "reveal Maren identity" and "reference the broken compass from ch12"
- [ ] `forbid` field is an array with at least 1 item, including "use of supernatural elements"
- [ ] `beats` field is an array with between 3 and 6 beat objects (expected: 5)
- [ ] Each beat object contains all required subfields: `beat`, `protagonist_action`, `obstacle`, `sensory_anchor`, `dialogue_goal`
- [ ] `sensory_anchors` field is an array of strings (at least 5 items from the sensory palette)
- [ ] `dialogue_plan` field is an array of strings (at least 4 items from the sensory palette)
- [ ] `hook` field is a non-empty string matching the master outline's hook text
- [ ] `comfort_element` field is an object (not a string) with both `type` and `description` subfields
- [ ] `comfort_element.type` equals `"familiar_object"` (not a plain string comfort element)
- [ ] The output JSON validates against the schema structure defined in `project/story_bible/series_schema.json`

## Automated Checks

```python
import os
import json
from pathlib import Path


def grade(transcript: list, workspace_path: str) -> dict:
    """Grade the chapter19_blueprint.json output file."""

    result = {
        "output_file_exists": 0.0,
        "valid_json": 0.0,
        "correct_goal": 0.0,
        "correct_conflict": 0.0,
        "correct_stage_tag": 0.0,
        "no_wrong_stage_tag_falling": 0.0,
        "correct_emotion": 0.0,
        "beats_count_valid": 0.0,
        "beat_subfields_complete": 0.0,
        "comfort_element_is_object": 0.0,
        "comfort_element_type_correct": 0.0,
        "has_must_array": 0.0,
        "has_forbid_array": 0.0,
        "forbid_supernatural": 0.0,
        "has_hook_field": 0.0,
        "has_sensory_anchors_array": 0.0,
        "has_dialogue_plan_array": 0.0,
    }

    output_path = os.path.join(workspace_path, "chapter19_blueprint.json")

    # 1. output_file_exists
    if not os.path.isfile(output_path):
        return result
    result["output_file_exists"] = 1.0

    # Read and parse JSON
    try:
        with open(output_path, "r", encoding="utf-8") as f:
            content = f.read()
    except Exception:
        return result

    parsed = None
    try:
        parsed = json.loads(content)
    except (json.JSONDecodeError, ValueError):
        return result

    # 2. valid_json
    if isinstance(parsed, dict):
        result["valid_json"] = 1.0

    # 3. correct_goal
    goal = parsed.get("goal", "")
    if isinstance(goal, str) and "recover the stolen cipher before the midnight exchange" in goal.lower():
        result["correct_goal"] = 1.0

    # 4. correct_conflict
    conflict = parsed.get("conflict", "")
    if isinstance(conflict, str):
        conflict_lower = conflict.lower()
        if "flooded" in conflict_lower and "underground market" in conflict_lower and "former ally" in conflict_lower:
            result["correct_conflict"] = 1.0

    # 5. correct_stage_tag
    stage_tag = parsed.get("stageTag", "")
    if isinstance(stage_tag, str) and stage_tag.lower() == "climax":
        result["correct_stage_tag"] = 1.0

    # 6. no_wrong_stage_tag_falling
    if isinstance(stage_tag, str) and stage_tag.lower() != "falling":
        result["no_wrong_stage_tag_falling"] = 1.0

    # 7. correct_emotion
    emotion = parsed.get("emotion", "")
    if isinstance(emotion, str) and "desperate" in emotion.lower() and "resolve" in emotion.lower():
        result["correct_emotion"] = 1.0

    # 8. beats_count_valid (partial scoring)
    beats = parsed.get("beats", [])
    if isinstance(beats, list):
        count = len(beats)
        if 3 <= count <= 6:
            result["beats_count_valid"] = 1.0
        elif count == 2 or count == 7:
            result["beats_count_valid"] = 0.25
        # else 0.0

    # 9. beat_subfields_complete (partial scoring based on proportion of complete beats)
    required_beat_fields = {"beat", "protagonist_action", "obstacle", "sensory_anchor", "dialogue_goal"}
    if isinstance(beats, list) and len(beats) > 0:
        complete_count = 0
        for b in beats:
            if isinstance(b, dict) and required_beat_fields.issubset(b.keys()):
                complete_count += 1
        result["beat_subfields_complete"] = round(complete_count / len(beats), 2)

    # 10. comfort_element_is_object
    comfort = parsed.get("comfort_element", None)
    if isinstance(comfort, dict) and "type" in comfort and "description" in comfort:
        result["comfort_element_is_object"] = 1.0

    # 11. comfort_element_type_correct
    if isinstance(comfort, dict):
        ce_type = comfort.get("type", "")
        if isinstance(ce_type, str) and ce_type.lower() == "familiar_object":
            result["comfort_element_type_correct"] = 1.0

    # 12. has_must_array
    must = parsed.get("must", [])
    if isinstance(must, list) and len(must) >= 2:
        must_lower = [m.lower() for m in must if isinstance(m, str)]
        has_maren = any("maren" in m and "identity" in m for m in must_lower)
        has_compass = any("broken compass" in m or "compass" in m for m in must_lower)
        if has_maren and has_compass:
            result["has_must_array"] = 1.0
        elif has_maren or has_compass:
            result["has_must_array"] = 0.5

    # 13. has_forbid_array
    forbid = parsed.get("forbid", [])
    if isinstance(forbid, list) and len(forbid) >= 1:
        result["has_forbid_array"] = 1.0

    # 14. forbid_supernatural
    if isinstance(forbid, list):
        forbid_lower = [f.lower() for f in forbid if isinstance(f, str)]
        if any("supernatural" in f for f in forbid_lower):
            result["forbid_supernatural"] = 1.0

    # 15. has_hook_field
    hook = parsed.get("hook", "")
    if isinstance(hook, str) and "lantern" in hook.lower() and len(hook) >= 10:
        result["has_hook_field"] = 1.0

    # 16. has_sensory_anchors_array
    sa = parsed.get("sensory_anchors", [])
    if isinstance(sa, list) and len(sa) >= 5:
        result["has_sensory_anchors_array"] = 1.0
    elif isinstance(sa, list) and len(sa) >= 3:
        result["has_sensory_anchors_array"] = 0.5

    # 17. has_dialogue_plan_array
    dp = parsed.get("dialogue_plan", [])
    if isinstance(dp, list) and len(dp) >= 4:
        result["has_dialogue_plan_array"] = 1.0
    elif isinstance(dp, list) and len(dp) >= 2:
        result["has_dialogue_plan_array"] = 0.5

    return result
```

## LLM Judge Rubric

### Dimension 1: Source Prioritization & Conflict Resolution (Weight: 40%)

Evaluates whether the agent correctly identified the canonical source hierarchy and resolved conflicts between authoritative and non-authoritative sources.

| Score | Description |
|-------|-------------|
| 1.0 | Agent consistently used the master outline as canonical source, correctly rejected the editor feedback's stageTag suggestion ("falling"), used the full goal from the outline rather than the old draft's simplified version, and produced comfort_element in object format per schema. All three traps handled correctly. |
| 0.75 | Agent handled 2 out of 3 traps correctly. One minor deviation from canonical source, but overall demonstrated understanding of source hierarchy. |
| 0.5 | Agent handled 1 out of 3 traps correctly, or mixed canonical and non-canonical values across multiple fields. Shows partial understanding of source priority. |
| 0.25 | Agent mostly relied on non-canonical sources (old draft, editor feedback) but got some values right by coincidence. |
| 0.0 | Agent used the old draft as primary template, adopted the editor's stageTag recommendation, or produced comfort_element as a string. No evidence of source prioritization. |

### Dimension 2: Data Extraction Accuracy & Completeness (Weight: 35%)

Evaluates whether all required fields were extracted from the correct sources with accurate values.

| Score | Description |
|-------|-------------|
| 1.0 | All 11 required fields present with correct values. Beats extracted accurately from beat_sheet_ch19.md with all 5 subfields. Sensory anchors and dialogue plan extracted from sensory_palette.json. Must/forbid arrays complete. |
| 0.75 | 9-10 fields correct. Minor inaccuracies in 1-2 fields (e.g., slightly paraphrased values, missing one item from an array). |
| 0.5 | 7-8 fields correct. Some fields missing or with values from wrong sources. Beat extraction partially complete. |
| 0.25 | 4-6 fields correct. Significant gaps in extraction. Multiple fields missing or incorrectly populated. |
| 0.0 | Fewer than 4 fields correct, or output is not a valid JSON object. |

### Dimension 3: Schema Compliance & Structural Validity (Weight: 25%)

Evaluates whether the output JSON conforms to the schema structure and validation rules.

| Score | Description |
|-------|-------------|
| 1.0 | Output is valid JSON, conforms to series_schema.json structure. All types correct (strings, arrays, objects). Beat count within 3-6. comfort_element is an object with required subfields. stageTag is a valid enum value. No extra fields violating additionalProperties:false. |
| 0.75 | Valid JSON with correct overall structure. 1-2 minor type issues or constraint violations (e.g., beat count slightly off, one missing subfield). |
| 0.5 | Valid JSON but with notable structural issues: wrong types for some fields, missing required subfields, or constraint violations in multiple areas. |
| 0.25 | Parseable JSON but significant structural problems: wrong top-level structure, many missing fields, or fundamental type mismatches. |
| 0.0 | Output is not valid JSON, is completely empty, or bears no structural resemblance to the required schema. |