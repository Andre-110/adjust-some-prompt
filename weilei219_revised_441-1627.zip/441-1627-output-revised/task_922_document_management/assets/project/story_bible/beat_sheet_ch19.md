# Beat Sheet — Chapter 19: The Flooded Exchange

**Series:** The Cipher Sequence  
**Chapter:** 19  
**Stage:** Climax (Act III)  
**Emotion:** Desperate resolve  
**Last revised:** 2024-11-03  

---

## Beat 1: Descent into the Market

- **Protagonist Action:** Slips through the rusted grate into knee-deep water
- **Obstacle:** Rising water level threatens to seal the entrance
- **Sensory Anchor:** The metallic tang of rust and stagnant water
- **Dialogue Goal:** Extract location info from a reluctant vendor

> *Notes:* Open with the hook line — "A single lantern flickered at the far end of the flooded corridor." Establish the claustrophobic atmosphere immediately. The vendor speaks in trade slang; protagonist must adapt quickly. Reference the broken compass here — protagonist checks it instinctively even though it no longer works. This callback to ch12 should feel habitual, not expository.

---

## Beat 2: The Recognition

- **Protagonist Action:** Spots Maren across the crowded stalls
- **Obstacle:** Maren signals armed guards
- **Sensory Anchor:** Flickering neon reflected on dark water
- **Dialogue Goal:** Buy time with misdirection

> *Notes:* This is the Maren identity reveal moment. The protagonist recognizes Maren despite the disguise — a detail from their shared past gives it away. Keep the recognition internal for a beat before Maren notices. The misdirection dialogue should reference the false objective planted in ch17. Ticking clock element: the midnight exchange is 40 minutes away.

---

## Beat 3: The Chase

- **Protagonist Action:** Ducks through a collapsed archway
- **Obstacle:** Dead-end passage forces a detour
- **Sensory Anchor:** Echo of boots splashing on stone
- **Dialogue Goal:** Convince a bystander to open a locked gate

> *Notes:* Fast pacing. Short sentences. The collapsed archway should feel dangerous — debris still shifting. The bystander is a market regular who wants no trouble; protagonist must offer something convincing (false promise of protection). The detour adds 10 minutes to the clock. Water is rising — mention it at least twice in this beat.

---

## Beat 4: The Confrontation

- **Protagonist Action:** Corners Maren near the exchange point
- **Obstacle:** Maren reveals knowledge of the protagonist's real identity
- **Sensory Anchor:** The low hum of generators beneath the floor
- **Dialogue Goal:** Negotiate for the cipher without revealing desperation

> *Notes:* The emotional core of the chapter. Maren's knowledge of the protagonist's identity shifts the power dynamic. The negotiation should feel like a chess match — each line calculated. The generators provide a constant low-frequency tension. The comfort element surfaces here: the protagonist touches the worn leather journal in their coat pocket, grounding themselves. Ticking clock: 12 minutes to midnight.

---

## Beat 5: The Escape

- **Protagonist Action:** Grabs the cipher and triggers a smoke device
- **Obstacle:** Exit route is blocked by rising floodwater
- **Sensory Anchor:** Acrid smoke mixing with damp air
- **Dialogue Goal:** Radio ally for extraction coordinates

> *Notes:* Maximum tension. The smoke device is improvised — established in the protagonist's kit from ch16. The blocked exit forces a vertical escape (up through maintenance shafts). The radio exchange should be coded — ally recognizes the extraction protocol from training. End the chapter with the protagonist emerging above the flood line, cipher in hand, as the market below begins to flood completely. Leave Maren's fate ambiguous.

---

## Summary

| Beat | Title | Clock Remaining |
|------|-------|----------------|
| 1 | Descent into the Market | ~55 min |
| 2 | The Recognition | ~40 min |
| 3 | The Chase | ~25 min |
| 4 | The Confrontation | ~12 min |
| 5 | The Escape | ~3 min |

**Total beats:** 5  
**Comfort element:** The worn leather journal (familiar_object) — surfaces in Beat 4  
**Key callbacks:** Broken compass (ch12), Maren identity (ch8), trade slang (ch14), smoke device (ch16)
