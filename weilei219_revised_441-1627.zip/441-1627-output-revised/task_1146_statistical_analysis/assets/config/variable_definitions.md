# Variable Definitions and Units

This document provides the authoritative definitions and units for all variables used in the Regional Innovation Subsidy Program impact evaluation.

---

## Main Panel Data (`data/panel_data_main.csv`)

| Variable | Definition | Unit / Values |
|---|---|---|
| `firm_id` | Unique firm identifier | String (e.g., F0001) |
| `year` | Calendar year of observation | Integer (2012–2021) |
| `revenue` | Annual firm revenue | **Thousands of USD** |
| `treated` | Treatment group indicator (firm is in a region targeted by the policy) | 0 = control, 1 = treated |
| `post` | Post-treatment period indicator | 0 = pre-policy (before 2017), 1 = post-policy (2017 onward) |
| `num_employees` | Number of employees at the firm | Count |
| `region` | Region code where the firm is headquartered | A, B, C, or D |
| `industry` | Industry classification | tech, manufacturing, services, retail |

## Firm Characteristics (`data/firm_characteristics.csv`)

| Variable | Definition | Unit / Values |
|---|---|---|
| `firm_id` | Unique firm identifier (matches panel data) | String |
| `founding_year` | Year the firm was founded | Integer |
| `hq_state` | US state abbreviation of headquarters | Two-letter state code |
| `public` | Whether the firm is publicly traded | 0 = private, 1 = public |
| `initial_capital` | Initial capitalization at founding | **USD (raw dollars)** |

## Supplementary Outcomes (`data/supplementary_outcomes.csv`)

| Variable | Definition | Unit / Values |
|---|---|---|
| `firm_id` | Unique firm identifier (matches panel data) | String |
| `year` | Calendar year of observation | Integer (2012–2021) |
| `profit_margin` | Net profit margin | Percentage (1–30%) |
| `rd_spending` | Annual research and development expenditure | **USD (raw dollars, NOT thousands)** |
| `market_share` | Firm's estimated market share within its industry-region | Proportion (0–1) |

> **⚠️ Important Unit Note:** `revenue` in the main panel data is recorded in **thousands of USD**, while `rd_spending` in the supplementary outcomes file is recorded in **raw USD**. Any joint analysis combining these variables must account for this difference in units. To convert `rd_spending` to thousands of USD, divide by 1,000. Alternatively, multiply `revenue` by 1,000 to convert to raw USD.

## Region Mapping (`data/region_mapping.csv`)

| Variable | Definition | Unit / Values |
|---|---|---|
| `region_code` | Region code | A, B, C, D |
| `region_name` | Full region name | Northeast, Southeast, Midwest, West |
| `treated_by_policy` | Whether the region is targeted by the policy | 0 = not targeted, 1 = targeted |

## Macroeconomic Indicators (`data/annual_macro_indicators.csv`)

| Variable | Definition | Unit / Values |
|---|---|---|
| `year` | Calendar year | Integer (2012–2021) |
| `gdp_growth_pct` | Annual real GDP growth rate | Percentage |
| `inflation_pct` | Annual CPI inflation rate | Percentage |
| `unemployment_pct` | Annual average unemployment rate | Percentage |

---

## Notes

- The policy implementation date is **January 1, 2017** (see `data/policy_timeline.json` for official documentation).
- Regions A (Northeast) and B (Southeast) are the treated regions.
- Regions C (Midwest) and D (West) serve as the control group.
- All monetary values should be checked for unit consistency before merging datasets.
