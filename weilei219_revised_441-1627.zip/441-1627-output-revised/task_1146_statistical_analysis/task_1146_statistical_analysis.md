---
id: task_1146_statistical_analysis
name: Difference-in-Differences Policy Impact Analysis
category: Data Analysis
grading_type: hybrid
difficulty: hard
timeout_seconds: 720
workspace_files:
- source: task_1146_statistical_analysis/data/panel_data_main.csv
  dest: data/panel_data_main.csv
- source: task_1146_statistical_analysis/data/firm_characteristics.csv
  dest: data/firm_characteristics.csv
- source: task_1146_statistical_analysis/data/supplementary_outcomes.csv
  dest: data/supplementary_outcomes.csv
- source: task_1146_statistical_analysis/data/policy_timeline.json
  dest: data/policy_timeline.json
- source: task_1146_statistical_analysis/data/legacy_panel_2019_extract.csv
  dest: data/legacy_panel_2019_extract.csv
- source: task_1146_statistical_analysis/config/analysis_config.yaml
  dest: config/analysis_config.yaml
- source: task_1146_statistical_analysis/config/variable_definitions.md
  dest: config/variable_definitions.md
- source: task_1146_statistical_analysis/notes/analyst_notes_2023.txt
  dest: notes/analyst_notes_2023.txt
- source: task_1146_statistical_analysis/notes/meeting_minutes_q3.txt
  dest: notes/meeting_minutes_q3.txt
- source: task_1146_statistical_analysis/scripts/old_regression_output.txt
  dest: scripts/old_regression_output.txt
- source: task_1146_statistical_analysis/data/region_mapping.csv
  dest: data/region_mapping.csv
- source: task_1146_statistical_analysis/data/annual_macro_indicators.csv
  dest: data/annual_macro_indicators.csv
grading_weights:
  automated: 0.55
  llm_judge: 0.45
source_query: Generate simulated panel data with a policy shock and run a difference-in-differences
  (DID) regression controlling for entity and year fixed effects, with standard errors
  clustered at the firm level, then interpret the regression results (including a
  parallel-trends/event-study check).
source_line_number: 1146
subcategory: Statistical Analysis and Modeling
---
## Prompt

We're closing the evaluation of the Regional Innovation Subsidy Program, and I need a final analytical memo saved to `reports/did_analysis_report.md`.

Please use the materials in the workspace to determine the right analysis setup and produce a decision-ready writeup for senior leadership. I care at least as much about whether you make the right judgment calls on the underlying materials as I do about the regression output itself.

What I need in the report:

- A short executive summary at the top with the bottom-line treatment effect on revenue and what it means in practical terms.
- A main DID analysis for revenue using a two-way fixed effects setup with firm and year fixed effects and standard errors clustered at the firm level.
- An event-study / parallel-trends assessment using the event window implied by the project materials.
- At least two robustness checks. These should be substantive, not just cosmetic restatements of the same model.
- A data quality / evidence review section that explains which files you treated as authoritative, which ones you did not, and why.

A few important expectations:

- The workspace contains conflicting and stale materials from different stages of the project. Do not assume every file should be used just because it exists.
- If you combine data sources for robustness work, make sure you reconcile definitions and units before interpreting coefficients.
- If different documents imply different modeling choices, resolve that conflict explicitly in the report rather than silently picking one.
- Senior leadership will read this as a final memo, so include tables in Markdown and make the narrative understandable to a non-technical but quantitatively literate audience.

Use your judgment on exact presentation, but the report should make it clear:
1. what you estimated,
2. why that specification is the right baseline given the evidence in the workspace,
3. whether the identifying assumptions look credible,
4. how sensitive the conclusion is to reasonable alternatives.

## Expected Behavior

The agent should produce `reports/did_analysis_report.md` as a complete Markdown report. The task is not only to run a DID, but to adjudicate conflicting evidence across files and document those choices.

### Reference analytical setup
The reference answer is based on:
- `data/panel_data_main.csv` as the authoritative panel
- Outcome: `revenue`
- Treatment timing: `post = 1` for `year >= 2017`
- Specification: two-way fixed effects DID with **firm fixed effects and year fixed effects**
- Inference: **standard errors clustered at the firm level**
- Event-study window from `config/analysis_config.yaml`: `[-4, 4]`
- Omitted event-study reference period: `t-1`

Under that reference setup, the main ATT / DID coefficient on revenue is expected to be approximately **15.0 thousand USD**, with reasonable implementations generally landing in the broad neighborhood of about **10 to 20 thousand USD**.

### Trap 1 — Outdated legacy extract
The file `data/legacy_panel_2019_extract.csv` is not the right base panel for the main analysis:
- it only covers **2018–2019**
- it is an older extract
- treated-firm revenue values are systematically lower than the corrected main panel for overlapping years

Correct behavior:
- use `data/panel_data_main.csv` as the primary panel dataset
- either exclude the legacy extract entirely or explicitly flag it as stale / non-authoritative in the data quality section
- do **not** substitute it for the main panel and do **not** merge it into the main revenue series for the baseline DID

A strong answer should not merely avoid saying “2018 policy year”; it should actively explain why the legacy extract was rejected.

### Trap 2 — Contradictory policy timing
There is a real conflict in the workspace:
- `data/policy_timeline.json` says implementation date is **2017-01-01**
- `config/analysis_config.yaml` says `policy_year: 2017`
- `notes/analyst_notes_2023.txt` incorrectly speculates that rollout happened in **2018**

Correct behavior:
- explicitly identify the contradiction
- explain why the official policy documentation and project config outweigh the informal analyst note
- define treatment timing using **2017** as the first post period

A weak answer may simply use 2017 without discussing the contradiction; a strong answer resolves the conflict transparently.

### Trap 3 — Unit mismatch
If the agent uses `data/supplementary_outcomes.csv` in robustness checks, especially with `rd_spending`, it must handle units correctly:
- `revenue` in `panel_data_main.csv` is in **thousands of USD**
- `rd_spending` in `supplementary_outcomes.csv` is in **raw USD**

Correct behavior:
- either convert `rd_spending` to thousands by dividing by 1,000, or convert `revenue` to raw USD before joint interpretation
- explicitly document the conversion in the report
- avoid interpreting coefficients from a mixed-unit regression as though the scales were already aligned

### Noise files
- `notes/meeting_minutes_q3.txt` is operational noise and should not inform the econometric analysis
- `scripts/old_regression_output.txt` is from an unrelated wage regression and should not be used as evidence about this policy evaluation

### Event-study expectations
The event study should:
- use the configured window and reference period
- report lead and lag coefficients, ideally in a table
- discuss whether pre-treatment coefficients are close enough to zero to support parallel trends
- distinguish between “no obvious pre-trend problem” and “proof of parallel trends”

A strong response will reference specific pre-treatment coefficients or at least specific event-time periods rather than making only a generic statement.

### Robustness expectations
The report should include at least two substantive robustness checks. Examples include:
- adding reasonable covariates from the provided files while preserving the baseline interpretation
- heterogeneity by industry or region with coherent interpretation
- alternative but still defensible specifications
- using supplementary outcomes carefully and with unit reconciliation

Not all alternative specifications are directly comparable. If the model changes scale (for example, a log outcome), the report should say so explicitly. In that case, LLM judging should evaluate whether the interpretation is coherent rather than forcing the raw ATT to be in the 10–20 range.

### Report structure expectations
The report should include, at minimum:
- Executive Summary
- Data / Evidence Review
- Methodology
- Main DID Results
- Event Study / Parallel Trends
- Robustness Checks
- Data Quality and File Adjudication
- Conclusion

## Grading Criteria

- [ ] Report exists at `reports/did_analysis_report.md` and is a structured Markdown memo with clear sections and readable tables
- [ ] Baseline analysis uses the authoritative panel data (`data/panel_data_main.csv`) rather than the legacy 2019 extract
- [ ] Report explicitly resolves the policy-year conflict in favor of **2017** and explains why official documentation is more authoritative than the analyst note
- [ ] Main results include a clearly labeled DID / ATT / Treated×Post estimate for revenue from the reference TWFE specification
- [ ] The reference specification is described as firm fixed effects + year fixed effects with standard errors clustered at the firm level
- [ ] Event-study section reports leads/lags consistent with the configured window and evaluates pre-trends with specific evidence
- [ ] At least two robustness checks are included and are analytically meaningful
- [ ] If `rd_spending` or other supplementary variables are used jointly with revenue, the report explicitly documents a correct unit conversion
- [ ] Data quality / evidence review flags stale or irrelevant materials (legacy extract, incorrect analyst note, unrelated regression output, meeting minutes)
- [ ] Main tables include enough detail to support interpretation: coefficient, uncertainty measure (SE and/or CI), and significance information where appropriate
- [ ] Executive summary states the bottom-line conclusion in accessible language and does not overclaim beyond the evidence
- [ ] If the report uses a transformed outcome or materially different scale in a robustness specification, it clearly distinguishes that from the baseline raw-unit ATT rather than conflating the magnitudes

## Automated Checks

```python
import os
import re
from pathlib import Path

def grade(transcript: list, workspace_path: str) -> dict:
    """Grade the DID analysis report with weighted checks and stricter extraction."""
    report_path = Path(workspace_path) / "reports" / "did_analysis_report.md"

    results = {
        "output_file_exists": 0.0,
        "report_structure": 0.0,
        "uses_main_panel_data": 0.0,
        "rejects_legacy_extract": 0.0,
        "correct_policy_year": 0.0,
        "resolves_policy_year_conflict": 0.0,
        "did_estimate_labeled_and_in_range": 0.0,
        "clustered_standard_errors": 0.0,
        "entity_fixed_effects": 0.0,
        "year_fixed_effects": 0.0,
        "event_study_section": 0.0,
        "event_study_specific_periods": 0.0,
        "robustness_checks": 0.0,
        "unit_conversion_documented": 0.0,
        "statistical_uncertainty_reported": 0.0,
    }

    weights = {
        "output_file_exists": 0.04,
        "report_structure": 0.08,
        "uses_main_panel_data": 0.08,
        "rejects_legacy_extract": 0.08,
        "correct_policy_year": 0.10,
        "resolves_policy_year_conflict": 0.10,
        "did_estimate_labeled_and_in_range": 0.14,
        "clustered_standard_errors": 0.06,
        "entity_fixed_effects": 0.06,
        "year_fixed_effects": 0.06,
        "event_study_section": 0.08,
        "event_study_specific_periods": 0.04,
        "robustness_checks": 0.04,
        "unit_conversion_documented": 0.08,
        "statistical_uncertainty_reported": 0.06,
    }

    if not report_path.is_file():
        return {"score": 0.0, "results": results}

    results["output_file_exists"] = 1.0

    try:
        content = report_path.read_text(encoding="utf-8")
    except Exception:
        return {"score": 0.0, "results": results}

    content_lower = content.lower()

    def has_all_patterns(patterns):
        return all(re.search(p, content_lower, re.IGNORECASE | re.MULTILINE) for p in patterns)

    # Structured memo sections
    section_hits = 0
    section_patterns = [
        r'#{1,6}\s*.*executive\s+summary',
        r'#{1,6}\s*.*(?:data|evidence)',
        r'#{1,6}\s*.*method',
        r'#{1,6}\s*.*(?:main\s+results|did|difference[\-\s]in[\-\s]differences|regression)',
        r'#{1,6}\s*.*(?:event\s+study|parallel\s+trends|pre[\-\s]trend)',
        r'#{1,6}\s*.*robust',
        r'#{1,6}\s*.*(?:data\s+quality|file\s+adjudication|evidence\s+review)',
        r'#{1,6}\s*.*conclusion',
    ]
    for pat in section_patterns:
        if re.search(pat, content_lower, re.IGNORECASE | re.MULTILINE):
            section_hits += 1
    if section_hits >= 6:
        results["report_structure"] = 1.0
    elif section_hits >= 4:
        results["report_structure"] = 0.5

    # Main panel data usage
    if (
        "panel_data_main" in content_lower
        or "data/panel_data_main.csv" in content_lower
        or re.search(r'authoritative[^.\n]{0,80}panel', content_lower)
    ):
        results["uses_main_panel_data"] = 1.0

    # Legacy extract rejection / flagging
    if (
        "legacy_panel_2019_extract" in content_lower
        or "legacy extract" in content_lower
        or "2019 extract" in content_lower
    ):
        if re.search(r'(outdated|stale|older|old|non[\-\s]?authoritative|not\s+authoritative|exclude|excluded|not\s+used|rejected|subset|2018[–\-]2019|2018\s*-\s*2019|biased)', content_lower):
            results["rejects_legacy_extract"] = 1.0
        else:
            results["rejects_legacy_extract"] = 0.5

    # Correct policy year
    if re.search(r'(policy|implementation|treated period|post)[^.\n]{0,80}2017', content_lower) or \
       re.search(r'2017[^.\n]{0,80}(policy|implementation|treated period|post)', content_lower):
        results["correct_policy_year"] = 1.0
    elif "2017" in content_lower:
        results["correct_policy_year"] = 0.5

    # Resolve policy-year conflict explicitly
    if (
        ("analyst notes" in content_lower or "analyst_notes_2023" in content_lower)
        and "2018" in content_lower
        and "2017" in content_lower
        and re.search(r'(conflict|contradict|discrep|official|policy_timeline|authoritative|informal|note)', content_lower)
    ):
        results["resolves_policy_year_conflict"] = 1.0
    elif (
        ("analyst notes" in content_lower or "analyst_notes_2023" in content_lower)
        and ("2018" in content_lower or "2017" in content_lower)
    ):
        results["resolves_policy_year_conflict"] = 0.5

    # DID estimate extraction: require explicit label near numeric estimate
    estimate_patterns = [
        r'(?:\batt\b|\bdid estimate\b|\bdid effect\b|\btreated\s*[×x\*]\s*post\b|\btreat(?:ed)?\s*[×x\*]\s*post\b|\btreatment effect\b)[^0-9\-]{0,20}(-?\d+(?:\.\d+)?)',
        r'(-?\d+(?:\.\d+)?)[^.\n|]{0,30}(?:\batt\b|\bdid estimate\b|\bdid effect\b|\btreated\s*[×x\*]\s*post\b|\btreat(?:ed)?\s*[×x\*]\s*post\b|\btreatment effect\b)',
        r'^\|\s*(?:att|did estimate|did effect|treated\s*[×x\*]\s*post|treat(?:ed)?\s*[×x\*]\s*post|treatment effect)\s*\|[^|\n]*\|\s*(-?\d+(?:\.\d+)?)',
    ]
    extracted_vals = []
    for pat in estimate_patterns:
        for m in re.finditer(pat, content, re.IGNORECASE | re.MULTILINE):
            groups = m.groups()
            for g in groups:
                if g is None:
                    continue
                try:
                    val = float(g)
                    extracted_vals.append(val)
                except ValueError:
                    pass
    if any(10.0 <= v <= 20.0 for v in extracted_vals):
        results["did_estimate_labeled_and_in_range"] = 1.0
    elif extracted_vals:
        results["did_estimate_labeled_and_in_range"] = 0.5

    # Standard errors / FE
    if re.search(r'cluster(?:ed|ing)?[^.\n]{0,40}firm', content_lower):
        results["clustered_standard_errors"] = 1.0
    elif "clustered" in content_lower:
        results["clustered_standard_errors"] = 0.5

    if re.search(r'(firm|entity)[^.\n]{0,20}(fixed effects|fixed effect|\bfe\b)', content_lower):
        results["entity_fixed_effects"] = 1.0

    if re.search(r'(year|time)[^.\n]{0,20}(fixed effects|fixed effect|\bfe\b)', content_lower):
        results["year_fixed_effects"] = 1.0

    # Event study
    if re.search(r'(event\s+study|parallel\s+trends|pre[\-\s]?trend)', content_lower):
        results["event_study_section"] = 1.0

    if re.search(r'(t[\-\s]?[234]|lead|lag|event time|tau[\-\s]?[234]|pre[\-\s]?treatment)', content_lower):
        results["event_study_specific_periods"] = 1.0

    # Robustness checks
    robust_mentions = len(re.findall(r'robust', content_lower))
    hetero_mentions = len(re.findall(r'heterogene', content_lower))
    alternative_mentions = len(re.findall(r'alternative\s+(specification|model|setup)', content_lower))
    covariate_mentions = len(re.findall(r'covariate|control', content_lower))
    if robust_mentions >= 2 or (hetero_mentions + alternative_mentions + covariate_mentions) >= 2:
        results["robustness_checks"] = 1.0

    # Unit conversion: only required if supplementary data / rd_spending is mentioned
    uses_supp = ("supplementary_outcomes" in content_lower) or ("rd_spending" in content_lower) or ("r&d" in content_lower)
    if not uses_supp:
        results["unit_conversion_documented"] = 1.0
    else:
        unit_ok = (
            re.search(r'rd_spending[^.\n]{0,80}(divide|divided|scaled|convert|converted)', content_lower)
            or re.search(r'(divide|divided)\s+by\s+1,?000', content_lower)
            or re.search(r'thousand[s]?\s+of\s+usd', content_lower)
            or re.search(r'raw\s+usd', content_lower)
            or re.search(r'unit[s]?\s+(mismatch|conversion|consistency)', content_lower)
        )
        if unit_ok:
            results["unit_conversion_documented"] = 1.0

    # Uncertainty reporting
    if re.search(r'(standard error|std\.?\s*err|confidence interval|95%\s*ci|p[\-\s]?value|statistically significant)', content_lower):
        results["statistical_uncertainty_reported"] = 1.0

    total_score = 0.0
    for key, weight in weights.items():
        total_score += results[key] * weight

    return {"score": round(total_score, 6), "results": results}
```

## LLM Judge Rubric

### Criterion 1: Trap Detection and Source Adjudication (Weight: 30%)
**Score 1.0**: Explicitly identifies all major source conflicts and resolves them correctly. The report states that `panel_data_main.csv` is the authoritative panel, rejects or flags `legacy_panel_2019_extract.csv` as stale/subset-biased, explicitly notes that analyst notes claim 2018 while official materials indicate 2017, and explains why official policy documents/config are more authoritative. If supplementary outcomes are used, the report also explicitly identifies the revenue vs `rd_spending` unit mismatch and documents the conversion. The reasoning is evidence-based rather than conclusory.

**Score 0.75**: Correctly resolves the major conflicts, but one explanation is incomplete. Typical cases: uses the right panel and 2017 timing and mentions the contradictory analyst note, but only briefly explains why; or uses supplementary data with correct conversion but weak documentation of that step.

**Score 0.5**: Gets the main baseline mostly right but is only partially explicit about the conflicts. Typical cases: uses 2017 and the main panel but does not clearly discuss the analyst note contradiction; or flags the legacy extract as old without explaining why it is analytically dangerous; or uses supplementary data with ambiguous unit handling.

**Score 0.25**: Shows limited source adjudication. May accidentally use the right baseline, but does not meaningfully explain conflicts, or falls into one major trap such as treating the 2018 note as credible, relying on the legacy extract, or mixing units without acknowledging scale differences.

**Score 0.0**: Fails to adjudicate evidence. Uses the wrong policy year, relies on the legacy extract as a valid base, ignores clear contradictions, or combines variables across incompatible units without recognizing the issue.

### Criterion 2: Analytical Depth and Methodological Rigor (Weight: 45%)
**Score 1.0**: Presents a well-specified TWFE DID and demonstrates strong econometric reasoning. Clearly states the baseline identification strategy, interprets the ATT in the correct units, and discusses assumptions with nuance. The event study uses the appropriate window/reference period and the writeup cites specific pre-treatment periods or coefficients when assessing parallel trends. Includes at least two substantive robustness checks that are motivated and interpreted, not merely listed. Distinguishes baseline raw-unit ATT from any transformed-specification results. Notes limitations or remaining threats to validity.

**Score 0.75**: Methodologically solid with moderate depth. The baseline model is clearly described and interpreted correctly. Event-study discussion refers to at least one specific pre-treatment period or coefficient pattern. Includes at least two meaningful robustness checks, though one may be less well motivated or less fully interpreted. Minor gaps in discussing assumptions or limitations.

**Score 0.5**: Contains the required ingredients but with limited depth. The baseline DID is present and roughly correct, but the event-study discussion is generic or only says pre-trends “look fine” without citing specific leads, or robustness checks are mostly formulaic (for example, “added controls” and “checked heterogeneity” with minimal interpretation). If transformed outcomes are used, the distinction from baseline magnitude may be blurry but not fatally misleading.

**Score 0.25**: Significant analytical weakness. May present a regression output but with ambiguous specification, shallow or missing event-study interpretation, only one meaningful robustness check, or weak understanding of identification. Parallel trends may be asserted without evidence. Interpretation may be largely generic.

**Score 0.0**: Lacks credible DID analysis. Missing baseline TWFE structure, no event study, no meaningful robustness work, major methodological confusion, or fabricated-looking results unsupported by the workspace.

### Criterion 3: Result Interpretation and Decision Usefulness (Weight: 15%)
**Score 1.0**: The report translates results into decision-relevant language without overclaiming. The executive summary clearly states the magnitude, direction, and practical meaning of the baseline ATT, explains whether assumptions appear credible, and conveys how robust the conclusion is. The narrative separates statistical evidence from stronger causal claims and avoids overstating certainty.

**Score 0.75**: Clear and useful interpretation with minor overstatement or minor omissions. Senior leadership would understand the bottom line and major caveats, though some nuance may be missing.

**Score 0.5**: Basic interpretation is present but thin. The report states the sign and rough magnitude but gives limited practical meaning, weak caveats, or insufficient distinction between baseline and robustness results.

**Score 0.25**: Interpretation is difficult to use. Results are reported numerically but not translated into implications, or the memo overstates what the design establishes.

**Score 0.0**: No meaningful interpretation or clearly misleading interpretation.

### Criterion 4: Professional Report Quality and Documentation (Weight: 10%)
**Score 1.0**: Well-structured, polished Markdown memo with clear headings, coherent flow, readable tables, and a professional tone suitable for a final policy evaluation deliverable. Data choices, transformations, and exclusions are documented clearly enough for auditability.

**Score 0.75**: Generally well organized and professional, with minor formatting or flow issues. Documentation is mostly adequate.

**Score 0.5**: Readable but uneven. Sections exist, yet formatting, transitions, or documentation quality are inconsistent. The memo would need moderate editing before external use.

**Score 0.25**: Poorly organized or thinly documented. Reads more like raw notes than a final deliverable.

**Score 0.0**: Incoherent, missing key sections, or not recognizable as a professional analytical report.
