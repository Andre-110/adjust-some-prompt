# 修改记录

| 序号 | 修改项 | 修改原因 |
|------|--------|----------|
| 1 | 重写 Prompt 中对交付物和判断任务的描述，强调需显式裁决冲突材料、单位一致性和文件权威性 | 对应问题2、问题3；同时按最终建议避免仅靠“碰巧没写错”通过，并提高对主动推理过程的要求 |
| 2 | 扩展 Expected Behavior，明确参考答案对应的精确基准设定（TWFE + firm/year FE + firm-clustered SE + 2017 policy year + main panel） | 对应问题6；补足 ATT 参考值的模型设定依据，避免对合理变体与基准答案混淆 |
| 3 | 强化 Expected Behavior 中三个 trap 的正确判断路径，特别是要求显式解释 analyst notes 与官方文件冲突、legacy extract 被拒绝原因、rd_spending 单位换算 | 对应问题2、问题3；提升题目区分度并覆盖主动推理能力 |
| 4 | 重写 Grading Criteria，增加“显式解决政策年份冲突”“明确标注 DID/ATT/Treated×Post 估计”“单位转换说明”等可验证能力点 | 对应问题1、问题2、问题3、问题6；使标准与真实能力更对齐 |
| 5 | 重构 automated grade()，将原来等权 12 项改为加权评分 | 对应问题3；避免文件存在等琐碎项与核心分析项权重相同 |
| 6 | 修复 `att_estimate_range` 检查逻辑，改为仅在明确 ATT / DID estimate / Treated×Post 等标签附近提取数值，并要求在合理区间内 | 对应问题1；修复严重假阳性/假阴性风险 |
| 7 | 修复 `rejects_wrong_policy_year` 的宽松负向检测，改为正向检查“是否显式讨论 analyst notes 的 2018 与官方 2017 冲突并解释取舍” | 对应问题2；避免模型忽略陷阱仍拿满分 |
| 8 | 新增 automated check：若使用 supplementary outcomes / rd_spending，则必须检测到单位转换或单位一致性说明；若未使用则不处罚 | 对应问题3、问题6；补上 Trap 3 的自动化覆盖并兼容合理不使用该文件的答案 |
| 9 | 细化 LLM Judge Rubric 权重为 Trap Detection 30%、Analytical Depth 45%、Result Interpretation 15%、Professional Quality 10% | 对应问题4；提高分析深度在总分中的占比 |
| 10 | 重写 LLM Judge 各档位锚点，特别细化中间档（0.5、0.75）为可观察行为，如是否引用具体 pre-treatment periods、是否有两项有动机的稳健性检验 | 对应问题5；降低评分方差、提升区分度 |
