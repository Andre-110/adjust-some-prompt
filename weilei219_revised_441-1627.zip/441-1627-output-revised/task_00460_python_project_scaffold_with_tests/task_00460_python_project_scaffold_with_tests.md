---
id: task_00460_python_project_scaffold_with_tests
name: Python 3 Project Scaffold with Tests and Skill
category: System Administration
subcategory: Software and Environment Management
difficulty: hard
grading_type: automated
grading_weights: {automated: 1.0}
timeout_seconds: 600
input_modality: text-only
external_dependency: none
workspace_files:
  - assets/project_brief.md
skill_creation: true
---

## Prompt

I keep redoing the same Python project setup work, so I want a reusable skill for it and one concrete project scaffold created in this workspace.

Please do two things:

1. Write a `SKILL.md` at the workspace root that explains how you scaffold a small Python 3 project with:
   - src layout
   - pytest-based tests
   - basic packaging metadata
   - sensible defaults for README / LICENSE / .gitignore
   - enough detail that I could reuse the skill later without this exact task prompt

2. Use that skill to create a project directory named `python-project/`.

The project should be a real, runnable scaffold rather than empty placeholders. Read `assets/project_brief.md` before deciding the package name, public API, and test cases. The brief intentionally includes constraints that need to be reconciled. Make reasonable choices and make the result internally consistent.

High-level expectations:
- Python 3 project using src layout
- package code under `python-project/src/`
- tests under `python-project/tests/`
- pytest should run successfully against the created project
- include `pyproject.toml`, `README.md`, `LICENSE`, `.gitignore`
- include `tests/conftest.py`

I care more about correctness and consistency than about matching any one template exactly.

## Expected Behavior

The agent should produce a reusable skill plus a runnable scaffold that correctly interprets `assets/project_brief.md` and resolves its conflicts.

### Required project interpretation

From the brief, the correct scaffolded package should:

1. Be created under `python-project/`.
2. Use package name **`scaffoldcalc`** under `python-project/src/scaffoldcalc/`.
3. Expose a function named **`normalize_name`**.
4. Implement `normalize_name(value: str) -> str` with the following behavior:
   - strip leading and trailing whitespace
   - convert internal runs of whitespace (spaces, tabs, newlines) to a single hyphen
   - lowercase the result
   - keep only ASCII letters `a-z`, digits `0-9`, and hyphens
   - collapse repeated hyphens to a single hyphen
   - remove leading/trailing hyphens after cleanup
   - raise `ValueError` if the normalized result is empty
5. Export `normalize_name` from `scaffoldcalc/__init__.py`.

### Required test behavior

The tests must be genuinely connected to the implementation rather than placeholder text. A correct solution should include tests that collectively verify at least these ground-truth cases:

- `"  Hello   World  "` -> `"hello-world"`
- `"Tabs\tand\nLines"` -> `"tabs-and-lines"`
- `"Already-clean"` -> `"already-clean"`
- `"***"` raises `ValueError`
- input consisting only of whitespace raises `ValueError`

The tests do not have to use exactly these names, but they must import the real package and pass under pytest.

### Packaging and structure expectations

A correct project should include at minimum:

- `python-project/src/scaffoldcalc/__init__.py`
- `python-project/src/scaffoldcalc/core.py`
- `python-project/tests/__init__.py`
- `python-project/tests/test_core.py`
- `python-project/tests/conftest.py`
- `python-project/pyproject.toml`
- `python-project/README.md`
- `python-project/LICENSE`
- `python-project/.gitignore`

`pyproject.toml` should be internally consistent with the scaffold:
- project name should reference `scaffoldcalc`
- pytest configuration should allow the tests to run
- build-system metadata must exist

### SKILL.md expectations

`SKILL.md` must be in the **workspace root only**. It should include:

- YAML frontmatter with `name:` and `description:`
- reusable instructions, not a copy of the task wording
- concrete operational guidance such as commands, file-creation steps, or validation steps
- mention of how to set up src layout, tests, and packaging metadata
- at least one validation step such as running pytest

### Trap handling / correct judgment path

The brief contains conflicting hints about naming. The correct resolution is to prefer the stable public API and final package naming requirements over discarded draft names. Solutions that scaffold a different package (for example `myproject`) are incorrect even if the files otherwise look fine.

The grader should distinguish:
- merely creating files from
- creating a coherent scaffold whose package name, implementation, tests, and metadata all align and whose tests actually pass.

## Grading Criteria

- [ ] `SKILL.md` exists at workspace root with valid YAML frontmatter (`name`, `description`)
- [ ] `SKILL.md` contains concrete, reusable scaffolding instructions and at least one validation step
- [ ] Correct package path exists: `python-project/src/scaffoldcalc/`
- [ ] `scaffoldcalc/__init__.py` exports `normalize_name`
- [ ] `core.py` defines `normalize_name`
- [ ] `normalize_name` implements the required normalization semantics, including error cases
- [ ] `tests/test_core.py` imports the real package/module and asserts the required behavior
- [ ] `tests/conftest.py` exists and is valid Python
- [ ] `pyproject.toml` contains coherent project/build metadata for `scaffoldcalc`
- [ ] README, LICENSE, and `.gitignore` are present and non-trivial
- [ ] `pytest` runs successfully for `python-project/tests/`

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    import ast
    import importlib.util
    import os
    import re
    import subprocess
    import sys
    from pathlib import Path

    ws = Path(workspace_path)
    project = ws / "python-project"
    src_dir = project / "src"
    pkg_dir = src_dir / "scaffoldcalc"
    init_py = pkg_dir / "__init__.py"
    core_py = pkg_dir / "core.py"
    tests_dir = project / "tests"
    test_core = tests_dir / "test_core.py"
    conftest = tests_dir / "conftest.py"
    pyproject = project / "pyproject.toml"
    readme = project / "README.md"
    license_file = project / "LICENSE"
    gitignore = project / ".gitignore"
    skill_md = ws / "SKILL.md"

    scores = {}

    # 1. SKILL.md frontmatter at workspace root only
    score = 0.0
    if skill_md.is_file():
        content = skill_md.read_text(errors="replace")
        fm_match = re.match(r"^---\s*\n(.*?)\n---\s*(?:\n|$)", content, re.DOTALL)
        if fm_match:
            fm = fm_match.group(1)
            has_name = bool(re.search(r"^\s*name\s*:\s*.+$", fm, re.MULTILINE))
            has_desc = bool(re.search(r"^\s*description\s*:\s*.+$", fm, re.MULTILINE))
            if has_name and has_desc:
                score = 1.0
            elif has_name or has_desc:
                score = 0.5
    scores["skill_md_frontmatter"] = score

    # 2. SKILL.md operational quality
    score = 0.0
    if skill_md.is_file():
        content = skill_md.read_text(errors="replace")
        headings = re.findall(r"^#{1,3}\s+.+$", content, re.MULTILINE)
        keywords = [
            "mkdir", "pytest", "pyproject.toml", "src", "tests", "README", "LICENSE", ".gitignore"
        ]
        hit_count = sum(1 for kw in keywords if kw.lower() in content.lower())
        has_validation = bool(re.search(r"\bpytest\b|python\s+-m\s+pytest", content, re.IGNORECASE))
        if len(headings) >= 2 and len(content) >= 300 and hit_count >= 5 and has_validation:
            score = 1.0
        elif len(headings) >= 2 and len(content) >= 180 and hit_count >= 3:
            score = 0.5
    scores["skill_md_content"] = score

    # 3. Correct package structure
    structure_items = [
        pkg_dir,
        init_py,
        core_py,
        tests_dir / "__init__.py",
        test_core,
        conftest,
        pyproject,
        readme,
        license_file,
        gitignore,
    ]
    present = sum(1 for p in structure_items if p.exists())
    scores["project_structure"] = 1.0 if present == len(structure_items) else present / len(structure_items)

    # 4. __init__.py exports normalize_name
    score = 0.0
    if init_py.is_file():
        content = init_py.read_text(errors="replace")
        if re.search(r"from\s+\.core\s+import\s+normalize_name\b", content):
            score = 1.0
        elif "normalize_name" in content:
            score = 0.5
    scores["init_exports_normalize_name"] = score

    # 5. core.py defines normalize_name
    score = 0.0
    if core_py.is_file():
        try:
            tree = ast.parse(core_py.read_text(errors="replace"))
            funcs = [n for n in tree.body if isinstance(n, ast.FunctionDef)]
            names = {f.name for f in funcs}
            if "normalize_name" in names:
                fn = next(f for f in funcs if f.name == "normalize_name")
                arg_count = len(fn.args.args)
                score = 1.0 if arg_count == 1 else 0.5
        except SyntaxError:
            score = 0.0
    scores["core_defines_normalize_name"] = score

    # 6. Implementation semantics via direct import and execution
    score = 0.0
    if core_py.is_file():
        try:
            spec = importlib.util.spec_from_file_location("scaffoldcalc.core", core_py)
            module = importlib.util.module_from_spec(spec)
            assert spec and spec.loader
            spec.loader.exec_module(module)
            fn = getattr(module, "normalize_name", None)
            if callable(fn):
                cases_ok = 0
                total = 5

                try:
                    if fn("  Hello   World  ") == "hello-world":
                        cases_ok += 1
                except Exception:
                    pass
                try:
                    if fn("Tabs\tand\nLines") == "tabs-and-lines":
                        cases_ok += 1
                except Exception:
                    pass
                try:
                    if fn("Already-clean") == "already-clean":
                        cases_ok += 1
                except Exception:
                    pass
                try:
                    fn("***")
                except ValueError:
                    cases_ok += 1
                except Exception:
                    pass
                try:
                    fn("   \t\n ")
                except ValueError:
                    cases_ok += 1
                except Exception:
                    pass

                score = cases_ok / total
        except Exception:
            score = 0.0
    scores["normalize_name_behavior"] = score

    # 7. Test file imports real package/module and covers key cases
    score = 0.0
    if test_core.is_file():
        try:
            content = test_core.read_text(errors="replace")
            tree = ast.parse(content)
            has_test_fn = any(isinstance(n, ast.FunctionDef) and n.name.startswith("test_") for n in tree.body)
            imports_target = False
            for node in ast.walk(tree):
                if isinstance(node, ast.ImportFrom):
                    if node.module in {"scaffoldcalc", "scaffoldcalc.core"}:
                        imported = {alias.name for alias in node.names}
                        if "normalize_name" in imported:
                            imports_target = True
                elif isinstance(node, ast.Import):
                    for alias in node.names:
                        if alias.name in {"scaffoldcalc", "scaffoldcalc.core"}:
                            imports_target = True

            case_hits = 0
            text_norm = content.replace('"', "'")
            expected_fragments = [
                "hello-world",
                "tabs-and-lines",
                "already-clean",
                "ValueError",
            ]
            case_hits = sum(1 for frag in expected_fragments if frag in text_norm)

            if has_test_fn and imports_target and case_hits >= 4:
                score = 1.0
            elif has_test_fn and imports_target:
                score = 0.5
        except SyntaxError:
            score = 0.0
    scores["tests_import_and_coverage"] = score

    # 8. conftest.py valid python
    score = 0.0
    if conftest.is_file():
        try:
            ast.parse(conftest.read_text(errors="replace"))
            score = 1.0
        except SyntaxError:
            score = 0.0
    scores["conftest_valid"] = score

    # 9. pyproject coherence
    score = 0.0
    if pyproject.is_file():
        content = pyproject.read_text(errors="replace")
        has_project = "[project]" in content
        has_build = "[build-system]" in content
        references_name = bool(re.search(r'name\s*=\s*["\']scaffoldcalc["\']', content))
        mentions_pytest = "pytest" in content.lower()
        if has_project and has_build and references_name and mentions_pytest:
            score = 1.0
        elif has_project and has_build and references_name:
            score = 0.75
        elif has_project and has_build:
            score = 0.5
        else:
            score = 0.0
    scores["pyproject_coherence"] = score

    # 10. docs and ignore files non-trivial
    score = 0.0
    parts = 0
    total = 4
    if readme.is_file() and len(readme.read_text(errors="replace").strip()) >= 80:
        parts += 1
    if license_file.is_file() and len(license_file.read_text(errors="replace").strip()) >= 20:
        parts += 1
    if gitignore.is_file() and len([ln for ln in gitignore.read_text(errors="replace").splitlines() if ln.strip()]) >= 3:
        parts += 1
    if readme.is_file():
        readme_text = readme.read_text(errors="replace").lower()
        if "normalize_name" in readme_text and "scaffoldcalc" in readme_text:
            parts += 1
    score = parts / total
    scores["docs_and_metadata_files"] = score

    # 11. Run pytest for real
    pytest_score = 0.0
    if project.is_dir():
        env = os.environ.copy()
        existing = env.get("PYTHONPATH", "")
        env["PYTHONPATH"] = str(src_dir) + (os.pathsep + existing if existing else "")
        try:
            result = subprocess.run(
                [sys.executable, "-m", "pytest", "tests", "--tb=short", "-q"],
                cwd=str(project),
                env=env,
                capture_output=True,
                text=True,
                timeout=120,
            )
            if result.returncode == 0:
                pytest_score = 1.0
            else:
                combined = (result.stdout or "") + "\n" + (result.stderr or "")
                if "collected" in combined.lower():
                    pytest_score = 0.2
        except Exception:
            pytest_score = 0.0
    scores["pytest_passes"] = pytest_score

    return scores
```

## LLM Judge Rubric

Use this rubric only if an LLM-based secondary review is needed.

### Dimension 1: Reusable skill quality
- **1.0**: `SKILL.md` is clearly reusable beyond this task, includes concrete commands or file-creation steps, explains src layout / tests / metadata choices, and includes explicit validation guidance.
- **0.75**: Mostly reusable and concrete, but missing one important operational element such as validation or packaging guidance.
- **0.5**: Partially reusable; contains some actionable steps but is generic, thin, or too tied to this exact prompt.
- **0.25**: Mostly vague prose or checklist with little operational value.
- **0.0**: Missing, malformed, or non-actionable.

### Dimension 2: Conflict resolution and judgment
- **1.0**: Correctly resolves naming/API conflicts from the brief, chooses `scaffoldcalc` and `normalize_name`, and keeps package path, metadata, docs, and tests aligned.
- **0.75**: Minor inconsistency in one place, but overall interpretation is correct.
- **0.5**: Shows some awareness of ambiguity but leaves meaningful inconsistencies.
- **0.25**: Follows superficial cues and gets major naming/API choices wrong.
- **0.0**: Ignores the brief’s constraints entirely.

### Dimension 3: Implementation correctness
- **1.0**: `normalize_name` fully matches required semantics, including whitespace normalization, allowed-character filtering, hyphen collapsing, trimming, and empty-result errors.
- **0.75**: Mostly correct with one minor edge-case miss.
- **0.5**: Works for simple happy paths but misses multiple edge cases or error handling.
- **0.25**: Minimal placeholder logic or substantially wrong behavior.
- **0.0**: No working implementation.

### Dimension 4: Test realism and quality
- **1.0**: Tests import the real implementation, cover normal and edge cases, and would catch common wrong implementations.
- **0.75**: Tests are real and runnable but not very discriminative.
- **0.5**: Tests exist but are shallow or miss important edge cases.
- **0.25**: Tests are mostly placeholder-level.
- **0.0**: Missing or non-runnable tests.

### Dimension 5: Delivery quality
- **1.0**: Project is runnable with pytest, documentation is coherent, and the scaffold looks like a plausible real starter project.
- **0.75**: Mostly coherent with small rough edges.
- **0.5**: Mixed quality; some files are okay but overall polish or consistency is limited.
- **0.25**: Barely scaffolded; mostly token compliance.
- **0.0**: Not a usable scaffold.
