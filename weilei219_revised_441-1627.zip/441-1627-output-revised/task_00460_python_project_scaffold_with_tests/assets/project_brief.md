You're helping standardize a tiny internal Python starter project.

Please scaffold a small package and include a tiny function plus tests so we can use it as a template.

Notes from earlier drafts (some of these may be stale):
- Someone first suggested package name `myproject`.
- Another note proposed `project_utils`.
- A later review said the public API should stay very small and center on a single function called `normalize_name`.
- We want src layout and pytest.
- README / LICENSE / .gitignore should be included.
- The project folder in this workspace should be named `python-project`.

Final direction that should win over stale draft names:
- The actual distributable/package name should be `scaffoldcalc`.
- Put implementation in `src/scaffoldcalc/core.py`.
- Re-export the main function from `src/scaffoldcalc/__init__.py`.

Behavior for `normalize_name(value: str) -> str`:
- Trim surrounding whitespace.
- Replace any run of whitespace with a single `-`.
- Lowercase the result.
- Remove characters other than ASCII letters, digits, and `-`.
- Collapse repeated `-` characters to one `-`.
- Strip leading/trailing `-`.
- If nothing remains, raise `ValueError`.

Examples that should be true:
- `normalize_name("  Hello   World  ") == "hello-world"`
- `normalize_name("Tabs\tand\nLines") == "tabs-and-lines"`
- `normalize_name("Already-clean") == "already-clean"`
- `normalize_name("***")` raises `ValueError`
- `normalize_name("   ")` raises `ValueError`

Do not treat the stale names above as authoritative if they conflict with the final direction.
