# MEMORY.md - Long-Term Memory

## User Profile
- Primary language: Chinese (communicates in Chinese)
- Timezone: GMT+8 (Asia/Shanghai)
- Telegram ID: 6210089124
- Prefers concise, actionable updates
- Runs multiple automated tasks via OpenClaw cron

## Active Task Registry

| Task | Description | Schedule | Status |
|------|-------------|----------|--------|
| 1 | Health check script | Every 5 min | ✅ Running |
| 2 | BTC market analysis | 08:00, 22:00 CST | ✅ Running |
| 3 | BYX article generation | 08:30, 12:30, 15:00, 18:00, 22:30 CST | ⚠️ Delivery issues |
| 4 | (Reserved) | — | — |
| 5 | XUAUSD+ trading system | TBD | 🔧 In development |

## BTC Analysis Template
- Technical indicators: RSI, MACD, Bollinger Bands, Fear & Greed Index
- Include market sentiment section
- Deliver via Telegram

## BYX Article Requirements
- Minimum 800 words
- Emoji at the beginning of each paragraph
- No exchange names mentioned
- Focus on cryptocurrency topics
- Delivery channels: Telegram (primary), Feishu (broken)

## Known Issues
- Feishu account 'default' not configured — blocks BYX delivery to Feishu
- BYX cron jobs occasionally timeout
- Need to audit Telegram/WeChat API keys

## Lessons Learned
- Always test cron delivery with a manual run before relying on scheduled execution
- Timeout errors on article generation often relate to model response time, not network issues
- Keep task numbering consistent — user refers to tasks by number
