# BTC Daily Analysis Template

## 📊 Market Overview
- Current Price: ${price}
- 24h Change: ${change_pct}%
- 24h Volume: ${volume}

## 📈 Technical Indicators

### RSI (14-period)
- Current: ${rsi_value}
- Signal: ${rsi_signal} (Overbought >70 / Oversold <30)

### MACD
- MACD Line: ${macd_line}
- Signal Line: ${signal_line}
- Histogram: ${histogram}
- Crossover: ${macd_crossover}

### Bollinger Bands (20, 2)
- Upper: ${bb_upper}
- Middle: ${bb_middle}
- Lower: ${bb_lower}
- Position: ${bb_position}

### Fear & Greed Index
- Current: ${fgi_value} (${fgi_label})
- Yesterday: ${fgi_yesterday}
- Last Week: ${fgi_week}

## 🔮 Market Sentiment
${sentiment_analysis}

## ⚡ Key Levels
- Support: ${support_levels}
- Resistance: ${resistance_levels}

## 📝 Summary
${summary}

---
_Generated at ${timestamp} | Data source: CoinGecko, Alternative.me_
