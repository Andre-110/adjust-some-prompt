---
id: task_1300_text_parsing
name: Parse Novel Chapter into Audiobook Emotion Script
category: Data Analysis
grading_type: automated
difficulty: hard
timeout_seconds: 600
workspace_files:
- source: task_1300_text_parsing/data/novel_chapter.txt
  dest: data/novel_chapter.txt
- source: task_1300_text_parsing/data/character_profiles.json
  dest: data/character_profiles.json
- source: task_1300_text_parsing/data/emotion_labels.json
  dest: data/emotion_labels.json
- source: task_1300_text_parsing/config/output_format_spec.yaml
  dest: config/output_format_spec.yaml
- source: task_1300_text_parsing/config/delay_guidelines.md
  dest: config/delay_guidelines.md
- source: task_1300_text_parsing/examples/sample_output.json
  dest: examples/sample_output.json
- source: task_1300_text_parsing/examples/old_script_v1.json
  dest: examples/old_script_v1.json
- source: task_1300_text_parsing/data/chapter_metadata.json
  dest: data/chapter_metadata.json
- source: task_1300_text_parsing/data/audio_settings.yaml
  dest: data/audio_settings.yaml
- source: task_1300_text_parsing/config/speaker_alias_map.json
  dest: config/speaker_alias_map.json
- source: task_1300_text_parsing/logs/previous_run.log
  dest: logs/previous_run.log
source_query: '将下面提供的小说文本逐句转换为"有声书情绪脚本"的纯JSON数组。


  硬性要求：

  1) 只输出JSON数组（禁止任何解释文字），输出必须以 [ 开头、以 ] 结尾。

  2) 数组中每个对象只能包含以下四个字段：speaker（说话者）、speaker_emo（情感标签）、content（文本内容）、delay（停顿毫秒整数）。

  3) 旁白行：speaker=旁白，speaker_emo=中性。

  4) 角色对话：speaker为说话人姓名；若原文出现【姓名-无】或【姓名】等标记，只表示说话人是"姓名"，该标记本身不得出现在content中，且【姓名-无】与【姓名】视为同一人。

  5) 路人/网友/观'
source_line_number: 1300
subcategory: Text Parsing
---
## Prompt

We're producing an audiobook for a Chinese web novel series and I need your help converting a raw chapter text into a structured emotion script that our TTS pipeline can consume.

Please read the chapter in `data/novel_chapter.txt` and write the final result to `output/audiobook_script.json`.

Use the workspace references as needed:
- output schema: `config/output_format_spec.yaml`
- delay rules: `config/delay_guidelines.md`
- allowed emotion labels: `data/emotion_labels.json`
- character reference: `data/character_profiles.json`

There are also old artifacts and helper-looking files elsewhere in the workspace. They may be useful, outdated, or misleading. If references disagree, follow the authoritative schema/rules above and the source chapter itself.

Requirements:
- Output must be a single JSON array and nothing else.
- Each array item must contain exactly these four fields: `speaker`, `speaker_emo`, `content`, `delay`.
- `speaker_emo` must use only labels from `data/emotion_labels.json`.
- `delay` must be an integer in milliseconds.
- Process the full chapter, keeping all meaningful narration/dialogue lines while skipping blank lines and purely structural chapter title lines.
- Resolve speaker identity from the text itself. Some lines use leading tags, some use inline attribution, and some are pure narration.
- Clean speaker markers out of `content`, but do not accidentally remove bracketed text that belongs to the prose itself.
- The chapter includes fast exchanges, reflective pauses, scene-like transitions, and a few places where multiple cues in the same line could influence both emotion and delay. Use judgment rather than a single simplistic heuristic.

Write only the file `output/audiobook_script.json`.

## Expected Behavior

The agent should produce a complete JSON array in `output/audiobook_script.json` that faithfully converts the chapter into an audiobook emotion script.

Ground-truth parsing expectations used for evaluation:

1. **Structural coverage**
   - Skip the title line `第三章：裂痕` and blank lines.
   - Convert every remaining meaningful non-empty line into one output object.
   - For the current chapter asset, the correct total number of output entries is **27**.

2. **Speaker resolution**
   - Leading speaker tags at the start of a line determine speaker identity.
   - `【name-无】` and `【name】` resolve to the same base speaker name by removing the `-无` suffix.
   - Inline attribution of the form `苏晴说：` resolves speaker to `苏晴`, and the attribution prefix should be removed from `content`.
   - Lines with no valid speaker attribution are narration and must use `speaker = "旁白"`.
   - The embedded bracket text `【旧照片】` inside the 苏晴 line is part of the prose and must remain in `content`; it is not a speaker tag because it is not the leading attribution marker for that line.

3. **Exact speaker counts derived from the source**
   - `旁白`: 7 lines
   - `林远`: 8 lines
   - `苏晴`: 8 lines
   - `路人甲`: 2 lines
   - `网友A`: 2 lines
   - `网友B`: 1 line

4. **Representative content expectations**
   - A `苏晴` line must contain `她看着【旧照片】上两个人的笑脸，眼泪终于忍不住落了下来。"我们回不去了，是不是？"` with the inner `【旧照片】` preserved.
   - No `content` field may begin with a leading speaker tag such as `【林远】`, `【林远-无】`, `【苏晴】`, `【路人甲】`, `【网友A】`, `【网友B】`.
   - The inline attribution line `苏晴说："那……你保重。"` should become speaker `苏晴` with content `"那……你保重。"`.

5. **Emotion expectations for representative lines**
   These are used to distinguish shallow formatting from genuine interpretation:
   - `林远` line containing `解释？你还有什么好解释的！三年了，整整三年，你一直在骗我！` → expected `speaker_emo = "愤怒"`
   - `苏晴` line containing `事情不是你想的那样……` → expected `speaker_emo = "焦虑"`
   - `苏晴` line containing `我们回不去了，是不是？` → expected `speaker_emo = "悲伤"`
   - `网友A` line containing `被绿的可怜虫` → expected `speaker_emo = "讽刺"`
   - `网友B` line containing `哪有那么简单` → expected `speaker_emo = "坚定"`
   - `林远` line containing `我已经把公司的事情处理好了，明天的会议你不用来了。` → expected `speaker_emo = "冷漠"`
   - Any narration line (`speaker = "旁白"`) → expected `speaker_emo = "中性"`

6. **Delay expectations**
   Delay must be an integer and obey the guideline ranges based on the line text:
   - Lines ending with `！` should be in **300–500ms**
   - Lines ending with `？` should be in **400–600ms**
   - Lines ending with `……` should be in **1000–1500ms**
   - Narration/scene-transition style lines should use longer pauses; some representative narration lines are expected to be at least **1500ms**
   - When multiple cues apply, the longer-delay rule should win

7. **Format expectations**
   - The output must be valid JSON.
   - The top-level value must be an array.
   - Every element must be an object with exactly: `speaker`, `speaker_emo`, `content`, `delay`.
   - No extra keys such as `volume`.
   - No English narrator value such as `narrator`.
   - `delay` must be numeric integer, not a string like `"500ms"`.

## Grading Criteria

- [ ] Produce a valid JSON array at `output/audiobook_script.json`
- [ ] Output contains exactly 27 entries, matching all meaningful source lines after skipping title/blank lines
- [ ] Every item has exactly the required four fields and no extras
- [ ] Speaker resolution is correct across all lines, including `-无` normalization and inline attribution cleanup
- [ ] Per-speaker line counts match the source-derived ground truth
- [ ] All narration lines use `speaker="旁白"` and every narration line has `speaker_emo="中性"`
- [ ] Embedded prose bracket content such as `【旧照片】` is preserved correctly
- [ ] Representative high-signal emotion assignments match the intended reading of the chapter
- [ ] Delay values are integers and satisfy both global range rules and representative punctuation-specific constraints
- [ ] Output does not retain leading raw speaker tags inside `content`
- [ ] Strong performance requires not just structural validity, but correct handling of ambiguous bracket content, attribution cleanup, emotion choice, and delay tradeoffs

## Automated Checks

```python
import json
import re
from pathlib import Path
from collections import Counter

def grade(transcript: list, workspace_path: str) -> dict:
    result = {
        "output_file_exists": 0.0,
        "valid_json_array": 0.0,
        "entry_count_correct": 0.0,
        "has_four_required_fields": 0.0,
        "no_volume_field": 0.0,
        "no_english_narrator": 0.0,
        "speaker_counts_match": 0.0,
        "all_narrator_lines_neutral": 0.0,
        "lin_yuan_alias_normalized": 0.0,
        "inline_attribution_cleaned": 0.0,
        "no_raw_speaker_tags_in_content": 0.0,
        "embedded_bracket_preserved": 0.0,
        "emotion_representative_lines": 0.0,
        "delay_is_integer": 0.0,
        "delay_global_range": 0.0,
        "delay_punctuation_rules": 0.0,
        "narration_long_pause_rules": 0.0,
    }

    output_file = Path(workspace_path) / "output" / "audiobook_script.json"
    if not output_file.is_file():
        return result
    result["output_file_exists"] = 1.0

    try:
        raw_content = output_file.read_text(encoding="utf-8")
    except Exception:
        return result

    if not re.match(r"\s*\[", raw_content) or not re.search(r"\]\s*$", raw_content):
        return result

    try:
        data = json.loads(raw_content)
        if isinstance(data, list):
            result["valid_json_array"] = 1.0
        else:
            return result
    except Exception:
        return result

    if len(data) == 27:
        result["entry_count_correct"] = 1.0

    required_keys = {"speaker", "speaker_emo", "content", "delay"}
    all_four = True
    for entry in data:
        if not isinstance(entry, dict) or set(entry.keys()) != required_keys:
            all_four = False
            break
    if all_four and len(data) > 0:
        result["has_four_required_fields"] = 1.0

    if not re.search(r'"volume"\s*:', raw_content, re.IGNORECASE):
        result["no_volume_field"] = 1.0

    if not re.search(r'"speaker"\s*:\s*"narrator"', raw_content, re.IGNORECASE):
        result["no_english_narrator"] = 1.0

    speakers = [e.get("speaker") for e in data if isinstance(e, dict)]
    counts = Counter(speakers)
    expected_counts = {
        "旁白": 7,
        "林远": 8,
        "苏晴": 8,
        "路人甲": 2,
        "网友A": 2,
        "网友B": 1,
    }
    if counts == expected_counts:
        result["speaker_counts_match"] = 1.0

    narrator_entries = [e for e in data if isinstance(e, dict) and e.get("speaker") == "旁白"]
    if narrator_entries and all(e.get("speaker_emo") == "中性" for e in narrator_entries):
        result["all_narrator_lines_neutral"] = 1.0

    if (
        all(e.get("speaker") != "林小远" for e in data if isinstance(e, dict))
        and sum(
            1
            for e in data
            if isinstance(e, dict)
            and e.get("speaker") == "林远"
            and isinstance(e.get("content"), str)
            and (
                "解释？你还有什么好解释的！三年了，整整三年，你一直在骗我！" in e.get("content")
                or "别再提以前的事了。过去的就让它过去吧。" in e.get("content")
                or "你也是。" in e.get("content")
            )
        ) == 3
    ):
        result["lin_yuan_alias_normalized"] = 1.0

    inline_contents = [
        e for e in data
        if isinstance(e, dict)
        and e.get("speaker") == "苏晴"
        and isinstance(e.get("content"), str)
        and e.get("content") in {
            "\"我没有骗你，我只是……不知道该怎么告诉你真相。\"",
            "\"你撑着一把黑色的伞，站在书店门口等雨停。\"",
            "\"你是要把我从你的生活里彻底清除出去吗？\"",
            "\"那……你保重。\"",
        }
    ]
    if len(inline_contents) == 4 and all("苏晴说：" not in e.get("content", "") for e in inline_contents):
        result["inline_attribution_cleaned"] = 1.0

    tag_pattern = re.compile(r'^【(?:林远(?:-无)?|苏晴|路人甲|网友A|网友B)】')
    if all(
        isinstance(e, dict)
        and isinstance(e.get("content"), str)
        and not tag_pattern.match(e.get("content"))
        for e in data
    ):
        result["no_raw_speaker_tags_in_content"] = 1.0

    embedded_matches = [
        e for e in data
        if isinstance(e, dict)
        and e.get("speaker") == "苏晴"
        and isinstance(e.get("content"), str)
        and "【旧照片】" in e.get("content")
        and "我们回不去了，是不是？" in e.get("content")
    ]
    if len(embedded_matches) == 1:
        result["embedded_bracket_preserved"] = 1.0

    expected_emotions = [
        ("林远", "解释？你还有什么好解释的！三年了，整整三年，你一直在骗我！", "愤怒"),
        ("苏晴", "事情不是你想的那样……", "焦虑"),
        ("苏晴", "我们回不去了，是不是？", "悲伤"),
        ("网友A", "被绿的可怜虫", "讽刺"),
        ("网友B", "哪有那么简单", "坚定"),
        ("林远", "我已经把公司的事情处理好了，明天的会议你不用来了。", "冷漠"),
    ]
    emo_hits = 0
    for speaker, snippet, emo in expected_emotions:
        found = False
        for e in data:
            if (
                isinstance(e, dict)
                and e.get("speaker") == speaker
                and e.get("speaker_emo") == emo
                and isinstance(e.get("content"), str)
                and snippet in e.get("content")
            ):
                found = True
                break
        if found:
            emo_hits += 1
    narrator_ok = all(e.get("speaker_emo") == "中性" for e in narrator_entries) if narrator_entries else False
    if emo_hits == len(expected_emotions) and narrator_ok:
        result["emotion_representative_lines"] = 1.0

    delays = [e.get("delay") for e in data if isinstance(e, dict)]
    if delays and all(isinstance(d, int) for d in delays):
        result["delay_is_integer"] = 1.0

    if delays and all(isinstance(d, int) and 200 <= d <= 2000 for d in delays):
        result["delay_global_range"] = 1.0

    punctuation_checks = []

    def find_one(snippet):
        for e in data:
            if isinstance(e, dict) and isinstance(e.get("content"), str) and snippet in e.get("content"):
                return e
        return None

    exclaim_line = find_one("解释？你还有什么好解释的！三年了，整整三年，你一直在骗我！")
    question_line = find_one("你觉得呢？")
    ellipsis_line = find_one("那……你保重。")

    if exclaim_line is not None:
        punctuation_checks.append(
            isinstance(exclaim_line.get("delay"), int) and 300 <= exclaim_line.get("delay") <= 500
        )
    if question_line is not None:
        punctuation_checks.append(
            isinstance(question_line.get("delay"), int) and 400 <= question_line.get("delay") <= 600
        )
    if ellipsis_line is not None:
        punctuation_checks.append(
            isinstance(ellipsis_line.get("delay"), int) and 1000 <= ellipsis_line.get("delay") <= 1500
        )

    if len(punctuation_checks) == 3 and all(punctuation_checks):
        result["delay_punctuation_rules"] = 1.0

    narration_snippets = [
        "夜色笼罩着整座城市，霓虹灯的光芒在雨水中碎成一地斑斓。",
        "三月的风带着寒意穿过街道——行人匆匆低头赶路，没有人注意到天桥上那两个对峙的身影。",
        "城市的喧嚣渐渐远去，只剩下雨水敲打栏杆的声音。",
    ]
    narration_hits = 0
    for snippet in narration_snippets:
        entry = find_one(snippet)
        if (
            entry is not None
            and entry.get("speaker") == "旁白"
            and isinstance(entry.get("delay"), int)
            and entry.get("delay") >= 1500
        ):
            narration_hits += 1
    if narration_hits == len(narration_snippets):
        result["narration_long_pause_rules"] = 1.0

    return result
```

## LLM Judge Rubric

Although the task is scored automatically, use the following rubric if manual review is needed for borderline outputs.

### Dimension 1: Speaker Resolution & Content Cleaning
- **1.0**: Correctly resolves all speaker lines, including `-无` normalization, inline `苏晴说：` attribution cleanup, and preservation of non-speaker bracketed prose like `【旧照片】`.
- **0.75**: One minor attribution or cleanup mistake, but the overall mapping is reliable and no major character is systematically wrong.
- **0.5**: Multiple attribution/cleanup mistakes, or one systematic issue affecting a subset of lines.
- **0.25**: Frequent speaker confusion, raw tags left in content, or bracket content mishandled.
- **0.0**: Output largely fails to distinguish speakers from narration.

### Dimension 2: Emotion Assignment Quality
- **1.0**: Emotions are consistently well-judged and context-sensitive; anger, sorrow, sarcasm, firmness, anxiety, and neutral narration are all assigned appropriately on representative lines.
- **0.75**: Mostly appropriate emotions, with 1–2 debatable assignments that do not flatten the chapter’s emotional arc.
- **0.5**: Several generic or weak choices (e.g., overusing `中性`/`冷漠`) that miss important emotional cues.
- **0.25**: Emotions are often implausible or nearly uniform across very different lines.
- **0.0**: Emotion labels are arbitrary, invalid, or ignore the source tone.

### Dimension 3: Delay Reasoning
- **1.0**: Delay values clearly reflect punctuation and scene rhythm, including longer pauses for ellipsis and narration/transition beats, shorter pauses for exclamatory exchanges, and correct longer-rule precedence when cues conflict.
- **0.75**: Mostly good delay choices with small inconsistencies that do not indicate a broken heuristic.
- **0.5**: Delays are in range but feel generic; punctuation-specific intent is only partially reflected.
- **0.25**: Delays appear mostly uniform or frequently contradict the guideline categories.
- **0.0**: Delay values are invalid, non-integer, or unrelated to the source.

### Dimension 4: Coverage & Structural Validity
- **1.0**: Valid JSON array, exact schema, no extra fields, and complete chapter coverage with no meaningful omissions.
- **0.75**: Structure is valid, with at most one minor omission or formatting issue.
- **0.5**: Partially correct structure but missing several lines or containing avoidable schema mistakes.
- **0.25**: Significant omissions or malformed structure that weakens downstream usability.
- **0.0**: Not usable as the requested deliverable.
