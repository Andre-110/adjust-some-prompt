# Delay Assignment Guidelines for Audiobook Script

## Overview

Delay values represent the pause (in milliseconds) **after** each line is spoken,
before the next line begins. All delay values must be **integers** within the
range of 200–2000ms.

## Rules by Punctuation / Context

### 1. Paragraph Breaks (Narration paragraphs)
- **Delay: 1500–2000ms**
- Narration paragraphs that describe scenes, atmosphere, or transitions should
  have longer pauses to let the listener absorb the imagery.

### 2. Sentence Ending with Period (。)
- **Delay: 500–800ms**
- Standard declarative sentences. Use the lower end (500ms) for rapid dialogue
  exchanges and the higher end (800ms) for slower, reflective statements.

### 3. Sentence Ending with Exclamation Mark (！)
- **Delay: 300–500ms**
- Exclamatory sentences convey urgency or strong emotion. Shorter pauses
  maintain the intensity and momentum.

### 4. Sentence Ending with Question Mark (？)
- **Delay: 400–600ms**
- Questions naturally create anticipation for a response. Use moderate pauses.

### 5. Sentence Ending with Ellipsis (……)
- **Delay: 1000–1500ms**
- Ellipses indicate trailing off, hesitation, or unfinished thoughts. Longer
  pauses help convey the emotional weight.

### 6. Em-Dash Mid-Sentence (——)
- **Delay: 800–1200ms**
- When a narration line contains an em-dash, the overall line delay should
  reflect the dramatic pause implied by the dash.

### 7. Scene Transitions
- **Delay: 2000ms**
- When the setting or time clearly shifts between consecutive lines, use the
  maximum delay to signal the transition to the listener.

## Important Notes

- All delay values must be **plain integers** (e.g., `500`), not strings (e.g., `"500ms"`).
- When multiple rules apply, use the rule that produces the **longer** delay.
- Delay values outside the 200–2000 range are invalid.
