# Character Reference Sheet

## Grand Meridian Hotel — Cast

| Character | Role | First Appearance | Status |
|-----------|------|-----------------|--------|
| Louis Liu (路易斯刘) | Hotel Owner | Chapter 1 | Active |
| Chen Mo (陈墨) | Investor | Chapter 3 | Active |
| Detective Fang | Lead Investigator | Chapter 2 | Active |
| Mei Zhao | Front Desk Manager | Chapter 1 | Active |
| Old Zhang | Night Security | Chapter 4 | Minor |
| Secretary Wang | Liu's assistant | Chapter 1 | Active |

## Unresolved Questions

- Are Louis Liu and Chen Mo the same person?
- What is Chen Mo's real relationship to the hotel?
- Who sent the anonymous letter in Chapter 4?

## Personality Notes

- **Louis Liu**: Charming, calculated, always in control. Speaks softly. Wears expensive but understated suits.
- **Chen Mo**: Rarely seen in person. Communicates through intermediaries. Known for large cash investments.
- **Detective Fang**: Chain smoker, divorced, lives alone. Brilliant but self-destructive.
- **Mei Zhao**: Quiet, observant. Keeps a personal journal (plot device).
