# WORKFLOW_AUTO.md — Automated Workflow Protocols

## Memory Management

- Always check `memory/` directory for today's date file on startup
- Append new entries with timestamps; never overwrite existing content
- Use H2 headers (`##`) to separate entries by time block
- When merging character notes, update both daily log and character-notes.md

## Session Recovery

After context compaction:
1. Re-read WORKFLOW_AUTO.md (this file)
2. Re-read the latest memory/YYYY-MM-DD.md file
3. Resume from where you left off

## Writing Project Conventions

- Character names: use English name with Chinese in parentheses on first mention
- Chapter references: use "Chapter N" format
- Plot decisions: log in daily memory file with rationale
