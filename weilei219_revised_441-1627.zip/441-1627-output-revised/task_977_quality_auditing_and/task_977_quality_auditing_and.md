---
id: task_977_quality_auditing_and
name: Second-Round QA Audit of Math Question 212432
category: Data Analysis
grading_type: hybrid
difficulty: hard
timeout_seconds: 600
workspace_files:
- source: task_977_quality_auditing_and/data/questions/question_212432.json
  dest: data/questions/question_212432.json
- source: task_977_quality_auditing_and/data/questions/question_212432_metadata.json
  dest: data/questions/question_212432_metadata.json
- source: task_977_quality_auditing_and/data/questions/question_212432_review_v1.json
  dest: data/questions/question_212432_review_v1.json
- source: task_977_quality_auditing_and/data/svg_rendering/svg_guidelines.md
  dest: data/svg_rendering/svg_guidelines.md
- source: task_977_quality_auditing_and/data/qa_checklist/qa_checklist_v3.json
  dest: data/qa_checklist/qa_checklist_v3.json
- source: task_977_quality_auditing_and/data/questions/batch_review_log.csv
  dest: data/questions/batch_review_log.csv
- source: task_977_quality_auditing_and/data/questions/question_212431.json
  dest: data/questions/question_212431.json
- source: task_977_quality_auditing_and/data/questions/question_212433.json
  dest: data/questions/question_212433.json
- source: task_977_quality_auditing_and/data/svg_rendering/known_svg_issues.csv
  dest: data/svg_rendering/known_svg_issues.csv
- source: task_977_quality_auditing_and/config/qa_policy.yaml
  dest: config/qa_policy.yaml
- source: task_977_quality_auditing_and/data/grid_spec.json
  dest: data/grid_spec.json
- source: task_977_quality_auditing_and/reports/qa_report_template.md
  dest: reports/qa_report_template.md
grading_weights:
  automated: 0.55
  llm_judge: 0.45
source_query: 对小学数学题（question_id=212432，含选项、标注答案、SVG与解析）进行二次质检：按"题干完整性、选项完整性/重复、答案正确性、解析一致性、SVG清晰度/无歧义/与题干一致性/是否泄露关键信息"逐项检查，并判断该题是否为真正错题（不确定则判为错题）。题目数据：选项A='A图'，B='B图'，C='C图'，D='D图'；标注答案=C；SVG：<svg
  width='400' height='200' xmlns='http://www.w3.org/2000/svg'><rect width='400' height='200'
  fill='#f0f0f0' stroke='#c
source_line_number: 977
subcategory: Quality Auditing and Diagnostics
---
## Prompt

We had a first-round review of question 212432 back in January that came back clean, but our QA lead isn't confident it was thorough enough — especially around the SVG content. She's asked me to get a proper second-round audit done before this question goes into the live question bank.

Everything you need is in the workspace. The primary question record is in `data/questions/question_212432.json`, there's metadata in the companion metadata file, and the first reviewer's notes are in `question_212432_review_v1.json`. We also have our SVG quality guidelines (`data/svg_rendering/svg_guidelines.md`), a known SVG issues log (`data/svg_rendering/known_svg_issues.csv`), the official QA checklist v3 (`data/qa_checklist/qa_checklist_v3.json`), grid specifications (`data/grid_spec.json`), QA policy config (`config/qa_policy.yaml`), and a batch review log in CSV form. There's also a report template in `reports/`.

What I need from you: go through every item on the QA checklist v3 systematically. Actually parse the SVG content in the question JSON — don't just trust the first reviewer's notes. Cross-reference data across files where relevant and flag any inconsistencies you find between sources. Check whether the geometric transformation depicted in the SVG is mathematically correct given the grid spec. If you find issues, classify them by severity per the checklist.

Write your full audit report to `qa_report_212432.md`. It should include: a summary of findings, the checklist results item by item (QA01 through QA09), any data inconsistencies across files, your overall verdict on whether this is an error question, and specific remediation recommendations. Be explicit about what's wrong and cite the exact file paths and values where you found problems.

## Expected Behavior

The agent must perform a thorough second-round quality audit of question 212432 by examining all relevant workspace files, cross-referencing data, and producing a comprehensive report. The correct solution involves identifying multiple issues:

**Trap 1 — Data Inconsistency Between Primary JSON and Batch Review Log:**
The primary question record `data/questions/question_212432.json` has `labeled_answer: "C"`. However, `data/questions/batch_review_log.csv` contains a row for question_id 212432 that lists `labeled_answer` as `"A"`. The agent must identify this contradiction, recognize the primary JSON (`question_212432.json`) as the authoritative source per the data source priority defined in `config/qa_policy.yaml`, and flag this inconsistency as a data integrity issue that needs resolution. The correct labeled answer is "C" per the primary record.

**Trap 2 — SVG Answer Leakage Missed by First Reviewer:**
The SVG content in `data/questions/question_212432.json` contains the element `<text x="10" y="190" font-size="10">答案:C</text>` which literally displays "Answer: C" at the bottom of the SVG image. This is a critical violation per `data/svg_rendering/svg_guidelines.md` (Section 2: No Answer Leakage). The first reviewer's notes in `data/questions/question_212432_review_v1.json` explicitly state "SVG清晰无歧义" (SVG clear and unambiguous) and "无问题" (No issues) — completely missing this critical answer leak. The agent must actually parse the SVG XML content rather than trusting the prior review, identify the leaking text element, and flag it as a critical severity issue per checklist item QA08.

**Trap 3 — Grid Specification Ambiguity Affecting Translation Verification:**
The `data/grid_spec.json` file contains both a current grid unit value of 30px and a deprecated/legacy value of 20px. The agent must use the correct current value (30px per grid unit) to verify whether the SVG figures are positioned correctly. With 30px per unit, translating 3 units right means a 90px shift. The original figure is at x=30, so the correct translated position should be at x=120. The C图 rectangle is at x=120, confirming C is correct. However, option A图's rectangle is at x=140, y=80 — not only is the x-position wrong (140 ≠ 120), but the y-position has also shifted from y=50 to y=80, meaning it depicts a diagonal move rather than a pure horizontal translation. The agent should flag that A図 might cause confusion since its x-position (140) could be misinterpreted as approximately correct if a student uses the deprecated 20px grid (3 × 20 = 60, so 30 + 60 = 90, which doesn't match x=140 either), and note that the explanation doesn't address why A is wrong.

**Trap 4 — Missing D图 Figure in SVG:**
The SVG contains labeled figures for 原图 (original), A图, B图, and C图, but no rectangle element corresponding to D图. While option D="D图" exists in the question options, the SVG does not render any figure for it. This is a completeness issue that should be flagged under QA02 (option completeness) or QA05 (SVG clarity).

**Additional Expected Findings:**
- The explanation in the question JSON says C is correct but doesn't explain why other options (particularly A) are incorrect, which is a gap in explanation quality (QA04).
- B図 has different dimensions (40×60 vs 40×40), correctly making it wrong as the shape changes, but this should be explicitly noted.
- The overall verdict (QA09) should be that this IS an error question due to the critical SVG answer leak, and it needs revision before going live.

The output file `qa_report_212432.md` should follow the template structure from `reports/qa_report_template.md` and include all checklist items QA01–QA09 with findings, the data inconsistency flag, severity classifications, and remediation steps.

## Grading Criteria

- [ ] The report correctly identifies the SVG answer leakage — the `<text x="10" y="190">答案:C</text>` element that reveals the correct answer — and classifies it as a critical severity issue.
- [ ] The report identifies the data inconsistency between `data/questions/question_212432.json` (labeled_answer="C") and `data/questions/batch_review_log.csv` (labeled_answer="A") for question 212432.
- [ ] The report explicitly notes that the first reviewer's assessment in `question_212432_review_v1.json` was incorrect in claiming the SVG had no issues.
- [ ] The report uses the correct current grid unit size (30px) from `data/grid_spec.json` (not the deprecated 20px value) when verifying the geometric translation.
- [ ] The report verifies the mathematical correctness of the translation: original at x=30, C図 at x=120, confirming a 90px (3 × 30px) rightward shift makes C the correct answer.
- [ ] The report addresses potential issues with option A (x=140, y=80 — incorrect x-position and shifted y-position compared to the original at x=30, y=50) and flags concerns under QA06 (svg_no_ambiguity) or QA07 (svg_stem_consistency).
- [ ] The report covers all nine QA checklist items (QA01 through QA09) with individual findings for each.
- [ ] The overall verdict (QA09) correctly concludes that question 212432 is an error question that requires revision, primarily due to the SVG answer leak.
- [ ] The report includes specific, actionable remediation recommendations (e.g., remove the answer text element from SVG, resolve the batch log inconsistency, improve the explanation).
- [ ] The report is saved to the correct output path `qa_report_212432.md` and is well-structured with clear sections.

## Automated Checks

```python
import os
import re
from pathlib import Path

def grade(transcript: list, workspace_path: str) -> dict:
    """Grade the QA audit report for question 212432."""
    
    output_file = os.path.join(workspace_path, "qa_report_212432.md")
    
    # Initialize all scores to 0.0
    result = {
        "output_file_exists": 0.0,
        "question_id_present": 0.0,
        "answer_leak_detected": 0.0,
        "svg_leak_detail": 0.0,
        "labeled_answer_contradiction": 0.0,
        "verdict_is_error": 0.0,
        "checklist_section_exists": 0.0,
        "svg_analysis_section": 0.0,
        "stem_completeness_checked": 0.0,
        "option_check_performed": 0.0,
        "no_false_pass_verdict": 0.0,
        "grid_spec_awareness": 0.0,
        "ambiguity_flagged": 0.0,
    }
    
    # Check file existence
    if not os.path.isfile(output_file):
        return result
    
    result["output_file_exists"] = 1.0
    
    try:
        with open(output_file, "r", encoding="utf-8") as f:
            content = f.read()
    except Exception:
        return result
    
    content_lower = content.lower()
    
    # --- question_id_present ---
    if re.search(r'\b212432\b', content):
        result["question_id_present"] = 1.0
    
    # --- answer_leak_detected ---
    leak_patterns = [
        r'answer\s*leak',
        r'leak\w*\s+\w*\s*answer',
        r'答案\s*泄[露漏]',
        r'泄[露漏]\s*答案',
        r'answer\s*leakage',
        r'leaks?\s+the\s+(correct\s+)?answer',
        r'reveals?\s+the\s+(correct\s+)?answer',
        r'discloses?\s+the\s+(correct\s+)?answer',
        r'exposes?\s+the\s+(correct\s+)?answer',
    ]
    for pat in leak_patterns:
        if re.search(pat, content, re.IGNORECASE):
            result["answer_leak_detected"] = 1.0
            break
    
    # --- svg_leak_detail ---
    # Report specifically mentions the leaked answer text in the SVG
    svg_leak_patterns = [
        r'答案.{0,5}C',
        r'answer.{0,15}(text|element|label|leak)',
        r'<text.{0,80}答案',
        r'x\s*=\s*"?10.{0,30}y\s*=\s*"?190',
        r'font.size.{0,10}10.{0,30}答案',
    ]
    for pat in svg_leak_patterns:
        if re.search(pat, content, re.IGNORECASE):
            result["svg_leak_detail"] = 1.0
            break
    
    # --- labeled_answer_contradiction ---
    # Check that the report mentions both the batch_review_log AND some form of
    # contradiction/inconsistency/discrepancy/mismatch
    has_batch_log = bool(re.search(r'batch.?review.?log', content, re.IGNORECASE))
    contradiction_words = [
        r'contradict', r'inconsisten', r'discrepan', r'mismatch', r'conflict',
        r'differ(?:s|ent|ence)', r'disagree', r'不一致', r'矛盾',
    ]
    has_contradiction = False
    for pat in contradiction_words:
        if re.search(pat, content, re.IGNORECASE):
            has_contradiction = True
            break
    if has_batch_log and has_contradiction:
        result["labeled_answer_contradiction"] = 1.0
    
    # --- verdict_is_error ---
    verdict_patterns = [
        r'is.?error.{0,20}(yes|true)',
        r'error.question.{0,20}(yes|true)',
        r'verdict.{0,40}error',
        r'判定.{0,10}错题',
        r'marked?.{0,15}error',
        r'(is|constitutes|classified\s+as)\s+(an?\s+)?error\s+question',
        r'this\s+(question\s+)?is\s+(an?\s+)?error',
        r'should\s+be\s+(flagged|marked|classified)\s+(as\s+)?(an?\s+)?error',
        r'error\s+question.{0,10}\|\s*yes',
        r'is\s+error\s+question.{0,10}yes',
        r'错题',
    ]
    for pat in verdict_patterns:
        if re.search(pat, content, re.IGNORECASE):
            result["verdict_is_error"] = 1.0
            break
    
    # --- checklist_section_exists ---
    # Check for markdown heading containing "Checklist" or presence of QA01-QA09 items
    if re.search(r'(?m)^#{1,4}\s+.*[Cc]hecklist', content):
        result["checklist_section_exists"] = 1.0
    elif re.search(r'QA01', content) and re.search(r'QA09', content):
        result["checklist_section_exists"] = 1.0
    
    # --- svg_analysis_section ---
    if re.search(r'(?m)^#{1,4}\s+.*SVG', content, re.IGNORECASE):
        result["svg_analysis_section"] = 1.0
    elif re.search(r'(?i)svg\s*(analysis|分析|inspection|review|check)', content):
        result["svg_analysis_section"] = 1.0
    
    # --- stem_completeness_checked ---
    stem_patterns = [
        r'stem.{0,20}(complete|completeness|intact)',
        r'题干.{0,10}(完整|检查)',
        r'QA01',
        r'stem_completeness',
    ]
    for pat in stem_patterns:
        if re.search(pat, content, re.IGNORECASE):
            result["stem_completeness_checked"] = 1.0
            break
    
    # --- option_check_performed ---
    option_patterns = [
        r'option.{0,20}(complete|completeness|duplicate|repeat|missing)',
        r'选项.{0,10}(完整|重复|缺)',
        r'QA02',
        r'option_completeness',
    ]
    for pat in option_patterns:
        if re.search(pat, content, re.IGNORECASE):
            result["option_check_performed"] = 1.0
            break
    
    # --- no_false_pass_verdict ---
    # Score 1.0 when "is_error_question: no" is NOT in the content
    if re.search(r'is.?error.?question.{0,5}no', content_lower):
        result["no_false_pass_verdict"] = 0.0
    else:
        result["no_false_pass_verdict"] = 1.0
    
    # --- grid_spec_awareness ---
    grid_patterns = [
        r'grid.{0,15}(unit|spec|pixel|px)',
        r'30\s*px',
        r'pixel.{0,10}(unit|grid)',
        r'grid_unit_px',
    ]
    for pat in grid_patterns:
        if re.search(pat, content, re.IGNORECASE):
            result["grid_spec_awareness"] = 1.0
            break
    
    # --- ambiguity_flagged ---
    ambiguity_patterns = [
        r'ambigu',
        r'unclear',
        r'not.{0,10}distinct',
        r'歧义',
        r'模糊',
        r'confus',
    ]
    for pat in ambiguity_patterns:
        if re.search(pat, content, re.IGNORECASE):
            result["ambiguity_flagged"] = 1.0
            break
    
    return result
```

## LLM Judge Rubric

### Criterion 1: Depth and Rigor of SVG Content Analysis (Weight: 35%)
**Score 1.0**: The agent demonstrates genuine parsing of the SVG XML content, quoting specific elements (coordinates, attributes, text nodes) directly from the source rather than paraphrasing the first reviewer. The analysis explains *why* the leaked text element is problematic (e.g., referencing the SVG guidelines section, explaining the impact on test integrity), and the agent explicitly contrasts its own findings against the first reviewer's "无问题" assessment with a clear rationale for overriding it. The mathematical verification of the geometric transformation uses concrete pixel values extracted from the SVG and shows step-by-step reasoning.
**Score 0.75**: The agent parses the SVG content and identifies key elements with some direct quoting, explains the significance of the answer leak, and notes the first reviewer's oversight. The geometric verification is present but may lack one step or minor detail in the calculation chain.
**Score 0.5**: The agent identifies the answer leak and mentions SVG parsing but provides limited direct evidence from the XML. The geometric verification is superficial or partially incorrect. The critique of the first reviewer is present but lacks depth or specificity.
**Score 0.25**: The agent mentions SVG issues in general terms without demonstrating actual parsing of the XML structure. The geometric analysis is missing or clearly wrong. The first reviewer's notes are referenced but not critically evaluated.
**Score 0.0**: The agent either trusts the first reviewer's assessment without independent verification, fails to engage with the SVG content meaningfully, or fabricates SVG details not present in the source files.

### Criterion 2: Cross-Referencing Quality and Contradiction Resolution (Weight: 35%)
**Score 1.0**: The agent systematically cross-references data across multiple files (primary JSON, batch log, metadata, review notes, grid spec, SVG guidelines, known issues log), explicitly identifies all contradictions and inconsistencies, provides clear reasoning for which source is authoritative in each case (citing the QA policy or data hierarchy), and explains the implications of each discrepancy (e.g., what would happen if the wrong labeled answer or wrong grid unit were used). The grid spec ambiguity between current (30px) and deprecated (20px) values is identified and the agent explains how the choice affects the correctness judgment.
**Score 0.75**: The agent cross-references most relevant files, identifies the key contradictions (labeled answer mismatch, grid spec ambiguity), and provides reasonable justification for source authority. Minor files may be underutilized or one implication may be incompletely explored.
**Score 0.5**: The agent identifies at least two of the three traps and attempts cross-referencing, but the reasoning for source authority is weak or assumed rather than justified. Some files are not consulted or their relevance is not explained.
**Score 0.25**: The agent identifies one contradiction but fails to cross-reference systematically. Source authority is asserted without justification. Most files are treated in isolation rather than compared.
**Score 0.0**: The agent fails to cross-reference files, misses major contradictions, or draws conclusions from a single source without checking others.

### Criterion 3: Professional Report Quality and Actionability (Weight: 30%)
**Score 1.0**: The report is well-structured with clear sections (summary, detailed findings, checklist results, severity classifications, recommendations), uses precise language, correctly classifies issue severities with justification tied to the QA checklist definitions, provides actionable remediation steps for each issue found (e.g., "remove the text element at line X," "reconcile batch log entry"), and the final verdict logically follows from the accumulated evidence. The tone is professional and appropriate for a QA audit document.
**Score 0.75**: The report is well-organized with most expected sections, severity classifications are present and mostly justified, remediation steps are provided for major issues, and the verdict is consistent with findings. Minor structural or clarity issues exist.
**Score 0.5**: The report has a recognizable structure but some sections are thin or missing. Severity classifications exist but lack clear justification. Recommendations are generic rather than specific. The verdict is present and directionally correct but not strongly supported by the preceding analysis.
**Score 0.25**: The report is poorly organized, missing key sections, or reads more like a stream of consciousness than a formal audit. Severity classifications are absent or arbitrary. Recommendations are vague or missing. The verdict may be present but is not well-supported.
**Score 0.0**: The report is incoherent, missing a verdict, or so poorly structured that it would not be usable as a QA document. Conclusions contradict the evidence presented, or the report contains significant hallucinated content not grounded in the source files.
```