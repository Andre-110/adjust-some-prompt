# QA Audit Report

**Report ID:** [AUTO-GENERATED]  
**Auditor:** [AUDITOR_ID]  
**Date:** [AUDIT_DATE]  

---

## Question Info

| Field | Value |
|---|---|
| Question ID | [QUESTION_ID] |
| Subject | [SUBJECT] |
| Grade | [GRADE] |
| Difficulty | [DIFFICULTY_RATING] |
| Author | [AUTHOR_ID] |
| Created | [CREATED_AT] |
| First Review | [FIRST_REVIEW_STATUS] on [FIRST_REVIEW_DATE] |

---

## Checklist Results

| Check Item | ID | Severity | Status | Details |
|---|---|---|---|---|
| Stem Completeness | QA01 | Critical | [PASS/FAIL] | [Details] |
| Option Completeness | QA02 | Critical | [PASS/FAIL] | [Details] |
| Answer Correctness | QA03 | Critical | [PASS/FAIL] | [Details] |
| Explanation Consistency | QA04 | Major | [PASS/FAIL] | [Details] |
| SVG Clarity | QA05 | Major | [PASS/FAIL] | [Details] |
| SVG No Ambiguity | QA06 | Critical | [PASS/FAIL] | [Details] |
| SVG-Stem Consistency | QA07 | Critical | [PASS/FAIL] | [Details] |
| SVG No Answer Leak | QA08 | Critical | [PASS/FAIL] | [Details] |
| Overall Verdict | QA09 | Critical | [PASS/FAIL] | [Details] |

---

## Issues Found

1. [Issue description, severity, and affected checklist item]
2. [Issue description, severity, and affected checklist item]
3. ...

---

## SVG Analysis

### Clarity
[Assessment of SVG rendering clarity, font sizes, contrast, label placement]

### Ambiguity
[Assessment of whether option figures are clearly distinct. Analyze positions, sizes, and shapes of each option figure relative to the original.]

### Consistency with Stem
[Verify that the SVG figures match the transformation described in the stem. Use grid_spec.json to convert pixel positions to grid units.]

### Answer Leakage
[Inspect all SVG elements for any text, annotation, or visual cue that reveals the correct answer. List any `<text>` elements and their content.]

---

## Data Consistency Check

[Cross-reference the labeled answer across all data sources: primary question JSON, batch review log, reviewer notes. Flag any discrepancies.]

---

## Verdict

| Field | Value |
|---|---|
| Is Error Question | [yes/no] |
| Confidence | [high/medium/low] |
| Critical Issues Count | [N] |
| Major Issues Count | [N] |
| Minor Issues Count | [N] |

**Reasoning:**  
[Detailed explanation of the verdict, referencing specific checklist items and issues found.]

---

## Recommendations

1. [Specific recommendation for fixing or handling the question]
2. [Additional recommendations]
3. ...
