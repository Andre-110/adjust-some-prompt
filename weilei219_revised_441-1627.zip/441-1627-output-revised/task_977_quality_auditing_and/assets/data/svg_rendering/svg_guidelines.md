# SVG Quality Guidelines for Math Questions

**Version:** 2.4  
**Last Updated:** 2023-12-01  
**Applies to:** All math questions containing SVG figures

---

## 1. SVG Clarity Requirements

All SVG figures used in math questions must meet the following clarity standards:

- **Font Size:** All text labels must use a minimum font size of **10px**. Recommended size is 12px for primary labels and 10px for secondary annotations.
- **Contrast:** Text must have sufficient contrast against the background. Dark text (#333 or darker) on light backgrounds (#f0f0f0 or lighter) is required.
- **Label Placement:** Labels must not overlap with figures or other labels. Each option figure must have its label clearly positioned above or beside it.
- **Dimensions:** SVG canvas must be large enough to display all figures without crowding. Minimum recommended size is 300x150 for 4-option questions.
- **Stroke Width:** All figure outlines must have a stroke width of at least **1px**.

## 2. No Answer Leakage

**CRITICAL RULE:** The SVG must **NOT** contain any text, visual cue, annotation, or metadata element that reveals the correct answer.

Violations include but are not limited to:
- Any `<text>` element that contains the answer letter (e.g., "答案:C", "Answer: B")
- Checkmarks, stars, or highlighting on the correct option figure
- Color differences that single out the correct answer (e.g., correct option in green, others in blue)
- Hidden or small text that encodes the answer
- SVG comments (`<!-- -->`) containing answer information
- Different stroke widths or styles that emphasize the correct option

**Any SVG containing answer leakage is a CRITICAL violation and the question must be immediately flagged as an error question.**

## 3. Consistency with Stem

The SVG figures must accurately represent what the question stem describes:

- **Transformation Questions:** If the stem asks about translation, rotation, or reflection, the SVG must show the original figure and option figures that correspond to the described transformation parameters (direction, distance, angle, axis).
- **Grid Units:** When the stem references grid units, the SVG must use the current grid specification (see `grid_spec.json`). Each grid unit corresponds to the defined pixel value. Figures must be positioned at exact grid-unit boundaries.
- **Measurements:** Any measurements shown in the SVG must match those stated in the stem.

## 4. No Ambiguity

Each option figure in the SVG must be **clearly distinguishable** from all other option figures:

- No two option figures should be visually identical or near-identical.
- No two option figures should both satisfy the conditions described in the question stem. If multiple figures could be considered correct answers, the question is **ambiguous** and must be flagged.
- Each figure must differ in at least one clearly visible attribute (position, size, shape, or orientation) that is relevant to the question.

**If ambiguity is detected, the question must be flagged as an error question regardless of other factors.**

## 5. Accessibility

SVG figures must be accessible to all students:

- **Stroke Widths:** Minimum 1px for all visible strokes. Recommended 2px for primary figure outlines.
- **Color Independence:** Color must not be the sole means of distinguishing between figures. Shape, position, size, or labels must also differentiate them.
- **Alt Text:** Where supported by the rendering platform, include descriptive alt text for the SVG.
- **High Contrast Mode:** Figures should remain distinguishable when rendered in high-contrast or grayscale modes.

---

## Appendix: Common SVG Issues

| Issue Type | Severity | Description |
|---|---|---|
| Answer leak via text element | Critical | SVG contains text revealing the answer |
| Figure ambiguity | Critical | Two or more option figures could be correct |
| Missing label | Major | An option figure is not labeled |
| Wrong dimensions | Major | Figure dimensions don't match stem |
| Color-only distinction | Major | Figures differ only by color |
| Overlapping elements | Minor | Labels or figures overlap |
| Low contrast | Minor | Text or figures hard to read |
