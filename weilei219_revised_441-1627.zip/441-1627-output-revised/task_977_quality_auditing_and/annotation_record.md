| 序号 | 修改项 | 修改原因 |
|------|--------|----------|
| 1 | grade() 函数 `labeled_answer_contradiction` 检查逻辑 | 原逻辑要求 "contradict" 和 "batch_review_log" 在同一段落中同时出现，但 agent 完全可能使用 "inconsistency"/"discrepancy"/"mismatch"/"conflict" 等同义词描述矛盾，且可能在不同段落分别提及批量日志和矛盾。这导致格式容忍度不足，合理的正确报告会被错误扣分。扩展匹配词并放宽为全文搜索。 |
| 2 | grade() 函数 `verdict_is_error` 检查逻辑 | 原正则非常狭窄，要求特定紧邻格式如 "is_error...yes" 或 "verdict...error"。但 agent 可能写 "this question should be classified as an error question"、"verdict: this is an error question"、"Is Error Question \| yes" 等多种表述。放宽正则以覆盖更多合理变体。 |
| 3 | grade() 函数 `svg_leak_detail` 检查逻辑 | 原正则 `答案.?C` 要求"答案"和"C"之间最多1个字符，但 agent 引用时可能写 `答案: C`（有空格）或 `答案:C` 或反引号包裹等。同时英文侧也过于局限。放宽匹配。 |
| 4 | grade() 函数 `checklist_section_exists` 检查逻辑 | 原正则要求 markdown 标题中含 "Checklist"，但 agent 也可能用 "QA Checklist" 或 "Checklist Results" 或编号如 "QA01" 作为节标题。增加对 QA01-QA09 列表存在性的检测作为备选。 |
| 5 | grade() 函数 `svg_analysis_section` 检查逻辑 | 增加对 "SVG Analysis" 等小写变体以及中文"SVG分析"的匹配，原正则已有 IGNORECASE flag 但限制了标题格式。放宽为也接受正文中有实质性 SVG 分析段落。 |
| 6 | grade() 函数 `stem_completeness_checked` 检查逻辑 | 增加 "QA01" 作为替代匹配项，因为 agent 按 checklist 编号报告时可能不再重复 "stem completeness" 字样。 |
| 7 | grade() 函数 `option_check_performed` 检查逻辑 | 同上，增加 "QA02" 作为替代匹配项。 |
| 8 | Expected Behavior 中关于 A图 位置的分析补充说明 | 原文说"A図 at x=140 is close enough to potentially confuse students"，但 x=140 与 x=120 差距为 20px，在 400px 宽的 SVG 中视觉上是明显可区分的。更准确地说，歧义在于 A图 的 y 坐标偏移（y=80 而非 y=50）——这使得 A 既有 x 偏移又有 y 偏移，而题目只要求水平平移。补充说明歧义的实际来源更准确。 |
| 9 | Expected Behavior 中补充 D图 缺失的说明 | SVG 中只有原图、A图、B图、C图的图形元素，没有 D图 的矩形元素。选项 D 存在但 SVG 中无对应图形，这是一个 QA02/QA05 级别的问题（选项完整性/SVG 完整性），Expected Behavior 中应提及。 |
| 10 | Grading Criteria 微调措辞 | 第 6 条关于 ambiguity 的描述更精确地反映实际 SVG 数据。 |