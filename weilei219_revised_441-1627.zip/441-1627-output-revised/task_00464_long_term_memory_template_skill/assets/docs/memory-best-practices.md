# Memory Management Best Practices

## Principles

1. **Keep it concise** — Memory files are loaded into context every session. Every line costs tokens.
2. **Update, don't append** — Replace outdated info rather than adding "UPDATE:" lines.
3. **Separate daily from long-term** — Use `memory/YYYY-MM-DD.md` for raw logs, `MEMORY.md` for curated insights.
4. **Review periodically** — Every few days, distill daily notes into MEMORY.md and prune stale entries.
5. **No secrets** — Avoid storing API keys, passwords, or sensitive credentials in memory files.

## Section Guidelines

| Section | Update Frequency | Max Lines |
|---------|-----------------|-----------|
| User Info | Rarely | 5-10 |
| Assistant Identity | Once | 5-8 |
| Important Dates | As needed | 10-15 |
| Projects | Weekly | 15-20 |
| Lessons Learned | Per incident | 10-15 |
| Tools & Config | As changed | 10-15 |

## Anti-Patterns

- Dumping entire conversation logs into MEMORY.md
- Keeping outdated project info "just in case"
- Duplicating info already in SOUL.md or USER.md
- Using memory as a task tracker (use HEARTBEAT.md or a todo file instead)

## File Size Target

Aim for MEMORY.md to stay under 100 lines / 3KB. If it grows beyond that, it's time to prune.
