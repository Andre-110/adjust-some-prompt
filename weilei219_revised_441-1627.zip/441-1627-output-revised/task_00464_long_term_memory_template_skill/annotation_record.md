# 修改记录

| 序号 | 修改项 | 修改原因 |
|------|--------|----------|
| 1 | 将任务难度从 easy 提升为 medium，并把 grading_type 改为 hybrid，增加 automated 与 llm 混合评分 | 对应问题 3；原题区分度严重不足，需增加 LLM Judge Rubric 并提升整体难度 |
| 2 | 重写 Prompt，明确要求读取 `assets/memory/` 日志与 `assets/docs/memory-best-practices.md`，并要求 `MEMORY.md` 基于真实日志提炼初始内容，而非空模板 | 对应问题 2；使 assets 成为强制输入，避免任务退化为模板生成 |
| 3 | 删除原 Prompt 中带有出题人提示意味的 supporting files 示例列表，改为“仅在真正有帮助时创建支持文件” | 对应问题 4；去除出题人视角与评分暗示 |
| 4 | 重写 Expected Behavior，加入具体陷阱与判断要求：提炼 durable facts、避免抄 raw logs、谨慎处理 open items、遵守 best practices | 对应问题 1、2、3；提高任务复杂度并显式覆盖真实判断能力 |
| 5 | 重写 Grading Criteria，加入“具体事实提取”“best-practice 遵守”“错误提升 transient open items”“supporting files 非 README 且非平庸文件”等维度 | 对应问题 1、3、5；提升自动评分与人工评分的区分度 |
| 6 | 新增完整 LLM Judge Rubric，细化到 1.0/0.75/0.5/0.25/0.0 五档锚点，覆盖内容 grounding、best-practice judgment、文件职责分离、SKILL.md 可操作性 | 对应问题 3；补足原题缺失的 Rubric，并提高评分细度 |
| 7 | 重写 `grade()`：从关键词存在检查改为检查有内容的 section、从 assets 中抽取具体 ground truth（bullet preference、utf-8 修复、02:00 UTC、08:00 CET、#team-updates）并验证 | 对应问题 1、2；修复关键词堆砌漏洞，改为基于真实资产内容评分 |
| 8 | 提高 `SKILL.md` 内容门槛：要求更长正文、至少多个 `##` 章节，并包含 distill/concise/anti-pattern/open-items 等操作性标记 | 对应问题 6；修复原先 `len(body) > 50` 过于宽松的问题 |
| 9 | 修复 supporting files 评分逻辑：移除 `README.md`，并要求支持文件达到最小内容与结构门槛，不再“创建一个文件即满分” | 对应问题 5；避免无意义文件获得满分 |
| 10 | 增加 `MEMORY.md` 长度、字节数、raw-log marker、transient item 的严格检查，确保评分与 best-practices 文档一致 | 对应问题 1、3；使自动评分真正验证“长期记忆”而非“日志转储” |
