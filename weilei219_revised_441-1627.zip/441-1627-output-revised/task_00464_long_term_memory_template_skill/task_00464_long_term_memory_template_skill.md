---
id: task_00464_long_term_memory_template_skill
name: Long-Term Memory Template Skill Creation
category: Knowledge and Memory Management
subcategory: Memory and Context Management
difficulty: medium
grading_type: hybrid
grading_weights: {automated: 0.7, llm: 0.3}
timeout_seconds: 600
input_modality: text-only
external_dependency: none
workspace_files: []
skill_creation: true
---

## Prompt

I’m trying to bootstrap a persistent memory system for my AI workspace.

There’s already some material in this repo:
- `assets/memory/` contains daily notes from recent sessions
- `assets/docs/memory-best-practices.md` describes how I want long-term memory files to be maintained
- `assets/memory-template-examples.json` has a few example shapes, but I don’t want you to copy one blindly if a better structure makes sense

Please do two things:

1. Create a reusable OpenClaw skill as `SKILL.md` that explains how to build and maintain long-term memory files in this workspace.
2. Create an initial `MEMORY.md` in the workspace root, but don’t leave it as an empty template — seed it using the actual facts you can extract from the existing daily notes.

A few important constraints:
- `MEMORY.md` should reflect curated long-term memory, not copied raw logs
- it should stay concise and align with the best-practices doc
- use the daily notes to capture stable or decision-relevant information such as communication preferences, recurring schedules, project decisions, and lessons learned
- if something from the daily notes looks transient, incomplete, or better treated as an open task than long-term memory, handle it carefully
- you may create supporting files if they genuinely help keep responsibilities separated, but only if they have a clear purpose

I care more about judgment than volume here.

## Expected Behavior

The agent should:

1. **Inspect the provided assets before writing files**
   - Read the daily notes in `assets/memory/` and extract concrete facts that are appropriate for long-term memory.
   - Read `assets/docs/memory-best-practices.md` and use it to guide what belongs in `MEMORY.md` versus what should be omitted or placed elsewhere.
   - Optionally consult `assets/memory-template-examples.json`, but avoid copying example section lists mechanically if they conflict with best practices.

2. **Create `SKILL.md` with substantive reusable instructions**
   - It must include valid YAML frontmatter with at least `name` and `description`.
   - The body should contain real operational guidance, not placeholders.
   - It should explain how to:
     - distill daily notes into curated memory,
     - decide what is stable enough to store,
     - avoid anti-patterns such as dumping logs or duplicating content across files,
     - keep the memory file concise over time,
     - handle open items that should not be promoted into durable memory unchanged.

3. **Create `MEMORY.md` in the workspace root with curated initial content**
   - It should contain clearly labeled sections covering the core domains of a long-term memory system, including:
     - user information / preferences,
     - assistant identity or operating stance,
     - important dates or recurring schedules,
     - project context / decisions,
     - lessons learned,
     - tools / configuration.
   - These sections must contain **real content derived from the provided daily notes and docs**, not just headings or placeholders.
   - At minimum, the correct `MEMORY.md` should capture facts grounded in the assets such as:
     - the user prefers **bullet-point summaries**,
     - the ETL pipeline issue involved adding `encoding='utf-8'` to `open()`,
     - the ETL pipeline is intended to run nightly at **02:00 UTC**,
     - the daily email digest is scheduled for **08:00 CET**,
     - weekly summaries go to **Slack `#team-updates`**.
   - The file should remain curated: it should **not** copy weather chatter or dump the full session logs verbatim.
   - Open items such as the database migration plan and PR review should not be naively stored as durable memory inside `MEMORY.md` as if they were stable facts.

4. **Use supporting files only when justified**
   - Supporting files are optional.
   - If created, they should have a distinct purpose and avoid duplicating large portions of `MEMORY.md`.
   - Creating trivial files purely to mirror section names is not considered good behavior.

5. **Honor best-practice constraints**
   - `MEMORY.md` should stay under 100 lines.
   - It should avoid secrets, raw-log dumping, and unnecessary duplication.
   - It should read like an actually useful starting memory file for future sessions, not like a blank template or a transcript copy.

## Grading Criteria

### Automated checks
- [ ] `SKILL.md` exists with valid YAML frontmatter containing `name` and `description`
- [ ] `SKILL.md` contains substantial, structured operational instructions (not a stub)
- [ ] `MEMORY.md` exists at workspace root
- [ ] `MEMORY.md` includes labeled sections for the required long-term memory domains
- [ ] `MEMORY.md` includes concrete facts extracted from the daily notes
- [ ] `MEMORY.md` reflects best-practice constraints (concise, not a raw log dump, under 100 lines)
- [ ] `MEMORY.md` does not incorrectly promote transient open items into durable memory
- [ ] Any supporting files created are non-trivial and not counted via `README.md`

### LLM Judge Rubric
Score each dimension using the anchors below.

#### 1. MEMORY.md content quality and grounding
- **1.0**: Strongly grounded in assets; includes multiple correct durable facts from logs; clearly curated; no obvious fabricated details.
- **0.75**: Mostly grounded; includes several correct facts but misses one important durable item or includes minor unnecessary detail.
- **0.5**: Partially grounded; has some real facts but remains template-like or too generic.
- **0.25**: Mostly headings/placeholders with minimal extraction from assets.
- **0.0**: Not grounded in assets or substantially fabricated.

#### 2. Best-practice adherence and judgment
- **1.0**: Clearly follows best practices: concise, no transcript dumping, no secrets, appropriate separation of long-term memory vs transient tasks, reasonable pruning mindset.
- **0.75**: Generally follows best practices with minor issues in concision or categorization.
- **0.5**: Mixed judgment; some curation but also some anti-patterns (minor duplication, task-tracker leakage, or excess verbosity).
- **0.25**: Significant anti-patterns such as storing raw logs, bloated content, or treating open items as stable memory.
- **0.0**: Ignores best practices entirely.

#### 3. File-structure design and responsibility separation
- **1.0**: Files have clear roles; supporting files, if any, meaningfully complement `MEMORY.md` without repeating it.
- **0.75**: Mostly good separation with limited overlap.
- **0.5**: Some duplication or unnecessary extra files, but the overall design is still usable.
- **0.25**: Heavy duplication or obvious file sprawl with weak rationale.
- **0.0**: Disorganized output with no meaningful separation of responsibilities.

#### 4. SKILL.md operational usefulness
- **1.0**: The skill gives concrete, reusable instructions for extraction, curation, update discipline, and edge-case handling.
- **0.75**: Useful overall, but missing one practical dimension such as update cadence or anti-pattern handling.
- **0.5**: Basic instructions exist, but they are generic and only somewhat actionable.
- **0.25**: Minimal or vague instructions with little reuse value.
- **0.0**: Missing or functionally useless.

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    from pathlib import Path
    import re

    scores = {}
    ws = Path(workspace_path)

    def read_text(path: Path) -> str:
        try:
            return path.read_text(encoding="utf-8", errors="replace")
        except Exception:
            return ""

    def strip_frontmatter(text: str) -> str:
        return re.sub(r"^---\s*\n.*?\n---\s*", "", text, count=1, flags=re.DOTALL)

    def normalize(text: str) -> str:
        return re.sub(r"\s+", " ", text.lower()).strip()

    def find_skill_path() -> Path | None:
        candidates = [ws / "SKILL.md"] + list(ws.glob("skills/*/SKILL.md")) + list(ws.glob("*/SKILL.md"))
        for p in candidates:
            if p.is_file():
                return p
        return None

    def heading_has_content(text: str, heading_keywords: list[str]) -> bool:
        lines = text.splitlines()
        normalized_keywords = [k.lower() for k in heading_keywords]
        for i, line in enumerate(lines):
            stripped = line.strip()
            if not stripped.startswith("#"):
                continue
            heading_text = stripped.lstrip("#").strip().lower()
            if any(k in heading_text for k in normalized_keywords):
                collected = []
                for j in range(i + 1, len(lines)):
                    nxt = lines[j].strip()
                    if nxt.startswith("#"):
                        break
                    if nxt:
                        collected.append(nxt)
                body = "\n".join(collected).strip()
                if len(body) >= 20:
                    return True
        return False

    # Ground truth from assets
    daily_0222 = read_text(ws / "assets/memory/2026-02-22.md")
    daily_0223 = read_text(ws / "assets/memory/2026-02-23.md")
    best_practices = read_text(ws / "assets/docs/memory-best-practices.md")
    _ = (daily_0222, daily_0223, best_practices)

    durable_fact_patterns = {
        "bullet_preference": [
            r"bullet[- ]point summaries",
            r"prefer[s]? bullet[- ]point",
            r"bullet[- ]point"
        ],
        "utf8_fix": [
            r"encoding\s*=\s*['\"]utf-?8['\"]",
            r"utf-?8"
        ],
        "etl_schedule": [
            r"02:00\s*utc",
            r"nightly at 02:00\s*utc",
            r"etl pipeline.*02:00\s*utc"
        ],
        "digest_schedule": [
            r"08:00\s*cet",
            r"daily email digest.*08:00\s*cet"
        ],
        "slack_channel": [
            r"#team-updates",
            r"slack.*team-updates"
        ]
    }

    transient_item_patterns = [
        r"finalize database migration plan",
        r"review pr\s*#?142",
        r"pr\s*#142",
    ]

    raw_log_markers = [
        r"10:15\s*utc",
        r"10:42\s*utc",
        r"11:03\s*utc",
        r"13:20\s*utc",
        r"14:55\s*utc",
        r"16:30\s*utc",
        r"12:35\s*utc",
        r"started new session",
        r"signed off for the day",
        r"weather in berlin",
        r"partly cloudy",
    ]

    # 1. SKILL.md checks
    skill_path = find_skill_path()
    skill_frontmatter_score = 0.0
    skill_instructions_score = 0.0

    if skill_path is not None:
        skill_text = read_text(skill_path)
        fm_match = re.search(r"^---\s*\n(.*?)\n---", skill_text, re.DOTALL)
        if fm_match:
            fm = fm_match.group(1)
            has_name = bool(re.search(r"(?im)^\s*name\s*:", fm))
            has_desc = bool(re.search(r"(?im)^\s*description\s*:", fm))
            if has_name and has_desc:
                skill_frontmatter_score = 1.0
            elif has_name or has_desc:
                skill_frontmatter_score = 0.5

        body = strip_frontmatter(skill_text).strip()
        section_count = len(re.findall(r"(?m)^##\s+", body))
        body_len = len(body)
        instruction_markers = sum(
            1 for pat in [
                r"daily notes|memory/",
                r"best[- ]practices|concise|under 100 lines",
                r"distill|curat|extract",
                r"avoid|anti-pattern|duplicate|duplication",
                r"open items|transient|task tracker",
            ]
            if re.search(pat, body, re.IGNORECASE)
        )
        if body_len >= 400 and section_count >= 3 and instruction_markers >= 4:
            skill_instructions_score = 1.0
        elif body_len >= 220 and section_count >= 2 and instruction_markers >= 2:
            skill_instructions_score = 0.5

    scores["skill_md_frontmatter"] = skill_frontmatter_score
    scores["skill_md_instructions"] = skill_instructions_score

    # 2. MEMORY.md existence
    memory_path = ws / "MEMORY.md"
    mem_exists = 0.0
    mem_text = ""
    mem_norm = ""
    if memory_path.is_file():
        mem_exists = 1.0
        mem_text = read_text(memory_path)
        mem_norm = normalize(mem_text)
    scores["memory_md_exists"] = mem_exists

    # 3. Section structure with actual content under headings
    required_sections = {
        "user_info": ["user", "human", "preferences", "communication"],
        "assistant_identity": ["assistant", "identity", "operating stance", "persona"],
        "important_dates": ["dates", "schedule", "important dates", "recurring"],
        "project_context": ["project", "projects", "context", "decisions"],
        "lessons_learned": ["lessons", "lessons learned", "takeaways"],
        "tools_config": ["tools", "config", "configuration", "setup"],
    }
    section_hits = sum(1 for _, keywords in required_sections.items() if heading_has_content(mem_text, keywords))
    scores["memory_structured_sections"] = 1.0 if section_hits >= 6 else (0.5 if section_hits >= 4 else 0.0)

    # 4. Concrete facts extracted from assets
    fact_hits = 0
    for patterns in durable_fact_patterns.values():
        if any(re.search(p, mem_text, re.IGNORECASE) for p in patterns):
            fact_hits += 1
    scores["memory_asset_grounding"] = 1.0 if fact_hits >= 4 else (0.5 if fact_hits >= 2 else 0.0)

    # 5. Best-practices / concision
    line_count = len(mem_text.splitlines()) if mem_text else 0
    byte_size = len(mem_text.encode("utf-8")) if mem_text else 0
    raw_log_hits = sum(1 for p in raw_log_markers if re.search(p, mem_text, re.IGNORECASE))
    if mem_exists == 0.0:
        scores["memory_best_practices"] = 0.0
    elif line_count < 100 and byte_size < 3072 and raw_log_hits == 0:
        scores["memory_best_practices"] = 1.0
    elif line_count <= 120 and byte_size < 4096 and raw_log_hits <= 1:
        scores["memory_best_practices"] = 0.5
    else:
        scores["memory_best_practices"] = 0.0

    # 6. Avoid promoting transient open items into durable memory
    transient_hits = sum(1 for p in transient_item_patterns if re.search(p, mem_text, re.IGNORECASE))
    scores["memory_transient_judgment"] = 1.0 if transient_hits == 0 else 0.0

    # 7. Supporting files: optional, but README does not count; trivial stubs do not count
    supporting_candidates = ["AGENTS.md", "IDENTITY.md", "SOUL.md", "HEARTBEAT.md", "USER.md", "TOOLS.md"]
    meaningful_supporting = 0
    for name in supporting_candidates:
        p = ws / name
        if p.is_file():
            txt = read_text(p).strip()
            if len(txt) >= 120 and len(re.findall(r"(?m)^#|^##", txt)) >= 2:
                meaningful_supporting += 1
    scores["supporting_files_quality"] = 1.0 if meaningful_supporting >= 2 else (0.5 if meaningful_supporting == 1 else 0.0)

    return scores
```
