# 修改记录

| 序号 | 修改项 | 修改原因 |
|------|--------|----------|
| 1 | Prompt 中删除"inspired by skills like workflow-tools (which does file analysis) and similar utility skills"，改为自然用户语气 | 问题4：出题人视角暴露，真实用户不会引用具体skill名称 |
| 2 | Prompt 增加歧义点：是否包含 SKILL.md 本身、生成的输出文件、隐藏文件（dotfiles），要求模型主动决策并记录 | 问题1：核心任务过于线性无歧义，需引入需要判断的边界case以提升难度 |
| 3 | Prompt 增加"在 token_frequency_results.txt 底部添加分析节"要求，需要对频率数据做实质性模式分析 | 问题1：任务纯属脚本执行，增加需要真实判断能力的分析环节 |
| 4 | Expected Behavior 增加 scope decision consistency trap 说明，明确指出 SKILL.md 与实际执行需要一致 | 问题1/问题6：增加需要权衡和决策的复杂性，防止强模型轻松满分 |
| 5 | 将 `skill_md_has_content`（50字节检测）替换为 `skill_md_substantive_content`，检测scope说明/输出格式/步骤结构等4个维度 | 问题2：原检查门槛极低，任意两行内容即满分，无区分度 |
| 6 | 修复 `contains_expected_tokens`，替换为 `top_token_counts_accurate`：基于动态计算的 ground truth，验证 top-5 token 计数精度（±2容忍度） | 问题3：原检查只验证词是否出现，不验证计数正确性，无法区分真正统计与伪造结果 |
| 7 | 修复 `sorted_descending` 解析逻辑：用更鲁棒的正则 `re.match(r"^\s*(?:\d+[.)\s]+)?([a-zA-Z][a-zA-Z0-9]*)\s*[:\s]\s*(\d+)", ...)` 替代 `re.findall(r"\b(\d+)\b", line)` 取最后一个数字 | 问题5：原解析在含百分比等额外数字的行中会误判 |
| 8 | grade() 中增加动态 ground truth 计算函数 `compute_ground_truth()`，支持 exclude_dotfiles 参数，同时计算两种scope变体取最佳匹配 | 问题3/问题6：需要精确计数验证，同时容纳agent的不同scope决策 |
| 9 | grade() 中 `no_short_tokens` 改为直接检查 parsed_token_counts 的 key 长度，而非扫描整个文件文本 | 问题5：原实现会误判分析节中的说明性文字 |
| 10 | 添加 LLM Judge Rubric，覆盖三个维度：skill_md_quality（40%）、analysis_section_quality（35%）、scope_consistency（25%），每个等级有具体锚点描述 | 问题2/问题3：自动检查无法评估SKILL.md实质质量和分析节洞察深度，需要LLM Judge补充 |
| 11 | 将 grading_weights 修改为 `{automated: 0.7, llm_judge: 0.3}`，引入LLM Judge分 | 新增LLM Judge维度需要对应权重调整 |
| 12 | 将 difficulty 从 medium 改为 hard | 问题1：原题目强模型必然接近满分，提升难度级别 |
| 13 | 将 `data/filename-analysis-notes.md` 的内容替换为 placeholder（移除分析方法论 hints） | 问题6：原文件包含 tokenization methodology 描述，相当于给模型提供了答案hints，降低难度 |
| 14 | workspace_files 中移除 `data/filename-analysis-notes.md` 的原始详细内容，并在 grade() 中将 `_create_files.py` 加入 excluded_names 集合 | 问题6：_create_files.py 会导致 token 统计结果与预期不匹配 |
| 15 | Grading Criteria 更新，增加scope一致性、分析节、计数精度等验收标准 | 对应所有问题，确保grading criteria与新的task设计一致 |
