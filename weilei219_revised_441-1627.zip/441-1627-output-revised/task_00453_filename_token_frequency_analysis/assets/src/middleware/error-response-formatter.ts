# placeholder: error-response-formatter.ts
