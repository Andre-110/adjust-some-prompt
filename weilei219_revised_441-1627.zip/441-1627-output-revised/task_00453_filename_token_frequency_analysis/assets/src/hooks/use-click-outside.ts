# placeholder: use-click-outside.ts
