---
id: task_00453_filename_token_frequency_analysis
name: Filename Token Frequency Analysis with Skill Creation
category: Data Analysis and Modeling
subcategory: Data Processing and Management
difficulty: hard
grading_type: automated
grading_weights: {automated: 0.7, llm_judge: 0.3}
timeout_seconds: 600
input_modality: text-only
external_dependency: none
workspace_files:
  - path: src/components/user-profile-card.tsx
    content: "# placeholder: user-profile-card.tsx"
  - path: src/components/navigation-sidebar-menu.tsx
    content: "# placeholder: navigation-sidebar-menu.tsx"
  - path: src/components/data-table-pagination.tsx
    content: "# placeholder: data-table-pagination.tsx"
  - path: src/components/modal-dialog-confirm.tsx
    content: "# placeholder: modal-dialog-confirm.tsx"
  - path: src/components/dropdown-select-multi.tsx
    content: "# placeholder: dropdown-select-multi.tsx"
  - path: src/components/search-bar-autocomplete.tsx
    content: "# placeholder: search-bar-autocomplete.tsx"
  - path: src/components/file-upload-progress.tsx
    content: "# placeholder: file-upload-progress.tsx"
  - path: src/components/notification-toast-stack.tsx
    content: "# placeholder: notification-toast-stack.tsx"
  - path: src/components/chart-line-realtime.tsx
    content: "# placeholder: chart-line-realtime.tsx"
  - path: src/components/form-validation-wrapper.tsx
    content: "# placeholder: form-validation-wrapper.tsx"
  - path: src/components/auth-login-form.tsx
    content: "# placeholder: auth-login-form.tsx"
  - path: src/components/dashboard-widget-container.tsx
    content: "# placeholder: dashboard-widget-container.tsx"
  - path: src/components/breadcrumb-navigation-trail.tsx
    content: "# placeholder: breadcrumb-navigation-trail.tsx"
  - path: src/components/image-gallery-lightbox.tsx
    content: "# placeholder: image-gallery-lightbox.tsx"
  - path: src/components/date-range-picker.tsx
    content: "# placeholder: date-range-picker.tsx"
  - path: src/utils/string-format-helpers.ts
    content: "# placeholder: string-format-helpers.ts"
  - path: src/utils/date-time-utils.ts
    content: "# placeholder: date-time-utils.ts"
  - path: src/utils/api-response-parser.ts
    content: "# placeholder: api-response-parser.ts"
  - path: src/utils/local-storage-manager.ts
    content: "# placeholder: local-storage-manager.ts"
  - path: src/utils/error-handler-global.ts
    content: "# placeholder: error-handler-global.ts"
  - path: src/utils/validation-schema-builder.ts
    content: "# placeholder: validation-schema-builder.ts"
  - path: src/utils/csv-export-utility.ts
    content: "# placeholder: csv-export-utility.ts"
  - path: src/utils/deep-merge-objects.ts
    content: "# placeholder: deep-merge-objects.ts"
  - path: src/utils/debounce-throttle-functions.ts
    content: "# placeholder: debounce-throttle-functions.ts"
  - path: src/utils/color-palette-generator.ts
    content: "# placeholder: color-palette-generator.ts"
  - path: src/hooks/use-auth-context.ts
    content: "# placeholder: use-auth-context.ts"
  - path: src/hooks/use-fetch-data.ts
    content: "# placeholder: use-fetch-data.ts"
  - path: src/hooks/use-local-storage.ts
    content: "# placeholder: use-local-storage.ts"
  - path: src/hooks/use-debounced-value.ts
    content: "# placeholder: use-debounced-value.ts"
  - path: src/hooks/use-intersection-observer.ts
    content: "# placeholder: use-intersection-observer.ts"
  - path: src/hooks/use-media-query.ts
    content: "# placeholder: use-media-query.ts"
  - path: src/hooks/use-window-resize.ts
    content: "# placeholder: use-window-resize.ts"
  - path: src/hooks/use-click-outside.ts
    content: "# placeholder: use-click-outside.ts"
  - path: src/services/user-authentication-service.ts
    content: "# placeholder: user-authentication-service.ts"
  - path: src/services/payment-processing-gateway.ts
    content: "# placeholder: payment-processing-gateway.ts"
  - path: src/services/notification-email-sender.ts
    content: "# placeholder: notification-email-sender.ts"
  - path: src/services/file-storage-cloud-adapter.ts
    content: "# placeholder: file-storage-cloud-adapter.ts"
  - path: src/services/analytics-event-tracker.ts
    content: "# placeholder: analytics-event-tracker.ts"
  - path: src/services/cache-redis-manager.ts
    content: "# placeholder: cache-redis-manager.ts"
  - path: src/services/search-elasticsearch-client.ts
    content: "# placeholder: search-elasticsearch-client.ts"
  - path: src/services/queue-message-broker.ts
    content: "# placeholder: queue-message-broker.ts"
  - path: src/middleware/auth-token-validator.ts
    content: "# placeholder: auth-token-validator.ts"
  - path: src/middleware/rate-limit-controller.ts
    content: "# placeholder: rate-limit-controller.ts"
  - path: src/middleware/request-logger-morgan.ts
    content: "# placeholder: request-logger-morgan.ts"
  - path: src/middleware/cors-policy-handler.ts
    content: "# placeholder: cors-policy-handler.ts"
  - path: src/middleware/error-response-formatter.ts
    content: "# placeholder: error-response-formatter.ts"
  - path: tests/unit/user-profile-card.test.tsx
    content: "# placeholder: user-profile-card.test.tsx"
  - path: tests/unit/string-format-helpers.test.ts
    content: "# placeholder: string-format-helpers.test.ts"
  - path: tests/unit/date-time-utils.test.ts
    content: "# placeholder: date-time-utils.test.ts"
  - path: tests/unit/api-response-parser.test.ts
    content: "# placeholder: api-response-parser.test.ts"
  - path: tests/unit/validation-schema-builder.test.ts
    content: "# placeholder: validation-schema-builder.test.ts"
  - path: tests/unit/deep-merge-objects.test.ts
    content: "# placeholder: deep-merge-objects.test.ts"
  - path: tests/integration/auth-login-flow.test.ts
    content: "# placeholder: auth-login-flow.test.ts"
  - path: tests/integration/payment-checkout-flow.test.ts
    content: "# placeholder: payment-checkout-flow.test.ts"
  - path: tests/integration/file-upload-pipeline.test.ts
    content: "# placeholder: file-upload-pipeline.test.ts"
  - path: tests/integration/search-filter-sort.test.ts
    content: "# placeholder: search-filter-sort.test.ts"
  - path: tests/e2e/user-registration-journey.spec.ts
    content: "# placeholder: user-registration-journey.spec.ts"
  - path: tests/e2e/dashboard-navigation-smoke.spec.ts
    content: "# placeholder: dashboard-navigation-smoke.spec.ts"
  - path: tests/e2e/data-export-download.spec.ts
    content: "# placeholder: data-export-download.spec.ts"
  - path: config/webpack.config.production.js
    content: "# placeholder: webpack.config.production.js"
  - path: config/webpack.config.development.js
    content: "# placeholder: webpack.config.development.js"
  - path: config/jest.setup.integration.ts
    content: "# placeholder: jest.setup.integration.ts"
  - path: config/eslint-rules-custom.json
    content: "# placeholder: eslint-rules-custom.json"
  - path: config/tailwind.config.extended.js
    content: "# placeholder: tailwind.config.extended.js"
  - path: config/database-migration-settings.yaml
    content: "# placeholder: database-migration-settings.yaml"
  - path: config/redis-cluster-config.yaml
    content: "# placeholder: redis-cluster-config.yaml"
  - path: config/nginx-reverse-proxy.conf
    content: "# placeholder: nginx-reverse-proxy.conf"
  - path: docs/api-reference-guide.md
    content: "# placeholder: api-reference-guide.md"
  - path: docs/getting-started-quickstart.md
    content: "# placeholder: getting-started-quickstart.md"
  - path: docs/deployment-production-checklist.md
    content: "# placeholder: deployment-production-checklist.md"
  - path: docs/architecture-decision-records.md
    content: "# placeholder: architecture-decision-records.md"
  - path: docs/database-schema-design.md
    content: "# placeholder: database-schema-design.md"
  - path: docs/troubleshooting-common-issues.md
    content: "# placeholder: troubleshooting-common-issues.md"
  - path: docs/changelog-release-notes.md
    content: "# placeholder: changelog-release-notes.md"
  - path: docs/contributing-guidelines-style.md
    content: "# placeholder: contributing-guidelines-style.md"
  - path: scripts/database-seed-initial.sh
    content: "# placeholder: database-seed-initial.sh"
  - path: scripts/backup-restore-postgres.sh
    content: "# placeholder: backup-restore-postgres.sh"
  - path: scripts/deploy-production-rollback.sh
    content: "# placeholder: deploy-production-rollback.sh"
  - path: scripts/generate-ssl-certificates.sh
    content: "# placeholder: generate-ssl-certificates.sh"
  - path: scripts/cleanup-temp-files.sh
    content: "# placeholder: cleanup-temp-files.sh"
  - path: scripts/run-performance-benchmark.sh
    content: "# placeholder: run-performance-benchmark.sh"
  - path: scripts/migrate-data-legacy-format.sh
    content: "# placeholder: migrate-data-legacy-format.sh"
  - path: assets/images/logo-dark-theme.svg
    content: "# placeholder: logo-dark-theme.svg"
  - path: assets/images/logo-light-theme.svg
    content: "# placeholder: logo-light-theme.svg"
  - path: assets/images/hero-banner-homepage.png
    content: "# placeholder: hero-banner-homepage.png"
  - path: assets/images/placeholder-user-avatar.png
    content: "# placeholder: placeholder-user-avatar.png"
  - path: assets/images/background-pattern-dots.svg
    content: "# placeholder: background-pattern-dots.svg"
  - path: assets/fonts/inter-variable-latin.woff2
    content: "# placeholder: inter-variable-latin.woff2"
  - path: assets/fonts/fira-code-regular.woff2
    content: "# placeholder: fira-code-regular.woff2"
  - path: assets/fonts/roboto-mono-bold.woff2
    content: "# placeholder: roboto-mono-bold.woff2"
  - path: assets/icons/icon-chevron-down.svg
    content: "# placeholder: icon-chevron-down.svg"
  - path: assets/icons/icon-search-magnify.svg
    content: "# placeholder: icon-search-magnify.svg"
  - path: assets/icons/icon-bell-notification.svg
    content: "# placeholder: icon-bell-notification.svg"
  - path: assets/icons/icon-settings-gear.svg
    content: "# placeholder: icon-settings-gear.svg"
  - path: assets/icons/icon-user-circle.svg
    content: "# placeholder: icon-user-circle.svg"
  - path: assets/icons/icon-menu-hamburger.svg
    content: "# placeholder: icon-menu-hamburger.svg"
  - path: assets/icons/icon-close-cross.svg
    content: "# placeholder: icon-close-cross.svg"
  - path: assets/icons/icon-check-circle.svg
    content: "# placeholder: icon-check-circle.svg"
  - path: data/sample-users-dataset.json
    content: "# placeholder: sample-users-dataset.json"
  - path: data/product-categories-lookup.csv
    content: "# placeholder: product-categories-lookup.csv"
  - path: data/country-codes-iso3166.json
    content: "# placeholder: country-codes-iso3166.json"
  - path: data/timezone-offset-mapping.json
    content: "# placeholder: timezone-offset-mapping.json"
  - path: data/error-codes-reference.yaml
    content: "# placeholder: error-codes-reference.yaml"
  - path: data/feature-flags-default.json
    content: "# placeholder: feature-flags-default.json"
  - path: logs/access-log-2026-02-22.txt
    content: "# placeholder: access-log-2026-02-22.txt"
  - path: logs/error-log-2026-02-22.txt
    content: "# placeholder: error-log-2026-02-22.txt"
  - path: logs/application-debug-output.log
    content: "# placeholder: application-debug-output.log"
  - path: logs/deployment-pipeline-trace.log
    content: "# placeholder: deployment-pipeline-trace.log"
  - path: .github/workflows/ci-build-test-lint.yml
    content: "# placeholder: ci-build-test-lint.yml"
  - path: .github/workflows/cd-deploy-staging.yml
    content: "# placeholder: cd-deploy-staging.yml"
  - path: .github/workflows/cd-deploy-production.yml
    content: "# placeholder: cd-deploy-production.yml"
  - path: .github/workflows/codeql-security-analysis.yml
    content: "# placeholder: codeql-security-analysis.yml"
  - path: .github/workflows/dependency-review-check.yml
    content: "# placeholder: dependency-review-check.yml"
  - path: deploy/terraform/main-infrastructure-vpc.tf
    content: "# placeholder: main-infrastructure-vpc.tf"
  - path: deploy/terraform/rds-database-instance.tf
    content: "# placeholder: rds-database-instance.tf"
  - path: deploy/terraform/ecs-fargate-service.tf
    content: "# placeholder: ecs-fargate-service.tf"
  - path: deploy/terraform/cloudfront-distribution-cdn.tf
    content: "# placeholder: cloudfront-distribution-cdn.tf"
  - path: deploy/terraform/route53-dns-records.tf
    content: "# placeholder: route53-dns-records.tf"
  - path: deploy/docker/Dockerfile.production-multi-stage
    content: "# placeholder: Dockerfile.production-multi-stage"
  - path: deploy/docker/Dockerfile.development-hot-reload
    content: "# placeholder: Dockerfile.development-hot-reload"
  - path: deploy/docker/docker-compose-local-dev.yml
    content: "# placeholder: docker-compose-local-dev.yml"
  - path: deploy/docker/docker-compose-integration-test.yml
    content: "# placeholder: docker-compose-integration-test.yml"
  - path: package.json
    content: "# placeholder: package.json"
  - path: package-lock.json
    content: "# placeholder: package-lock.json"
  - path: tsconfig.json
    content: "# placeholder: tsconfig.json"
  - path: tsconfig.build.json
    content: "# placeholder: tsconfig.build.json"
  - path: .env.example
    content: "# placeholder: .env.example"
  - path: .env.production.template
    content: "# placeholder: .env.production.template"
  - path: .gitignore
    content: "# placeholder: .gitignore"
  - path: .prettierrc.json
    content: "# placeholder: .prettierrc.json"
  - path: .dockerignore
    content: "# placeholder: .dockerignore"
  - path: README.md
    content: "# placeholder: README.md"
  - path: LICENSE
    content: "# placeholder: LICENSE"
  - path: Makefile
    content: "# placeholder: Makefile"
  - path: docker-compose.yml
    content: "# placeholder: docker-compose.yml"
  - path: vitest.config.ts
    content: "# placeholder: vitest.config.ts"
skill_creation: true
---

## Prompt

Hey, I want to analyze the file naming patterns in this codebase to understand how we're naming things. I'd like you to:

1. First, create a `SKILL.md` in the workspace root that documents this as a reusable skill — something I could share with others so they can run the same analysis on any project. The skill doc should be detailed enough that someone else could actually follow it to reproduce the analysis, including what steps to take, what decisions need to be made (like boundary cases), and example output format. Make it genuinely useful, not just a template with placeholder text.

2. Then actually run the analysis on this workspace:
   - Scan all filenames recursively (basename only, not full paths)
   - Split filenames into tokens by breaking on non-alphanumeric characters
   - Filter out tokens shorter than 3 characters
   - Count token frequencies and output the top 50, sorted by frequency descending
   - Save results to `token_frequency_results.txt` with one `token: count` entry per line

One thing I'm not sure about: should the analysis include files like `SKILL.md` itself, generated output files, or hidden files (dotfiles)? Make a reasonable call and document your decision in the SKILL.md.

Also — after producing the raw frequency list, I'd like a brief analysis section at the bottom of `token_frequency_results.txt` that comments on what the frequency distribution reveals about this project's naming conventions. Are there patterns that look unusual or inconsistent? What naming conventions dominate?

## Expected Behavior

The agent should:

1. **Create a SKILL.md file** with proper YAML frontmatter (`name` and `description` fields) and substantive markdown content that a third party could follow to reproduce the analysis. The skill doc must include:
   - Clear description of the analysis steps
   - Explicit decision about scope boundaries (which files to include/exclude, e.g. SKILL.md itself, generated output files, dotfiles)
   - Expected output format specification
   - At least one concrete usage example or sample output snippet
   
   Note: The agent must make an active decision about scope (e.g., "include dotfiles or not", "include SKILL.md itself or not") — there is no single correct answer, but the decision must be explicit and consistent with what the analysis actually does.

2. **Recursively scan** all files in the workspace, applying its stated scope decision consistently.

3. **Tokenize** each filename (basename only) by splitting on non-alphanumeric characters, normalize to lowercase, and filter tokens shorter than 3 characters.

4. **Count frequencies** and produce the top 50 tokens sorted by frequency descending, written to `token_frequency_results.txt` in `token: count` format (one entry per line).

5. **Append an analysis section** to `token_frequency_results.txt` that makes concrete observations about naming patterns — not just generic statements. This section should identify any cross-cutting naming themes, potential inconsistencies, or dominant conventions in the file tree.

6. **Scope decision consistency trap**: The agent must be consistent between what it says in SKILL.md and what it actually counts. If it says "exclude dotfiles" but counts `.gitignore` tokens, that is a failure. Common traps include: forgetting to exclude `SKILL.md` and `token_frequency_results.txt` themselves (which would artificially inflate `skill`, `token`, `frequency`, `results`), and inconsistent handling of hidden files.

7. **Expected top tokens** (excluding SKILL.md, token_frequency_results.txt, and dotfiles from scope): Based on the workspace file tree, the top tokens by frequency should include `test` (12), `config` (9), `production` (7), `tsx` (16), `svg` (11), `user` (6), `database` (5), `deploy` or `deployment` (5+), `notification` (3), `auth` (4). Exact counts depend on scope decisions — the grader allows ±2 tolerance on counts.

## Grading Criteria

- [ ] SKILL.md exists with proper YAML frontmatter (name and description)
- [ ] SKILL.md contains substantive, actionable content including scope boundary decisions, steps, and output format
- [ ] SKILL.md includes explicit documentation of the scope decision (which files to include/exclude)
- [ ] token_frequency_results.txt exists and is non-empty with correct format (`token: count` per line)
- [ ] Results are sorted by frequency descending
- [ ] Tokens shorter than 3 characters are excluded
- [ ] Top token counts are approximately correct (within ±2 of ground truth for top-5 tokens)
- [ ] token_frequency_results.txt includes a non-trivial analysis section with specific observations
- [ ] Scope decision is applied consistently between SKILL.md documentation and actual analysis

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    import os
    import re
    from pathlib import Path
    from collections import Counter

    scores = {
        "skill_md_exists_and_structured": 0.0,
        "skill_md_substantive_content": 0.0,
        "results_file_exists_and_formatted": 0.0,
        "top_token_counts_accurate": 0.0,
        "sorted_descending": 0.0,
        "no_short_tokens": 0.0,
    }

    workspace = Path(workspace_path)

    # ── 1. SKILL.md structure check ──────────────────────────────────────────
    skill_path = workspace / "SKILL.md"
    if skill_path.exists():
        skill_content = skill_path.read_text(encoding="utf-8", errors="replace")
        frontmatter_match = re.search(r"^---\s*\n(.*?)\n---", skill_content, re.DOTALL)
        if frontmatter_match:
            fm = frontmatter_match.group(1)
            has_name = bool(re.search(r"name\s*:", fm))
            has_desc = bool(re.search(r"description\s*:", fm))
            if has_name and has_desc:
                scores["skill_md_exists_and_structured"] = 1.0
            elif has_name or has_desc:
                scores["skill_md_exists_and_structured"] = 0.5

        # Check SKILL.md has substantive content (steps + scope decision + output format)
        body = re.sub(r"^---\s*\n.*?\n---\s*\n?", "", skill_content, count=1, flags=re.DOTALL)
        body_lower = body.lower()
        # Must have: meaningful length, mention of scope/exclusion decision,
        # mention of output format, and step-like structure
        has_length = len(body.strip()) > 400
        has_scope_mention = any(
            kw in body_lower for kw in ["exclud", "includ", "scope", "skip", "ignore", "dotfile", "hidden"]
        )
        has_output_format = any(
            kw in body_lower for kw in ["output", "format", "token:", "example", "sample"]
        )
        has_steps = bool(re.search(r"(step\s*\d|##\s+\w|\d+\.\s+\w)", body, re.IGNORECASE))
        content_score = sum([has_length, has_scope_mention, has_output_format, has_steps])
        scores["skill_md_substantive_content"] = content_score / 4.0

    # ── 2. Compute ground truth token counts from workspace ───────────────────
    # We compute ground truth here so the checker can verify accuracy.
    # Scope: all files recursively, excluding: SKILL.md, token_frequency_results.txt,
    # and any dotfiles/hidden files (files starting with '.').
    # This matches the recommended scope; agents with different scope decisions
    # will have slight count differences (handled by tolerance below).
    def compute_ground_truth(ws_path, exclude_dotfiles=True):
        token_counter = Counter()
        excluded_names = {"SKILL.md", "token_frequency_results.txt", "_create_files.py"}
        for root, dirs, files in os.walk(ws_path):
            # Optionally skip hidden directories
            if exclude_dotfiles:
                dirs[:] = [d for d in dirs if not d.startswith(".")]
            for fname in files:
                if fname in excluded_names:
                    continue
                if exclude_dotfiles and fname.startswith("."):
                    continue
                basename = fname
                # Split on non-alphanumeric, lowercase, filter len < 3
                raw_tokens = re.split(r"[^a-zA-Z0-9]+", basename)
                for tok in raw_tokens:
                    tok_lower = tok.lower()
                    if len(tok_lower) >= 3:
                        token_counter[tok_lower] += 1
        return token_counter

    ground_truth = compute_ground_truth(workspace)
    # Also compute with dotfiles included (agent may have chosen differently)
    ground_truth_with_dots = compute_ground_truth(workspace, exclude_dotfiles=False)

    top50_gt = [tok for tok, cnt in ground_truth.most_common(50)]
    top5_gt = ground_truth.most_common(5)  # [(token, count), ...]

    # ── 3. Read results file ──────────────────────────────────────────────────
    results_path = workspace / "token_frequency_results.txt"
    results_content = ""
    parsed_token_counts = {}  # token -> count from results file

    if results_path.exists():
        results_content = results_path.read_text(encoding="utf-8", errors="replace").strip()
        if len(results_content) > 20:
            scores["results_file_exists_and_formatted"] = 0.5

        # Parse token: count lines robustly
        # Accepts formats: "token: 12", "token: 12 (8.2%)", "token 12", "1. token: 12"
        lines = results_content.split("\n")
        freq_lines = []
        analysis_started = False
        for line in lines:
            stripped = line.strip()
            if not stripped:
                continue
            # Detect analysis section separator
            if re.match(r"^#{1,3}\s+", stripped) or "analysis" in stripped.lower() or "pattern" in stripped.lower() or "convention" in stripped.lower():
                # Once we hit a header that looks like analysis, stop parsing counts
                if parsed_token_counts:  # only if we already have some counts
                    analysis_started = True
            if analysis_started:
                continue
            # Try to parse "token: count" or "token count" patterns
            # Match: optional rank prefix, then word token, then colon or space, then number
            m = re.match(r"^\s*(?:\d+[.)\s]+)?([a-zA-Z][a-zA-Z0-9]*)\s*[:\s]\s*(\d+)", stripped)
            if m:
                tok = m.group(1).lower()
                cnt = int(m.group(2))
                # Skip obvious header words
                if tok not in {"token", "count", "rank", "frequency", "freq", "top", "name"}:
                    parsed_token_counts[tok] = cnt
                    freq_lines.append(cnt)

        # Check format quality: if we parsed ≥10 token:count pairs, good format
        if len(parsed_token_counts) >= 10:
            scores["results_file_exists_and_formatted"] = 1.0
        elif len(parsed_token_counts) >= 5:
            scores["results_file_exists_and_formatted"] = 0.75

    if not results_content:
        # Transcript fallback: very limited credit
        for event in transcript:
            if event.get("type") != "message":
                continue
            msg = event.get("message", {})
            if msg.get("role") == "assistant":
                content = msg.get("content", "")
                if isinstance(content, list):
                    content = " ".join(
                        item.get("text", "") for item in content if isinstance(item, dict)
                    )
                if re.search(r"\b(tsx|svg|test)\s*[:\s]\s*\d+", content):
                    results_content = content
                    scores["results_file_exists_and_formatted"] = 0.25
                    break

    # ── 4. Top token count accuracy ───────────────────────────────────────────
    if parsed_token_counts:
        # Check top-5 ground truth tokens: verify counts are within ±2
        # Use either scope variant (dotfiles excluded or included) — take best match
        def accuracy_score(gt_top5, parsed):
            correct = 0
            present = 0
            for tok, gt_cnt in gt_top5:
                if tok in parsed:
                    present += 1
                    if abs(parsed[tok] - gt_cnt) <= 2:
                        correct += 1
            return correct, present

        correct_excl, present_excl = accuracy_score(top5_gt, parsed_token_counts)
        correct_incl, present_incl = accuracy_score(ground_truth_with_dots.most_common(5), parsed_token_counts)
        best_correct = max(correct_excl, correct_incl)
        best_present = max(present_excl, present_incl)

        if best_correct >= 4:
            scores["top_token_counts_accurate"] = 1.0
        elif best_correct == 3:
            scores["top_token_counts_accurate"] = 0.75
        elif best_correct == 2 or best_present >= 4:
            scores["top_token_counts_accurate"] = 0.5
        elif best_correct == 1 or best_present >= 2:
            scores["top_token_counts_accurate"] = 0.25

    # ── 5. Descending sort order ──────────────────────────────────────────────
    if len(parsed_token_counts) >= 3:
        # Use the ordered frequencies from the results file (parsed in order)
        # Re-parse to get ordered list
        ordered_freqs = []
        if results_path.exists():
            raw_lines = results_path.read_text(encoding="utf-8", errors="replace").split("\n")
            analysis_hit = False
            for line in raw_lines:
                stripped = line.strip()
                if not stripped:
                    continue
                if re.match(r"^#{1,3}\s+", stripped) and ordered_freqs:
                    analysis_hit = True
                if analysis_hit:
                    continue
                m = re.match(r"^\s*(?:\d+[.)\s]+)?([a-zA-Z][a-zA-Z0-9]*)\s*[:\s]\s*(\d+)", stripped)
                if m:
                    tok = m.group(1).lower()
                    if tok not in {"token", "count", "rank", "frequency", "freq", "top", "name"}:
                        ordered_freqs.append(int(m.group(2)))

        if len(ordered_freqs) >= 3:
            violations = sum(
                1 for i in range(len(ordered_freqs) - 1)
                if ordered_freqs[i] < ordered_freqs[i + 1]
            )
            total_pairs = len(ordered_freqs) - 1
            if violations == 0:
                scores["sorted_descending"] = 1.0
            elif violations / total_pairs <= 0.05:
                scores["sorted_descending"] = 0.75
            elif violations / total_pairs <= 0.15:
                scores["sorted_descending"] = 0.5

    # ── 6. No short tokens ────────────────────────────────────────────────────
    if parsed_token_counts:
        short_tokens = [t for t in parsed_token_counts.keys() if len(t) < 3]
        total_tokens = len(parsed_token_counts)
        short_ratio = len(short_tokens) / total_tokens if total_tokens else 1.0
        if short_ratio == 0:
            scores["no_short_tokens"] = 1.0
        elif short_ratio <= 0.05:
            scores["no_short_tokens"] = 0.75
        elif short_ratio <= 0.15:
            scores["no_short_tokens"] = 0.5

    return scores
```

## LLM Judge Rubric

```yaml
dimensions:
  - name: skill_md_quality
    weight: 0.40
    description: >
      Evaluate the quality of SKILL.md as a reusable skill document.
      A high-quality SKILL.md should be genuinely useful to a third party
      trying to run this analysis on their own project.
    rubric:
      1.0: |
        SKILL.md contains all of the following:
        (a) Proper YAML frontmatter with name and description fields
        (b) Clear, numbered or structured steps that a human could follow
        (c) An explicit, reasoned scope decision (e.g., "we exclude dotfiles
            because they are tooling config and not project naming conventions;
            we also exclude SKILL.md and token_frequency_results.txt to avoid
            polluting the results with meta-files")
        (d) Specified output format with a concrete example (at least 3 sample
            lines showing token: count format)
        (e) At least one non-obvious guidance note (e.g., case normalization,
            handling of numeric tokens, what to do with single-word filenames)
      0.75: |
        SKILL.md covers 4 of the 5 criteria above. Scope decision is present
        but lacks explicit reasoning, OR output format is described but without
        a concrete example, OR steps are present but high-level without
        actionable detail.
      0.5: |
        SKILL.md has frontmatter and at least 2 substantive sections, but
        scope decision is absent or implicit, OR output format is not specified,
        OR the document reads as a generic template with placeholder-level content.
      0.25: |
        SKILL.md exists with valid frontmatter and at least 50 words of body
        content, but lacks structured guidance. A third party could not
        reproduce the analysis from this document alone.
      0.0: |
        SKILL.md is missing, has invalid/missing frontmatter, or body is
        essentially empty (fewer than 50 words).

  - name: analysis_section_quality
    weight: 0.35
    description: >
      Evaluate the quality of the analysis section appended to
      token_frequency_results.txt. Does it make specific, non-trivial
      observations about naming conventions in this codebase?
    rubric:
      1.0: |
        Analysis section makes at least 3 specific, evidence-based observations
        about naming conventions visible in the token frequency data. Examples:
        - Identifies dominant technical vocabulary (e.g., infra vs. domain terms)
        - Notes inconsistencies (e.g., "config appears in multiple forms: config,
          configuration; they are counted separately")
        - Comments on architectural patterns revealed by token distribution
          (e.g., heavy use of test/spec tokens suggests test-driven structure)
        - Points out potential naming smells or cross-cutting concerns
        Observations must reference specific tokens and their counts.
      0.75: |
        Analysis section makes 2 specific observations referencing actual token
        data, plus at least one general observation. OR makes 3 specific
        observations but without referencing token counts/frequencies.
      0.5: |
        Analysis section exists and mentions specific tokens, but observations
        are generic (e.g., "test is common because there are many test files")
        without insight into naming patterns or inconsistencies.
      0.25: |
        Analysis section exists but is entirely generic, could apply to any
        project, references no specific tokens or counts.
      0.0: |
        No analysis section present in token_frequency_results.txt, or the
        file does not exist.

  - name: scope_consistency
    weight: 0.25
    description: >
      Does the agent apply its stated scope decision consistently? Check
      whether what SKILL.md documents matches what the analysis actually did.
      Focus especially on: (1) whether meta-files like SKILL.md and
      token_frequency_results.txt were excluded, (2) whether dotfile handling
      is consistent, (3) whether the token counts in the results are plausible
      given the stated scope.
    rubric:
      1.0: |
        SKILL.md explicitly states the scope decision AND the token_frequency_results.txt
        is consistent with that decision. Specifically:
        - If SKILL.md says "exclude meta-files", tokens like "skill", "token",
          "frequency", "results" do NOT appear inflated in top results
        - If SKILL.md says "exclude dotfiles", dotfile-derived tokens (env, gitignore,
          prettierrc, dockerignore) do not appear with implausibly high counts
        - The total number of entries is consistent with the stated scope
      0.75: |
        Scope decision is stated but minor inconsistencies exist (e.g., says
        "exclude SKILL.md" but SKILL.md tokens appear with count=1, which
        could be coincidental from other filenames). No major violations.
      0.5: |
        Scope decision is stated but one clear inconsistency exists (e.g.,
        claims to exclude meta-files but "token" or "frequency" appears with
        inflated count suggesting token_frequency_results.txt was scanned).
      0.25: |
        No explicit scope decision in SKILL.md, but results look plausible
        (no obviously inflated meta-file tokens in top results).
      0.0: |
        No scope decision stated AND results contain clear evidence of
        inconsistency (e.g., "skill" or "frequency" in top 10 with high count),
        OR SKILL.md and results directly contradict each other.
```
