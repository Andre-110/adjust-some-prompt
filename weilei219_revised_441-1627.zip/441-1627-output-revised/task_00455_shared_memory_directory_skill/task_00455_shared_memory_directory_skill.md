---
id: task_00455_shared_memory_directory_skill
name: Shared Memory Directory with Skill Creation
category: Knowledge and Memory Management
subcategory: Memory and Context Management
difficulty: medium
grading_type: automated
grading_weights: {automated: 1.0}
timeout_seconds: 600
input_modality: text-only
external_dependency: none
workspace_files: []
skill_creation: true
---

## Prompt

I want a reusable setup guide for a shared memory space that multiple AI assistants can use to coordinate through the filesystem, and I also want the actual shared directory created.

Please do two things:

1. Create a reusable OpenClaw skill as a `SKILL.md` file that explains how to set up and document a shared memory directory for future projects.
2. Then create the actual shared directory at `~/.openclaw/shared/` (relative to the workspace: `.openclaw/shared/`) with a `README.md`.

Use the materials in `assets/` as the source of truth. The output should not just be generic documentation — it needs to reflect the actual design and constraints in those files.

A few things matter for the writeup:
- The shared space should explain its intended structure and operating rules in a way that multiple assistants could realistically follow.
- The documentation should account for the fact that not every assistant has the same permissions.
- If there are places where the materials suggest different defaults or special cases, handle that carefully rather than flattening everything into one vague rule.
- The skill should be reusable, but still concrete enough that someone applying it later would know what to create, what to document, and what pitfalls to watch for.

Do not create extra deliverables beyond the skill, the directory, and the README.

## Expected Behavior

The agent should produce the required files, but high-quality completion now depends on aligning them with the provided assets rather than writing generic shared-memory advice.

1. **Create a `SKILL.md` file** in the workspace root.
   - It must include YAML frontmatter with at least `name` and `description`.
   - It must be a reusable skill for setting up shared-memory directories, but grounded in the actual materials in `assets/`.
   - It should include actionable setup instructions, not just abstract principles.
   - It should instruct future users to:
     - create the shared directory at `~/.openclaw/shared/`
     - create a README
     - document the namespace structure from the provided configuration
     - respect role-based permissions
     - mention allowed file types
     - mention retention behavior
     - address concurrent write handling in a practical way
   - A strong answer will correctly preserve important distinctions from the assets:
     - namespaces are `global`, `projects`, `handoffs`, `scratch`
     - `assistant-gamma` is read-only and must not be described as a writer
     - scratch retention is 24 hours, while other namespaces default to 90 days
     - concurrency guidance should reflect atomic writes / response-file pattern / handoffs usage

2. **Create the directory `.openclaw/shared/`**.

3. **Create `.openclaw/shared/README.md`** that is specific and operational.
   - It should explain the purpose of the shared memory space.
   - It should describe the actual namespace structure reflected by the assets, rather than a made-up structure.
   - It should describe permissions accurately:
     - read-write role can create/read/update but not delete
     - read-only role can read but not create/update/delete
     - `assistant-gamma` should be treated consistently with that read-only role
   - It should describe file conventions and allowed file types in a way consistent with the assets.
   - It should include retention guidance without collapsing the special case:
     - `scratch/` is cleaned after 24 hours
     - other namespaces default to 90 days
   - It should include usable multi-assistant conventions for concurrent work:
     - read before writing
     - prefer atomic writes
     - avoid editing another agent's file directly
     - use handoffs/ for task passing or response-file patterns

4. **Important traps / edge cases**
   - Generic README text that talks about “facts.md”, “preferences.md”, or “inbox/” but ignores the configured namespaces is not sufficient.
   - Stating or implying that all assistants can write is incorrect.
   - Claiming a single retention policy everywhere is incorrect.
   - Omitting concurrency guidance from the design doc is incomplete.
   - The assets include both broad file-format guidance and a more explicit allowlist; the safest correct output reflects the actual allowlist and can mention markdown/plain text as defaults without excluding the other allowed types.

## Grading Criteria

- [ ] `SKILL.md` exists with valid YAML frontmatter including `name` and `description`
- [ ] `SKILL.md` contains actionable setup instructions with concrete steps for creating the shared directory and README
- [ ] `SKILL.md` is aligned with asset-derived constraints: namespaces, permissions, file types, retention, concurrency
- [ ] `.openclaw/shared/` exists
- [ ] `.openclaw/shared/README.md` exists
- [ ] README accurately documents the configured namespace structure (`global`, `projects`, `handoffs`, `scratch`)
- [ ] README accurately documents role permissions, including the read-only limitation and the special case of `assistant-gamma`
- [ ] README documents file type expectations and allowed formats consistent with the assets
- [ ] README documents retention correctly, including the 24-hour `scratch/` exception and 90-day default elsewhere
- [ ] README includes practical multi-assistant coordination guidance consistent with the design doc’s concurrency section

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    import os
    import re
    import json

    scores = {
        "skill_md_frontmatter": 0.0,
        "skill_md_actionable_steps": 0.0,
        "skill_md_asset_alignment": 0.0,
        "shared_directory_exists": 0.0,
        "readme_exists": 0.0,
        "readme_namespace_accuracy": 0.0,
        "readme_permissions_accuracy": 0.0,
        "readme_file_types_accuracy": 0.0,
        "readme_retention_accuracy": 0.0,
        "readme_concurrency_guidance": 0.0,
    }

    def read_text(path):
        try:
            with open(path, "r", encoding="utf-8") as f:
                return f.read()
        except Exception:
            return ""

    # Load assets as source of truth for strict checks
    permissions_path = os.path.join(workspace_path, "assets", "config", "permissions.json")
    agents_path = os.path.join(workspace_path, "assets", "config", "agents.yaml")
    design_path = os.path.join(workspace_path, "assets", "docs", "shared-memory-design.md")

    permissions = {}
    try:
        with open(permissions_path, "r", encoding="utf-8") as f:
            permissions = json.load(f)
    except Exception:
        permissions = {}

    namespaces = permissions.get("shared_memory", {}).get("namespaces", [])
    allowed_types = permissions.get("shared_memory", {}).get("file_types_allowed", [])
    max_entries = permissions.get("shared_memory", {}).get("max_entries_per_namespace")

    # Parse retention from agents.yaml with regex to avoid external deps
    agents_text = read_text(agents_path)
    retention_days = None
    sync_interval_seconds = None
    gamma_read_only = False
    if agents_text:
        m = re.search(r"retention_days:\s*(\d+)", agents_text)
        if m:
            retention_days = m.group(1)
        m = re.search(r"sync_interval_seconds:\s*(\d+)", agents_text)
        if m:
            sync_interval_seconds = m.group(1)
        gamma_block = re.search(
            r"id:\s*assistant-gamma\b.*?memory_access:\s*([^\n]+)",
            agents_text,
            re.DOTALL,
        )
        if gamma_block and "read-only" in gamma_block.group(1).lower():
            gamma_read_only = True

    design_text = read_text(design_path).lower()

    # Find SKILL.md in root or common skill locations
    import glob as _glob
    skill_candidates = [os.path.join(workspace_path, "SKILL.md")] + \
        _glob.glob(os.path.join(workspace_path, "skills", "*", "SKILL.md")) + \
        _glob.glob(os.path.join(workspace_path, "*", "SKILL.md"))
    skill_path = next((p for p in skill_candidates if os.path.isfile(p)), None)
    skill_text = read_text(skill_path) if skill_path else ""
    skill_lower = skill_text.lower()

    # 1. SKILL.md frontmatter
    if skill_text:
        fm_match = re.match(r"^---\s*\n(.*?)\n---\s*", skill_text, re.DOTALL)
        if fm_match:
            fm_text = fm_match.group(1).lower()
            has_name = "name:" in fm_text
            has_desc = "description:" in fm_text
            if has_name and has_desc:
                scores["skill_md_frontmatter"] = 1.0
            elif has_name or has_desc:
                scores["skill_md_frontmatter"] = 0.5

    # 2. SKILL.md actionable steps
    if skill_text:
        step_lines = re.findall(r"^\s*(?:\d+\.\s+|\-\s+)", skill_text, re.MULTILINE)
        action_checks = [
            ".openclaw/shared" in skill_lower or "~/.openclaw/shared" in skill_lower,
            "readme" in skill_lower,
            ("create" in skill_lower or "mkdir" in skill_lower),
            ("write" in skill_lower or "document" in skill_lower),
        ]
        action_hits = sum(1 for x in action_checks if x)
        if len(step_lines) >= 3 and action_hits >= 4:
            scores["skill_md_actionable_steps"] = 1.0
        elif len(step_lines) >= 2 and action_hits >= 3:
            scores["skill_md_actionable_steps"] = 0.5

    # 3. SKILL.md asset alignment
    if skill_text:
        ns_hits = sum(1 for ns in namespaces if ns.lower() in skill_lower)
        file_type_hits = sum(1 for ext in allowed_types if ext.lower() in skill_lower)
        permission_hits = 0
        if "read-write" in skill_lower:
            permission_hits += 1
        if "read-only" in skill_lower:
            permission_hits += 1
        retention_ok = ("24 hour" in skill_lower or "24-hour" in skill_lower) and (
            (retention_days and retention_days in skill_lower) or "90 day" in skill_lower or "90-day" in skill_lower
        )
        concurrency_ok = any(
            phrase in skill_lower
            for phrase in ["atomic write", "temp file", "rename", "response file", "response files", "handoffs"]
        )
        if ns_hits == len(namespaces) and file_type_hits >= 4 and permission_hits == 2 and retention_ok and concurrency_ok:
            scores["skill_md_asset_alignment"] = 1.0
        elif ns_hits >= max(2, len(namespaces) - 1) and file_type_hits >= 2 and (permission_hits >= 1 or retention_ok or concurrency_ok):
            scores["skill_md_asset_alignment"] = 0.5

    # 4. Shared directory exists
    shared_dir = os.path.join(workspace_path, ".openclaw", "shared")
    if os.path.isdir(shared_dir):
        scores["shared_directory_exists"] = 1.0

    # 5. README exists
    readme_path = os.path.join(shared_dir, "README.md")
    readme_text = read_text(readme_path)
    readme_lower = readme_text.lower()
    if readme_text:
        scores["readme_exists"] = 1.0

    # 6. README namespace accuracy
    if readme_text:
        ns_hits = sum(1 for ns in namespaces if ns.lower() in readme_lower)
        if ns_hits == len(namespaces):
            scores["readme_namespace_accuracy"] = 1.0
        elif ns_hits >= max(2, len(namespaces) - 1):
            scores["readme_namespace_accuracy"] = 0.5

    # 7. README permissions accuracy
    if readme_text:
        has_rw = "read-write" in readme_lower
        has_ro = "read-only" in readme_lower
        rw_detail = all(term in readme_lower for term in ["can create", "can read", "can update"]) and (
            "cannot delete" in readme_lower or "can_delete: false" in readme_lower or "not delete" in readme_lower
        )
        ro_detail = (
            "cannot create" in readme_lower or "can create: false" in readme_lower or "not create" in readme_lower
        ) and (
            "cannot update" in readme_lower or "can update: false" in readme_lower or "not update" in readme_lower
        ) and ("can read" in readme_lower or "read access" in readme_lower)
        gamma_ok = ("assistant-gamma" in readme_lower and "read-only" in readme_lower) if gamma_read_only else True
        if has_rw and has_ro and rw_detail and ro_detail and gamma_ok:
            scores["readme_permissions_accuracy"] = 1.0
        elif (has_rw and has_ro) or gamma_ok:
            scores["readme_permissions_accuracy"] = 0.5

    # 8. README file types accuracy
    if readme_text:
        ext_hits = sum(1 for ext in allowed_types if ext.lower() in readme_lower)
        mentions_defaults = (".md" in readme_lower or "markdown" in readme_lower) and (
            ".txt" in readme_lower or "plain text" in readme_lower
        )
        if ext_hits == len(allowed_types) and mentions_defaults:
            scores["readme_file_types_accuracy"] = 1.0
        elif ext_hits >= 3:
            scores["readme_file_types_accuracy"] = 0.5

    # 9. README retention accuracy
    if readme_text:
        has_scratch_special = "scratch" in readme_lower and (
            "24 hour" in readme_lower or "24-hour" in readme_lower
        )
        has_default_retention = (
            (retention_days and retention_days in readme_lower) or "90 day" in readme_lower or "90-day" in readme_lower
        )
        if has_scratch_special and has_default_retention:
            scores["readme_retention_accuracy"] = 1.0
        elif has_scratch_special or has_default_retention:
            scores["readme_retention_accuracy"] = 0.5

    # 10. README concurrency guidance
    if readme_text:
        concurrency_hits = 0
        phrases = [
            "read before writing",
            "read-before-write",
            "atomic write",
            "temp file",
            "rename",
            "avoid modifying files written by other agents",
            "response file",
            "response files",
            "handoffs",
        ]
        for phrase in phrases:
            if phrase in readme_lower:
                concurrency_hits += 1

        if concurrency_hits >= 4:
            scores["readme_concurrency_guidance"] = 1.0
        elif concurrency_hits >= 2:
            scores["readme_concurrency_guidance"] = 0.5

    return scores
```

## LLM Judge Rubric

Use this rubric only if a semantic/manual review is needed in addition to automated checks.

### 1.0
- `SKILL.md` is clearly reusable, correctly structured, and operational rather than generic.
- It gives concrete setup steps and reflects the assets accurately: correct namespaces, role model, file types, retention, and concurrency handling.
- `README.md` reads like a real handoff document for multiple assistants, not a template full of filler.
- It correctly preserves key distinctions:
  - `assistant-gamma` is read-only
  - read-write users cannot delete
  - `scratch/` has a 24-hour cleanup rule while other namespaces default to 90 days
  - concurrency guidance includes atomic-write style handling and avoiding direct edits to another agent’s files
- No important contradictions or invented structures.

### 0.75
- Mostly correct and useful, but with minor omissions or mild imprecision.
- May miss one lower-priority asset detail (for example, incomplete file-type list or weak explanation of response-file patterns) while still getting the main structure, permissions, and retention model right.
- Still clearly grounded in the provided assets.

### 0.5
- Mixed quality.
- Produces the required files and some relevant content, but documentation is only partially aligned with assets.
- Typical examples:
  - uses some correct namespaces but invents others or omits one
  - mentions roles but does not clearly explain the permission boundaries
  - mentions retention but misses the `scratch/` exception
  - gives generic collaboration advice without concrete concurrency handling
- Looks plausible, but would require manual correction before real use.

### 0.25
- Superficially formatted but largely generic.
- Could pass a weak keyword check while failing the actual task intent.
- Examples:
  - README focuses on generic files like `facts.md` / `preferences.md` instead of the configured namespaces
  - implies everyone can write
  - collapses retention into a single blanket rule
  - ignores concurrency issues from the design doc
- Limited evidence that the assets were actually read.

### 0.0
- Missing core deliverables, or content is materially incorrect.
- Examples:
  - no `SKILL.md` or no README
  - shared directory not created
  - documentation contradicts the assets on permissions or structure
  - output is too empty to be operational
