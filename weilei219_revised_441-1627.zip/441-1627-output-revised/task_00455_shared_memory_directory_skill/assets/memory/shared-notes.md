# Shared Notes

These are notes from previous sessions about setting up shared infrastructure.

## 2025-01-15
- Discussed shared memory approach with the team
- Decided on `~/.openclaw/shared/` as the canonical path
- Need to add a README explaining conventions

## 2025-01-12
- Looked into how multi-agent setups handle context sharing
- Options considered:
  - Shared filesystem directory (simple, works well)
  - Redis-backed store (overkill for now)
  - SQLite database (good but harder to inspect)
- Conclusion: start with filesystem, migrate later if needed

## Open Questions
- Should we namespace by agent ID?
- How to handle concurrent writes?
- Retention policy for old entries?
