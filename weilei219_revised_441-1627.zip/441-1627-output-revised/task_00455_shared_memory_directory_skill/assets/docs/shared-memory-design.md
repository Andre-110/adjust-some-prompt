# Shared Memory Design Document

## Overview

This document outlines the design for a shared memory system that allows multiple OpenClaw assistants to exchange information through a common filesystem directory.

## Goals

1. Enable assistants to share context, handoffs, and notes
2. Keep the implementation simple (filesystem-based)
3. Support namespacing to organize different types of shared data
4. Provide basic access control through role-based permissions

## Architecture

```
~/.openclaw/shared/
├── README.md              # Explains purpose and conventions
├── global/                # Shared across all agents
│   ├── daily-briefing.md
│   └── announcements.md
├── projects/              # Project-specific shared context
│   ├── project-a/
│   └── project-b/
├── handoffs/              # Task handoffs between agents
│   ├── task-001.md
│   └── task-002.md
└── scratch/               # Temporary working space
    └── .gitkeep
```

## File Conventions

- All files should be Markdown (.md) or plain text (.txt) by default
- JSON and YAML are acceptable for structured data
- Each file should include a YAML frontmatter header with:
  - `author`: agent ID that created the file
  - `created`: ISO 8601 timestamp
  - `updated`: ISO 8601 timestamp (if modified)
  - `tags`: optional list of tags

## Concurrency

Since multiple agents may read/write simultaneously:
- Use atomic writes (write to temp file, then rename)
- Avoid modifying files written by other agents; create response files instead
- Use the handoffs/ namespace for task passing

## Retention

- Files in scratch/ are cleaned after 24 hours
- Files in other namespaces are retained for 90 days by default
- Critical files can be pinned by adding `pinned: true` to frontmatter

## Status

- [x] Design approved
- [ ] Directory structure created
- [ ] README written
- [ ] Integration tested with multi-agent setup
