---
id: task_1090_trading_strategy_and
name: Trading Strategy Analysis and Position Decision for XYZT
category: Finance
grading_type: hybrid
difficulty: hard
timeout_seconds: 600
workspace_files:
- source: task_1090_trading_strategy_and/data/market/XYZT_ohlcv_daily.csv
  dest: data/market/XYZT_ohlcv_daily.csv
- source: task_1090_trading_strategy_and/data/market/XYZT_ohlcv_intraday.csv
  dest: data/market/XYZT_ohlcv_intraday.csv
- source: task_1090_trading_strategy_and/data/signals/signal_report_2024-12-13.json
  dest: data/signals/signal_report_2024-12-13.json
- source: task_1090_trading_strategy_and/data/portfolio/current_positions.json
  dest: data/portfolio/current_positions.json
- source: task_1090_trading_strategy_and/data/risk/risk_parameters.yaml
  dest: data/risk/risk_parameters.yaml
- source: task_1090_trading_strategy_and/data/signals/sentiment_analysis.json
  dest: data/signals/sentiment_analysis.json
- source: task_1090_trading_strategy_and/data/market/sector_performance.csv
  dest: data/market/sector_performance.csv
- source: task_1090_trading_strategy_and/data/market/economic_calendar.json
  dest: data/market/economic_calendar.json
- source: task_1090_trading_strategy_and/data/risk/correlation_matrix.csv
  dest: data/risk/correlation_matrix.csv
- source: task_1090_trading_strategy_and/reports/backtest_summary_XYZT_sell.csv
  dest: reports/backtest_summary_XYZT_sell.csv
- source: task_1090_trading_strategy_and/data/signals/technical_indicators.json
  dest: data/signals/technical_indicators.json
- source: task_1090_trading_strategy_and/logs/model_execution_2024-12-13.log
  dest: logs/model_execution_2024-12-13.log
- source: task_1090_trading_strategy_and/data/market/options_chain_XYZT.csv
  dest: data/market/options_chain_XYZT.csv
- source: task_1090_trading_strategy_and/data/signals/peer_comparison.csv
  dest: data/signals/peer_comparison.csv
grading_weights:
  automated: 0.55
  llm_judge: 0.45
source_query: 'Given the following signal, market data, and portfolio status, decide
  whether to trade (BUY/SELL/HOLD), choose a position size as a percentage of available
  capital (0–20%), assess risk (low/medium/high), and provide a detailed rationale
  and key factors. Signal: SELL (confidence: MEDIUM), patterns: d'
source_line_number: 1090
subcategory: Trading Strategy and Backtesting
---
## Prompt

End of day Friday, and I need a decision memo on XYZT before Monday’s open.

We already hold 800 shares and the position is underwater. A fresh model output came in after today’s close, but not every file in this workspace was generated at the same time or even from the same system, so I do not want a surface-level recap. I want a recommendation that shows you actually reconciled the data.

Please write your memo to `trading_decision.md`.

What I need from it:

- A decision on the existing XYZT position: reduce, fully exit, hold, or add
- Position-sizing language that is unambiguous for an *existing* position (for example, sell X% of current shares, fully liquidate, or explicitly keep current size). If you express sizing in portfolio terms instead, make clear whether that is current weight, target weight, or incremental change
- Risk rating for the XYZT position
- Specific price levels that matter for execution/risk management
- A rationale that ties together technicals, portfolio/risk constraints, macro/event risk, and signal reliability
- Any data problems, stale inputs, unit issues, or cross-file inconsistencies that could change the conclusion

A few constraints:

- This is not a greenfield trade idea; you are evaluating an existing losing position into a major macro event
- You should not assume every bullish or bearish-looking file deserves equal weight
- If you think a HOLD is still justified, it must be defended as a deliberate risk decision rather than inertia
- If you think the backtest is useful, sanity-check the units before leaning on it
- If you use peer comparison at all, make sure the scale/units are internally plausible

Use the workspace files only. The final memo should read like something I could forward to a PM or risk manager without rewriting.

## Expected Behavior

The strongest responses will synthesize the workspace into a coherent position decision while handling ambiguity rather than mechanically following the most obvious signal.

### Ground Truth the agent should recover

1. **Current market state is bearish, but not one-dimensional**
   - `data/market/XYZT_ohlcv_daily.csv` shows a major deterioration from the September highs (~95) into a 2024-12-13 close of **66.80**.
   - `data/market/XYZT_ohlcv_intraday.csv` shows a morning push that peaks at **70.37** and then fades steadily into a **66.80** close, consistent with failed upside participation.
   - `data/signals/technical_indicators.json` confirms:
     - RSI(14) **28.4** = oversold
     - MACD interpretation = **bearish_crossover**
     - Bollinger position = **below_lower_band**
     - ADX **38.5** = strong trend
     - bearish_signals **9** vs bullish_signals **1**
   - Correct interpretation: this is a **strong downtrend with oversold bounce risk**, not a clean “oversold means buy” setup.

2. **Current position/risk math matters**
   - `data/portfolio/current_positions.json` gives:
     - XYZT shares = **800**
     - avg cost = **82.30**
     - current price = **66.80**
     - unrealized P&L = **-12,400**
     - weight = **10.69%**
     - portfolio total value = **500,000**
   - The unrealized loss should be either cited from file or correctly recomputed:
     - **800 × (66.80 - 82.30) = -12,400**
   - `data/risk/risk_parameters.yaml`:
     - max single loss = **5%** of portfolio = **25,000**
     - max sector exposure = **35%**
     - current sector exposure Technology = **28.5%**
   - Correct interpretation:
     - The position is **not yet breaching** the desk’s hard single-loss limit, but it is already a meaningful loser and sits inside a sector cluster with correlation overlap.
     - This is not a case for complacency simply because the formal limit has not yet been breached.

3. **Correlation and sector concentration worsen the context**
   - `data/risk/correlation_matrix.csv` shows XYZT–ABCD correlation of **0.78**, above the risk parameter threshold of **0.70**.
   - Technology is already **28.5%** of portfolio by risk parameters and is the **worst 30-day sector performer at -8.2%** in `data/market/sector_performance.csv`.
   - Correct interpretation: even if absolute sector exposure is below the 35% cap, the combination of **same-sector concentration + elevated pairwise correlation + weak sector tape** supports de-risking ahead of Monday.

4. **Macro/event risk is material**
   - `data/market/economic_calendar.json` includes:
     - **2024-12-16 Fed Interest Rate Decision** (HIGH impact)
     - **2024-12-16 FOMC Press Conference** (HIGH impact)
   - The description text is slightly noisy/internally awkward (`previous: 4.75%`, `consensus: hold_at_4.50%`, description says market expects a 25bp cut to 4.50%), so the agent should not over-parse the exact policy path.
   - Correct interpretation: regardless of whether the market frames this as “hold at 4.50%” or “25bp cut to 4.50%,” **Monday carries major event volatility**, which raises the bar for holding a weak, losing tech position.

### Trap handling and correct reasoning path

#### Trap 1: Outdated sentiment report — highest importance
- `data/signals/sentiment_analysis.json` is dated **2024-11-28T09:00:00Z** and references `current_price: 78.50`.
- The live decision context is 2024-12-13 with current price **66.80** in the signal report, technical indicators, portfolio file, and OHLCV close.
- The sentiment file is therefore **stale by roughly two weeks and ~11.70 points / ~14.9% away from current price**.
- Correct handling:
  - Explicitly flag it as stale/outdated and lower priority
  - Explain why higher confidence on a stale report does **not** override fresher market-state evidence
  - Avoid using it as a primary bullish rebuttal
- This trap matters the most because mishandling it can directly flip the trade conclusion.

#### Trap 2: Backtest unit mismatch — medium importance
- In `reports/backtest_summary_XYZT_sell.csv`, the column `return_pct` is mislabeled; the values behave like **basis points**, not percentages.
- From the actual file:
  - There are **25 trades**
  - **14** rows have positive `return_pct`, so win rate = **14/25 = 56%**
  - Sum of `return_pct` values = **6,296**
  - Average = **6,296 / 25 = 251.84 bps = 2.5184% average trade return**
- Correct handling:
  - The agent should identify that `280`-style numbers cannot reasonably mean 280%
  - It should interpret the backtest returns as approximately **2.5% average**, or “roughly 2.5–2.8% depending on rounding/quick estimate,” but it must **not** present them as hundreds of percent
  - It should state a sensible win-rate definition:
    - For this file, **positive `return_pct` corresponds to profitable SELL signals**, giving **56%**
- High-quality responses will also note that a ~56% win rate with ~2.5% average return supports the signal as **moderately useful**, not “sure thing” evidence.

#### Trap 3: Peer comparison market-cap unit anomaly — lowest importance
- In `data/signals/peer_comparison.csv`, `market_cap_B` implies billions, but `PQRS` has value **4200**.
- If treated literally, that would imply **$4.2T**, which is implausible and inconsistent with the rest of the peer set.
- Correct handling:
  - Flag the unit inconsistency if discussing peer data
  - Infer that `4200` is likely in millions (**~$4.2B**) or otherwise malformed
- Missing this trap should matter less than missing Trap 1 or Trap 2 unless the memo relies heavily on peer comparison.

### What counts as a correct final decision

This task intentionally allows more than one professionally defensible answer, but not all answers are equally strong.

1. **Best-supported recommendation: reduce materially or fully exit**
   - The most evidence-consistent conclusion is to **reduce or close** the XYZT position before Monday’s event risk.
   - Strong answers usually recommend one of:
     - **full exit (sell 100% / 800 shares)**, or
     - **partial reduction** such as selling **50%–75% of the existing position**, often paired with a stop on the remainder
   - Why this is strongest:
     - strong bearish trend
     - existing loss
     - high-impact Fed event
     - high correlation with ABCD
     - weak Technology sector backdrop
     - only medium-confidence signal and only moderate backtest edge

2. **Defensible but lower-scoring alternative: disciplined HOLD**
   - A HOLD can still be considered logically coherent **only if** it is framed as a deliberate risk-managed exception, not passive indecision.
   - To be defensible, a HOLD should include all of:
     - explicit acknowledgement that the technical regime is still bearish
     - explicit acknowledgement that oversold conditions create short-term bounce potential
     - a **hard stop around 65.00** (or a clearly justified nearby level tied to support)
     - clear discussion of Monday Fed/event risk
     - no suggestion of adding size ahead of the event
   - A HOLD without a hard stop, or a vague “wait and see,” should score materially lower.

3. **Clearly incorrect direction**
   - A **BUY/add** recommendation is inconsistent with the evidence unless extraordinarily hedged and justified, and even then should score poorly.
   - Any answer that treats stale bullish sentiment or “280% average return” as key support for adding risk is incorrect.

### What the memo should include operationally

- A clear action statement for the **existing** position
- Unambiguous sizing language:
  - e.g. “sell 400 shares (50% of current position),” “fully liquidate all 800 shares,” or “hold current 800 shares; do not add”
- Risk rating should resolve to **HIGH** for the XYZT position/context
- Concrete price levels should be tied to actual files:
  - support around **65.00**
  - resistance around **72.50**
  - signal-report stop-loss suggestion around **70.50** is acceptable if used correctly in context
- At least **two** data quality/inconsistency issues should be flagged, ideally among:
  - stale sentiment report
  - backtest bps/% label mismatch
  - peer market-cap unit anomaly
  - minor wording inconsistency inside the economic calendar regarding the Fed path

## Grading Criteria

- [ ] The output file `trading_decision.md` exists and contains a structured trading decision memo
- [ ] The memo correctly characterizes XYZT as a bearish trend with oversold bounce risk, using multiple technical facts rather than a single indicator
- [ ] The memo either cites or correctly computes the existing XYZT unrealized loss at approximately **-$12,400**, and anchors it to the current position data
- [ ] The memo correctly identifies the sentiment report as stale/outdated by referencing its **2024-11-28** timestamp and/or stale **$78.50** price versus current **$66.80**
- [ ] The memo correctly identifies the backtest unit mismatch and interprets the backtest as roughly **56% win rate** and **~2.5% average return (bps, not hundreds of percent)**
- [ ] The memo discusses XYZT’s **0.78** correlation with ABCD and connects it to Technology concentration/risk overlap
- [ ] The memo treats the **2024-12-16 Fed decision / FOMC event risk** as a material factor
- [ ] The memo gives a clear action on the existing position and uses sizing language that distinguishes **current position**, **target weight**, and/or **amount to sell**
- [ ] The memo explicitly assigns **HIGH** risk to the XYZT position/context
- [ ] The memo flags at least two genuine data quality or cross-file consistency issues
- [ ] The memo does **not** recommend adding to the position; a risk-managed HOLD can receive partial credit, but only if it includes a concrete stop and event-risk reasoning
- [ ] The overall recommendation is logically consistent with the evidence and the memo does not let stale or malformed data dominate the conclusion

## Automated Checks

```python
import os
import re
import csv
from pathlib import Path

def grade(transcript: list, workspace_path: str) -> dict:
    """Grade the trading_decision.md output file."""
    result = {
        "output_file_exists": 0.0,
        "action_not_add": 0.0,
        "existing_position_sizing_is_unambiguous": 0.0,
        "risk_rating_high": 0.0,
        "identifies_outdated_sentiment_with_evidence": 0.0,
        "mentions_fed_decision_risk": 0.0,
        "xyzt_loss_math_present": 0.0,
        "mentions_correlation_overlap": 0.0,
        "oversold_and_bearish_acknowledged": 0.0,
        "structured_memo_present": 0.0,
        "backtest_unit_mismatch_identified": 0.0,
        "backtest_correct_interpretation_present": 0.0,
    }

    output_file = Path(workspace_path) / "trading_decision.md"
    if not output_file.exists():
        return result

    result["output_file_exists"] = 1.0
    content = output_file.read_text(encoding="utf-8", errors="replace")
    content_lower = content.lower()
    paragraphs = [p for p in re.split(r'\n\s*\n', content) if p.strip()]

    # Ground truth from assets for robust checks
    backtest_file = Path(workspace_path) / "reports" / "backtest_summary_XYZT_sell.csv"
    avg_bps = None
    avg_pct = None
    win_rate_pct = None
    if backtest_file.exists():
        rows = []
        with backtest_file.open("r", encoding="utf-8", errors="replace", newline="") as f:
            reader = csv.DictReader(f)
            for row in reader:
                try:
                    rows.append(float(row["return_pct"]))
                except Exception:
                    pass
        if rows:
            avg_bps = sum(rows) / len(rows)
            avg_pct = avg_bps / 100.0
            wins = sum(1 for x in rows if x > 0)
            win_rate_pct = 100.0 * wins / len(rows)

    # 1. action_not_add
    # Pass if recommendation/action explicitly says reduce/sell/trim/exit/close/hold,
    # and does not explicitly recommend add/buy/increase.
    action_context = re.search(
        r'(?is)(recommendation|decision|action|trade plan|position decision)[^\n:]{0,40}[:\s\-–]*([^\n]+)',
        content
    )
    bearish_or_hold = bool(re.search(r'\b(reduce|sell|trim|exit|close|hold)\b', content_lower))
    explicit_add = bool(re.search(r'(?i)\b(recommend(?:ation)?|decision|action)[^.\n]{0,80}\b(add|buy|increase)\b', content))
    if bearish_or_hold and not explicit_add:
        result["action_not_add"] = 1.0

    # 2. existing_position_sizing_is_unambiguous
    sizing_patterns = [
        r'(?i)\b(sell|reduce|trim|exit|close)\b[^.\n]{0,60}\b(25|33|50|75|100)(?:\.0+)?\s*%\s+of\s+(?:the\s+)?(?:current|existing)\s+(?:position|shares?)',
        r'(?i)\b(?:sell|reduce|trim|exit|close)\b[^.\n]{0,60}\b(200|400|600|800)\s+shares?\b',
        r'(?i)\bhold\b[^.\n]{0,80}\b(?:current|existing)\s+(?:position|800\s+shares?)\b',
        r'(?i)\btarget\s+(?:weight|position)\b[^.\n]{0,40}\b\d+(?:\.\d+)?\s*%\b',
    ]
    if any(re.search(p, content) for p in sizing_patterns):
        result["existing_position_sizing_is_unambiguous"] = 1.0

    # 3. risk_rating_high
    risk_patterns = [
        r'(?i)\b(risk assessment|risk level|risk rating|position risk)\b[^.\n:]{0,20}[:\s\-–]*high\b',
        r'(?i)\bhigh[-\s]?risk\b[^.\n]{0,60}\bxyzt\b',
        r'(?i)\bxyzt\b[^.\n]{0,60}\bhigh[-\s]?risk\b',
        r'(?i)\b风险\b[:：]?\s*高\b',
    ]
    if any(re.search(p, content) for p in risk_patterns):
        result["risk_rating_high"] = 1.0

    # 4. identifies_outdated_sentiment_with_evidence
    has_sentiment = "sentiment" in content_lower
    has_stale_word = bool(re.search(r'\b(outdated|stale|old|not current)\b', content_lower))
    has_old_date = "2024-11-28" in content
    has_old_price = "78.50" in content or "$78.50" in content
    has_current_price = "66.80" in content or "$66.80" in content
    if has_sentiment and has_stale_word and (has_old_date or has_old_price) and has_current_price:
        result["identifies_outdated_sentiment_with_evidence"] = 1.0

    # 5. mentions_fed_decision_risk
    for para in paragraphs:
        pl = para.lower()
        if ("fed" in pl or "fomc" in pl) and ("risk" in pl or "volatility" in pl or "event" in pl):
            result["mentions_fed_decision_risk"] = 1.0
            break

    # 6. xyzt_loss_math_present
    has_loss_amount = bool(re.search(r'(?i)(-\$?\s?12[, ]?400|\$?\s?12[, ]?400\s+(?:loss|unrealized loss)|unrealized[^.\n]{0,30}12[, ]?400)', content))
    has_basis_terms = ("800" in content and ("82.30" in content or "$82.30" in content) and ("66.80" in content or "$66.80" in content))
    if has_loss_amount or has_basis_terms:
        result["xyzt_loss_math_present"] = 1.0

    # 7. mentions_correlation_overlap
    corr_ok = (
        ("0.78" in content or ".78" in content) and
        "abcd" in content_lower and
        ("correlation" in content_lower or "overlap" in content_lower)
    )
    if corr_ok:
        result["mentions_correlation_overlap"] = 1.0

    # 8. oversold_and_bearish_acknowledged
    tech_ok = (
        (("rsi" in content_lower) and ("28.4" in content or "oversold" in content_lower)) and
        (("macd" in content_lower and "bearish" in content_lower) or ("below lower band" in content_lower) or ("downtrend" in content_lower))
    )
    if tech_ok:
        result["oversold_and_bearish_acknowledged"] = 1.0

    # 9. structured_memo_present
    heading_count = len(re.findall(r'(?m)^#{1,6}\s+\S+', content))
    if heading_count >= 3:
        result["structured_memo_present"] = 1.0
    else:
        # fallback for strong non-markdown structure
        labels = sum(bool(re.search(p, content_lower)) for p in [
            r'\brecommendation\b', r'\brationale\b', r'\brisk\b', r'\btechnical\b', r'\bmacro\b'
        ])
        if labels >= 3:
            result["structured_memo_present"] = 1.0

    # 10. backtest_unit_mismatch_identified
    mismatch_terms = (
        ("basis points" in content_lower or "bps" in content_lower or "bp " in content_lower or "b.p." in content_lower) and
        ("return_pct" in content_lower or "%" in content or "percent" in content_lower) and
        ("mismatch" in content_lower or "mislabel" in content_lower or "labeled" in content_lower or "not percent" in content_lower or "unit" in content_lower)
    )
    if mismatch_terms:
        result["backtest_unit_mismatch_identified"] = 1.0

    # 11. backtest_correct_interpretation_present
    has_winrate = False
    has_avg_return = False
    if win_rate_pct is not None:
        has_winrate = bool(re.search(r'(?i)\b56\s*%|\b56\.0\s*%|\b14\s*/\s*25\b', content))
    if avg_pct is not None:
        has_avg_return = bool(re.search(r'(?i)\b2\.[45-8]\d?\s*%|\b251\.84\s*bps\b|\b252\s*bps\b|\b2\.5184\s*%', content))
    no_280_percent = not bool(re.search(r'(?i)\b280\s*%|\b280\s+percent\b|\b251\.84\s*%\b|\b252\s*%\b', content))
    if has_winrate and has_avg_return and no_280_percent:
        result["backtest_correct_interpretation_present"] = 1.0

    return result
```

## LLM Judge Rubric

### Criterion 1: Depth and Rigor of Cross-Source Synthesis (Weight: 35%)
**Score 1.0**: The memo integrates nearly all relevant core files into a single decision framework and explicitly reconciles numbers across files rather than merely listing them. It correctly aligns the latest close/current price at **66.80** across market data, signal, technicals, and portfolio context; correctly cites or recomputes the **-$12,400** unrealized loss from the actual position terms; connects the **0.78** XYZT–ABCD correlation to Technology concentration and the **-8.2%** sector backdrop; and treats the Fed calendar as an event-risk overlay rather than an isolated fact. The analysis shows prioritization of evidence and explains conflicts between files.
**Score 0.75**: The memo uses most of the important files and includes several accurate cross-file checks, but one meaningful reconciliation is missing or only implicit (for example, it mentions the unrealized loss without tying it to the share/price math, or mentions sector weakness without connecting it to portfolio concentration). The overall synthesis is still coherent and data-grounded.
**Score 0.5**: The memo references the major categories of data, but the sections remain mostly siloed. It may summarize technicals, portfolio, and macro separately without clearly showing how they combine into the recommendation. Some important numbers are cited, but cross-file consistency checking is weak or incomplete.
**Score 0.25**: The memo uses only a subset of the provided materials and relies heavily on generic trading language. Numerical claims are sparse, weakly tied to the actual files, or not reconciled across sources.
**Score 0.0**: The memo is largely generic, unsupported, or hallucinated, with little evidence that the workspace files were actually analyzed.

### Criterion 2: Trap Detection Quality and Decision Impact Weighting (Weight: 40%)
**Important weighting note:** Trap importance is **Trap 1 > Trap 2 > Trap 3**. Missing Trap 1 is a major failure. Missing Trap 3 is less serious unless peer data is used materially in the recommendation.

**Score 1.0**: The memo correctly handles **Trap 1** and **Trap 2**, and also flags **Trap 3** if peer data is used or explicitly notes it as a lower-priority inconsistency. It explicitly explains that the sentiment report is stale because it is dated **2024-11-28** and tied to **$78.50** rather than the current **$66.80**, and explains why its higher confidence should not dominate fresher evidence. It also correctly identifies the backtest return-unit problem as a bps/% mismatch, gives a valid interpretation such as **56% win rate** and **~2.5% average return**, and explains how misreading it would overstate signal quality. If peer comparison is discussed, it flags the **4200** market-cap anomaly as implausible under a billions label. The memo makes clear how these corrections affect the final decision.
**Score 0.75**: The memo **must correctly handle Trap 1** and also correctly handle **either Trap 2 or Trap 3**, with Trap 2 preferred. A typical 0.75 answer properly de-prioritizes the stale sentiment report and correctly interprets the backtest in bps, but may omit the peer market-cap anomaly. If Trap 1 is not correctly handled, the score cannot exceed 0.5.
**Score 0.5**: The memo handles **Trap 1 only**, or partially handles Trap 1 and Trap 2 but with incomplete implications. Example: it notices the sentiment file is old but does not explain why that changes evidence weighting; or it says the backtest “looks too high” without translating it into a correct approximate return scale. This band may also apply if Trap 2 is handled well but Trap 1 is mishandled, since Trap 1 is more decision-critical.
**Score 0.25**: The memo vaguely mentions “data quality issues” or notices something odd in one file, but does not resolve any major trap correctly, or resolves only low-impact Trap 3 while missing Trap 1. The flawed data may still influence the conclusion.
**Score 0.0**: The memo fails to detect the critical traps and materially relies on flawed inputs — especially if it treats the stale bullish sentiment as current evidence or interprets backtest returns as hundreds of percent.

### Criterion 3: Professional Memo Quality, Trade Framing, and Boundary Handling (Weight: 25%)
**Score 1.0**: The memo is polished and decision-ready, with a clear recommendation near the top, explicit treatment of the fact that this is an **existing losing position**, and unambiguous sizing language (e.g. “sell 400 shares / 50% of current position,” “fully exit all 800 shares,” or “hold current size; do not add”). It assigns **HIGH** risk appropriately, gives concrete levels tied to the files (such as **65.00** support/stop context and **72.50** resistance), and handles edge cases thoughtfully: it acknowledges oversold bounce risk, explains why that does or does not justify holding, and if recommending HOLD, includes a hard stop and event-risk logic. The recommendation is balanced, operationally usable, and logically consistent.
**Score 0.75**: The memo is professional and mostly actionable, with a clear recommendation and workable trade parameters. It acknowledges at least one important counterargument (usually oversold conditions) and resolves it reasonably. Minor ambiguity may remain around exact sizing language or level selection, but the decision framework is still coherent.
**Score 0.5**: The memo has a recognizable structure and a recommendation, but one of the following is materially weak: sizing is ambiguous, levels are not well justified, the risk rating is vague, or the recommendation does not fully grapple with the oversold/event-risk tension. A HOLD without a concrete stop usually belongs here at best.
**Score 0.25**: The memo is disorganized or operationally weak. Recommendation language is vague (“be cautious,” “monitor closely”), sizing is not actionable, or the document ignores obvious counterarguments and boundary conditions. The result would need substantial editing before use.
**Score 0.0**: The memo lacks a coherent recommendation, gives an obviously inconsistent direction (especially adding risk without justification), or is not usable as a professional decision document.
