---
id: task_228_openclaw_system_status_user_notification
name: OpenClaw System Status User Notification
category: Knowledge Management
subcategory: Document Management
difficulty: easy
external_dependency: none
verification_method: output-check
input_modality: text-only
grading_type: llm_judge
timeout_seconds: 120
workspace_files: []
source_line_number: 6706
source_query: "把下面这份 OpenClaw 系统状态报告改写成一段要发给用户的简洁、友好通知：说明当前有可用更新、哪个 Cron 任务失败以及连续错误次数，并总结系统健康与安全提醒；不要重复内容。  📊 OpenClaw 系统状态报告 ⏰ 2026-02-23 12:17 (Asia/Shanghai)  ✅ Cron 任务状态 • 启用任务：9/9 • 失败任务：1 ⚠️  📋 任务列表： • glm-unified-sample — 每 5 分钟 ✅ • model-failover-watchdog — 每 5 分钟 ✅ • qmd-embed-every-2h — 每 2 小时 ✅ • system-status-every-2h — 每 2 小时 ❌ (2 次连续错误) • memory-janitor-daily — 每天 01:00 ✅ • knowledge-compounder-daily — 每天 01:30 ✅ • cleanup-exec-sessions-daily — 每天 02:00 ✅ • crypto-price-daily — 每天 08:30 ✅ • gl..."
---

## Prompt

Please rewrite the following OpenClaw system status report into a short, friendly notification intended for end users.

Requirements:
- Mention that an update is available, including the version number
- Mention which cron task failed and how many consecutive errors it has
- Briefly summarize overall system health
- Mention the security reminders in a user-friendly way
- Keep it concise
- Do not repeat information
- Output only the notification text

Here is the report:

```text
📊 OpenClaw System Status Report
⏰ 2026-02-23 12:17 (Asia/Shanghai)

✅ Cron Task Status
• Enabled tasks: 9/9
• Failed tasks: 1 ⚠️

📋 Task List:
• glm-unified-sample — every 5 min ✅
• model-failover-watchdog — every 5 min ✅
• qmd-embed-every-2h — every 2 hours ✅
• system-status-every-2h — every 2 hours ❌ (2 consecutive errors)
• memory-janitor-daily — daily 01:00 ✅
• knowledge-compounder-daily — daily 01:30 ✅
• cleanup-exec-sessions-daily — daily 02:00 ✅
• crypto-price-daily — daily 08:30 ✅
• glm-unified-report — daily 08:30 ✅

🖥️ System Health
• Gateway: ✅ Running (pid 11951)
• Update: ⚠️ Available (2026.2.22-2)
• Sessions: 40 active
• Memory index: 1645 files

⚠️ Security Alerts
• Warning: Reverse proxy headers not trusted
• Warning: Exec sandbox mode disabled
```

## Expected Behavior

The agent should:

1. Write a short notification suitable for sending directly to users.
2. Clearly mention that an update is available and include version `2026.2.22-2`.
3. Identify the failed cron task as `system-status-every-2h`.
4. State that the task has had `2 consecutive errors`.
5. Provide a brief overall health summary, such as:

   * the gateway is running
   * most scheduled tasks are healthy / only one task is failing
6. Include both security reminders:

   * reverse proxy headers are not trusted
   * exec sandbox mode is disabled
7. Present the security items in a calm, user-friendly way rather than as an alarmist technical dump.
8. Avoid repeating the same information or restating the same issue multiple times.
9. Output plain notification text only, with no bullets required unless naturally used.

Trap handling expected from the model:

* Do not omit the update version number.
* Do not omit the failed cron task name.
* Do not omit the consecutive error count.
* Do not drop either security reminder.
* Do not turn the response into a raw copy of the source report.
* Do not make the message overly technical or overly alarming.

Tested capabilities:

* information extraction
* concise rewriting
* tone transformation
* user-facing summarization

## Grading Criteria

* [ ] Mentions the available update and includes version `2026.2.22-2`
* [ ] Correctly identifies the failed cron task as `system-status-every-2h`
* [ ] States that the failed task has `2 consecutive errors`
* [ ] Summarizes overall system health in a reassuring but accurate way
* [ ] Mentions both security reminders
* [ ] Uses a friendly, concise, user-facing tone
* [ ] Avoids redundancy and unnecessary repetition

## LLM Judge Rubric

### Dimension 1: Key Information Accuracy (35%)

* **1.0**: Includes all critical facts correctly: update available with version `2026.2.22-2`, failed task `system-status-every-2h`, `2 consecutive errors`, and both security reminders.
* **0.75**: Includes most critical facts correctly, with only one minor omission or slight wording issue.
* **0.5**: Includes some key facts, but misses an important required item such as the exact version, task name, error count, or one of the security reminders.
* **0.25**: Includes only limited correct information and misses multiple key requirements.
* **0.0**: Fails to convey the required core information or contains major factual errors.

### Dimension 2: Conciseness and Non-Redundancy (25%)

* **1.0**: The message is concise, clear, and free of repetition.
* **0.75**: Mostly concise, with slight extra wording or minor redundancy.
* **0.5**: Noticeably wordy or somewhat repetitive, but still usable.
* **0.25**: Too verbose, repetitive, or cluttered for a user notification.
* **0.0**: Very repetitive or excessively long, failing the task requirement.

### Dimension 3: Friendly User-Facing Tone (20%)

* **1.0**: Reads like a polished, helpful user notification with approachable wording.
* **0.75**: Generally friendly and user-facing, though slightly stiff or internal in tone.
* **0.5**: Neutral and understandable, but not especially user-friendly.
* **0.25**: Too technical, awkward, or overly formal for end users.
* **0.0**: Not user-facing at all, or reads like raw internal notes/report output.

### Dimension 4: System Health and Security Framing (20%)

* **1.0**: Gives users a balanced summary of system health and includes both security reminders in a calm, understandable way.
* **0.75**: Covers health and security reasonably well, but one part is slightly under-explained or awkwardly phrased.
* **0.5**: Mentions health/security but lacks balance, clarity, or user-friendly framing.
* **0.25**: Mentions only part of the required health/security context or frames it poorly.
* **0.0**: Omits the health/security summary or presents it misleadingly.