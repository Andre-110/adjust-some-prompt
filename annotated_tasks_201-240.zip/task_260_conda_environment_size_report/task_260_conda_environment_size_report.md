---
id: task_260_conda_environment_size_report
name: Conda Environment Size Report
category: System Administration
subcategory: Storage and Data Management
difficulty: easy
external_dependency: none
verification_method: unit-test
input_modality: text-only
grading_type: automated
grading_weights:
  automated: 1.0
timeout_seconds: 120
workspace_files: []
source_line_number: 1932
source_query: "如何查看每个 conda 虚拟环境占用的磁盘大小（列出环境路径并统计大小）？"
---

## Prompt

Hey, I need to check how much disk space each of my conda environments is using. Can you write me a script that lists all conda envs with their paths and calculates the size of each one?

Save it as `check_env_sizes.sh` - it should output something like:
```
/home/user/miniconda3/envs/myenv: 1.2G
/home/user/miniconda3/envs/data_science: 3.5G
```

Just the path and human-readable size for each env, one per line. Oh and also save the output to `env_sizes.txt` when I run it.

## Expected Behavior

The agent should:
1. Create a bash script that uses `conda info --envs` or `conda env list` to get environment paths
2. Filter out comment lines (lines starting with `#`) from the conda output before processing
3. Calculate directory sizes using `du` with human-readable output
4. Format output as path: size pairs
5. Save results to `env_sizes.txt` when executed
6. Include the base environment in the output

Tested capabilities: conda knowledge, bash scripting, disk usage commands, output formatting.

**Trap handling — the agent should correctly navigate the following traps:**

- **Comment lines in conda output**: `conda info --envs` outputs header lines starting with `#` before the environment list. These must be filtered out (e.g., with `grep -v '^#'`) before passing paths to `du`. Failing to filter them will cause `du` to error on the `#` character or skip paths entirely.
- **Base environment path**: The base conda environment is listed as the path with `*` marker (e.g., `/home/user/miniconda3  *`). The script must strip the `*` and any trailing whitespace to extract a valid path. It should be included in the size report.

## Grading Criteria

- [ ] Script file `check_env_sizes.sh` exists
- [ ] Script uses conda command to list environments
- [ ] Script uses du or similar to calculate sizes
- [ ] Script outputs to env_sizes.txt
- [ ] Script has proper shebang line
- [ ] Script filters or handles comment lines from conda output

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    from pathlib import Path

    scores = {}
    ws = Path(workspace_path)

    script_file = ws / "check_env_sizes.sh"
    scores["script_exists"] = 1.0 if script_file.exists() else 0.0

    if not script_file.exists():
        scores["has_shebang"] = 0.0
        scores["uses_conda_command"] = 0.0
        scores["uses_du_command"] = 0.0
        scores["outputs_to_file"] = 0.0
        scores["filters_comments"] = 0.0
        return scores

    content = script_file.read_text(errors="ignore")
    content_lower = content.lower()

    first_line = content.split("\n")[0] if content else ""
    has_shebang = first_line.startswith("#!") and ("bash" in first_line or "sh" in first_line)
    scores["has_shebang"] = 1.0 if has_shebang else 0.0

    conda_patterns = ["conda info", "conda env list", "conda info --envs"]
    has_conda_cmd = any(p in content_lower for p in conda_patterns)
    scores["uses_conda_command"] = 1.0 if has_conda_cmd else 0.0

    du_patterns = ["du -sh", "du -h", "du --human", "du -s"]
    has_du_cmd = any(p in content_lower for p in du_patterns)
    scores["uses_du_command"] = 1.0 if has_du_cmd else 0.0

    scores["outputs_to_file"] = 1.0 if "env_sizes.txt" in content else 0.0

    # Check that comment lines from conda output are filtered
    filter_patterns = ["grep -v", "grep -E", "awk", "sed", "^#", "startswith"]
    has_filter = any(p in content for p in filter_patterns)
    scores["filters_comments"] = 1.0 if has_filter else 0.0

    return scores
```