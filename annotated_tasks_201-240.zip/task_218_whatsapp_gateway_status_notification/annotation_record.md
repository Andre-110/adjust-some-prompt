| 序号 | 修改项 | 修改原因 |
|---|---|---|
| 1  | 改写 Prompt            | 保持真实用户通知写作场景，减少“题解式”提示，避免把期望表达方式说得过死                                                           |
| 2  | 重写 Expected Behavior | 补充完整解题路径、信息取舍原则、陷阱说明和 Ground Truth 范围                                                          |
| 3  | 重写 Grading Criteria  | 改成 6 条独立、可验证标准，覆盖内容准确、语气、细节控制和可读性                                                              |
| 4  | 新增 Automated Checks  | 原题只有 `llm_judge`，缺少 automated checks；补充基础自动评分以提升可评分性                                           |
| 5  | 修改 frontmatter       | 将 `verification_method` 改为 `rubric`，`grading_type` 改为 `hybrid`，并补 `grading_weights`，保证权重和为 1.0 |
| 6  | 重写 LLM Judge Rubric  | 原 rubric 只有百分比描述，没有 1.0/0.75/0.5/0.25/0.0 分档，不满足审校要求                                         |