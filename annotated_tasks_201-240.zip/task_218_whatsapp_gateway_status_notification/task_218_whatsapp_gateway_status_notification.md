---
id: task_218_whatsapp_gateway_status_notification
name: WhatsApp Gateway Status Notification
category: Communication and Scheduling
subcategory: Messaging and Email Communication
difficulty: easy
external_dependency: none
verification_method: llm-judge
input_modality: text-only
grading_type: hybrid
grading_weights:
  automated: 0.4
  llm_judge: 0.6
timeout_seconds: 60
workspace_files: []
source_line_number: 3867
source_query: "Write a helpful, friendly notification to the user: the WhatsApp gateway briefly disconnected (status 428) and then reconnected a few seconds later; the heartbeat check reports everything OK."
---

## Prompt

Please write a short, friendly user notification based on these system events:

```text
System: [2026-02-23 05:34:12 GMT+8] WhatsApp gateway disconnected (status 428)
System: [2026-02-23 05:34:16 GMT+8] WhatsApp gateway connected.
System: [2026-02-23 05:55:59 GMT+8] Cron: HEARTBEAT_OK
```

What the user needs to know:

* There was a brief WhatsApp connection interruption
* It recovered shortly afterward
* The system is currently operating normally

Output only the notification message itself.
Do not include bullet points, labels, timestamps, log lines, status codes, or extra explanation outside the message.

## Expected Behavior

A strong answer should transform the raw system logs into a short, user-facing notification that is accurate, reassuring, and easy to understand.

Recommended reasoning path:

1. Identify the core facts from the logs

   * The WhatsApp gateway disconnected briefly
   * It reconnected a few seconds later
   * A later heartbeat check reported normal system health

2. Filter out unnecessary technical detail

   * The user does not need timestamps, `status 428`, or `Cron: HEARTBEAT_OK`
   * These details should be translated into plain language

3. Communicate the right level of reassurance

   * The message should acknowledge a brief interruption
   * It should clearly state that service has been restored and everything looks normal now
   * It should avoid sounding alarming or overly dramatic

4. Keep the message concise and natural

   * This is a lightweight notification, not a technical incident report
   * A short paragraph or 1–3 sentences is ideal

Ground Truth / acceptable answer band:

* The message should mention a brief WhatsApp connection issue
* It should state or strongly imply that the issue was resolved quickly
* It should confirm that the service/system is now working normally
* It should avoid exposing internal technical details such as `428`, raw logs, or heartbeat/cron jargon

Key traps:

* Do not copy raw logs into the answer
* Do not emphasize internal status codes or monitoring terminology
* Do not make the message sound severe when the incident was brief and recovered
* Do not omit the “everything is OK now” reassurance

Tested capabilities: user-facing notification writing, technical-to-nontechnical translation, tone control, brevity, and instruction compliance.

## Grading Criteria

* [ ] Message accurately states there was a brief WhatsApp connection issue
* [ ] Message clearly indicates the issue was resolved and service is normal now
* [ ] Tone is friendly and reassuring rather than alarming or overly technical
* [ ] The response avoids raw status codes, timestamps, and monitoring jargon
* [ ] The message is concise and readable
* [ ] Output contains only the notification message, with no extra framing text

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    import re

    scores = {
        "mentions_brief_whatsapp_issue": 0.0,
        "confirms_recovery_and_normal_status": 0.0,
        "friendly_reassuring_tone": 0.0,
        "avoids_technical_log_details": 0.0,
        "concise_and_readable": 0.0,
        "message_only_output": 0.0,
    }

    def _get_last_assistant_text(transcript: list) -> str:
        for event in reversed(transcript):
            if event.get("type") != "message":
                continue
            msg = event.get("message", {})
            if msg.get("role") != "assistant":
                continue
            content = msg.get("content", "")
            if isinstance(content, str):
                return content
            if isinstance(content, list):
                parts = []
                for item in content:
                    if isinstance(item, dict) and item.get("type") == "text":
                        parts.append(item.get("text", ""))
                return "\n".join(parts).strip()
        return ""

    text = _get_last_assistant_text(transcript).strip()
    if not text:
        return scores

    lower = text.lower()

    # 1. Mentions a brief WhatsApp connection issue
    has_whatsapp = "whatsapp" in lower
    issue_terms = ["connection", "connected", "disconnected", "interruption", "issue", "hiccup", "temporary problem"]
    brief_terms = ["brief", "temporary", "momentary", "for a short time", "for a few seconds", "quickly"]
    issue_hit = any(t in lower for t in issue_terms)
    brief_hit = any(t in lower for t in brief_terms)

    if has_whatsapp and issue_hit and brief_hit:
        scores["mentions_brief_whatsapp_issue"] = 1.0
    elif has_whatsapp and issue_hit:
        scores["mentions_brief_whatsapp_issue"] = 0.6

    # 2. Confirms recovery / normal status
    recovery_terms = ["restored", "reconnected", "back online", "resolved", "working normally", "everything is okay", "everything is ok", "all good", "normal now"]
    recovery_hits = sum(1 for t in recovery_terms if t in lower)
    if recovery_hits >= 2:
        scores["confirms_recovery_and_normal_status"] = 1.0
    elif recovery_hits == 1:
        scores["confirms_recovery_and_normal_status"] = 0.6

    # 3. Friendly / reassuring tone
    tone_terms = ["thanks", "thank you", "just a quick update", "good news", "everything is back", "all set", "no action needed", "appreciate your patience"]
    alarming_terms = ["critical", "failure", "severe", "urgent", "major incident", "outage"]
    tone_score = 0.0
    if any(t in lower for t in alarming_terms):
        tone_score = 0.0
    else:
        if any(t in lower for t in tone_terms):
            tone_score = 1.0
        else:
            tone_score = 0.6
    scores["friendly_reassuring_tone"] = tone_score

    # 4. Avoid technical log details
    forbidden_patterns = [
        r"\b428\b",
        r"\bheartbeat_ok\b",
        r"\bcron\b",
        r"\bgmt\+?8\b",
        r"\d{4}-\d{2}-\d{2}",
        r"\d{2}:\d{2}:\d{2}",
        r"status\s*\d+",
    ]
    forbidden_hits = sum(1 for p in forbidden_patterns if re.search(p, lower))
    if forbidden_hits == 0:
        scores["avoids_technical_log_details"] = 1.0
    elif forbidden_hits == 1:
        scores["avoids_technical_log_details"] = 0.5

    # 5. Concise and readable
    word_count = len(re.findall(r"\S+", text))
    if 8 <= word_count <= 60:
        scores["concise_and_readable"] = 1.0
    elif 5 <= word_count <= 90:
        scores["concise_and_readable"] = 0.6

    # 6. Message-only output
    bad_wrappers = ["notification:", "message:", "subject:", "here's", "logs show", "system:"]
    if not any(w in lower for w in bad_wrappers):
        scores["message_only_output"] = 1.0
    else:
        scores["message_only_output"] = 0.5 if len(text.splitlines()) <= 2 else 0.0

    return scores
```

## LLM Judge Rubric

### Dimension 1: Content Accuracy and Completeness (Weight: 35%)

**1.0**
Clearly communicates that there was a brief WhatsApp connection interruption, that it recovered shortly afterward, and that the system is now functioning normally.

**0.75**
Conveys the main event and recovery accurately, with only minor omission or wording weakness.

**0.5**
Captures part of the situation correctly, but misses either the brevity of the interruption or the current healthy status.

**0.25**
Includes major factual gaps or confusing wording about what happened.

**0.0**
Misrepresents the event or fails to communicate the essential status update.

### Dimension 2: Tone and User Appropriateness (Weight: 35%)

**1.0**
The message is friendly, calm, and reassuring, and translates technical events into language suitable for a non-technical user.

**0.75**
Generally appropriate and reassuring, with only slight stiffness or minor overtechnical phrasing.

**0.5**
Understandable but somewhat too technical, too formal, or not especially reassuring.

**0.25**
Tone is mismatched, overly alarming, or too technical for the intended audience.

**0.0**
The message is clearly unsuitable for an end user.

### Dimension 3: Brevity and Format Compliance (Weight: 30%)

**1.0**
Outputs only the notification message, keeps it concise, and avoids logs, status codes, timestamps, and framing text.

**0.75**
Mostly concise and compliant, with only minimal extra wording or formatting noise.

**0.5**
Contains the core message but includes noticeable extra framing or unnecessary detail.

**0.25**
Substantially deviates from the requested direct-message format.

**0.0**
Does not follow the output requirements at all.