---
id: task_233_python_version_check_and_switch
name: Python Version Check and Switch
category: System Administration
subcategory: Software and Environment Management
difficulty: hard
external_dependency: none
verification_method: unit-test
input_modality: text-only
grading_type: automated
timeout_seconds: 120
workspace_files: []
source_line_number: 7853
source_query: "检查服务器是否已安装 Python 3.11.0；若已安装，将默认 python 命令切换为 Python 3.11.0，并最终验证 `python --version` 输出为 3.11.0。"
---

## Prompt

Hey, can you check whether Python 3.11.0 is available on this server?

If Python 3.11.0 is available, make the `python` command resolve to Python 3.11.0 for the current task session, then verify the result by running `python --version`.

After that, save the final `python --version` output to a file named `python_version.txt`.

Requirements:
- First check whether Python 3.11.0 is actually available
- Only switch `python` if Python 3.11.0 is available
- Do not fabricate the result
- The file should contain the real final output of `python --version`
- Focus on making the change effective for the current task session; do not assume permanent system-wide reconfiguration is required

## Expected Behavior

The agent should:
1. Check whether Python 3.11.0 is available in the environment.
   - Acceptable discovery methods include commands such as `python3.11 --version`, checking common executable paths, or inspecting version managers/environment configuration.
2. If Python 3.11.0 is available, make the `python` command resolve to Python 3.11.0 for the current task session.
   - Acceptable approaches include temporary PATH-based resolution, shell-level aliasing/wrapping that affects the active task session, virtual-environment or version-manager based selection, or another session-scoped method.
   - The task does **not** require a permanent system-wide change.
3. Verify the result by running `python --version` after the change.
4. Save the exact final output of `python --version` into `python_version.txt`.
5. The saved file should contain the actual command output, not an explanation or a guessed version string.

Traps the agent should handle correctly:
- The task is conditional: the switch should happen only if Python 3.11.0 is actually available.
- “Switch the default python command” does not necessarily mean modifying the whole OS permanently; a session-scoped change is acceptable.
- The final file must contain the real verified output of `python --version`, not the output of `python3.11 --version` unless `python` was actually made to resolve to that executable.
- The agent should not claim success without verifying `python --version`.

Ground truth constraints:
- Output file must be `python_version.txt`
- The file must contain a Python version string
- A fully correct solution should end with `python --version` resolving to `Python 3.11.0`
- The file content should be the verified final output of `python --version`

Tested capabilities: environment inspection, conditional execution, version selection, command verification, file output.

## Grading Criteria

- [ ] `python_version.txt` exists
- [ ] `python_version.txt` contains a Python version string
- [ ] `python_version.txt` records exactly `Python 3.11.0`
- [ ] The saved content appears to be a real command output rather than fabricated placeholder text
- [ ] The transcript shows the agent checked availability of Python 3.11.0 before switching
- [ ] The transcript shows the agent verified the final `python --version` result after switching

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    from pathlib import Path
    import re

    scores = {
        "version_file_exists": 0.0,
        "contains_python_version_string": 0.0,
        "exact_version_3_11_0": 0.0,
        "not_fabricated": 0.0,
        "checked_python_3_11_availability": 0.0,
        "verified_final_python_version": 0.0,
    }

    ws = Path(workspace_path)
    version_file = ws / "python_version.txt"

    if not version_file.exists():
        return scores

    scores["version_file_exists"] = 1.0

    try:
        content = version_file.read_text(encoding="utf-8").strip()
    except Exception:
        return scores

    lowered = content.lower()

    if re.search(r"\bpython\s+\d+\.\d+(?:\.\d+)?\b", lowered):
        scores["contains_python_version_string"] = 1.0

    if re.search(r"\bpython\s+3\.11\.0\b", lowered):
        scores["exact_version_3_11_0"] = 1.0

    placeholder_patterns = [
        r"<.*version.*>",
        r"\[.*version.*\]",
        r"x\.x\.x",
        r"placeholder",
        r"example",
        r"your version here",
    ]
    is_fabricated = any(re.search(p, lowered, re.IGNORECASE) for p in placeholder_patterns)
    scores["not_fabricated"] = 0.0 if is_fabricated else 1.0

    # Inspect transcript for evidence of a check before switching
    joined = "\n".join(str(x) for x in transcript).lower()

    availability_patterns = [
        r"python3\.11\s+--version",
        r"python\s+3\.11\.0\s+is\s+installed",
        r"python\s+3\.11\.0\s+available",
        r"/usr/bin/python3\.11",
        r"which\s+python3\.11",
        r"command\s+-v\s+python3\.11",
        r"pyenv\s+versions",
    ]
    if any(re.search(p, joined) for p in availability_patterns):
        scores["checked_python_3_11_availability"] = 1.0

    verify_patterns = [
        r"python\s+--version",
        r"python_version\.txt",
    ]
    verify_hits = sum(1 for p in verify_patterns if re.search(p, joined))
    if verify_hits >= 2:
        scores["verified_final_python_version"] = 1.0
    elif verify_hits == 1:
        scores["verified_final_python_version"] = 0.5

    return scores
```