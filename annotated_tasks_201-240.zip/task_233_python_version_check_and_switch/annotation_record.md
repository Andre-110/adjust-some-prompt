| 序号 | 修改项 | 修改原因 |
|---|---|---|
| 1 | 将 `difficulty: medium` 改为 `difficulty: hard` | 该题涉及环境探测、条件分支、版本切换、会话级命令解析、验证与文件保存，复杂度明显高于一般 medium |
| 2 | 重写 Prompt 中“switch the default python command”的表述 | 原表述容易被理解为必须永久修改系统默认解释器，带来不必要歧义；改为“for the current task session”更可执行、可评分 |
| 3 | 在 Prompt 中补充“先检查再切换”的显式要求 | 原题虽有条件逻辑，但要求不够突出，需明确强调条件执行 |
| 4 | 在 Prompt 中补充“不要伪造结果”“保存真实最终输出” | 防止模型绕过执行直接写文件，增强题目真实性和可评分性 |
| 5 | 扩充 Expected Behavior | 原版本未明确说明什么算“切换成功”、是否要求永久修改、以及验证对象必须是 `python --version` |
| 6 | 在 Expected Behavior 中增加“会话级修改即可” | 原任务若强制永久系统级修改，不同环境下不可稳定执行；调整后更符合 Agent 评测可复现性 |
| 7 | 在 Expected Behavior 中增加陷阱说明 | 按规范要求，题目存在条件执行和验证对象混淆等陷阱，需明确写出正确处理方式 |
| 8 | 在 Expected Behavior 中补充 Ground Truth | 原版本 Ground Truth 不够明确，需明确输出文件名、验证命令和正确版本结果 |
| 9 | 重写 Grading Criteria | 原标准过于集中在文件内容，未覆盖“先检查可用性”“最终验证 `python --version`”这些核心能力 |
| 10 | 增加“检查 Python 3.11.0 可用性”评分条目 | 原评分未覆盖条件分支前提，导致题目关键动作无法被评估 |
| 11 | 增加“验证最终 `python --version`”评分条目 | 原评分未真正检查是否执行过最终验证，与 Prompt 不对齐 |
| 12 | 重写 automated checks 的 score key | 使 score key 与 Grading Criteria 更接近一一对应，满足 Key 对齐要求 |
| 13 | 读取文件时显式指定 `encoding="utf-8"` | 提高代码稳健性 |
| 14 | 改进版本字符串检测逻辑 | 原逻辑只检查是否包含 “python” 和 “3.11”，区分度不足；新版要求匹配 Python 版本串格式 |
| 15 | 扩充 fabricated/placeholder 文本检测 | 原版只覆盖少数占位表达，补充更多常见伪造模式 |
| 16 | 在自动评分中增加 transcript 证据检查 | 原评分仅看输出文件，无法判断是否真的“检查安装情况”和“验证最终 python --version”；加入 transcript 线索后更贴近任务目标 |