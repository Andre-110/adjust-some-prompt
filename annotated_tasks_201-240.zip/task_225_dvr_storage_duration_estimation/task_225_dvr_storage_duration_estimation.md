---
id: task_225_dvr_storage_duration_estimation
name: DVR Storage Duration Estimation
category: Data Analysis
subcategory: Statistical Analysis and Modeling
difficulty: medium
external_dependency: none
verification_method: unit-test
input_modality: text-only
grading_type: automated
timeout_seconds: 120
workspace_files: []
source_line_number: 5485
source_query: "我有一台硬盘录像机，总容量 1863.02GB，目前剩余 1786GB，共 5 路监控。从 2 月 17 日 20:00 录到 2 月 23 日 15:30。假设码率不变，请根据这段时间的耗盘速度估算还可以继续录制大约多长时间。"
---

## Prompt

I need to estimate how much longer my DVR can keep recording if the storage consumption rate stays constant.

Known information:
- Total storage capacity: 1863.02 GB
- Remaining storage: 1786 GB
- Number of camera channels: 5
- Recording start time: February 17 at 20:00
- Current time: February 23 at 15:30

Please calculate:
1. how much storage has already been used
2. how many total recording hours have elapsed
3. the average storage consumption rate in GB/hour
4. the estimated remaining recording hours
5. the estimated remaining recording days

Save the result to `dvr_estimate.json`.

The JSON output must contain exactly these fields:
- `storage_used_gb`
- `recording_hours_elapsed`
- `consumption_rate_gb_per_hour`
- `remaining_hours`
- `remaining_days`

Use numeric values for all fields.

## Expected Behavior

The agent should:

1. Compute used storage:
   \[
   1863.02 - 1786 = 77.02 \text{ GB}
   \]
2. Compute elapsed recording time from February 17 20:00 to February 23 15:30:
   - 5 full days = 120 hours
   - plus 19.5 hours
   - total = **139.5 hours**
3. Compute the average storage consumption rate:
   \[
   77.02 / 139.5 \approx 0.5521 \text{ GB/hour}
   \]
4. Compute estimated remaining recording hours:
   \[
   1786 / 0.5521 \approx 3234.3 \text{ hours}
   \]
5. Compute estimated remaining recording days:
   \[
   3234.3 / 24 \approx 134.8 \text{ days}
   \]
6. Write a valid JSON file named `dvr_estimate.json`.
7. The JSON should contain exactly the 5 required numeric fields and no additional reasoning text.

Ground truth targets (allowing normal rounding differences):
- `storage_used_gb` ≈ **77.02**
- `recording_hours_elapsed` ≈ **139.5**
- `consumption_rate_gb_per_hour` ≈ **0.552**
- `remaining_hours` ≈ **3234.3**
- `remaining_days` ≈ **134.8**

Trap handling expected from the model:
- Do not confuse total capacity with used storage.
- Do not miscalculate the time interval.
- Do not divide by the number of cameras again; the observed storage consumption already reflects all 5 channels combined.
- Do not output prose instead of the required JSON file.

Tested capabilities:
- time interval calculation
- rate estimation
- unit conversion
- structured JSON output

## Grading Criteria

- [ ] File `dvr_estimate.json` exists
- [ ] File content is valid JSON
- [ ] JSON contains exactly the 5 required fields
- [ ] `storage_used_gb` is correctly calculated
- [ ] `recording_hours_elapsed` is correctly calculated
- [ ] `consumption_rate_gb_per_hour` is correctly calculated
- [ ] `remaining_hours` is correctly estimated
- [ ] `remaining_days` is correctly estimated and consistent with `remaining_hours`
- [ ] Output uses numeric values and does not fabricate unrelated data

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    from pathlib import Path
    import json

    score_keys = [
        "file_exists",
        "valid_json",
        "correct_fields",
        "storage_used_correct",
        "elapsed_hours_correct",
        "consumption_rate_correct",
        "remaining_hours_correct",
        "remaining_days_correct",
        "numeric_and_no_fabrication",
    ]
    scores = {k: 0.0 for k in score_keys}

    ws = Path(workspace_path)
    estimate_file = ws / "dvr_estimate.json"
    scores["file_exists"] = 1.0 if estimate_file.exists() else 0.0

    if not estimate_file.exists():
        return scores

    try:
        data = json.loads(estimate_file.read_text(encoding="utf-8"))
        scores["valid_json"] = 1.0
    except Exception:
        try:
            data = json.loads(estimate_file.read_text())
            scores["valid_json"] = 1.0
        except Exception:
            return scores

    expected_keys = [
        "storage_used_gb",
        "recording_hours_elapsed",
        "consumption_rate_gb_per_hour",
        "remaining_hours",
        "remaining_days",
    ]

    if isinstance(data, dict) and set(data.keys()) == set(expected_keys) and len(data) == 5:
        scores["correct_fields"] = 1.0
    elif isinstance(data, dict) and all(k in data for k in expected_keys):
        scores["correct_fields"] = 0.5
    else:
        return scores

    expected_used = 77.02
    expected_elapsed = 139.5
    expected_rate = expected_used / expected_elapsed
    expected_remaining_hours = 1786 / expected_rate
    expected_remaining_days = expected_remaining_hours / 24

    def is_number(x):
        return isinstance(x, (int, float)) and not isinstance(x, bool)

    storage_used = data.get("storage_used_gb")
    elapsed_hours = data.get("recording_hours_elapsed")
    consumption_rate = data.get("consumption_rate_gb_per_hour")
    remaining_hours = data.get("remaining_hours")
    remaining_days = data.get("remaining_days")

    if is_number(storage_used):
        diff = abs(storage_used - expected_used)
        if diff < 0.2:
            scores["storage_used_correct"] = 1.0
        elif diff < 1.0:
            scores["storage_used_correct"] = 0.5

    if is_number(elapsed_hours):
        diff = abs(elapsed_hours - expected_elapsed)
        if diff < 0.2:
            scores["elapsed_hours_correct"] = 1.0
        elif diff < 2.0:
            scores["elapsed_hours_correct"] = 0.5

    if is_number(consumption_rate):
        diff = abs(consumption_rate - expected_rate)
        if diff < 0.01:
            scores["consumption_rate_correct"] = 1.0
        elif diff < 0.05:
            scores["consumption_rate_correct"] = 0.5

    if is_number(remaining_hours):
        diff = abs(remaining_hours - expected_remaining_hours)
        if diff < 20:
            scores["remaining_hours_correct"] = 1.0
        elif diff < 100:
            scores["remaining_hours_correct"] = 0.5

    if is_number(remaining_days):
        diff = abs(remaining_days - expected_remaining_days)
        consistent = is_number(remaining_hours) and abs(remaining_days - (remaining_hours / 24)) < 1.0
        if diff < 1.0 and consistent:
            scores["remaining_days_correct"] = 1.0
        elif diff < 5.0:
            scores["remaining_days_correct"] = 0.5

    numeric_values = all(is_number(data.get(k)) for k in expected_keys)
    plausible_values = (
        is_number(storage_used) and 0 < storage_used < 200 and
        is_number(elapsed_hours) and 100 < elapsed_hours < 200 and
        is_number(consumption_rate) and 0 < consumption_rate < 2 and
        is_number(remaining_hours) and 2000 < remaining_hours < 5000 and
        is_number(remaining_days) and 80 < remaining_days < 250
    )
    if numeric_values and plausible_values:
        scores["numeric_and_no_fabrication"] = 1.0
    elif numeric_values:
        scores["numeric_and_no_fabrication"] = 0.5

    return scores
```