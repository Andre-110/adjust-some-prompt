| 序号 | 修改项 | 修改原因 |
|---|---|---|
| 1 | 重写 Prompt，明确只输出到 `dvr_estimate.json` 且字段固定 | 提升指令清晰度与可评分性 |
| 2 | 在 Prompt 中明确所有字段都应为数值 | 避免模型输出字符串或解释文本 |
| 3 | 精简并规范 Expected Behavior 中的时间差计算表述 | 原版本虽然数值正确，但分段过细，容易引发边界歧义 |
| 4 | 补充 Ground Truth 数值范围 | 使答案更明确、可验证 |
| 5 | 增加“不要再次按 5 路监控做除法”的陷阱说明 | 原题容易被误解为还要按单路分摊，需明确避免 |
| 6 | 重写 Grading Criteria，加入字段结构检查 | 原标准未检查 JSON 是否包含且仅包含要求字段 |
| 7 | 在 Grading Criteria 中增加 `remaining_days` 与 `remaining_hours` 一致性要求 | 提高评分完整性 |
| 8 | 重写 `grade()` 的 score keys | 与新的 Grading Criteria 一一对应 |
| 9 | `grade()` 统一初始化所有 key，并在文件缺失/JSON 失败时直接返回 | 满足空白零分要求 |
| 10 | `grade()` 增加 `correct_fields` 检查 | 原自动评分未检查字段完整性 |
| 11 | `grade()` 增加部分得分逻辑 | 满足支持 0.0–1.0 部分得分要求 |
| 12 | `grade()` 收紧关键数值项满分阈值，同时保留合理容忍区间 | 提高区分度并容忍正常四舍五入 |
| 13 | `grade()` 将 `no_fabrication` 改为 `numeric_and_no_fabrication` | 使检查语义更清晰，并覆盖“必须是数值”要求 |
| 14 | `grade()` 增加对 plausibility 的联合判断 | 原 `no_fabrication` 只看 `remaining_hours`，过于单薄 |