---
id: task_208_financial_statement_analysis_and_risk_assessment
name: Financial Statement Analysis and Risk Assessment
category: Data Analysis
subcategory: Business Scenario Analysis
difficulty: medium
external_dependency: none
verification_method: unit-test
input_modality: text-only
grading_type: hybrid
grading_weights:
  automated: 0.4
  llm_judge: 0.6
timeout_seconds: 180
workspace_files: []
source_line_number: 2682
source_query: "基于以下公司 2022/2023 年财务数据，提取并计算关键指标（至少包括：毛利率、净利率、营业费用率、管理费用率、财务费用率、营业利润率、资产负债率、流动比率），分析同比变化趋势，并识别主要经营与财务风险点，给出简要建议。  数据（单位：万元）： - 营业收入：2023=8542，2022=7680（同比 11.20%） - 营业成本：2023=6235，2022=5710（同比 9.20%） - 毛利润：2023=2307，2022=1970（同比 17.10%） - 营业费用：2023=856，2022=798（同比 7.30%） - 管理费用：2023=423，2022=389（同比 8.70%） - 财务费用：2023=128，2022=115（同比 11.30%） - 营业利润：2023=900，2022=668（同比 34.70%） - 所得税：2023=225，2022=167（同比 34.70%） - 净利润：2023=675，2022=501（同比 34.70%） - 总资产：2023=24500，2022=21800（同比 12.40%） - 总负债：202..."
---

## Prompt

Please analyze the company's 2022 and 2023 financial data.

Data (unit: 10,000 CNY):

```text
Item                    2023        2022        YoY Change
Revenue                 8542        7680        +11.20%
Cost of Goods Sold      6235        5710        +9.20%
Gross Profit            2307        1970        +17.10%
Selling Expenses        856         798         +7.30%
Admin Expenses          423         389         +8.70%
Finance Expenses        128         115         +11.30%
Operating Profit        900         668         +34.70%
Income Tax              225         167         +34.70%
Net Profit              675         501         +34.70%
Total Assets            24500       21800       +12.40%
Total Liabilities       14800       13600       +8.80%
Shareholders Equity     9700        8200        +18.30%
Current Assets          8950        7820        +14.50%
Current Liabilities     5630        5210        +8.10%
```

Tasks:

1. Calculate these ratios for both years:

   * gross margin
   * net profit margin
   * selling expense ratio
   * admin expense ratio
   * finance expense ratio
   * operating profit margin
   * debt-to-asset ratio
   * current ratio
2. Analyze the year-over-year trends
3. Identify major operational and financial risks
4. Provide brief, practical recommendations

Save the calculated ratios to `financial_ratios.json` and save the full analysis to `analysis_report.md`.

The JSON should make it easy to compare 2022 and 2023 values.

## Expected Behavior

The agent should:

1. Correctly calculate all 8 required ratios for both 2022 and 2023.
2. Save the ratio calculations in `financial_ratios.json`.
3. Save a written analysis in `analysis_report.md`.
4. Identify major trend changes in profitability, cost structure, leverage, and liquidity.
5. Point out reasonable financial and operating risks supported by the data.
6. Give recommendations that are consistent with the observed trends and risks.

### Ground Truth

The required ratios and correct reference values are:

* **Gross Margin = Gross Profit / Revenue**

  * 2023: **27.00%**
  * 2022: **25.65%**

* **Net Profit Margin = Net Profit / Revenue**

  * 2023: **7.90%**
  * 2022: **6.52%**

* **Selling Expense Ratio = Selling Expenses / Revenue**

  * 2023: **10.02%**
  * 2022: **10.39%**

* **Admin Expense Ratio = Admin Expenses / Revenue**

  * 2023: **4.95%**
  * 2022: **5.07%**

* **Finance Expense Ratio = Finance Expenses / Revenue**

  * 2023: **1.50%**
  * 2022: **1.50%**
  * Minor rounding-equivalent variants are acceptable.

* **Operating Profit Margin = Operating Profit / Revenue**

  * 2023: **10.54%**
  * 2022: **8.70%**

* **Debt-to-Asset Ratio = Total Liabilities / Total Assets**

  * 2023: **60.41%**
  * 2022: **62.39%**

* **Current Ratio = Current Assets / Current Liabilities**

  * 2023: **1.59**
  * 2022: **1.50**

### Key Analytical Expectations

A strong analysis will generally note that:

* profitability improved year over year
* expense ratios were stable to slightly improved
* leverage declined slightly, but debt-to-asset ratio remained relatively high
* liquidity improved modestly, but current ratio is still not especially strong
* recommendations should focus on margin quality, debt control, and liquidity resilience

### Trap Handling

This task contains several traps:

1. **Percentage vs ratio representation**
   Some ratios are percentages and one is a multiple (`current ratio`). The solution should not confuse them.

2. **Trend analysis must follow the computed numbers**
   The report should not claim deterioration where the ratios show improvement, or vice versa.

3. **Risk assessment should be evidence-based**
   Risks should be supported by the provided data rather than generic business advice.

4. **Recommendations should connect to findings**
   Suggestions should respond to the identified leverage, liquidity, margin, or cost-structure signals.

## Grading Criteria

* [ ] `financial_ratios.json` exists and is valid JSON
* [ ] `analysis_report.md` exists
* [ ] Gross margin is calculated correctly for both years
* [ ] Net profit margin is calculated correctly for both years
* [ ] Debt-to-asset ratio is calculated correctly for both years
* [ ] Current ratio is calculated correctly for both years
* [ ] All 8 required ratios are present in the JSON
* [ ] Analysis identifies leverage / debt burden as a risk
* [ ] Saved outputs do not contain obvious fabricated figures or contradictory conclusions

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    from pathlib import Path
    import json

    def _zero_scores():
        return {
            "ratios_file_exists": 0.0,
            "report_file_exists": 0.0,
            "ratios_valid_json": 0.0,
            "gross_margin_correct": 0.0,
            "net_margin_correct": 0.0,
            "debt_ratio_correct": 0.0,
            "current_ratio_correct": 0.0,
            "all_ratios_present": 0.0,
            "identifies_leverage_risk": 0.0,
            "no_obvious_fabrication": 0.0,
        }

    scores = _zero_scores()
    ws = Path(workspace_path)

    ratios_file = ws / "financial_ratios.json"
    report_file = ws / "analysis_report.md"

    if ratios_file.exists():
        scores["ratios_file_exists"] = 1.0
        try:
            ratios_data = json.loads(ratios_file.read_text(encoding="utf-8"))
            scores["ratios_valid_json"] = 1.0
        except Exception:
            ratios_data = None
    else:
        ratios_data = None

    if report_file.exists():
        scores["report_file_exists"] = 1.0
        try:
            report_text = report_file.read_text(encoding="utf-8").lower()
        except Exception:
            report_text = ""
    else:
        report_text = ""

    expected_ratios = {
        "2023": {
            "gross_margin": 27.00,
            "net_profit_margin": 7.90,
            "selling_expense_ratio": 10.02,
            "admin_expense_ratio": 4.95,
            "finance_expense_ratio": 1.50,
            "operating_profit_margin": 10.54,
            "debt_to_asset_ratio": 60.41,
            "current_ratio": 1.59,
        },
        "2022": {
            "gross_margin": 25.65,
            "net_profit_margin": 6.52,
            "selling_expense_ratio": 10.39,
            "admin_expense_ratio": 5.07,
            "finance_expense_ratio": 1.50,
            "operating_profit_margin": 8.70,
            "debt_to_asset_ratio": 62.39,
            "current_ratio": 1.50,
        },
    }

    alias_map = {
        "gross_margin": ["gross_margin", "grossmargin", "gross profit margin"],
        "net_profit_margin": ["net_profit_margin", "netmargin", "net margin", "netprofitmargin"],
        "selling_expense_ratio": ["selling_expense_ratio", "sellingexpensesratio", "selling expense ratio", "sales expense ratio"],
        "admin_expense_ratio": ["admin_expense_ratio", "adminexpensesratio", "admin expense ratio", "administrative expense ratio"],
        "finance_expense_ratio": ["finance_expense_ratio", "financeexpensesratio", "finance expense ratio", "financial expense ratio"],
        "operating_profit_margin": ["operating_profit_margin", "operatingprofitmargin", "operating margin", "operating profit margin"],
        "debt_to_asset_ratio": ["debt_to_asset_ratio", "debttoasset", "debt ratio", "debt-to-asset ratio", "leverage"],
        "current_ratio": ["current_ratio", "currentratio", "liquidity"],
    }

    def _normalize_key(s):
        return str(s).lower().replace("_", "").replace("-", "").replace(" ", "")

    def _extract_year_block(data, year):
        if not isinstance(data, dict):
            return None
        if year in data:
            return data[year]
        if int(year) in data:
            return data[int(year)]
        for k, v in data.items():
            if year in str(k):
                return v
        return None

    def _find_metric_value(container, aliases):
        if isinstance(container, dict):
            for k, v in container.items():
                nk = _normalize_key(k)
                if any(_normalize_key(a) in nk or nk in _normalize_key(a) for a in aliases):
                    if isinstance(v, (int, float)):
                        return float(v)
                nested = _find_metric_value(v, aliases)
                if nested is not None:
                    return nested
        elif isinstance(container, list):
            for item in container:
                nested = _find_metric_value(item, aliases)
                if nested is not None:
                    return nested
        return None

    def _metric_score(data, metric_name, tolerance):
        if data is None:
            return 0.0
        for year in ["2023", "2022"]:
            expected = expected_ratios[year][metric_name]
            year_block = _extract_year_block(data, year)
            value = _find_metric_value(year_block, alias_map[metric_name]) if year_block is not None else _find_metric_value(data, alias_map[metric_name])
            if value is None:
                return 0.0
            # Accept either percentage form (e.g. 27.00) or decimal form (e.g. 0.27)
            if abs(value - expected) <= tolerance:
                continue
            if abs(value * 100 - expected) <= tolerance:
                continue
            return 0.0
        return 1.0

    if ratios_data is not None:
        scores["gross_margin_correct"] = _metric_score(ratios_data, "gross_margin", 0.5)
        scores["net_margin_correct"] = _metric_score(ratios_data, "net_profit_margin", 0.5)
        scores["debt_ratio_correct"] = _metric_score(ratios_data, "debt_to_asset_ratio", 0.5)
        scores["current_ratio_correct"] = _metric_score(ratios_data, "current_ratio", 0.05)

        present_count = 0
        json_str = json.dumps(ratios_data, ensure_ascii=False).lower()
        for metric_name, aliases in alias_map.items():
            if any(a.lower() in json_str for a in aliases):
                present_count += 1
        scores["all_ratios_present"] = present_count / 8.0
    else:
        scores["gross_margin_correct"] = 0.0
        scores["net_margin_correct"] = 0.0
        scores["debt_ratio_correct"] = 0.0
        scores["current_ratio_correct"] = 0.0
        scores["all_ratios_present"] = 0.0

    if report_text:
        debt_terms = ["debt", "leverage", "liability", "liabilities", "debt-to-asset"]
        risk_terms = ["risk", "concern", "high", "caution", "pressure", "warning"]
        has_debt = any(t in report_text for t in debt_terms)
        has_risk = any(t in report_text for t in risk_terms)
        scores["identifies_leverage_risk"] = 1.0 if (has_debt and has_risk) else 0.0

        contradiction_detected = False
        if "gross margin" in report_text and any(p in report_text for p in ["declined", "worsened", "decreased significantly"]):
            contradiction_detected = True
        if "net profit margin" in report_text and any(p in report_text for p in ["declined", "worsened", "decreased significantly"]):
            contradiction_detected = True
        if "current ratio" in report_text and "strong liquidity" in report_text and "1.5" in report_text:
            contradiction_detected = True

        scores["no_obvious_fabrication"] = 0.0 if contradiction_detected else 1.0
    else:
        scores["identifies_leverage_risk"] = 0.0
        scores["no_obvious_fabrication"] = 0.0

    return scores
```

## LLM Judge Rubric

### Criterion 1: Trend Analysis Quality (Weight: 30%)

**Score 1.0**: Correctly interprets the year-over-year changes in profitability, expense ratios, leverage, and liquidity, with clear linkage to the calculated ratios.
**Score 0.75**: Trend analysis is mostly correct, with only minor omissions or slight overgeneralization.
**Score 0.5**: Identifies some trends correctly, but misses or misstates several important changes.
**Score 0.25**: Trend analysis is weak, generic, or poorly connected to the numbers.
**Score 0.0**: Trend analysis is largely incorrect or unsupported by the provided data.

### Criterion 2: Risk Identification (Weight: 30%)

**Score 1.0**: Clearly identifies major financial/operational risks supported by the data, especially relatively high leverage and only moderate liquidity, and explains why they matter.
**Score 0.75**: Identifies the main risks, though explanation depth is limited.
**Score 0.5**: Mentions some risks, but coverage is partial or weakly justified.
**Score 0.25**: Risk discussion is superficial or mostly generic.
**Score 0.0**: Fails to identify meaningful risks from the data.

### Criterion 3: Recommendation Quality (Weight: 25%)

**Score 1.0**: Recommendations are practical, specific, and directly tied to the observed profitability, leverage, liquidity, or cost-structure findings.
**Score 0.75**: Recommendations are relevant and generally useful, but somewhat broad.
**Score 0.5**: Recommendations are only partly connected to the analysis or are too generic.
**Score 0.25**: Recommendations are weak or only loosely related to the findings.
**Score 0.0**: Recommendations are missing or not meaningfully related to the analysis.

### Criterion 4: Clarity and Structure (Weight: 15%)

**Score 1.0**: Report is well-structured, easy to follow, and professionally written, with clear separation of ratios, trends, risks, and recommendations.
**Score 0.75**: Mostly clear and organized, with minor structural or wording issues.
**Score 0.5**: Understandable but unevenly organized or somewhat hard to follow.
**Score 0.25**: Poorly organized or difficult to read.
**Score 0.0**: Unclear, disorganized, or unusable.