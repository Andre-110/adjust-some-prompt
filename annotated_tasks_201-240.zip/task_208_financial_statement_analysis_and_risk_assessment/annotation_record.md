| 序号 | 修改项 | 修改原因 |
|---|---|---|
| 1 | 轻微改写 `Prompt` | 提高清晰度与自然度，避免过度口语化，同时不泄露分析结论 |
| 2 | 重写 `Expected Behavior` | 将其从“答案列表”调整为“行为要求 + Ground Truth + 分析预期”，更完整 |
| 3 | 将趋势/风险/建议部分从硬编码答案改为 `Key Analytical Expectations` | 减少模板化泄露，让模型仍需自行完成分析 |
| 4 | 增加 `Trap Handling` | 明确说明百分比 vs 倍数、趋势判定、证据支撑、建议联动等陷阱及正确处理方式 |
| 5 | 重写 `Grading Criteria` | 让条目更独立、可验证，并与 automated / llm_judge 分工更清晰 |
| 6 | 重写 `grade()` 的零分初始化逻辑 | 满足缺文件/空结果时全 0 的要求 |
| 7 | 为文件读取增加 `encoding="utf-8"` | 提高稳健性 |
| 8 | 简化并重写比率提取逻辑 | 原 `check_ratio()` 逻辑过于复杂且不够稳定，改为更清晰的 metric-level 检查 |
| 9 | 改进 `all_ratios_present` 计算 | 仍使用启发式，但更明确按 8 个 required metric 计分 |
| 10 | 将 `no_fabrication` 改为 `no_obvious_fabrication` 并改成“矛盾结论”检查 | 原版用少量数字启发式判断编造，过于随意；新逻辑更贴近报告文本质量 |
| 11 | 重写 LLM Judge Rubric | 满足至少 3 个维度的要求，并补齐 1.0 / 0.75 / 0.5 / 0.25 / 0.0 全档描述 |