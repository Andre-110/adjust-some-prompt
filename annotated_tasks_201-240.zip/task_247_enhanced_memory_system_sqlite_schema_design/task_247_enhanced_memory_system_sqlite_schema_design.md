---
id: task_247_enhanced_memory_system_sqlite_schema_design
name: Enhanced Memory System SQLite Schema Design
category: Knowledge Management
subcategory: Memory and Context Management
difficulty: hard
external_dependency: none
verification_method: rubric
input_modality: text-only
grading_type: hybrid
timeout_seconds: 240
grading_weights:
  automated: 0.4
  llm_judge: 0.6
workspace_files: []
source_line_number: 8737
source_query: "为一个"增强版记忆系统"设计并生成可直接执行的 SQLite 数据库 schema v2.0，并写入文件 config/database_schema_v2.0.sql。要求：  1) 必须包含以下表与字段（含默认值/约束说明）： - conversations：   - id INTEGER PRIMARY KEY AUTOINCREMENT   - user_message TEXT NOT NULL（完整原文，永不压缩）   - assistant_response TEXT NOT NULL（完整原文，永不压缩）   - summary TEXT（综合摘要：仅当原文超 1000 字才生成）   - summary_tokens INTEGER   - created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP   - updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP   - layer INTEGER DEFAULT 3（L0-L4，范围 0-4，4 最重要）   - is_landmark B..."
---

## Prompt

Hey, I need you to design and create a SQLite database schema for an "Enhanced Memory System" v2.0. Save it to `config/database_schema_v2.0.sql`.

The system needs to support four dimensions of memory: content layering (L0-L4), memory depth, timeline, and emotional coloring.

Here's what I need:

**Table 1: conversations**
- id INTEGER PRIMARY KEY AUTOINCREMENT
- user_message TEXT NOT NULL (full original text, never compressed)
- assistant_response TEXT NOT NULL (full original text, never compressed)
- summary TEXT (combined summary - only generate when original exceeds 1000 chars)
- summary_tokens INTEGER
- created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
- updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
- layer INTEGER DEFAULT 3 (L0-L4 range, 4 = most important, valid range 0-4)
- is_landmark BOOLEAN DEFAULT 0 (when =1, never compress)
- category TEXT DEFAULT 'other' (work/intimate/learning/other)
- tags TEXT (comma-separated)
- retrieval_count INTEGER DEFAULT 0
- system_prompt_inclusions INTEGER DEFAULT 0
- notes TEXT
- emotion_valence REAL DEFAULT 0 (-1 cold to +1 warm)
- emotion_arousal REAL DEFAULT 0 (0 calm to 1 intense)
- emotion_color TEXT (emoji or text description)
- emotion_description TEXT
- original_length INTEGER

**Table 2: tags**
- tag_name TEXT PRIMARY KEY
- call_count INTEGER DEFAULT 0
- last_called_at TIMESTAMP
- last_called_context INTEGER (foreign key to conversations.id)
- usage_trend TEXT (optional, trend data)

**Table 3: knowledge_items** (learning library)
- id INTEGER PRIMARY KEY AUTOINCREMENT
- title TEXT NOT NULL
- category TEXT (paper/tool/concept/other)
- source_url TEXT
- local_path TEXT
- file_format TEXT (pdf/md/txt/web_snapshot/etc)
- summary TEXT
- annotations TEXT
- added_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
- tags TEXT (comma-separated)
- relevance_score INTEGER DEFAULT 5 (1-10)
- visibility TEXT DEFAULT 'public' (public/private)
- is_shared_with_user BOOLEAN DEFAULT 0
- created_by_user_suggestion BOOLEAN DEFAULT 0

**Indexes needed:**
- conversations: layer, is_landmark, category, created_at
- tags: call_count
- knowledge_items: relevance_score

Also, I'd like you to evaluate whether I should add a `diary` table and a `wishlist` table for extensibility. If you think they'd be useful, include their schemas in the SQL file too.

Before writing the final SQL, output a [PLAN] section at the top of the file as SQL comments that covers: overall SQL structure, indexing strategy, whether to add diary/wishlist (and why), and any other extension suggestions. Then write the complete executable SQL below it.

## Expected Behavior

The agent should:
1. Create the directory structure `config/` if it doesn't exist
2. Generate a complete, executable SQLite schema file at `config/database_schema_v2.0.sql` — note the filename contains `v2.0` with a literal dot, which must be preserved exactly
3. Include a PLAN section as SQL comments at the top
4. Create all three required tables with correct field types, constraints, and defaults
5. Add all specified indexes
6. Evaluate and potentially add diary and wishlist tables with appropriate schemas
7. Ensure the SQL is syntactically valid and can be executed directly

Tested capabilities: database schema design, SQLite syntax, requirements analysis, extensibility planning, file creation.

**Trap handling — the agent should correctly navigate the following traps:**

- **Filename with dot in version number**: The target path is `config/database_schema_v2.0.sql`. The `.0` is part of the version string in the filename, not a file extension separator. The correct filename is `database_schema_v2.0.sql`. Writing `database_schema_v2_0.sql` or `database_schema_v2.sql` is wrong.
- **SQLite foreign key enforcement**: SQLite does not enforce foreign key constraints by default. The `last_called_context INTEGER` field in the `tags` table should be defined with a `REFERENCES conversations(id)` clause for correctness, but the agent should be aware (and ideally note in the PLAN) that enforcement requires `PRAGMA foreign_keys = ON` at runtime. Omitting the REFERENCES clause entirely is a schema design error.
- **diary/wishlist evaluation is required**: The Prompt explicitly asks the agent to evaluate whether to add these two tables. The agent must address this question in the PLAN section — either include schemas for both tables with rationale, or explain why they are not recommended. Silently omitting this evaluation is incorrect.

## Grading Criteria

- [ ] File `config/database_schema_v2.0.sql` exists (exact filename)
- [ ] Contains PLAN section as SQL comments
- [ ] Contains conversations table with all required fields
- [ ] Contains tags table with foreign key reference to conversations
- [ ] Contains knowledge_items table with all required fields
- [ ] Contains required indexes for conversations, tags, and knowledge_items
- [ ] SQL is syntactically valid (no obvious syntax errors)
- [ ] SQL file contains discussion or schema for diary/wishlist extensibility

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    from pathlib import Path
    import re

    scores = {}
    ws = Path(workspace_path)

    schema_file = ws / "config" / "database_schema_v2.0.sql"
    scores["file_exists"] = 1.0 if schema_file.exists() else 0.0

    if not schema_file.exists():
        scores["has_plan_section"] = 0.0
        scores["conversations_table"] = 0.0
        scores["tags_table"] = 0.0
        scores["knowledge_items_table"] = 0.0
        scores["required_indexes"] = 0.0
        scores["has_diary_wishlist_eval"] = 0.0
        return scores

    try:
        content = schema_file.read_text(encoding="utf-8")
    except Exception:
        try:
            content = schema_file.read_text(encoding="latin-1")
        except Exception:
            scores["has_plan_section"] = 0.0
            scores["conversations_table"] = 0.0
            scores["tags_table"] = 0.0
            scores["knowledge_items_table"] = 0.0
            scores["required_indexes"] = 0.0
            scores["has_diary_wishlist_eval"] = 0.0
            return scores

    content_lower = content.lower()

    plan_patterns = [r"--.*plan", r"/\*.*plan.*\*/", r"plan\s*:"]
    has_plan = any(re.search(p, content_lower, re.IGNORECASE | re.DOTALL) for p in plan_patterns)
    scores["has_plan_section"] = 1.0 if has_plan else 0.0

    conv_match = re.search(r"create\s+table\s+(?:if\s+not\s+exists\s+)?conversations\s*\(", content_lower)
    if conv_match:
        conv_required = ["user_message", "assistant_response", "layer", "is_landmark",
                         "emotion_valence", "emotion_arousal", "retrieval_count"]
        conv_found = sum(1 for f in conv_required if f in content_lower)
        scores["conversations_table"] = conv_found / len(conv_required)
    else:
        scores["conversations_table"] = 0.0

    tags_match = re.search(r"create\s+table\s+(?:if\s+not\s+exists\s+)?tags\s*\(", content_lower)
    if tags_match:
        tags_required = ["tag_name", "call_count", "last_called_context"]
        tags_found = sum(1 for f in tags_required if f in content_lower)
        has_fk = "references" in content_lower or "foreign key" in content_lower
        tags_score = tags_found / len(tags_required)
        if has_fk:
            tags_score = min(1.0, tags_score + 0.2)
        scores["tags_table"] = tags_score
    else:
        scores["tags_table"] = 0.0

    ki_match = re.search(r"create\s+table\s+(?:if\s+not\s+exists\s+)?knowledge_items\s*\(", content_lower)
    if ki_match:
        ki_required = ["title", "category", "source_url", "relevance_score", "visibility"]
        ki_found = sum(1 for f in ki_required if f in content_lower)
        scores["knowledge_items_table"] = ki_found / len(ki_required)
    else:
        scores["knowledge_items_table"] = 0.0

    index_targets = [
        (r"create\s+index.*\blayer\b", "layer"),
        (r"create\s+index.*\bis_landmark\b", "is_landmark"),
        (r"create\s+index.*\bcategory\b", "category"),
        (r"create\s+index.*\bcreated_at\b", "created_at"),
        (r"create\s+index.*\bcall_count\b", "call_count"),
        (r"create\s+index.*\brelevance_score\b", "relevance_score"),
    ]
    idx_found = sum(1 for pattern, _ in index_targets if re.search(pattern, content_lower))
    scores["required_indexes"] = idx_found / len(index_targets)

    # Check for diary/wishlist evaluation in comments or table definitions
    has_diary = "diary" in content_lower
    has_wishlist = "wishlist" in content_lower
    if has_diary and has_wishlist:
        scores["has_diary_wishlist_eval"] = 1.0
    elif has_diary or has_wishlist:
        scores["has_diary_wishlist_eval"] = 0.5
    else:
        scores["has_diary_wishlist_eval"] = 0.0

    return scores
```

## LLM Judge Rubric

### Criterion 1: Schema Completeness and Correctness (Weight: 35%)

**Score 1.0**: All three tables have every specified field with correct types, constraints, and default values exactly as requested. Foreign key relationship on `tags.last_called_context` properly defined with REFERENCES clause.
**Score 0.75**: All tables present with most fields correct; minor issues like missing a default value, slightly different constraint, or foreign key declared but without REFERENCES.
**Score 0.5**: All tables present but several fields missing or have incorrect types/defaults.
**Score 0.25**: Tables exist but significant fields missing or major type errors.
**Score 0.0**: Missing one or more required tables or fundamentally incorrect schema.

### Criterion 2: Plan Quality and Extensibility Analysis (Weight: 30%)

**Score 1.0**: Comprehensive PLAN section with clear rationale for structure, thoughtful indexing strategy explanation, and well-reasoned evaluation of both diary and wishlist tables — either with concrete schema proposals if recommended, or explicit reasoning for not including them.
**Score 0.75**: Good PLAN with reasonable analysis; diary/wishlist evaluation present but one of the two tables is missing from the discussion, or analysis lacks depth.
**Score 0.5**: Basic PLAN exists but lacks depth; diary/wishlist mentioned but not meaningfully evaluated.
**Score 0.25**: Minimal PLAN with little analysis; diary/wishlist barely mentioned or ignored.
**Score 0.0**: No PLAN section or completely irrelevant content.

### Criterion 3: SQL Quality and Executability (Weight: 20%)

**Score 1.0**: SQL is syntactically perfect, uses appropriate SQLite conventions, includes IF NOT EXISTS for safety, proper semicolons, and would execute without errors. Filename is exactly `database_schema_v2.0.sql`.
**Score 0.75**: SQL is mostly correct with very minor syntax issues that wouldn't prevent execution.
**Score 0.5**: SQL has some syntax issues but overall structure is sound.
**Score 0.25**: Multiple syntax errors that would prevent execution.
**Score 0.0**: SQL is not executable or fundamentally broken.

### Criterion 4: Index Design and Performance Considerations (Weight: 15%)

**Score 1.0**: All required indexes present with appropriate naming conventions; may include additional useful indexes with justification in the PLAN.
**Score 0.75**: All required indexes present, reasonable naming.
**Score 0.5**: Most required indexes present but some missing (e.g., one of the conversations indexes absent).
**Score 0.25**: Only a few indexes present; most required ones missing.
**Score 0.0**: No indexes defined, or index statements are syntactically invalid and would not execute.