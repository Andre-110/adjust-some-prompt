| 序号 | 修改项 | 修改原因 |
|---|---|---|
| 1 | 将 `difficulty: hard` 改为 `difficulty: medium` | 题目主要考察 schema 遵循、缺失数据处理、保守决策，推理复杂度有限，与 hard 不匹配 |
| 2 | 重写 `Prompt` 中的任务说明 | 原 Prompt 存在明显答案泄露，直接提示 `info_quality`、`action_hint`、`action.score` 应如何填写 |
| 3 | 删除 Prompt 中 “Since all three data panels are unavailable, you should...” 这类直接引导答案的内容 | 避免将 Expected Behavior 中的 Ground Truth 直接暴露给模型 |
| 4 | 保留 JSON 结构要求，但弱化结论性提示 | 保证任务可执行，同时避免把正确答案写进题面 |
| 5 | 补充 `Expected Behavior` 中的 Ground Truth / Key Expectations | 原版本虽有方向，但 Ground Truth 不够明确，便于评审与模型对齐 |
| 6 | 增加 `Trap Handling` 段落 | 原文没有明确说明本题的“陷阱”及正确处理方式，需补齐 |
| 7 | 重写 `Grading Criteria` | 原条目部分过于笼统，独立可验证性和覆盖度不足 |
| 8 | 将 “Output is valid JSON” 改成 “valid JSON 且无额外文本” | 原评分未校验“只能输出 JSON 对象”这一关键要求 |
| 9 | 增加 `evidence_refs` 合法性检查维度 | 原评分未检查证据引用是否仅来自给定 panel |
| 10 | 增加 `behavioral_diagnosis` 完整结构检查 | 原 grade() 未覆盖该评分点，与 Grading Criteria 不完全对齐 |
| 11 | 重写 `grade()` 的 JSON 校验逻辑 | 原实现用正则抽取 JSON，可能放过“JSON 前后有额外文本”的不合格答案 |
| 12 | 为 `action.score` 增加部分得分梯度 | 原逻辑只有单阈值，部分得分不够合理 |
| 13 | 为 `behavioral_diagnosis` 的低置信度要求增加检查 | 原逻辑只检查 primary_biases，且对谨慎性的覆盖不够 |
| 14 | 增强 `no_fabrication` 检测 | 原版仅少量检查 opportunity 和 primary_biases，容易漏掉编造技术面/新闻面/情绪面的情况 |
| 15 | 调整 automated score keys | 使 score key 与修订后的 Grading Criteria 更接近一一对应 |
| 16 | 重写 LLM Judge Rubric 四个维度标题与描述 | 提高清晰度，突出“只输出 JSON”“证据真空处理”“不编造信息”“决策保守性” |