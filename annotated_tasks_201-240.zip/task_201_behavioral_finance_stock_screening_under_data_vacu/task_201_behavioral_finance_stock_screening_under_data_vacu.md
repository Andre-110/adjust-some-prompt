---
id: task_201_behavioral_finance_stock_screening_under_data_vacu
name: Behavioral Finance Stock Screening Under Data Vacuum
category: Finance
subcategory: Market Analysis and Research
difficulty: medium
external_dependency: none
verification_method: rubric
input_modality: text-only
grading_type: hybrid
timeout_seconds: 180
grading_weights:
  automated: 0.35
  llm_judge: 0.65
workspace_files: []
source_line_number: 8710
source_query: "基于以下结构化信息，从行为金融视角判断 A 股 601606.SH（长城军工）在 2026-02-12 是否值得进入候选池。仅可使用 meta、tech_panel、news_panel、sentiment_panel 中给出的信息；当某个 panel 的 data_status 非 ok（此处均为 unavailable）时降低该维度权重但仍需输出结果。  请仅输出一个 JSON 对象（不要输出任何多余文字），并严格包含以下结构与字段： - stock_id, logical_date - info_quality: rich | sparse | conflicting | vacuum - conflict_assessment { has_major_conflict, has_resonance, description, evidence_refs[] } - behavioral_diagnosis {   primary_biases[] (每项含 name, description, evidence_refs[], confidence),   seconda..."

---

## Prompt

Please assess whether stock `601606.SH` should enter a candidate pool on `2026-02-12` from a **behavioral finance** perspective.

You may use **only** the information provided in `meta`, `tech_panel`, `news_panel`, and `sentiment_panel`. If one or more panels are unavailable, you must still return a result, but your reasoning and confidence should reflect the reduced evidence quality.

Here is the structured input:

```json
{
  "meta": {
    "stock_id": "601606.SH",
    "stock_name": "Great Wall Military Industry",
    "logical_date": "2026-02-12",
    "pool_type": "A"
  },
  "tech_panel": {
    "data_status": "unavailable",
    "tech_summary": "Technical panel data unavailable"
  },
  "news_panel": {
    "data_status": "unavailable",
    "narrative_summary": "News panel data unavailable"
  },
  "sentiment_panel": {
    "data_status": "unavailable",
    "sentiment_summary": "Sentiment panel data unavailable"
  }
}
```

Output **only one JSON object** and **no extra text**. Your JSON must include exactly these top-level fields:

* `stock_id`
* `logical_date`
* `info_quality`
* `conflict_assessment`
* `behavioral_diagnosis`
* `opportunity_assessment`
* `action`
* `falsification_points`
* `explanations`

Use this structure:

* `stock_id`, `logical_date`
* `info_quality`: one of "rich", "sparse", "conflicting", "vacuum"
* `conflict_assessment`:
  `{ has_major_conflict, has_resonance, description, evidence_refs[] }`
* `behavioral_diagnosis`:
  `{  
    primary_biases[] (each with `name`, `description`, `evidence_refs[]`, `confidence`),  
    secondary_biases[] (same structure),  
    psychological_drivers: { `dominant_bias`, `attention_dynamics`, `rationality_status`, `narrative_trap`, `evidence_refs[]` }  
  }`
* `opportunity_assessment`:
  `{ has_potential_opportunity, opportunity_type, hypothesis, evidence_refs[], limitations }`
* `action`:
  `{ score, would_buy_if_slot_available, action_hint, rationale, evidence_refs[] }`
* `falsification_points[]`: each with
  `{ machine_rule: { metric, operator, value, lookback_days }, human_note, evidence_refs[] }`
  where `operator` is one of "above", "below", "crosses"
* `explanations[]`: each with
  `{ conclusion, evidence_refs[], confidence }`

Important constraints:

* Do not invent facts that are not supported by the provided panels.
* If evidence is weak or absent, reflect that in confidence, rationale, and limitations.
* `evidence_refs` should point only to the provided sections (for example: "meta", "tech_panel", "news_panel", "sentiment_panel").
* The result must remain internally consistent.

## Expected Behavior

A strong answer should:

1. Recognize that `tech_panel`, `news_panel`, and `sentiment_panel` are all unavailable, so the evidence base is extremely weak.
2. Return a **valid JSON object only**, with no leading or trailing commentary.
3. Set `info_quality` to **`"vacuum"**, because all non-meta analytical panels are unavailable.
4. Avoid claiming specific behavioral signals (for example, momentum, narrative contagion, retail panic, media-driven attention spikes) as established facts, since there is no supporting panel data.
5. Keep any behavioral-finance diagnosis explicitly tentative, low-confidence, and grounded in the lack of observable evidence rather than fabricated market detail.
6. Provide an `action` that is conservative and consistent with the evidence vacuum:

   * `score` should be low rather than bullish,
   * `action_hint` should not recommend confident entry,
   * rationale should explicitly mention insufficient evidence.
7. Populate all required fields, including nested structures, while making limitations explicit.
8. Use only supported references in `evidence_refs` such as `meta`, `tech_panel`, `news_panel`, and `sentiment_panel`.

### Ground Truth / Key Expectations

* Correct `info_quality`: **`vacuum`**
* Correct evidence situation: **all three analytical panels unavailable**
* Acceptable decision posture: **conservative / deferential to missing data**
* Unacceptable behavior:

  * inventing concrete news, sentiment, or technical patterns
  * assigning high confidence to behavioral biases
  * giving an aggressive “enter” style recommendation without evidence

### Trap Handling

This task contains an evidence-scarcity trap: the model may be tempted to fill the schema with plausible-sounding stock analysis. The correct handling is to complete the schema **without fabricating missing observations** and to express uncertainty explicitly.

## Grading Criteria

* [ ] Output is valid JSON and contains no extra text outside the JSON object
* [ ] All required top-level fields are present
* [ ] `info_quality` is correctly set to reflect the evidence vacuum
* [ ] `behavioral_diagnosis` contains the required nested structure and uses cautious confidence
* [ ] `action.score` is conservative and consistent with missing evidence
* [ ] `action_hint` is appropriate for an evidence-vacuum scenario
* [ ] `evidence_refs` only cite provided sections and do not imply unseen evidence
* [ ] The response does not fabricate unavailable technical, news, or sentiment signals

### Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    import json
    import re

    def _zero_scores():
        return {
            "valid_json_only": 0.0,
            "has_required_fields": 0.0,
            "info_quality_correct": 0.0,
            "behavioral_structure_and_caution": 0.0,
            "action_score_conservative": 0.0,
            "action_hint_appropriate": 0.0,
            "evidence_refs_grounded": 0.0,
            "no_fabrication": 0.0,
        }

    def _get_last_assistant_text(transcript: list) -> str:
        for event in reversed(transcript):
            if event.get("type") != "message":
                continue
            msg = event.get("message", {})
            if msg.get("role") != "assistant":
                continue
            content = msg.get("content", "")
            if isinstance(content, str):
                return content
            if isinstance(content, list):
                parts = []
                for item in content:
                    if isinstance(item, dict) and item.get("type") == "text":
                        parts.append(item.get("text", ""))
                return "".join(parts)
        return ""

    def _collect_evidence_refs(obj):
        refs = []
        if isinstance(obj, dict):
            for k, v in obj.items():
                if k == "evidence_refs" and isinstance(v, list):
                    refs.extend(v)
                else:
                    refs.extend(_collect_evidence_refs(v))
        elif isinstance(obj, list):
            for item in obj:
                refs.extend(_collect_evidence_refs(item))
        return refs

    text = _get_last_assistant_text(transcript).strip()
    scores = _zero_scores()

    if not text:
        return scores

    # Must be a JSON object only, with no extra text.
    try:
        data = json.loads(text)
        if isinstance(data, dict):
            scores["valid_json_only"] = 1.0
        else:
            return scores
    except Exception:
        return scores

    required_fields = [
        "stock_id",
        "logical_date",
        "info_quality",
        "conflict_assessment",
        "behavioral_diagnosis",
        "opportunity_assessment",
        "action",
        "falsification_points",
        "explanations",
    ]
    present = sum(1 for f in required_fields if f in data)
    scores["has_required_fields"] = present / len(required_fields)

    info_q = str(data.get("info_quality", "")).strip().lower()
    scores["info_quality_correct"] = 1.0 if info_q == "vacuum" else 0.0

    # behavioral_diagnosis structure + cautious confidence
    bd = data.get("behavioral_diagnosis", {})
    structure_points = 0
    if isinstance(bd, dict):
        if isinstance(bd.get("primary_biases"), list):
            structure_points += 1
        if isinstance(bd.get("secondary_biases"), list):
            structure_points += 1
        pd = bd.get("psychological_drivers")
        if isinstance(pd, dict):
            needed = ["dominant_bias", "attention_dynamics", "rationality_status", "narrative_trap", "evidence_refs"]
            if all(k in pd for k in needed):
                structure_points += 1

    caution_ok = True
    for bias_group in [bd.get("primary_biases", []), bd.get("secondary_biases", [])]:
        if isinstance(bias_group, list):
            for bias in bias_group:
                if not isinstance(bias, dict):
                    caution_ok = False
                    continue
                if "confidence" not in bias:
                    caution_ok = False
                    continue
                try:
                    if float(bias["confidence"]) > 0.6:
                        caution_ok = False
                except Exception:
                    caution_ok = False

    scores["behavioral_structure_and_caution"] = (structure_points / 3.0) * (1.0 if caution_ok else 0.5)

    action = data.get("action", {})
    action_score = action.get("score", None)
    if action_score is None:
        scores["action_score_conservative"] = 0.0
    else:
        try:
            score_val = float(action_score)
            if score_val <= 0.2:
                scores["action_score_conservative"] = 1.0
            elif score_val <= 0.35:
                scores["action_score_conservative"] = 0.5
            else:
                scores["action_score_conservative"] = 0.0
        except Exception:
            scores["action_score_conservative"] = 0.0

    action_hint = str(action.get("action_hint", "")).strip().lower()
    if action_hint in {"manual_review", "avoid"}:
        scores["action_hint_appropriate"] = 1.0
    elif action_hint in {"enter"}:
        scores["action_hint_appropriate"] = 0.0
    else:
        scores["action_hint_appropriate"] = 0.0

    allowed_refs = {"meta", "tech_panel", "news_panel", "sentiment_panel"}
    refs = _collect_evidence_refs(data)
    if refs:
        valid_count = sum(1 for r in refs if str(r) in allowed_refs)
        scores["evidence_refs_grounded"] = valid_count / len(refs)
    else:
        scores["evidence_refs_grounded"] = 0.0

    fabrication_detected = False

    # High-confidence bias claims are suspicious in a vacuum setting
    for bias_group in [bd.get("primary_biases", []), bd.get("secondary_biases", [])]:
        if isinstance(bias_group, list):
            for bias in bias_group:
                if not isinstance(bias, dict):
                    continue
                desc = str(bias.get("description", "")).lower()
                try:
                    conf = float(bias.get("confidence", 0))
                except Exception:
                    conf = 0
                if conf > 0.6:
                    fabrication_detected = True
                suspicious_terms = [
                    "momentum surge", "media frenzy", "retail panic", "sentiment spike",
                    "bullish breakout", "panic selling", "viral narrative"
                ]
                if any(term in desc for term in suspicious_terms):
                    fabrication_detected = True

    opp = data.get("opportunity_assessment", {})
    if isinstance(opp, dict) and opp.get("has_potential_opportunity") is True:
        opp_type = str(opp.get("opportunity_type", "")).lower()
        hypothesis = str(opp.get("hypothesis", "")).lower()
        if opp_type not in {"unknown", "unclear", "data_limited", "insufficient_evidence", ""}:
            fabrication_detected = True
        suspicious_terms = [
            "reversal", "breakout", "narrative rotation", "momentum continuation"
        ]
        if any(term in hypothesis for term in suspicious_terms):
            fabrication_detected = True

    # Must not claim unavailable panels contain real signals
    full_text = json.dumps(data, ensure_ascii=False).lower()
    suspicious_claims = [
        "technical breakout",
        "positive news flow",
        "bullish sentiment",
        "strong media attention",
        "investor optimism surge",
    ]
    if any(term in full_text for term in suspicious_claims):
        fabrication_detected = True

    scores["no_fabrication"] = 0.0 if fabrication_detected else 1.0

    return scores
```

## LLM Judge Rubric

### Criterion 1: Schema Compliance and Output Discipline (Weight: 25%)

**Score 1.0**: Output is exactly one valid JSON object, with all required top-level fields and correctly formed nested structures. No extra text appears outside the JSON.
**Score 0.75**: Valid JSON with all major fields present, but minor structural or formatting issues.
**Score 0.5**: Valid JSON, but several nested fields are incomplete or malformed.
**Score 0.25**: Partial schema compliance; major fields missing or incorrectly structured.
**Score 0.0**: Not valid JSON or not limited to a single JSON object.

### Criterion 2: Correct Handling of the Evidence Vacuum (Weight: 35%)

**Score 1.0**: Clearly recognizes that all analytical panels are unavailable, sets `info_quality` appropriately, and consistently reflects severe evidence limitations across the entire answer.
**Score 0.75**: Correctly handles the missing-data setting overall, with only small inconsistencies in uncertainty calibration.
**Score 0.5**: Acknowledges missing data, but some parts of the answer behave as though stronger evidence exists.
**Score 0.25**: Partially acknowledges the vacuum but still draws several unsupported conclusions.
**Score 0.0**: Fails to recognize the evidence vacuum or responds as though real panel data were available.

### Criterion 3: Behavioral Finance Reasoning Under Uncertainty (Weight: 20%)

**Score 1.0**: Uses behavioral-finance concepts appropriately while keeping them explicitly tentative, abstract, and evidence-limited; avoids turning missing data into fabricated behavioral signals.
**Score 0.75**: Demonstrates solid behavioral-finance reasoning with mostly appropriate uncertainty handling.
**Score 0.5**: Shows basic behavioral-finance understanding, but analysis is generic or unevenly grounded.
**Score 0.25**: Minimal or weak behavioral-finance reasoning, with template-like content.
**Score 0.0**: No meaningful behavioral-finance analysis.

### Criterion 4: Conservative and Internally Consistent Decisioning (Weight: 20%)

**Score 1.0**: Action recommendation is conservative, internally consistent with the missing evidence, and clearly justified by limitations; no aggressive recommendation is implied.
**Score 0.75**: Conservative recommendation with good justification, though some details are slightly inconsistent.
**Score 0.5**: Recommendation is somewhat cautious, but rationale or confidence calibration is weak.
**Score 0.25**: Recommendation is poorly aligned with the evidence limitations.
**Score 0.0**: Gives an aggressive positive recommendation despite the evidence vacuum.