---
id: task_232_custom_instructions_file_with_auto_suffix
name: Custom Instructions File with Auto Suffix
category: Knowledge Management
subcategory: Agent and Tool Integration
difficulty: easy
external_dependency: none
verification_method: unit-test
input_modality: text-only
grading_type: automated
timeout_seconds: 60
workspace_files: []
source_line_number: 3120
source_query: "创建一个用于自定义指令的 .md 文件，使助手每次回复末尾自动添加“喵”。"
---

## Prompt

Hey, please create a markdown file named `custom_instructions.md` for custom assistant instructions.

I want the file to clearly tell an assistant to add the word `meow` at the end of every response.

Requirements:
- The file must be valid markdown
- The instruction should be explicit and easy to follow
- Keep the content short and simple
- Do not include unrelated instructions or extra complexity

Write the instructions into `custom_instructions.md`.

## Expected Behavior

The agent should:
1. Create a file named `custom_instructions.md` in the workspace.
2. Write markdown content that explicitly instructs an assistant to add `meow` at the end of every response.
3. Keep the content short, clear, and directly usable as a custom-instructions file.
4. Avoid unrelated instructions, roleplay setup, policy text, secrets, or fabricated configuration details.
5. Produce non-empty content that is recognizably markdown-formatted.

Ground truth constraints:
- Output filename must be `custom_instructions.md`
- The file must contain an explicit instruction about adding `meow`
- The instruction must clearly indicate this applies to every response
- The instruction must indicate that `meow` is added at the end of the response
- The file should contain only simple custom-instruction content, not unrelated system configuration

Tested capabilities: file creation, instruction writing, markdown formatting, simple requirement following.

## Grading Criteria

- [ ] `custom_instructions.md` exists
- [ ] The file is non-empty and contains markdown-formatted content
- [ ] The file explicitly mentions `meow`
- [ ] The file clearly instructs that `meow` should be added to every response
- [ ] The file clearly indicates that `meow` should appear at the end of the response
- [ ] The file does not contain unrelated or fabricated complex instructions

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    from pathlib import Path
    import re

    scores = {
        "file_exists": 0.0,
        "nonempty_markdown": 0.0,
        "mentions_meow": 0.0,
        "every_response_instruction": 0.0,
        "end_of_response_instruction": 0.0,
        "no_unrelated_or_fabricated_content": 0.0,
    }

    ws = Path(workspace_path)
    md_file = ws / "custom_instructions.md"

    if not md_file.exists():
        return scores

    scores["file_exists"] = 1.0

    try:
        content = md_file.read_text(encoding="utf-8")
        lowered = content.lower()
    except Exception:
        return scores

    if content.strip():
        has_markdown = (
            "#" in content
            or "-" in content
            or "*" in content
            or content.count("\n") >= 1
        )
        scores["nonempty_markdown"] = 1.0 if has_markdown else 0.5

    if "meow" in lowered:
        scores["mentions_meow"] = 1.0

    every_markers = [
        "every response",
        "each response",
        "all responses",
        "every reply",
        "each reply",
        "every answer",
        "each answer",
    ]
    if any(marker in lowered for marker in every_markers):
        scores["every_response_instruction"] = 1.0
    elif ("every" in lowered or "each" in lowered or "all" in lowered) and (
        "response" in lowered or "reply" in lowered or "answer" in lowered
    ):
        scores["every_response_instruction"] = 1.0

    end_patterns = [
        r"at the end of (every |each |all )?(response|reply|answer)",
        r"end (every |each |all )?(response|reply|answer) with",
        r"append .*meow",
        r"add .*meow.*end",
        r"suffix .*meow",
    ]
    if any(re.search(pattern, lowered) for pattern in end_patterns):
        scores["end_of_response_instruction"] = 1.0
    elif "end" in lowered and "meow" in lowered and (
        "response" in lowered or "reply" in lowered or "answer" in lowered
    ):
        scores["end_of_response_instruction"] = 1.0

    unrelated_terms = [
        "firewall",
        "database",
        "api key",
        "password",
        "secret",
        "token",
        "ssh",
        "encryption",
        "deploy",
        "server",
    ]
    has_unrelated = any(term in lowered for term in unrelated_terms)
    scores["no_unrelated_or_fabricated_content"] = 0.0 if has_unrelated else 1.0

    return scores
```