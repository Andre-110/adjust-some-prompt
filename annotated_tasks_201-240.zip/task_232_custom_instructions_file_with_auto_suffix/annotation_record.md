| 序号 | 修改项 | 修改原因 |
|---|---|---|
| 1 | 重写 Prompt 的要求部分 | 原 Prompt 基本清楚，但“clear and easy to follow”“simple but effective”略泛，补充成更明确的可执行要求，减少歧义 |
| 2 | 扩充 Expected Behavior | 原版较简略，缺少“every response”“end of response”“避免无关内容”等可验证 Ground Truth |
| 3 | 在 Expected Behavior 中补充 Ground truth constraints | 满足“答案明确、可验证”的要求，方便后续评分与质检 |
| 4 | 重写 Grading Criteria | 原标准部分可验证性不够强，例如“reasonable length”过于主观；改为更独立、清晰、可判定的条目 |
| 5 | 将 “contains markdown content” 细化为 “non-empty and contains markdown-formatted content” | 提高独立可验证性，避免模糊判断 |
| 6 | 拆分“mentions meow”和“every response”“end of response” | 原要求混在一起，拆分后更有区分度，也更利于 automated checks 与 score key 对齐 |
| 7 | 重写 automated checks 的 score key | 让 score key 与 Grading Criteria 一一对应，满足 Key 对齐要求 |
| 8 | 为主输出文件缺失时返回全 0 | 满足“空白零分”要求 |
| 9 | 明确使用 `encoding="utf-8"` 读取文件 | 提高稳健性，避免潜在编码问题 |
| 10 | 改进 “every response” 检查逻辑 | 原版仅通过 `response/reply/answer` 和 `append/add` 粗略判断，不足以验证“每次回复” |
| 11 | 改进 “end of response” 检查逻辑 | 原版只要出现 `end` 或 `append/add` 就可能给分，逻辑过宽；改为正则和多模式匹配，更准确区分好坏答案 |
| 12 | 扩充无关内容黑名单词 | 原版只检查少数词，覆盖不足；补充常见无关复杂配置词，提高区分度 |
| 13 | 删除“has .md extension”单独评分点 | 输出文件名已固定为 `custom_instructions.md`，单独检查扩展名与文件存在高度重合，区分度不足 |