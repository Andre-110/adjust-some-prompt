| 序号 | 修改项 | 修改原因 |
|---|---|---|
| 1 | 将 `difficulty` 从 `medium` 改为 `easy` | 题目仅要求识别简单 `echo` 命令前缀，复杂度不足以支撑 medium |
| 2 | 将 Prompt 中待分析命令改回 `echo "服务未运行"` | 与 `source_query` 保持一致，避免题面与来源不一致 |
| 3 | 保留 prefix/injection 规则示例，但精简任务描述 | 保持题目清晰，同时提升自然度 |
| 4 | 删除 Prompt 中多余的答案暗示性表达 | 避免在题面中直接提示正确结论 |
| 5 | 补充 `Expected Behavior` 的 Ground Truth | 让正确答案与判定依据更明确、可核验 |
| 6 | 增加 `Trap Handling` | 明确说明“引号中的普通文本不算注入”“简单命令也有 prefix”这两个关键陷阱 |
| 7 | 重写 `Grading Criteria` | 使条目更独立、可验证，并与自动评分项对齐 |
| 8 | 重写 `grade()` 的零分初始化逻辑 | 满足“空白输出时各项为 0.0”的要求 |
| 9 | 去掉原先“只要包含 echo 就算对”的宽松匹配 | 原逻辑过松，会放过带解释的输出，不符合“只输出 prefix string”要求 |
| 10 | 去掉 `concise_answer` | 该项区分度极低，且与核心能力关系弱，不宜保留 |
| 11 | 增加 `clean_output_only` | 严格检查是否只输出最终结果，无额外解释 |
| 12 | 将正确性判断改为严格等于 `echo` | 与题目要求完全一致，避免模糊通过 |
| 13 | 保留并收紧对 `command_injection_detected` 和 `none` 的误判检查 | 覆盖本题两个主要错误方向 |