| 序号 | 修改项 | 修改原因 |
|---|---|---|
| 1    | 改写 Prompt              | 降低答案泄露，保留真实“更新工作记忆草稿本”的用户请求风格，不直接把应更新的结论说死                                         |
| 2    | 重写 Expected Behavior   | 补充完整更新路径、信息取舍原则、Ground Truth 和陷阱说明，避免只写“应加入这条新事件”                                  |
| 3    | 重写 Grading Criteria    | 改成 6 条独立、可验证标准，并与 `grade()` score key 一一对应                                         |
| 4    | 重写 `grade()`           | 增强文件检查、四段结构检查、新事件整合检查、关键细节检查、字符数限制和“无无关编造”检查，支持空白零分                                |
| 5    | 优化 frontmatter         | 去掉重复字段 `automated_weight`，将 `verification_method` 从 `unit-test` 调整为更适合该题的 `rubric` |
| 6    | 重写 LLM Judge Rubric    | 原 rubric 只有百分比描述，没有 1.0/0.75/0.5/0.25/0.0 五档说明，不满足审校标准                           |