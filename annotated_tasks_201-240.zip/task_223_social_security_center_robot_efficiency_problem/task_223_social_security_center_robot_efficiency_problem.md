---
id: task_223_social_security_center_robot_efficiency_problem
name: Social Security Center Robot Efficiency Problem
category: Data Analysis
subcategory: Statistical Analysis and Modeling
difficulty: medium
external_dependency: none
verification_method: unit-test
input_modality: text-only
grading_type: automated
timeout_seconds: 120
workspace_files: []
source_line_number: 4803
source_query: "某岗位小张/小王/小李完结1单分别需6/5/4分钟，三人一天最多完结259单。机器人2分钟/单，80%可正常完结，20%需人工重新办理。若某天小张出差，机器人与人工工作时间相同，问当天小王、小李和机器人最多可完结多少单？（A 357，B 399，C 427，D 469）"
---

## Prompt

I have a work-related word problem and want the result written clearly.

Here is the setup:

- Zhang completes 1 case in 6 minutes
- Wang completes 1 case in 5 minutes
- Li completes 1 case in 4 minutes
- Together, Zhang, Wang, and Li can complete at most 259 cases in one workday

A robot is introduced:
- It takes 2 minutes per case
- 80% of the cases it handles are completed successfully
- The remaining 20% must be redone manually by a human worker

Now suppose Zhang is away on a business trip for one day, and the robot works the same total number of hours as the human workers that day.

Question:
What is the maximum number of cases that Wang, Li, and the robot can complete together that day?

Choices:
- A) 357
- B) 399
- C) 427
- D) 469

Please solve it and save your reasoning plus the final answer to `solution.txt`.
The final answer in the file should clearly indicate the correct option letter and the corresponding total number of completed cases.

## Expected Behavior

The agent should:

1. Infer the length of one workday from the original 3-person capacity:
   \[
   T/6 + T/5 + T/4 = 259
   \]
2. Solve for the daily working time:
   \[
   T = 420 \text{ minutes}
   \]
3. Compute Wang's maximum individual capacity for that day:
   \[
   420 / 5 = 84
   \]
4. Compute Li's maximum individual capacity for that day:
   \[
   420 / 4 = 105
   \]
5. Conclude that Wang and Li together can manually complete at most:
   \[
   84 + 105 = 189
   \]
6. Compute the robot's total attempted cases in 420 minutes:
   \[
   420 / 2 = 210
   \]
7. Compute robot successful completions:
   \[
   210 \times 80\% = 168
   \]
8. Compute robot failed cases needing human redo:
   \[
   210 \times 20\% = 42
   \]
9. Correctly recognize the key constraint/trap:
   the 42 failed robot cases must be redone using Wang and Li's existing working time, so they do **not** add extra capacity beyond the humans' total daily maximum of 189 cases.
10. Therefore, the maximum total completed cases that day are:
    \[
    168 + 189 = 357
    \]
11. The correct answer is:
    **A) 357**

Trap handling expected from the model:
- Do not double-count the 42 failed robot cases.
- Do not add robot failures on top of the full manual capacity.
- Do not conclude 399 by treating redo work as free extra output.

Tested capabilities:
- algebraic reasoning
- rate and work problems
- percentage calculations
- identifying hidden resource constraints
- avoiding double counting in optimization problems

## Grading Criteria

- [ ] File `solution.txt` exists
- [ ] Correctly identifies the workday length as 420 minutes (or 7 hours)
- [ ] Correctly identifies Wang + Li manual capacity as 189 cases
- [ ] Correctly identifies robot attempted volume as 210 and successful volume as 168
- [ ] Explicitly recognizes that the 20% failed robot cases consume human working time and cannot be double-counted
- [ ] Final answer is A (or 357)
- [ ] Does not claim B, C, or D as the final answer

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    from pathlib import Path
    import re

    score_keys = [
        "solution_file_exists",
        "identifies_working_time",
        "identifies_human_capacity",
        "identifies_robot_volume",
        "understands_no_double_counting",
        "correct_answer_a",
        "no_wrong_final_answer",
    ]
    scores = {k: 0.0 for k in score_keys}

    ws = Path(workspace_path)
    solution_file = ws / "solution.txt"
    scores["solution_file_exists"] = 1.0 if solution_file.exists() else 0.0

    if not solution_file.exists():
        return scores

    try:
        content = solution_file.read_text(encoding="utf-8")
    except Exception:
        try:
            content = solution_file.read_text()
        except Exception:
            return scores

    text = content.lower()

    # 1) Workday length = 420 min / 7 hours
    time_patterns = [
        r"\b420\b\s*(min|mins|minute|minutes|分钟)",
        r"\b7\b\s*(hour|hours|小时)",
        r"\bt\s*=\s*420\b",
        r"workday.*420",
        r"420.*workday",
    ]
    if any(re.search(p, text) for p in time_patterns):
        scores["identifies_working_time"] = 1.0

    # 2) Human capacity without Zhang = 189
    human_capacity_patterns = [
        r"\b189\b\s*(case|cases|单)",
        r"\b84\b.*\b105\b.*\b189\b",
        r"\b105\b.*\b84\b.*\b189\b",
        r"wang.*84",
        r"li.*105",
    ]
    hits = sum(1 for p in human_capacity_patterns if re.search(p, text))
    if hits >= 2:
        scores["identifies_human_capacity"] = 1.0
    elif hits == 1:
        scores["identifies_human_capacity"] = 0.5

    # 3) Robot attempted 210, success 168, fail 42
    robot_patterns = [
        r"\b210\b",
        r"\b168\b",
        r"\b42\b",
        r"80\s*%",
        r"20\s*%",
        r"0\.8",
        r"0\.2",
    ]
    robot_hits = sum(1 for p in robot_patterns if re.search(p, text))
    if robot_hits >= 4:
        scores["identifies_robot_volume"] = 1.0
    elif robot_hits >= 2:
        scores["identifies_robot_volume"] = 0.5

    # 4) Understands failed robot work cannot be double-counted
    no_double_count_patterns = [
        r"cannot be double-counted",
        r"not double-count",
        r"do not add.*42",
        r"42.*not.*extra",
        r"failed.*consume.*human time",
        r"redo.*uses.*human time",
        r"within.*189",
        r"manual capacity.*189",
        r"human.*capacity.*not.*extra",
    ]
    nd_hits = sum(1 for p in no_double_count_patterns if re.search(p, text))
    if nd_hits >= 1:
        scores["understands_no_double_counting"] = 1.0

    # 5) Correct final answer A / 357
    answer_a_patterns = [
        r"\ba\s*\)\s*357\b",
        r"answer[:\s]*a\b",
        r"answer[:\s]*is[:\s]*a\b",
        r"final answer[:\s]*a\b",
        r"correct answer[:\s]*a\b",
        r"\b357\b\s*(case|cases|单)",
        r"maximum.*357",
        r"total.*357",
    ]
    if any(re.search(p, text) for p in answer_a_patterns):
        scores["correct_answer_a"] = 1.0

    # 6) No wrong final answer
    wrong_answer_patterns = [
        r"final answer[:\s]*b\b",
        r"final answer[:\s]*c\b",
        r"final answer[:\s]*d\b",
        r"correct answer[:\s]*b\b",
        r"correct answer[:\s]*c\b",
        r"correct answer[:\s]*d\b",
        r"answer[:\s]*is[:\s]*b\b",
        r"answer[:\s]*is[:\s]*c\b",
        r"answer[:\s]*is[:\s]*d\b",
        r"\bb\s*\)\s*399\b",
        r"\bc\s*\)\s*427\b",
        r"\bd\s*\)\s*469\b",
    ]
    found_wrong = any(re.search(p, text) for p in wrong_answer_patterns)
    if scores["correct_answer_a"] == 1.0:
        scores["no_wrong_final_answer"] = 1.0 if not found_wrong else 0.0
    else:
        scores["no_wrong_final_answer"] = 0.0 if found_wrong else 0.5

    return scores
```