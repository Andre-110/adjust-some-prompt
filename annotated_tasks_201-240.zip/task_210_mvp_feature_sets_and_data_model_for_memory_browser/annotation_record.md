| 序号 | 修改项 | 修改原因 |
|---|---|---|
| 1 | 将 `difficulty` 从 `hard` 改为 `medium` | 题目属于产品设计与基础数据建模文档题，复杂度不足以支撑 hard |
| 2 | 将 `verification_method` 从 `rubric` 改为 `hybrid` | 原题包含 Automated Checks，不能同时标成纯 rubric；需与实际评分方式一致 |
| 3 | 将 `grading_type` 从 `llm_judge` 改为 `hybrid` | 原文件已包含自动评分逻辑，应声明为 hybrid |
| 4 | 调整 `grading_weights` 为 `automated: 0.2, llm_judge: 0.8` | 自动检查较弱，适合作为保底；主评分仍应由 LLM judge 完成 |
| 5 | 轻微改写 `Prompt` | 提高清晰度和自然度，避免过于口语化，同时不泄露具体答案 |
| 6 | 重写 `Expected Behavior` | 增加完整的行为要求、Ground Truth / Key Expectations 和 Trap Handling |
| 7 | 增加 `Ground Truth / Key Expectations` | 原版本缺少更清晰的可验证预期，补充后更利于评审 |
| 8 | 增加 `Trap Handling` | 明确说明 MVP 过度膨胀、数据模型过于空泛、两项目覆盖不平衡、技术说明空泛等陷阱及正确处理方式 |
| 9 | 重写 `Grading Criteria` | 使标准更独立、可验证，并与自动评分 key 更一致 |
| 10 | 重写 `grade()` 的零分初始化逻辑 | 满足缺文件/空输出时各项为 0.0 的要求 |
| 11 | 为 `read_text()` 增加 `encoding="utf-8"` | 提高稳健性 |
| 12 | 增加 `has_technical_considerations` 自动评分项 | 原 Criteria 中要求技术说明，但自动评分未单独覆盖，需补齐 |
| 13 | 增加 `mvp_scope_signal` 自动评分项 | 更好对齐“MVP 范围控制”这一核心要求 |
| 14 | 提高 `sufficient_depth` 阈值 | 原版 500 字过低，较难体现“可分享的实用文档”要求 |
| 15 | 保留 Automated Checks 但弱化其权重 | 关键词检查区分度有限，适合作为基础保底，不应主导最终评分 |
| 16 | 重写 LLM Judge Rubric 文字 | 强化“两项目都要覆盖”“关系应支撑 feature”“技术说明应贴合 MVP”这些判断标准 |