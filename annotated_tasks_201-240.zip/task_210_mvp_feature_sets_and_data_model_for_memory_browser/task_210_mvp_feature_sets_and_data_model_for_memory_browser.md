---
id: task_210_mvp_feature_sets_and_data_model_for_memory_browser
name: MVP Feature Sets and Data Model for Memory Browser and CRM
category: Knowledge Management
subcategory: Knowledge Base and Semantic Retrieval
difficulty: medium
external_dependency: none
verification_method: hybrid
input_modality: text-only
grading_type: hybrid
timeout_seconds: 240
grading_weights:
  automated: 0.2
  llm_judge: 0.8
workspace_files: []
source_line_number: 1262
source_query: "Propose MVP feature sets and a basic data model for two projects: a memory-document browser (for browsing/searching memory notes) and a CRM system"
---

## Prompt

I’m planning two side projects and want a clean MVP spec I can share with a developer friend.

Please propose MVP feature sets and a basic data model for each of these:

### Project 1: Memory Document Browser
- a tool for browsing and searching personal memory notes
- examples include journal entries, fleeting thoughts, meeting notes, and similar items
- should support semantic search, not just keyword search
- should handle different note types, and may use tags or categories

### Project 2: CRM System
- a simple CRM for a small consulting business
- should track contacts, companies, deals/opportunities, and interactions
- keep it lean and focused on core relationship-management workflows

For **each** project, include:
1. MVP feature list (lean, truly essential for v1)
2. Data model with entities, key attributes, and relationships
3. Brief technical considerations

Save the result to `mvp_spec.md`.

Make it structured and easy to scan.

## Expected Behavior

The agent should:

1. Create a document `mvp_spec.md`.
2. Cover **both** projects: the Memory Document Browser and the CRM System.
3. For each project, provide:
   - a lean MVP feature set
   - a basic but usable data model
   - brief technical considerations
4. Clearly describe entities, important attributes, and relationships in the data model.
5. Keep the scope appropriate for an MVP rather than a full enterprise product.

### Ground Truth / Key Expectations

A strong answer will usually include:

#### Memory Document Browser
Likely MVP features such as:
- note browsing/listing
- note detail view
- semantic search
- filtering by type / tag / category
- lightweight create/edit or import flow
- basic metadata support (timestamps, source/type, tags)

Likely data model elements such as:
- `Note`
- `Tag`
- optional `Category` or `Notebook`
- optional `Embedding` / search index representation
- relationships between notes and tags/categories

Likely technical considerations such as:
- embedding generation / vector search
- metadata filtering alongside semantic retrieval
- storage/indexing tradeoffs
- ingestion pipeline for different note types

#### CRM System
Likely MVP features such as:
- contact management
- company management
- deal / opportunity tracking
- interaction / activity logging
- simple pipeline or stage tracking
- basic search/filtering

Likely data model elements such as:
- `Contact`
- `Company`
- `Deal` or `Opportunity`
- `Interaction` or `Activity`
- optional ownership / user fields
- relationships between contacts, companies, deals, and interactions

Likely technical considerations such as:
- relational schema design
- auditability / activity history
- stage/status enums
- search/filtering and simple reporting
- avoiding feature bloat in v1

### Trap Handling

This task contains several common traps:

1. **Not actually MVP-scoped**
   The answer should avoid overloading v1 with advanced workflow automation, analytics, permissions, or other non-core features.

2. **Data model too vague**
   Listing only entity names is not enough; the response should include key attributes and relationships.

3. **Two projects must both be covered**
   A strong answer should not spend almost all detail on one project and barely address the other.

4. **Technical notes should support the proposed MVP**
   Technical considerations should be relevant and lightweight, not generic filler or over-engineered architecture.

## Grading Criteria

- [ ] File `mvp_spec.md` exists
- [ ] Covers both projects (Memory Browser and CRM)
- [ ] Each project includes an MVP feature set
- [ ] Each project includes a data model with entities and key attributes
- [ ] Relationships are described for both projects
- [ ] Technical considerations are mentioned for both projects
- [ ] Scope remains appropriate for MVP
- [ ] Document has enough substance to be practically useful

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    from pathlib import Path

    def _zero_scores():
        return {
            "file_exists": 0.0,
            "covers_both_projects": 0.0,
            "has_feature_lists": 0.0,
            "has_data_model": 0.0,
            "has_relationships": 0.0,
            "has_technical_considerations": 0.0,
            "mvp_scope_signal": 0.0,
            "sufficient_depth": 0.0,
        }

    scores = _zero_scores()
    ws = Path(workspace_path)

    spec = ws / "mvp_spec.md"
    if not spec.exists():
        return scores

    scores["file_exists"] = 1.0

    try:
        text = spec.read_text(encoding="utf-8").lower()
    except Exception:
        return scores

    memory_terms = ["memory", "document", "browser", "note", "semantic search"]
    crm_terms = ["crm", "contact", "deal", "company", "interaction", "opportunity"]

    memory_hits = sum(1 for t in memory_terms if t in text)
    crm_hits = sum(1 for t in crm_terms if t in text)
    if memory_hits >= 3 and crm_hits >= 3:
        scores["covers_both_projects"] = 1.0
    elif memory_hits >= 2 or crm_hits >= 2:
        scores["covers_both_projects"] = 0.5

    feature_indicators = ["feature", "mvp", "v1", "essential", "core"]
    feature_hits = sum(1 for t in feature_indicators if t in text)
    scores["has_feature_lists"] = 1.0 if feature_hits >= 2 else 0.0

    data_model_terms = ["entity", "attribute", "relationship", "field", "schema", "model", "table"]
    model_hits = sum(1 for t in data_model_terms if t in text)
    scores["has_data_model"] = 1.0 if model_hits >= 2 else 0.0

    relationship_terms = [
        "one-to-many", "many-to-many", "foreign key", "references",
        "belongs to", "has many", "relationship"
    ]
    scores["has_relationships"] = 1.0 if any(t in text for t in relationship_terms) else 0.0

    technical_terms = [
        "index", "embedding", "vector", "storage", "search", "schema",
        "enum", "audit", "pipeline", "filter", "retrieval"
    ]
    tech_hits = sum(1 for t in technical_terms if t in text)
    scores["has_technical_considerations"] = 1.0 if tech_hits >= 2 else 0.0

    mvp_scope_terms = ["mvp", "v1", "lean", "minimal", "essential", "avoid"]
    scope_hits = sum(1 for t in mvp_scope_terms if t in text)
    scores["mvp_scope_signal"] = 1.0 if scope_hits >= 2 else 0.5 if scope_hits == 1 else 0.0

    scores["sufficient_depth"] = 1.0 if len(text) >= 700 else 0.5 if len(text) >= 400 else 0.0

    return scores
```

## LLM Judge Rubric

### Criterion 1: MVP Feature Quality (Weight: 30%)

**Score 1.0**: Both projects have lean, well-prioritized MVP feature sets that cover the true v1 essentials without obvious bloat or critical omissions.
**Score 0.75**: Feature sets are generally strong, with only minor over-scoping or one small omission.
**Score 0.5**: Features are reasonable but either somewhat bloated or missing an important core workflow in one project.
**Score 0.25**: Feature lists are generic, poorly prioritized, or weakly scoped as MVPs.
**Score 0.0**: No meaningful MVP feature definition.

### Criterion 2: Data Model Completeness and Fit (Weight: 35%)

**Score 1.0**: Both projects include sensible entities, useful key attributes, and clearly defined relationships that directly support the proposed features.
**Score 0.75**: Good data models with only minor gaps in attributes or relationships.
**Score 0.5**: Basic data models are present, but one project is notably incomplete or relationships are under-specified.
**Score 0.25**: Data models are vague, incomplete, or weakly connected to the product requirements.
**Score 0.0**: No usable data modeling.

### Criterion 3: Technical Considerations (Weight: 20%)

**Score 1.0**: Technical notes are relevant, lightweight, and aligned to MVP needs for both projects, including appropriate search/indexing or schema considerations where relevant.
**Score 0.75**: Technical notes are useful overall, but one project is less well covered.
**Score 0.5**: Some technical considerations are present, but they are superficial or partly generic.
**Score 0.25**: Minimal technical discussion with little practical value.
**Score 0.0**: No meaningful technical considerations.

### Criterion 4: Organization, Balance, and Clarity (Weight: 15%)

**Score 1.0**: The document is well-structured, easy to scan, balanced across both projects, and shareable as a practical MVP spec.
**Score 0.75**: Clear and mostly balanced, with only minor structure or emphasis issues.
**Score 0.5**: Understandable but unevenly organized or disproportionately focused on one project.
**Score 0.25**: Hard to scan, unbalanced, or poorly structured.
**Score 0.0**: Disorganized or unusable.