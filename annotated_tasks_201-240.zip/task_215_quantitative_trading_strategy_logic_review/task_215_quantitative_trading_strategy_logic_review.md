---
id: task_215_quantitative_trading_strategy_logic_review
name: Quantitative Trading Strategy Logic Review
category: Finance
subcategory: Trading Strategy and Backtesting
difficulty: medium
external_dependency: none
verification_method: rubric
input_modality: text-only
grading_type: hybrid
timeout_seconds: 180
grading_weights:
  automated: 0.4
  llm_judge: 0.6
workspace_files: []
source_line_number: 8968
source_query: "审查以下量化交易策略的纯逻辑规则，判断是否具备进入代码回测阶段的资格。仅在存在致命逻辑硬伤时驳回（规则模糊不可编程、逻辑冲突/死锁、无硬止损风控、严重参数冗余/过度拟合）。请严格仅输出以下XML结构（不要输出额外文本）： <decision>准许测试</decision> 或 <decision>驳回重构</decision> <reason>（若准许测试：用一句话提示最大自然风险；若驳回重构：对照上述4类硬伤列出需要修改的致命缺陷清单）</reason> 策略如下：  # 策略名称：QuantArch-EMA-MACD-Pro-v2 # 策略版本：2.0 (重构增强版) # 优化轨道：核心逻辑重构 + 靶向模块增强 (轨道一 + 轨道二)  ## 1. 基础配置 (Configuration) - 主趋势周期：60分钟；交易执行周期：5分钟；适用市场：高流动性期货/加密货币/外汇主流对 - 指标：EMA(20/60/120主周期)、MACD(12,26,9)、ATR(14)  ## 2. 趋势过滤模块（60分钟） - 多头：收盘>EMA60；EMA60>EMA120；EMA60..."
---

## Prompt

Hey, I need you to review this quant trading strategy's pure logic rules and decide whether it is ready to move into the backtesting stage.

Only reject it if there are fatal logic flaws in one or more of these categories:
- rules are too vague to be coded
- logical conflicts or deadlocks exist
- there is no hard stop-loss risk control
- there is severe parameter redundancy or clear overfitting risk

Output only this exact XML structure and nothing else:

```xml
<decision>Approved for Testing</decision> or <decision>Rejected for Revision</decision>
<reason>(If approved: give one sentence describing the biggest natural risk. If rejected: list the fatal defects that require revision, aligned to the four categories above.)</reason>
```

Here is the strategy:

# Strategy Name: QuantArch-EMA-MACD-Pro-v2

# Version: 2.0 (Restructured Enhanced Edition)

# Optimization Track: Core Logic Restructure + Targeted Module Enhancement

## 1. Base Configuration

* Primary trend timeframe: 60-minute
* Trade execution timeframe: 5-minute
* Target markets: High-liquidity futures/crypto/major forex pairs
* Indicators: EMA(20/60/120 on primary), MACD(12,26,9), ATR(14)

## 2. Trend Filter Module (60-minute)

* Bullish: Close > EMA60; EMA60 > EMA120; Current EMA60 > EMA60 from 3 bars ago
* Bearish: Close < EMA60; EMA60 < EMA120; Current EMA60 < EMA60 from 3 bars ago

## 3. Entry Signals (5-minute)

* Long entry: Bullish trend confirmed; Close > EMA20; MACD fast line > 0; MACD golden cross OR histogram turns from negative to positive; ATR14 > 80% of 20-bar ATR average
* Short entry: Bearish trend confirmed; Close < EMA20; MACD fast line < 0; MACD death cross OR histogram turns from positive to negative; ATR14 > 80% of 20-bar ATR average

## 4. Exit & Risk Management

* Initial hard stop: Long = Entry - 2.5*ATR14(5m); Short = Entry + 2.5*ATR14(5m)
* Primary exit: 5m close below EMA60 (long) / above EMA60 (short)
* Breakeven: When floating profit reaches 1.5R, move stop to entry price + commission
* Trailing: After 3R profit, use Chandelier Exit: Long stop = Highest high - 3*ATR14; Short stop = Lowest low + 3*ATR14
* Time stop: Force close if profit hasn't exceeded 1R within 20 bars after entry

## 5. Position Sizing

* Single trade risk: 1% of equity
* Position size = (Equity * 1%) / (Entry price - Initial stop price)
* Max positions: No more than 3 non-correlated instruments simultaneously

## 6. Execution Constraints

* News: No new positions 30 minutes before/after major data releases
* Consecutive losses: Stop trading for the day after 3 consecutive losses
* Slippage: Use limit orders for entry (cancel if not filled); Use market orders for stops to ensure execution

## Expected Behavior

The agent should:

1. Evaluate the strategy only against the four allowed fatal flaw categories:

   * uncodable or overly vague rules
   * logical conflict or deadlock
   * missing hard stop-loss risk control
   * severe parameter redundancy or overfitting
2. Decide whether the strategy is ready for backtesting from a logic-review perspective only, not from a profitability, alpha quality, or live-trading-worthiness perspective.
3. Output only the required XML structure with exactly one `<decision>` tag and one `<reason>` tag.
4. Use exactly one of these decision values:

   * `Approved for Testing`
   * `Rejected for Revision`
5. If the decision is `Approved for Testing`, the reason should describe the biggest natural risk that remains even if the logic is acceptable for backtesting.
6. If the decision is `Rejected for Revision`, the reason should identify one or more fatal flaws and tie them to the allowed rejection categories.
7. Avoid rejecting the strategy based only on non-fatal operational ambiguity. For example, terms like `major data releases` or `non-correlated instruments` may need tighter implementation definitions later, but should not automatically count as fatal flaws unless they make the strategy fundamentally uncodable.

Ground Truth:

* Expected decision: `Approved for Testing`
* Expected reasoning direction: the strategy is sufficiently codable for backtesting, includes an explicit hard stop, does not show an obvious logical deadlock, and any remaining concern should be framed as a natural risk rather than a fatal logic flaw.

Potential traps and correct handling:

* Do not reject the strategy for non-fatal implementation ambiguity alone.
* Do not judge the strategy based on expected profitability or whether it is likely to outperform.
* Do not convert natural market risks into fatal logic flaws.

Tested capabilities:

* financial domain knowledge
* logical analysis
* structured output compliance
* distinguishing fatal flaws from non-fatal risk

## Grading Criteria

* [ ] Output contains both `<decision>` and `<reason>` tags
* [ ] Decision value is exactly `Approved for Testing` or `Rejected for Revision`
* [ ] If the decision is `Approved for Testing`, the reason describes a natural risk rather than a fatal flaw
* [ ] If the decision is `Rejected for Revision`, the reason identifies at least one fatal flaw aligned with the allowed rejection categories
* [ ] The response applies the “reject only for fatal logic flaws” standard
* [ ] No extra text appears outside the required XML structure

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    import re

    scores = {
        "has_required_tags": 0.0,
        "valid_decision_value": 0.0,
        "reason_matches_decision": 0.0,
        "applies_fatal_flaw_standard": 0.0,
        "no_extra_text": 0.0,
        "strict_xml_structure": 0.0,
    }

    def _get_last_assistant_text(transcript: list) -> str:
        for event in reversed(transcript):
            if event.get("type") != "message":
                continue
            msg = event.get("message", {})
            if msg.get("role") != "assistant":
                continue
            content = msg.get("content", "")
            if isinstance(content, str):
                return content
            if isinstance(content, list):
                texts = []
                for item in content:
                    if isinstance(item, dict) and item.get("type") == "text":
                        texts.append(item.get("text", ""))
                return "\n".join(texts).strip()
        return ""

    text = _get_last_assistant_text(transcript)
    if not text or not text.strip():
        return scores

    text = text.strip()

    decision_match = re.search(
        r"<decision>\s*(Approved for Testing|Rejected for Revision)\s*</decision>",
        text,
        flags=re.IGNORECASE | re.DOTALL
    )
    reason_match = re.search(
        r"<reason>\s*(.*?)\s*</reason>",
        text,
        flags=re.IGNORECASE | re.DOTALL
    )

    if decision_match and reason_match:
        scores["has_required_tags"] = 1.0
    elif decision_match or reason_match:
        scores["has_required_tags"] = 0.5

    decision = decision_match.group(1).strip().lower() if decision_match else ""
    reason = reason_match.group(1).strip() if reason_match else ""

    if decision in {"approved for testing", "rejected for revision"}:
        scores["valid_decision_value"] = 1.0

    exact_xml = re.compile(
        r"^\s*<decision>\s*(Approved for Testing|Rejected for Revision)\s*</decision>\s*<reason>\s*.*?\s*</reason>\s*$",
        flags=re.IGNORECASE | re.DOTALL
    )

    if exact_xml.match(text):
        scores["strict_xml_structure"] = 1.0
        scores["no_extra_text"] = 1.0
    else:
        extra = re.sub(r"<decision>.*?</decision>", "", text, flags=re.IGNORECASE | re.DOTALL)
        extra = re.sub(r"<reason>.*?</reason>", "", extra, flags=re.IGNORECASE | re.DOTALL).strip()

        if len(extra) == 0:
            scores["no_extra_text"] = 1.0
        elif len(extra) <= 20:
            scores["no_extra_text"] = 0.5
        else:
            scores["no_extra_text"] = 0.0

        if decision_match and reason_match:
            scores["strict_xml_structure"] = 0.5

    fatal_keywords = [
        "vague", "uncodable", "cannot be coded", "not codable",
        "logical conflict", "conflict", "deadlock",
        "no hard stop", "missing hard stop", "no stop-loss",
        "parameter redundancy", "overfit", "overfitting", "fatal flaw"
    ]
    natural_risk_keywords = [
        "whipsaw", "slippage", "lag", "lagging", "regime", "volatility",
        "chop", "false breakout", "drawdown", "correlation drift",
        "news risk", "execution risk", "trend reversal"
    ]

    reason_lower = reason.lower()

    if decision == "approved for testing":
        has_fatal = any(k in reason_lower for k in fatal_keywords)
        has_natural_risk = any(k in reason_lower for k in natural_risk_keywords)

        if len(reason) >= 8 and has_natural_risk and not has_fatal:
            scores["reason_matches_decision"] = 1.0
        elif len(reason) >= 8 and not has_fatal:
            scores["reason_matches_decision"] = 0.5

        if scores["reason_matches_decision"] >= 0.5:
            scores["applies_fatal_flaw_standard"] = 1.0

    elif decision == "rejected for revision":
        matched_fatal = sum(1 for k in fatal_keywords if k in reason_lower)

        if len(reason) >= 8 and matched_fatal >= 1:
            scores["reason_matches_decision"] = 1.0
        elif len(reason) >= 8:
            scores["reason_matches_decision"] = 0.5

        if scores["reason_matches_decision"] >= 0.5:
            scores["applies_fatal_flaw_standard"] = 1.0

    return scores
```

## LLM Judge Rubric

### Criterion 1: Fatal Flaw Analysis Accuracy (Weight: 40%)

**Score 1.0**: Correctly evaluates the strategy using only the four allowed fatal flaw categories and clearly distinguishes fatal flaws from non-fatal concerns.
**Score 0.75**: Mostly accurate, with only minor overreach or omission.
**Score 0.5**: Partially accurate, but mixes fatal flaws with secondary implementation concerns.
**Score 0.25**: Shows substantial misunderstanding of the fatal flaw standard.
**Score 0.0**: Fails to apply the required fatal flaw framework.

### Criterion 2: Decision and Reason Alignment (Weight: 35%)

**Score 1.0**: The decision is well supported by the strategy text; if approving, the reason names a plausible natural risk; if rejecting, the reason clearly identifies fatal flaws tied to the allowed categories.
**Score 0.75**: The decision is mostly defensible, but the explanation has minor weaknesses.
**Score 0.5**: The decision is somewhat plausible, but the explanation is generic, incomplete, or weakly grounded.
**Score 0.25**: The decision and explanation are poorly aligned or weakly supported.
**Score 0.0**: The decision is clearly unsupported by the strategy text.

### Criterion 3: Output Format Compliance (Weight: 25%)

**Score 1.0**: Output contains only the required XML structure with `<decision>` and `<reason>` and no extra text.
**Score 0.75**: XML structure is correct with only trivial formatting deviation.
**Score 0.5**: XML structure is present but includes noticeable extra text or formatting issues.
**Score 0.25**: Partial XML compliance with major deviations.
**Score 0.0**: Does not follow the required output format.