| 序号 | 修改项 | 修改原因 |
|---|---|---|
| 1 | 将 `difficulty` 从 `hard` 改为 `medium` | 题目要求的是策略逻辑审查与结构化输出，复杂度不足以稳定支撑 hard，medium 更匹配 |
| 2 | 重写 `Prompt` | 保持要求清晰，同时避免与修正后的评分逻辑冲突 |
| 3 | 重写 `Expected Behavior` | 原版本存在答案泄露倾向，修正为中性、完整、可执行，并补充 Ground Truth 与 trap handling |
| 4 | 补充 `Ground Truth` | 满足“答案明确、可验证”的要求 |
| 5 | 补充 `Potential traps and correct handling` | 满足“陷阱说明”要求，明确哪些问题不应被误判为致命硬伤 |
| 6 | 重写 `Grading Criteria` | 调整为 6 条，满足数量合理、可独立验证、覆盖关键点、有区分度 |
| 7 | 重写 `grade()` 函数 | 修复原函数与任务要求不一致的问题，使其识别英文 decision 值并检查 reason 与 decision 是否匹配 |
| 8 | 增加空白零分逻辑 | 满足“空白零分”要求，输出为空时所有 score key 返回 0.0 |
| 9 | 增加部分得分逻辑 | 对标签存在但不完整、结构接近、reason 基本合理等情况提供 0.5 分，而非纯 0/1 |
| 10 | 使 `score key` 与 `Grading Criteria` 对齐 | 提升自动评分项和文字标准的一致性 |
| 11 | 重写 `LLM Judge Rubric` | 去除过强答案暗示，改为基于 fatal flaw 标准的中性判分 rubric |