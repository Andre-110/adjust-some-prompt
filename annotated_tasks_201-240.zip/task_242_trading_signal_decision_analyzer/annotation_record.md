| 序号 | 修改项 | 修改原因 |
|---|---|---|
| 1 | difficulty 从 hard 改为 medium | 题目结构与 task_241 高度相似，复杂度不足 hard |
| 2 | 删除 Prompt 末尾的思考提示段落 | 直接引导模型得出"信号冲突"结论，泄露 Expected Behavior 的核心答案 |
| 3 | Expected Behavior 补充陷阱说明 | 原文缺少对三个关键陷阱的明确处理说明 |
| 4 | Grading Criteria 增加第 8 条（risk 合理性） | Expected Behavior 明确要求 HIGH/medium risk，但 Grading Criteria 未体现 |
| 5 | grade() JSON 提取改为括号计数法 | 原正则对嵌套结构脆弱，括号计数法更健壮 |
| 6 | 删除 grade() 中的 `no_fabrication` 检查 | 检查逻辑过于简单易误判，且与 Grading Criteria 无对应条目（key 未对齐）；fabrication 检测交由 LLM Judge 处理 |
| 7 | grade() 增加 `risk_appropriate` score key | 对应新增的 Grading Criteria 第 8 条 |