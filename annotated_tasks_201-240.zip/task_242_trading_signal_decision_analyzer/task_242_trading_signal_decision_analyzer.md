---
id: task_242_trading_signal_decision_analyzer
name: Trading Signal Decision Analyzer
category: Finance
subcategory: Trading Strategy and Backtesting
difficulty: medium
external_dependency: none
verification_method: rubric
input_modality: text-only
grading_type: hybrid
timeout_seconds: 180
grading_weights:
  automated: 0.4
  llm_judge: 0.6
workspace_files: []
source_line_number: 7493
source_query: "Analyze the following trading signal, market data, and portfolio status, then decide whether to trade and how to size the position. Signal: BUY; confidence: LOW; pattern: double_bottom. Market: current price $198.42; trend strong_downtrend; volume 1.7x average; ATR $6.61; price below EMA20. Portfolio: available cash $1,000,000; current position 0 shares. Output ONLY valid JSON with fields: action (BUY|SELL|HOLD), position_size_pct (0-20), risk_assessment (low|medium|high), rationale (detailed..."
---

## Prompt

Hey, I need you to analyze this trading opportunity and give me a decision. Here's all the info:

Signal: BUY with LOW confidence, pattern detected is double_bottom

Market conditions:
- Price right now: $198.42
- Trend: strong_downtrend
- Volume is 1.7x the average
- ATR (volatility): $6.61
- Price is below the EMA20

My portfolio:
- Cash available: $1,000,000
- Currently holding 0 shares
- No existing position

I need you to decide:
1. Trade or not? (BUY/SELL/HOLD)
2. Position size as a percentage of available capital (0-20%)
3. Risk level (low/medium/high)
4. Why you're making this call

Output ONLY valid JSON with these exact fields:
- action: BUY, SELL, or HOLD
- position_size_pct: number between 0 and 20
- risk_assessment: low, medium, or high
- rationale: detailed explanation of your reasoning
- key_factors: array of strings listing the main factors you considered

No other text, just the JSON.

## Expected Behavior

The agent should:
1. Recognize the conflicting signals (BUY signal vs strong downtrend)
2. Account for the LOW confidence level when sizing the position
3. Weigh the elevated volume (1.7x average) — noting it could indicate either capitulation or trend continuation, and that this ambiguity warrants caution rather than boldness
4. Consider that price below EMA20 confirms bearish momentum
5. Provide a conservative decision given the mixed signals
6. Output properly formatted JSON with all required fields

Key insight: A double_bottom in a strong_downtrend with LOW confidence suggests either HOLD (wait for confirmation) or a very small BUY position (2-5%) given the counter-trend nature. HIGH or medium risk assessment is appropriate given the conflicting factors.

**Trap handling — the agent should correctly navigate the following traps:**

- **Signal vs. trend conflict**: The BUY signal directly contradicts the strong_downtrend. The correct response is caution (HOLD or very small position ≤5%), not blind execution of the signal.
- **Volume ambiguity**: 1.7x average volume could mean capitulation (bullish for reversal) or panic selling (bearish continuation). The agent should acknowledge this ambiguity rather than treating volume as unambiguous confirmation of either direction.
- **LOW confidence signal**: A low-confidence signal should substantially reduce position sizing. Acting with a large position (>10%) is inappropriate.
- **SELL with zero position**: The current position is 0 shares. A SELL action with non-zero position_size_pct is logically invalid (cannot sell what is not owned). If SELL is chosen, position_size_pct must be 0.
- **Risk underestimation**: Given the strong downtrend and low confidence, assessing risk as "low" is a factual error regardless of reasoning.

## Grading Criteria

- [ ] Output is valid JSON
- [ ] Contains all required fields (action, position_size_pct, risk_assessment, rationale, key_factors)
- [ ] position_size_pct is within 0-20 range
- [ ] action is one of BUY, SELL, HOLD
- [ ] risk_assessment is one of low, medium, high
- [ ] key_factors is an array with at least 2 items
- [ ] rationale mentions the conflicting signals (downtrend vs buy signal)
- [ ] risk_assessment is medium or high (not low), reflecting the strong downtrend and LOW confidence signal

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    import json
    import re

    def _get_last_assistant_text(transcript: list) -> str:
        for event in reversed(transcript):
            if event.get("type") != "message":
                continue
            msg = event.get("message", {})
            if msg.get("role") != "assistant":
                continue
            for item in msg.get("content", []):
                if isinstance(item, dict) and item.get("type") == "text":
                    return item.get("text", "")
            content = msg.get("content", "")
            if isinstance(content, str):
                return content
        return ""

    def _extract_json(text: str) -> str:
        brace_count = 0
        start_idx = -1
        for i, c in enumerate(text):
            if c == '{':
                if brace_count == 0:
                    start_idx = i
                brace_count += 1
            elif c == '}':
                brace_count -= 1
                if brace_count == 0 and start_idx != -1:
                    return text[start_idx:i + 1]
        return ""

    scores = {}
    text = _get_last_assistant_text(transcript)

    if not text.strip():
        return {
            "valid_json": 0.0,
            "has_all_fields": 0.0,
            "position_size_valid": 0.0,
            "action_valid": 0.0,
            "risk_valid": 0.0,
            "key_factors_valid": 0.0,
            "mentions_conflict": 0.0,
            "risk_appropriate": 0.0,
        }

    json_str = _extract_json(text)
    if not json_str:
        json_str = text.strip()

    try:
        data = json.loads(json_str)
        scores["valid_json"] = 1.0
    except json.JSONDecodeError:
        return {
            "valid_json": 0.0,
            "has_all_fields": 0.0,
            "position_size_valid": 0.0,
            "action_valid": 0.0,
            "risk_valid": 0.0,
            "key_factors_valid": 0.0,
            "mentions_conflict": 0.0,
            "risk_appropriate": 0.0,
        }

    required_fields = ["action", "position_size_pct", "risk_assessment", "rationale", "key_factors"]
    has_all = all(field in data for field in required_fields)
    scores["has_all_fields"] = 1.0 if has_all else 0.0

    pos_size = data.get("position_size_pct")
    if isinstance(pos_size, (int, float)) and 0 <= pos_size <= 20:
        scores["position_size_valid"] = 1.0
    else:
        scores["position_size_valid"] = 0.0

    action = data.get("action", "").upper() if isinstance(data.get("action"), str) else ""
    scores["action_valid"] = 1.0 if action in ["BUY", "SELL", "HOLD"] else 0.0

    risk = data.get("risk_assessment", "").lower() if isinstance(data.get("risk_assessment"), str) else ""
    scores["risk_valid"] = 1.0 if risk in ["low", "medium", "high"] else 0.0

    key_factors = data.get("key_factors", [])
    if isinstance(key_factors, list) and len(key_factors) >= 2:
        scores["key_factors_valid"] = 1.0
    else:
        scores["key_factors_valid"] = 0.0

    rationale = data.get("rationale", "").lower() if isinstance(data.get("rationale"), str) else ""
    conflict_terms = ["downtrend", "trend", "conflicting", "against", "counter", "bearish", "ema", "below"]
    signal_terms = ["buy signal", "double bottom", "pattern", "signal", "low confidence"]
    has_trend_mention = any(term in rationale for term in conflict_terms)
    has_signal_mention = any(term in rationale for term in signal_terms)
    if has_trend_mention and has_signal_mention:
        scores["mentions_conflict"] = 1.0
    elif has_trend_mention or has_signal_mention:
        scores["mentions_conflict"] = 0.5
    else:
        scores["mentions_conflict"] = 0.0

    # Risk should be medium or high given strong downtrend + LOW confidence
    if risk in ["medium", "high"]:
        scores["risk_appropriate"] = 1.0
    elif risk == "low":
        scores["risk_appropriate"] = 0.0
    else:
        scores["risk_appropriate"] = 0.0

    return scores
```

## LLM Judge Rubric

### Criterion 1: Decision Quality (Weight: 40%)

**Score 1.0**: Decision appropriately accounts for conflicting signals. If BUY, position size is conservative (≤5%) given LOW confidence and counter-trend nature. If HOLD, reasoning correctly identifies need for confirmation. Risk assessment is medium or high.
**Score 0.75**: Decision is reasonable but position sizing slightly aggressive (6-10%) or risk assessment doesn't fully match the situation.
**Score 0.5**: Decision makes some sense but doesn't adequately address the conflicting signals or uses inappropriate position sizing (>10%).
**Score 0.25**: Decision ignores key factors like the strong downtrend or LOW confidence.
**Score 0.0**: Decision is completely inappropriate (e.g., SELL with non-zero position size when holding 0 shares, or position >20%).

### Criterion 2: Analysis Depth (Weight: 35%)

**Score 1.0**: Rationale thoroughly addresses: trend vs signal conflict, double bottom reliability in downtrends, volume ambiguity (capitulation vs continuation), LOW confidence impact, and price below EMA20. Key factors are comprehensive and relevant.
**Score 0.75**: Rationale covers most important factors with good reasoning but misses one or two considerations.
**Score 0.5**: Rationale mentions several factors but analysis is superficial or misses the core conflict.
**Score 0.25**: Rationale is brief and misses most key considerations.
**Score 0.0**: No meaningful analysis or rationale is generic/irrelevant.

### Criterion 3: Professional Quality (Weight: 25%)

**Score 1.0**: Response demonstrates trading knowledge — mentions concepts like confirmation, risk management, counter-trend trading caution, or pattern reliability. Language is precise and professional. Does not fabricate data not provided in the prompt.
**Score 0.75**: Response shows good understanding with minor gaps in terminology or concepts.
**Score 0.5**: Response is understandable but lacks professional depth or uses imprecise language.
**Score 0.25**: Response is vague or shows misunderstanding of trading concepts.
**Score 0.0**: Response demonstrates no trading knowledge, is incoherent, or fabricates market data not present in the input.