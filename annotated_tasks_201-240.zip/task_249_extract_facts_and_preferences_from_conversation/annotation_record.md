| 序号 | 修改项 | 修改原因 |
|---|---|---|
| 1 | Expected Behavior 补充陷阱说明 | 缺少对"说话者角色归属混淆"和"直接保留 yesterday 不转换"两个陷阱的处理说明 |
| 2 | Grading Criteria 增加第 9 条（actress feedback） | 演员对 Joanna 剧本的正面反馈是 Expected Behavior 第 3 点明确要求的，但 Grading Criteria 中缺失 |
| 3 | grade() 新增 `joanna_actress_feedback` score key | 对应新增的 Grading Criteria 第 9 条 |
| 4 | 删除 grade() 中 `no_fabrication` 检查，删除 Grading Criteria 对应条目 | 检测词汇过于特定，几乎永远得满分，无区分度；真正的 fabrication 检测需要 LLM |
| 5 | LLM Judge Rubric 各维度补充等级描述 | 原文只有维度描述，缺少 1.0/0.75/0.5/0.25/0.0 各等级的具体说明 |