---
id: task_249_extract_facts_and_preferences_from_conversation
name: Extract Facts and Preferences from Conversation
category: Data Analysis
subcategory: Text Parsing
difficulty: medium
external_dependency: none
verification_method: unit-test
input_modality: text-only
grading_type: hybrid
grading_weights:
  automated: 0.4
  llm_judge: 0.6
timeout_seconds: 120
workspace_files: []
source_line_number: 5684
source_query: "Extract relevant facts and preferences from the conversation below. Use the exact date/time 12:06 am on 11 November 2022 to resolve relative references (e.g., "yesterday", "last week") into explicit dates.  Conversation: User: [Joanna] Nate, can you believe it? I'm finally filming my own movie from the road-trip script! Assistant: [Nate] Congrats, Joanna! Not surprised at all that your hard work paid off. Must feel awesome to see your script come alive in a movie! Pretty cool when something y..."
---

## Prompt

Hey, I need you to extract all the relevant facts and preferences from this conversation between Joanna and Nate. Use the exact timestamp 12:06 am on November 11, 2022 to resolve any relative dates like "yesterday" into actual dates.

Save the extracted info to `facts.json` with separate sections for each person.

Here's the conversation:

```
User: [Joanna] Nate, can you believe it? I'm finally filming my own movie from the road-trip script!
Assistant: [Nate] Congrats, Joanna! Not surprised at all that your hard work paid off. Must feel awesome to see your script come alive in a movie! Pretty cool when something you love brings success, right? Tell me more about your movie!
User: [Joanna] Woohoo, thanks Nate! It's pretty wild to see it come alive. Every day on set is awesome and full of potential. Being able to show my vision is awesome.
Assistant: [Nate] I think so too! What's been the coolest moment on set?
User: [Joanna] One of the actors came up to me and told me how much she liked my script! I was so excited when that happened - it gave me chills!
Assistant: [Nate] Wow Joanna, that must have been so exciting! It's incredible when you get those moments of joy. Anyway, I took my turtles to the beach in Tampa yesterday! They always bring me peace in the craziness of life.
User: [Joanna] Woah, that's awesome, Nate! You must really enjoy having them around - they're so cool! What do you love most about having them?
Assistant: [Nate] Your completely right! I really love having them around. They're so cool and they make me feel calm. Plus, they don't require much looking after, which is great. I love seeing them soaking in the sun like this.
User: [Joanna] That's awesome, Nate! They look so serene and happy. It's great to have something like that.
Assistant: [Nate] Yeah, turtles are like zen masters! They always remind me to slow down and appreciate the small things in life. I'm loving experimenting with flavors right now. Here are some colorful bowls of coconut milk ice cream that I made.
User: [Joanna] Hey Nate, that looks really yummy! The colors and mix-ins give it a nice kick.
Assistant: [Nate] Nice! I'm glad you like it too. This recipe really jazzes it up. Wanna give it a try?
User: [Joanna] Definitely, Nate! That ice cream looks mouthwatering. Thanks so much for offering!
Assistant: [Nate] No worries, Joanna. Hope you enjoy it!
User: [Joanna] Yea, no worries! It was great catching up. Take it easy!
```

Make sure to convert "yesterday" to the actual date based on the timestamp I gave you.

## Expected Behavior

The agent should:
1. Identify facts about Joanna: filming a movie from her road-trip script, works on set, received positive feedback from an actress about her script
2. Identify facts about Nate: owns turtles, took them to Tampa beach on November 10, 2022 (yesterday from the reference date), turtles make him feel calm, they're low maintenance, he makes coconut milk ice cream, enjoys experimenting with flavors
3. Identify preferences: Nate finds turtles calming/peaceful, Nate enjoys cooking/experimenting, Joanna is passionate about filmmaking
4. Convert "yesterday" to November 10, 2022 (the reference timestamp is 12:06 am on November 11, 2022, so yesterday = November 10, 2022)
5. Output structured JSON with clear attribution to each person

Tested capabilities: information extraction, temporal reasoning, structured output generation, distinguishing facts from preferences.

**Trap handling — the agent should correctly navigate the following traps:**

- **Speaker attribution from dialogue format**: The conversation uses `User: [Joanna]` and `Assistant: [Nate]` formatting. The agent must attribute facts to the named person (Joanna or Nate), not to the role label (User or Assistant). Assigning Nate's turtle ownership to "the assistant" rather than to Nate is a misattribution error.
- **Relative date must be resolved**: The word "yesterday" must be converted to the explicit date November 10, 2022. Leaving it as "yesterday" in the output is incorrect. The reference timestamp is November 11, 2022 at 12:06 am, so "yesterday" unambiguously refers to November 10, 2022.

## Grading Criteria

- [ ] File `facts.json` exists and is valid JSON
- [ ] Joanna's movie/filmmaking activity is captured
- [ ] Joanna's road-trip script is mentioned
- [ ] Joanna's actress feedback is captured (an actress praised her script)
- [ ] Nate's turtle ownership is captured
- [ ] Tampa beach visit is recorded with correct date (November 10, 2022)
- [ ] Nate's coconut milk ice cream making is captured
- [ ] Date conversion is correct (yesterday = November 10, 2022)

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    from pathlib import Path
    import json
    import re

    scores = {}
    ws = Path(workspace_path)

    facts_file = ws / "facts.json"
    scores["file_exists"] = 1.0 if facts_file.exists() else 0.0

    if not facts_file.exists():
        scores["valid_json"] = 0.0
        scores["joanna_movie"] = 0.0
        scores["joanna_script"] = 0.0
        scores["joanna_actress_feedback"] = 0.0
        scores["nate_turtles"] = 0.0
        scores["tampa_beach"] = 0.0
        scores["correct_date"] = 0.0
        scores["nate_ice_cream"] = 0.0
        return scores

    try:
        content = facts_file.read_text(errors="ignore")
        data = json.loads(content)
        scores["valid_json"] = 1.0
    except Exception:
        scores["valid_json"] = 0.0
        scores["joanna_movie"] = 0.0
        scores["joanna_script"] = 0.0
        scores["joanna_actress_feedback"] = 0.0
        scores["nate_turtles"] = 0.0
        scores["tampa_beach"] = 0.0
        scores["correct_date"] = 0.0
        scores["nate_ice_cream"] = 0.0
        return scores

    content_lower = content.lower()

    movie_terms = ["movie", "film", "filming"]
    scores["joanna_movie"] = 1.0 if any(t in content_lower for t in movie_terms) else 0.0

    script_terms = ["road-trip", "road trip", "roadtrip", "script"]
    scores["joanna_script"] = 1.0 if any(t in content_lower for t in script_terms) else 0.0

    actress_terms = ["actress", "actor", "cast", "compliment", "praised", "liked", "positive feedback"]
    scores["joanna_actress_feedback"] = 1.0 if any(t in content_lower for t in actress_terms) else 0.0

    scores["nate_turtles"] = 1.0 if "turtle" in content_lower else 0.0

    scores["tampa_beach"] = 1.0 if "tampa" in content_lower and "beach" in content_lower else 0.0

    date_patterns = [
        r"november\s*10",
        r"nov\s*10",
        r"10\s*november",
        r"10\s*nov",
        r"2022[-/]11[-/]10",
        r"11[-/]10[-/]2022",
        r"10[-/]11[-/]2022",
        r"november 10,?\s*2022",
        r"nov 10,?\s*2022",
        r"10 november 2022",
    ]
    has_correct_date = any(re.search(p, content_lower) for p in date_patterns)
    scores["correct_date"] = 1.0 if has_correct_date else 0.0

    ice_cream_terms = ["ice cream", "ice-cream", "icecream", "coconut milk"]
    scores["nate_ice_cream"] = 1.0 if any(t in content_lower for t in ice_cream_terms) else 0.0

    return scores
```

## LLM Judge Rubric

### Criterion 1: Completeness (Weight: 30%)

**Score 1.0**: All major facts captured for both people: Joanna's movie filming, road-trip script origin, actress compliment; Nate's turtle ownership, Tampa beach trip with resolved date, coconut milk ice cream making, and flavor experimentation.
**Score 0.75**: Most facts present but one minor fact missing (e.g., actress compliment or flavor experimentation omitted).
**Score 0.5**: Core facts present (movie, turtles, ice cream) but 2–3 supporting details missing.
**Score 0.25**: Only the most obvious facts captured; significant portions of the conversation not reflected.
**Score 0.0**: Fewer than half the facts captured or output is largely empty.

### Criterion 2: Accuracy (Weight: 25%)

**Score 1.0**: All extracted facts are accurate and correctly attributed to Joanna or Nate. No misattributions or embellishments beyond what is stated in the conversation.
**Score 0.75**: Facts are mostly accurate but one fact is slightly embellished or a minor detail is misattributed.
**Score 0.5**: Some facts are correct but there are notable misattributions (e.g., Nate's facts attributed to Joanna) or one fabricated fact.
**Score 0.25**: Several inaccuracies or misattributions; the output would mislead a reader about the conversation.
**Score 0.0**: Facts are largely incorrect, fabricated, or systematically misattributed.

### Criterion 3: Date Resolution (Weight: 20%)

**Score 1.0**: "Yesterday" is correctly resolved to November 10, 2022 and explicitly stated as such in the output. The Tampa beach visit date is clearly recorded as November 10, 2022.
**Score 0.75**: Date is correctly resolved but the format is ambiguous (e.g., "10/11/2022" without specifying month-first or day-first convention).
**Score 0.5**: The date November 10 appears but year is missing or attribution to the beach trip is unclear.
**Score 0.25**: Incorrect date (e.g., November 11 instead of November 10) or "yesterday" is left unresolved.
**Score 0.0**: No date resolution attempted; "yesterday" appears verbatim in the output.

### Criterion 4: Organization (Weight: 15%)

**Score 1.0**: JSON is well-structured with clear separation between Joanna and Nate. Facts and preferences are distinguished within each person's section. Keys are meaningful and consistent.
**Score 0.75**: Clear separation between people but facts and preferences are not distinguished, or structure is slightly inconsistent.
**Score 0.5**: Both people are present in the JSON but structure is flat or hard to navigate.
**Score 0.25**: Output is valid JSON but organization is poor — e.g., a single flat list with no person separation.
**Score 0.0**: Output is not valid JSON or has no discernible structure.

### Criterion 5: Preference Identification (Weight: 10%)

**Score 1.0**: Subjective preferences are clearly distinguished from objective facts — e.g., Nate finding turtles calming, enjoying flavor experimentation, and Joanna's passion for filmmaking are labeled as preferences or attitudes rather than facts.
**Score 0.75**: Most preferences identified but one or two are lumped in with facts without distinction.
**Score 0.5**: Preferences are present in the output but not clearly differentiated from facts.
**Score 0.25**: Only one preference identified or distinction between facts and preferences is absent.
**Score 0.0**: No preferences identified or no attempt to distinguish subjective attitudes from objective facts.