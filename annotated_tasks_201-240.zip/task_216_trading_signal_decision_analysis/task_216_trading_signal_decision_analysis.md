---
id: task_216_trading_signal_decision_analysis
name: Trading Signal Decision Analysis
category: Finance
subcategory: Trading Strategy and Backtesting
difficulty: medium
external_dependency: none
verification_method: output-check
input_modality: text-only
grading_type: hybrid
grading_weights:
  automated: 0.4
  llm_judge: 0.6
timeout_seconds: 120
workspace_files: []
source_line_number: 6973
source_query: "Given the following signal, market data, and portfolio status, decide whether to trade (BUY/SELL/HOLD), choose a position size as a percentage of available capital (0–20%), assess risk (low/medium/high), and provide a detailed rationale and key factors. Consider signal strength/pattern reliability, trend alignment, risk/reward, diversification, and sizing based on confidence.  Signal: SELL (confidence: LOW); pattern: bearish_engulfing Market: price $288.40; trend strong_uptrend; volume vs avg..."
---

## Prompt

I need a quick trading decision on the setup below.

Please analyze the signal, market context, and portfolio status, then return **only valid JSON** in the exact schema shown below.

Situation:

Signal info:
- Signal: SELL
- Confidence: LOW
- Pattern detected: bearish_engulfing

Market data:
- Current price: $288.40
- Trend: strong_uptrend
- Volume vs average: 0.97x
- Volatility (ATR): $12.69
- Price vs EMA20: above

Portfolio:
- Available cash: $1,000,000
- Current position: 0 shares
- Total portfolio value: $1,000,000

Required output:
1. `action`: one of `BUY`, `SELL`, `HOLD`
2. `position_size_pct`: a number from 0 to 20
3. `risk_assessment`: one of `low`, `medium`, `high`
4. `rationale`: a concise but meaningful explanation
5. `key_factors`: an array of the main factors that drove the decision

Consider signal quality, trend alignment, pattern reliability, risk/reward, portfolio context, and whether the suggested size matches the level of conviction.

Return only:

```json
{
  "action": "BUY|SELL|HOLD",
  "position_size_pct": 0,
  "risk_assessment": "low|medium|high",
  "rationale": "string",
  "key_factors": ["factor1", "factor2"]
}
````

## Expected Behavior

A strong answer should evaluate the trade idea by balancing the raw signal against the broader market context rather than blindly following the detected pattern.

Recommended reasoning path:

1. Assess the signal itself

   * The signal direction is `SELL`
   * Confidence is explicitly `LOW`
   * The detected pattern is `bearish_engulfing`, which on its own is not always strong enough to override the broader market context

2. Assess trend alignment

   * The market trend is `strong_uptrend`
   * Price is above EMA20, which supports the bullish trend context
   * A short trade that goes against a strong uptrend should generally be treated cautiously

3. Assess confirmation quality

   * Volume is only `0.97x` average, so there is no obvious strong confirmation from unusually high participation
   * ATR indicates meaningful volatility, which increases risk if taking a counter-trend trade

4. Decide action and size consistently

   * A cautious, risk-aware answer will usually avoid an aggressive short
   * Acceptable high-quality outputs are typically:

     * `HOLD` with `position_size_pct = 0`, or
     * a very small exploratory `SELL` position, usually in the low single digits
   * An aggressive `SELL` with large size would usually be inconsistent with the evidence
   * A `BUY` is less natural than `HOLD` here because the explicit signal is bearish, even if weak

5. Set risk assessment consistently

   * If choosing `SELL`, risk should generally be `high` because it is counter-trend and low-confidence
   * If choosing `HOLD`, `risk_assessment` may reasonably reflect the setup risk rather than portfolio risk; `medium` or `high` can both be defensible if the rationale is coherent

Ground Truth / acceptable answer band:

* Best-supported decision: `HOLD`, size `0`
* Also acceptable: very small `SELL` such as `1-5%`
* Usually not acceptable: aggressive `SELL` sizing, or a confident directional call that ignores the low-confidence/counter-trend conflict

Key traps:

* Do not treat every detected candlestick pattern as tradable on its own
* Do not recommend a large short position against a strong uptrend with low-confidence evidence
* Do not ignore the relationship between action, position size, and risk assessment
* Do not output extra commentary outside the JSON

Tested capabilities: trading signal interpretation, context-aware decision-making, risk sizing, structured JSON output, and consistency between reasoning and action.

## Grading Criteria

* [ ] Output is valid JSON and includes all required fields
* [ ] `action` is one of `BUY`, `SELL`, or `HOLD`, and `position_size_pct` is within `0-20`
* [ ] `risk_assessment` is one of `low`, `medium`, or `high`
* [ ] `rationale` and `key_factors` are meaningful and non-empty
* [ ] The decision logic is risk-aware and does not recommend an aggressive counter-trend short
* [ ] The chosen action, size, and risk assessment are internally consistent

## Automated Checks

````python
def grade(transcript: list, workspace_path: str) -> dict:
    import json
    import re

    scores = {
        "valid_json_and_required_fields": 0.0,
        "action_and_position_size_valid": 0.0,
        "risk_assessment_valid": 0.0,
        "rationale_and_key_factors_meaningful": 0.0,
        "decision_logic_risk_aware": 0.0,
        "action_size_risk_consistency": 0.0,
    }

    def _get_last_assistant_text(transcript: list) -> str:
        for event in reversed(transcript):
            if event.get("type") != "message":
                continue
            msg = event.get("message", {})
            if msg.get("role") != "assistant":
                continue
            content = msg.get("content", "")
            if isinstance(content, str):
                return content
            if isinstance(content, list):
                parts = []
                for item in content:
                    if isinstance(item, dict) and item.get("type") == "text":
                        parts.append(item.get("text", ""))
                return "\n".join(parts).strip()
        return ""

    response = _get_last_assistant_text(transcript).strip()
    if not response:
        return scores

    json_str = ""
    try:
        # First try direct parse
        parsed = json.loads(response)
        json_str = response
    except Exception:
        parsed = None

    if parsed is None:
        # Fallback: fenced block
        m = re.search(r"```json\s*(\{.*?\})\s*```", response, re.DOTALL | re.IGNORECASE)
        if m:
            json_str = m.group(1)
        else:
            # Fallback: first top-level object-like span
            m = re.search(r"\{.*\}", response, re.DOTALL)
            if m:
                json_str = m.group(0)

        if json_str:
            try:
                parsed = json.loads(json_str)
            except Exception:
                parsed = None

    required_fields = {"action", "position_size_pct", "risk_assessment", "rationale", "key_factors"}

    if isinstance(parsed, dict):
        present = set(parsed.keys())
        overlap = len(required_fields & present)
        base = overlap / len(required_fields)
        exact_bonus = 0.0 if present != required_fields else 0.2
        scores["valid_json_and_required_fields"] = min(1.0, base * 0.8 + exact_bonus)
    else:
        return scores

    action = parsed.get("action", "")
    if isinstance(action, str):
        action_norm = action.strip().upper()
    else:
        action_norm = ""

    position_size = parsed.get("position_size_pct")
    size_num = None
    if isinstance(position_size, (int, float)):
        size_num = float(position_size)
    elif isinstance(position_size, str):
        try:
            size_num = float(position_size.strip())
        except Exception:
            size_num = None

    action_score = 1.0 if action_norm in {"BUY", "SELL", "HOLD"} else 0.0
    size_score = 1.0 if size_num is not None and 0 <= size_num <= 20 else 0.0
    scores["action_and_position_size_valid"] = (action_score + size_score) / 2

    risk = parsed.get("risk_assessment", "")
    risk_norm = risk.strip().lower() if isinstance(risk, str) else ""
    scores["risk_assessment_valid"] = 1.0 if risk_norm in {"low", "medium", "high"} else 0.0

    rationale = parsed.get("rationale", "")
    key_factors = parsed.get("key_factors", [])

    rationale_score = 0.0
    if isinstance(rationale, str):
        rationale_len = len(rationale.strip())
        if rationale_len >= 30:
            rationale_score = 1.0
        elif rationale_len >= 15:
            rationale_score = 0.5

    factors_score = 0.0
    if isinstance(key_factors, list):
        nonempty = [x for x in key_factors if isinstance(x, str) and x.strip()]
        if len(nonempty) >= 2:
            factors_score = 1.0
        elif len(nonempty) == 1:
            factors_score = 0.5

    scores["rationale_and_key_factors_meaningful"] = (rationale_score + factors_score) / 2

    # Decision logic: avoid aggressive counter-trend short.
    logic_score = 0.0
    if action_norm == "HOLD":
        if size_num is not None and abs(size_num) < 0.01:
            logic_score = 1.0
        elif size_num is not None and size_num <= 1:
            logic_score = 0.8
        else:
            logic_score = 0.2
    elif action_norm == "SELL":
        if size_num is None:
            logic_score = 0.0
        elif size_num <= 5:
            logic_score = 1.0
        elif size_num <= 10:
            logic_score = 0.5
        else:
            logic_score = 0.0
    elif action_norm == "BUY":
        if size_num is None:
            logic_score = 0.0
        elif size_num <= 3:
            logic_score = 0.4
        else:
            logic_score = 0.1

    scores["decision_logic_risk_aware"] = logic_score

    # Internal consistency among action / size / risk
    consistency = 0.0
    if action_norm == "HOLD":
        if size_num is not None and abs(size_num) < 0.01 and risk_norm in {"medium", "high"}:
            consistency = 1.0
        elif size_num is not None and abs(size_num) < 0.01 and risk_norm in {"low"}:
            consistency = 0.6
    elif action_norm == "SELL":
        if size_num is not None and size_num <= 5 and risk_norm == "high":
            consistency = 1.0
        elif size_num is not None and size_num <= 5 and risk_norm == "medium":
            consistency = 0.7
        elif size_num is not None and size_num > 10 and risk_norm == "low":
            consistency = 0.0
        elif size_num is not None:
            consistency = 0.3
    elif action_norm == "BUY":
        if size_num is not None and size_num <= 3 and risk_norm in {"medium", "high"}:
            consistency = 0.5
        elif size_num is not None:
            consistency = 0.2

    scores["action_size_risk_consistency"] = consistency

    return scores
````

## LLM Judge Rubric

### Dimension 1: Market Context Interpretation (Weight: 35%)

**1.0**
Correctly identifies the central conflict: a low-confidence bearish signal is occurring against a strong uptrend with price above EMA20. The answer appropriately weighs signal weakness, trend context, and limited confirmation.

**0.75**
Understands most of the setup and recognizes at least the main signal-vs-trend conflict, with only minor gaps.

**0.5**
Shows partial understanding but misses an important contextual factor such as confidence, trend direction, or confirmation quality.

**0.25**
Misreads the setup or focuses on isolated details without integrating the broader context.

**0.0**
Fails to meaningfully analyze the trading setup.

### Dimension 2: Decision and Risk Sizing Quality (Weight: 40%)

**1.0**
Recommends a prudent action consistent with the evidence, typically `HOLD` or at most a very small `SELL`, and sets size/risk in a way that matches the weak, counter-trend nature of the setup.

**0.75**
Decision is mostly sensible, though slightly more aggressive or conservative than ideal.

**0.5**
Decision is debatable but still somewhat defensible; size or risk labeling may not fully match the setup.

**0.25**
Decision is materially inconsistent with the evidence, such as taking an oversized counter-trend position.

**0.0**
Decision is clearly unsound given the setup.

### Dimension 3: Output Format and Instruction Compliance (Weight: 25%)

**1.0**
Returns valid JSON only, includes all required fields, and keeps `rationale` and `key_factors` informative.

**0.75**
Mostly compliant JSON with only minor formatting or content issues.

**0.5**
Partially compliant output with noticeable formatting issues or weak field content.

**0.25**
Significant deviations from the required schema.

**0.0**
Not valid JSON or missing most required structure.
