| 序号 | 修改项 | 修改原因 |
|---|---|---|
| 1    | 改写 Prompt              | 降低答案泄露，保留真实用户请求风格，不直接暗示“应该 HOLD”                                                             |
| 2    | 重写 Expected Behavior   | 补充完整审查路径、陷阱说明和 Ground Truth 区间，避免直接给唯一标准答案                                                   |
| 3    | 重写 Grading Criteria    | 改成 6 条独立、可验证标准，并与 `grade()` score key 一一对应                                                   |
| 4    | 重写 `grade()`           | 增强 JSON 提取、字段校验、部分得分、分支逻辑判断与空白零分                                                             |
| 5    | 增加格式容忍                 | 接受大小写变体、整数/浮点数、轻微 JSON 外包裹文本等合理格式差异                                                          |
| 6    | 补充 LLM Judge Rubric    | 原文件缺失该部分，不符合你的审校要求                                                                           |
| 7    | 修改 frontmatter         | 将 `verification_method` 调整为 `rubric`，`grading_type` 改为 `hybrid`，补上 `grading_weights` 且和为 1.0 |