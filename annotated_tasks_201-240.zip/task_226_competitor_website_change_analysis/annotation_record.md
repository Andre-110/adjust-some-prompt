| 序号 | 修改项 | 修改原因 |
|---|---|---|
| 1 | 重写 Prompt 中的分析要求，明确“只能基于可见 diff 做保守分析” | 原题会诱导模型输出无法从证据中验证的结论 |
| 2 | 在 Prompt 中增加“不得声称具体邮箱地址变化，除非 diff 明确显示” | 修复原题最核心的事实性问题 |
| 3 | 重写 Expected Behavior | 原版本把“info@ → sales@”当作确定事实，属于错误 Ground Truth |
| 4 | 将正确分析目标改为“联系信息/邮箱联系行发生了小幅内容更新” | 这是当前 diff 能稳定支持的最合理结论 |
| 5 | 明确 `change_type` 应为 `content` | 该变更属于联系信息内容更新，不是价格、布局、SEO、新页或删除 |
| 6 | 明确 significance 应为低分值 | 变更幅度仅 0.74%，且只涉及联系区单行更新 |
| 7 | 在 Expected Behavior 中补充“不可夸大为重大产品/价格/重设计事件” | 增加陷阱处理说明 |
| 8 | 重写 Grading Criteria，使其覆盖“低显著性”“联系信息变更”“不臆造具体邮箱地址” | 原标准覆盖不足，无法约束关键错误 |
| 9 | 重写 `grade()` 并预初始化所有 score keys | 满足空白零分要求，结构更清晰 |
| 10 | `grade()` 改为要求响应整体就是一个 JSON 对象 | 原逻辑允许从混杂文本中抽取 JSON，不够严格 |
| 11 | 新增 `change_type_content` 检查 | 与 Grading Criteria 对齐，明确该题正确类别 |
| 12 | 新增 `low_significance` 检查 | 覆盖该题的核心判断之一 |
| 13 | 新增 `mentions_contact_change` 检查 | 要求模型聚焦于联系信息/邮箱行本身 |
| 14 | 将原 `no_fabrication` 拆分为 `no_major_fabrication` 和 `no_specific_email_hallucination` | 原检查太粗，且不能拦截“脑补具体邮箱地址变化”的关键错误 |
| 15 | 删除对“info@siteimpact.com → sales@siteimpact.com”的隐含正确答案依赖 | 使题目从“错误题”修复为“可评分题” |