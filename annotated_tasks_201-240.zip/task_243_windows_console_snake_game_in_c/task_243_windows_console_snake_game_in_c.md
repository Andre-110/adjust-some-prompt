---
id: task_243_windows_console_snake_game_in_c
name: Windows Console Snake Game in C
category: Automation
subcategory: Script and Terminal Automation
difficulty: hard
external_dependency: none
verification_method: unit-test
input_modality: text-only
grading_type: hybrid
grading_weights:
  automated: 0.4
  llm_judge: 0.6
timeout_seconds: 240
workspace_files: []
source_line_number: 653
source_query: "在 Windows 控制台上用 C 语言实现一个贪食蛇游戏：支持上下左右移动控制、随机生成食物、吃到食物后蛇身增长、撞墙或撞到自身则游戏结束、分数显示。创建项目结构并提供主程序文件 snake.c（必要时可添加头文件）完整代码，使用 Windows API 或 conio.h 实现控制台输入输出与游戏循环，并给出使用 gcc（如 MinGW）等编译运行说明。"
---

## Prompt

Hey, I want to build a classic snake game for Windows console using C. Can you create the whole project for me?

Here's what I need:
- Arrow keys to move the snake (up/down/left/right)
- Food spawns randomly on the board
- Snake grows when it eats food
- Game over if you hit a wall or yourself
- Show the current score somewhere on screen

Create a project with at least a main file called `snake.c` (add a header file if you think it helps keep things clean). The code should work on Windows - you can use Windows API stuff or conio.h for the console input/output and the game loop.

Oh and please include a `README.md` with instructions on how to compile and run it using gcc (like MinGW). Just basic stuff like what command to run.

## Expected Behavior

The agent should:
1. Create a `snake.c` file with complete, compilable C code
2. Implement snake movement with keyboard input handling (using Windows-specific APIs like conio.h or windows.h)
3. Implement food generation with random positioning
4. Implement snake growth mechanics when food is eaten
5. Implement collision detection for walls and self-collision
6. Display score during gameplay
7. Create a proper game loop with timing
8. Optionally create header files for better organization
9. Create a `README.md` with compilation instructions for gcc/MinGW

Tested capabilities: C programming, Windows console programming, game logic implementation, project organization.

**Trap handling — the agent should correctly navigate the following traps:**

- **Arrow key double-read**: On Windows with `conio.h`, `getch()` returns `0x00` or `0xE0` as a prefix byte when an arrow key is pressed; the actual direction code comes from a second `getch()` call. Code that only calls `getch()` once will misread arrow keys as garbage input. The correct implementation calls `getch()` twice when the first byte is `0x00` or `0xE0`.
- **Food spawning on the snake's body**: `rand()` may generate coordinates that overlap with the snake's current body segments. The correct implementation checks all body positions and regenerates the food location if it overlaps.
- **Reverse direction prohibition**: The snake should not be allowed to immediately reverse direction (e.g., moving right and then pressing left should be ignored). Without this check, pressing the opposite direction causes an instant self-collision on the next frame and an unfair game over.

## Grading Criteria

- [ ] File `snake.c` exists and contains valid C code structure
- [ ] Code includes Windows-specific headers (windows.h or conio.h)
- [ ] Code implements keyboard input handling for arrow keys
- [ ] Code implements food/fruit generation logic with randomness
- [ ] Code implements snake growth mechanism
- [ ] Code implements collision detection (wall and self)
- [ ] Code implements score tracking and display
- [ ] Code has a game loop structure
- [ ] File `README.md` exists with compilation instructions
- [ ] README mentions gcc or MinGW

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    from pathlib import Path
    import re

    scores = {}
    ws = Path(workspace_path)

    snake_file = ws / "snake.c"
    scores["snake_c_exists"] = 1.0 if snake_file.exists() else 0.0

    if snake_file.exists():
        content = snake_file.read_text(errors="ignore").lower()

        has_windows_header = any(h in content for h in [
            "#include <windows.h>", "#include <conio.h>",
            "#include<windows.h>", "#include<conio.h>"
        ])
        scores["windows_headers"] = 1.0 if has_windows_header else 0.0

        has_stdio = "#include" in content and ("stdio" in content or "stdlib" in content)
        scores["basic_headers"] = 1.0 if has_stdio else 0.0

        keyboard_patterns = [
            "getch", "kbhit", "getasynckeystate", "readconsoleinput",
            "key_up", "key_down", "key_left", "key_right",
            "vk_up", "vk_down", "vk_left", "vk_right",
            "72", "80", "75", "77", "arrow"
        ]
        has_keyboard = any(p in content for p in keyboard_patterns)
        scores["keyboard_input"] = 1.0 if has_keyboard else 0.0

        # Relaxed: match "rand" rather than "rand()" to catch all usage patterns
        food_patterns = ["food", "fruit", "apple", "rand", "random", "srand"]
        has_food = sum(1 for p in food_patterns if p in content) >= 2
        scores["food_generation"] = 1.0 if has_food else 0.0

        growth_patterns = ["length", "size", "grow", "snake", "body", "tail", "head"]
        has_growth = sum(1 for p in growth_patterns if p in content) >= 2
        scores["snake_growth"] = 1.0 if has_growth else 0.0

        collision_patterns = [
            "collision", "gameover", "game_over", "game over", "dead", "hit",
            "wall", "boundary", "border", "== 0", "== width", "== height",
            ">= width", ">= height", "< 0"
        ]
        has_collision = sum(1 for p in collision_patterns if p in content) >= 2
        scores["collision_detection"] = 1.0 if has_collision else 0.0

        score_patterns = ["score", "point", "printf", "gotoxy", "setcursorposition"]
        has_score = sum(1 for p in score_patterns if p in content) >= 2
        scores["score_display"] = 1.0 if has_score else 0.0

        loop_patterns = ["while", "for", "loop", "sleep", "delay"]
        has_loop = sum(1 for p in loop_patterns if p in content) >= 2
        scores["game_loop"] = 1.0 if has_loop else 0.0

        has_main = "int main" in content or "void main" in content
        has_functions = content.count("(") > 10 and content.count("{") > 5
        scores["valid_c_structure"] = 1.0 if (has_main and has_functions) else 0.0

        scores["not_trivial"] = 1.0 if len(content) > 1000 else 0.0
    else:
        scores["windows_headers"] = 0.0
        scores["basic_headers"] = 0.0
        scores["keyboard_input"] = 0.0
        scores["food_generation"] = 0.0
        scores["snake_growth"] = 0.0
        scores["collision_detection"] = 0.0
        scores["score_display"] = 0.0
        scores["game_loop"] = 0.0
        scores["valid_c_structure"] = 0.0
        scores["not_trivial"] = 0.0

    readme_file = ws / "README.md"
    if not readme_file.exists():
        readme_file = ws / "readme.md"
    if not readme_file.exists():
        readme_file = ws / "README.MD"

    scores["readme_exists"] = 1.0 if readme_file.exists() else 0.0

    if readme_file.exists():
        readme_content = readme_file.read_text(errors="ignore").lower()
        has_gcc = "gcc" in readme_content or "mingw" in readme_content or "compile" in readme_content
        scores["readme_has_compile_info"] = 1.0 if has_gcc else 0.0
    else:
        scores["readme_has_compile_info"] = 0.0

    return scores
```

## LLM Judge Rubric

### Criterion 1: Code Quality and Organization (Weight: 30%)

**Score 1.0**: Code is well-structured with clear function separation (e.g., separate functions for input, drawing, update, collision), meaningful variable names, and appropriate comments. Follows reasonable C coding practices throughout.
**Score 0.75**: Code has mostly good structure with minor issues — e.g., one or two large functions that could be split, or sparse comments.
**Score 0.5**: Code works but is poorly organized — e.g., most logic crammed into `main()`, inconsistent naming, or no comments.
**Score 0.25**: Code is difficult to read or maintain; structure is hard to follow even if it nominally compiles.
**Score 0.0**: Code is not structured C — e.g., pseudocode, placeholder stubs only, or completely incoherent.

### Criterion 2: Game Logic Completeness (Weight: 30%)

**Score 1.0**: All core mechanics are correctly implemented: movement in four directions, food consumption triggering growth, game-over on wall collision, game-over on self-collision, and reverse-direction prohibition.
**Score 0.75**: All major mechanics are present but one minor detail is missing or subtly wrong (e.g., reverse direction not blocked, or food can spawn on snake body).
**Score 0.5**: Core mechanics are present but one significant feature is missing or broken (e.g., self-collision not detected, or snake does not grow).
**Score 0.25**: Only partial mechanics implemented — e.g., snake moves but food or collision is absent.
**Score 0.0**: Game logic is essentially absent or non-functional.

### Criterion 3: Windows Platform Compatibility (Weight: 20%)

**Score 1.0**: Code correctly uses Windows-specific APIs (`windows.h`, `conio.h`) for console manipulation, keyboard input (including correct double-`getch()` handling for arrow keys), and screen updates. Would compile and run on Windows with MinGW.
**Score 0.75**: Windows APIs are used correctly in most places but one platform-specific detail is handled incorrectly (e.g., single `getch()` for arrow keys without prefix check).
**Score 0.5**: Windows headers are included and used, but the approach has notable issues that would cause incorrect behavior on a real Windows console.
**Score 0.25**: Windows headers are referenced but usage is superficial or mostly wrong.
**Score 0.0**: No Windows-specific code; code is platform-agnostic or uses POSIX/Linux APIs only.

### Criterion 4: Documentation Quality (Weight: 20%)

**Score 1.0**: README is clear and complete — provides the exact `gcc` command to compile (e.g., `gcc snake.c -o snake.exe`), notes any required flags (e.g., `-lwinmm` if used), and explains how to run the result. A developer could follow it without prior knowledge.
**Score 0.75**: README provides a correct compile command but omits minor details (e.g., missing flags, or no run instruction).
**Score 0.5**: README mentions gcc/MinGW and compilation but the instructions are vague or incomplete.
**Score 0.25**: README exists but provides little actionable information.
**Score 0.0**: No README, or README contains no compilation or run instructions.