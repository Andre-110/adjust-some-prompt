---
id: task_254_product_information_translator
name: Product Information Translator
category: Data Analysis
subcategory: Data Processing and Management
difficulty: medium
external_dependency: none
verification_method: unit-test
input_modality: text-only
grading_type: hybrid
grading_weights:
  automated: 0.4
  llm_judge: 0.6
timeout_seconds: 180
workspace_files: []
source_line_number: 6944
source_query: "Translate the provided product information JSON into all target_languages. Translate each non-empty field (e.g., names/allergens/ingredients) into each target language and return only translations for target_languages. Follow the specified sanitization (strip HTML, decode entities), bolding normalization (use exactly **...**), and allergen extraction rules. Input: { \"names\": { \"zh\": \"卧龙 高山玉米脆浓郁香辣108g\" }, \"allergens\": {}, \"ingredients\": {}, \"target_languages\": [\"bg\",\"cs\",\"da\"..."
---

## Prompt

Hey, I need you to translate this product info into a bunch of languages. Here's the JSON:

```json
{
  "names": {
    "zh": "Wolong Highland Corn Crisp Rich Spicy 108g"
  },
  "allergens": {},
  "ingredients": {},
  "target_languages": ["bg", "cs", "da", "de", "el", "en", "es", "fi", "fr", "hu", "it", "ja", "ko", "nb", "nl", "pl", "pt", "ro", "ru", "sv", "tr", "zh-cn", "zh-tw"]
}
```

Basically translate the product name into all those target languages. Only translate fields that have content (so skip allergens and ingredients since they're empty).

Some rules to follow:
- Strip any HTML tags from the text before translating
- Decode HTML entities (like `&amp;` → `&`)
- For bold text, normalize to use exactly `**...**` format
- Keep the brand name "Wolong" as-is in all translations

Save the output to `translations.json` with this structure:
```json
{
  "names": {
    "bg": "translated name",
    "cs": "translated name",
    ...
  }
}
```

Only include translations for the target_languages list, nothing else.

## Expected Behavior

The agent should:
1. Parse the input JSON and identify that only "names" has content
2. Translate the product name "Wolong Highland Corn Crisp Rich Spicy 108g" into all 23 target languages
3. Keep the brand name "Wolong" unchanged across all translations
4. Preserve the weight "108g" in appropriate format for each locale
5. Output a properly structured JSON file with translations for all target languages
6. Skip allergens and ingredients since they're empty
7. Provide distinct translations for `zh-cn` (Simplified Chinese) and `zh-tw` (Traditional Chinese) — these are separate locales and should not be identical copies of the input

Tested capabilities: multilingual translation, JSON parsing/generation, following specific formatting rules, handling empty fields appropriately.

**Trap handling — the agent should correctly navigate the following traps:**

- **zh-cn and zh-tw are not the same**: The input has a `zh` source name. Both `zh-cn` (Simplified Chinese) and `zh-tw` (Traditional Chinese) are in the target list and must be provided as distinct translations. `zh-cn` should use Simplified Chinese characters; `zh-tw` should use Traditional Chinese characters. Simply copying the input `zh` value for both, or leaving them identical, is incorrect — `zh-cn` and `zh-tw` may differ in both script and vocabulary.

## Grading Criteria

- [ ] File `translations.json` exists and is valid JSON
- [ ] Output contains "names" object with translations
- [ ] All 23 target languages are present in the output
- [ ] Brand name "Wolong" is preserved in translations
- [ ] No allergens or ingredients keys with content in output (since they were empty)
- [ ] English translation is reasonable
- [ ] Translations are appropriate for each language

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    from pathlib import Path
    import json

    scores = {}
    ws = Path(workspace_path)

    target_langs = ["bg", "cs", "da", "de", "el", "en", "es", "fi", "fr", "hu", "it", "ja", "ko", "nb", "nl", "pl", "pt", "ro", "ru", "sv", "tr", "zh-cn", "zh-tw"]

    translations_file = ws / "translations.json"
    scores["file_exists"] = 1.0 if translations_file.exists() else 0.0

    if not translations_file.exists():
        scores["valid_json"] = 0.0
        scores["has_names_object"] = 0.0
        scores["all_languages_present"] = 0.0
        scores["brand_preserved"] = 0.0
        scores["no_empty_fields"] = 0.0
        scores["en_translation_reasonable"] = 0.0
        return scores

    try:
        data = json.loads(translations_file.read_text(errors="ignore"))
        scores["valid_json"] = 1.0
    except Exception:
        scores["valid_json"] = 0.0
        scores["has_names_object"] = 0.0
        scores["all_languages_present"] = 0.0
        scores["brand_preserved"] = 0.0
        scores["no_empty_fields"] = 0.0
        scores["en_translation_reasonable"] = 0.0
        return scores

    scores["has_names_object"] = 1.0 if "names" in data and isinstance(data["names"], dict) else 0.0

    if "names" in data and isinstance(data["names"], dict):
        names = data["names"]
        present_langs = [lang for lang in target_langs if lang in names and names[lang]]
        present_count = len(present_langs)
        scores["all_languages_present"] = present_count / len(target_langs)

        # brand_preserved: proportion of present translations that contain "wolong"
        if present_count > 0:
            wolong_count = sum(
                1 for lang in present_langs
                if "wolong" in names.get(lang, "").lower()
            )
            scores["brand_preserved"] = wolong_count / present_count
        else:
            scores["brand_preserved"] = 0.0

        en_name = names.get("en", "")
        en_reasonable = 0.0
        if en_name:
            en_lower = en_name.lower()
            if "corn" in en_lower or "crisp" in en_lower or "spicy" in en_lower or "snack" in en_lower:
                en_reasonable = 1.0
            elif "wolong" in en_lower and "108" in en_name:
                en_reasonable = 0.5
        scores["en_translation_reasonable"] = en_reasonable
    else:
        scores["all_languages_present"] = 0.0
        scores["brand_preserved"] = 0.0
        scores["en_translation_reasonable"] = 0.0

    has_nonempty_allergens = "allergens" in data and bool(data["allergens"])
    has_nonempty_ingredients = "ingredients" in data and bool(data["ingredients"])
    scores["no_empty_fields"] = 1.0 if not has_nonempty_allergens and not has_nonempty_ingredients else 0.0

    return scores
```

## LLM Judge Rubric

### Criterion 1: Translation Quality (Weight: 40%)

**Score 1.0**: Translations are accurate and natural-sounding in each language. Key descriptors (highland, corn, crisp, rich, spicy) are correctly conveyed with appropriate vocabulary for each language.
**Score 0.75**: Most translations are accurate but 1–3 languages have awkward phrasing or minor inaccuracies.
**Score 0.5**: Translations convey the general meaning but several languages have notable inaccuracies or unnatural phrasing.
**Score 0.25**: Translations are present but many are poorly rendered — e.g., word-for-word literal translations that sound unnatural, or key descriptors omitted.
**Score 0.0**: Translations are missing, empty, or clearly wrong (e.g., untranslated English copied into all fields).

### Criterion 2: Language Appropriateness (Weight: 25%)

**Score 1.0**: All translations use the correct script and register for their locale. CJK languages (ja, ko, zh-cn, zh-tw) use appropriate characters; zh-cn and zh-tw are distinct and use Simplified vs Traditional Chinese respectively; European languages use correct diacritics.
**Score 0.75**: Most locales are correctly handled but one locale has a script or register issue (e.g., zh-cn and zh-tw are identical, or a language uses wrong character set).
**Score 0.5**: Several locales have script or register issues, or zh-cn/zh-tw are not differentiated.
**Score 0.25**: Multiple locales use wrong scripts or the output is mostly transliterated/romanized instead of using native scripts.
**Score 0.0**: Locale-appropriate scripts are ignored throughout — e.g., all CJK fields contain romanized text.

### Criterion 3: Consistency (Weight: 20%)

**Score 1.0**: Formatting is consistent across all translations. The brand name "Wolong" is preserved unchanged in every translation. The weight "108g" is present in all translations in a locale-appropriate format.
**Score 0.75**: Mostly consistent but "Wolong" or "108g" is missing or altered in 1–3 languages.
**Score 0.5**: Brand name or weight is inconsistently handled across several translations.
**Score 0.25**: Brand name is translated or omitted in many languages, or weight is missing in most.
**Score 0.0**: No consistent handling of brand name or weight across translations.

### Criterion 4: Completeness (Weight: 15%)

**Score 1.0**: All 23 required languages are present with non-empty translations. No allergens or ingredients keys with content appear in the output.
**Score 0.75**: 20–22 languages present with non-empty translations; or allergens/ingredients appear as empty objects (acceptable).
**Score 0.5**: 15–19 languages present.
**Score 0.25**: Fewer than 15 languages present.
**Score 0.0**: Fewer than 5 languages present or output structure is fundamentally wrong.
```