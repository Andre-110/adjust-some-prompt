| 序号 | 修改项 | 修改原因 |
|---|---|---|
| 1 | Expected Behavior 补充陷阱说明 | 缺少对 zh-cn/zh-tw 需要区分翻译（不能直接复制输入的中文）的陷阱说明 |
| 2 | grade() 修复 `brand_preserved` 分母 | 原逻辑使用 len(target_langs) 作为分母，应改为 present_count，避免缺失翻译拉低品牌保留率分数 |
| 3 | LLM Judge Rubric 各维度补充等级描述 | 原文只有维度描述，缺少 1.0/0.75/0.5/0.25/0.0 各等级的具体说明 |