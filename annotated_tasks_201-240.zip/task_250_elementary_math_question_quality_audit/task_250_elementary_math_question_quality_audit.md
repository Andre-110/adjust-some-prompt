---
id: task_250_elementary_math_question_quality_audit
name: Elementary Math Question Quality Audit
category: Data Analysis
subcategory: Quality Auditing and Diagnostics
difficulty: medium
external_dependency: none
verification_method: output-check
input_modality: text-only
grading_type: automated
grading_weights:
  automated: 1.0
timeout_seconds: 120
workspace_files: []
source_line_number: 3056
source_query: "作为小学数学题目质量审核专家，对以下题目进行二次质检：按题干完整性、选项完整/重复、标注答案是否正确、解析是否正确且与题干一致、SVG质量与是否泄露关键信息（如有）进行核查；若有任何不确定，判为错题。仅输出以下JSON：{\"question_id\":186362,\"is_really_wrong\":true/false,\"confidence\":\"high/medium/low\",\"issues\":[\"题干错/选项错/答案错/解析错/svg 错\"...],\"reason\":\"50字以内\"}。题目：选项A=2/15，B=8/15，C=4/15，D=3/15；标注正确答案A；解析称：括号内(1/3-1/5)=2/15，2/3-2/15=8/15，并提到"选项调整为8/15"。"
---

## Prompt

Hey, I'm doing QA on our elementary math question bank. Can you double-check this question that was flagged as potentially wrong?

Here's the question data:

```json
{
  "question_id": 186362,
  "grade": "5th",
  "type": "multiple_choice",
  "stem": "Calculate: 2/3 - (1/3 - 1/5) = ?",
  "options": {
    "A": "2/15",
    "B": "8/15",
    "C": "4/15",
    "D": "3/15"
  },
  "marked_answer": "A",
  "explanation": "First calculate the parentheses: (1/3 - 1/5) = 5/15 - 3/15 = 2/15. Then: 2/3 - 2/15 = 10/15 - 2/15 = 8/15. The answer should be adjusted to 8/15.",
  "flagged_issue": "answer_wrong",
  "svg_content": null
}
```

Check these things:
- Is the stem complete and clear?
- Are options complete (no duplicates, 3-4 choices)?
- Is the marked answer actually correct based on the math?
- Does the explanation match the marked answer and is the math right?
- If there's SVG, check if it's clear and doesn't leak the answer

If anything is off or you're not sure, mark it as wrong.

Output just this JSON (nothing else):
```json
{
  "question_id": 186362,
  "is_really_wrong": true/false,
  "confidence": "high/medium/low",
  "issues": ["stem_wrong", "options_wrong", "answer_wrong", "explanation_wrong", "svg_wrong"],
  "reason": "brief explanation under 50 words"
}
```

## Expected Behavior

The agent should:
1. Verify the stem is complete and clear (it is — "2/3 - (1/3 - 1/5) = ?" is unambiguous)
2. Check options are complete with no duplicates (they are — four distinct values)
3. Calculate independently: 2/3 - (1/3 - 1/5) = 2/3 - 2/15 = 10/15 - 2/15 = 8/15
4. Note that the marked answer is A (2/15) but the correct answer is B (8/15) — the marked answer is wrong
5. Note that the explanation's mathematical steps are correct (arriving at 8/15), but the marked answer contradicts them
6. Determine this IS a wrong question due to the marked answer being incorrect
7. Output valid JSON with is_really_wrong: true, issues containing "answer_wrong", confidence "high"

**Trap handling — the agent should correctly navigate the following traps:**

- **Distinguishing answer_wrong from explanation_wrong**: The explanation's arithmetic is correct — it properly calculates 8/15 step by step. The error is that the *marked answer* field points to A (2/15) instead of B (8/15). The correct issue to report is `answer_wrong`, not `explanation_wrong`. The final sentence of the explanation ("The answer should be adjusted to 8/15") is actually a note acknowledging the discrepancy, not an error in the explanation itself. Marking the explanation as wrong when its math is correct is an over-flagging error.
- **Stem and options are correct**: The stem is clear and the four options are distinct. The agent should not flag `stem_wrong` or `options_wrong`. These are correct.

## Grading Criteria

- [ ] Output is valid JSON
- [ ] question_id is 186362
- [ ] is_really_wrong is true (the marked answer is incorrect)
- [ ] issues array contains "answer_wrong" or "explanation_wrong"
- [ ] confidence is one of high, medium, low
- [ ] Does not falsely claim stem_wrong
- [ ] Does not falsely claim options_wrong

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    import json
    import re

    def _get_last_assistant_text(transcript: list) -> str:
        for event in reversed(transcript):
            if event.get("type") != "message":
                continue
            msg = event.get("message", {})
            if msg.get("role") != "assistant":
                continue
            for item in msg.get("content", []):
                if isinstance(item, dict) and item.get("type") == "text":
                    return item.get("text", "")
            content = msg.get("content", "")
            if isinstance(content, str):
                return content
        return ""

    def _extract_json(text: str) -> str:
        brace_count = 0
        start_idx = -1
        for i, c in enumerate(text):
            if c == '{':
                if brace_count == 0:
                    start_idx = i
                brace_count += 1
            elif c == '}':
                brace_count -= 1
                if brace_count == 0 and start_idx != -1:
                    return text[start_idx:i + 1]
        return ""

    empty_scores = {
        "valid_json": 0.0,
        "correct_question_id": 0.0,
        "identified_as_wrong": 0.0,
        "found_answer_or_explanation_issue": 0.0,
        "has_confidence": 0.0,
        "no_false_stem_claim": 0.0,
        "no_false_options_claim": 0.0,
    }

    scores = {}
    text = _get_last_assistant_text(transcript)

    if not text.strip():
        return empty_scores

    json_str = _extract_json(text)
    if not json_str:
        # Fallback: try code block
        code_block = re.search(r'```(?:json)?\s*(\{.*?\})\s*```', text, re.DOTALL)
        if code_block:
            json_str = code_block.group(1)
        else:
            return empty_scores

    parsed = None
    try:
        parsed = json.loads(json_str)
        scores["valid_json"] = 1.0
    except Exception:
        return empty_scores

    qid = parsed.get("question_id")
    scores["correct_question_id"] = 1.0 if qid == 186362 else 0.0

    is_wrong = parsed.get("is_really_wrong")
    scores["identified_as_wrong"] = 1.0 if is_wrong is True else 0.0

    issues = parsed.get("issues", [])
    if not isinstance(issues, list):
        issues = []
    issues_lower = [str(i).lower() for i in issues]

    has_answer_issue = any("answer" in i for i in issues_lower)
    has_explanation_issue = any("explanation" in i for i in issues_lower)
    scores["found_answer_or_explanation_issue"] = 1.0 if (has_answer_issue or has_explanation_issue) else 0.0

    confidence = str(parsed.get("confidence", "")).lower().strip()
    scores["has_confidence"] = 1.0 if confidence in ["high", "medium", "low"] else 0.0

    has_false_stem = any("stem" in i for i in issues_lower)
    scores["no_false_stem_claim"] = 0.0 if has_false_stem else 1.0

    has_false_options = any("option" in i for i in issues_lower)
    scores["no_false_options_claim"] = 0.0 if has_false_options else 1.0

    return scores
```