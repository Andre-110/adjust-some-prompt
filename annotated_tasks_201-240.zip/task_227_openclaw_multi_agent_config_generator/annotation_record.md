| 序号 | 修改项 | 修改原因 |
|---|---|---|
| 1 | 重写 Prompt 中的 agent 名称 | 原题把 source_query 中的中文名称错误英文化，导致 Prompt 与源要求不一致 |
| 2 | 在 Prompt 中明确“只包含 bailian provider” | 补足 source_query 的关键约束 |
| 3 | 在 Prompt 中明确“恰好 6 个 agent，且不得增加额外 agent” | 提升可评分性与约束清晰度 |
| 4 | 重写 Expected Behavior | 原版本基于错误英文名，Ground Truth 不正确 |
| 5 | 在 Expected Behavior 中补充“不要翻译 agent 名称”陷阱说明 | 这是本题最关键的错误来源之一 |
| 6 | 在 Expected Behavior 中补充“不要遗漏 bailian/ 前缀” | 覆盖核心格式要求 |
| 7 | 重写 Grading Criteria，用中文名称作为判定标准 | 纠正原有错误评分目标 |
| 8 | 重写 `grade()` 并统一初始化 score keys | 满足空白零分要求，结构更清晰 |
| 9 | `grade()` 改为使用 `yaml.safe_load` 解析 YAML | 原逻辑只做字符串级“像 YAML”判断，不可靠 |
| 10 | `grade()` 改为基于解析后的 name/model 映射进行评分 | 原逻辑用字符距离判断，容易误判 |
| 11 | `grade()` 增加部分得分 | 满足支持 0.0–1.0 部分得分要求 |
| 12 | `grade()` 将英文 key 检查改为中文名称映射检查 | 与修正后的 Grading Criteria 对齐 |
| 13 | `grade()` 增加 `no_extra_agents_or_models` 联合检查 | 原题对额外 agent / 非 bailian 模型约束不够稳 |
| 14 | 删除对错误英文名（Lobster/Jim/Jimmy 等）的依赖 | 修复题目事实性错误，使其可稳定评分 |