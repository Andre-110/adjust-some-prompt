---
id: task_227_openclaw_multi_agent_config_generator
name: OpenClaw Multi-Agent Config Generator
category: Automation
subcategory: Agent and AI Orchestration
difficulty: medium
external_dependency: none
verification_method: unit-test
input_modality: text-only
grading_type: automated
timeout_seconds: 120
workspace_files: []
source_line_number: 4619
source_query: "生成 OpenClaw 的多 Agent 配置模板（YAML），只覆盖 bailian 下的模型；为每个模型创建一个 agent，并按以下映射设置 agent 名称与模型 ID（全部使用 bailian/ 前缀）：龙虾→bailian/qwen3-max-2026-01-23，吉姆→bailian/glm-4.7，吉米→bailian/kimi-k2.5，倪工→bailian/qwen3-coder-next，裴工→bailian/qwen3-coder-plus，大龙→bailian/qwen3.5-plus；输出完整 YAML 文件内容。"
---

## Prompt

Please generate a YAML configuration template for OpenClaw multi-agent setup.

Requirements:
- Only include agents for the **bailian** provider
- Create exactly **one agent per model**
- Use the following exact agent name → model mappings:

  - 龙虾 → `bailian/qwen3-max-2026-01-23`
  - 吉姆 → `bailian/glm-4.7`
  - 吉米 → `bailian/kimi-k2.5`
  - 倪工 → `bailian/qwen3-coder-next`
  - 裴工 → `bailian/qwen3-coder-plus`
  - 大龙 → `bailian/qwen3.5-plus`

Output:
- Save the complete YAML configuration to `openclaw_agents.yaml`

Constraints:
- The YAML must define exactly 6 agents
- Each agent must include at least:
  - `name`
  - `model`
- Do not add agents for any non-`bailian/` model
- Do not add extra agents beyond the 6 specified

You may choose a reasonable overall YAML structure such as a top-level `agents:` list.

## Expected Behavior

The agent should:

1. Create a valid YAML file named `openclaw_agents.yaml`.
2. Output a complete YAML configuration, not partial snippets or prose.
3. Define exactly 6 agents.
4. Use the exact required agent names:
   - `龙虾`
   - `吉姆`
   - `吉米`
   - `倪工`
   - `裴工`
   - `大龙`
5. Map each agent to the exact required model ID:
   - `龙虾` → `bailian/qwen3-max-2026-01-23`
   - `吉姆` → `bailian/glm-4.7`
   - `吉米` → `bailian/kimi-k2.5`
   - `倪工` → `bailian/qwen3-coder-next`
   - `裴工` → `bailian/qwen3-coder-plus`
   - `大龙` → `bailian/qwen3.5-plus`
6. Ensure all model IDs use the `bailian/` prefix.
7. Avoid adding any extra agent entries or unrelated model mappings.
8. Keep the file structurally valid YAML.

Trap handling expected from the model:
- Do not translate the agent names into English.
- Do not omit the `bailian/` prefix.
- Do not add extra agents or non-bailian models.
- Do not output incomplete YAML.

Tested capabilities:
- YAML generation
- exact mapping following
- multilingual string fidelity
- structured config output

## Grading Criteria

- [ ] File `openclaw_agents.yaml` exists
- [ ] File contains valid YAML
- [ ] YAML defines exactly 6 agents
- [ ] Agent `龙虾` maps to `bailian/qwen3-max-2026-01-23`
- [ ] Agent `吉姆` maps to `bailian/glm-4.7`
- [ ] Agent `吉米` maps to `bailian/kimi-k2.5`
- [ ] Agent `倪工` maps to `bailian/qwen3-coder-next`
- [ ] Agent `裴工` maps to `bailian/qwen3-coder-plus`
- [ ] Agent `大龙` maps to `bailian/qwen3.5-plus`
- [ ] No extra agents or non-`bailian/` model mappings are added

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    from pathlib import Path

    score_keys = [
        "file_exists",
        "valid_yaml",
        "agent_count_correct",
        "longxia_correct",
        "jimu_correct",
        "jimi_correct",
        "nigong_correct",
        "peigong_correct",
        "dalong_correct",
        "no_extra_agents_or_models",
    ]
    scores = {k: 0.0 for k in score_keys}

    ws = Path(workspace_path)
    yaml_file = ws / "openclaw_agents.yaml"
    scores["file_exists"] = 1.0 if yaml_file.exists() else 0.0

    if not yaml_file.exists():
        return scores

    try:
        import yaml
        content = yaml_file.read_text(encoding="utf-8")
    except Exception:
        try:
            content = yaml_file.read_text()
            import yaml
        except Exception:
            return scores

    try:
        data = yaml.safe_load(content)
        scores["valid_yaml"] = 1.0
    except Exception:
        return scores

    def collect_agents(obj):
        if isinstance(obj, dict):
            if "agents" in obj and isinstance(obj["agents"], list):
                return obj["agents"]
            # fallback: if top-level itself looks like an agent list container
            for v in obj.values():
                if isinstance(v, list) and all(isinstance(item, dict) for item in v):
                    name_model_pairs = [
                        item for item in v
                        if "name" in item and "model" in item
                    ]
                    if name_model_pairs:
                        return v
        elif isinstance(obj, list):
            if all(isinstance(item, dict) for item in obj):
                return obj
        return []

    agents = collect_agents(data)

    if isinstance(agents, list):
        if len(agents) == 6:
            scores["agent_count_correct"] = 1.0
        elif len(agents) > 0:
            scores["agent_count_correct"] = 0.5

    expected = {
        "龙虾": "bailian/qwen3-max-2026-01-23",
        "吉姆": "bailian/glm-4.7",
        "吉米": "bailian/kimi-k2.5",
        "倪工": "bailian/qwen3-coder-next",
        "裴工": "bailian/qwen3-coder-plus",
        "大龙": "bailian/qwen3.5-plus",
    }

    found = {}
    extra_agents = []
    extra_models = []

    for agent in agents:
        if not isinstance(agent, dict):
            continue
        name = agent.get("name")
        model = agent.get("model")
        if isinstance(name, str) and isinstance(model, str):
            found[name] = model
            if name not in expected:
                extra_agents.append(name)
            if not model.startswith("bailian/"):
                extra_models.append(model)

    def mapping_score(agent_name, expected_model):
        actual = found.get(agent_name)
        if actual is None:
            return 0.0
        if actual == expected_model:
            return 1.0
        if isinstance(actual, str) and actual.startswith("bailian/"):
            return 0.5
        return 0.0

    scores["longxia_correct"] = mapping_score("龙虾", expected["龙虾"])
    scores["jimu_correct"] = mapping_score("吉姆", expected["吉姆"])
    scores["jimi_correct"] = mapping_score("吉米", expected["吉米"])
    scores["nigong_correct"] = mapping_score("倪工", expected["倪工"])
    scores["peigong_correct"] = mapping_score("裴工", expected["裴工"])
    scores["dalong_correct"] = mapping_score("大龙", expected["大龙"])

    expected_models = set(expected.values())
    found_models = set(found.values())

    has_only_expected_names = set(found.keys()) == set(expected.keys())
    has_only_expected_models = found_models == expected_models
    has_no_non_bailian = len(extra_models) == 0

    if has_only_expected_names and has_only_expected_models and has_no_non_bailian and len(extra_agents) == 0:
        scores["no_extra_agents_or_models"] = 1.0
    elif has_no_non_bailian and len(extra_agents) == 0:
        scores["no_extra_agents_or_models"] = 0.5

    return scores
```