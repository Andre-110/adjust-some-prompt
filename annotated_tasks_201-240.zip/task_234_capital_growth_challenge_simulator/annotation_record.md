| 序号 | 修改项 | 修改原因 |
|---|---|---|
| 1 | 重写 Prompt 中关于配置的表述 | 原 Prompt 说“load config from a file or use defaults”，但没有明确默认测试配置与无配置文件时的行为，存在歧义 |
| 2 | 明确“提供的 sample config 是无外部配置文件时的默认配置” | 让 Prompt、Expected Behavior、自动评分统一，避免脚本行为不可判定 |
| 3 | 在 Prompt 中补充 `final_balance` 字段要求 | 原 Prompt 的 JSON 要求里缺少 `final_balance`，但自动评分又可能检查它，需补齐 |
| 4 | 扩充 Expected Behavior | 原版虽有核心结果，但对默认配置、累计计算规则、日志内容要求写得不够完整 |
| 5 | 在 Expected Behavior 中补充陷阱说明 | 按规范要求，需写清“累计余额”“布尔类型”“日志反映真实运行结果”等关键陷阱 |
| 6 | 在 Expected Behavior 中补充 Ground Truth | 明确默认配置下的精确数值，确保答案可验证 |
| 7 | 重写 Grading Criteria | 原标准偏粗，缺少对 `config used`、`final_balance` 等关键字段的独立检查 |
| 8 | 增加“JSON log includes config used”评分条目 | Prompt 明确要求包含 config used，原评分未覆盖 |
| 9 | 增加“includes final_balance, total_profit, and goal_reached”评分条目 | 这些是核心输出字段，应单独验证 |
| 10 | 合并 `script_exists` 与 `script_valid_python` 为单一评分项 | 二者高度相关，合并后更贴合评分点，也减少冗余 |
| 11 | 重写 automated checks 的 score key | 使 score key 更贴近 Grading Criteria，满足 Key 对齐要求 |
| 12 | 为文件读取添加 `encoding="utf-8"` | 提高稳健性 |
| 13 | 运行脚本时显式设置 `text=True`、`check=False` | 增强 subprocess 调用稳定性，避免不必要异常干扰评分 |
| 14 | 增加对 `config_used` 的自动检查 | 原代码未检查 Prompt 明确要求的关键字段 |
| 15 | 增强对最终字段完整性的自动检查 | 将 `final_balance`、`total_profit`、`goal_reached` 独立归为一项，更清晰 |
| 16 | 改进 periods 检查为“累计 balance”评分 | 原逻辑只检查存在 `balance` 字段，不验证是否真的是累计余额；新版按默认配置的 4 期结果部分给分 |
| 17 | 收紧 calculation 正确性检查 | 原版允许 `final_balance == 1680` 或 `total_profit == 680` 任一成立就通过，过宽；新版要求默认配置下核心结果一致 |