---
id: task_234_capital_growth_challenge_simulator
name: Capital Growth Challenge Simulator
category: Automation
subcategory: Script and Terminal Automation
difficulty: medium
external_dependency: none
verification_method: unit-test
input_modality: text-only
grading_type: automated
timeout_seconds: 180
workspace_files: []
source_line_number: 1885
source_query: "写一个可在 macOS 上运行的 Python 脚本/小项目，用于模拟“用更小本金做增值挑战”的过程：可配置初始本金、支出、收入与利润目标，运行后输出收支与是否达标，并将结果保存为 JSON 日志文件。"
---

## Prompt

Hey, I want a small Python script that simulates a “grow your money with less starting capital” challenge.

Please create a script named `capital_challenge.py`.

What it should do:
- support configurable `starting_capital`, `profit_goal`, and `periods`
- each period should include `income` and `expenses`
- calculate the running balance period by period
- print a readable summary for each period
- tell me at the end whether the profit goal was reached
- save the simulation result to `challenge_log.json`

Use this sample configuration as the default test configuration when the script is run without an external config file:

```json
{
  "starting_capital": 1000,
  "profit_goal": 500,
  "periods": [
    {"income": 300, "expenses": 150},
    {"income": 450, "expenses": 200},
    {"income": 200, "expenses": 180},
    {"income": 380, "expenses": 120}
  ]
}
```

Requirements for `challenge_log.json`:

* include the config used
* include per-period details
* include the balance after each period
* include `final_balance`
* include `total_profit`
* include `goal_reached` as a boolean

The script should run with standard Python 3 on macOS and should not require any third-party packages.

## Expected Behavior

The agent should:

1. Create a valid Python script named `capital_challenge.py`.
2. Make the script runnable with standard Python 3 and no third-party dependencies.
3. Support using the provided sample configuration as the default configuration when no external config file is supplied.
4. Simulate the periods in order using:

   * `balance_after_period = previous_balance + income - expenses`
5. For the provided default configuration, compute:

   * starting balance: `1000`
   * period 1 ending balance: `1150`
   * period 2 ending balance: `1400`
   * period 3 ending balance: `1420`
   * period 4 ending balance: `1680`
   * final balance: `1680`
   * total profit: `680`
   * `goal_reached: true`
6. Print a readable period-by-period summary to stdout.
7. Write `challenge_log.json` containing:

   * the config used
   * a list of period records
   * for each period: at least income, expenses, and resulting balance
   * `final_balance`
   * `total_profit`
   * `goal_reached` as a JSON boolean
8. Avoid fabricated values and ensure the JSON reflects the actual simulation result.

Traps the agent should handle correctly:

* The task requires using the provided sample configuration as the default behavior when no config file is provided.
* `goal_reached` must be a boolean, not a string like `"true"`.
* The period balances must be cumulative, not period-local net values.
* The saved JSON log should reflect the actual executed simulation, not hardcoded summary values only.

Ground truth constraints:

* Output script filename: `capital_challenge.py`
* Output log filename: `challenge_log.json`
* For the default configuration:

  * `final_balance = 1680`
  * `total_profit = 680`
  * `goal_reached = true`

Tested capabilities: Python scripting, cumulative financial calculation, JSON serialization, default configuration handling, file output.

## Grading Criteria

* [ ] `capital_challenge.py` exists and is syntactically valid Python
* [ ] Running the script produces `challenge_log.json`
* [ ] `challenge_log.json` is valid JSON
* [ ] The JSON log includes the config used
* [ ] The JSON log includes per-period details with cumulative balance after each period
* [ ] The JSON log includes `final_balance`, `total_profit`, and `goal_reached`
* [ ] `goal_reached` is stored as a boolean
* [ ] For the default configuration, the calculation is correct (`final_balance = 1680`, `total_profit = 680`, goal reached)
* [ ] The result is consistent and does not falsely claim the goal was reached when the recorded profit is below the target

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    from pathlib import Path
    import json
    import ast
    import subprocess
    import sys

    scores = {
        "script_exists_and_valid_python": 0.0,
        "log_file_created": 0.0,
        "log_valid_json": 0.0,
        "includes_config_used": 0.0,
        "periods_with_cumulative_balance": 0.0,
        "includes_final_fields": 0.0,
        "goal_reached_is_boolean": 0.0,
        "calculation_correct_for_default_config": 0.0,
        "no_false_positive_goal_result": 0.0,
    }

    ws = Path(workspace_path)
    script_file = ws / "capital_challenge.py"
    log_file = ws / "challenge_log.json"

    if not script_file.exists():
        return scores

    try:
        ast.parse(script_file.read_text(encoding="utf-8"))
        scores["script_exists_and_valid_python"] = 1.0
    except Exception:
        return scores

    try:
        subprocess.run(
            [sys.executable, str(script_file)],
            cwd=str(ws),
            capture_output=True,
            text=True,
            timeout=30,
            check=False,
        )
    except Exception:
        return scores

    if log_file.exists():
        scores["log_file_created"] = 1.0
    else:
        return scores

    try:
        log_data = json.loads(log_file.read_text(encoding="utf-8"))
        scores["log_valid_json"] = 1.0
    except Exception:
        return scores

    if isinstance(log_data, dict) and "config_used" in log_data and isinstance(log_data["config_used"], dict):
        scores["includes_config_used"] = 1.0

    if isinstance(log_data, dict):
        has_final_balance = "final_balance" in log_data
        has_total_profit = "total_profit" in log_data
        has_goal_reached = "goal_reached" in log_data
        scores["includes_final_fields"] = 1.0 if (has_final_balance and has_total_profit and has_goal_reached) else 0.0

        if isinstance(log_data.get("goal_reached"), bool):
            scores["goal_reached_is_boolean"] = 1.0

    periods = log_data.get("periods")
    config_used = log_data.get("config_used", {})

    if isinstance(periods, list) and len(periods) == 4:
        balances = []
        valid_period_shape = True
        for p in periods:
            if not isinstance(p, dict):
                valid_period_shape = False
                break
            if not all(k in p for k in ["income", "expenses", "balance"]):
                valid_period_shape = False
                break
            balances.append(p["balance"])

        if valid_period_shape:
            expected_balances = [1150, 1400, 1420, 1680]
            match_count = sum(1 for a, b in zip(balances, expected_balances) if a == b)
            scores["periods_with_cumulative_balance"] = match_count / len(expected_balances)

    calc_ok = False
    if isinstance(log_data, dict):
        final_balance = log_data.get("final_balance")
        total_profit = log_data.get("total_profit")
        goal_reached = log_data.get("goal_reached")

        if final_balance == 1680 and total_profit == 680 and goal_reached is True:
            calc_ok = True

    scores["calculation_correct_for_default_config"] = 1.0 if calc_ok else 0.0

    false_positive = False
    if isinstance(log_data, dict):
        total_profit = log_data.get("total_profit")
        goal_reached = log_data.get("goal_reached")
        config_profit_goal = None
        if isinstance(config_used, dict):
            config_profit_goal = config_used.get("profit_goal")

        if (
            isinstance(total_profit, (int, float))
            and isinstance(config_profit_goal, (int, float))
            and isinstance(goal_reached, bool)
            and goal_reached is True
            and total_profit < config_profit_goal
        ):
            false_positive = True

    scores["no_false_positive_goal_result"] = 0.0 if false_positive else 1.0

    return scores
```