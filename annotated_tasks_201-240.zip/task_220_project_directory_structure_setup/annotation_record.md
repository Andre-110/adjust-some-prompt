| 序号 | 修改项 | 修改原因 |
|---|---|---|
| 1 | 删除 Prompt 中 `README.txt` 要求 | `README.txt` 属于额外 deliverable，不是该题核心任务。原题目标是 project directory structure setup，不应扩展成“建目录 + 写说明文件”。 |
| 2 | 重写 `Expected Behavior`，去掉 README 相关内容 | `Expected Behavior` 应只描述正确解题路径。原版本把 README creation 写进 expected behavior，会把非必要动作变成评分依据。 |
| 3 | 在 `Expected Behavior` 中补充 trap handling | 本题存在明显 trap：创建额外文件、建到错误位置、误解 “project isolation” 为需要移动/清理其他文件。这些都应明确写出。 |
| 4 | 在 `Expected Behavior` 中补充 Ground truth 路径 | 增加明确可验证答案，便于人工审校和自动评分统一标准。 |
| 5 | 重写 `Grading Criteria`，移除 README existence / README content 检查 | 原 criteria 偏离了核心能力点，过多检查 README，会导致评分重点错误。 |
| 6 | 将 `Grading Criteria` 聚焦为 5 项：main folder、year folder、project folder、exact name、correct hierarchy | 这样覆盖了核心能力，且每条都可以独立验证，满足“可独立判定”和“覆盖关键点”的要求。 |
| 7 | 重写 `grade()`，删除所有 README 相关逻辑 | 既然 README 不属于题目要求，`grade()` 不应继续依赖 `readme_exists` 或 `readme_has_convention`。 |
| 8 | 将 score keys 调整为 `main_folder_exists`、`year_folder_exists`、`project_folder_exists`、`project_folder_exact_name`、`correct_hierarchy_location` | 让 key 与 `Grading Criteria` 一一对应，满足 Key 对齐要求，也方便后续排查评分结果。 |
| 9 | 让 `grade()` 默认返回 0.0，再按命中情况加分 | 这种写法更稳健，符合“空白零分”原则，避免输出缺失时出现误加分。 |
| 10 | 为 `grade()` 增加 partial credit 逻辑 | 当 agent 建了 near-match 项目目录、或者 exact folder name 在 wrong location 时，可以给部分分，满足 partial scoring 要求。 |
| 11 | 移除原先统一扣减的 `wrong_location_penalty` 机制 | blanket penalty 会同时影响多个 score key，解释性差；改成单独评分 `correct_hierarchy_location` 更清晰。 |
| 12 | 新增完整 `LLM Judge Rubric` | 原文件缺少该部分，不满足审校规范。 |
| 13 | 在 Rubric 中设置 3 个维度：`Task Completion`、`Naming Accuracy`、`Location Correctness` | 满足“至少 3 个评分维度”的要求，并且与题目核心能力直接对应。 |
| 14 | 为每个 Rubric 维度补充 1.0 / 0.75 / 0.5 / 0.25 / 0.0 的描述 | 满足“等级描述清晰”的要求，避免 rubric 过于抽象。 |
| 15 | 增加 `grading_weights`，设为 `automated: 0.8`, `llm_judge: 0.2` | 满足 `automated + llm_judge = 1.0` 的要求。 |