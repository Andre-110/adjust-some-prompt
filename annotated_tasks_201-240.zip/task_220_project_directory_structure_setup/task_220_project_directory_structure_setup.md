---
id: task_220_project_directory_structure_setup
name: Project Directory Structure Setup
category: System Administration
subcategory: Storage and Data Management
difficulty: easy
external_dependency: none
verification_method: unit-test
input_modality: text-only
grading_type: automated
timeout_seconds: 120
workspace_files: []
source_line_number: 899
source_query: "为基础设计项目“05TK25002D-蓝海新材料有限公司高端聚烯烃新材料项目”在 D 盘建立标准化项目目录：在 D:/ 创建“我的项目/”，其下按年份创建“2026年项目/”，并在其中创建项目文件夹“05TK25002D-蓝海新材料有限公司高端聚烯烃新材料项目/”。将此作为后续新项目统一建档规则。同时执行项目隔离：该项目所有文件必须只保存在此项目文件夹内，严禁混入其他项目资料以避免数据错乱。"
---

## Prompt

Hey, I need you to set up a standardized project folder structure for a new engineering project I'm working on.

The project is called "Blue Ocean New Materials Co. High-End Polyolefin New Materials Project" with project code "05TK25002D", and we're in the "Basic Design" phase.

Here's what I need:
- Create a main folder called "My Projects" in the D drive root (D:/)
- Inside that, create a year-based subfolder "2026 Projects" (since we're in 2026)
- Inside the year folder, create the actual project folder named "05TK25002D-Blue Ocean New Materials Co. High-End Polyolefin New Materials Project"

This will be our standard way of organizing projects going forward - main folder, then year, then project code + name. Keep everything for this project strictly inside its own folder, with no mixing with other project files.

## Expected Behavior

The agent should:
1. Create the directory structure `D:/My Projects/2026 Projects/05TK25002D-Blue Ocean New Materials Co. High-End Polyolefin New Materials Project/`.
2. Ensure the full path hierarchy exists under the D drive.
3. Use the exact requested folder naming convention: main folder, then year folder, then project code plus project name.
4. Complete only the requested directory setup; no extra files are required.

Trap handling:
- The agent should not create extra deliverables such as a `README.txt` file, because the task is only asking for the project directory structure.
- The agent should not create the folders in another location such as the workspace, desktop, or a different drive.
- The “keep everything for this project inside its own folder” instruction is a constraint on future file organization, not a request to create sample files or move unrelated files during this task.

Ground truth:
- Base folder: `D:/My Projects/`
- Year folder: `D:/My Projects/2026 Projects/`
- Project folder: `D:/My Projects/2026 Projects/05TK25002D-Blue Ocean New Materials Co. High-End Polyolefin New Materials Project/`

Tested capabilities: file system operations, directory creation, instruction following, exact path naming.

## Grading Criteria

- [ ] `D:/My Projects/` exists as a directory
- [ ] `D:/My Projects/2026 Projects/` exists as a directory
- [ ] `D:/My Projects/2026 Projects/05TK25002D-Blue Ocean New Materials Co. High-End Polyolefin New Materials Project/` exists as a directory
- [ ] The project folder name exactly matches the requested project code and project name
- [ ] The project folder is created under the correct `D:/My Projects/2026 Projects/` hierarchy rather than in an incorrect alternative location

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    from pathlib import Path

    scores = {
        "main_folder_exists": 0.0,
        "year_folder_exists": 0.0,
        "project_folder_exists": 0.0,
        "project_folder_exact_name": 0.0,
        "correct_hierarchy_location": 0.0,
    }

    base_path = Path("D:/My Projects")
    year_path = base_path / "2026 Projects"
    project_folder_name = "05TK25002D-Blue Ocean New Materials Co. High-End Polyolefin New Materials Project"
    project_path = year_path / project_folder_name
    workspace = Path(workspace_path)

    if base_path.exists() and base_path.is_dir():
        scores["main_folder_exists"] = 1.0

    if year_path.exists() and year_path.is_dir():
        scores["year_folder_exists"] = 1.0

    if project_path.exists() and project_path.is_dir():
        scores["project_folder_exists"] = 1.0
        scores["project_folder_exact_name"] = 1.0
        scores["correct_hierarchy_location"] = 1.0
        return scores

    # If the exact target project folder is missing, keep the remaining keys at 0.0 by default.
    # Then check for partial-credit cases such as the exact name in the wrong location
    # or a near-match name in a plausible location.
    candidate_dirs = []

    search_roots = []
    if year_path.exists() and year_path.is_dir():
        search_roots.append(year_path)
    if base_path.exists() and base_path.is_dir():
        search_roots.append(base_path)
    if workspace.exists() and workspace.is_dir():
        search_roots.append(workspace)
    d_root = Path("D:/")
    if d_root.exists() and d_root.is_dir():
        search_roots.append(d_root)

    seen = set()
    for root in search_roots:
        try:
            root_key = str(root.resolve())
        except Exception:
            root_key = str(root)
        if root_key in seen:
            continue
        seen.add(root_key)

        try:
            for item in root.iterdir():
                if item.is_dir() and "05TK25002D" in item.name:
                    candidate_dirs.append(item)
        except Exception:
            pass

    exact_name_found_wrong_place = False
    near_match_found = False

    for item in candidate_dirs:
        if item.name == project_folder_name:
            exact_name_found_wrong_place = True
        elif "Blue Ocean" in item.name:
            near_match_found = True

    if exact_name_found_wrong_place:
        scores["project_folder_exists"] = 0.6
        scores["project_folder_exact_name"] = 1.0
        scores["correct_hierarchy_location"] = 0.0
    elif near_match_found:
        scores["project_folder_exists"] = 0.4
        scores["project_folder_exact_name"] = 0.0
        scores["correct_hierarchy_location"] = 0.0

    return scores
````

## LLM Judge Rubric

### Dimensions

#### 1. Task Completion (Weight: 40%)

* **1.0**: Fully creates the requested directory structure exactly as specified.
* **0.75**: Creates most of the requested structure, with only a minor omission or recoverable mistake.
* **0.5**: Creates part of the structure, but misses one important level or places part of it incorrectly.
* **0.25**: Attempts directory creation, but the result is largely incorrect or incomplete.
* **0.0**: Does not create the requested directory structure.

#### 2. Naming Accuracy (Weight: 35%)

* **1.0**: Uses the exact requested folder names, including the full project folder name with code.
* **0.75**: Folder naming is mostly correct, with only a minor formatting deviation that does not materially change identity.
* **0.5**: Folder naming is partially correct, but includes truncation or a noticeable deviation.
* **0.25**: Folder names are substantially wrong or ambiguous.
* **0.0**: Folder names do not match the requested structure.

#### 3. Location Correctness (Weight: 25%)

* **1.0**: Places the folders under the exact required hierarchy `D:/My Projects/2026 Projects/`.
* **0.75**: Uses the correct drive and mostly correct hierarchy, with only a minor placement issue.
* **0.5**: Uses the correct general area but the wrong level in the hierarchy.
* **0.25**: Creates the folders in a clearly incorrect alternative location.
* **0.0**: Does not place the folders in the required location.