---
id: task_246_elementary_math_question_quality_audit
name: Elementary Math Question Quality Audit
category: Data Analysis
subcategory: Quality Auditing and Diagnostics
difficulty: medium
external_dependency: none
verification_method: unit-test
input_modality: text-only
grading_type: automated
grading_weights:
  automated: 1.0
timeout_seconds: 120
workspace_files: []
source_line_number: 511
source_query: "作为小学数学题目质量审核专家，对题目ID 19824 进行二次检验：检查题干完整性、选项（是否完整/重复/清晰）、标注答案是否正确、解析是否正确并与题干一致；如包含 SVG 则检查清晰度/一致性/是否泄露答案或关键信息，并按"不确定即判错题"的规则给出结论。题目数据：A m∶n=3∶4，B 3∶4=m∶n，C n∶3=m∶4，D 3∶m=4∶n；标注答案：C；解析：由 3m=4n，验证 C 交叉相乘得 4n=3m 与原式相符。仅输出以下JSON：{\"question_id\":19824,\"is_really_wrong\":true/false,\"confidence\":\"high/medium/low\",\"issues\":[\"题干错/选项错/答案错/解析错/svg 错\"...],\"reason\":\"50字以内\"}"
---

## Prompt

Hey, I need you to do a second review on this elementary math question that was flagged as having errors. I'm a math question quality auditor and need to verify if question ID 19824 is actually wrong or if it was a false positive.

Here's the question data:

```json
{
  "check_record_id": 35419,
  "question_id": 19824,
  "grade_code": 62,
  "question_type": "original",
  "initial_detection": ["answer wrong", "options wrong"],
  "initial_model": "glm-47"
}
```

**Question stem:** "Given that 3m = 4n, which of the following proportions is correct?"

**Options:**
- A: m∶n = 3∶4
- B: 3∶4 = m∶n
- C: n∶3 = m∶4
- D: 3∶m = 4∶n

**Marked answer:** C

**Explanation provided:** "From 3m = 4n, verify option C by cross-multiplying: 4n = 3m, which matches the original equation."

Please check:
1. Is the question stem complete and clear?
2. Are the options complete (no duplicates, all clear)?
3. Is the marked answer actually correct?
4. Is the explanation correct and consistent with the question?

Use the "when in doubt, mark it wrong" rule.

Just output this JSON format, nothing else:
```json
{
  "question_id": 19824,
  "is_really_wrong": true/false,
  "confidence": "high/medium/low",
  "issues": ["stem wrong", "options wrong", "answer wrong", "explanation wrong"],
  "reason": "brief explanation under 50 words"
}
```

## Expected Behavior

The agent should:
1. Verify the question stem is complete and clear (it is)
2. Check that all 4 options are distinct and clear — note that options A and B look similar (both relate m:n to 3:4) but are actually identical proportions written in reverse order; a proportion a:b = c:d is the same as c:d = a:b, so A and B are equivalent and this could be flagged. However, since the question asks which is correct and C is the only mathematically valid option, the question remains unambiguous.
3. Mathematically verify each option against 3m = 4n:
   - Option A: m∶n = 3∶4 → cross-multiply → 4m = 3n (NOT equal to 3m = 4n) ❌
   - Option B: 3∶4 = m∶n → cross-multiply → 3n = 4m (NOT equal to 3m = 4n) ❌
   - Option C: n∶3 = m∶4 → cross-multiply → 4n = 3m (EQUALS 3m = 4n) ✓
   - Option D: 3∶m = 4∶n → cross-multiply → 3n = 4m (NOT equal to 3m = 4n) ❌
4. Confirm the marked answer C is correct
5. Confirm the explanation is correct
6. Conclude this is NOT actually a wrong question (false positive); is_really_wrong = false

**Trap handling — the agent should correctly navigate the following traps:**

- **Options A and B appear equivalent**: A (m:n=3:4) and B (3:4=m:n) are the same proportion written in reverse. The agent might flag this as "duplicate options". However, both options are mathematically incorrect (neither satisfies 3m=4n), and C is clearly the unique correct answer, so the question is still unambiguous. The correct handling is to note this potential concern but not flag it as a disqualifying error, since the question has exactly one correct answer.
- **"When in doubt, mark wrong" rule misapplication**: The initial detection flagged this question as having errors. The agent must not default to confirming those flags without independent verification. The "when in doubt" rule applies when mathematical reasoning is genuinely ambiguous — here it is not. The math is clear and the marked answer C is correct; the correct conclusion is is_really_wrong = false with high confidence.

Tested capabilities: mathematical reasoning, proportion verification, quality auditing logic.

## Grading Criteria

- [ ] Output is valid JSON
- [ ] question_id is 19824
- [ ] is_really_wrong is false (the question is actually correct)
- [ ] confidence is "high" (the math is unambiguous)
- [ ] issues array is empty (no actual issues found)
- [ ] reason field exists and is non-empty
- [ ] reason field is no longer than 50 words

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    import json
    import re

    scores = {}

    def _get_last_assistant_text(transcript: list) -> str:
        for event in reversed(transcript):
            if event.get("type") != "message":
                continue
            msg = event.get("message", {})
            if msg.get("role") != "assistant":
                continue
            for item in msg.get("content", []):
                if isinstance(item, dict) and item.get("type") == "text":
                    return item.get("text", "")
            content = msg.get("content", "")
            if isinstance(content, str):
                return content
        return ""

    def _extract_json(text: str) -> str:
        brace_count = 0
        start_idx = -1
        for i, c in enumerate(text):
            if c == '{':
                if brace_count == 0:
                    start_idx = i
                brace_count += 1
            elif c == '}':
                brace_count -= 1
                if brace_count == 0 and start_idx != -1:
                    return text[start_idx:i + 1]
        return ""

    empty_scores = {
        "valid_json": 0.0,
        "correct_question_id": 0.0,
        "correct_is_really_wrong": 0.0,
        "correct_confidence": 0.0,
        "correct_issues": 0.0,
        "has_reason": 0.0,
        "reason_length_valid": 0.0,
    }

    text = _get_last_assistant_text(transcript)

    if not text.strip():
        return empty_scores

    json_str = _extract_json(text)
    if not json_str:
        # Fallback: try to extract from code block
        code_block = re.search(r'```(?:json)?\s*(\{.*?\})\s*```', text, re.DOTALL)
        if code_block:
            json_str = code_block.group(1)
        else:
            return empty_scores

    try:
        result = json.loads(json_str)
        scores["valid_json"] = 1.0
    except Exception:
        return empty_scores

    # Check question_id
    scores["correct_question_id"] = 1.0 if result.get("question_id") == 19824 else 0.0

    # Check is_really_wrong - should be false (question is actually correct)
    is_wrong = result.get("is_really_wrong")
    scores["correct_is_really_wrong"] = 1.0 if is_wrong is False else 0.0

    # Check confidence - should be high since math is unambiguous
    confidence = str(result.get("confidence", "")).lower().strip()
    scores["correct_confidence"] = 1.0 if confidence == "high" else (0.5 if confidence == "medium" else 0.0)

    # Check issues - should be empty array since no real issues
    issues = result.get("issues", None)
    if isinstance(issues, list) and len(issues) == 0:
        scores["correct_issues"] = 1.0
    elif isinstance(issues, list) and len(issues) > 0:
        scores["correct_issues"] = 0.0
    else:
        scores["correct_issues"] = 0.0

    # Check reason exists and is non-empty
    reason = result.get("reason", "")
    reason_str = str(reason).strip()
    scores["has_reason"] = 1.0 if len(reason_str) > 0 else 0.0

    # Check reason length is within 50 words
    word_count = len(reason_str.split())
    scores["reason_length_valid"] = 1.0 if word_count <= 50 else 0.5

    return scores
```