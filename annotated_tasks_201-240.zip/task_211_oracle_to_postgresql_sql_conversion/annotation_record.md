| 序号 | 修改项 | 修改原因 |
|---|---|---|
| 1    | 改写 Prompt            | 原 Prompt 直接提示“schema/table names should be lowercase”，有点像把评分点直接告诉模型；改为更自然的迁移请求，同时保留输出要求             |
| 2    | 修正 Expected Behavior | 原文对 query 3 只说“可以用子查询或承认差异”，但没有给出明确 Ground Truth；现补充为“必须保留 Oracle 的 ROWNUM-before-ORDER-BY 语义”      |
| 3    | 重写 Grading Criteria  | 原 criteria 偏重复，且与 `grade()` key 不完全对齐；现改为 6 条独立、可验证、覆盖关键能力的条目                                       |
| 4    | 重写 `grade()`         | 原 `grade()` 只能粗略检查关键词，无法判断 query 3 是否真的保留语义；现增加 statement 数量、query 3 子查询/外层排序、Oracle 语法残留、插入语句保留等检查 |
| 5    | 增加部分得分               | 原先多数项接近 0/1；现对多语句检查、标识符规范化等项支持部分得分                                                                  |
| 6    | 增加空白零分前置检查           | 虽然原文件已有部分处理，但 key 与 criteria 不一致；现统一为主输出不存在时全部返回 0.0                                                |
| 7    | 补充 LLM Judge Rubric  | 原文件完全缺失该部分，不满足标注要求                                                                                  |
| 8    | 调整 frontmatter       | 将 `grading_type` 改为 `hybrid`，并增加 `grading_weights`，使 automated + llm_judge 权重和为 1.0                 |