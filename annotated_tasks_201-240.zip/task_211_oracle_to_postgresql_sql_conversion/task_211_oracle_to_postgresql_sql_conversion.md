---
id: task_211_oracle_to_postgresql_sql_conversion
name: Oracle to PostgreSQL SQL Conversion
category: Data Analysis
subcategory: Data Processing and Management
difficulty: medium
external_dependency: none
verification_method: unit-test
input_modality: text-only
grading_type: hybrid
grading_weights:
  automated: 0.8
  llm_judge: 0.2
timeout_seconds: 120
workspace_files: []
source_line_number: 930
source_query: "Convert the following Oracle SQL statements to PostgreSQL equivalents (handle Oracle-specific syntax such as ROWNUM vs LIMIT/OFFSET, function differences like NVL/DECODE if present, date arithmetic, joins/subqueries, and case-sensitivity rules). Provide only the converted PostgreSQL SQL.  Oracle SQL: 1) SELECT * FROM HR.REGIONS ORDER BY REGION_ID; 2) SELECT DEPARTMENT_ID, DEPARTMENT_NAME, LOCATION_ID FROM HR.DEPARTMENTS ORDER BY DEPARTMENT_ID; 3) SELECT e.EMPLOYEE_ID, e.FIRST_NAME, e.LAST_NAM..."
---

## Prompt

I’m migrating a few Oracle SQL statements to PostgreSQL and need the converted SQL saved to a file.

Convert the following Oracle statements to PostgreSQL equivalents and save the result to `postgres_queries.sql`.

Requirements:
- Keep the queries numbered `1)` through `5)`.
- Output only the converted PostgreSQL SQL in the file.
- Preserve the original query behavior as closely as possible.

Oracle SQL:

```sql
1) SELECT * FROM HR.REGIONS ORDER BY REGION_ID;

2) SELECT DEPARTMENT_ID, DEPARTMENT_NAME, LOCATION_ID
   FROM HR.DEPARTMENTS
   ORDER BY DEPARTMENT_ID;

3) SELECT e.EMPLOYEE_ID, e.FIRST_NAME, e.LAST_NAME, e.JOB_ID, e.SALARY, d.DEPARTMENT_NAME
   FROM HR.EMPLOYEES e
   LEFT JOIN HR.DEPARTMENTS d ON e.DEPARTMENT_ID = d.DEPARTMENT_ID
   WHERE ROWNUM <= 10
   ORDER BY e.EMPLOYEE_ID;

4) SELECT COUNT(*) FROM HR.EMPLOYEES;

5) INSERT INTO HR.LOCATIONS
   (LOCATION_ID, STREET_ADDRESS, POSTAL_CODE, CITY, STATE_PROVINCE, COUNTRY_ID)
   VALUES (3300, 'Test St', '00000', 'Test City', 'Test State', 'US');
````

## Expected Behavior

A correct solution should write a file named `postgres_queries.sql` containing five converted PostgreSQL statements.

Key expectations:

1. Use PostgreSQL-compatible SQL and remove Oracle-only syntax.
2. Use unquoted PostgreSQL identifiers consistently (for example `hr.regions`, `department_id`).
3. Preserve the meaning of straightforward statements:

   * Query 1 remains a `SELECT * ... ORDER BY region_id`
   * Query 2 remains a projection from `hr.departments` ordered by `department_id`
   * Query 4 remains `SELECT COUNT(*) FROM hr.employees`
   * Query 5 remains an `INSERT INTO hr.locations (...) VALUES (...)`
4. Query 3 must preserve Oracle semantics, not merely replace `ROWNUM <= 10` with `LIMIT 10` after `ORDER BY`.

   * In Oracle, `ROWNUM <= 10` is applied before the final `ORDER BY`.
   * Therefore, a faithful PostgreSQL conversion should first limit the joined rows in a subquery, then sort those 10 rows in the outer query.
   * One valid pattern is:

```sql
SELECT *
FROM (
    SELECT e.employee_id, e.first_name, e.last_name, e.job_id, e.salary, d.department_name
    FROM hr.employees e
    LEFT JOIN hr.departments d ON e.department_id = d.department_id
    LIMIT 10
) sub
ORDER BY employee_id;
```

5. The output may differ in formatting, whitespace, alias names, or whether the outer query explicitly lists columns instead of `SELECT *`, as long as the PostgreSQL SQL is valid and preserves the original behavior.

Ground truth expectations by query:

* Query 1 references `hr.regions`
* Query 2 references `hr.departments`
* Query 3 preserves `ROWNUM <= 10` semantics via a limiting subquery plus outer `ORDER BY`
* Query 4 references `hr.employees`
* Query 5 inserts into `hr.locations`
* No Oracle-only keywords such as `ROWNUM`, `NVL`, `DECODE`, `SYSDATE`, or `DUAL` should remain

Tested capabilities: SQL dialect conversion, Oracle-to-PostgreSQL syntax knowledge, semantic preservation, and handling of Oracle `ROWNUM` behavior.

## Grading Criteria

* [ ] `postgres_queries.sql` exists
* [ ] The file contains all 5 converted SQL statements
* [ ] Oracle schema/table references are converted to PostgreSQL-style unquoted identifiers (for example `hr.regions`, `hr.departments`, `hr.employees`, `hr.locations`)
* [ ] Query 3 preserves Oracle `ROWNUM <= 10` behavior by limiting rows before the final sort
* [ ] No Oracle-only syntax remains in the output
* [ ] The insert statement for `hr.locations` is preserved with the same values

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    from pathlib import Path
    import re

    ws = Path(workspace_path)
    sql_file = ws / "postgres_queries.sql"

    scores = {
        "file_exists": 0.0,
        "all_5_statements_present": 0.0,
        "identifiers_converted_to_postgresql_style": 0.0,
        "query_3_rownum_semantics_preserved": 0.0,
        "no_oracle_only_syntax_remaining": 0.0,
        "insert_statement_preserved": 0.0,
    }

    if not sql_file.exists():
        return scores

    scores["file_exists"] = 1.0

    try:
        content = sql_file.read_text(encoding="utf-8", errors="ignore")
    except Exception:
        return scores

    content_lower = content.lower()

    # Split on semicolons for a tolerant statement count.
    statements = [s.strip() for s in re.split(r";\s*", content) if s.strip()]

    # Count numbering markers 1) ... 5), but allow comments or simple prefixes.
    marker_hits = 0
    for i in range(1, 6):
        if re.search(rf"(^|\n)\s*(--\s*)?{i}[\)\.]", content_lower):
            marker_hits += 1

    # Presence of expected statement types/content.
    has_selects = len(re.findall(r"\bselect\b", content_lower)) >= 4
    has_insert = "insert into" in content_lower
    statement_score = 0.0
    if len(statements) >= 5:
        statement_score += 0.5
    elif len(statements) == 4:
        statement_score += 0.25

    if marker_hits >= 5:
        statement_score += 0.25
    elif marker_hits >= 3:
        statement_score += 0.1

    if has_selects and has_insert:
        statement_score += 0.25

    scores["all_5_statements_present"] = min(statement_score, 1.0)

    # Check PostgreSQL-style unquoted identifiers.
    expected_refs = [
        "hr.regions",
        "hr.departments",
        "hr.employees",
        "hr.locations",
    ]
    ref_hits = sum(1 for ref in expected_refs if ref in content_lower)

    upper_oracle_refs = [
        "HR.REGIONS",
        "HR.DEPARTMENTS",
        "HR.EMPLOYEES",
        "HR.LOCATIONS",
    ]
    upper_hits = sum(1 for ref in upper_oracle_refs if ref in content)

    ident_score = 0.0
    ident_score += min(ref_hits / 4.0, 1.0) * 0.8
    if upper_hits == 0:
        ident_score += 0.2
    scores["identifiers_converted_to_postgresql_style"] = min(ident_score, 1.0)

    # Query 3: must preserve Oracle semantics by limiting before final ORDER BY.
    # We accept either:
    # - a subquery/CTE containing LIMIT/FETCH, followed by an outer ORDER BY
    # - or any clearly nested pattern where LIMIT/FETCH appears before the final outer ORDER BY.
    has_rownum = "rownum" in content_lower

    nested_limit_pattern = re.search(
        r"select\s+.*?\bfrom\s*\(\s*select\s+.*?\bfrom\s+hr\.employees\b.*?"
        r"(limit\s+10|fetch\s+first\s+10\s+rows\s+only).*?\)\s*[a-z_][a-z0-9_]*\s*"
        r"order\s+by\s+",
        content_lower,
        re.DOTALL,
    )

    cte_limit_pattern = re.search(
        r"with\s+[a-z_][a-z0-9_]*\s+as\s*\(\s*select\s+.*?\bfrom\s+hr\.employees\b.*?"
        r"(limit\s+10|fetch\s+first\s+10\s+rows\s+only).*?\)\s*select\s+.*?order\s+by\s+",
        content_lower,
        re.DOTALL,
    )

    naive_wrong_pattern = re.search(
        r"from\s+hr\.employees\b.*?order\s+by\s+.*?(limit\s+10|fetch\s+first\s+10\s+rows\s+only)",
        content_lower,
        re.DOTALL,
    )

    if not has_rownum and (nested_limit_pattern or cte_limit_pattern):
        scores["query_3_rownum_semantics_preserved"] = 1.0
    elif not has_rownum and naive_wrong_pattern:
        scores["query_3_rownum_semantics_preserved"] = 0.25
    else:
        scores["query_3_rownum_semantics_preserved"] = 0.0

    oracle_keywords = ["rownum", "nvl(", "decode(", "sysdate", "dual", "connect by", "start with"]
    oracle_found = sum(1 for kw in oracle_keywords if kw in content_lower)
    scores["no_oracle_only_syntax_remaining"] = 1.0 if oracle_found == 0 else 0.0

    # Check insert statement preserved with same target and values, tolerant to whitespace/newlines.
    insert_pattern = re.search(
        r"insert\s+into\s+hr\.locations\s*"
        r"\(\s*location_id\s*,\s*street_address\s*,\s*postal_code\s*,\s*city\s*,\s*state_province\s*,\s*country_id\s*\)\s*"
        r"values\s*\(\s*3300\s*,\s*'test st'\s*,\s*'00000'\s*,\s*'test city'\s*,\s*'test state'\s*,\s*'us'\s*\)",
        content_lower,
        re.DOTALL,
    )
    scores["insert_statement_preserved"] = 1.0 if insert_pattern else 0.0

    return scores
```

## LLM Judge Rubric

### Dimension 1: SQL correctness and PostgreSQL compatibility (Weight: 40%)

**1.0**
All five statements are valid PostgreSQL-style conversions. Oracle-only syntax is removed. The SQL is internally consistent and executable with only minor environment-specific assumptions.

**0.75**
Most statements are correctly converted, with only small PostgreSQL syntax or style issues that do not materially change intent.

**0.5**
Some statements are converted correctly, but one or more contain notable syntax issues, inconsistent identifier handling, or partially retained Oracle conventions.

**0.25**
The response shows limited PostgreSQL conversion ability. Several statements remain Oracle-like or would likely fail in PostgreSQL.

**0.0**
The response is missing, unrelated, or mostly unconverted Oracle SQL.

### Dimension 2: Semantic preservation, especially Query 3 (Weight: 40%)

**1.0**
The response preserves the original behavior of all queries, including correctly handling Oracle `ROWNUM <= 10` semantics by limiting rows before the final sort in Query 3.

**0.75**
The response preserves the behavior of most queries and clearly attempts to handle Query 3 carefully, with only minor semantic ambiguity.

**0.5**
The response preserves basic intent for simple queries, but Query 3 is only partially correct or uses a naive `ORDER BY ... LIMIT 10` conversion that changes semantics.

**0.25**
Multiple queries materially change behavior, or Query 3 is converted in a way that clearly ignores Oracle `ROWNUM` semantics.

**0.0**
The response does not preserve the original query behavior.

### Dimension 3: Instruction following and output formatting (Weight: 20%)

**1.0**
The answer follows all instructions: writes to `postgres_queries.sql`, includes five numbered statements, and outputs only the converted SQL.

**0.75**
Minor formatting or numbering issues are present, but the file content is still easy to evaluate and mostly compliant.

**0.5**
The answer is partially compliant but includes extra explanation, inconsistent numbering, or incomplete file content.

**0.25**
The output format substantially deviates from the instructions.

**0.0**
The requested file is not produced or the response does not follow the task format at all.

