---
id: task_237_fix_factor_expression_syntax_error
name: Fix Factor Expression Syntax Error
category: Finance
subcategory: Trading Strategy and Backtesting
difficulty: medium
external_dependency: none
verification_method: rubric
input_modality: text-only
grading_type: automated
timeout_seconds: 120
grading_weights:
  automated: 1.0
  llm_judge: 0.0
workspace_files: []
source_line_number: 6957
source_query: "Rewrite/correct the factor expression for factor_name \"Opening_Return_Reversion_Ratio_3D_10D\" (ratio of short-term to long-term mean reversion speed after opening gaps). Former (failed) expression: \"RANK(TS_MEAN($return, 3) / (TS_MEAN($return, 10) + 1e-8)) * SIGN($open - DELAY($close, 1))\". Fix it to avoid the SyntaxError and comply with the expression parser requirements noted in the feedback: ensure variables are valid available columns and are properly referenced (avoid unresolved \"$r..."
---

## Prompt

Hey, I need help fixing a quant factor expression that is failing to parse.

The factor is called `Opening_Return_Reversion_Ratio_3D_10D`. It is intended to represent the ratio of short-term to long-term mean reversion speed after opening gaps.

Original expression:
```text
RANK(TS_MEAN($return, 3) / (TS_MEAN($return, 10) + 1e-8)) * SIGN($open - DELAY($close, 1))
````

Parser constraints:

* Available columns: `$open`, `$high`, `$low`, `$close`, `$volume`
* Supported functions: `ADD`, `SUBTRACT`, `MULTIPLY`, `DIVIDE`, `RANK`, `TS_MEAN`, `TS_STD`, `DELAY`, `SIGN`, `ABS`, `LOG`, `SQRT`, `MAX`, `MIN`, `IF`, `CONST`
* Arithmetic must be written in function form, not with raw operators
* The expression must be valid under those parser rules

Please rewrite the expression so it preserves the original factor logic as closely as possible.

Return **only** a JSON object in exactly this format:

```json
{"expr":"<corrected_expression>"}
```

Do not include any explanation or extra text.

## Expected Behavior

The agent should:

1. Output exactly one JSON object with a top-level `"expr"` key.
2. Rewrite the invalid expression into a parser-compliant expression.
3. Preserve the original logic as closely as possible:

   * a ranked ratio of short-term versus long-term mean return
   * multiplied by the sign of the opening gap direction
4. Replace the invalid `$return` reference by computing return from valid price columns.
5. Use only supported functions and valid available columns.
6. Avoid raw arithmetic operators such as `+`, `-`, `*`, `/`.
7. Wrap non-window numeric constants in `CONST(...)`.
8. Include both `TS_MEAN(..., 3)` and `TS_MEAN(..., 10)` in the corrected logic.

Traps the agent should handle correctly:

* The response must be JSON only; any extra prose should be considered incorrect.
* `$return` is not a valid available column and must not appear in the final expression.
* Raw arithmetic operators are not allowed even if the expression is mathematically correct.
* Small constants such as epsilon must be wrapped with `CONST(...)`.
* Window sizes such as `3` and `10` are function parameters and do not need `CONST(...)`.

Ground truth constraints:

* Output format: a valid JSON object with key `"expr"`
* Final expression must not contain `$return`
* Final expression must use valid columns only
* Final expression must use function-form arithmetic only
* Final expression must preserve the short-vs-long mean return ratio and opening-gap sign structure

## Grading Criteria

* [ ] Output is valid JSON with top-level `"expr"` key
* [ ] Expression does not contain `$return`
* [ ] Expression computes return using `$close` and `DELAY($close, 1)`
* [ ] Expression uses `TS_MEAN(..., 3)` and `TS_MEAN(..., 10)`
* [ ] Expression contains a `SIGN` component using the opening gap direction
* [ ] Expression uses function-form arithmetic only, with no raw `+`, `-`, `*`, `/`
* [ ] Non-window numeric constants are wrapped in `CONST(...)`
* [ ] Expression uses only supported functions and valid columns

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    import json
    import re

    def _get_last_assistant_text(transcript: list) -> str:
        for event in reversed(transcript):
            if event.get("type") != "message":
                continue
            msg = event.get("message", {})
            if msg.get("role") != "assistant":
                continue

            content = msg.get("content", "")
            if isinstance(content, str):
                return content

            if isinstance(content, list):
                text_parts = []
                for item in content:
                    if isinstance(item, dict) and item.get("type") == "text":
                        text_parts.append(item.get("text", ""))
                if text_parts:
                    return "\n".join(text_parts)

        return ""

    scores = {
        "valid_json_with_expr": 0.0,
        "no_invalid_return_column": 0.0,
        "uses_delay_for_returns": 0.0,
        "has_ts_mean_both_windows": 0.0,
        "has_sign_component": 0.0,
        "uses_function_forms_only": 0.0,
        "non_window_constants_wrapped": 0.0,
        "uses_only_supported_functions_and_valid_columns": 0.0,
    }

    text = _get_last_assistant_text(transcript).strip()

    parsed_expr = None
    try:
        parsed = json.loads(text)
        if isinstance(parsed, dict) and "expr" in parsed and isinstance(parsed["expr"], str):
            parsed_expr = parsed["expr"]
            scores["valid_json_with_expr"] = 1.0
    except Exception:
        parsed_expr = None

    if parsed_expr is None:
        return scores

    expr = parsed_expr
    expr_upper = expr.upper()

    # 1) Invalid $return reference
    scores["no_invalid_return_column"] = 0.0 if "$RETURN" in expr_upper else 1.0

    # 2) Return should be based on $close and DELAY($close, 1)
    has_delay = "DELAY($CLOSE, 1)" in expr_upper or "DELAY($CLOSE,1)" in expr_upper
    has_close = "$CLOSE" in expr_upper
    scores["uses_delay_for_returns"] = 1.0 if (has_close and has_delay) else 0.0

    # 3) Must contain both windows 3 and 10 with TS_MEAN
    has_ts_mean_3 = "TS_MEAN(" in expr_upper and ", 3)" in expr_upper or ",3)" in expr_upper
    has_ts_mean_10 = "TS_MEAN(" in expr_upper and ", 10)" in expr_upper or ",10)" in expr_upper
    scores["has_ts_mean_both_windows"] = 1.0 if (has_ts_mean_3 and has_ts_mean_10) else 0.0

    # 4) SIGN opening gap direction
    has_sign = "SIGN(" in expr_upper
    has_open = "$OPEN" in expr_upper
    scores["has_sign_component"] = 1.0 if (has_sign and has_open and has_delay) else 0.0

    # 5) Function-form arithmetic only
    no_raw_ops = not bool(re.search(r'[\+\-\*/]', expr))
    has_required_function_arith = all(fn in expr_upper for fn in ["ADD(", "SUBTRACT(", "MULTIPLY(", "DIVIDE("])
    scores["uses_function_forms_only"] = 1.0 if (no_raw_ops and has_required_function_arith) else 0.0

    # 6) Non-window constants must be wrapped in CONST(...)
    temp = re.sub(r'CONST\s*\(\s*[^()]+\s*\)', '', expr, flags=re.IGNORECASE)
    bare_float_or_sci = re.search(r'(?<![A-Z_])\d+\.\d+(?:[eE][+\-]?\d+)?|\d+[eE][+\-]?\d+', temp)
    scores["non_window_constants_wrapped"] = 0.0 if bare_float_or_sci else 1.0

    # 7) Only supported functions and valid columns
    supported_functions = {
        "ADD", "SUBTRACT", "MULTIPLY", "DIVIDE", "RANK", "TS_MEAN", "TS_STD",
        "DELAY", "SIGN", "ABS", "LOG", "SQRT", "MAX", "MIN", "IF", "CONST"
    }
    valid_columns = {"$OPEN", "$HIGH", "$LOW", "$CLOSE", "$VOLUME"}

    called_funcs = set(re.findall(r'\b([A-Z_]+)\s*\(', expr_upper))
    invalid_funcs = {f for f in called_funcs if f not in supported_functions}

    referenced_cols = set(re.findall(r'(\$[A-Z]+)\b', expr_upper))
    invalid_cols = {c for c in referenced_cols if c not in valid_columns}

    scores["uses_only_supported_functions_and_valid_columns"] = 1.0 if (not invalid_funcs and not invalid_cols) else 0.0

    return scores
```

## LLM Judge Rubric

Not applicable. This task is graded fully by automated checks.

