| 序号 | 修改项 | 修改原因 |
|------|--------|----------|
| 1    | 将 `difficulty` 从 `hard` 改为 `medium` | 该题目标单一、答案空间较窄、主要是表达式语法修复与格式约束，复杂度不足以稳定落到 hard |
| 2    | 重写 Prompt，减少解法泄露 | 原 Prompt 已经明确提示了 `$return` 应如何改写、`CONST(0.00000001)` 应如何写，答案泄露过多，不符合“Prompt 不泄露答案”要求 |
| 3    | 强化“仅输出 JSON，不要解释文字” | 这是该题最关键的输出约束之一，必须在 Prompt 和 Expected Behavior 中都明确 |
| 4    | 在 Expected Behavior 中补充完整解题路径 | 原版虽然有核心点，但缺少对输出格式、函数形式、列合法性、常量包装等完整约束链条 |
| 5    | 增加 traps 说明 | 这题存在明显陷阱：输出多余文字、继续使用 `$return`、使用裸操作符、裸写 epsilon、误包窗口参数等，需显式写出 |
| 6    | 增加 Ground Truth constraints | 让答案更可验证，便于 automated grading 与人工审核一致 |
| 7    | 重写 Grading Criteria | 原条目基本合理，但可进一步与自动评分 key 精确对齐，并拆分为独立可验证项 |
| 8    | 明确“return 必须由 `$close` 与 `DELAY($close, 1)` 计算” | 原评分有这层意思，但标准未充分显式化 |
| 9   | 明确“只允许受支持函数与合法列” | 原 Prompt 有说明，但 Grading Criteria 未单独强调完整合法性 |
| 10   | 调整 automated checks 的 score key | 让 key 与 Grading Criteria 更接近一一对应，满足 Key 对齐要求 |
| 11   | 改进 JSON 检查逻辑 | 原版会在整段文字中用正则抓 JSON，可能误把附加解释包进去也判通过；新版直接要求整段输出可被 `json.loads` 成功解析，更符合“只输出 JSON”要求 |
| 12   | 改进 `uses_function_forms` 检查 | 原版只要求出现 `DIVIDE` 或 `MULTIPLY`，不足以确保所有算术都已函数化；新版要求无裸操作符且 `ADD/SUBTRACT/MULTIPLY/DIVIDE` 都出现 |
| 13   | 简化并收紧裸操作符检查 | 原版对 `+/-/*//` 的正则较脆，且有一些例外处理；新版在该任务中直接要求表达式内无裸四则符号，更清晰 |
| 14   | 改进常量包装检查 | 原版只在“存在 raw float 且没有 CONST”时给 0，过于宽松；新版移除 `CONST(...)` 后再查裸浮点/科学计数，更贴近规则 |
| 15   | 明确允许窗口参数整数不包 `CONST` | 题目本身要求应允许 `3` 和 `10` 作为窗口参数，因此在 Expected Behavior 和 trap 中补充说明 |
| 16   | 改进支持函数与合法列检查 | 原版没有单独验证是否调用了未注册函数；新版通过正则抽取函数名和列名检查合法性 |
| 17   | 将 `LLM Judge Rubric` 改为 “Not applicable” | 由于 `grading_type: automated` 且 `llm_judge: 0.0`，不需要再保留一个实际不参与评分的 Rubric 段落，避免冗余和歧义 |