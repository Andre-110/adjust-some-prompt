---
id: task_202_openclaw_multi_model_configuration_generator
name: OpenClaw Multi-Model Configuration Generator
category: Automation
subcategory: Agent and AI Orchestration
difficulty: medium
external_dependency: none
verification_method: unit-test
input_modality: text-only
grading_type: automated
timeout_seconds: 120
workspace_files: []
source_line_number: 3612
source_query: "请按以下分工生成/调整 OpenClaw 多模型配置（必要时修正提供商前缀并给出可直接粘贴的 JSON）：complex_reasoning→glm-4.7（主脑决策）、mining_tasks→qwen3-max-2026-01-23、general_tasks→qwen3.5-plus、coding_tasks→qwen3-coder-plus。"
---

## Prompt

I need an OpenClaw multi-model configuration file for routing different task types to different models.

Target routing:
- `complex_reasoning` → `glm-4.7`
- `mining_tasks` → `qwen3-max-2026-01-23`
- `general_tasks` → `qwen3.5-plus`
- `coding_tasks` → `qwen3-coder-plus`

Please generate a JSON config and save it as `openclaw_config.json`.

Requirements:
- The config must include a top-level `models` object containing the task-to-model mappings.
- It must also include:
  - `version`: `"1.0"`
  - `routing_enabled`: `true`
- Use the correct provider prefixes for each model family.
- Do not add any extra task types beyond the four listed above.

## Expected Behavior

The agent should:

1. Create a file named `openclaw_config.json`.
2. Write valid JSON into that file.
3. Include a top-level `models` object.
4. Map the four task types exactly as follows, using correct provider prefixes:
   - `complex_reasoning` → `zhipu/glm-4.7`
   - `mining_tasks` → `dashscope/qwen3-max-2026-01-23`
   - `general_tasks` → `dashscope/qwen3.5-plus`
   - `coding_tasks` → `dashscope/qwen3-coder-plus`
5. Include:
   - `version: "1.0"`
   - `routing_enabled: true`
6. Avoid adding any extra task types or unrelated configuration fields that change the requested routing structure.

### Ground Truth

The expected JSON content is equivalent to:

```json
{
  "version": "1.0",
  "routing_enabled": true,
  "models": {
    "complex_reasoning": "zhipu/glm-4.7",
    "mining_tasks": "dashscope/qwen3-max-2026-01-23",
    "general_tasks": "dashscope/qwen3.5-plus",
    "coding_tasks": "dashscope/qwen3-coder-plus"
  }
}
````

Key correctness points:

* `glm` model uses provider prefix `zhipu/`
* all `qwen` models use provider prefix `dashscope/`
* only the four requested task types appear under `models`

### Trap Handling

This task contains a provider-prefix trap. The model names are given without full provider-qualified names, so the agent must infer and apply the correct prefixes instead of copying bare model names directly.

## Grading Criteria

* [ ] File `openclaw_config.json` exists
* [ ] File contains valid JSON
* [ ] Top-level required fields are present: `version`, `routing_enabled`, `models`
* [ ] `models` contains all 4 required task mappings
* [ ] `complex_reasoning` is `zhipu/glm-4.7`
* [ ] `mining_tasks` is `dashscope/qwen3-max-2026-01-23`
* [ ] `general_tasks` is `dashscope/qwen3.5-plus`
* [ ] `coding_tasks` is `dashscope/qwen3-coder-plus`
* [ ] `version` is `"1.0"` and `routing_enabled` is `true`
* [ ] No extra task types are added under `models`

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    from pathlib import Path
    import json

    def _zero_scores():
        return {
            "config_file_exists": 0.0,
            "valid_json": 0.0,
            "top_level_fields_present": 0.0,
            "models_has_required_tasks": 0.0,
            "complex_reasoning_correct": 0.0,
            "mining_tasks_correct": 0.0,
            "general_tasks_correct": 0.0,
            "coding_tasks_correct": 0.0,
            "metadata_correct": 0.0,
            "no_extra_tasks": 0.0,
        }

    scores = _zero_scores()
    ws = Path(workspace_path)
    config_file = ws / "openclaw_config.json"

    if not config_file.exists():
        return scores

    scores["config_file_exists"] = 1.0

    try:
        content = config_file.read_text(encoding="utf-8")
        config = json.loads(content)
        if not isinstance(config, dict):
            return scores
        scores["valid_json"] = 1.0
    except Exception:
        return scores

    required_top = {"version", "routing_enabled", "models"}
    present_top = sum(1 for key in required_top if key in config)
    scores["top_level_fields_present"] = present_top / len(required_top)

    models = config.get("models", {})
    expected_tasks = {"complex_reasoning", "mining_tasks", "general_tasks", "coding_tasks"}

    if isinstance(models, dict):
        actual_tasks = set(models.keys())
        required_present = len(actual_tasks & expected_tasks)
        scores["models_has_required_tasks"] = required_present / len(expected_tasks)
    else:
        actual_tasks = set()
        scores["models_has_required_tasks"] = 0.0

    def _norm(v):
        return str(v).strip()

    scores["complex_reasoning_correct"] = 1.0 if _norm(models.get("complex_reasoning", "")) == "zhipu/glm-4.7" else 0.0
    scores["mining_tasks_correct"] = 1.0 if _norm(models.get("mining_tasks", "")) == "dashscope/qwen3-max-2026-01-23" else 0.0
    scores["general_tasks_correct"] = 1.0 if _norm(models.get("general_tasks", "")) == "dashscope/qwen3.5-plus" else 0.0
    scores["coding_tasks_correct"] = 1.0 if _norm(models.get("coding_tasks", "")) == "dashscope/qwen3-coder-plus" else 0.0

    version_ok = _norm(config.get("version", "")) == "1.0"
    routing_ok = config.get("routing_enabled") is True
    if version_ok and routing_ok:
        scores["metadata_correct"] = 1.0
    elif version_ok or routing_ok:
        scores["metadata_correct"] = 0.5
    else:
        scores["metadata_correct"] = 0.0

    extra_tasks = actual_tasks - expected_tasks
    scores["no_extra_tasks"] = 1.0 if len(extra_tasks) == 0 else 0.0

    return scores
```

## LLM Judge Rubric

Not applicable. This task uses automated grading only.
