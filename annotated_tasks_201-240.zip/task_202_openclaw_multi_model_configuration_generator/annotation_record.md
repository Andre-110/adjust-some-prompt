| 序号 | 修改项 | 修改原因 |
|---|---|---|
| 1 | 轻微改写 `Prompt` | 原 Prompt 较清晰，但略偏“把答案结构直接说全”，调整后更像真实配置请求，同时保留必要约束 |
| 2 | 将 “provider prefix should be ...” 改为 “Use the correct provider prefixes for each model family” | 减少答案泄露，保留“需要模型自行判断/修正前缀”的考点 |
| 3 | 补充 `Expected Behavior` 的 Ground Truth | 原版本方向明确，但缺少更标准的可核验目标内容 |
| 4 | 增加 `Trap Handling` | 原版本没有明确说明“provider prefix trap”及正确处理方式 |
| 5 | 重写 `Grading Criteria` 表述 | 让条目更独立、可验证，并与自动评分 key 更好对齐 |
| 6 | 将 `has_models_object` 改为 `top_level_fields_present` + `models_has_required_tasks` | 原评分项粒度不够合理，难以区分顶层结构问题和 models 内字段缺失问题 |
| 7 | 为顶层字段检查增加部分得分 | 原逻辑没有体现字段缺失时的梯度 |
| 8 | 为 `models` 中 4 个任务是否齐全增加部分得分 | 原逻辑只有 `len(models) >= 4`，不能准确反映“缺项”情况 |
| 9 | 合并 `version_correct` 与 `routing_enabled_correct` 为 `metadata_correct` | 与 Grading Criteria 中“metadata 正确”更一致，同时支持部分得分 |
| 10 | 增加 `read_text(encoding="utf-8")` | 提高实现稳健性 |
| 11 | 增加 `config` 必须为 dict 的检查 | 防止 JSON 虽合法但顶层结构错误时误通过 |
| 12 | 明确 “No extra task types” 只针对 `models` 下的键 | 避免规则歧义 |
| 13 | 明确说明 `LLM Judge Rubric` 不适用 | 该题 `grading_type: automated`，避免 rubric 缺失造成歧义 |