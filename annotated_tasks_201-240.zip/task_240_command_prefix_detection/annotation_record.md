| 序号 | 修改项 | 修改原因 |
|---|---|---|
| 1 | 补充 `grading_weights` | 原文件缺少 `grading_weights`；按规范需满足 automated + llm_judge = 1.0。该题为纯自动评分，因此补为 `automated: 1.0`、`llm_judge: 0.0` |
| 2 | 重写 Prompt，移除过多示例与答案暗示 | 原 Prompt 给了大量规则和接近答案的引导，泄露过多；新版只保留必要规则和待判断命令 |
| 3 | 去掉“这是合法命令、没有注入”的直接提示 | 这属于 Expected Behavior 的判断结果，不应提前在 Prompt 中告诉模型 |
| 4 | 重写 Expected Behavior | 原版几乎把 `plink`、合法性、输出形式都直接说出来；新版保留必要行为要求，但减少答案泄露 |
| 5 | 增加 traps 说明 | 该题的主要陷阱是：带空格路径的引号、远程命令的嵌套引号、外层 `plink` 与内层 `mysql` 的区分、以及“只输出 prefix” |
| 6 | 增加 Ground truth | 满足“答案明确、可验证”的要求，同时明确允许的规范输出集合 |
| 7 | 重写 Grading Criteria | 原标准“valid prefix”“plink-related prefix”“clean output”都较宽松；新版改成“accepted output / 非误报 / 非 none / 无额外文本”四项，更独立、可验证 |
| 8 | 将前缀判定改为“允许集合精确匹配” | 原版只要输出中包含 `plink` 或路径片段就通过，过松；新版用 accepted set 明确允许值 |
| 9 | 去掉“长度 < 100 即算 clean”逻辑 | 该逻辑太宽，带解释文本也可能通过；output-check 题应更严格要求“只输出 prefix” |
| 10 | 将 `clean_output` 改为 `output_only_prefix` | 让 score key 更贴近 Grading Criteria，并真正检查是否只有被允许的前缀输出 |
| 11 | 改进 transcript 提取逻辑 | 与前几题保持一致，兼容字符串内容与结构化 `content` 列表，提高稳健性 |
| 12 | 删除无效的“识别 plink-related prefix”模糊表述 | 该表述太宽泛，无法有效区分精确输出与附带解释文本 |
| 13 | 将 `LLM Judge Rubric` 改为 Not applicable | 该题 `grading_type: automated`，且 `llm_judge: 0.0`，不应保留实际不参与评分的 Rubric，避免歧义 |