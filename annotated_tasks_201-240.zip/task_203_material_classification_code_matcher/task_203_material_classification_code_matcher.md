---
id: task_203_material_classification_code_matcher
name: Material Classification Code Matcher
category: Data Analysis
subcategory: Text Parsing
difficulty: medium
external_dependency: none
verification_method: output-check
input_modality: text-only
grading_type: automated
timeout_seconds: 120
workspace_files: []
source_line_number: 7797
source_query: "根据物料信息与专家意见，在以下候选列表中选择最精准匹配的标准分类编码；若无匹配则输出 \"NO_MATCH\"。只输出分类编码或 \"NO_MATCH\"。  物料信息：名称=滚针轴承；规格=Φ45*12.6。 专家意见要点：该物料为滚针轴承（Needle Roller Bearing），外径45mm、宽度12.6mm。  候选列表： 1. 43011301：43 轴承 -> 4301 滚动轴承 -> 430113 滚针轴承 -> 滚针轴承 2. 43011502：43 轴承 -> 4301 滚动轴承 -> 430115 滚轮轴承 -> 滚轮轴承 3. 43011002：43 轴承 -> 4301 滚动轴承 -> 430110 N系列圆柱滚子轴承 -> 偏心轴承 4. 43710103：43 轴承 -> 4371 轴承零、附件 -> 437101 轴承零件 -> 滚针 5. 43011401：43 轴承 -> 4301 滚动轴承 -> 430114 组合轴承 -> 组合轴承 6. 43011601：43 轴承 -> 4301 滚动轴承 -> 430116 翻边轴承 -> 翻边轴承..."
---

## Prompt

I need the standard classification code for the following material from our candidate list.

Material information:
- Name: Needle Roller Bearing
- Specification: Φ45*12.6

Expert notes:
- The material is a needle roller bearing.
- Outer diameter: 45 mm
- Width: 12.6 mm

Choose the **single best matching classification code** from the list below.  
If none of the candidates matches, output `NO_MATCH`.

Output requirement:
- Output **only** the classification code or `NO_MATCH`
- Do not output any explanation or extra text

Candidate list:
1. 43011301: 43 Bearings -> 4301 Rolling Bearings -> 430113 Needle Roller Bearings -> Needle Roller Bearing
2. 43011502: 43 Bearings -> 4301 Rolling Bearings -> 430115 Roller Bearings -> Roller Bearing
3. 43011002: 43 Bearings -> 4301 Rolling Bearings -> 430110 N-Series Cylindrical Roller Bearings -> Eccentric Bearing
4. 43710103: 43 Bearings -> 4371 Bearing Parts & Accessories -> 437101 Bearing Parts -> Needle Roller
5. 43011401: 43 Bearings -> 4301 Rolling Bearings -> 430114 Combined Bearings -> Combined Bearing
6. 43011601: 43 Bearings -> 4301 Rolling Bearings -> 430116 Flanged Bearings -> Flanged Bearing
7. 43020103: 43 Bearings -> 4302 Sliding Bearings -> 430201 Spherical Plain Bearings -> Thrust Spherical Plain Bearing
8. 43020104: 43 Bearings -> 4302 Sliding Bearings -> 430201 Spherical Plain Bearings -> Rod End Bearing
9. 43020101: 43 Bearings -> 4302 Sliding Bearings -> 430201 Spherical Plain Bearings -> Radial Spherical Plain Bearing
10. 43020102: 43 Bearings -> 4302 Sliding Bearings -> 430201 Spherical Plain Bearings -> Angular Contact Spherical Plain Bearing
11. 43011801: 43 Bearings -> 4301 Rolling Bearings -> 430118 Ball Screw Bearings -> Ball Screw Bearing
12. 43990101: 43 Bearings -> 4399 Other Bearings -> 439901 Flange Bearings -> Flange Bearing
13. 43990201: 43 Bearings -> 4399 Other Bearings -> 439902 Graphite Bearings -> Graphite Bearing
14. 43011701: 43 Bearings -> 4301 Rolling Bearings -> 430117 Self-Lubricating Bearings -> Self-Lubricating Bearing
15. 43010201: 43 Bearings -> 4301 Rolling Bearings -> 430102 1-Series Self-Aligning Ball Bearings -> Self-Aligning Ball Bearing
16. 43010601: 43 Bearings -> 4301 Rolling Bearings -> 430106 5-Series Thrust Ball Bearings -> Thrust Ball Bearing
17. 43010701: 43 Bearings -> 4301 Rolling Bearings -> 430107 6-Series Deep Groove Ball Bearings -> Deep Groove Ball Bearing
18. 43011001: 43 Bearings -> 4301 Rolling Bearings -> 430110 N-Series Cylindrical Roller Bearings -> Cylindrical Roller Bearing
19. 43010401: 43 Bearings -> 4301 Rolling Bearings -> 430104 3-Series Tapered Roller Bearings -> Tapered Roller Bearing
20. 43010801: 43 Bearings -> 4301 Rolling Bearings -> 430108 7-Series Angular Contact Ball Bearings -> Angular Contact Ball Bearing
21. 43011101: 43 Bearings -> 4301 Rolling Bearings -> 430111 U-Series Insert Bearings -> Insert Bearing
22. 43020401: 43 Bearings -> 4302 Sliding Bearings -> 430204 Linear Motion Bearings -> Sleeve Type Linear Motion Bearing
23. 43020403: 43 Bearings -> 4302 Sliding Bearings -> 430204 Linear Motion Bearings -> Open Type Linear Motion Bearing
24. 43010501: 43 Bearings -> 4301 Rolling Bearings -> 430105 4-Series Double Row Deep Groove Ball Bearings -> Double Row Deep Groove Ball Bearing
25. 43010101: 43 Bearings -> 4301 Rolling Bearings -> 430101 0-Series Double Row Angular Contact Bearings -> Double Row Angular Contact Bearing
26. 43990301: 43 Bearings -> 4399 Other Bearings -> 439903 Slewing Bearings -> Slewing Bearing
27. 43020402: 43 Bearings -> 4302 Sliding Bearings -> 430204 Linear Motion Bearings -> Adjustable Clearance Linear Motion Bearing
28. 43010901: 43 Bearings -> 4301 Rolling Bearings -> 430109 8-Series Thrust Cylindrical Roller Bearings -> Thrust Cylindrical Roller Bearing
29. 43710201: 43 Bearings -> 4371 Bearing Parts & Accessories -> 437102 Bearing Accessories -> Bearing Housing
30. 43010301: 43 Bearings -> 4301 Rolling Bearings -> 430103 2-Series Spherical Roller Bearings -> Spherical Roller Bearing

Selection rules:
- Prefer the most precise match
- If no candidate matches the material itself, output `NO_MATCH`
- Do not output multiple codes

## Expected Behavior

The agent should:

1. Identify the material as a **complete needle roller bearing**, not merely a bearing part or accessory.
2. Compare the material against the candidate list and select the **most precise** matching code.
3. Distinguish between:
   - `43011301` = complete **Needle Roller Bearing**
   - `43710103` = **Needle Roller** as a bearing part/component
4. Output only the final code, with no explanation.

### Ground Truth

The correct output is:

```text
43011301
```

Reason:

* The material name explicitly indicates a finished **Needle Roller Bearing**
* Candidate `43011301` is the exact product-level match
* Candidate `43710103` refers to a component/part (“Needle Roller”), not the complete bearing assembly

### Trap Handling

This task contains a part-vs-finished-product trap.
The correct handling is to classify the item as the full bearing assembly, not as a bearing component simply because the phrase “needle roller” appears in both labels.

## Grading Criteria

* [ ] Output is exactly one token: either a single classification code or `NO_MATCH`
* [ ] Output matches the correct code `43011301`
* [ ] Output does not select the part code `43710103`
* [ ] Output does not select any other incorrect candidate code
* [ ] Output does not return `NO_MATCH`

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    import re

    def _zero_scores():
        return {
            "single_clean_output": 0.0,
            "correct_code": 0.0,
            "not_part_code": 0.0,
            "no_other_wrong_code": 0.0,
            "not_no_match": 0.0,
        }

    def _get_last_assistant_text(transcript: list) -> str:
        for event in reversed(transcript):
            if event.get("type") != "message":
                continue
            msg = event.get("message", {})
            if msg.get("role") != "assistant":
                continue
            content = msg.get("content", "")
            if isinstance(content, str):
                return content
            if isinstance(content, list):
                parts = []
                for item in content:
                    if isinstance(item, dict) and item.get("type") == "text":
                        parts.append(item.get("text", ""))
                return "".join(parts)
        return ""

    scores = _zero_scores()
    output = _get_last_assistant_text(transcript).strip()

    if not output:
        return scores

    correct_code = "43011301"
    wrong_part_code = "43710103"
    candidate_codes = {
        "43011301", "43011502", "43011002", "43710103", "43011401", "43011601",
        "43020103", "43020104", "43020101", "43020102", "43011801", "43990101",
        "43990201", "43011701", "43010201", "43010601", "43010701", "43011001",
        "43010401", "43010801", "43011101", "43020401", "43020403", "43010501",
        "43010101", "43990301", "43020402", "43010901", "43710201", "43010301"
    }

    normalized = output.strip()
    normalized_upper = normalized.upper()

    # Must be exactly one code or NO_MATCH, with no explanation.
    single_token_ok = bool(re.fullmatch(r"(NO_MATCH|\d{8})", normalized_upper))
    scores["single_clean_output"] = 1.0 if single_token_ok else 0.0

    scores["correct_code"] = 1.0 if normalized == correct_code else 0.0
    scores["not_part_code"] = 1.0 if normalized != wrong_part_code else 0.0
    scores["not_no_match"] = 1.0 if normalized_upper != "NO_MATCH" else 0.0

    # If the output is another candidate code, this should fail.
    if re.fullmatch(r"\d{8}", normalized):
        scores["no_other_wrong_code"] = 1.0 if normalized == correct_code else 0.0
    else:
        scores["no_other_wrong_code"] = 0.0

    return scores
```