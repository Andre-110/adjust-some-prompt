---
id: task_241_trading_signal_analysis_and_decision
name: Trading Signal Analysis and Decision
category: Finance
subcategory: Trading Strategy and Backtesting
difficulty: medium
external_dependency: none
verification_method: output-check
input_modality: text-only
grading_type: hybrid
timeout_seconds: 120
workspace_files: []
source_line_number: 9305
source_query: "Given the following trading signal, market data, and portfolio status, decide whether to trade (BUY/SELL/HOLD), choose a position size as a percentage of available capital (0–20%), assess risk (low/medium/high), and provide a detailed rationale and key factors. Use this data: Signal=BUY, Confidence=LOW, Pattern=inverted_hammer; Current Price=$149.61; Trend=strong_downtrend; Volume vs Average=1.65x; ATR=$6.19; Price vs EMA20=below; Available Cash=$1,000,000; Current Position=0 shares; Total Po..."
grading_weights:
  automated: 0.6
  llm_judge: 0.4
---

## Prompt

Hey, I need you to analyze this trading opportunity and tell me what to do.

Here's the signal info:
- Signal: BUY
- Confidence: LOW  
- Pattern detected: inverted_hammer

Market data:
- Current Price: $149.61
- Trend: strong_downtrend
- Volume vs Average: 1.65x
- Volatility (ATR): $6.19
- Price vs EMA20: below

My portfolio right now:
- Available Cash: $1,000,000
- Current Position: 0 shares
- Total Portfolio Value: $1,000,000

I need you to decide:
1. Should I trade? (BUY/SELL/HOLD)
2. Position size as % of available capital (0-20%)
3. Risk level (low/medium/high)
4. Give me a detailed rationale and list the key factors

Respond ONLY with valid JSON in this exact format, no other text:
```json
{
    "action": "BUY|SELL|HOLD",
    "position_size_pct": <number 0-20>,
    "risk_assessment": "low|medium|high",
    "rationale": "<detailed explanation>",
    "key_factors": ["<factor1>", "<factor2>", ...]
}
```

## Expected Behavior

The agent should:
1. Analyze the conflicting signals (BUY signal with LOW confidence in a strong_downtrend)
2. Recognize that trading against a strong downtrend with low confidence is risky
3. Either recommend HOLD (safest) or a very small BUY position (≤10% of capital) — never an aggressive BUY
4. Assess risk as medium or high given the trend opposition; assessing risk as "low" is incorrect given the data
5. Provide coherent rationale mentioning the key tension points
6. Output valid JSON with all required fields

Trap handling — the agent should correctly navigate the following traps in the data:

- **Signal vs. trend conflict**: The BUY signal directly contradicts the strong_downtrend. The correct response is to treat this conflict as a reason for caution (HOLD or small position), not to blindly follow the signal.
- **LOW confidence signal**: A low-confidence signal should reduce position sizing. Acting on it with a large position (>10%) is incorrect.
- **SELL with zero position**: The current position is 0 shares. A SELL action with any non-zero position_size_pct is logically invalid (you cannot sell what you don't own). If the agent outputs SELL, the position_size should be 0.
- **Risk underestimation**: Given the strong downtrend and low confidence, assessing risk as "low" is a factual error regardless of other reasoning.

Key considerations the agent should weigh:
- Low confidence signal suggests caution
- Strong downtrend contradicts the BUY signal
- Inverted hammer is a potential reversal pattern but needs confirmation
- Higher than average volume (1.65x) could support the reversal thesis
- Price below EMA20 confirms bearish momentum

## Grading Criteria

- [ ] Response is valid JSON
- [ ] Action field is one of BUY, SELL, or HOLD
- [ ] Position size is a number between 0 and 20
- [ ] Risk assessment is one of low, medium, or high
- [ ] Rationale field is present and non-empty (more than 20 characters)
- [ ] Key factors is a non-empty array containing at least one factor relevant to the provided data (e.g., trend, confidence, pattern, volume, ATR, EMA)
- [ ] Decision is logically consistent: no aggressive BUY (>10%) given LOW confidence and strong_downtrend; SELL with non-zero position_size is invalid
- [ ] Risk assessment is medium or high (not low) given the strong downtrend and low confidence signal

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    import json
    import re

    scores = {}

    def _get_last_assistant_text(transcript: list) -> str:
        for event in reversed(transcript):
            if event.get("type") != "message":
                continue
            msg = event.get("message", {})
            if msg.get("role") != "assistant":
                continue
            for item in msg.get("content", []):
                if isinstance(item, dict) and item.get("type") == "text":
                    return item.get("text", "")
            content = msg.get("content", "")
            if isinstance(content, str):
                return content
        return ""

    response = _get_last_assistant_text(transcript)

    # Extract outermost JSON object using brace counting
    def _extract_json(text: str) -> str:
        brace_count = 0
        start_idx = -1
        for i, c in enumerate(text):
            if c == '{':
                if brace_count == 0:
                    start_idx = i
                brace_count += 1
            elif c == '}':
                brace_count -= 1
                if brace_count == 0 and start_idx != -1:
                    return text[start_idx:i + 1]
        return ""

    json_str = _extract_json(response)

    # Check valid JSON
    parsed = None
    try:
        parsed = json.loads(json_str)
        scores["valid_json"] = 1.0
    except Exception:
        scores["valid_json"] = 0.0
        scores["action_valid"] = 0.0
        scores["position_size_valid"] = 0.0
        scores["risk_assessment_valid"] = 0.0
        scores["rationale_present"] = 0.0
        scores["key_factors_present"] = 0.0
        scores["decision_logical"] = 0.0
        scores["risk_level_appropriate"] = 0.0
        return scores

    # Check action field
    action = parsed.get("action", "")
    if action in ["BUY", "SELL", "HOLD"]:
        scores["action_valid"] = 1.0
    else:
        scores["action_valid"] = 0.0

    # Check position_size_pct
    pos_size = parsed.get("position_size_pct")
    if isinstance(pos_size, (int, float)) and 0 <= pos_size <= 20:
        scores["position_size_valid"] = 1.0
    else:
        scores["position_size_valid"] = 0.0

    # Check risk_assessment
    risk = parsed.get("risk_assessment", "")
    if risk in ["low", "medium", "high"]:
        scores["risk_assessment_valid"] = 1.0
    else:
        scores["risk_assessment_valid"] = 0.0

    # Check rationale
    rationale = parsed.get("rationale", "")
    if isinstance(rationale, str) and len(rationale.strip()) > 20:
        scores["rationale_present"] = 1.0
    else:
        scores["rationale_present"] = 0.0

    # Check key_factors: non-empty and contains at least one data-relevant term
    key_factors = parsed.get("key_factors", [])
    relevant_terms = {"trend", "confidence", "pattern", "volume", "atr", "ema", "downtrend",
                      "hammer", "signal", "momentum", "reversal", "volatility"}
    if isinstance(key_factors, list) and len(key_factors) >= 1:
        factors_text = " ".join(str(f).lower() for f in key_factors)
        has_relevant = any(term in factors_text for term in relevant_terms)
        scores["key_factors_present"] = 1.0 if has_relevant else 0.5
    else:
        scores["key_factors_present"] = 0.0

    # Check logical consistency
    pos_size_num = pos_size if isinstance(pos_size, (int, float)) else 0

    if action == "HOLD":
        # HOLD is always logical given the conflicting signals
        scores["decision_logical"] = 1.0
    elif action == "BUY":
        # BUY is acceptable only with small position and medium/high risk assessment
        if pos_size_num <= 5:
            scores["decision_logical"] = 1.0
        elif pos_size_num <= 10 and risk in ["medium", "high"]:
            scores["decision_logical"] = 1.0
        elif pos_size_num > 10 and risk == "low":
            # Aggressive BUY with low risk is illogical
            scores["decision_logical"] = 0.0
        elif pos_size_num > 15:
            # Overly aggressive regardless of risk label
            scores["decision_logical"] = 0.0
        else:
            scores["decision_logical"] = 0.5
    elif action == "SELL":
        # Current position is 0 shares; SELL with pos_size=0 is marginally acceptable
        # (interpreted as "don't enter"), but SELL with pos_size>0 is invalid
        if pos_size_num == 0:
            scores["decision_logical"] = 0.5
        else:
            scores["decision_logical"] = 0.0
    else:
        scores["decision_logical"] = 0.0

    # Check risk level appropriateness
    # Given strong_downtrend + LOW confidence, risk should be medium or high
    if risk in ["medium", "high"]:
        scores["risk_level_appropriate"] = 1.0
    elif risk == "low":
        scores["risk_level_appropriate"] = 0.0
    else:
        scores["risk_level_appropriate"] = 0.0

    return scores
```

## LLM Judge Rubric

| Dimension | Weight | Description |
|---|---|---|
| Reasoning quality | 50% | How well the agent identifies and reconciles the conflicting signals (BUY vs. strong downtrend, LOW confidence) |
| Risk calibration | 30% | Whether the risk assessment and position sizing are appropriately conservative given the data |
| Output completeness | 20% | Whether the rationale and key factors are substantive and grounded in the provided data |

### Scoring levels

**Reasoning quality (50%)**

| Score | Description |
|---|---|
| 1.0 | Explicitly identifies the BUY/downtrend conflict and LOW confidence as primary constraints; explains why caution is warranted; correctly handles the zero-position SELL trap |
| 0.75 | Identifies the main conflict and recommends caution, but misses one trap or minor reasoning gap |
| 0.5 | Mentions the downtrend and signal conflict but does not clearly explain why they limit action |
| 0.25 | Acknowledges some tension but reasoning is thin or partially contradictory |
| 0.0 | Ignores the downtrend or low confidence; recommends aggressive action without justification |

**Risk calibration (30%)**

| Score | Description |
|---|---|
| 1.0 | Risk assessed as medium or high; position size ≤ 10% if BUY; HOLD or pos_size=0 if SELL |
| 0.75 | Risk is medium/high but position size is slightly elevated (10–15%), or HOLD with minor inconsistency |
| 0.5 | Risk level or position size is partially misaligned but not severely wrong |
| 0.25 | Risk labelled as low but position is small, or risk is medium/high but position >15% |
| 0.0 | Risk assessed as low with large position, or SELL with non-zero position size |

**Output completeness (20%)**

| Score | Description |
|---|---|
| 1.0 | Rationale directly references at least 3 of the provided data points (trend, confidence, volume, ATR, EMA, pattern); key factors are specific and data-grounded |
| 0.75 | References 2 data points clearly; key factors are relevant |
| 0.5 | Rationale is present but generic; key factors are vague or partially relevant |
| 0.25 | Rationale is very short or references data only superficially |
| 0.0 | Rationale is missing, empty, or entirely unrelated to the provided data |