| 序号 | 修改项 | 修改原因 |
|---|---|---|
| 1 | 补充 Expected Behavior 中的陷阱说明 | 原文只列出了"Key considerations"，未说明模型遇到陷阱（信号冲突、0持仓SELL）时应如何正确处理 |
| 2 | Grading Criteria 第 7 条细化，增加第 8 条 | 原第7条对"逻辑一致"的描述过于笼统；增加 key_factors 至少包含与题目数据相关因素的检查 |
| 3 | 修复 grade() 中 JSON 提取逻辑的 bug | `json_match` 变量名复用导致 re.Match 对象与 str 混用，可能引发 AttributeError；重构为统一清晰的提取逻辑 |
| 4 | 修复 grade() 中 SELL 逻辑的得分规则 | SELL + pos_size=0 得 0.5 分语义合理，但 SELL + pos_size>0 直接得 0.0 过于严格，应部分得分 |
| 5 | 增加 LLM Judge Rubric 部分 | 原文件完全缺失该部分；补充 3 个维度、权重合计 100%、各等级描述 |
| 6 | 补充 frontmatter grading_weights 字段 | 原文件缺少 grading_weights，需说明 automated 与 llm_judge 的权重比例 |
