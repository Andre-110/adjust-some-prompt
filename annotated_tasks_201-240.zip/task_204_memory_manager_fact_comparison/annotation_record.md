| 序号 | 修改项 | 修改原因 |
|---|---|---|
| 1 | 改写 `Prompt` 中的操作说明 | 保留业务规则，但降低对具体答案的直接引导，使题目更像真实 memory 管理请求 |
| 2 | 删除原 Prompt 中对 conference 事实的强定向提示 | 原文直接提示该事实必须按 UPDATE 处理，存在较明显答案泄露 |
| 3 | 补充 `Expected Behavior` 的完整性 | 增加对新增、冗余、更新三类处理路径的完整说明 |
| 4 | 增加 `Ground Truth` | 原版本虽列了关键决策，但不够结构化；补充后更便于核验 |
| 5 | 增加 `Trap Handling` | 明确列出“计划变现实”“强化已有事实”“具体新事实是否值得存储”等陷阱及正确处理方式 |
| 6 | 将“Caroline loves reading and finds books motivating”设为可接受弹性项 | 该事实有合理分歧，允许 `ADD` 或 `NONE` 更符合高质量标注要求 |
| 7 | 重写 `Grading Criteria` | 提升独立可验证性，并覆盖输出结构、关键更新、新增事实、冗余控制等核心能力 |
| 8 | 重写 `grade()` 的零分初始化逻辑 | 满足“主输出文件不存在时全 0”要求 |
| 9 | 增加 `valid_operation_objects` 检查 | 原评分未验证操作对象是否符合 schema |
| 10 | 增强操作对象合法性校验 | 检查 `event` 合法值、`id` 必填、`text` 在 ADD/UPDATE 时必填、DELETE 时应省略 |
| 11 | 增加 `purple_shoes_added` 检查 | 原 Grading Criteria/grade() 未覆盖这一条 Expected Behavior 中的重要新增事实 |
| 12 | 强化 conference 更新判断 | 原实现过于宽松，现在同时要求 UPDATE、正确 id、且文本体现 attended + 日期 |
| 13 | 扩展冗余新增检测 | 原版只检查 conference 重复新增，未覆盖其他明显应跳过的 reinforcement facts |
| 14 | 使 score key 更贴近 Grading Criteria | 提高评分项与标准的一致性和可解释性 |