---
id: task_204_memory_manager_fact_comparison
name: Memory Manager Fact Comparison
category: Knowledge Management
subcategory: Memory and Context Management
difficulty: medium
external_dependency: none
verification_method: unit-test
input_modality: text-only
grading_type: automated
timeout_seconds: 120
workspace_files: []
source_line_number: 3493
source_query: "Compare the provided \"New retrieved facts\" against the \"Current memory\" list and decide which memory operations are needed for each fact: ADD (new info; create a new short id), UPDATE (updates/corrects existing; use existing id and updated text), DELETE (contradicts/invalidates existing; use existing id), or NONE (already present/irrelevant; omit). Return ONLY a JSON array of action objects with fields: \"event\" (ADD/UPDATE/DELETE), \"id\" (existing for UPDATE/DELETE; new for ADD), and ..."
---

## Prompt

I need help maintaining a memory store.

Compare the **new retrieved facts** against the **current memory** and decide which memory operations are needed for each fact:

- `ADD`: new information worth storing; create a new short id
- `UPDATE`: an existing memory should be updated/corrected; reuse the existing id and provide updated text
- `DELETE`: an existing memory is contradicted/invalidated; reuse the existing id
- `NONE`: already covered, redundant, or not worth storing; omit it from the output

Current memory:

```json
[
  {"id": "caroline_lgbtq_support", "text": "Caroline attended an LGBTQ support group on 7 May, 2023."},
  {"id": "caroline_conference_plan", "text": "Caroline plans to attend a transgender conference in July 2023."},
  {"id": "caroline_pride_parade", "text": "Caroline attended an LGBTQ+ pride parade on the week of June 26, 2023."},
  {"id": "caroline_counseling_workshop", "text": "Caroline attended an LGBTQ+ counseling workshop on Friday, June 23, 2023."},
  {"id": "caroline_advocacy", "text": "Caroline is an advocate for the LGBTQ community and is interested in advocacy within the transgender community."},
  {"id": "caroline_community_belonging", "text": "Caroline feels a sense of belonging and happiness from the LGBTQ+ community."},
  {"id": "caroline_identity", "text": "Caroline identifies as transgender."},
  {"id": "caroline_career_goal", "text": "Caroline plans to work with trans people to help them accept themselves and support their mental health."},
  {"id": "caroline_agency_choice", "text": "Caroline chose an adoption agency that helps LGBTQ+ folks due to their inclusivity and support."},
  {"id": "caroline_career_interest", "text": "Caroline is exploring a career in counseling or mental health work to help people and make a positive impact."},
  {"id": "caroline_adoption_research", "text": "Caroline is researching adoption agencies."},
  {"id": "caroline_education_plan", "text": "Caroline plans to continue her education."},
  {"id": "caroline_career_motivation", "text": "Caroline's own journey and received support motivated her to pursue counseling."},
  {"id": "caroline_feels_accepted", "text": "The support group made Caroline feel accepted and gave her courage to embrace herself."},
  {"id": "caroline_past_breakup", "text": "Caroline experienced a tough breakup in the past."},
  {"id": "caroline_future_library", "text": "Caroline is creating a library for her future children and looks forward to reading to them."},
  {"id": "caroline_book_collection", "text": "Caroline collects kids' books including classics, stories from different cultures, and educational books."},
  {"id": "caroline_motivation_source", "text": "Caroline's friends, family, and mentors are her primary source of motivation."},
  {"id": "caroline_inspired_by_stories", "text": "Caroline found the transgender stories at the support group inspiring."},
  {"id": "caroline_single_parent_adoption", "text": "Caroline is planning to adopt as a single parent."},
  {"id": "caroline_adoption_outlook", "text": "Caroline feels hopeful and optimistic about the adoption process."},
  {"id": "caroline_transition_status", "text": "Caroline is undergoing a transition with love, guidance, and acceptance from friends and family."},
  {"id": "caroline_safe_space_passion", "text": "Caroline is passionate about creating a safe, inviting place for people to grow."},
  {"id": "melanie_has_kids", "text": "Melanie has a husband and kids."},
  {"id": "melanie_cherishes_family", "text": "Family time matters to Melanie."},
  {"id": "melanie_family_motivation", "text": "Melanie's family motivates her."},
  {"id": "melanie_beach_camping", "text": "Melanie's family enjoys camping at the beach."},
  {"id": "melanie_swimming_plan", "text": "Melanie plans to go swimming with her kids."},
  {"id": "melanie_childhood_favorite_book", "text": "Melanie loved reading 'Charlotte's Web' as a child."},
  {"id": "melanie_daily_routine", "text": "Melanie carves out me-time each day for running, reading, or playing the violin."},
  {"id": "melanie_charity_race", "text": "Melanie ran a charity race for mental health on 2023-05-20."
]
```

New retrieved facts:

```json
[
  "Caroline attended an LGBTQ conference on 10 July 2023",
  "Caroline feels thankful for the LGBTQ community and values fighting for trans rights",
  "Caroline is looking into counseling and mental health jobs",
  "Caroline struggled with mental health in the past and found support helpful",
  "Caroline loves reading and finds books motivating",
  "Caroline's favorite book is \"Becoming Nicole\" by Amy Ellis Nutt",
  "Caroline believes pets bring joy",
  "Melanie has a dog named Luna",
  "Melanie has a cat named Oliver",
  "Melanie recently bought new purple running shoes",
  "Melanie runs to de-stress and clear her mind",
  "Melanie prioritizes mental health"
]
```

Return **only** a JSON array of operation objects with this schema:

* `event`: `ADD`, `UPDATE`, or `DELETE`
* `id`: existing id for `UPDATE`/`DELETE`; new short id for `ADD`
* `text`: required for `ADD` and `UPDATE`; omit for `DELETE`

If no memory changes are needed, return `[]`.

Save the result to `memory_operations.json`.

## Expected Behavior

The agent should:

1. Compare each new fact against current memory and omit facts that are already covered, redundant, or too low-value to store.
2. Recognize that an existing future plan becoming a completed event should be handled as an `UPDATE`, not as a duplicate `ADD`.
3. Add genuinely new and useful facts that are not already represented in memory.
4. Avoid storing near-duplicates that only restate existing themes with little new information.
5. Output a valid JSON array of operation objects and save it to `memory_operations.json`.

### Ground Truth

Expected decisions:

* `UPDATE` `caroline_conference_plan` to reflect that Caroline attended the conference on 10 July 2023
* `NONE` for:

  * "Caroline feels thankful for the LGBTQ community and values fighting for trans rights"
  * "Caroline is looking into counseling and mental health jobs"
  * "Melanie runs to de-stress and clear her mind"
  * "Melanie prioritizes mental health"
* `ADD` for:

  * Caroline struggled with mental health in the past and found support helpful
  * Caroline's favorite book is "Becoming Nicole" by Amy Ellis Nutt
  * Caroline believes pets bring joy
  * Melanie has a dog named Luna
  * Melanie has a cat named Oliver
  * Melanie recently bought new purple running shoes
* Accept either `ADD` or `NONE` for:

  * "Caroline loves reading and finds books motivating"

A strong canonical output will therefore include:

* one `UPDATE` for `caroline_conference_plan`
* `ADD`s for favorite book, mental health struggle/support, pets belief, Luna, Oliver, purple running shoes
* no duplicate `ADD` for the conference fact

### Trap Handling

This task contains several traps:

1. **Plan vs completed event**
   If a fact changes an existing future plan into a completed event, the correct action is `UPDATE`, not `ADD`.

2. **Reinforcement vs new memory**
   Facts that merely reinforce existing memories without meaningful new detail should be omitted (`NONE`).

3. **Specificity matters**
   A more specific new fact (for example a named pet or a favorite book title) is usually worth storing even if it fits an existing theme.

4. **Low-value detail judgment**
   Some lifestyle details may be new but borderline in value. The grader should allow reasonable judgment where appropriate.

## Grading Criteria

* [ ] File `memory_operations.json` exists and contains valid JSON
* [ ] Output is a JSON array of valid operation objects
* [ ] Conference fact is handled as an `UPDATE`, not a duplicate `ADD`
* [ ] `caroline_conference_plan` is the id used for the conference `UPDATE`
* [ ] Caroline's favorite book is added
* [ ] Melanie's dog Luna is added
* [ ] Melanie's cat Oliver is added
* [ ] Purple running shoes fact is added
* [ ] Redundant reinforcement facts are not incorrectly added
* [ ] No malformed operations are included

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    from pathlib import Path
    import json

    def _zero_scores():
        return {
            "file_exists": 0.0,
            "valid_json": 0.0,
            "valid_operation_objects": 0.0,
            "conference_updated": 0.0,
            "correct_update_id": 0.0,
            "favorite_book_added": 0.0,
            "dog_luna_added": 0.0,
            "cat_oliver_added": 0.0,
            "purple_shoes_added": 0.0,
            "no_redundant_adds": 0.0,
        }

    scores = _zero_scores()
    ws = Path(workspace_path)
    ops_file = ws / "memory_operations.json"

    if not ops_file.exists():
        return scores

    scores["file_exists"] = 1.0

    try:
        content = ops_file.read_text(encoding="utf-8")
        ops = json.loads(content)
    except Exception:
        return scores

    if not isinstance(ops, list):
        return scores

    scores["valid_json"] = 1.0

    valid_events = {"ADD", "UPDATE", "DELETE"}
    valid_obj_count = 0

    conference_updated = False
    correct_update_id = False
    favorite_book_added = False
    dog_added = False
    cat_added = False
    purple_shoes_added = False
    redundant_add_detected = False

    redundant_patterns = [
        "thankful for the lgbtq community",
        "values fighting for trans rights",
        "looking into counseling and mental health jobs",
        "runs to de-stress and clear her mind",
        "prioritizes mental health",
    ]

    for op in ops:
        if not isinstance(op, dict):
            continue

        event = str(op.get("event", "")).strip().upper()
        op_id = str(op.get("id", "")).strip()
        text_present = "text" in op
        text = str(op.get("text", "")).strip().lower()

        obj_valid = False
        if event in valid_events and op_id:
            if event in {"ADD", "UPDATE"} and text_present and str(op.get("text", "")).strip():
                obj_valid = True
            elif event == "DELETE" and not text_present:
                obj_valid = True

        if obj_valid:
            valid_obj_count += 1

        if event == "UPDATE" and op_id == "caroline_conference_plan":
            if "attended" in text and ("10 july 2023" in text or "july 10 2023" in text or "2023-07-10" in text):
                conference_updated = True
                correct_update_id = True

        if event == "ADD":
            if "conference" in text and "caroline" in text:
                redundant_add_detected = True

            if "becoming nicole" in text or ('favorite book' in text and 'amy ellis nutt' in text):
                favorite_book_added = True

            if "luna" in text and "dog" in text:
                dog_added = True

            if "oliver" in text and "cat" in text:
                cat_added = True

            if "purple" in text and "running shoes" in text:
                purple_shoes_added = True

            if any(pat in text for pat in redundant_patterns):
                redundant_add_detected = True

    if len(ops) == 0:
        scores["valid_operation_objects"] = 1.0
    else:
        scores["valid_operation_objects"] = valid_obj_count / len(ops)

    scores["conference_updated"] = 1.0 if conference_updated else 0.0
    scores["correct_update_id"] = 1.0 if correct_update_id else 0.0
    scores["favorite_book_added"] = 1.0 if favorite_book_added else 0.0
    scores["dog_luna_added"] = 1.0 if dog_added else 0.0
    scores["cat_oliver_added"] = 1.0 if cat_added else 0.0
    scores["purple_shoes_added"] = 1.0 if purple_shoes_added else 0.0
    scores["no_redundant_adds"] = 0.0 if redundant_add_detected else 1.0

    return scores
```

## LLM Judge Rubric

Not applicable. This task uses automated grading only.