| 序号 | 修改项 | 修改原因 |
|---|---|---|
| 1 | 重写 Prompt 的结构要求 | 原 Prompt 基本清晰，但对“样例数据只是格式参考”“占位 API 函数”“双文件输出”约束不够明确，容易引发不稳定输出 |
| 2 | 明确样例 candle 数据只用于格式参考 | 避免模型将样例行硬编码为唯一输入来源，影响脚本泛化性 |
| 3 | 明确必须使用占位交易所函数 | 原 Prompt 说 ready to connect to an exchange API，但没有明确需要哪些占位函数，导致可执行性和可判定性不足 |
| 4 | 扩充 Expected Behavior | 原版缺少完整解题路径，尤其是占位 API、配置参数、cron 替换动作等内容未充分落地 |
| 5 | 在 Expected Behavior 中补充 traps | 这题有明显陷阱：只做多、不做空；RSI 阈值方向写反；ATR 参数错；只给新 cron 行不说明怎么替换旧任务；伪造真实交易能力 |
| 6 | 增加 Ground Truth constraints | 满足“答案明确、可验证”的要求，便于自动评分与人工评审对齐 |
| 7 | 重写 Grading Criteria | 原标准覆盖不足，没有单独检查配置参数、占位 API、cron 替换动作等关键点 |
| 8 | 将“short logic”扩展为“long and short logic” | 原题任务本身包含双向逻辑，而原自动检查只突出 short，不足以覆盖完整核心能力 |
| 9 | 增加“requested strategy configuration values”评分项 | 原版对 5/20 均线、RSI 14、ATR 14、15m、8 USDT、2 USDT、3x 的完整落地检查不充分 |
| 10 | 增加“placeholder exchange API functions”评分项 | 原 Prompt 有要求，但原评分没有单独覆盖 |
| 11 | 强化 cron 文档要求 | 原标准只检查存在与 15 分钟间隔，没有充分强调“替换旧 cron”的动作说明 |
| 12 | 重写 automated checks 的 score key | 让 score key 与 Grading Criteria 更接近一一对应，满足 Key 对齐要求 |
| 13 | 为文件读取增加 `encoding="utf-8"` | 提高稳健性 |
| 14 | 改进 long/short 逻辑检查 | 原版 `has_short_logic` 只靠搜词，容易误判；新版分别检查 long 和 short 痕迹，并支持部分得分 |
| 15 | 改进 RSI 检查 | 原版只粗略检查 70 和 30 出现；新版区分 long `< 70` 和 short `> 30` 两个方向约束 |
| 16 | 改进 ATR 风控检查 | 原版对 ATR 检查较粗；新版分别检查 ATR(14)、止损 1.5x、止盈 3x，并按覆盖率给分 |
| 17 | 改进 position check 检查 | 原版实现逻辑较脆；新版直接检查常见仓位判定语句或函数名，更符合该题风格 |
| 18 | 扩展参数配置检查 | 原版只粗看资金、保证金、杠杆；新版把 MA、RSI、ATR、timeframe、capital、margin、leverage 都纳入检查 |
| 19 | 增加占位 API 函数检查 | 新版检查 `fetch_candles`、`get_current_position`、`place_long`、`place_short`、`close_position` 等占位函数是否存在 |
| 20 | 强化 false claims 检查 | 补充 `always profitable` 等典型不实承诺，防止脚本出现夸大表述 |
| 21 | 改进 cron 替换说明检查 | 原版只要出现少量 cron 关键词就可能通过；新版要求更多“编辑/删除/替换旧任务”的相关痕迹，并支持部分得分 |