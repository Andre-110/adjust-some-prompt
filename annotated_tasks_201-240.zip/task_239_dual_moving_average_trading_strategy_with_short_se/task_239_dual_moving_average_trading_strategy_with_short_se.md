---
id: task_239_dual_moving_average_trading_strategy_with_short_se
name: Dual Moving Average Trading Strategy with Short Selling
category: Finance
subcategory: Trading Strategy and Backtesting
difficulty: hard
external_dependency: none
verification_method: rubric
input_modality: text-only
grading_type: hybrid
timeout_seconds: 300
grading_weights:
  automated: 0.4
  llm_judge: 0.6
workspace_files: []
source_line_number: 3419
source_query: "优化一个双均线交易策略以适应普跌行情，并生成完整 Python 脚本与旧定时任务替换说明。要求： 1) 增加做空：快线下穿慢线时在无持仓情况下开空 2) RSI 过滤：开多需 RSI < 70；开空需 RSI > 30 3) 止损=ATR(14)*1.5；止盈=ATR(14)*3 4) 每 15 分钟运行一次；总资金 8 USDT；每笔保证金/开仓额 2 USDT；3 倍杠杆 5) 说明如何替换旧的 cron/定时任务以运行新脚本"
---

## Prompt

Hey, I need help upgrading my dual moving average trading strategy so it can handle bearish conditions better.

Please do the following:
1. Add short selling:
   - when the fast moving average crosses below the slow moving average, open a short position
   - only open a new trade if there is no existing position
2. Add RSI filtering:
   - only go long if RSI < 70
   - only go short if RSI > 30
3. Use ATR-based exits:
   - stop loss = ATR(14) × 1.5
   - take profit = ATR(14) × 3
4. Use these strategy settings:
   - fast MA = 5
   - slow MA = 20
   - RSI period = 14
   - ATR period = 14
   - timeframe = 15 minutes
   - total capital = 8 USDT
   - per-trade margin = 2 USDT
   - leverage = 3x
5. Write a complete Python script to `dual_ma_strategy.py`
6. Write instructions to replace the old cron job with the new one in `cron_setup.md`

The Python script should be structured so it is ready to connect to an exchange API later, but for now use placeholder functions for exchange-specific actions such as:
- fetching candles
- getting current position
- placing long orders
- placing short orders
- closing positions

You may use the sample candle format below as a reference for expected columns, but do not rely on the sample rows being the only input the script can handle.

```csv
timestamp,open,high,low,close,volume
2026-02-23 08:00,1.2450,1.2485,1.2430,1.2470,15000
2026-02-23 08:15,1.2470,1.2490,1.2445,1.2455,12500
2026-02-23 08:30,1.2455,1.2460,1.2410,1.2420,18000
2026-02-23 08:45,1.2420,1.2435,1.2395,1.2405,22000
2026-02-23 09:00,1.2405,1.2420,1.2380,1.2390,25000
2026-02-23 09:15,1.2390,1.2400,1.2360,1.2375,28000
2026-02-23 09:30,1.2375,1.2395,1.2355,1.2365,20000
2026-02-23 09:45,1.2365,1.2380,1.2340,1.2350,24000
2026-02-23 10:00,1.2350,1.2370,1.2335,1.2360,19000
2026-02-23 10:15,1.2360,1.2385,1.2350,1.2380,16000
2026-02-23 10:30,1.2380,1.2410,1.2375,1.2405,21000
2026-02-23 10:45,1.2405,1.2425,1.2390,1.2395,17000
2026-02-23 11:00,1.2395,1.2400,1.2365,1.2370,23000
2026-02-23 11:15,1.2370,1.2375,1.2340,1.2345,26000
2026-02-23 11:30,1.2345,1.2360,1.2320,1.2335,30000
2026-02-23 11:45,1.2335,1.2355,1.2315,1.2340,22000
2026-02-23 12:00,1.2340,1.2365,1.2330,1.2355,18000
2026-02-23 12:15,1.2355,1.2380,1.2350,1.2375,15000
2026-02-23 12:30,1.2375,1.2390,1.2360,1.2365,14000
2026-02-23 12:45,1.2365,1.2370,1.2335,1.2340,20000
```

## Expected Behavior

The agent should:

1. Create `dual_ma_strategy.py` as a valid Python script.
2. Implement a dual moving average crossover strategy using:

   * fast MA = 5
   * slow MA = 20
3. Implement both long and short entry logic:

   * long entry on fast MA crossing above slow MA
   * short entry on fast MA crossing below slow MA
4. Prevent opening a new position if an existing position is already open.
5. Apply RSI filtering:

   * long entries require RSI(14) < 70
   * short entries require RSI(14) > 30
6. Apply ATR-based exits:

   * ATR period = 14
   * stop loss = ATR × 1.5
   * take profit = ATR × 3
7. Include the execution/risk settings in the script:

   * timeframe = 15m
   * total capital = 8 USDT
   * per-trade margin = 2 USDT
   * leverage = 3
8. Structure the script with placeholder exchange API functions so the strategy can later be connected to a real exchange.
9. Create `cron_setup.md` with instructions for replacing the old scheduled job with a new one that runs every 15 minutes.
10. The cron instructions should explicitly describe:

* how to identify or edit the old cron entry
* how to remove or replace it
* the new 15-minute cron expression
* how to verify the new job is installed

Traps the agent should handle correctly:

* The task requires two output files, not just the Python script.
* The strategy must support short entry logic, not only long entry logic.
* RSI thresholds are directional: long uses `< 70`, short uses `> 30`.
* ATR exits must use the requested multipliers and ATR(14), not other defaults.
* The script should be complete and syntactically valid, but exchange integration should remain as placeholders rather than fabricated live credentials or fake execution claims.
* The sample candles are only a format reference; the script should operate on general OHLCV data with the same columns.
* “Replace the old cron job” means the documentation should explain removal or update of the previous task, not only show a new cron line.

Ground truth constraints:

* Output files: `dual_ma_strategy.py` and `cron_setup.md`
* `dual_ma_strategy.py` must be valid Python
* The script must implement MA crossover, RSI filter, ATR exits, position checks, and placeholder exchange API functions
* Strategy parameters must match the requested values: MA(5/20), RSI(14), ATR(14), 15m timeframe, 8 USDT capital, 2 USDT margin, 3x leverage
* `cron_setup.md` must explain replacing the old job and running the new script every 15 minutes

Tested capabilities: trading strategy implementation, technical indicator logic, position management, risk management, Python scripting, operational scheduling documentation.

## Grading Criteria

* [ ] File `dual_ma_strategy.py` exists and is valid Python
* [ ] The script implements long and short MA crossover entry logic
* [ ] The script applies RSI filtering with the correct thresholds
* [ ] The script applies ATR(14)-based stop loss and take profit using 1.5x and 3x multipliers
* [ ] The script checks for an existing position before opening a new one
* [ ] The script includes the requested strategy configuration values (MA 5/20, RSI 14, ATR 14, 15m, 8 USDT, 2 USDT, 3x)
* [ ] The script includes placeholder exchange API functions
* [ ] File `cron_setup.md` exists
* [ ] The cron instructions include a 15-minute schedule
* [ ] The cron instructions explain how to remove, replace, or update the old scheduled task

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    from pathlib import Path
    import ast
    import re

    scores = {
        "script_exists": 0.0,
        "valid_python": 0.0,
        "has_long_and_short_logic": 0.0,
        "has_rsi_filter": 0.0,
        "has_atr_risk_management": 0.0,
        "has_position_check": 0.0,
        "has_requested_config": 0.0,
        "has_placeholder_exchange_functions": 0.0,
        "cron_doc_exists": 0.0,
        "cron_15min_interval": 0.0,
        "cron_replacement_instructions": 0.0,
        "no_false_claims": 0.0,
    }

    ws = Path(workspace_path)
    script_path = ws / "dual_ma_strategy.py"
    cron_path = ws / "cron_setup.md"

    if not script_path.exists():
        return scores

    scores["script_exists"] = 1.0

    try:
        code = script_path.read_text(encoding="utf-8")
        ast.parse(code)
        scores["valid_python"] = 1.0
    except Exception:
        code = ""

    if code:
        code_lower = code.lower()

        # Long and short logic
        long_signals = [
            r"cross.*above",
            r"cross.*up",
            r"golden.*cross",
            r"open_long",
            r"place_long",
            r"buy"
        ]
        short_signals = [
            r"cross.*below",
            r"cross.*down",
            r"death.*cross",
            r"open_short",
            r"place_short",
            r"short"
        ]
        long_hit = any(re.search(p, code_lower) for p in long_signals)
        short_hit = any(re.search(p, code_lower) for p in short_signals)
        scores["has_long_and_short_logic"] = 1.0 if (long_hit and short_hit) else (0.5 if (long_hit or short_hit) else 0.0)

        # RSI filter
        rsi_long = bool(re.search(r"rsi.*<\s*70|<\s*70.*rsi", code_lower))
        rsi_short = bool(re.search(r"rsi.*>\s*30|>\s*30.*rsi", code_lower))
        scores["has_rsi_filter"] = 1.0 if (rsi_long and rsi_short) else (0.5 if (rsi_long or rsi_short) else 0.0)

        # ATR risk management
        has_atr_14 = bool(re.search(r"atr.*14|14.*atr", code_lower))
        has_stop = bool(re.search(r"1\.5.*atr|atr.*1\.5|stop.*loss", code_lower))
        has_take = bool(re.search(r"3(\.0)?\s*\*?\s*atr|atr.*3|take.*profit", code_lower))
        atr_score = sum([has_atr_14, has_stop, has_take]) / 3.0
        scores["has_atr_risk_management"] = atr_score

        # Existing position check
        position_terms = [
            r"get_current_position",
            r"current_position",
            r"position is none",
            r"if not position",
            r"no existing position",
            r"position == 0",
            r"position is None"
        ]
        scores["has_position_check"] = 1.0 if any(re.search(p, code, re.IGNORECASE) for p in position_terms) else 0.0

        # Requested configuration
        config_hits = 0
        config_patterns = [
            r"fast.*=\s*5|fast_ma.*5",
            r"slow.*=\s*20|slow_ma.*20",
            r"rsi.*=\s*14|rsi_period.*14",
            r"atr.*=\s*14|atr_period.*14",
            r"15m|15min|15-minute|timeframe.*15",
            r"8\s*(usdt|usd)|capital.*8|total.*8",
            r"2\s*(usdt|usd)|margin.*2|per.*trade.*2",
            r"3\s*x|leverage.*3|3.*leverage"
        ]
        for p in config_patterns:
            if re.search(p, code_lower):
                config_hits += 1
        scores["has_requested_config"] = config_hits / len(config_patterns)

        # Placeholder exchange functions
        placeholder_funcs = [
            r"def\s+fetch_candles",
            r"def\s+get_current_position",
            r"def\s+place_long",
            r"def\s+place_short",
            r"def\s+close_position"
        ]
        func_hits = sum(1 for p in placeholder_funcs if re.search(p, code))
        scores["has_placeholder_exchange_functions"] = func_hits / len(placeholder_funcs)

        fabrication_patterns = [
            r"guaranteed\s*profit",
            r"100%\s*win",
            r"risk\s*free",
            r"always\s*profitable"
        ]
        has_fabrication = any(re.search(p, code_lower) for p in fabrication_patterns)
        scores["no_false_claims"] = 0.0 if has_fabrication else 1.0

    if cron_path.exists():
        scores["cron_doc_exists"] = 1.0
        cron_text = cron_path.read_text(encoding="utf-8").lower()

        fifteen_min_patterns = [
            r"\*/15",
            r"every\s*15\s*min",
            r"15\s*minute",
            r"0,15,30,45"
        ]
        scores["cron_15min_interval"] = 1.0 if any(re.search(p, cron_text) for p in fifteen_min_patterns) else 0.0

        replace_patterns = [
            r"crontab",
            r"cron\s+-e",
            r"remove",
            r"replace",
            r"update",
            r"delete",
            r"old job",
            r"old cron"
        ]
        replace_hits = sum(1 for p in replace_patterns if re.search(p, cron_text))
        scores["cron_replacement_instructions"] = 1.0 if replace_hits >= 3 else (0.5 if replace_hits >= 1 else 0.0)

    return scores
```

## LLM Judge Rubric

### Criterion 1: Technical Indicator Implementation (Weight: 30%)

Evaluate whether the trading script correctly implements the requested indicators and parameter settings.

**Score 1.0**: Correctly implements MA crossover with fast MA=5 and slow MA=20, RSI(14), and ATR(14), with correct use of each indicator in the trading logic.
**Score 0.75**: Indicators are mostly correct, with only minor parameter or edge-case issues.
**Score 0.5**: Most indicators are present but one important component is incomplete or partially incorrect.
**Score 0.25**: Only a subset of the required indicators is implemented or implementation quality is weak.
**Score 0.0**: Indicator implementation is missing or unusable.

### Criterion 2: Trading Logic Completeness (Weight: 30%)

Evaluate whether the strategy logic fully reflects the requested long/short behavior, filtering, and risk handling.

**Score 1.0**: Fully implements long and short entries, position checks, RSI thresholds, and ATR-based stop loss/take profit with the requested multipliers.
**Score 0.75**: Most logic is correct, with only one minor omission or weakness.
**Score 0.5**: Core entry logic exists, but one or more important constraints are missing.
**Score 0.25**: Only partial strategy behavior is implemented.
**Score 0.0**: No coherent requested strategy logic is present.

### Criterion 3: Code Quality and Integration Readiness (Weight: 20%)

Evaluate whether the script is well structured, maintainable, and ready for later API integration.

**Score 1.0**: Code is well organized, syntactically valid, uses clear functions, includes placeholder exchange API hooks, and is practical to extend.
**Score 0.75**: Good overall structure with only minor maintainability issues.
**Score 0.5**: Functional but somewhat disorganized or missing some integration-readiness details.
**Score 0.25**: Difficult to maintain or only loosely connected to future exchange integration.
**Score 0.0**: Broken or severely incomplete code.

### Criterion 4: Cron Replacement Documentation (Weight: 20%)

Evaluate whether the documentation clearly explains how to switch from the old scheduled task to the new one.

**Score 1.0**: Clearly explains how to inspect/edit cron, remove or replace the old job, add the new 15-minute schedule, and verify that the new task is active.
**Score 0.75**: Good replacement guidance with only one minor missing detail.
**Score 0.5**: Basic scheduling instructions are present but replacement steps are incomplete.
**Score 0.25**: Vague or partially incorrect documentation.
**Score 0.0**: Missing or unusable cron replacement guidance.
