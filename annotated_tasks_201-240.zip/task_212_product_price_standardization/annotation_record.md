| 序号 | 修改项 | 修改原因 |
|---|---|---|
| 1 | 将 `difficulty` 从 `medium` 改为 `easy` | 该题是单样本规格抽取 + 简单标准化计算，难度与 `medium` 不匹配 |
| 2 | 将 Prompt 中英文商品样本改回与原始 `source_query` 一致的中文商品样本 | 原文件 Prompt 与 frontmatter/source_query 不一致，造成题目样本漂移 |
| 3 | 保持任务说明主体为英文，但保留商品内容中的中文 | 参考原文件语言风格：结构字段和评测任务是英文，商品实体数据应与原题一致 |
| 4 | 改写 Prompt，使要求更清晰 | 原 Prompt 虽可理解，但对“只能输出哪些字段”“按哪个字段取规格”“用哪个价格字段计算”不够明确 |
| 5 | 在 Prompt 中增加 “only these fields” 约束 | 防止模型输出额外字段，便于 automated grading |
| 6 | 在 Prompt 中明确不能使用 `price_info.price_unit` 作为包装规格 | 这是本题核心陷阱，需在任务要求中清晰约束 |
| 7 | 在 Prompt 中明确使用 `current_price` 计算 `price_std` | 避免 `original_price` / `current_price` 的歧义 |
| 8 | 补充 Expected Behavior 中的完整 Ground Truth JSON | 原版本只有步骤说明，没有完整明确答案结构，不利于审校与评测 |
| 9 | 在 Expected Behavior 中补充陷阱处理说明 | 按规范，若题目存在陷阱，应说明期望模型如何正确处理 |
| 10 | 重写 Grading Criteria，使条目更独立可验证 | 原条目“valid JSON”和“file exists”耦合较强，“No fabricated fields or incorrect data types”也较泛化 |
| 11 | 将 “No fabricated fields or incorrect data types” 改为 “exactly the required 6 fields” | 这样更可独立判定，也更容易和自动评分逻辑对齐 |
| 12 | 修改 `grade()`，增加统一的空白零分逻辑 | 满足“主输出文件不存在时，所有 score key 返回 0.0”要求 |
| 13 | 修改 `grade()`，使用 `encoding="utf-8"` 读取文件 | 提高稳健性，适配中文内容 |
| 14 | 修改 `grade()`，增加 `to_float()` 与 `norm_str()` | 放宽格式匹配，增强对字符串数字、空格、大小写等合理变体的容忍度 |
| 15 | 修改 `grade()`，将字段集合精确校验为 `schema_exact` | 使评分更准确地区分“字段齐全但有额外字段”与“严格符合 schema” |
| 16 | 使 `score key` 与 Grading Criteria 一一对齐 | 满足 Key 对齐要求 |
| 17 | 补充 `LLM Judge Rubric` 整个章节 | 原文件缺失该部分，不符合任务文件完整性要求 |
| 18 | 在 `grading_weights` 中设置 `automated: 0.8`、`llm_judge: 0.2` | 满足 automated + llm_judge 权重和为 1.0 |
| 19 | 设置 3 个 LLM Judge 维度 | 满足“至少 3 个评分维度”要求 |
| 20 | 为每个维度补充 1.0 / 0.75 / 0.5 / 0.25 / 0.0 的清晰描述 | 满足等级描述清晰要求 |