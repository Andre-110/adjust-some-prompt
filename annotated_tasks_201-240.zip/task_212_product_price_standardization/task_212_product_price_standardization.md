---
id: task_212_product_price_standardization
name: Product Price Standardization
category: Data Analysis
subcategory: Data Processing and Management
difficulty: easy
external_dependency: none
verification_method: unit-test
input_modality: text-only
grading_type: hybrid
grading_weights:
  automated: 0.8
  llm_judge: 0.2
timeout_seconds: 120
workspace_files: []
source_line_number: 4993
source_query: "Standardize the following product price data by extracting quantity/unit, determining unit_std (100g/100ml/pc), computing quantity_std and price_std, and outputting package_std: {'main_name': '海底捞 火锅蘸料 麻辣味 100g', 'original_price': '1.28', 'current_price': '1.28', 'in_discount': False, 'price_info': {'price_unit': '0.180000 kg'}, 'front_ocr': 'a red and yellow plastic tub of 海底捞 麻辣味 火锅蘸料 hot pot dipping sauce', 'version': '麻辣味'}"
---

## Prompt

Please standardize the following product price data and save the result to `standardized_price.json`.

Product data:

```json
{
  "main_name": "Haidilao Hot Pot Dipping Sauce Spicy Flavor 100g",
  "original_price": "1.28",
  "current_price": "1.28",
  "in_discount": false,
  "price_info": {"price_unit": "0.180000 kg"},
  "front_ocr": "a red and yellow plastic tub of Haidilao Spicy Flavor Hot Pot Dipping Sauce",
  "version": "Spicy Flavor"
}
```

Output a JSON object that contains **only** these fields:

* `quantity`: the numeric amount extracted from the product name
* `unit`: the unit extracted from the product name (such as `g`, `kg`, `ml`, `L`, `pc`)
* `unit_std`: the standardized comparison unit

  * use `100g` for solid food sold by weight
  * use `100ml` for liquids
  * use `pc` for items sold by piece
* `quantity_std`: how many standardized units the package contains
* `price_std`: price per standardized unit
* `package_std`: the actual package size string, such as `100g` or `500ml`

Requirements:

1. Extract the package size from `main_name`.
2. Do **not** use `price_info.price_unit` as the package size.
3. Use `current_price` when calculating `price_std`.
4. Save valid JSON to `standardized_price.json`.

## Expected Behavior

The agent should:

1. Extract the package size from `main_name`:

   * `quantity = 100`
   * `unit = "g"`

2. Recognize that `海底捞 火锅蘸料 麻辣味` is a solid food product sold by weight, so:

   * `unit_std = "100g"`

3. Compute the standardized quantity:

   * actual package size = `100g`
   * standard unit = `100g`
   * therefore `quantity_std = 100 / 100 = 1.0`

4. Compute the standardized price using `current_price`:

   * `price_std = 1.28 / 1.0 = 1.28`

5. Set the package string:

   * `package_std = "100g"`

6. Write a valid JSON object to `standardized_price.json` with the following ground truth values:

```json
{
  "quantity": 100,
  "unit": "g",
  "unit_std": "100g",
  "quantity_std": 1.0,
  "price_std": 1.28,
  "package_std": "100g"
}
```

Trap handling:

* `price_info.price_unit = "0.180000 kg"` is pricing-display metadata, not the actual package size.
* The actual package size must come from `main_name`.
* The agent should not invent extra fields or infer a different package size from OCR text.

## Grading Criteria

* [ ] File `standardized_price.json` exists
* [ ] The file content is valid JSON
* [ ] `quantity` is correctly extracted as 100
* [ ] `unit` is correctly extracted as `g`
* [ ] `unit_std` is correctly set to `100g`
* [ ] `quantity_std` is correctly computed as 1.0
* [ ] `price_std` is correctly computed as 1.28
* [ ] `package_std` is correctly set to `100g`
* [ ] The output contains exactly the required 6 fields and no extra fields

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    from pathlib import Path
    import json

    scores = {}
    ws = Path(workspace_path)
    output_file = ws / "standardized_price.json"

    expected_keys = {
        "quantity",
        "unit",
        "unit_std",
        "quantity_std",
        "price_std",
        "package_std",
    }

    all_score_keys = [
        "file_exists",
        "valid_json",
        "quantity_correct",
        "unit_correct",
        "unit_std_correct",
        "quantity_std_correct",
        "price_std_correct",
        "package_std_correct",
        "schema_exact",
    ]

    if not output_file.exists():
        for key in all_score_keys:
            scores[key] = 0.0
        return scores

    scores["file_exists"] = 1.0

    try:
        data = json.loads(output_file.read_text(encoding="utf-8"))
        scores["valid_json"] = 1.0
    except Exception:
        scores["valid_json"] = 0.0
        for key in all_score_keys:
            if key not in scores:
                scores[key] = 0.0
        return scores

    def to_float(val):
        if isinstance(val, (int, float)):
            return float(val)
        if isinstance(val, str):
            s = val.strip().replace(",", "")
            try:
                return float(s)
            except ValueError:
                return None
        return None

    def norm_str(val):
        if not isinstance(val, str):
            return ""
        return val.strip().lower().replace(" ", "")

    qty = to_float(data.get("quantity"))
    scores["quantity_correct"] = 1.0 if qty is not None and abs(qty - 100.0) < 0.01 else 0.0

    unit = norm_str(data.get("unit"))
    scores["unit_correct"] = 1.0 if unit == "g" else 0.0

    unit_std = norm_str(data.get("unit_std"))
    scores["unit_std_correct"] = 1.0 if unit_std == "100g" else 0.0

    qty_std = to_float(data.get("quantity_std"))
    scores["quantity_std_correct"] = 1.0 if qty_std is not None and abs(qty_std - 1.0) < 0.01 else 0.0

    price_std = to_float(data.get("price_std"))
    scores["price_std_correct"] = 1.0 if price_std is not None and abs(price_std - 1.28) < 0.01 else 0.0

    pkg_std = norm_str(data.get("package_std"))
    scores["package_std_correct"] = 1.0 if pkg_std == "100g" else 0.0

    actual_keys = set(data.keys()) if isinstance(data, dict) else set()
    scores["schema_exact"] = 1.0 if actual_keys == expected_keys else 0.0

    for key in all_score_keys:
        if key not in scores:
            scores[key] = 0.0

    return scores
```

## LLM Judge Rubric

### grading_weights

* automated: 0.8
* llm_judge: 0.2

### Dimension 1: Task Completion (Weight: 35%)

* 1.0: Successfully creates `standardized_price.json` with a complete, valid JSON output that fully satisfies the task.
* 0.75: Creates the correct file and mostly correct content, with only minor non-critical issues.
* 0.5: Creates the file, but the output is partially incomplete or contains one major mistake.
* 0.25: Attempts the task, but the output is seriously incomplete or mostly incorrect.
* 0.0: Does not create the required file, or the output is unrelated to the task.

### Dimension 2: Extraction and Calculation Accuracy (Weight: 45%)

* 1.0: Correctly extracts `quantity=100` and `unit="g"`, identifies `unit_std="100g"`, and correctly computes `quantity_std=1.0`, `price_std=1.28`, and `package_std="100g"`.
* 0.75: Most extraction and calculations are correct, with only one minor mistake.
* 0.5: Some key values are correct, but there are notable extraction or calculation errors.
* 0.25: Only a small portion of the extraction/calculation is correct.
* 0.0: The extraction and calculations are fundamentally incorrect.

### Dimension 3: Constraint Following and Output Quality (Weight: 20%)

* 1.0: Follows all constraints exactly, including using `main_name` for package extraction, not using `price_info.price_unit` as package size, and outputting exactly the required six fields.
* 0.75: Follows nearly all constraints, with only minor formatting or non-critical compliance issues.
* 0.5: Partially follows constraints, but includes extra fields or minor reasoning mistakes.
* 0.25: Poor constraint following, with multiple extra or incorrect outputs.
* 0.0: Fails to follow the core constraints or produces invalid output.