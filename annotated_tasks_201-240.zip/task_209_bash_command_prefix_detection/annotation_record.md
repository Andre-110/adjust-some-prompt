| 序号 | 修改项 | 修改原因 |
|---|---|---|
| 1 | 将 Prompt 中命令路径改回 `d:\Aria_HU\转码\VibeCoding\food-diary` | 与 `source_query` 保持一致，避免题面与来源不一致 |
| 2 | 精简并重写 `Prompt` | 保持规则清晰，同时减少“解释型提示”带来的答案泄露感 |
| 3 | 重写 `Expected Behavior` | 从“直接逐条送答案”改为“行为要求 + Ground Truth + Trap Handling” |
| 4 | 增加 `Ground Truth` | 明确唯一正确输出，满足答案可验证要求 |
| 5 | 增加 `Trap Handling` | 明确“不能只看首个命令”“本题规则下 `&&` 视为注入”两个关键陷阱及正确处理方式 |
| 6 | 重写 `Grading Criteria` | 提高独立可验证性，并与自动评分 key 更好对齐 |
| 7 | 重写 `grade()` 的零分初始化逻辑 | 满足空白输出时各项为 0.0 的要求 |
| 8 | 将包含式判断改为严格等于判断 | 原逻辑只要包含 `command_injection_detected` 就通过，可能放过带解释输出，不符合“只输出结果”的要求 |
| 9| 增加 `clean_output_only` | 严格检查是否只输出最终答案，无额外文本 |
| 10 | 简化 `not_wrong_cd` / `not_wrong_none` / `not_wrong_npm` 逻辑 | 提高可解释性，减少条件绕行和误判风险 |
| 11 | 明确 `LLM Judge Rubric` 不适用 | 本题为 automated grading，避免结构歧义 |