| 序号 | 修改项 | 修改原因 |
|---|---|---|
| 1  | 改写 Prompt            | 保持真实用户请求风格，减少“题解式提示”，避免直接把正确答案塞进题面                                                            |
| 2  | 重写 Expected Behavior | 补充完整解题路径、陷阱说明与 Ground Truth，不只写“答案是 echo”                                                     |
| 3  | 重写 Grading Criteria  | 改成 5 条独立、可验证标准，并与 `grade()` score key 一一对应                                                    |
| 4  | 重写 `grade()`         | 增加空白零分、格式容忍、大小写容忍、额外文本惩罚和部分得分                                                                 |
| 5  | 补充 LLM Judge Rubric  | 原文件缺失该部分，不满足审校要求                                                                            |
| 6  | 修改 frontmatter       | 将 `verification_method` 改为 `rubric`，`grading_type` 改为 `hybrid`，并补 `grading_weights` 使权重和为 1.0 |