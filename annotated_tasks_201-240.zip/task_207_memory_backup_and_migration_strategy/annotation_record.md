| 序号 | 修改项 | 修改原因 |
|---|---|---|
| 1 | 删除 frontmatter 中的 `automated_weight` | 与 `grading_weights` 重复且可能冲突，保留一套权重定义即可 |
| 2 | 轻微改写 `Prompt` | 提高清晰度与自然度，保留真实用户场景，不直接泄露答案 |
| 3 | 补充 `Expected Behavior` 的 Ground Truth / Key Expectations | 原版本缺少更明确的可验证目标与关键保留事实 |
| 4 | 增加 `Trap Handling` | 明确说明过度压缩、不安全备份建议、弱索引、摘要编造等陷阱及正确处理方式 |
| 5 | 重写 `Grading Criteria` | 提高独立可验证性，并覆盖策略文档、分段质量、索引质量、事实保真等核心点 |
| 6 | 重写 `grade()` 的零分初始化逻辑 | 满足“空白/缺文件时全 0”要求 |
| 7 | 为 `read_text()` 显式指定 `encoding="utf-8"` | 提高稳健性 |
| 8 | 将策略文档检查从“只看 segment/compress”扩展为 5 个关键维度 | 更好对齐题目要求与评分标准 |
| 9 | 增加 `index_has_topic_mappings` | 原版只检查 index 是否有内容，不足以判断其是否有检索价值 |
| 10 | 增加 `segments_appear_processed` | 原版只看有没有分段文件，未检查内容是否经过组织/压缩处理 |
| 11 | 强化 `important_facts_preserved` | 增加对关键事实的覆盖，不只依赖单一数字 |
| 12 | 扩展 `no_fabrication` 检查 | 原版仅对 XGBoost accuracy 做弱检查，现增加 B2B AUC 与 Secrets Manager 相关检查 |
| 13 | 重写 LLM Judge Rubric 为 4 个正式评分维度 | 满足“至少 3 个维度”的要求 |
| 14 | 为每个 LLM 维度补齐 1.0 / 0.75 / 0.5 / 0.25 / 0.0 描述 | 满足等级描述清晰的要求 |