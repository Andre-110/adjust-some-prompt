---
id: task_207_memory_backup_and_migration_strategy
name: Memory Backup and Migration Strategy
category: Knowledge Management
subcategory: Memory and Context Management
difficulty: medium
external_dependency: none
verification_method: unit-test
input_modality: text-only
grading_type: hybrid
grading_weights:
  automated: 0.4
  llm_judge: 0.6
timeout_seconds: 180
workspace_files: []
source_line_number: 6189
source_query: "当“记忆/内容”过长导致无法继续发送（触发输入长度限制）时，如何安全备份，并用分段/压缩/摘要的方式保存与迁移这些内容？"
---

## Prompt

I’ve built up a large “memory bank” of notes and context for my AI assistant, and it has become too long to send in one shot because of input length limits.

I need help with three things:

1. Create a backup strategy document explaining how to safely save and migrate this kind of long-form memory/context
2. Process the memory dump into organized, compressed segments that can be loaded separately
3. Generate an index file so I can quickly find relevant content without loading everything

Save the outputs to files:
- `backup_strategy.md` for the strategy guide
- organized segment files for the processed memory
- `index.json` for quick lookup

Here is the memory dump to work from:

```text
=== PROJECT NOTES ===
[2024-01] Started new ML project for customer churn prediction. Using Python 3.10, scikit-learn, pandas. Dataset has 50k rows, 23 features. Target variable is binary (churned/retained). Initial baseline accuracy: 72%.

[2024-01] Team members: Alice (data eng), Bob (backend), Carol (PM). Weekly syncs on Thursdays 2pm PST. Slack channel: #churn-prediction.

[2024-02] Feature engineering done. Added: tenure_months, avg_monthly_spend, support_tickets_90d, login_frequency, last_purchase_days. New accuracy: 78%.

[2024-02] Bob suggested trying XGBoost instead of random forest. Need to test this week.

[2024-03] XGBoost results: 82% accuracy, 0.79 AUC. Much better! Hyperparameters: max_depth=6, learning_rate=0.1, n_estimators=200.

[2024-03] Carol wants a dashboard. Using Streamlit for quick prototype. Deploy to internal server at ml.internal.company.com.

[2024-04] Production deployment approved. API endpoint: /api/v1/predict_churn. Auth via API key in header. Rate limit: 100 req/min.

[2024-04] Bug found: model crashes on null values in tenure_months. Added imputation with median. Hotfix deployed.

[2024-05] Q2 review: model prevented estimated $340k in churn by enabling targeted retention campaigns. Stakeholders happy.

=== PERSONAL PREFERENCES ===
- Prefer concise answers, no fluff
- Code examples should include comments
- Always show imports at top of code blocks
- Timezone: PST
- Preferred languages: Python, JavaScript, SQL
- Don't explain basic concepts unless I ask
- Format dates as YYYY-MM-DD

=== RECURRING TASKS ===
- Monday: Review Jira backlog, update sprint board
- Tuesday: 1:1 with Carol at 10am
- Wednesday: Code review day
- Thursday: Team sync 2pm, write weekly summary
- Friday: Documentation and cleanup

=== TECHNICAL CONTEXT ===
Current stack: AWS (EC2, S3, Lambda), PostgreSQL 14, Redis for caching, Docker + K8s. CI/CD through GitHub Actions. Monitoring via Datadog.

Database schema for churn project:
- customers (id, email, created_at, plan_type, status)
- transactions (id, customer_id, amount, timestamp)
- support_tickets (id, customer_id, category, resolved_at)
- predictions (id, customer_id, churn_prob, model_version, predicted_at)

API keys stored in AWS Secrets Manager. Never hardcode credentials.

=== MEETING NOTES ===
[2024-05-15] Discussed expanding model to B2B customers. Different features needed: company_size, industry, contract_value. Carol to get stakeholder buy-in.

[2024-05-22] B2B expansion approved. Timeline: 6 weeks. Need to coordinate with sales team for labeled data.

[2024-06-01] Sales provided 5k labeled B2B records. Initial exploration shows class imbalance (only 8% churned). Will need SMOTE or class weights.

[2024-06-10] B2B model v1 done. AUC: 0.74. Lower than B2C but acceptable given data quality. Deployed to /api/v2/predict_churn_b2b.
```

The processed outputs should be shorter and better organized than the raw dump, but they must preserve important factual details such as dates, names, metrics, endpoints, and security cautions.

## Expected Behavior

The agent should:

1. Create `backup_strategy.md` with practical guidance for:

   * safe backup/export
   * segmentation/chunking
   * summarization/compression
   * migration/restoration
   * handling sensitive information safely
2. Split the provided dump into logical, organized segment files such as:

   * project notes / timeline
   * personal preferences
   * recurring tasks
   * technical context
   * meeting notes
3. Compress or summarize each segment so it is shorter than the raw source section while preserving key facts.
4. Create `index.json` that helps users locate topics without opening every file.
5. Avoid inventing facts that are not present in the source dump.

### Ground Truth / Key Expectations

A strong solution will typically produce:

* one strategy document: `backup_strategy.md`
* multiple segment files, with at least 3 distinct logical categories
* one valid JSON index file: `index.json`

The strategy document should mention concepts such as:

* backing up raw vs processed copies
* chunking/segmentation by topic or time
* compression/summarization
* restoration or rehydration workflow
* protection of secrets/credentials or sensitive operational details

The processed memory should preserve key source facts, including examples like:

* XGBoost reached **82% accuracy** and **0.79 AUC**
* deployment endpoint `/api/v1/predict_churn`
* B2B model v1 had **0.74 AUC**
* API keys are stored in **AWS Secrets Manager**
* dates, names, and recurring schedule details should remain accurate if included

### Trap Handling

This task contains several traps:

1. **Over-compression**
   The output should be shorter, but must not drop important factual details such as dates, metrics, endpoints, or security guidance.

2. **Unsafe backup advice**
   The strategy should not recommend insecure handling of secrets, credentials, or raw sensitive context.

3. **Weak indexing**
   The index should help retrieval, not just exist as an empty or meaningless file.

4. **Fabrication during summarization**
   Summaries must stay faithful to the source dump and must not invent team members, metrics, systems, or timelines.

## Grading Criteria

* [ ] `backup_strategy.md` exists
* [ ] Strategy document includes backup/export, chunking/segmentation, summarization/compression, migration/restoration, and sensitive-info handling guidance
* [ ] Multiple logical segment files are created (at least 3)
* [ ] Segment files contain compressed/organized content rather than raw copy-paste only
* [ ] `index.json` exists and is valid JSON
* [ ] `index.json` contains meaningful topic-to-location mappings
* [ ] Important source facts are preserved accurately
* [ ] No fabricated information appears in the saved outputs

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    from pathlib import Path
    import json
    import re

    def _zero_scores():
        return {
            "strategy_file_exists": 0.0,
            "strategy_has_required_guidance": 0.0,
            "segment_files_created": 0.0,
            "segments_appear_processed": 0.0,
            "index_file_exists": 0.0,
            "index_valid_json": 0.0,
            "index_has_topic_mappings": 0.0,
            "important_facts_preserved": 0.0,
            "no_fabrication": 0.0,
        }

    scores = _zero_scores()
    ws = Path(workspace_path)

    strategy_file = ws / "backup_strategy.md"
    index_file = ws / "index.json"

    if strategy_file.exists():
        scores["strategy_file_exists"] = 1.0
        try:
            strategy_text = strategy_file.read_text(encoding="utf-8").lower()
        except Exception:
            strategy_text = ""
    else:
        strategy_text = ""

    if strategy_text:
        has_backup = any(w in strategy_text for w in ["backup", "export", "archive"])
        has_chunking = any(w in strategy_text for w in ["segment", "chunk", "split", "partition"])
        has_summary = any(w in strategy_text for w in ["summar", "compress", "condense", "reduce"])
        has_restore = any(w in strategy_text for w in ["restore", "rehydrat", "migrate", "reload"])
        has_sensitive = any(w in strategy_text for w in ["secret", "credential", "api key", "sensitive", "aws secrets manager"])

        present = sum([has_backup, has_chunking, has_summary, has_restore, has_sensitive])
        scores["strategy_has_required_guidance"] = present / 5.0

    if index_file.exists():
        scores["index_file_exists"] = 1.0
        try:
            index_data = json.loads(index_file.read_text(encoding="utf-8"))
            scores["index_valid_json"] = 1.0
        except Exception:
            index_data = None
    else:
        index_data = None

    if isinstance(index_data, dict) and len(index_data) > 0:
        scores["index_has_topic_mappings"] = 1.0
    elif isinstance(index_data, list) and len(index_data) > 0:
        scores["index_has_topic_mappings"] = 0.5
    else:
        scores["index_has_topic_mappings"] = 0.0

    segment_patterns = [
        "project", "preference", "task", "technical", "meeting",
        "context", "notes", "segment", "chunk", "memory"
    ]
    segment_files = []
    for f in ws.iterdir():
        if not f.is_file():
            continue
        if f.name in {"backup_strategy.md", "index.json"}:
            continue
        if f.suffix.lower() not in {".md", ".txt", ".json"}:
            continue
        fname = f.stem.lower()
        if any(p in fname for p in segment_patterns):
            segment_files.append(f)

    if len(segment_files) >= 3:
        scores["segment_files_created"] = 1.0
    elif len(segment_files) >= 1:
        scores["segment_files_created"] = 0.5

    processed_hits = 0
    inspected = 0
    for f in segment_files[:10]:
        try:
            txt = f.read_text(encoding="utf-8")
        except Exception:
            continue
        inspected += 1
        lowered = txt.lower()
        if any(tok in lowered for tok in ["summary", "key points", "highlights", "overview", "timeline", "important"]):
            processed_hits += 1
        elif len(txt.splitlines()) >= 3 and len(txt) < 2500:
            processed_hits += 1

    if inspected > 0:
        scores["segments_appear_processed"] = processed_hits / inspected

    all_content = ""
    for f in ws.iterdir():
        if f.is_file() and f.suffix.lower() in {".md", ".txt", ".json"}:
            try:
                all_content += f.read_text(encoding="utf-8") + "\n"
            except Exception:
                pass
    lowered_all = all_content.lower()

    fact_checks = [
        ("82% accuracy", "82%"),
        ("0.79 auc", "0.79"),
        ("/api/v1/predict_churn", "/api/v1/predict_churn"),
        ("aws secrets manager", "aws secrets manager"),
        ("0.74 auc", "0.74"),
    ]
    fact_hits = 0
    for _, needle in fact_checks:
        if needle in lowered_all:
            fact_hits += 1
    scores["important_facts_preserved"] = fact_hits / len(fact_checks)

    fabrication_detected = False

    # Wrong XGBoost accuracy near xgboost mention
    if "xgboost" in lowered_all:
        for bad in ["83%", "84%", "85%", "86%", "87%", "88%", "89%", "90%"]:
            if bad in lowered_all:
                fabrication_detected = True

    # Wrong B2B AUC if B2B is mentioned
    if "b2b" in lowered_all and "auc" in lowered_all:
        b2b_bad = re.search(r"b2b[^.\n]{0,120}auc[^0-9]{0,10}(0\.\d+)", lowered_all)
        if b2b_bad and b2b_bad.group(1) != "0.74":
            fabrication_detected = True

    # Wrong security storage statement
    if "api keys" in lowered_all and "secrets manager" not in lowered_all:
        fabrication_detected = True

    scores["no_fabrication"] = 0.0 if fabrication_detected else 1.0

    return scores
```

## LLM Judge Rubric

### Criterion 1: Backup Strategy Quality (Weight: 25%)

**Score 1.0**: The strategy document is practical, clear, and actionable. It covers safe backup/export, versioning or raw-vs-processed backup considerations, chunking, summarization, migration/restoration, and sensitive-information handling.
**Score 0.75**: Good strategy with most key elements present, but one area is underdeveloped.
**Score 0.5**: Basic strategy exists, but guidance is generic or missing multiple important elements.
**Score 0.25**: Minimal or weak strategy document with limited practical value.
**Score 0.0**: Missing or unusable strategy document.

### Criterion 2: Segmentation Logic and Organization (Weight: 25%)

**Score 1.0**: The memory dump is split into coherent, useful segments that are easy to load independently. The grouping is logical and improves retrieval.
**Score 0.75**: Segmentation is mostly logical, with only minor organizational issues.
**Score 0.5**: Some segmentation exists, but grouping is inconsistent or only partly useful.
**Score 0.25**: Weak segmentation with limited practical organization.
**Score 0.0**: No meaningful segmentation.

### Criterion 3: Compression Fidelity and Information Preservation (Weight: 30%)

**Score 1.0**: The segments are meaningfully compressed while preserving important details such as dates, names, metrics, endpoints, and security cautions. No material facts are distorted.
**Score 0.75**: Good compression with small omissions, but most important details are preserved accurately.
**Score 0.5**: Partial compression success; several key facts are missing or overly vague.
**Score 0.25**: Heavy loss of important detail or noticeable factual drift.
**Score 0.0**: Summaries are unreliable, inaccurate, or largely unfaithful to the source.

### Criterion 4: Index Usefulness and Retrieval Support (Weight: 20%)

**Score 1.0**: `index.json` is well-structured and genuinely useful for locating topics, files, or sections quickly.
**Score 0.75**: Index is valid and somewhat useful, but could be more specific or structured.
**Score 0.5**: Index exists but provides limited retrieval value.
**Score 0.25**: Weak or barely usable index.
**Score 0.0**: Missing, invalid, or non-functional index.
