| 序号 | 修改项 | 修改原因 |
|---|---|---|
| 1 | 重写 Prompt 的要求部分 | 原 Prompt 基本清晰，但对每个 factor 的结构要求不够收敛，容易导致输出格式不稳定 |
| 2 | 在 Prompt 中明确“只能使用允许算子” | 原题虽列出算子，但未将“不得使用其他算子”单独强调，容易出现 fabricated operators |
| 3 | 在 Prompt 中明确“不是 simple parameter-only variations” | 原题说不要 minor variations，但表述较口语化，改成更可执行的约束 |
| 4 | 扩充 Expected Behavior | 原 Expected Behavior 过于简略，缺少 traps 和可验证 Ground Truth |
| 5 | 在 Expected Behavior 中补充 traps | 题目存在多个典型陷阱：只写泛泛解释、不用规定公式语言、用新算子、只改 lookback 冒充新因子，因此应明确写出 |
| 6 | 在 Expected Behavior 中补充 Ground Truth constraints | 满足“答案明确、可验证”的规范要求，便于自动评分和 LLM Judge 对齐 |
| 7 | 重写 Grading Criteria | 原条目过粗，未把“name / formula / intuition / lookback / distinctness / fabricated operators”拆开，区分度不足 |
| 8 | 增加“每个因子包含名称”评分条目 | 原题在 Prompt 中要求 name，但原评分没有单独覆盖 |
| 9 | 增加“每个因子包含 lookback/parameter 信息”评分条目 | 原 Prompt 明确要求，但原自动评分没有很好覆盖 |
| 10 | 增加“factors are meaningfully distinct”评分条目 | 原 Prompt 提出要求，但原自动评分几乎没有真正检查 distinctness |
| 11 | 增加“formulas do not use fabricated operators”评分条目 | 原评分虽有 `no_fabricated_operators`，但未在 Grading Criteria 中明确列出，造成不对齐 |
| 12 | 重写 automated checks 的 score key | 让 score key 与 Grading Criteria 更接近一一对应，满足 Key 对齐要求 |
| 13 | 为读取文件显式指定 `encoding="utf-8"` | 提高稳健性 |
| 14 | 改写 factor block 识别逻辑 | 原版 `factor_pattern` 过窄，容易漏掉正常写法；新版更兼容 heading 和常见结构 |
| 15 | 改进 factor count 逻辑 | 原版通过 heading 数量、formula 数量和 `content_lower.count("formula")` 混合估计，误判概率高；新版基于 factor block 更稳健 |
| 16 | 改进“valid operators”检查 | 原版只是统计全文出现了多少个合法算子，不足以判断每个公式是否合法；新版按 factor block 抽公式并检查调用的算子名 |
| 17 | 收紧 fabricated operator 检查 | 原版会把一些非公式性文本也误计为 fabricated；新版只在公式文本内检查函数调用形式 |
| 18 | 改进 volume factor 检查 | 原版只要全文出现 `volume` 加若干 momentum 词就可能通过；新版优先要求在公式层面同时出现 `Volume` 与动量相关元素 |
| 19 | 改进 normalization 检查 | 将检查聚焦到公式文本，而不是全文任意位置 |
| 20 | 增加 explanations 的分块检查 | 原版只看“是否提供 explanations”但未单独评分；新版按 factor block 统计解释覆盖率，支持部分得分 |
| 21 | 增加 lookback / parameter 的分块检查 | 原版遗漏这项；新版按 factor block 统计覆盖率，支持部分得分 |
| 22 | 增加 distinctness 的自动检查 | 虽无法完美语义判断，但至少可以通过公式签名去重，对简单重复项形成约束 |
| 23 | 重写 LLM Judge Rubric | 原 Rubric 基本可用，但维度描述较粗；新版改为更清晰的 4 维结构并补足 1.0 / 0.75 / 0.5 / 0.25 / 0.0 分档描述 |