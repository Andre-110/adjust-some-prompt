---
id: task_236_momentum_factor_generator
name: Momentum Factor Generator
category: Finance
subcategory: Trading Strategy and Backtesting
difficulty: hard
external_dependency: none
verification_method: rubric
input_modality: text-only
grading_type: hybrid
timeout_seconds: 240
grading_weights:
  automated: 0.4
  llm_judge: 0.6
workspace_files: []
source_line_number: 150
source_query: "使用以下算子（Mean, Std, Ref, Corr, Rank, Delta, Delay, EMA, SMA, WMA, MACD, RSI, BOLL, KDJ, Open, High, Low, Close, Volume, Abs, Log, Sign, Power, Sqrt, Min, Max, ArgMin, ArgMax, CumSum, Scale, Neutralize），从动量因子出发生成 3–5 个量化因子。"
---

## Prompt

Hey, I need help designing some quantitative factors for a stock selection model.

Please generate **3 to 5** quantitative factors starting from **momentum-related ideas** and using only the operators listed below.

Allowed operators:
`Mean`, `Std`, `Ref`, `Corr`, `Rank`, `Delta`, `Delay`, `EMA`, `SMA`, `WMA`, `MACD`, `RSI`, `BOLL`, `KDJ`, `Open`, `High`, `Low`, `Close`, `Volume`, `Abs`, `Log`, `Sign`, `Power`, `Sqrt`, `Min`, `Max`, `ArgMin`, `ArgMax`, `CumSum`, `Scale`, `Neutralize`

For each factor, include:
- a factor name
- the formula using only the allowed operators
- a short explanation of what it captures and why it may predict returns
- the lookback windows or parameters used

Requirements:
- Save the result to `factors.md`
- The factors should be meaningfully different from each other, not simple parameter-only variations
- Include at least one factor that combines momentum with `Volume`
- Include at least one factor that uses `Rank`, `Scale`, or `Neutralize`
- Do not use operators outside the allowed list

## Expected Behavior

The agent should:
1. Create a file named `factors.md`.
2. Generate **3 to 5** momentum-related quantitative factors.
3. For each factor, provide:
   - a clear factor name
   - a formula written with the allowed operator syntax
   - a short financial intuition
   - the lookback windows or parameter choices used
4. Ensure the factors are conceptually distinct rather than trivial rewrites of the same idea.
   - For example, changing only one lookback from 5 to 6 is not enough to count as a distinct factor by itself.
5. Include at least one factor that explicitly combines price momentum with `Volume`.
6. Include at least one factor that uses a normalization-style operator:
   - `Rank`, `Scale`, or `Neutralize`
7. Use only operators from the allowed list in the formulas.
8. Save the full response in `factors.md`.

Traps the agent should handle correctly:
- The task is not asking for generic prose only; it requires a structured file with factor definitions.
- The formulas should be expressed in the provided operator language, not in plain English or standard algebra only.
- Factors should be genuinely different in construction or intuition, not just minor window tweaks.
- The agent should not invent new operators outside the allowed set.

Ground truth constraints:
- Output filename: `factors.md`
- Number of factors: between 3 and 5 inclusive
- At least one factor must use `Volume`
- At least one factor must use `Rank`, `Scale`, or `Neutralize`
- Each factor must include name, formula, intuition, and parameter/lookback information
- Formulas must use only operators from the allowed list

Tested capabilities: quantitative finance reasoning, factor design, structured formula writing, instruction following, file generation.

## Grading Criteria

- [ ] `factors.md` exists
- [ ] The file contains 3 to 5 factor definitions
- [ ] Each factor includes a name
- [ ] Each factor includes a formula written with allowed operators
- [ ] At least one factor combines momentum with `Volume`
- [ ] At least one factor uses `Rank`, `Scale`, or `Neutralize`
- [ ] Each factor includes financial intuition or explanation
- [ ] Each factor includes lookback windows or parameter information
- [ ] The factors are meaningfully distinct rather than trivial parameter-only variations
- [ ] The formulas do not use fabricated operators outside the allowed list

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    from pathlib import Path
    import re

    scores = {
        "file_exists": 0.0,
        "factor_count": 0.0,
        "has_factor_names": 0.0,
        "has_formulas_with_allowed_operators": 0.0,
        "has_volume_factor": 0.0,
        "has_normalization_factor": 0.0,
        "has_explanations": 0.0,
        "has_lookbacks_or_parameters": 0.0,
        "factors_are_distinct": 0.0,
        "no_fabricated_operators": 0.0,
    }

    ws = Path(workspace_path)
    factors_file = ws / "factors.md"

    if not factors_file.exists():
        return scores

    scores["file_exists"] = 1.0

    try:
        content = factors_file.read_text(encoding="utf-8")
    except Exception:
        return scores

    lowered = content.lower()

    allowed_ops = [
        "mean", "std", "ref", "corr", "rank", "delta", "delay", "ema", "sma", "wma",
        "macd", "rsi", "boll", "kdj", "open", "high", "low", "close", "volume",
        "abs", "log", "sign", "power", "sqrt", "min", "max", "argmin", "argmax",
        "cumsum", "scale", "neutralize"
    ]
    allowed_set = set(allowed_ops)

    # Split likely factor blocks using markdown headings or repeated "Factor" labels.
    blocks = re.split(r'(?:^|\n)(?=#+\s+|(?:factor\s*\d+\s*:))', content, flags=re.IGNORECASE)
    factor_blocks = []

    for block in blocks:
        b = block.strip()
        if not b:
            continue
        if (
            re.search(r'formula', b, re.IGNORECASE)
            or re.search(r'\b(?:rank|delta|ema|sma|wma|macd|rsi|boll|kdj|scale|neutralize)\s*\(', b, re.IGNORECASE)
        ):
            factor_blocks.append(b)

    # Conservative cap to avoid counting intro text as factor blocks
    if len(factor_blocks) > 5:
        factor_blocks = factor_blocks[:5]

    count = len(factor_blocks)
    if 3 <= count <= 5:
        scores["factor_count"] = 1.0
    elif count == 2:
        scores["factor_count"] = 0.5
    else:
        scores["factor_count"] = 0.0

    # Name presence
    name_hits = 0
    for block in factor_blocks:
        has_heading = bool(re.search(r'^(#+\s+.+)', block, re.IGNORECASE | re.MULTILINE))
        has_name_label = bool(re.search(r'\bname\s*:', block, re.IGNORECASE))
        if has_heading or has_name_label:
            name_hits += 1
    if factor_blocks:
        scores["has_factor_names"] = name_hits / len(factor_blocks)

    # Formula extraction and validation
    formula_hits = 0
    volume_hits = 0
    norm_hits = 0
    explanation_hits = 0
    lookback_hits = 0
    unique_formula_signatures = []
    fabricated_penalty = 0

    formula_label_pattern = re.compile(
        r'(?:formula\s*:?\s*`?([^\n`]+)`?)',
        re.IGNORECASE
    )

    generic_call_pattern = re.compile(r'\b([A-Za-z][A-Za-z0-9_]*)\s*\(')

    for block in factor_blocks:
        formula_text = None

        m = formula_label_pattern.search(block)
        if m:
            formula_text = m.group(1).strip()
        else:
            # fallback: first line containing obvious operator call
            for line in block.splitlines():
                if re.search(r'\b(?:rank|delta|ema|sma|wma|macd|rsi|boll|kdj|scale|neutralize|corr|mean|std|min|max|argmin|argmax|cumsum)\s*\(', line, re.IGNORECASE):
                    formula_text = line.strip().strip("`")
                    break

        if formula_text:
            called_ops = [op.lower() for op in generic_call_pattern.findall(formula_text)]
            if called_ops and all(op in allowed_set for op in called_ops):
                formula_hits += 1
            else:
                if called_ops:
                    fabricated_penalty += 1

            if re.search(r'\bvolume\b', formula_text, re.IGNORECASE) and re.search(r'\b(close|delta|macd|rsi|ema|sma|wma|rank|return|momentum)\b', formula_text, re.IGNORECASE):
                volume_hits += 1

            if re.search(r'\b(rank|scale|neutralize)\s*\(', formula_text, re.IGNORECASE):
                norm_hits += 1

            normalized_sig = re.sub(r'\s+', '', formula_text.lower())
            unique_formula_signatures.append(normalized_sig)

        if re.search(r'\b(explain|intuition|captures|predict|reason|why)\b', block, re.IGNORECASE):
            explanation_hits += 1
        else:
            # allow prose blocks without explicit label
            prose_lines = [ln.strip() for ln in block.splitlines() if ln.strip()]
            if len(prose_lines) >= 3:
                explanation_hits += 1

        if re.search(r'\b(lookback|window|parameter|period|days?|weeks?)\b', block, re.IGNORECASE) or re.search(r'\b\d+\b', block):
            lookback_hits += 1

    if factor_blocks:
        scores["has_formulas_with_allowed_operators"] = formula_hits / len(factor_blocks)
        scores["has_volume_factor"] = 1.0 if volume_hits >= 1 else 0.0
        scores["has_normalization_factor"] = 1.0 if norm_hits >= 1 else 0.0
        scores["has_explanations"] = explanation_hits / len(factor_blocks)
        scores["has_lookbacks_or_parameters"] = lookback_hits / len(factor_blocks)

        unique_count = len(set(unique_formula_signatures))
        if len(factor_blocks) >= 3:
            scores["factors_are_distinct"] = unique_count / len(factor_blocks)
        else:
            scores["factors_are_distinct"] = 0.0

    scores["no_fabricated_operators"] = 1.0 if fabricated_penalty == 0 else max(0.0, 1.0 - fabricated_penalty / max(1, len(factor_blocks)))

    return scores
```