| 序号 | 修改项 | 修改原因 |
|------|--------|----------|
| 1    | 补充 `grading_weights` | 原文件缺少 `grading_weights`，但规范要求 automated + llm_judge 权重之和应为 1.0；该题为纯自动评分，因此补为 `automated: 1.0`、`llm_judge: 0.0` |
| 2    | 重写 Prompt 的要求部分 | 原 Prompt 基本清晰，但“under models/providers/bailian”“clear alias”“primary model”仍略口语化，补成更稳定、可执行的约束 |
| 3    | 明确“exactly these 6 models” | 原 Prompt 虽列了 6 个模型，但没有把“不得添加额外模型”强调到足够可判定；现显式写明 |
| 4    | 明确“Return the result by writing the YAML file only” | 避免模型只在聊天中返回 YAML 片段而不生成文件 |
| 5    | 扩充 Expected Behavior | 原版有核心要求，但缺少完整路径结构、primary 表达方式、alias 覆盖范围等可验证细节 |
| 6    | 在 Expected Behavior 中增加 traps | 这题存在明显陷阱：真实 key、路径放错、主模型只靠顺序暗示、alias 只配一部分、额外加模型，因此需要显式说明 |
| 7    | 增加 Ground Truth constraints | 满足“答案明确、可验证”的要求，让自动评分与人工审核统一 |
| 8    | 重写 Grading Criteria | 原标准偏粗，尤其对“路径正确”“每个模型都有 alias”“exactly 6 models”区分不够，重新拆分为独立可判项 |
| 9   | 将 `bailian_provider_path` 改为结构化检查 | 原版只要文本里出现 `providers` 和 `bailian` 就通过，过宽；新版通过解析 YAML 后检查 `models.providers.bailian` 实际存在 |
| 10   | 将“all models declared”改为“exact required models declared” | 原版只是全文搜模型名，无法确认它们是否真的声明在目标路径下；新版基于结构化键集合判断 |
| 11   | 新增“no extra models under bailian”结构化检查 | 原版只是排除个别常见模型名，不能真正防止添加额外模型；新版要求 `bailian` 下键集合与 required set 完全一致 |
| 12   | 将 enabled 检查改为逐模型检查 | 原版没有真正检查 6 个模型是否都启用；新版对每个模型读取 `enabled` 字段并支持部分得分 |
| 13   | 将 alias 检查改为逐模型检查 | 原版只要全文出现 alias/name 等字样就通过，不能保证每个模型都有 alias；新版对 6 个模型逐一检查 `alias` |
| 14   | 将 primary model 检查改为结构化字段检查 | 原版依赖文本近邻匹配，较脆弱；新版检查多个常见顶层主模型字段是否明确指向 `glm-4.7` |
| 15   | 为文件读取增加 `encoding="utf-8"` | 提高稳健性 |
| 16   | 删除实际无用的 LLM Rubric，改为 Not applicable | 该题 `grading_type: automated` 且 `llm_judge: 0.0`，不应保留一个参与度为 0 的 Rubric 段落，避免歧义 |