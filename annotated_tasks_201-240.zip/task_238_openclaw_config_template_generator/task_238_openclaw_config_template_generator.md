---
id: task_238_openclaw_config_template_generator
name: OpenClaw Config Template Generator
category: Automation
subcategory: Agent and AI Orchestration
difficulty: medium
external_dependency: none
verification_method: unit-test
input_modality: text-only
grading_type: automated
timeout_seconds: 120
grading_weights:
  automated: 1.0
  llm_judge: 0.0
workspace_files: []
source_line_number: 9501
source_query: "生成一份 OpenClaw 配置模板：使用 Coding Plan 的 baseUrl https://coding.dashscope.aliyuncs.com/v1（API key 用占位符），在 models/providers/bailian 下声明并启用模型 qwen3-max-2026-01-23、qwen3.5-plus、qwen3-coder-next、qwen3-coder-plus、glm-4.7、kimi-k2.5，并把主脑（primary model）设置为 glm-4.7；同时为各模型设置清晰的 alias。"
---

## Prompt

Hey, I need an OpenClaw YAML config template for our team.

Please create a file named `openclaw-config.yaml`.

Requirements:
- use `https://coding.dashscope.aliyuncs.com/v1` as the `baseUrl`
- use an API key placeholder such as `YOUR_API_KEY_HERE`
- declare the models under `models -> providers -> bailian`
- include exactly these 6 models and mark them enabled:
  - `qwen3-max-2026-01-23`
  - `qwen3.5-plus`
  - `qwen3-coder-next`
  - `qwen3-coder-plus`
  - `glm-4.7`
  - `kimi-k2.5`
- set `glm-4.7` as the primary model
- give each model a clear alias that is easy to understand from the model name
- do not add extra models beyond the 6 listed above

Return the result by writing the YAML file only.

## Expected Behavior

The agent should:
1. Create a file named `openclaw-config.yaml`.
2. Write valid YAML.
3. Set `baseUrl` to `https://coding.dashscope.aliyuncs.com/v1`.
4. Use a placeholder value for the API key rather than a real secret.
5. Declare a nested configuration path corresponding to:
   - `models`
   - `providers`
   - `bailian`
6. Under `models.providers.bailian`, declare exactly these 6 models:
   - `qwen3-max-2026-01-23`
   - `qwen3.5-plus`
   - `qwen3-coder-next`
   - `qwen3-coder-plus`
   - `glm-4.7`
   - `kimi-k2.5`
7. Mark all 6 models as enabled.
8. Assign an alias to each of the 6 models.
9. Set `glm-4.7` as the primary model in a way that is clearly represented in the YAML structure.
10. Do not introduce fabricated or extra model entries.

Traps the agent should handle correctly:
- The task is about generating a configuration template, so the API key must be a placeholder, not a guessed real key.
- The 6 required models must all appear under the `bailian` provider path, not scattered elsewhere in the file.
- “Set glm-4.7 as the primary model” must be reflected explicitly in the YAML, not only implied by ordering.
- “Give each model a clear alias” means every required model should have its own alias field or equivalent alias mapping, not just one or two examples.
- The task asks for exactly the listed models; adding other common model names should be treated as incorrect.

Ground truth constraints:
- Output filename: `openclaw-config.yaml`
- Output format: valid YAML
- Required provider path: `models.providers.bailian`
- Required model set: exactly 6 specified models
- All required models must be enabled
- `glm-4.7` must be designated as the primary model
- Each required model must have an alias
- API key must be a placeholder, not a real secret

Tested capabilities: YAML configuration generation, hierarchical config structuring, instruction following, model inventory accuracy, placeholder secret handling.

## Grading Criteria

- [ ] `openclaw-config.yaml` exists
- [ ] The file is valid YAML
- [ ] `baseUrl` is correctly set to `https://coding.dashscope.aliyuncs.com/v1`
- [ ] The API key is a placeholder value
- [ ] The YAML contains the `models.providers.bailian` path
- [ ] Exactly the 6 required models are declared under `models.providers.bailian`
- [ ] All 6 required models are enabled
- [ ] `glm-4.7` is explicitly set as the primary model
- [ ] Each of the 6 required models has an alias
- [ ] No extra fabricated models are added under `models.providers.bailian`

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    from pathlib import Path
    import re

    scores = {
        "config_file_exists": 0.0,
        "valid_yaml": 0.0,
        "correct_baseurl": 0.0,
        "api_key_placeholder": 0.0,
        "has_bailian_provider_path": 0.0,
        "exact_required_models_declared": 0.0,
        "all_models_enabled": 0.0,
        "primary_model_glm47": 0.0,
        "aliases_defined_for_all_models": 0.0,
        "no_extra_models_under_bailian": 0.0,
    }

    ws = Path(workspace_path)
    config_file = ws / "openclaw-config.yaml"

    if not config_file.exists():
        return scores

    scores["config_file_exists"] = 1.0

    try:
        content = config_file.read_text(encoding="utf-8")
    except Exception:
        return scores

    try:
        import yaml
        config = yaml.safe_load(content)
        if config is None:
            return scores
        scores["valid_yaml"] = 1.0
    except Exception:
        return scores

    expected_url = "https://coding.dashscope.aliyuncs.com/v1"
    if isinstance(config, dict) and config.get("baseUrl") == expected_url:
        scores["correct_baseurl"] = 1.0

    api_key_value = None
    if isinstance(config, dict):
        api_key_value = config.get("apiKey")

    if isinstance(api_key_value, str):
        placeholder_patterns = [
            r"YOUR_API_KEY",
            r"PLACEHOLDER",
            r"your[_-]?api[_-]?key",
            r"api[_-]?key[_-]?here",
            r"<.*API.*KEY.*>",
            r"\$\{.*API.*KEY.*\}",
        ]
        if any(re.search(p, api_key_value, re.IGNORECASE) for p in placeholder_patterns):
            scores["api_key_placeholder"] = 1.0

    bailian = None
    if isinstance(config, dict):
        models = config.get("models")
        if isinstance(models, dict):
            providers = models.get("providers")
            if isinstance(providers, dict):
                bailian = providers.get("bailian")
                if isinstance(bailian, dict):
                    scores["has_bailian_provider_path"] = 1.0

    if not isinstance(bailian, dict):
        return scores

    required_models = {
        "qwen3-max-2026-01-23",
        "qwen3.5-plus",
        "qwen3-coder-next",
        "qwen3-coder-plus",
        "glm-4.7",
        "kimi-k2.5",
    }

    declared_models = set(bailian.keys())

    matched_count = len(required_models & declared_models)
    if matched_count == 6:
        scores["exact_required_models_declared"] = 1.0
    else:
        scores["exact_required_models_declared"] = matched_count / 6.0

    if declared_models == required_models:
        scores["no_extra_models_under_bailian"] = 1.0
    else:
        scores["no_extra_models_under_bailian"] = 0.0

    enabled_count = 0
    alias_count = 0

    for model_name in required_models:
        model_cfg = bailian.get(model_name)
        if not isinstance(model_cfg, dict):
            continue

        if model_cfg.get("enabled") is True:
            enabled_count += 1

        alias = model_cfg.get("alias")
        if isinstance(alias, str) and alias.strip():
            alias_count += 1

    scores["all_models_enabled"] = enabled_count / 6.0
    scores["aliases_defined_for_all_models"] = alias_count / 6.0

    primary_candidates = []
    if isinstance(config, dict):
        primary_candidates.extend([
            config.get("primaryModel"),
            config.get("primary_model"),
            config.get("primary"),
            config.get("defaultModel"),
            config.get("default_model"),
            config.get("mainModel"),
            config.get("main_model"),
        ])

    has_primary_glm47 = any(v == "glm-4.7" for v in primary_candidates)
    scores["primary_model_glm47"] = 1.0 if has_primary_glm47 else 0.0

    return scores
```

## LLM Judge Rubric

Not applicable. This task is graded fully by automated checks.

