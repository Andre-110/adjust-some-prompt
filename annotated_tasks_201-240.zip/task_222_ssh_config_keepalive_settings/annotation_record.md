| 序号 | 修改项 | 修改原因 |
|---|---|---|
| 1    | 将 `difficulty` 从 `easy` 改为 `medium` | 该题不仅要求添加配置，还要求精确作用于 `proxy` 块、保留其他 host、不误改配置、输出到指定文件，难度高于简单题 |
| 2    | 重写 `Prompt` 中的要求列表 | 原 Prompt 基本可用，但对“只改 proxy、不改其他 host”的约束不够突出，补强后更清晰无歧义 |
| 3    | 在 Prompt 中明确输出文件名为 `ssh_config` | 强化可执行性与可评分性 |
| 4    | 补充 `Expected Behavior` 中“只修改 Host proxy block” | 原版本虽有提及，但不够明确，需补成核心约束 |
| 5    | 补充 `Expected Behavior` 中对 `proxy` 原始字段必须保留的 Ground Truth | 便于验证输出是否正确而非重写错块 |
| 6    | 补充 `Expected Behavior` 中“不得给 devbox / production 添加 keepalive 设置” | 原版缺少对陷阱的明确处理说明 |
| 7    | 重写 `Grading Criteria`，加入 `Host proxy` block 存在检查 | 原标准未单列该关键前提 |
| 8    | 重写 `Grading Criteria` 使其与自动评分 key 更一致 | 满足 Key 对齐与独立可验证要求 |
| 9    | 重写 `grade()`，预先定义全部 score keys 并在缺文件时统一返回 0.0 | 满足“空白零分”要求，结构更稳健 |
| 10   | `grade()` 增加 `proxy_block_exists` | 原评分没有单独检查 `proxy` host block 是否存在 |
| 11   | `grade()` 为数值项增加更合理的部分得分 | 满足支持 0.0–1.0 部分得分要求 |
| 12   | `grade()` 调整 `ServerAliveInterval` / `ServerAliveCountMax` / `ConnectTimeout` 的满分区间与部分分区间 | 让“reasonable value”更贴近题意，同时允许合理变体 |
| 13   | `grade()` 改进文件读取逻辑 | 增加 `utf-8` 读取与兜底，降低编码问题导致误判的风险 |
| 14   | `grade()` 的负向检查扩展到 `TCPKeepAlive` 和 `ConnectTimeout` | 原 `no_fabrication` 只检查了部分 keepalive 项，覆盖不全 |
| 15   | 将负向检查 key 从 `no_fabrication` 改为 `no_keepalive_on_other_hosts` | 名称更清晰、语义更准确，也与评分标准更好对齐 |