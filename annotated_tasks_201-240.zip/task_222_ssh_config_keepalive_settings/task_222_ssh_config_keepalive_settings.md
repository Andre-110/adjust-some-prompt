---
id: task_222_ssh_config_keepalive_settings
name: SSH Config Keepalive Settings
category: System Administration
subcategory: Network and Remote Services
difficulty: medium
external_dependency: none
verification_method: unit-test
input_modality: text-only
grading_type: automated
timeout_seconds: 120
workspace_files: []
source_line_number: 6449
source_query: "Update the SSH client configuration (`~/.ssh/config`) to enable keepalive/heartbeat settings for the host alias `proxy` to reduce idle disconnects (e.g., `ServerAliveInterval`, `ServerAliveCountMax`, `TCPKeepAlive`, and a reasonable `ConnectTimeout`)."
---

## Prompt

I keep getting disconnected from SSH when the connection sits idle for a while. Please update the SSH client config so the **`proxy`** host has keepalive / heartbeat settings to reduce idle disconnects.

Here is my current `~/.ssh/config`:

```sshconfig
Host devbox
    HostName 192.168.1.50
    User developer
    IdentityFile ~/.ssh/id_dev

Host proxy
    HostName jump.example.com
    User admin
    Port 2222

Host production
    HostName prod.example.com
    User deploy
    ProxyJump proxy
```

Requirements:

* Add the keepalive settings **only** under the `proxy` host block
* Include:

  * `ServerAliveInterval`
  * `ServerAliveCountMax`
  * `TCPKeepAlive`
  * `ConnectTimeout`
* Use reasonable values for these settings
* Preserve the existing settings for all hosts
* Save the updated result to a file named **`ssh_config`** in the current working directory

## Expected Behavior

The agent should:

1. Read the provided SSH client configuration from the prompt.
2. Preserve the overall SSH config structure and keep all existing host blocks.
3. Modify only the `Host proxy` block.
4. Keep the existing `proxy` settings unchanged:

   * `HostName jump.example.com`
   * `User admin`
   * `Port 2222`
5. Add the following keepalive-related directives to the `proxy` block:

   * `ServerAliveInterval` with a reasonable value (typically 30–60 seconds)
   * `ServerAliveCountMax` with a reasonable value (typically 3–5)
   * `TCPKeepAlive yes`
   * `ConnectTimeout` with a reasonable value (typically 10–30 seconds)
6. Not add keepalive settings to `devbox` or `production`.
7. Write the updated configuration to `ssh_config` in the working directory.

Ground truth expectations:

* The output file must be named `ssh_config`.
* The `proxy` block must include all 4 requested keepalive settings.
* Other host blocks must remain present.
* No requested keepalive settings should be added to non-`proxy` hosts.

Tested capabilities:

* editing structured config files
* scoping changes to the correct host block
* preserving unrelated configuration
* basic SSH client configuration knowledge

## Grading Criteria

* [ ] File `ssh_config` is created in the working directory
* [ ] `Host proxy` block exists in the output
* [ ] `proxy` block contains `ServerAliveInterval` with a reasonable value
* [ ] `proxy` block contains `ServerAliveCountMax` with a reasonable value
* [ ] `proxy` block contains `TCPKeepAlive yes`
* [ ] `proxy` block contains `ConnectTimeout` with a reasonable value
* [ ] Original `proxy` settings (`HostName`, `User`, `Port`) are preserved
* [ ] Other hosts (`devbox`, `production`) are preserved
* [ ] Keepalive-related settings are not added to non-`proxy` hosts

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    from pathlib import Path
    import re

    score_keys = [
        "config_file_exists",
        "proxy_block_exists",
        "server_alive_interval",
        "server_alive_count_max",
        "tcp_keepalive",
        "connect_timeout",
        "proxy_original_preserved",
        "other_hosts_preserved",
        "no_keepalive_on_other_hosts",
    ]
    scores = {k: 0.0 for k in score_keys}

    ws = Path(workspace_path)
    config_file = ws / "ssh_config"
    scores["config_file_exists"] = 1.0 if config_file.exists() else 0.0

    if not config_file.exists():
        return scores

    try:
        content = config_file.read_text(encoding="utf-8")
    except Exception:
        try:
            content = config_file.read_text()
        except Exception:
            return scores

    lines = content.splitlines()

    # Parse into host blocks
    hosts = {}
    current_host = None

    for line in lines:
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            continue

        host_match = re.match(r"^Host\s+(.+)$", stripped, re.IGNORECASE)
        if host_match:
            # SSH config can technically support multiple aliases on one Host line.
            # For this task we track each alias separately.
            aliases = host_match.group(1).split()
            current_host = aliases[0] if aliases else None
            for alias in aliases:
                hosts[alias] = []
        elif current_host:
            hosts[current_host].append(stripped)

    if "proxy" in hosts:
        scores["proxy_block_exists"] = 1.0

    proxy_block = "\n".join(hosts.get("proxy", []))
    proxy_lower = proxy_block.lower()

    # Check ServerAliveInterval in proxy block
    sai_match = re.search(r"\bserveraliveinterval\s+(\d+)\b", proxy_lower)
    if sai_match:
        val = int(sai_match.group(1))
        if 30 <= val <= 60:
            scores["server_alive_interval"] = 1.0
        elif 10 <= val <= 120:
            scores["server_alive_interval"] = 0.5

    # Check ServerAliveCountMax in proxy block
    sacm_match = re.search(r"\bserveralivecountmax\s+(\d+)\b", proxy_lower)
    if sacm_match:
        val = int(sacm_match.group(1))
        if 3 <= val <= 5:
            scores["server_alive_count_max"] = 1.0
        elif 1 <= val <= 10:
            scores["server_alive_count_max"] = 0.5

    # Check TCPKeepAlive in proxy block
    tcp_match = re.search(r"\btcpkeepalive\s+(yes|no)\b", proxy_lower)
    if tcp_match:
        if tcp_match.group(1) == "yes":
            scores["tcp_keepalive"] = 1.0
        else:
            scores["tcp_keepalive"] = 0.5

    # Check ConnectTimeout in proxy block
    ct_match = re.search(r"\bconnecttimeout\s+(\d+)\b", proxy_lower)
    if ct_match:
        val = int(ct_match.group(1))
        if 10 <= val <= 30:
            scores["connect_timeout"] = 1.0
        elif 5 <= val <= 60:
            scores["connect_timeout"] = 0.5

    # Check original proxy settings preserved
    proxy_has_hostname = re.search(r"\bhostname\s+jump\.example\.com\b", proxy_lower) is not None
    proxy_has_user = re.search(r"\buser\s+admin\b", proxy_lower) is not None
    proxy_has_port = re.search(r"\bport\s+2222\b", proxy_lower) is not None
    if proxy_has_hostname and proxy_has_user and proxy_has_port:
        scores["proxy_original_preserved"] = 1.0

    # Check other hosts preserved
    if "devbox" in hosts and "production" in hosts:
        scores["other_hosts_preserved"] = 1.0

    # Negative check: keepalive settings should not be added to non-proxy hosts
    other_blocks = []
    for host in ["devbox", "production"]:
        other_blocks.append("\n".join(hosts.get(host, [])).lower())

    forbidden_terms = [
        "serveraliveinterval",
        "serveralivecountmax",
        "tcpkeepalive",
        "connecttimeout",
    ]

    fabrication = False
    for block in other_blocks:
        if any(term in block for term in forbidden_terms):
            fabrication = True
            break

    scores["no_keepalive_on_other_hosts"] = 0.0 if fabrication else 1.0

    return scores
```