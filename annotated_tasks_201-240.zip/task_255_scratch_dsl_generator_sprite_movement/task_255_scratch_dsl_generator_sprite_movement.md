---
id: task_255_scratch_dsl_generator_sprite_movement
name: Scratch DSL Generator - Sprite Movement
category: Data Analysis
subcategory: Data Processing and Management
difficulty: medium
external_dependency: none
verification_method: unit-test
input_modality: text-only
grading_type: automated
grading_weights:
  automated: 1.0
timeout_seconds: 120
workspace_files: []
source_line_number: 1575
source_query: "按照 Canonical Scratch DSL v1.2 生成可直接应用到 Scratch 的 DSL：仅输出 1 个严格 JSON 的 ```json``` 代码块，顶层格式为 {\"scripts\":[{\"hat\":\"event_whenflagclicked\",\"hatId\":\"event_whenflagclicked\",\"body\":[...]}]}。实现一个新角色在舞台上左右来回移动。"
---

## Prompt

Hey, I need you to generate a Scratch DSL JSON file for me. I'm using the Canonical Scratch DSL v1.2 format.

The DSL format is strict:
- Top level must be `{"scripts":[{"hat":<opcode>,"hatId":<opcode>,"body":[...]}]}`
- The `hat` and `hatId` fields must match each other exactly
- Use standard Scratch block opcodes like `event_whenflagclicked`, `control_forever`, `motion_movesteps`, `motion_ifonedgebounce`, `motion_pointindirection`, etc.

I want to create a sprite that moves back and forth across the stage continuously. When the green flag is clicked, it should start moving horizontally, and when it hits an edge it should bounce back and keep going.

Save the output to `scratch_dsl.json` - just the JSON, nothing else in the file.

## Expected Behavior

The agent should:
1. Create a valid JSON file with the exact top-level structure required
2. Use `event_whenflagclicked` as both `hat` and `hatId` (they must be identical strings)
3. Include a forever loop (`control_forever`) for continuous movement — the forever block should contain a nested body/substack with the movement blocks inside it
4. Include motion blocks for moving steps (`motion_movesteps`)
5. Include edge bounce logic (`motion_ifonedgebounce`)
6. Optionally set initial direction for horizontal movement

Tested capabilities: JSON generation, understanding DSL specifications, Scratch programming concepts.

**Trap handling — the agent should correctly navigate the following traps:**

- **hat and hatId must be identical**: The DSL spec requires both `hat` and `hatId` to be set to the same opcode string (e.g., both `"event_whenflagclicked"`). Setting only one, or setting them to different values, violates the spec.
- **control_forever requires a nested body**: The `control_forever` block is not just a label — it must contain a nested structure (typically a `body` or `substack` field) that holds the blocks to repeat. Simply listing `control_forever` as a flat entry in the body array without nested movement blocks is structurally incorrect.

## Grading Criteria

- [ ] File `scratch_dsl.json` exists
- [ ] Valid JSON structure
- [ ] Top-level has "scripts" array
- [ ] Script has matching "hat" and "hatId" fields (identical strings)
- [ ] Uses `event_whenflagclicked` as the hat block
- [ ] Contains a forever loop for continuous movement
- [ ] Contains motion_movesteps or equivalent movement block
- [ ] Contains motion_ifonedgebounce for bouncing
- [ ] No fabricated/invalid block opcodes

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    from pathlib import Path
    import json

    scores = {}
    ws = Path(workspace_path)

    dsl_file = ws / "scratch_dsl.json"
    scores["file_exists"] = 1.0 if dsl_file.exists() else 0.0

    if not dsl_file.exists():
        scores["valid_json"] = 0.0
        scores["has_scripts_array"] = 0.0
        scores["hat_hatid_match"] = 0.0
        scores["uses_flag_clicked"] = 0.0
        scores["has_forever_loop"] = 0.0
        scores["has_move_block"] = 0.0
        scores["has_bounce_block"] = 0.0
        scores["no_invalid_opcodes"] = 0.0
        return scores

    content = dsl_file.read_text(errors="ignore")
    try:
        data = json.loads(content)
        scores["valid_json"] = 1.0
    except Exception:
        scores["valid_json"] = 0.0
        scores["has_scripts_array"] = 0.0
        scores["hat_hatid_match"] = 0.0
        scores["uses_flag_clicked"] = 0.0
        scores["has_forever_loop"] = 0.0
        scores["has_move_block"] = 0.0
        scores["has_bounce_block"] = 0.0
        scores["no_invalid_opcodes"] = 0.0
        return scores

    if isinstance(data, dict) and "scripts" in data and isinstance(data["scripts"], list):
        scores["has_scripts_array"] = 1.0
    else:
        scores["has_scripts_array"] = 0.0
        scores["hat_hatid_match"] = 0.0
        scores["uses_flag_clicked"] = 0.0
        scores["has_forever_loop"] = 0.0
        scores["has_move_block"] = 0.0
        scores["has_bounce_block"] = 0.0
        scores["no_invalid_opcodes"] = 0.0
        return scores

    scripts = data.get("scripts", [])
    if len(scripts) == 0:
        scores["hat_hatid_match"] = 0.0
        scores["uses_flag_clicked"] = 0.0
        scores["has_forever_loop"] = 0.0
        scores["has_move_block"] = 0.0
        scores["has_bounce_block"] = 0.0
        scores["no_invalid_opcodes"] = 0.0
        return scores

    script = scripts[0]
    hat = script.get("hat", "")
    hat_id = script.get("hatId", "")
    scores["hat_hatid_match"] = 1.0 if hat == hat_id and hat != "" else 0.0
    scores["uses_flag_clicked"] = 1.0 if hat == "event_whenflagclicked" else 0.0

    content_str = json.dumps(data).lower()

    scores["has_forever_loop"] = 1.0 if "control_forever" in content_str else 0.0

    move_opcodes = ["motion_movesteps", "motion_gotoxy", "motion_changexby", "motion_glideto"]
    has_move = any(kw in content_str for kw in move_opcodes)
    scores["has_move_block"] = 1.0 if has_move else 0.0

    bounce_opcodes = ["motion_ifonedgebounce"]
    has_bounce = any(kw in content_str for kw in bounce_opcodes)
    scores["has_bounce_block"] = 1.0 if has_bounce else 0.0

    # Collect all opcode values from the JSON structure
    valid_prefixes = [
        "event_", "control_", "motion_", "looks_", "sound_",
        "sensing_", "operator_", "data_", "procedures_", "pen_", "music_"
    ]

    def find_opcodes(obj, opcodes):
        if isinstance(obj, dict):
            for k, v in obj.items():
                if k in ["opcode", "op", "block", "hat", "hatId"] and isinstance(v, str) and v:
                    opcodes.append(v)
                else:
                    find_opcodes(v, opcodes)
        elif isinstance(obj, list):
            for item in obj:
                find_opcodes(item, opcodes)

    all_opcodes = []
    find_opcodes(data, all_opcodes)

    invalid_found = False
    for opcode in all_opcodes:
        if opcode and not any(opcode.startswith(p) for p in valid_prefixes):
            invalid_found = True
            break

    scores["no_invalid_opcodes"] = 0.0 if invalid_found else 1.0

    return scores
```