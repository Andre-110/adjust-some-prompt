| 序号 | 修改项 | 修改原因 |
|---|---|---|
| 1 | 精简并重写 Prompt 开头说明 | 原 Prompt 基本清楚，但措辞略重复，整理后更直接、更易执行 |
| 2 | 保留 policy examples，但去掉多余解释性引导 | 原题示例较多且几乎直接把求解模式铺平，虽然仍可保留规则示例，但应减少不必要提示 |
| 3 | 将 Prompt 结尾要求明确为“只输出 prefix” | 与 output-check 任务强绑定，减少模型输出解释文本的空间 |
| 4 | 重写 Expected Behavior | 原版几乎是一步步把答案推出，泄露答案较重；新版保留必要推理路径，但更聚焦于可验证行为 |
| 5 | 在 Expected Behavior 中补充 Ground truth | 满足“答案明确、可验证”的要求 |
| 6 | 明确列出错误 special-case 输出 | 使 `command_injection_detected` 和 `none` 两类错误更容易被区分评分 |
| 7 | 重写 Grading Criteria | 原标准有重复性，且“Output contains git merge”过宽；新版改为“exactly git merge”与“无额外文本”更独立 |
| 8 | 将“输出包含 git merge”改为“输出精确等于 git merge” | 原检查过松，可能让带解释的回答通过，无法体现 output-only 要求 |
| 9 | 增加“无额外 explanation / punctuation / surrounding text”条目 | 强化对 output-check 任务格式约束的覆盖 |
| 10 | 重写 automated checks 的 score key | 使 score key 与 Grading Criteria 更接近一一对应，满足 Key 对齐要求 |
| 11 | 移除原有 `concise_output = 0.5` 的宽松逻辑 | 原逻辑允许带解释文本也拿较高分，不符合“Only output the prefix”要求 |
| 12 | 使用严格相等判断 `lowered == "git merge"` | 提高评分区分度，避免包含 `git merge` 的冗余回答误判为正确 |
| 13 | 改进 transcript 提取逻辑 | 保持兼容字符串内容和结构化 content 列表，提高稳健性 |
| 14 | 删除“reasonably concise”这类主观标准 | 按规范要求，评分项应尽量独立且可客观验证 |