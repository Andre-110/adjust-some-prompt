---
id: task_213_cross_platform_rust_audio_player_core
name: Cross-Platform Rust Audio Player Core
category: Automation
subcategory: Workflow and Task Scheduling
difficulty: hard
external_dependency: none
verification_method: rubric
input_modality: text-only
grading_type: hybrid
timeout_seconds: 300
grading_weights:
  automated: 0.3
  llm_judge: 0.7
workspace_files: []
source_line_number: 199
source_query: "Design and implement a cross-platform Rust audio player core that includes: playback queue management (add/remove/reorder/clear/persist), play modes (sequential, shuffle, repeat one, repeat all), playback controls (play/pause/stop/prev/next/seek/speed), a caching system (e.g., LRU with prefetch), streaming download while playing, a DSP processing pipeline, unified audio stream parsing/decoding, and FFT (and optionally RMS) telemetry output for a frontend UI."
---

## Prompt

I need a Rust library that serves as the core of a cross-platform audio player. It should be organized like a real reusable backend library, not just a single demo file.

Please create the project under `audio_player/` with these files:

- `Cargo.toml`
- `src/lib.rs`
- `src/queue.rs`
- `src/playback.rs`
- `src/cache.rs`
- `src/streaming.rs`
- `src/dsp.rs`
- `src/decoder.rs`
- `src/telemetry.rs`
- `DESIGN.md`

The library should cover these capabilities:

1. **Playback queue management**
   - add, remove, reorder, and clear tracks
   - persist and reload the queue
   - support track metadata such as:

```json
{
  "tracks": [
    {"id": "t001", "title": "Summer Nights", "artist": "The Waves", "duration_ms": 234000, "url": "https://cdn.example.com/tracks/summer_nights.mp3"},
    {"id": "t002", "title": "Mountain Echo", "artist": "Alpine", "duration_ms": 198000, "url": "https://cdn.example.com/tracks/mountain_echo.flac"},
    {"id": "t003", "title": "City Lights", "artist": "Urban Beat", "duration_ms": 267000, "url": "https://cdn.example.com/tracks/city_lights.ogg"},
    {"id": "t004", "title": "Ocean Breeze", "artist": "The Waves", "duration_ms": 312000, "url": "https://cdn.example.com/tracks/ocean_breeze.mp3"},
    {"id": "t005", "title": "Forest Rain", "artist": "Nature Sound", "duration_ms": 285000, "url": "https://cdn.example.com/tracks/forest_rain.wav"}
  ]
}
````

2. **Play modes**

   * sequential
   * shuffle
   * repeat one
   * repeat all

3. **Playback controls**

   * play
   * pause
   * stop
   * previous / next
   * seek
   * playback speed adjustment

4. **Caching and prefetch**

   * design a cache for downloaded audio data
   * include a prefetch strategy for upcoming playback

5. **Streaming while downloading**

   * audio data should be consumable progressively rather than requiring a full download first
   * include buffer management abstractions

6. **DSP pipeline**

   * support at least volume adjustment
   * make the processing chain extensible for future effects

7. **Unified decoding/parsing layer**

   * expose a common interface for formats such as mp3, flac, ogg, and wav

8. **Telemetry for frontend visualization**

   * provide FFT output
   * RMS output is optional but recommended

9. **Cross-platform design**

   * the architecture should be suitable for Windows, macOS, and Linux

Also write `DESIGN.md` describing the architecture, major components, data flow, and important design decisions.

You do not need to build a fully production-ready audio engine or OS-specific output backend, but the code should present a coherent, realistic, extensible design rather than placeholders only.

## Expected Behavior

A strong solution should:

1. Create the required `audio_player/` directory structure and all requested files.

2. Provide a coherent Rust library structure with clearly separated modules for:

   * queue management
   * playback state and controls
   * caching/prefetch
   * streaming/buffering
   * DSP
   * decoding
   * telemetry

3. Implement a queue model with:

   * track metadata structures
   * add/remove/reorder/clear operations
   * persistence and reload support

4. Define playback state and play mode abstractions that cover:

   * sequential
   * shuffle
   * repeat one
   * repeat all
   * previous / next navigation
   * play / pause / stop
   * seek and playback speed

5. Include a cache design that clearly represents:

   * bounded storage behavior
   * eviction strategy
   * prefetch behavior for likely upcoming data

6. Include a streaming abstraction showing how:

   * audio bytes/chunks are downloaded incrementally
   * buffered data becomes available to decoding/playback
   * playback can proceed before the full file is downloaded

7. Include an extensible DSP pipeline:

   * at minimum one concrete effect such as volume adjustment
   * a composable trait/processor chain or equivalent abstraction

8. Include a unified decoder interface:

   * a trait or equivalent abstraction for decoding audio streams
   * explicit support for mp3, flac, ogg, and wav in the design/API surface

9. Include telemetry support:

   * FFT output representation suitable for UI visualization
   * optional RMS support earns additional credit but is not mandatory for core correctness

10. Address cross-platform concerns through abstraction boundaries, conditional compilation, or backend-agnostic design choices.

11. Document the architecture in `DESIGN.md`, including:

* module responsibilities
* data flow between streaming, decoding, DSP, playback, and telemetry
* tradeoffs and extensibility considerations

Ground-truth expectations:

* This task does **not** require a fully working speaker-output backend.
* This task does **not** require real network/audio integration to be production-complete.
* It **does** require realistic Rust module design and meaningful code skeletons/interfaces, rather than empty placeholder files.

Key traps and correct handling:

* Do not collapse everything into a single oversized module.
* Do not omit either `repeat one` or `repeat all`.
* Do not treat “cross-platform” as a claim only; the code or design should show an actual portability strategy.
* Do not provide only comments/TODOs with no meaningful types, traits, or method structure.

## Grading Criteria

* [ ] The `audio_player/` directory and all required files are created
* [ ] `Cargo.toml` is valid-looking TOML and defines a Rust library crate
* [ ] `src/lib.rs` exposes all required modules
* [ ] Queue management includes track data structures and add/remove/reorder/clear/persist logic
* [ ] Playback logic includes all four play modes: sequential, shuffle, repeat one, and repeat all
* [ ] Playback controls include play, pause, stop, previous, next, seek, and playback speed support
* [ ] Cache design includes bounded storage/eviction behavior and prefetch support
* [ ] Streaming design includes incremental download and buffer management concepts
* [ ] DSP module provides an extensible processing pipeline with at least volume adjustment
* [ ] Decoder module exposes a unified interface covering mp3, flac, ogg, and wav
* [ ] Telemetry module provides FFT output; RMS support may strengthen the solution
* [ ] Cross-platform strategy is addressed in code or design documentation
* [ ] `DESIGN.md` explains architecture, component interaction, and design decisions
* [ ] The implementation is substantive and not mostly empty placeholders/TODO stubs

## Automated Checks

```python id="ab3s0d"
def grade(transcript: list, workspace_path: str) -> dict:
    from pathlib import Path
    import re

    scores = {}
    ws = Path(workspace_path)
    ap = ws / "audio_player"
    src = ap / "src"

    all_score_keys = [
        "dir_and_files_exist",
        "cargo_valid",
        "lib_exports_modules",
        "queue_management",
        "play_modes",
        "playback_controls",
        "cache_and_prefetch",
        "streaming_buffering",
        "dsp_pipeline",
        "decoder_unified",
        "telemetry_fft",
        "cross_platform",
        "design_doc",
        "substantive_implementation",
    ]

    required_files = [
        ap / "Cargo.toml",
        ap / "DESIGN.md",
        src / "lib.rs",
        src / "queue.rs",
        src / "playback.rs",
        src / "cache.rs",
        src / "streaming.rs",
        src / "dsp.rs",
        src / "decoder.rs",
        src / "telemetry.rs",
    ]

    if not ap.is_dir():
        for key in all_score_keys:
            scores[key] = 0.0
        return scores

    scores["dir_and_files_exist"] = 1.0 if all(p.exists() for p in required_files) else 0.0

    def read_text(path: Path) -> str:
        try:
            return path.read_text(encoding="utf-8")
        except Exception:
            try:
                return path.read_text()
            except Exception:
                return ""

    def norm(s: str) -> str:
        return s.lower()

    cargo = ap / "Cargo.toml"
    cargo_text = read_text(cargo)
    if cargo_text:
        has_package = "[package]" in cargo_text
        has_lib_or_src = ("[lib]" in cargo_text) or ('src/lib.rs' in cargo_text) or ('path = "src/lib.rs"' in cargo_text)
        has_name = re.search(r'(?m)^\s*name\s*=\s*["\'].*?["\']\s*$', cargo_text) is not None
        has_version = re.search(r'(?m)^\s*version\s*=\s*["\'].*?["\']\s*$', cargo_text) is not None
        scores["cargo_valid"] = 1.0 if (has_package and has_name and has_version) else 0.5 if (has_package and has_name) else 0.0
    else:
        scores["cargo_valid"] = 0.0

    lib_rs = src / "lib.rs"
    lib_text = norm(read_text(lib_rs))
    modules = ["queue", "playback", "cache", "streaming", "dsp", "decoder", "telemetry"]
    if lib_text:
        found = sum(
            1 for m in modules
            if f"pub mod {m}" in lib_text or f"mod {m}" in lib_text
        )
        scores["lib_exports_modules"] = found / len(modules)
    else:
        scores["lib_exports_modules"] = 0.0

    queue_rs = src / "queue.rs"
    queue_text = norm(read_text(queue_rs))
    if queue_text:
        structure_terms = ["track", "queue"]
        op_terms = ["add", "remove", "reorder", "clear", "persist", "save", "load"]
        structure_found = sum(1 for t in structure_terms if t in queue_text)
        op_found = sum(1 for t in op_terms if t in queue_text)
        structural_score = 0.4 if structure_found == len(structure_terms) else 0.2 if structure_found > 0 else 0.0
        operational_score = min(op_found / 5, 0.6)
        scores["queue_management"] = min(structural_score + operational_score, 1.0)
    else:
        scores["queue_management"] = 0.0

    playback_rs = src / "playback.rs"
    playback_text = norm(read_text(playback_rs))
    if playback_text:
        mode_terms = {
            "sequential": ["sequential"],
            "shuffle": ["shuffle"],
            "repeat_one": ["repeatone", "repeat_one", "repeat one"],
            "repeat_all": ["repeatall", "repeat_all", "repeat all"],
        }
        mode_found = 0
        for variants in mode_terms.values():
            if any(v in playback_text.replace("-", "_") for v in variants):
                mode_found += 1
        scores["play_modes"] = mode_found / 4

        control_terms = ["play", "pause", "stop", "seek", "speed", "next", "prev", "previous"]
        control_found = 0
        matched = set()
        for term in control_terms:
            if term in playback_text:
                canonical = "prev" if term == "previous" else term
                matched.add(canonical)
        control_found = len(matched)
        scores["playback_controls"] = min(control_found / 7, 1.0)
    else:
        scores["play_modes"] = 0.0
        scores["playback_controls"] = 0.0

    cache_rs = src / "cache.rs"
    cache_text = norm(read_text(cache_rs))
    if cache_text:
        cache_terms = ["lru", "evict", "capacity", "bounded", "least recently used"]
        prefetch_terms = ["prefetch", "preload", "ahead", "next track", "upcoming"]
        cache_score = 1.0 if any(t in cache_text for t in cache_terms) else 0.5 if "cache" in cache_text else 0.0
        prefetch_score = 1.0 if any(t in cache_text for t in prefetch_terms) else 0.0
        scores["cache_and_prefetch"] = 0.5 * cache_score + 0.5 * prefetch_score
    else:
        scores["cache_and_prefetch"] = 0.0

    streaming_rs = src / "streaming.rs"
    streaming_text = norm(read_text(streaming_rs))
    if streaming_text:
        stream_terms = ["stream", "download", "chunk", "buffer", "progressive", "incremental"]
        found = sum(1 for t in stream_terms if t in streaming_text)
        scores["streaming_buffering"] = min(found / 4, 1.0)
    else:
        scores["streaming_buffering"] = 0.0

    dsp_rs = src / "dsp.rs"
    dsp_text = norm(read_text(dsp_rs))
    if dsp_text:
        pipeline_terms = ["pipeline", "chain", "processor", "effect", "process"]
        volume_terms = ["volume", "gain"]
        has_pipeline = any(t in dsp_text for t in pipeline_terms)
        has_volume = any(t in dsp_text for t in volume_terms)
        scores["dsp_pipeline"] = 1.0 if (has_pipeline and has_volume) else 0.5 if (has_pipeline or has_volume) else 0.0
    else:
        scores["dsp_pipeline"] = 0.0

    decoder_rs = src / "decoder.rs"
    decoder_text = norm(read_text(decoder_rs))
    if decoder_text:
        has_trait_like = any(t in decoder_text for t in ["trait", "interface", "decode", "decoder"])
        formats = ["mp3", "flac", "ogg", "wav"]
        format_found = sum(1 for f in formats if f in decoder_text)
        base = 0.4 if has_trait_like else 0.0
        scores["decoder_unified"] = min(base + (format_found / 4) * 0.6, 1.0)
    else:
        scores["decoder_unified"] = 0.0

    telemetry_rs = src / "telemetry.rs"
    telemetry_text = norm(read_text(telemetry_rs))
    if telemetry_text:
        has_fft = any(t in telemetry_text for t in ["fft", "fourier", "spectrum", "frequency"])
        has_rms = any(t in telemetry_text for t in ["rms", "root mean square"])
        scores["telemetry_fft"] = 1.0 if has_fft else 0.0
        if has_rms:
            scores["telemetry_fft"] = min(scores["telemetry_fft"] + 0.0, 1.0)
    else:
        scores["telemetry_fft"] = 0.0

    design_md = ap / "DESIGN.md"
    design_text = norm(read_text(design_md))
    if design_text:
        design_terms = ["architecture", "module", "component", "flow", "design", "playback", "streaming", "decoder", "dsp", "telemetry"]
        found = sum(1 for t in design_terms if t in design_text)
        scores["design_doc"] = min(found / 5, 1.0)
    else:
        scores["design_doc"] = 0.0

    all_text = "\n".join(
        read_text(p) for p in required_files
        if p.exists() and p.suffix in {".rs", ".md", ".toml"}
    ).lower()

    cross_terms = [
        "cfg(target",
        "cfg!(",
        "windows",
        "macos",
        "linux",
        "cross-platform",
        "backend-agnostic",
        "platform abstraction",
    ]
    scores["cross_platform"] = 1.0 if any(t in all_text for t in cross_terms) else 0.0

    rs_files = [src / name for name in ["lib.rs", "queue.rs", "playback.rs", "cache.rs", "streaming.rs", "dsp.rs", "decoder.rs", "telemetry.rs"]]
    existing_rs = [p for p in rs_files if p.exists()]
    total_lines = 0
    todo_count = 0
    non_comment_code_lines = 0

    for f in existing_rs:
        text = read_text(f)
        total_lines += len(text.splitlines())
        todo_count += text.lower().count("todo!()") + text.lower().count("todo:")
        for line in text.splitlines():
            stripped = line.strip()
            if stripped and not stripped.startswith("//"):
                non_comment_code_lines += 1

    if not existing_rs:
        scores["substantive_implementation"] = 0.0
    else:
        if non_comment_code_lines >= 120 and todo_count <= 8:
            scores["substantive_implementation"] = 1.0
        elif non_comment_code_lines >= 60 and todo_count <= 15:
            scores["substantive_implementation"] = 0.5
        else:
            scores["substantive_implementation"] = 0.0

    for key in all_score_keys:
        if key not in scores:
            scores[key] = 0.0

    return scores
```

## LLM Judge Rubric

### grading_weights

* automated: 0.3
* llm_judge: 0.7

### Dimension 1: Architecture Quality (Weight: 30%)

* 1.0: Excellent separation of concerns with clear module responsibilities and interfaces. The design is realistic, extensible, and appropriate for a reusable Rust audio-player core.
* 0.75: Good modular architecture with mostly clear boundaries. Minor coupling issues or a few underdeveloped abstractions.
* 0.5: Functional architecture, but several responsibilities are mixed together or insufficiently abstracted.
* 0.25: Weak architecture with unclear module boundaries or heavily monolithic design.
* 0.0: No coherent architecture; modules appear arbitrary or disconnected.

### Dimension 2: Feature Coverage and Audio-System Design (Weight: 30%)

* 1.0: Covers queueing, play modes, controls, streaming, caching/prefetch, DSP, decoding, telemetry, and cross-platform concerns in a coherent way. The design reflects realistic audio-system thinking.
* 0.75: Covers most requested features with only minor omissions or simplifications.
* 0.5: Covers only the main features, with several important missing capabilities or shallow treatment of audio concepts.
* 0.25: Covers a limited subset of the requested system with major omissions.
* 0.0: Fails to address most of the requested functionality.

### Dimension 3: Rust Code Quality and Technical Realism (Weight: 25%)

* 1.0: Uses idiomatic Rust structures such as traits, enums, structs, and error-aware APIs appropriately. The code is technically plausible and would be a strong starting point for real implementation.
* 0.75: Mostly solid Rust code with a few non-idiomatic choices or minor technical weaknesses.
* 0.5: Understandable Rust code, but simplistic, inconsistent, or only partially realistic.
* 0.25: Poor Rust quality, weak API design, or heavy reliance on placeholders.
* 0.0: Fundamentally broken or implausible Rust implementation.

### Dimension 4: Documentation and Design Explanation (Weight: 15%)

* 1.0: `DESIGN.md` clearly explains module responsibilities, data flow, major tradeoffs, and extensibility decisions. It is easy to understand how the system fits together.
* 0.75: Good documentation with clear architecture explanation and only minor gaps.
* 0.5: Basic documentation that explains the structure but lacks depth or interaction details.
* 0.25: Minimal documentation with limited architectural value.
* 0.0: Missing or non-meaningful documentation.
