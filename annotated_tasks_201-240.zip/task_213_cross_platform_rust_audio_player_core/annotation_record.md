| 序号 | 修改项 | 修改原因 |
|---|---|---|
| 1 | 将 `difficulty` 从 `expert` 改为 `hard` | 原题要求复杂，但更偏架构设计与模块化实现，不要求完整生产级音频引擎，和 `expert` 不匹配 |
| 2 | 保持 frontmatter、代码、文件路径、rubric 为英文 | 原文件整体任务规格是英文，应保持一致 |
| 3 | 保持 Prompt 为英文 | 原题用户请求本身为英文工程需求，不应强行改成中文 |
| 4 | 重写 Prompt，使需求更自然、更像真实工程请求 | 原 Prompt 有些“列清单式考试题”风格，修正后更接近真实开发需求 |
| 5 | 在 Prompt 中明确“需要真实可扩展设计，但不要求完整生产级音频引擎或 OS 输出后端” | 避免任务边界不清，降低不必要歧义 |
| 6 | 保留并整理所需目录结构要求 | 目录输出是本题核心交付物，需要明确且可评分 |
| 7 | 重写 Expected Behavior，使其覆盖完整解题路径 | 原版本列点较粗，缺少对“完成度”和“可接受抽象层级”的界定 |
| 8 | 在 Expected Behavior 中加入 Ground-truth expectations | 说明此题不要求真实可播放后端，但必须有有意义的模块设计与代码骨架 |
| 9 | 在 Expected Behavior 中补充陷阱说明 | 按规范，应说明真实陷阱及正确处理方式，如不能遗漏 `repeat one` / `repeat all`、不能只写 TODO |
| 10 | 重写 Grading Criteria，使条目更独立可验证 | 原条目与自动检查未完全对齐，且有些条目表述过泛 |
| 11 | 新增 “implementation is substantive and not mostly empty placeholders/TODO stubs” | 原题只检查功能词命中，无法约束大量空文件/占位实现 |
| 12 | 重写 `grade()`，增加统一空白零分逻辑 | 满足“主输出不存在时所有 score key 返回 0.0”要求 |
| 13 | 在 `grade()` 中显式检查所有必需文件是否存在 | 原版只检查目录，未统一覆盖所有必需文件 |
| 14 | 改进 `Cargo.toml` 检查逻辑 | 原版仅看 `[package]` 和 `name`，过于宽松；新版增加 `version` 等合理约束 |
| 15 | 改进 `lib.rs` 模块导出检查 | 保持评分可分级，同时更稳健 |
| 16 | 改进 `queue` 检查逻辑 | 原版仅靠关键词粗扫且分母不合理；新版同时检查结构与操作，部分得分更合理 |
| 17 | 改进 `play_modes` 检查逻辑 | 原版只检查 `repeat` 无法区分 `repeat one` 与 `repeat all`，新版分别检查四种模式 |
| 18 | 改进 `playback_controls` 检查逻辑 | 原版分母与控制项数量不完全匹配，且 `prev/previous` 未归一；新版做了归一处理 |
| 19 | 合并 `cache_lru` 与 `cache_prefetch` 为 `cache_and_prefetch` | 与 Grading Criteria 更一致，避免 score key 过细且不对齐 |
| 20 | 将 `streaming_buffer` 改为 `streaming_buffering` | 使 key 与评分项语义更一致 |
| 21 | 保留并优化 `dsp_pipeline`、`decoder_unified`、`telemetry_fft` 的部分得分逻辑 | 满足部分得分要求，并提升评分区分度 |
| 22 | 将 cross-platform 检查扩大到代码和文档整体 | 原版仅扫描 `.rs` 文件，可能漏掉 DESIGN.md 中的真实平台策略说明 |
| 23 | 用 `substantive_implementation` 取代原 `no_fabrication` | 原 `no_fabrication` 几乎无效，只数 `todo!()`；新版更贴近“是否大多为空壳实现” |
| 24 | 补充 `LLM Judge Rubric` 的 `grading_weights` 小节 | 与 hybrid grading 结构明确对齐 |
| 25 | 规范化 LLM Judge Rubric 为 4 个 Dimension | 满足“至少 3 个评分维度”要求，并保持原题强调的架构/功能/代码/文档四层结构 |