---
id: task_245_bfs_flood_fill_test_case_generator
name: BFS Flood Fill Test Case Generator
category: Data Analysis
subcategory: Data Processing and Management
difficulty: medium
external_dependency: none
verification_method: unit-test
input_modality: text-only
grading_type: hybrid
grading_weights:
  automated: 0.5
  llm_judge: 0.5
timeout_seconds: 180
workspace_files: []
source_line_number: 5307
source_query: "根据下面题意与给定参考 C++ 代码，生成 10 组合法输入样例（覆盖：最小规模；两组最大规模（极端/随机）；边界/特殊情况（全高于泉眼、全不高于泉眼、仅泉眼可达、狭长地图等）；普通情况；综合情况），并提供一段 C++ 代码将这 10 组样例分别写入 A1.in~A10.in。  题意（摘要）：给定 n×m 高度网格（n,m≤1000），泉眼在 (p1,p2)，水位固定为 h=a[p1][p2]。水从泉眼出发只能在网格内按 4 邻接传播到高度 ≤ h 的格子，高于 h 的格子不可进入也不可越过。求最终可被水淹没（从泉眼可达且高度≤h）的格子数。 输入格式：n m p1 p2 接着 n 行每行 m 个整数高度。 输出：被水淹没格子数。 参考代码：见用户提供代码段。"
---

## Prompt

I have this competitive programming problem and a reference solution. I need to generate 10 test cases for it and write C++ code to save them to files.

**Problem Summary:**
Given an n×m height grid (n,m ≤ 1000), there's a spring at position (p1, p2). The water level is fixed at h = a[p1][p2]. Water flows from the spring and can only spread to 4-adjacent cells within the grid that have height ≤ h. Cells with height > h cannot be entered or crossed. Count how many cells get flooded (reachable from spring with height ≤ h).

**Input format:**
- First line: n m p1 p2
- Next n lines: m integers each (heights)

**Output:** Number of flooded cells

**Sample:**
```
3 5 2 3
3 4 1 5 1
2 3 3 4 7
4 1 4 1 1
```
Output: 6

**Reference C++ solution:**
```cpp
#include<bits/stdc++.h>
using namespace std;

int a[1010][1010],q[1000100][3];
bool b[1010][1010];
int fx[5]={0,0,1, 0,-1};
int fy[5]={0,1,0,-1, 0};
int n,m,p1,p2;
int head=1,tail=1;
int main(){
    ios::sync_with_stdio(0),cin.tie(0),cout.tie(0);
    cin>>n>>m>>p1>>p2;
    for(int i=1;i<=n;i++){
        for(int j=1;j<=m;j++) cin>>a[i][j];
    }
    int h=a[p1][p2];
    b[p1][p2]=1;
    q[head][1]=p1,q[head][2]=p2;
    while(head<=tail){
        for(int i=1;i<=4;i++){
            int tx=q[head][1]+fx[i];
            int ty=q[head][2]+fy[i];
            if(tx>=1&&tx<=n&&ty>=1&&ty<=m&&b[tx][ty]==0&&a[tx][ty]<=h){
                tail++;
                b[tx][ty]=1;
                q[tail][1]=tx,q[tail][2]=ty;
            }
        }
        head++;
    }
    cout<<tail;
    return 0;
}
```

Generate 10 valid test cases covering these scenarios:
1. Minimum size (1×1 grid)
2. Maximum size with extreme pattern (1000×1000, spring at corner, all cells same height)
3. Maximum size random (1000×1000, random heights 1-1000000)
4. All cells higher than spring (only spring floods)
5. All cells equal or lower than spring (entire grid floods)
6. Only spring reachable (surrounded by walls)
7. Narrow/elongated map (1000×1 or 1×1000)
8. Spring at corner
9. Normal mixed case
10. Complex case with islands and barriers

Then write C++ code that generates these 10 test cases and saves them to A1.in through A10.in. Save the C++ code to `generator.cpp`.

## Expected Behavior

The agent should:
1. Design 10 test cases covering minimum size, maximum size (extreme and random), edge cases (all higher, all lower, isolated spring, narrow maps), and mixed scenarios
2. Write valid C++ code that generates these test cases
3. The code should use proper file I/O to write to A1.in through A10.in
4. All test cases must satisfy constraints (n,m ≤ 1000, valid p1/p2 within bounds)
5. Save the generator code to generator.cpp

**Trap handling — the agent should correctly navigate the following traps:**

- **1-based coordinates**: The reference solution uses 1-based indexing — rows and columns are indexed from 1. Therefore p1 must be in [1, n] and p2 must be in [1, m]. Generating p1=0 or p2=0 would cause the reference code to access `a[0][j]` which is outside the intended range and produces wrong output. All generated test cases must use 1-based p1 and p2.
- **Isolated spring construction**: For test case 6 (only spring reachable), the correct approach is to set the spring's height to some value h, then set all 4 orthogonal neighbors to height > h. Simply surrounding with "walls" using a large value is correct; forgetting to handle corner/edge springs (which have fewer than 4 neighbors) is a subtle error.
- **Narrow map output format**: For a 1000×1 grid, each row has exactly 1 integer. The generator must output 1000 rows of 1 number each, not 1 row of 1000 numbers.

## Grading Criteria

- [ ] File `generator.cpp` exists
- [ ] Code compiles (valid C++ syntax with includes and main function)
- [ ] Uses proper file output (ofstream, freopen, or fopen) to write A1.in through A10.in
- [ ] Contains minimum size test (1×1 grid with n=1, m=1)
- [ ] Contains maximum size test (1000×1000 grid)
- [ ] Contains narrow map test (1000×1 or 1×1000)
- [ ] Contains isolated spring test (spring surrounded by higher-valued cells)
- [ ] Generates references to all 10 output files (A1.in through A10.in)
- [ ] Spring coordinates p1/p2 are 1-based (p1 ≥ 1 and p2 ≥ 1 in all test cases)

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    from pathlib import Path
    import re

    scores = {}
    ws = Path(workspace_path)

    gen_file = ws / "generator.cpp"
    scores["generator_exists"] = 1.0 if gen_file.exists() else 0.0

    if not gen_file.exists():
        scores["has_main"] = 0.0
        scores["has_includes"] = 0.0
        scores["has_file_output"] = 0.0
        scores["has_min_size"] = 0.0
        scores["has_max_size"] = 0.0
        scores["has_narrow_map"] = 0.0
        scores["has_isolated_spring"] = 0.0
        scores["generates_10_files"] = 0.0
        scores["coordinates_1based"] = 0.0
        return scores

    code = gen_file.read_text(errors="ignore")

    scores["has_main"] = 1.0 if re.search(r'\bint\s+main\s*\(', code) else 0.0
    scores["has_includes"] = 1.0 if re.search(r'#include\s*<', code) else 0.0

    has_ofstream = "ofstream" in code
    has_freopen = "freopen" in code
    has_fopen = "fopen" in code
    scores["has_file_output"] = 1.0 if (has_ofstream or has_freopen or has_fopen) else 0.0

    # Match "1 1 1 1" pattern in string literals (the first line of a 1x1 test case)
    # or assignment patterns like n=1, m=1 together
    has_1x1 = bool(
        re.search(r'"1\s+1\s+1\s+1"', code) or
        re.search(r'out\s*<<\s*"?1\s+1\s+1\s+1"?', code) or
        re.search(r'(n\s*=\s*1\b.*m\s*=\s*1\b|m\s*=\s*1\b.*n\s*=\s*1\b)', code)
    )
    scores["has_min_size"] = 1.0 if has_1x1 else 0.0

    scores["has_max_size"] = 1.0 if "1000" in code else 0.0

    narrow_patterns = [
        bool(re.search(r'\b1000\s+1\b', code)),
        bool(re.search(r'\b1\s+1000\b', code)),
        "narrow" in code.lower(),
        "elongated" in code.lower(),
        bool(re.search(r'n\s*=\s*1000.*m\s*=\s*1\b', code)),
        bool(re.search(r'n\s*=\s*1\b.*m\s*=\s*1000', code)),
    ]
    scores["has_narrow_map"] = 1.0 if any(narrow_patterns) else 0.0

    isolated_patterns = [
        "surround" in code.lower(),
        "isolat" in code.lower(),
        "wall" in code.lower(),
        "block" in code.lower(),
        "only spring" in code.lower(),
    ]
    scores["has_isolated_spring"] = 1.0 if any(isolated_patterns) else 0.0

    file_refs = []
    for i in range(1, 11):
        patterns = [f"A{i}.in", f'"A{i}"', f'"A" + to_string({i})', f'"A" << {i}']
        if any(p in code for p in patterns):
            file_refs.append(i)
    if re.search(r'for\s*\([^)]*10', code) or re.search(r'i\s*<=\s*10', code) or re.search(r'i\s*<\s*11', code):
        file_refs = list(range(1, 11))
    scores["generates_10_files"] = 1.0 if len(file_refs) >= 8 else (0.5 if len(file_refs) >= 5 else 0.0)

    # Check that spring coordinates are 1-based: p1/p2 should not be written as 0
    # Look for output patterns where first line starts with "0" as p1 or p2
    has_zero_coords = bool(
        re.search(r'<<\s*["\s]0\s+0\b', code) or
        re.search(r'p1\s*=\s*0\b', code) or
        re.search(r'p2\s*=\s*0\b', code)
    )
    scores["coordinates_1based"] = 0.0 if has_zero_coords else 1.0

    return scores
```

## LLM Judge Rubric

### Criterion 1: Test Case Coverage Quality (Weight: 40%)

**Score 1.0**: All 10 test cases are present and correctly implement their intended scenarios. Minimum (1×1), maximum (1000×1000), narrow (1000×1 or 1×1000), isolated spring, all-flood, no-flood, and mixed cases are all correctly constructed with valid heights and 1-based coordinates.
**Score 0.75**: 8–9 test cases are correctly implemented; one scenario is missing or slightly incorrect (e.g., isolated spring has one neighbor not blocked).
**Score 0.5**: 6–7 test cases are correct; a clearly required scenario (e.g., max size or narrow map) is absent or incorrectly constructed.
**Score 0.25**: Fewer than 6 test cases are correct or meaningful; coverage is sparse.
**Score 0.0**: Test cases are mostly invalid, duplicated, or do not match the problem constraints.

### Criterion 2: Correctness of Generated Input Format (Weight: 35%)

**Score 1.0**: All generated test cases follow the exact input format: first line is `n m p1 p2`, followed by n lines of m integers. Spring coordinates p1/p2 are 1-based and within [1,n] × [1,m]. Heights are positive integers within a reasonable range.
**Score 0.75**: Format is mostly correct but one test case has a minor error (e.g., off-by-one in coordinates, or a row has wrong number of integers).
**Score 0.5**: Most test cases have correct format but one or two have structural errors (e.g., wrong number of rows, 0-based coordinates in some cases).
**Score 0.25**: Several test cases have format errors that would cause the reference solution to produce wrong output or crash.
**Score 0.0**: Generated format is fundamentally wrong (e.g., columns and rows swapped, coordinates always 0-based, or heights missing).

### Criterion 3: Code Quality and Correctness (Weight: 25%)

**Score 1.0**: `generator.cpp` is clean, compiles without errors, uses proper file I/O, and correctly produces all 10 test files. Code is readable with comments identifying each test case scenario.
**Score 0.75**: Code compiles and runs correctly but lacks comments or has minor style issues.
**Score 0.5**: Code compiles but has logic errors in one or two test case generators (e.g., narrow map outputs wrong dimensions, isolated spring not fully enclosed).
**Score 0.25**: Code has compilation errors or significant logic errors affecting multiple test cases.
**Score 0.0**: Code does not compile or produces no output files.