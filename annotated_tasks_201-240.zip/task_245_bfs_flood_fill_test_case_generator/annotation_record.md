| 序号 | 修改项 | 修改原因 |
|---|---|---|
| 1 | frontmatter 补充 grading_weights 字段，grading_type 改为 hybrid | 原文缺少 grading_weights；纯自动化无法评估测试用例覆盖质量，需 LLM Judge |
| 2 | Expected Behavior 补充陷阱说明 | 缺少对 1-based 坐标要求的陷阱说明，模型可能生成 0-based 坐标导致参考代码出错 |
| 3 | 删除 grade() 中 `no_fabricated_features` 检查 | 与 Grading Criteria 无对应条目，key 未对齐 |
| 4 | 修复 `has_1x1` 检测正则 | 原正则 `\b1\s*,\s*1\b` 会误匹配数组索引等，改为匹配更具体的模式 |
| 5 | 修复 `has_isolated_spring` 检测 | `re.search(r'>\s*h', code)` 过于宽松会误匹配，移除该条件，保留关键词检测 |
| 6 | Grading Criteria 新增第 9 条，grade() 新增对应 score key | 补充对 p1/p2 坐标合法性（1-based）的检查，与 Expected Behavior 陷阱说明对应 |
| 7 | 补充 LLM Judge Rubric | 原文完全缺失，纯自动检测无法覆盖测试用例实际覆盖质量 |