---
id: task_231_product_information_translator
name: Product Information Translator
category: Data Analysis
subcategory: Data Processing and Management
difficulty: medium
external_dependency: none
verification_method: output-check
input_modality: text-only
grading_type: hybrid
grading_weights:
  automated: 0.4
  llm_judge: 0.6
timeout_seconds: 240
workspace_files: []
source_line_number: 8498
source_query: "Translate the following product information JSON into all languages listed in `target_languages`. Translate each non-empty field (`names`, `allergens`, `ingredients`) and return only the translated entries for the target languages (do not include non-target languages). Apply sanitization/normalization, and preserve/normalize bolding for allergens/additives as required.  Input: ``` {\"names\": {\"de\": \"Barilla Sugo al Tonno\", \"en\": \"Barilla Tuna Sauce\", \"fr\": \"Barilla Sugo al Tonno\"..."
---

## Prompt

Hey, I need help translating some product info for our food label database.

Please create a file named `translations.json` containing translations for the requested target languages only.

Here is the source data:

```json
{
  "names": {
    "de": "Barilla Sugo al Tonno",
    "en": "Barilla Tuna Sauce",
    "fr": "Barilla Sugo al Tonno",
    "it": "Barilla Sugo al Tonno"
  },
  "allergens": {},
  "ingredients": {
    "en": "Tomato puree 64%, tomato concentrate 14%, **TUNA** in olive oil 10% (**TUNA** 9%, olive oil 0.25%, salt), sunflower oil, parsley 1.2%, sugar, salt, **anchovy** paste (**ANCHOVIES**, salt, sunflower oil), capers (capers, salt), maize starch, flavourings, garlic, acidity regulator: **LACTIC ACID**, black pepper."
  },
  "target_languages": ["bg", "cs", "da", "el", "es", "fi", "hu", "ja", "ko", "nb", "nl", "pl", "pt", "ro", "ru", "sv", "tr"]
}
````

Requirements:

1. Translate only the non-empty fields that need translation:

   * `names`
   * `ingredients`
   * Skip `allergens` because it is empty
2. Output only the target languages listed in `target_languages`
3. Do not include any source languages (`de`, `en`, `fr`, `it`) in the output
4. Preserve percentage values, numeric values, parentheses, and list structure
5. Preserve or normalize markdown bold markers around allergen/additive mentions in `ingredients` so that the translated text still clearly marks the highlighted terms using `**...**`
6. Apply reasonable sanitization/normalization:

   * no empty strings for required translated entries
   * no extra commentary
   * valid JSON only
7. Save the result as `translations.json` with this structure:

```json
{
  "names": {
    "<lang_code>": "<translated product name>"
  },
  "ingredients": {
    "<lang_code>": "<translated ingredients>"
  }
}
```

Return the result by writing the file only.

## Expected Behavior

The agent should:

1. Create a file named `translations.json` in the workspace.
2. Write valid UTF-8 JSON with exactly two top-level keys:

   * `names`
   * `ingredients`
3. For both `names` and `ingredients`, include exactly the 17 target languages:
   `bg`, `cs`, `da`, `el`, `es`, `fi`, `hu`, `ja`, `ko`, `nb`, `nl`, `pl`, `pt`, `ro`, `ru`, `sv`, `tr`
4. Exclude all non-target languages from the output, especially the source languages:
   `de`, `en`, `fr`, `it`
5. Translate the product name using the English product meaning as the semantic reference. Brand token `Barilla` should remain unchanged. A correct product-name translation should express the meaning “tuna sauce” naturally in each target language.
6. Translate the ingredients list fully into each target language while preserving:

   * all percentages and numeric values exactly (`64%`, `14%`, `10%`, `9%`, `0.25%`, `1.2%`)
   * parenthetical structure
   * ingredient ordering
7. Preserve or normalize markdown bolding in `ingredients` around highlighted allergen/additive terms so the translated output still contains bold-marked equivalents of:

   * tuna
   * anchovies
   * lactic acid
     The exact translated words may differ by language, but markdown emphasis using `**...**` must still be present.
8. Skip `allergens` entirely because it is empty in the input; it should not appear in the output.
9. Output only JSON content in the file, with no explanatory prose.

Traps the agent should handle correctly:

* The source product name appears untranslated in several source languages, but the intended meaning is given by the English name “Barilla Tuna Sauce”; the agent should not simply copy the Italian phrase into every target language.
* The `allergens` field is empty and should be omitted rather than emitted as an empty object.
* Bold formatting may be normalized to translated terms, but the highlighted concepts must remain clearly marked with markdown `**...**`.
* The task is about producing the requested file, not replying in chat with a JSON snippet only.

Ground truth constraints that are objectively checkable:

* Output filename: `translations.json`
* Required top-level keys: `names`, `ingredients`
* Required language set: exactly the 17 target languages for each populated section
* Forbidden language keys: `de`, `en`, `fr`, `it`
* `allergens` must be absent
* Bold markers must appear in every translated ingredient string
* All specified numeric values must still appear in every translated ingredient string

Tested capabilities: multilingual translation, structured data transformation, instruction following, formatting preservation, normalization, JSON file generation.

## Grading Criteria

* [ ] `translations.json` exists in the workspace
* [ ] `translations.json` is valid JSON and uses the required top-level structure
* [ ] The output contains a `names` object with all 17 target languages populated
* [ ] The output contains an `ingredients` object with all 17 target languages populated
* [ ] The output does not include `allergens`
* [ ] The output excludes source-language keys (`de`, `en`, `fr`, `it`) and other non-target languages
* [ ] Each translated ingredient string preserves all required numeric values and percentages
* [ ] Each translated ingredient string preserves markdown bolding for highlighted allergen/additive terms
* [ ] The product-name translations and ingredient translations are semantically correct and suitable for food-label usage

## LLM Judge Rubric

### Dimension 1: Translation Accuracy and Food-Label Appropriateness (40%)

Assess whether the `names` and `ingredients` translations are semantically correct, natural, and appropriate for food-label context.

* **1.0**: Translations are accurate, natural, and terminology is appropriate for food labeling across nearly all target languages.
* **0.75**: Minor wording issues or a few awkward terms, but translations are mostly accurate and usable.
* **0.5**: Noticeable translation errors or literal/awkward phrasing in multiple languages, but overall meaning is still partially preserved.
* **0.25**: Major translation problems in many languages; important content is mistranslated or unreliable.
* **0.0**: Translations are largely missing, copied from source text without translation, or fundamentally incorrect.

### Dimension 2: Coverage and Structural Compliance (25%)

Assess whether the file includes the required sections, all target languages, and excludes forbidden content.

* **1.0**: Output has the exact required structure, includes all 17 target languages under both `names` and `ingredients`, omits `allergens`, and excludes source/non-target languages.
* **0.75**: Small structural issue or one to two missing/extra language entries, but the output is mostly compliant.
* **0.5**: Several missing entries or mild structural issues, though the intended format is still recognizable.
* **0.25**: Major omissions or incorrect structure reduce usability substantially.
* **0.0**: Output is missing required sections or is structurally unusable.

### Dimension 3: Formatting and Detail Preservation (20%)

Assess preservation of bold markers and exact numeric/detail retention.

* **1.0**: Bold markdown is consistently preserved/normalized for highlighted allergen or additive terms in all ingredient translations, and all numeric values/percentages are preserved exactly.
* **0.75**: Mostly preserved, with only minor formatting/detail inconsistencies.
* **0.5**: Partial preservation; some bolding or numeric details are lost in several entries.
* **0.25**: Frequent loss of bolding or key numeric/detail information.
* **0.0**: Formatting/detail preservation is largely absent.

### Dimension 4: Output Cleanliness and Validity (15%)

Assess whether the result is clean machine-consumable JSON without irrelevant content.

* **1.0**: Valid JSON only, no extra prose, no empty required values, and file is cleanly machine-readable.
* **0.75**: Minor cleanliness issues that do not materially affect usability.
* **0.5**: Some formatting or content noise issues, but JSON remains usable.
* **0.25**: Output is messy or partially invalid, reducing machine usability.
* **0.0**: Output is not usable JSON.

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    from pathlib import Path
    import json
    import re

    ws = Path(workspace_path)
    json_file = ws / "translations.json"

    target_langs = ["bg", "cs", "da", "el", "es", "fi", "hu", "ja", "ko", "nb", "nl", "pl", "pt", "ro", "ru", "sv", "tr"]
    source_langs = ["de", "en", "fr", "it", "zh-cn"]

    score_keys = {
        "file_exists": 0.0,
        "valid_json_and_structure": 0.0,
        "names_coverage": 0.0,
        "ingredients_coverage": 0.0,
        "allergens_omitted": 0.0,
        "no_source_or_extra_langs": 0.0,
        "numeric_values_preserved": 0.0,
        "bold_preserved": 0.0,
        "content_nonempty": 0.0,
    }

    if not json_file.exists():
        return score_keys

    score_keys["file_exists"] = 1.0

    try:
        data = json.loads(json_file.read_text(encoding="utf-8"))
    except Exception:
        return score_keys

    names = data.get("names")
    ingredients = data.get("ingredients")

    if (
        isinstance(data, dict)
        and isinstance(names, dict)
        and isinstance(ingredients, dict)
    ):
        score_keys["valid_json_and_structure"] = 1.0

    if "allergens" not in data:
        score_keys["allergens_omitted"] = 1.0

    def nonempty_string(v):
        return isinstance(v, str) and v.strip() != ""

    def coverage_score(section):
        if not isinstance(section, dict):
            return 0.0
        present = sum(1 for lang in target_langs if nonempty_string(section.get(lang)))
        return present / len(target_langs)

    score_keys["names_coverage"] = coverage_score(names)
    score_keys["ingredients_coverage"] = coverage_score(ingredients)

    # Check for exact target-language set only
    allowed_set = set(target_langs)
    lang_set_score = 1.0

    for section in [names, ingredients]:
        if not isinstance(section, dict):
            lang_set_score = 0.0
            break
        keys = set(section.keys())
        if any(lang in keys for lang in source_langs):
            lang_set_score = 0.0
            break
        if keys != allowed_set:
            overlap = len(keys & allowed_set)
            penalty = abs(len(keys - allowed_set)) + (len(allowed_set) - overlap)
            lang_set_score = min(lang_set_score, max(0.0, 1.0 - penalty / len(target_langs)))

    score_keys["no_source_or_extra_langs"] = lang_set_score

    required_number_tokens = ["64%", "14%", "10%", "9%", "0.25%", "1.2%"]

    numeric_hits = 0
    bold_hits = 0
    nonempty_hits = 0

    if isinstance(ingredients, dict):
        for lang in target_langs:
            text = ingredients.get(lang)
            if nonempty_string(text):
                nonempty_hits += 1

                # Numeric preservation
                if all(token in text for token in required_number_tokens):
                    numeric_hits += 1

                # Bold preservation: require at least 3 bold spans or 6 marker tokens
                marker_count = text.count("**")
                bold_spans = re.findall(r"\*\*[^*]+\*\*", text)
                if marker_count >= 6 or len(bold_spans) >= 3:
                    bold_hits += 1

    score_keys["numeric_values_preserved"] = numeric_hits / len(target_langs)
    score_keys["bold_preserved"] = bold_hits / len(target_langs)
    score_keys["content_nonempty"] = nonempty_hits / len(target_langs)

    return score_keys
```
