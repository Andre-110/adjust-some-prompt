| 序号 | 修改项 | 修改原因 |
|------|--------|----------|
| 1    | 将 `difficulty: medium` 改为 `difficulty: hard` | 任务要求同时处理 17 种语言、JSON 结构约束、字段筛选、bold 保留、数值保留，复杂度高于 medium |
| 2    | 重写 Prompt，改为明确提供 JSON 输入 | 原 Prompt 为自然语言描述，虽然可理解，但与任务真实输入结构不完全对齐，不利于降低歧义 |
| 3    | 在 Prompt 中补充“只翻译非空字段”“跳过 allergens”“仅输出目标语言”“仅写文件” | 原 Prompt 对跳过空字段与输出行为约束不够完整，需提高可执行性 |
| 4    | 在 Prompt 中加入 sanitization/normalization 要求 | 源任务说明包含该要求，但原 Prompt 未体现，存在 Expected Behavior 与 Prompt 不一致问题 |
| 5    | 在 Prompt 中明确要求保留百分比、数值、括号和列表结构 | 原题未清晰强调结构细节保留，容易导致输出不稳定 |
| 6    | 扩充 Expected Behavior，加入完整解题路径 | 原 Expected Behavior 过于简略，没有覆盖空字段跳过、品牌保留、数值保持、输出仅 JSON 等关键要求 |
| 7    | 在 Expected Behavior 中补充“陷阱说明” | 按规范要求，当题目存在陷阱时，要写清正确处理方式。原版本未指出“不要把意大利文名直接复制到所有目标语言”等陷阱 |
| 8    | 在 Expected Behavior 中补充可验证的 Ground Truth 约束 | 原版本缺少足够明确的可验证标准，尤其是 `allergens` 不应出现、语言集合应精确匹配 |
| 9    | 重写 Grading Criteria | 原条目偏粗，且“Translation quality is reasonable and consistent”不可独立自动验证；新版拆分为更独立、可判定的条目 |
| 10   | 增加 “allergens 不出现” 评分条目 | 原 Prompt 明确说空字段跳过，但评分未单独覆盖这一关键要求 |
| 11   | 增加 “不得包含额外非目标语言” 条目 | 原自动检查只检查 source languages，未充分覆盖“只能输出目标语言” |
| 12   | 增加 “保留数值/百分比” 条目 | 这是食品标签翻译的重要合规要求，原评分未覆盖 |
| 13   | 重写 LLM Judge Rubric 为分维度分档描述 | 原 Rubric 只有维度和权重，没有 1.0 / 0.75 / 0.5 / 0.25 / 0.0 的清晰等级描述，不符合规范 |
| 14   | 重写 automated checks，使 score key 与评分点更一致 | 原有 key 与 Grading Criteria 不是严格一一对应，且缺少 `allergens`、数值保持、额外语言检查 |
| 15   | 为主输出文件缺失时统一返回全 0 | 满足“空白零分”要求 |
| 16   | 提升自动评分对部分得分的支持 | 使用 coverage 比例和分项比例计算，不再是简单 0/1 |
| 17   | 增强自动评分对“额外语言”的检测 | 原版仅检测 source languages，未检查其他非目标语言；新版要求键集合尽量与目标语言精确匹配 |
| 18   | 增强自动评分对 bold 的检查 | 原版只要包含 `**` 就算通过，过于宽松；新版要求每条 ingredients 至少有足够 bold span |
| 19   | 增强自动评分对 ingredients 数值保留的检查 | 原版未检查数值百分比是否被破坏，无法有效区分好答案和坏答案 |
| 20   | 新增 `content_nonempty` 检查 | 避免模型输出空字符串但仍通过 coverage 的边缘情况 |