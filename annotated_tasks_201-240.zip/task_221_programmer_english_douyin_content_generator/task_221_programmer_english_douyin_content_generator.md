---
id: task_221_programmer_english_douyin_content_generator
name: Programmer English Douyin Content Generator
category: Automation
subcategory: Scenario Based Automation
difficulty: medium
external_dependency: none
verification_method: output-check
input_modality: text-only
grading_type: hybrid
grading_weights:
  automated: 0.4
  llm_judge: 0.6
timeout_seconds: 120
workspace_files: []
source_line_number: 8833
source_query: "以“资深技术导师/程序员英语”风格（极简、犀利、干货；禁止贬低观众、啰嗦定义解释、Chinglish）生成关于单词“ugly（丑陋的，adj.）”的抖音内容，并仅输出一个 JSON 对象，格式为 {\"title\":\"...\",\"description\":\"...\",\"cta\":\"...\",\"tags\":[...] }。要求：1) title 必须以“程序员必会词：ugly”开头，后半部分结合 ugly 特性写差异化、吸睛副标题；2) description：先用一句话极简释义，再给场景/对比（说明比普通词好在哪或在哪用），可补充开发场景用法、常见搭配、踩坑经验等，但绝对不要英文例句；3) tags 必须严格为 [\"#每日英语\",\"#英语学习\",\"#英语口语\",\"#背单词\",\"#ugly\"] 共5个；4) 输出顺序为 description → tags → cta，cta 放在 tags 之后且简短有力；5) 总字数（含标签与 cta）≤500 字。"
---

## Prompt

Hey, I need you to create a short-form video script for my "Programmer English" series on TikTok/Douyin. Today's word is "ugly" (adjective, meaning unattractive/unpleasant).

My style is: senior tech mentor vibes — minimal, sharp, pure value. No fluff, no talking down to viewers, no verbose dictionary definitions, and no Chinglish.

Here's what I need:

- title: must start with "Programmer's Word: ugly" — then add a catchy subtitle that ties into what makes "ugly" special in dev contexts
- description: first give a one-line minimalist meaning, then show where/why devs use it (like "ugly hack", "ugly code", "ugly workaround"), maybe mention common collocations, contrasts, or gotchas in real projects — but NO English example sentences
- tags: exactly these 5: ["#DailyEnglish", "#LearnEnglish", "#SpokenEnglish", "#Vocabulary", "#ugly"]
- cta: short punchy call-to-action, placed AFTER tags in the JSON

The JSON key order must be:
"title" → "description" → "tags" → "cta"

Total word count including tags and cta should be under 500 words.

Output ONLY a single JSON object like this:
{"title":"...","description":"...","tags":[...],"cta":"..."}

## Expected Behavior

The agent should:
1. Generate exactly one JSON object with exactly 4 keys: `title`, `description`, `tags`, and `cta`
2. Preserve the JSON key order exactly as: `title` → `description` → `tags` → `cta`
3. Make the title start exactly with `Programmer's Word: ugly`, followed by a meaningful and attention-grabbing subtitle
4. Make the description concise, dev-focused, and practically useful
5. Start the description with a minimalist meaning of the word, then add programming/developer context such as `ugly hack`, `ugly code`, `ugly workaround`, readability, maintainability, refactoring, or similar usage
6. Include no English example sentences in the description
7. Use tags exactly as `["#DailyEnglish", "#LearnEnglish", "#SpokenEnglish", "#Vocabulary", "#ugly"]`
8. Make the CTA brief and engaging
9. Keep the full output within 500 words
10. Match the requested tone: senior tech mentor, minimal, sharp, high-value, not condescending, and not verbose

Ground-truth constraints:
- Exact title prefix: `Programmer's Word: ugly`
- Exact tags: `["#DailyEnglish", "#LearnEnglish", "#SpokenEnglish", "#Vocabulary", "#ugly"]`
- Exact key order: `title`, `description`, `tags`, `cta`
- No English example sentences
- Total length ≤ 500 words

Tested capabilities: following precise formatting constraints, creative writing within constraints, JSON output formatting, multilingual instruction handling, and attention to detailed requirements.

## Grading Criteria

- [ ] Output is valid JSON with exactly the required 4 keys
- [ ] JSON keys appear in the required order: `title` → `description` → `tags` → `cta`
- [ ] Title starts exactly with `Programmer's Word: ugly`
- [ ] Title includes a meaningful subtitle after the required prefix
- [ ] Description gives a concise meaning and includes relevant programming/developer context
- [ ] Description contains no English example sentences
- [ ] Tags match exactly `["#DailyEnglish", "#LearnEnglish", "#SpokenEnglish", "#Vocabulary", "#ugly"]`
- [ ] CTA exists, is non-empty, and is brief
- [ ] Total output length is within 500 words
- [ ] Overall style matches the requested senior-tech-mentor tone

## LLM Judge Rubric

- **Format Compliance (30%)**
  - **1.0**: Output is exactly one JSON object, uses exactly the required keys, preserves the required key order, and includes no extra text.
  - **0.75**: Minor formatting issue, but the output is still mostly compliant and usable.
  - **0.5**: Multiple formatting issues, but the intended structure is still recognizable.
  - **0.25**: Significant structure or compliance problems.
  - **0.0**: Fails to provide a usable JSON object.

- **Title and Description Quality (30%)**
  - **1.0**: Title starts exactly as required and has a strong dev-relevant subtitle; description is concise, clear, practical, and meaningfully explains developer-context usage.
  - **0.75**: Mostly good, but either the subtitle or the description is somewhat generic.
  - **0.5**: Adequate but shallow or only partially dev-relevant.
  - **0.25**: Weak title/description with limited practical value.
  - **0.0**: Fails to provide a relevant title or usable description.

- **Constraint Satisfaction (20%)**
  - **1.0**: Uses the exact required tags, includes no English example sentence, keeps CTA brief, and stays within 500 words.
  - **0.75**: One minor constraint miss, but overall compliance is still strong.
  - **0.5**: Multiple minor misses or one major miss.
  - **0.25**: Several important constraints are violated.
  - **0.0**: Hard constraints are broadly ignored.

- **Style Fit (20%)**
  - **1.0**: Fully matches the requested senior-tech-mentor tone: minimal, sharp, practical, high-signal, and not condescending.
  - **0.75**: Mostly aligned, with slight fluff or awkwardness.
  - **0.5**: Mixed tone; somewhat generic or wordy.
  - **0.25**: Noticeably off-tone.
  - **0.0**: Clearly mismatched with the requested style.

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    import json
    import re

    score_keys = [
        "valid_json_structure",
        "json_key_order",
        "title_prefix_exact",
        "title_has_subtitle",
        "description_meaning_and_dev_context",
        "description_no_english_example_sentence",
        "tags_exact_match",
        "cta_present_and_brief",
        "length_within_limit",
        "style_match_basic",
    ]

    def zero_scores():
        return {k: 0.0 for k in score_keys}

    def _get_last_assistant_text(transcript: list) -> str:
        for event in reversed(transcript):
            if event.get("type") != "message":
                continue
            msg = event.get("message", {})
            if msg.get("role") != "assistant":
                continue
            for item in msg.get("content", []):
                if isinstance(item, dict) and item.get("type") == "text":
                    return item.get("text", "")
            content = msg.get("content", "")
            if isinstance(content, str):
                return content
        return ""

    text = _get_last_assistant_text(transcript).strip()
    if not text:
        return zero_scores()

    scores = zero_scores()

    if not (text.startswith("{") and text.endswith("}")):
        return scores

    try:
        parsed = json.loads(text)
    except Exception:
        return scores

    if not isinstance(parsed, dict):
        return scores

    required_keys = ["title", "description", "tags", "cta"]
    actual_keys = list(parsed.keys())

    has_required_types = (
        isinstance(parsed.get("title"), str)
        and isinstance(parsed.get("description"), str)
        and isinstance(parsed.get("tags"), list)
        and isinstance(parsed.get("cta"), str)
    )

    scores["valid_json_structure"] = 1.0 if (actual_keys == required_keys and has_required_types) else 0.0
    scores["json_key_order"] = 1.0 if actual_keys == required_keys else 0.0

    title = parsed.get("title", "")
    required_prefix = "Programmer's Word: ugly"
    scores["title_prefix_exact"] = 1.0 if isinstance(title, str) and title.startswith(required_prefix) else 0.0

    subtitle = title[len(required_prefix):].strip() if isinstance(title, str) and title.startswith(required_prefix) else ""
    scores["title_has_subtitle"] = 1.0 if len(subtitle) >= 4 else 0.0

    description = parsed.get("description", "")
    if isinstance(description, str):
        desc_lower = description.lower()
        meaning_terms = [
            "unattractive", "unpleasant", "not pretty", "visually bad",
            "rough", "messy", "awkward", "inelegant"
        ]
        dev_terms = [
            "ugly hack", "ugly code", "ugly workaround", "ugly fix", "ugly solution",
            "code", "hack", "developer", "programming", "dev", "refactor", "refactoring",
            "codebase", "legacy", "readability", "maintainability", "engineering"
        ]
        has_meaning = any(term in desc_lower for term in meaning_terms)
        has_dev_context = any(term in desc_lower for term in dev_terms)
        if has_meaning and has_dev_context:
            scores["description_meaning_and_dev_context"] = 1.0
        elif has_meaning or has_dev_context:
            scores["description_meaning_and_dev_context"] = 0.5
        else:
            scores["description_meaning_and_dev_context"] = 0.0
    else:
        scores["description_meaning_and_dev_context"] = 0.0

    if isinstance(description, str):
        english_sentence_patterns = [
            r'[A-Z][A-Za-z0-9,\-\s]{8,}[.!?]',
            r'\b(?:this|that|it|code|function|api|hack|workaround|solution|fix|design|query|script)\b[^。\n!?]{8,}[.!?]'
        ]
        has_english_sentence = any(re.search(p, description) for p in english_sentence_patterns)
        scores["description_no_english_example_sentence"] = 0.0 if has_english_sentence else 1.0
    else:
        scores["description_no_english_example_sentence"] = 0.0

    required_tags = ["#DailyEnglish", "#LearnEnglish", "#SpokenEnglish", "#Vocabulary", "#ugly"]
    scores["tags_exact_match"] = 1.0 if parsed.get("tags") == required_tags else 0.0

    cta = parsed.get("cta", "")
    if isinstance(cta, str):
        cta = cta.strip()
        if not cta:
            scores["cta_present_and_brief"] = 0.0
        elif len(cta.split()) <= 8:
            scores["cta_present_and_brief"] = 1.0
        else:
            scores["cta_present_and_brief"] = 0.5
    else:
        scores["cta_present_and_brief"] = 0.0

    scores["length_within_limit"] = 1.0 if len(text.split()) <= 500 else 0.0

    if isinstance(title, str) and isinstance(description, str) and isinstance(cta, str):
        combined = f"{title} {description} {cta}".lower()
        negative_style_terms = ["you people", "obviously", "everyone knows", "stupid", "dumb", "idiot"]
        positive_style_terms = ["dev", "code", "hack", "workaround", "readability", "maintainability", "refactor", "practical"]

        has_negative = any(term in combined for term in negative_style_terms)
        positive_hits = sum(1 for term in positive_style_terms if term in combined)

        if has_negative:
            scores["style_match_basic"] = 0.0
        elif positive_hits >= 2 and len(description.split()) <= 80:
            scores["style_match_basic"] = 1.0
        elif positive_hits >= 1:
            scores["style_match_basic"] = 0.5
        else:
            scores["style_match_basic"] = 0.5
    else:
        scores["style_match_basic"] = 0.0

    return scores
```