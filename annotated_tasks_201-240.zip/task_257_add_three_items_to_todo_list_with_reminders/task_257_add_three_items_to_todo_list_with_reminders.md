---
id: task_257_add_three_items_to_todo_list_with_reminders
name: Add Three Items to Todo List with Reminders
category: Communication and Scheduling
subcategory: Reminders and Scheduled Tasks
difficulty: easy
external_dependency: none
verification_method: unit-test
input_modality: text-only
grading_type: automated
grading_weights:
  automated: 1.0
timeout_seconds: 120
workspace_files: []
source_line_number: 4133
source_query: "把以下3条事项写入待办清单，并分别设置提醒： 1) 2026-02-24 11:00：要求所有销售汇总手上订单发给我；我整理后再发给你，用于把真实数据录入订单管理。 2) 2026-03-06 11:00：提醒处理"龙华路黄刚家衣杆断了"：工厂找图纸重新做2个同长度的挂衣杆，质量要更好，不要以前那种。 3) 2026-02-25 11:30：提醒与设计师阿彪对接"朗诗花语"案子（徐老师的案子）。"
---

## Prompt

Hey, I need you to add these 3 items to my todo list and set reminders for each:

1) 2026-02-24 at 11:00 - Ask all sales reps to compile their current orders and send to me; I'll organize everything and send it to you so we can enter the real data into the order management system.

2) 2026-03-06 at 11:00 - Reminder about "Longhua Road - Mr. Huang Gang's broken clothes rod": need the factory to find the drawings and make 2 new hanging rods of the same length, better quality this time, not the old type.

3) 2026-02-25 at 11:30 - Reminder to coordinate with designer Abiao about the "Langshi Huayu" project (this is Teacher Xu's project).

Save everything to `todo_list.json` with the items and their reminder times.

## Expected Behavior

The agent should:
1. Create a JSON file containing all three todo items
2. Each item should have the correct date and time for the reminder
3. Each item should contain the key details from the description
4. The JSON structure should be valid and well-organized

Tested capabilities: information extraction, JSON formatting, date/time handling.

**Trap handling — the agent should correctly navigate the following traps:**

- **Time confusion between items 1 and 2 vs item 3**: Items 1 and 2 are both at 11:00, while item 3 is at 11:30. The agent must not write 11:00 for item 3 — the correct time is 11:30. Mixing up the times would cause item 3 to have the wrong reminder.

## Grading Criteria

- [ ] File `todo_list.json` exists
- [ ] Valid JSON format
- [ ] Contains exactly 3 todo items
- [ ] First item has correct datetime (2026-02-24 11:00) and mentions sales/orders
- [ ] Second item has correct datetime (2026-03-06 11:00) and mentions clothes rod/Huang Gang
- [ ] Third item has correct datetime (2026-02-25 11:30) and mentions Abiao/designer and Langshi Huayu
- [ ] No fabricated fourth item (negative check)

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    from pathlib import Path
    import json

    scores = {}
    ws = Path(workspace_path)

    todo_file = ws / "todo_list.json"
    scores["file_exists"] = 1.0 if todo_file.exists() else 0.0

    if not todo_file.exists():
        scores["valid_json"] = 0.0
        scores["has_three_items"] = 0.0
        scores["item1_correct"] = 0.0
        scores["item2_correct"] = 0.0
        scores["item3_correct"] = 0.0
        scores["no_extra_items"] = 0.0
        return scores

    try:
        content = todo_file.read_text(errors="ignore")
        data = json.loads(content)
        scores["valid_json"] = 1.0
    except Exception:
        scores["valid_json"] = 0.0
        scores["has_three_items"] = 0.0
        scores["item1_correct"] = 0.0
        scores["item2_correct"] = 0.0
        scores["item3_correct"] = 0.0
        scores["no_extra_items"] = 0.0
        return scores

    items = []
    if isinstance(data, list):
        items = data
    elif isinstance(data, dict):
        for key in ["items", "todos", "todo_list", "tasks", "reminders"]:
            if key in data and isinstance(data[key], list):
                items = data[key]
                break
        if not items and len(data) > 0:
            items = list(data.values()) if all(isinstance(v, dict) for v in data.values()) else []

    scores["has_three_items"] = 1.0 if len(items) == 3 else 0.0

    content_lower = content.lower()

    item1_date = "2026-02-24" in content and "11:00" in content
    item1_content = any(kw in content_lower for kw in ["sales", "order", "compile"])
    scores["item1_correct"] = 1.0 if (item1_date and item1_content) else 0.0

    item2_date = "2026-03-06" in content and "11:00" in content
    item2_content = any(kw in content_lower for kw in ["rod", "huang", "longhua", "factory", "drawing"])
    scores["item2_correct"] = 1.0 if (item2_date and item2_content) else 0.0

    item3_date = "2026-02-25" in content and "11:30" in content
    item3_content = (
        any(kw in content_lower for kw in ["abiao", "designer", "a biao"]) and
        any(kw in content_lower for kw in ["langshi", "huayu", "xu"])
    )
    scores["item3_correct"] = 1.0 if (item3_date and item3_content) else 0.0

    scores["no_extra_items"] = 1.0 if len(items) <= 3 else 0.0

    return scores
```