---
id: task_259_product_information_translator
name: Product Information Translator
category: Data Analysis
subcategory: Data Processing and Management
difficulty: medium
external_dependency: none
verification_method: unit-test
input_modality: text-only
grading_type: hybrid
grading_weights:
  automated: 0.4
  llm_judge: 0.6
timeout_seconds: 240
workspace_files: []
source_line_number: 6800
source_query: "Translate the following product information JSON into all languages listed in target_languages. Translate each non-empty field (names, ingredients, allergens) and return only the translations for target_languages. Follow the sanitization, bolding, and extraction rules strictly.  Input JSON: {\"names\": {\"de\": \"CUCINA NOBILE Gorgonzola, Piccante\", \"fr\": \"CUCINA NOBILE Gorgonzola, Piccante\", \"it\": \"CUCINA NOBILE Gorgonzola, piccante\", \"en\": \"CUCINA NOBILE Gorgonzola, Spicy\", \"z..."
---

## Prompt

Hey, I need help translating some product info to a bunch of languages. Here's the JSON data:

```json
{
  "names": {
    "de": "CUCINA NOBILE Gorgonzola, Piccante",
    "fr": "CUCINA NOBILE Gorgonzola, Piccante",
    "it": "CUCINA NOBILE Gorgonzola, piccante",
    "en": "CUCINA NOBILE Gorgonzola, Spicy"
  },
  "allergens": {},
  "ingredients": {
    "de": "Milch pasteurisiert, Salz, Lab. / au moins 48% de MG/ES (a pate mi-dure). **Ingrediente**: Latte pastorizzato, sale, caglio.",
    "it": "Latte pastorizzato, sale, caglio.",
    "fr": "Lait pasteurise, sel, presure. / almeno 48% di grasso s.s. (semiduro).",
    "en": "**Milk** pasteurised, salt, rennet. / at least 48% fat in dry matter (semi-hard). **Ingredients**: Pasteurised **milk**, salt, rennet."
  },
  "target_languages": ["bg", "cs", "da", "el", "es", "fi", "hu", "ja", "ko", "nb", "nl", "pl", "pt", "ro", "ru", "sv", "tr", "zh-tw"]
}
```

Translate each non-empty field (names, ingredients, allergens) to all the languages in target_languages. A few things:
- Keep the brand name "CUCINA NOBILE" and product name "Gorgonzola" unchanged in all translations
- Preserve any **bold** markdown formatting for allergens (like **Milk** stays bold in translations — translate the word but keep the ** markers)
- Skip the allergens field since it's empty
- Only output translations for the target_languages, not the source languages

Save the result as `translations.json` with this structure:
```
{
  "names": {"bg": "...", "cs": "...", ...},
  "ingredients": {"bg": "...", "cs": "...", ...}
}
```

## Expected Behavior

The agent should:
1. Parse the input JSON and identify the fields to translate
2. Recognize that allergens is empty and skip it
3. Translate the product name to all 18 target languages, keeping "CUCINA NOBILE" and "Gorgonzola" unchanged
4. Translate the ingredients text, preserving the **bold** markdown around allergen words like milk — the bold markers must wrap the translated word (e.g., `**Leche**` in Spanish, `**牛奶**` in zh-tw), not the original English word
5. Output a JSON file with only the target language translations

Key translation considerations:
- "Spicy" or "Piccante" should be translated appropriately for each language
- Ingredient terms (pasteurised milk, salt, rennet) should be translated accurately
- Technical info like "48% fat in dry matter (semi-hard)" should be translated
- Bold markers (**) around allergens must be preserved and wrap the translated equivalent

**Trap handling — the agent should correctly navigate the following traps:**

- **Mixed-language source ingredients**: The `de` ingredients field contains Italian text mixed in ("**Ingrediente**: Latte pastorizzato..."), and the `fr` field contains Italian annotations. When translating to target languages, the agent should use the clearest source (preferably `en`) and produce a clean, non-duplicated translation rather than propagating the mixed-language artifacts.
- **zh-tw must use Traditional Chinese characters**: `zh-tw` is Traditional Chinese (繁體中文). The agent must not use Simplified Chinese characters for this locale. "牛奶" and "鹽" (Traditional) are correct; using Simplified variants where they differ is a locale error.
- **Bold markers wrap the translated word, not the English word**: `**Milk**` in English should become `**[translated equivalent]**` in the target language — for example `**Milch**` in German (if German were a target). Leaving `**Milk**` untranslated inside the bold markers is incorrect.

## Grading Criteria

- [ ] File `translations.json` exists and is valid JSON
- [ ] Output contains all 18 target languages for names
- [ ] Output contains all 18 target languages for ingredients
- [ ] Brand name "CUCINA NOBILE" preserved unchanged in all name translations
- [ ] Product name "Gorgonzola" preserved unchanged in all name translations
- [ ] Bold markdown formatting preserved in ingredient translations
- [ ] No allergens field in output (or empty allergens field)
- [ ] Translation quality is appropriate for each target language

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    from pathlib import Path
    import json

    scores = {}
    ws = Path(workspace_path)

    trans_file = ws / "translations.json"
    scores["file_exists"] = 1.0 if trans_file.exists() else 0.0

    if not trans_file.exists():
        scores["valid_json"] = 0.0
        scores["all_target_langs_names"] = 0.0
        scores["all_target_langs_ingredients"] = 0.0
        scores["brand_preserved"] = 0.0
        scores["gorgonzola_preserved"] = 0.0
        scores["no_allergens_field"] = 0.0
        scores["bold_preserved"] = 0.0
        return scores

    try:
        data = json.loads(trans_file.read_text(encoding="utf-8"))
        scores["valid_json"] = 1.0
    except Exception:
        try:
            data = json.loads(trans_file.read_text(encoding="latin-1"))
            scores["valid_json"] = 1.0
        except Exception:
            scores["valid_json"] = 0.0
            scores["all_target_langs_names"] = 0.0
            scores["all_target_langs_ingredients"] = 0.0
            scores["brand_preserved"] = 0.0
            scores["gorgonzola_preserved"] = 0.0
            scores["no_allergens_field"] = 0.0
            scores["bold_preserved"] = 0.0
            return scores

    target_langs = ["bg", "cs", "da", "el", "es", "fi", "hu", "ja", "ko", "nb", "nl", "pl", "pt", "ro", "ru", "sv", "tr", "zh-tw"]

    names = data.get("names", {})
    names_coverage = len(set(names.keys()).intersection(set(target_langs))) / len(target_langs)
    scores["all_target_langs_names"] = names_coverage

    ingredients = data.get("ingredients", {})
    ing_coverage = len(set(ingredients.keys()).intersection(set(target_langs))) / len(target_langs)
    scores["all_target_langs_ingredients"] = ing_coverage

    brand_count = sum(1 for lang in target_langs if lang in names and "CUCINA NOBILE" in names[lang])
    scores["brand_preserved"] = brand_count / len(target_langs) if names else 0.0

    gorg_count = sum(1 for lang in target_langs if lang in names and "Gorgonzola" in names[lang])
    scores["gorgonzola_preserved"] = gorg_count / len(target_langs) if names else 0.0

    allergens_val = data.get("allergens")
    scores["no_allergens_field"] = 1.0 if "allergens" not in data or allergens_val == {} or allergens_val is None else 0.0

    bold_count = sum(1 for lang in target_langs if lang in ingredients and "**" in ingredients[lang])
    scores["bold_preserved"] = bold_count / len(target_langs) if ingredients else 0.0

    return scores
```

## LLM Judge Rubric

### Criterion 1: Translation Accuracy (Weight: 35%)

**Score 1.0**: Translations correctly convey "Spicy/Piccante" in names and ingredient details (milk, salt, rennet, fat content, semi-hard) for all 18 target languages. Terminology is accurate and natural.
**Score 0.75**: Most languages are accurately translated but 1–3 have minor inaccuracies in ingredient terms or spice descriptor.
**Score 0.5**: Several languages have noticeable translation errors or awkward phrasing; core ingredients are mostly recognizable.
**Score 0.25**: Many translations are inaccurate, missing key terms, or clearly machine-translated without review.
**Score 0.0**: Translations are wrong, missing, or untranslated (source language text copied as-is).

### Criterion 2: Format Preservation (Weight: 25%)

**Score 1.0**: Bold markdown `**...**` wraps the translated allergen words (e.g., `**Leche**` in Spanish, `**牛奶**` in zh-tw) in ingredient translations across all 18 languages. Does not leave the English word inside the bold markers.
**Score 0.75**: Bold formatting is preserved in most languages but 1–3 have the original English word inside the markers or the bold is missing.
**Score 0.5**: Bold formatting present in roughly half the target languages.
**Score 0.25**: Bold formatting mostly absent or consistently wrapping untranslated English words.
**Score 0.0**: No bold formatting in any ingredient translation.

### Criterion 3: Brand Integrity (Weight: 20%)

**Score 1.0**: "CUCINA NOBILE" and "Gorgonzola" remain exactly unchanged (correct case and spelling) in every one of the 18 target language name translations.
**Score 0.75**: Brand names unchanged in most translations but altered (case change, partial translation) in 1–2 languages.
**Score 0.5**: Brand names preserved in roughly half the translations.
**Score 0.25**: Brand names frequently altered or partially translated.
**Score 0.0**: Brand names translated or absent in most translations.

### Criterion 4: Completeness (Weight: 15%)

**Score 1.0**: All 18 target languages are present with non-empty values for both names and ingredients. No allergens field (or empty allergens).
**Score 0.75**: 15–17 languages present for both fields; or allergens appears as an empty object (acceptable).
**Score 0.5**: 10–14 languages present.
**Score 0.25**: Fewer than 10 languages present.
**Score 0.0**: Fewer than 5 languages present or output structure is missing names or ingredients.

### Criterion 5: Structure Correctness (Weight: 5%)

**Score 1.0**: Output is valid JSON with exactly `names` and `ingredients` keys (no allergens field with content). Keys contain only the 18 target languages, not the source languages.
**Score 0.75**: Structure mostly correct but source languages (de, fr, it, en) accidentally included alongside target languages.
**Score 0.5**: Structure has minor issues but is parseable.
**Score 0.25**: Structure deviates significantly from the requested format.
**Score 0.0**: Output is not valid JSON or has fundamentally wrong structure.
