---
id: task_214_elementary_math_question_quality_audit
name: Elementary Math Question Quality Audit
category: Data Analysis
subcategory: Quality Auditing and Diagnostics
difficulty: medium
external_dependency: none
verification_method: rubric
input_modality: text-only
grading_type: hybrid
timeout_seconds: 180
grading_weights:
  automated: 0.4
  llm_judge: 0.6
workspace_files: []
source_line_number: 6499
source_query: "作为小学数学题目质量审核专家，对题目ID 3701进行二次质检：检查题干完整清晰无歧义、选项是否完整(3-4个)且无重复、标注答案是否正确、解析是否与标注答案一致、SVG是否清晰/完整/无歧义且不泄露答案或推理或冗余信息（如泄露则判为“svg 错”）。规则：仅当题目完全合格时才输出 is_really_wrong=false；任何不确定都输出 true。题目数据：选项A香蕉、B苹果、C橘子、D都不吃；标注答案=C；SVG=<svg width='300' height='100' xmlns='http://www.w3.org/2000/svg'><text x='20' y='50' font-size='40'>🍌 🍎 🍊</text><text x='20' y='85' font-size='16'>小林：❌🍎 ❌🍊</text></svg>；解析：1小林不吃苹果和橘子所以吃香蕉；2剩下苹果和橘子由小刚和小明吃；3小刚不吃橘子所以吃苹果；4最后橘子由小明吃。仅输出JSON：{\"question_id\":3701,\"is_really_wrong\":true/fa..."
---

## Prompt

You are doing a second-pass quality audit for an elementary math multiple-choice item that was previously flagged as problematic.

Review the following question data for **Question ID 3701**:

- **Options**:  
  A) Banana  
  B) Apple  
  C) Orange  
  D) None of them

- **Marked Answer**: C

- **SVG Image**:
```xml
<svg width='300' height='100' xmlns='http://www.w3.org/2000/svg'>
  <text x='20' y='50' font-size='40'>🍌 🍎 🍊</text>
  <text x='20' y='85' font-size='16'>Xiaolin: ❌🍎 ❌🍊</text>
</svg>
```

* **Explanation**:

  1. Xiaolin doesn't eat apple or orange, so he eats banana.
  2. The remaining apple and orange are eaten by Xiaogang and Xiaoming.
  3. Xiaogang doesn't eat orange, so he eats apple.
  4. Finally, the orange is eaten by Xiaoming.

Audit the item using these checks:

1. Whether the question stem is present, complete, and unambiguous
2. Whether the options are complete (3-4 options) and non-duplicative
3. Whether the marked answer can be verified from the provided information
4. Whether the explanation is consistent with the marked answer and the provided information
5. Whether the SVG is clear, complete, non-misleading, and does not reveal the answer or reasoning

Decision rule:

* Output `"is_really_wrong": false` **only if** the item is fully valid.
* If any required information is missing, inconsistent, unverifiable, ambiguous, or uncertain, output `"is_really_wrong": true`.

Write your result to `audit_result.json` in the following format:

```json
{
  "question_id": 3701,
  "is_really_wrong": true,
  "confidence": "high",
  "issues": ["stem_error", "svg_error"],
  "reason": "Brief explanation under 50 words."
}
```

Additional requirements:

* `issues` must be a JSON array.
* Use only issue labels that are supported by your findings, such as:
  `stem_error`, `options_error`, `answer_error`, `explanation_error`, `svg_error`.
* Keep `reason` concise and evidence-based.

## Expected Behavior

The agent should determine that the item is defective and set `"is_really_wrong": true`.

A strong response should identify the following:

1. **The question stem is missing or incomplete.**
   The provided data contains options, an answer, an SVG, and an explanation, but no actual question text describing what the student is being asked.

2. **The answer cannot be reliably verified from the provided information.**
   Because the stem is absent and the constraints are incomplete, the correctness of option C cannot be established with confidence.

3. **The SVG is incomplete relative to the explanation.**
   The SVG only provides information about Xiaolin, while the explanation also depends on Xiaogang and Xiaoming. Their constraints are not shown.

4. **The explanation relies on unstated information.**
   The explanation introduces reasoning steps that are not fully supported by the visible prompt data and image.

5. **The result should be conservative.**
   Per the task rule, any uncertainty should lead to `"is_really_wrong": true`.

Ground truth expectations:

* `question_id` should be `3701`
* `is_really_wrong` should be `true`
* The `issues` array should include `stem_error` and should usually include at least one of `svg_error`, `answer_error`, or `explanation_error`

Important trap handling:

* Do **not** mark the item as valid just because the explanation appears internally coherent.
* Do **not** assume hidden question text or missing constraints.
* Do **not** ignore the mismatch between the SVG content and the explanation.

## Grading Criteria

* [ ] `file_exists`: `audit_result.json` exists
* [ ] `valid_json`: the file is valid JSON and parses successfully
* [ ] `correct_verdict`: `is_really_wrong` is correctly set to `true`
* [ ] `identifies_core_issues`: output identifies the core defects, especially the missing/incomplete stem and at least one additional substantive issue
* [ ] `required_fields_complete`: output contains all required fields with valid basic types/content
* [ ] `concise_reason`: `reason` is coherent, evidence-based, and no longer than 50 words

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    from pathlib import Path
    import json

    score_keys = [
        "file_exists",
        "valid_json",
        "correct_verdict",
        "identifies_core_issues",
        "required_fields_complete",
        "concise_reason",
    ]
    scores = {k: 0.0 for k in score_keys}

    ws = Path(workspace_path)
    result_file = ws / "audit_result.json"

    if not result_file.exists():
        return scores

    scores["file_exists"] = 1.0

    try:
        with open(result_file, "r", encoding="utf-8") as f:
            data = json.load(f)
    except Exception:
        return scores

    scores["valid_json"] = 1.0

    # correct_verdict
    is_wrong = data.get("is_really_wrong", None)
    if isinstance(is_wrong, bool):
        scores["correct_verdict"] = 1.0 if is_wrong is True else 0.0
    elif isinstance(is_wrong, str):
        normalized = is_wrong.strip().lower()
        if normalized == "true":
            scores["correct_verdict"] = 1.0
        elif normalized == "false":
            scores["correct_verdict"] = 0.0

    # identifies_core_issues
    issues = data.get("issues", [])
    normalized_issues = []
    if isinstance(issues, list):
        normalized_issues = [
            str(x).strip().lower().replace("-", "_").replace(" ", "_")
            for x in issues
        ]

    has_stem = "stem_error" in normalized_issues
    has_other_core = any(
        issue in normalized_issues
        for issue in ["svg_error", "answer_error", "explanation_error"]
    )

    if has_stem and has_other_core:
        scores["identifies_core_issues"] = 1.0
    elif has_stem:
        scores["identifies_core_issues"] = 0.5
    else:
        scores["identifies_core_issues"] = 0.0

    # required_fields_complete
    required_fields = ["question_id", "is_really_wrong", "confidence", "issues", "reason"]
    field_scores = []

    for field in required_fields:
        if field not in data:
            field_scores.append(0.0)
            continue

        value = data[field]

        if field == "question_id":
            field_scores.append(1.0 if str(value).strip() == "3701" else 0.5)
        elif field == "confidence":
            if isinstance(value, str) and value.strip().lower() in {"high", "medium", "low"}:
                field_scores.append(1.0)
            else:
                field_scores.append(0.0)
        elif field == "issues":
            field_scores.append(1.0 if isinstance(value, list) else 0.0)
        elif field == "reason":
            field_scores.append(1.0 if isinstance(value, str) and value.strip() else 0.0)
        elif field == "is_really_wrong":
            if isinstance(value, bool):
                field_scores.append(1.0)
            elif isinstance(value, str) and value.strip().lower() in {"true", "false"}:
                field_scores.append(0.5)
            else:
                field_scores.append(0.0)
        else:
            field_scores.append(1.0)

    scores["required_fields_complete"] = sum(field_scores) / len(required_fields)

    # concise_reason
    reason = data.get("reason", "")
    if isinstance(reason, str) and reason.strip():
        word_count = len(reason.strip().split())
        if word_count <= 50:
            scores["concise_reason"] = 1.0
        elif word_count <= 70:
            scores["concise_reason"] = 0.5
        else:
            scores["concise_reason"] = 0.0

    return scores
```

## LLM Judge Rubric

### Criterion 1: Defect Identification Accuracy (Weight: 40%)

**Score 1.0**: Correctly identifies that the item is defective, explicitly notes the missing or incomplete question stem, and recognizes that the provided information is insufficient to validate the marked answer. Also identifies at least one additional major issue such as incomplete SVG support or unsupported explanation steps.
**Score 0.75**: Correctly concludes the item is defective and identifies the missing stem or equivalent incompleteness, but misses one important secondary issue.
**Score 0.5**: Reaches the correct overall verdict but provides only partial or weak issue identification.
**Score 0.25**: Mentions vague quality concerns but misses the core defect or provides mostly unsupported criticism.
**Score 0.0**: Incorrectly judges the item as valid or fails to identify any meaningful defect.

### Criterion 2: Evidence-Based Reasoning (Weight: 35%)

**Score 1.0**: Gives clear, logically grounded reasoning based only on the provided item data, accurately connecting missing prompt information, incomplete SVG evidence, and unverifiable answer logic.
**Score 0.75**: Reasoning is mostly sound and evidence-based, with only minor gaps or overstatements.
**Score 0.5**: Some valid reasoning is present, but parts are underexplained, speculative, or loosely connected to the evidence.
**Score 0.25**: Reasoning is weak, confusing, or relies heavily on assumptions not justified by the provided data.
**Score 0.0**: Reasoning is absent, clearly incorrect, or unsupported by the task evidence.

### Criterion 3: Output Schema Compliance (Weight: 25%)

**Score 1.0**: Produces valid JSON with all required fields, uses an appropriate confidence value, includes a proper issues array, and keeps the reason concise and relevant.
**Score 0.75**: Minor schema or formatting issues, but output is still mostly compliant and usable.
**Score 0.5**: Output is partially compliant but has notable field, typing, or formatting problems.
**Score 0.25**: Output format is substantially flawed but still conveys some relevant content.
**Score 0.0**: Output is invalid JSON or fails to follow the requested schema in a meaningful way.
