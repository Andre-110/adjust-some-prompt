| 序号 | 修改项 | 修改原因 |
|---|---|---|
| 1 | 将 `difficulty: hard` 改为 `difficulty: medium` | 原任务主要考查题目质检、信息完备性判断与结构化输出，复杂度不足以支撑 hard |
| 2 | 重写 `Prompt` 的审题说明与输出要求 | 原 Prompt 对“题目缺失、SVG不完整、答案不可验证”的暗示过强，接近直接泄露 Expected Behavior；改后更像真实审核请求 |
| 3 | 保留英文为主的任务表述 | 原文件整体是英文任务定义，仅 `source_query` 为中文，因此按原文件语境保留英文主体更一致 |
| 4 | 明确 `Decision rule` | 防止模型在信息不完整时仍输出 false，强化“任何不确定都判 true”的判定标准 |
| 5 | 补强 `Expected Behavior` | 原内容虽指出主问题，但对 Ground Truth、保守判定原则、陷阱处理写得不够系统 |
| 6 | 增加 “Ground truth expectations” | 原 Expected Behavior 缺少更明确、可验证的正确答案结构，不利于评分一致性 |
| 7 | 增加 “Important trap handling” | 按规范补充“题中存在陷阱时模型应如何处理”，而不是只写失败模式 |
| 8 | 重写 `Grading Criteria` 为 6 个独立条目 | 原标准偏松，且与 `grade()` key 未做到严格一一对应；现已对齐并增强独立可判定性 |
| 9 | 删除原 `no_false_positive` 设计 | 原逻辑命名和判定意图不够清晰，且与核心目标关联弱，不如改为更直接的核心缺陷识别 |
| 10 | 重写 `grade()` 的空文件逻辑 | 按要求保证主输出文件不存在时所有 score key 返回 0.0 |
| 11 | 重写 `grade()` 的 key 集合 | 使 score key 与新版 Grading Criteria 条目严格一一对应 |
| 12 | 为 `identifies_core_issues` 增加部分得分 | 满足“支持 0.0-1.0 之间部分得分”，例如只识别 `stem_error` 给 0.5 |
| 13 | 为 `required_fields_complete` 增加分项平均 | 避免只有全对/全错，提高评分梯度和鲁棒性 |
| 14 | 放宽 `is_really_wrong` 类型容忍 | 接受布尔值优先，也对 `"true"` / `"false"` 字符串给出容忍评分，减少过严格式误伤 |
| 15 | 放宽 `issues` 归一化匹配 | 支持大小写、空格、连字符等合理格式变体，符合“格式容忍”要求 |
| 16 | 补充 `reason` 长度分层判分 | 原评分未真正检查“under 50 words”，现加入 1.0 / 0.5 / 0.0 梯度 |
| 17 | 重写 `LLM Judge Rubric` | 原 rubric 基本可用，但描述不够贴合新版任务结构；现明确三维度、100% 权重、五档评分描述完整 |
| 18 | 强化 `Criterion 1` 与 `Criterion 2` 的区分 | 避免“发现问题”和“解释问题”混在一起，提升 LLM Judge 维度独立性 |
| 19 | 强化 schema 合规要求 | 让 LLM Judge 能检查 JSON、字段、issues 数组、confidence 合法值等格式要求 |