| 序号 | 修改项 | 修改原因 |
|---|---|---|
| 1    | 删除 frontmatter 中冲突字段 `automated_weight: 0.3` | 与 `grading_weights.automated: 0.4` 冲突，导致元信息不一致 |
| 2    | 将 `verification_method` 从 `reasoning` 改为 `output-check` | 该题要求写入 `storage_estimate.md`，且存在自动评分与输出检查，更适合 `output-check` |
| 3    | 重写 Prompt，明确 200 天必须体现在计算中 | 原 Prompt 虽有要求，但没有把这一关键约束强调为显式检查点 |
| 4    | 在 Prompt 中明确“估算值不唯一，但必须自洽合理” | 该题并无唯一数值答案，需防止误导成单解题 |
| 5    | 重写 Expected Behavior，明确“以假设驱动、以自洽性为核心” | 原版本更像单一模板，未充分体现估算题的开放性 |
| 6    | 增加 Ground Truth 说明“没有唯一数值答案” | 保证题目答案明确但不伪造唯一解 |
| 7    | 补充陷阱说明：不得遗漏 200 天、不得跳步、不得混淆 raw/compressed | 覆盖本题关键易错点 |
| 8    | 将 Grading Criteria 扩展为 10 条 | 提高覆盖度，覆盖 assumptions、records/day、bytes/record、200 天、压缩、单位、一致性、合理性 |
| 9   | 重写 `grade()` 并统一初始化所有 score keys | 满足空白零分要求，避免缺 key |
| 10   | `grade()` 增加对 records/day 的检查 | 原自动评分未覆盖关键中间量 |
| 11   | `grade()` 增加对 bytes/record 的检查 | 原自动评分未覆盖关键中间量 |
| 12   | `grade()` 增加对 “200 days” 的显式检查 | 覆盖题目核心约束 |
| 13   | `grade()` 增加 raw estimate / labeling 检查 | 防止 raw/compressed 混淆 |
| 14   | `grade()` 增加 compression handling 检查 | 与 Prompt/Expected Behavior 对齐 |
| 15   | 重写 LLM Judge Rubric，补充 1.0 / 0.75 / 0.5 / 0.25 / 0.0 分档描述 | 原 Rubric 不符合你给的质检要求 |