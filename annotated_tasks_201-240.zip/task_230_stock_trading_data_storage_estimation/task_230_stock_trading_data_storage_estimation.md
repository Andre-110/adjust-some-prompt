---
id: task_230_stock_trading_data_storage_estimation
name: Stock Trading Data Storage Estimation
category: Data Analysis
subcategory: Statistical Analysis and Modeling
difficulty: medium
external_dependency: none
verification_method: output-check
input_modality: text-only
grading_type: hybrid
grading_weights:
  automated: 0.4
  llm_judge: 0.6
timeout_seconds: 120
workspace_files: []
source_line_number: 6445
source_query: "估算保存 200 天股票交易数据需要的存储空间；请明确你的假设（标的数量、频率/粒度、字段数、压缩方式等）并给出计算过程与结果。"
---

## Prompt

Please estimate how much storage is needed to keep **200 days of stock trading data**.

Your analysis must:
- clearly state your assumptions
- show the calculation step by step
- give a final estimate with units

At minimum, include assumptions about:
- number of stocks / tickers
- data frequency or granularity (for example: tick, 1-minute bars, daily bars)
- fields stored per record
- data types or byte size per field / per record
- whether compression is used and, if so, the assumed compression ratio

Please save the full analysis to `storage_estimate.md`.

Requirements:
- The analysis should be self-contained and readable
- The estimate does not need to match one single “correct” number, but it must be internally consistent and reasonable
- Make sure the 200-day duration is explicitly reflected in the math

## Expected Behavior

The agent should:

1. Write a Markdown file named `storage_estimate.md`.
2. Explicitly define a reasonable scenario for estimating stock trading data storage, including:
   - number of tickers
   - frequency / granularity
   - fields stored
   - approximate byte size per field or per record
   - compression assumption (or explicitly state no compression)
3. Compute or derive:
   - records per day
   - bytes per record
   - total records for 200 days
   - raw storage size
   - compressed storage size if compression is assumed
4. Show the full calculation chain clearly enough that a reviewer can follow and verify the math.
5. Provide a final estimate with units such as MB, GB, or TB.
6. Keep the assumptions and result mutually consistent.

Ground truth expectations:
- There is **not a single required numeric answer**, because the estimate depends on the chosen assumptions.
- A correct answer must therefore be judged on:
   - explicit assumptions
   - mathematically valid derivation
   - realistic byte-size reasoning
   - plausible final storage estimate for the scenario chosen

Trap handling expected from the model:
- Do not give a number without stating assumptions.
- Do not omit the 200-day multiplier.
- Do not skip intermediate steps such as records/day or bytes/record.
- Do not mix raw and compressed sizes without clearly labeling them.
- Do not use unrealistic pseudo-precision that is unsupported by the assumptions.

Tested capabilities:
- estimation under assumptions
- quantitative reasoning
- storage calculation
- clear technical writing

## Grading Criteria

- [ ] File `storage_estimate.md` exists
- [ ] Assumptions are explicitly stated (tickers, frequency, fields, data sizes, compression)
- [ ] Analysis shows records per day
- [ ] Analysis shows bytes per record
- [ ] Analysis explicitly includes the 200-day duration in the math
- [ ] Analysis provides a raw storage estimate, or clearly states that the reported estimate is raw only
- [ ] Analysis provides a compressed estimate if compression is assumed
- [ ] Final estimate is given with units
- [ ] Math is internally consistent
- [ ] Assumptions and resulting storage estimate are reasonable

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    from pathlib import Path
    import re

    score_keys = [
        "file_exists",
        "has_assumptions",
        "has_records_per_day",
        "has_bytes_per_record",
        "mentions_200_days",
        "has_raw_or_labeled_estimate",
        "handles_compression",
        "has_final_estimate_with_units",
        "no_overprecision",
    ]
    scores = {k: 0.0 for k in score_keys}

    ws = Path(workspace_path)
    estimate_file = ws / "storage_estimate.md"
    scores["file_exists"] = 1.0 if estimate_file.exists() else 0.0

    if not estimate_file.exists():
        return scores

    try:
        content = estimate_file.read_text(encoding="utf-8")
    except Exception:
        try:
            content = estimate_file.read_text()
        except Exception:
            return scores

    text = content.lower()

    # Assumptions coverage
    assumption_groups = {
        "tickers": ["ticker", "tickers", "stock", "stocks", "symbol", "symbols"],
        "frequency": ["frequency", "granularity", "interval", "tick data", "minute", "daily bar", "1-minute", "1 min"],
        "fields": ["field", "fields", "column", "columns", "timestamp", "open", "high", "low", "close", "volume"],
        "sizes": ["byte", "bytes", "int32", "int64", "float32", "float64", "data type", "datatype"],
        "compression": ["compression", "compressed", "compression ratio", "no compression", "gzip", "snappy", "zstd"],
    }
    covered = 0
    for keywords in assumption_groups.values():
        if any(kw in text for kw in keywords):
            covered += 1
    if covered == 5:
        scores["has_assumptions"] = 1.0
    elif covered >= 3:
        scores["has_assumptions"] = 0.5

    # records per day
    records_day_patterns = [
        r"records?\s+per\s+day",
        r"rows?\s+per\s+day",
        r"per day.*records?",
        r"daily records?",
    ]
    if any(re.search(p, text) for p in records_day_patterns):
        scores["has_records_per_day"] = 1.0

    # bytes per record
    bytes_record_patterns = [
        r"bytes?\s+per\s+record",
        r"bytes?\s+per\s+row",
        r"record size",
        r"row size",
        r"per record.*bytes?",
    ]
    if any(re.search(p, text) for p in bytes_record_patterns):
        scores["has_bytes_per_record"] = 1.0

    # must mention 200 days
    if "200 days" in text or "200-day" in text or "200 day" in text:
        scores["mentions_200_days"] = 1.0

    # raw estimate / labeling
    raw_patterns = [
        r"raw storage",
        r"raw size",
        r"uncompressed",
        r"before compression",
    ]
    size_pattern = r"\d+(\.\d+)?\s*(kb|mb|gb|tb|kilobyte|megabyte|gigabyte|terabyte)"
    has_any_size = bool(re.search(size_pattern, text))
    has_raw_label = any(re.search(p, text) for p in raw_patterns)
    if has_raw_label:
        scores["has_raw_or_labeled_estimate"] = 1.0
    elif has_any_size:
        scores["has_raw_or_labeled_estimate"] = 0.5

    # compression handling
    compression_patterns = [
        r"compression",
        r"compressed",
        r"compression ratio",
        r"no compression",
        r"after compression",
    ]
    if any(re.search(p, text) for p in compression_patterns):
        scores["handles_compression"] = 1.0

    # final estimate with units
    if has_any_size:
        scores["has_final_estimate_with_units"] = 1.0

    # discourage false precision
    overprecision_patterns = [
        r"exactly\s+\d+\.\d{4,}",
        r"precisely\s+\d+\.\d{4,}",
        r"\d+\.\d{6,}\s*(gb|tb|mb)",
    ]
    has_overprecision = any(re.search(p, text) for p in overprecision_patterns)
    scores["no_overprecision"] = 0.0 if has_overprecision else 1.0

    return scores
````

## LLM Judge Rubric

### Dimension 1: Assumption Clarity and Coverage (25%)

* **1.0**: Clearly states all major assumptions, including ticker count, frequency/granularity, fields, byte sizes/data types, and compression approach; assumptions are realistic and easy to understand.
* **0.75**: States most major assumptions clearly, with only one minor missing or weakly specified item.
* **0.5**: States some assumptions, but several important ones are vague or missing.
* **0.25**: Assumptions are sparse, unclear, or only partially relevant.
* **0.0**: Little to no usable assumption framing is provided.

### Dimension 2: Calculation Completeness and Traceability (30%)

* **1.0**: Shows a full, easy-to-follow calculation chain from assumptions to records/day, bytes/record, 200-day total, and final size; labels raw/compressed results clearly where relevant.
* **0.75**: Mostly complete calculation chain, but one intermediate step is missing or not clearly labeled.
* **0.5**: Partial calculation is shown, but important intermediate steps are omitted or hard to follow.
* **0.25**: Fragmented calculation with major missing steps.
* **0.0**: No meaningful calculation chain is presented.

### Dimension 3: Mathematical Consistency (25%)

* **1.0**: The math is internally consistent and the final estimate matches the stated assumptions.
* **0.75**: Minor arithmetic or rounding issues, but the overall logic remains sound.
* **0.5**: Noticeable inconsistencies, though the intended method is still recognizable.
* **0.25**: Major inconsistencies between assumptions, calculations, and result.
* **0.0**: The estimate is mathematically unsound.

### Dimension 4: Reasonableness of Scenario and Result (10%)

* **1.0**: Assumptions and final storage estimate are plausible for the scenario chosen.
* **0.75**: Mostly reasonable, with only slight plausibility concerns.
* **0.5**: Some assumptions or the resulting scale are questionable.
* **0.25**: The scenario is weakly grounded or the estimate seems implausible.
* **0.0**: The scenario/result is clearly unrealistic.

### Dimension 5: Presentation Quality (10%)

* **1.0**: The Markdown file is well organized, readable, and clearly communicates the result.
* **0.75**: Generally clear and readable, with minor organizational issues.
* **0.5**: Understandable but somewhat messy or hard to scan.
* **0.25**: Poorly organized or difficult to follow.
* **0.0**: Very unclear or not meaningfully structured.

