| 序号 | 修改项 | 修改原因 |
|---|---|---|
| 1 | Expected Behavior 补充陷阱说明 | 缺少对小数据集导致训练困难、时间序列不可随机分割两个关键陷阱的说明 |
| 2 | 删除 grade() 中 `no_fabricated_imports` 检查 | 与 Grading Criteria 无对应条目（key 未对齐）；且实际几乎不会触发 |
| 3 | Grading Criteria 增加第 9、10 条，grade() 增加对应 key | 题目要求输出 equity_curve.png 和 feature_importance.png，但 Grading Criteria 和 grade() 均未检查文件是否实际存在 |
| 4 | 收紧 commission/slippage 数值匹配正则 | 原 `r"0\.1.*%"` 等会误匹配注释文本，改为匹配具体数值常量 |