---
id: task_256_ai_quantitative_backtesting_system_with_xgboost
name: AI Quantitative Backtesting System with XGBoost
category: Finance
subcategory: Trading Strategy and Backtesting
difficulty: expert
external_dependency: none
verification_method: rubric
input_modality: text-only
grading_type: hybrid
timeout_seconds: 300
grading_weights:
  automated: 0.4
  llm_judge: 0.6
workspace_files: []
source_line_number: 2685
source_query: "用 Python 编写一个可直接运行的“AI 量化回测系统“脚本：包含（1）高级特征工程：自适应布林带、RSI 背离、ATR/vol_factor 等波动率因子；（2）三屏障法（Triple Barrier）打标，剔除"先止损后止盈"的样本；（3）训练 XGBoost 二分类模型，并在回测中使用置信度阈值（默认 0.65）决定是否交易，同时处理样本不平衡；（4）事件驱动回测，模拟手续费与滑点；输出并绘制资金曲线（与买入持有对比）以及特征重要性图；支持可调参数 TP_PCT 与 SL_PCT。"
---

## Prompt

Hey, I need you to write a complete Python script for an AI quantitative backtesting system. Should be runnable directly. Here's what I want:

1. Feature engineering stuff: adaptive Bollinger Bands, RSI divergence detection, and volatility factors using ATR (vol_factor). The Bollinger Bands should widen when ATR is high.

2. Triple Barrier labeling method - this is important. Label samples as positive only if they hit take-profit BEFORE hitting stop-loss. If stop-loss gets hit first, mark it as negative even if it eventually reaches TP. Gotta filter out those "fake" signals that get stopped out before winning.

3. Train an XGBoost binary classifier. Handle class imbalance (use scale_pos_weight or something). During backtesting, only trade when model confidence exceeds a threshold (default 0.65).

4. Event-driven backtest that simulates commission fees (0.1%) and slippage (0.05%). Track equity curve.

5. Output: plot the equity curve vs buy-and-hold benchmark, and show feature importance chart. Save the equity curve to `equity_curve.png` and feature importance to `feature_importance.png`.

Make TP_PCT and SL_PCT adjustable parameters at the top (default TP_PCT=0.03, SL_PCT=0.02).

Use this sample data for the backtest:

```csv
date,open,high,low,close,volume
2025-01-02,100.00,101.50,99.20,101.20,1500000
2025-01-03,101.20,102.80,100.50,102.50,1620000
2025-01-06,102.50,103.20,101.00,101.80,1480000
2025-01-07,101.80,102.50,100.20,100.50,1750000
2025-01-08,100.50,101.80,99.50,101.50,1890000
2025-01-09,101.50,104.00,101.20,103.80,2100000
2025-01-10,103.80,105.50,103.00,105.20,2250000
2025-01-13,105.20,106.00,104.00,104.50,1980000
2025-01-14,104.50,105.80,103.50,105.50,1850000
2025-01-15,105.50,107.20,105.00,106.80,2050000
2025-01-16,106.80,108.00,105.50,106.00,1920000
2025-01-17,106.00,106.50,104.00,104.20,2150000
2025-01-20,104.20,105.00,102.50,103.00,2300000
2025-01-21,103.00,104.50,102.00,104.20,1980000
2025-01-22,104.20,105.80,103.80,105.50,1750000
2025-01-23,105.50,107.00,105.00,106.50,1680000
2025-01-24,106.50,108.50,106.00,108.20,1920000
2025-01-27,108.20,109.00,107.00,107.50,1850000
2025-01-28,107.50,108.20,106.00,106.20,2050000
2025-01-29,106.20,107.50,105.50,107.00,1780000
2025-01-30,107.00,108.80,106.50,108.50,1920000
2025-01-31,108.50,110.00,108.00,109.80,2150000
2025-02-03,109.80,111.50,109.00,111.20,2350000
2025-02-04,111.20,112.00,110.00,110.50,2100000
2025-02-05,110.50,111.80,109.50,111.50,1980000
2025-02-06,111.50,112.50,110.00,110.20,2250000
2025-02-07,110.20,111.00,108.50,109.00,2450000
2025-02-10,109.00,110.50,108.00,110.20,2100000
2025-02-11,110.20,112.00,109.80,111.80,1950000
2025-02-12,111.80,113.50,111.00,113.00,2200000
2025-02-13,113.00,114.00,112.00,112.50,2050000
2025-02-14,112.50,113.20,111.00,111.20,2350000
2025-02-17,111.20,112.50,110.00,112.00,1980000
2025-02-18,112.00,114.00,111.50,113.80,2150000
2025-02-19,113.80,115.00,113.00,114.50,2300000
2025-02-20,114.50,116.00,114.00,115.80,2450000
2025-02-21,115.80,117.00,115.00,116.50,2200000
2025-02-24,116.50,117.50,115.50,116.00,2050000
2025-02-25,116.00,117.00,114.50,115.00,2350000
2025-02-26,115.00,116.50,114.00,116.20,2100000
2025-02-27,116.20,118.00,115.80,117.50,2250000
2025-02-28,117.50,119.00,117.00,118.80,2400000
2025-03-03,118.80,120.00,118.00,119.50,2550000
2025-03-04,119.50,120.50,118.50,119.00,2300000
2025-03-05,119.00,120.00,117.50,118.00,2450000
2025-03-06,118.00,119.50,117.00,119.20,2150000
2025-03-07,119.20,121.00,118.50,120.50,2350000
2025-03-10,120.50,122.00,120.00,121.80,2500000
2025-03-11,121.80,123.00,121.00,122.50,2650000
2025-03-12,122.50,123.50,121.50,122.00,2400000
```

Save the script as `ai_backtest.py`. The script should run end-to-end and generate both plots when executed.

## Expected Behavior

The agent should create a complete, runnable Python script that:
1. Implements feature engineering with adaptive Bollinger Bands (width scales with ATR/volatility), RSI with divergence detection, and vol_factor
2. Implements Triple Barrier labeling that correctly marks samples as negative if stop-loss is hit before take-profit
3. Trains XGBoost with class imbalance handling (scale_pos_weight or similar)
4. Runs event-driven backtest with 0.65 confidence threshold, commission (0.1%), and slippage (0.05%)
5. Generates equity curve plot comparing strategy vs buy-and-hold, saved as `equity_curve.png`
6. Generates feature importance plot, saved as `feature_importance.png`
7. Has configurable TP_PCT (default 0.03) and SL_PCT (default 0.02) parameters

Tested capabilities: quantitative finance, machine learning, feature engineering, backtesting logic, Python programming, data visualization.

**Trap handling — the agent should correctly navigate the following traps:**

- **Small dataset for ML training**: The provided data has only 50 rows. After Triple Barrier labeling and feature computation (which requires lookback periods), very few labeled samples remain for training. The script must handle this gracefully — either with a try/except around training, a minimum-sample guard, or by using simplified logic when insufficient data exists. Crashing with an error (e.g., XGBoost receiving 0 samples) is incorrect.
- **Time series train/test split**: Financial time series data must not be split randomly. The script must use a chronological split (e.g., first 70-80% for training, remaining for testing) to avoid look-ahead bias. Using `train_test_split` with `shuffle=True` on time series data is a methodological error.

## Grading Criteria

- [ ] File `ai_backtest.py` exists and is valid Python
- [ ] Script contains Triple Barrier labeling logic
- [ ] Script contains XGBoost training with class imbalance handling
- [ ] Script contains confidence threshold logic (default 0.65)
- [ ] Script contains commission and slippage simulation
- [ ] Script has configurable TP_PCT and SL_PCT parameters
- [ ] Script generates equity curve plot (saves to equity_curve.png)
- [ ] Script generates feature importance plot (saves to feature_importance.png)
- [ ] File `equity_curve.png` exists after execution
- [ ] File `feature_importance.png` exists after execution

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    from pathlib import Path
    import ast
    import re

    scores = {}
    ws = Path(workspace_path)

    script_path = ws / "ai_backtest.py"
    scores["script_exists"] = 1.0 if script_path.exists() else 0.0

    if not script_path.exists():
        scores["valid_python"] = 0.0
        scores["triple_barrier_logic"] = 0.0
        scores["xgboost_imbalance"] = 0.0
        scores["confidence_threshold"] = 0.0
        scores["commission_slippage"] = 0.0
        scores["tp_sl_params"] = 0.0
        scores["equity_plot"] = 0.0
        scores["feature_importance_plot"] = 0.0
        scores["equity_png_exists"] = 0.0
        scores["feature_importance_png_exists"] = 0.0
        return scores

    code = script_path.read_text(errors="ignore")

    try:
        ast.parse(code)
        scores["valid_python"] = 1.0
    except SyntaxError:
        scores["valid_python"] = 0.0
        scores["triple_barrier_logic"] = 0.0
        scores["xgboost_imbalance"] = 0.0
        scores["confidence_threshold"] = 0.0
        scores["commission_slippage"] = 0.0
        scores["tp_sl_params"] = 0.0
        scores["equity_plot"] = 0.0
        scores["feature_importance_plot"] = 0.0
        scores["equity_png_exists"] = 0.0
        scores["feature_importance_png_exists"] = 0.0
        return scores

    code_lower = code.lower()

    triple_barrier_patterns = [
        r"triple.?barrier",
        r"first.*(upper|tp|take).*(lower|sl|stop)",
        r"first.*(lower|sl|stop).*(upper|tp|take)",
        r"hit.*(stop|sl).*before.*(tp|profit)",
        r"(stop|sl).*(first|before).*(tp|profit|take)",
    ]
    has_triple_barrier = any(re.search(p, code_lower) for p in triple_barrier_patterns)
    scores["triple_barrier_logic"] = 1.0 if has_triple_barrier else 0.0

    has_xgb = bool(re.search(r"xgb(oost)?", code_lower))
    imbalance_patterns = [
        r"scale_pos_weight",
        r"class.?weight",
        r"smote",
        r"imbalance",
        r"pos.?weight",
    ]
    has_imbalance = any(re.search(p, code_lower) for p in imbalance_patterns)
    scores["xgboost_imbalance"] = 1.0 if (has_xgb and has_imbalance) else 0.0

    confidence_patterns = [
        r"confidence.*0\.6",
        r"threshold.*0\.6",
        r"proba.*>.*0\.6",
        r"predict_proba",
        r"0\.65",
    ]
    has_confidence = any(re.search(p, code_lower) for p in confidence_patterns)
    scores["confidence_threshold"] = 1.0 if has_confidence else 0.0

    commission_patterns = [r"commission", r"\bfee\b", r"0\.001\b"]
    slippage_patterns = [r"slippage", r"\bslip\b", r"0\.0005\b"]
    has_commission = any(re.search(p, code_lower) for p in commission_patterns)
    has_slippage = any(re.search(p, code_lower) for p in slippage_patterns)
    scores["commission_slippage"] = 1.0 if (has_commission and has_slippage) else 0.0

    has_tp = bool(re.search(r"tp.?pct|take.?profit.?pct|tp.?percent", code_lower))
    has_sl = bool(re.search(r"sl.?pct|stop.?loss.?pct|sl.?percent", code_lower))
    scores["tp_sl_params"] = 1.0 if (has_tp and has_sl) else 0.0

    equity_patterns = [
        r"equity.*curve",
        r"savefig.*equity",
        r"equity.*\.png",
        r"capital.*plot",
        r"buy.*hold",
    ]
    has_equity_plot = any(re.search(p, code_lower) for p in equity_patterns)
    scores["equity_plot"] = 1.0 if has_equity_plot else 0.0

    fi_patterns = [
        r"feature.?importance",
        r"importance.*plot",
        r"feature_importances",
        r"savefig.*importance",
    ]
    has_fi_plot = any(re.search(p, code_lower) for p in fi_patterns)
    scores["feature_importance_plot"] = 1.0 if has_fi_plot else 0.0

    scores["equity_png_exists"] = 1.0 if (ws / "equity_curve.png").exists() else 0.0
    scores["feature_importance_png_exists"] = 1.0 if (ws / "feature_importance.png").exists() else 0.0

    return scores
```

## LLM Judge Rubric

### Criterion 1: Triple Barrier Implementation Quality (Weight: 25%)

**Score 1.0**: Correctly implements Triple Barrier labeling that marks samples as negative when stop-loss is hit before take-profit, with clear logic for checking which barrier is hit first. Handles edge cases such as neither barrier being hit within the lookback window.
**Score 0.75**: Triple Barrier logic is present and mostly correct, with minor issues in edge case handling.
**Score 0.5**: Basic barrier labeling exists but doesn't properly check which barrier is hit first.
**Score 0.25**: Mentions triple barrier but implementation is fundamentally flawed.
**Score 0.0**: No triple barrier logic or completely incorrect approach.

### Criterion 2: Feature Engineering Sophistication (Weight: 25%)

**Score 1.0**: Implements adaptive Bollinger Bands that scale with ATR/volatility, RSI with divergence detection, and vol_factor. Features are well-designed for the prediction task.
**Score 0.75**: Has adaptive Bollinger Bands and RSI, but divergence detection or vol_factor is basic or missing.
**Score 0.5**: Basic Bollinger Bands and RSI without adaptive/volatility components.
**Score 0.25**: Only simple technical indicators without the requested sophistication.
**Score 0.0**: No meaningful feature engineering.

### Criterion 3: ML Pipeline and Trading Logic (Weight: 25%)

**Score 1.0**: XGBoost properly configured with class imbalance handling, confidence threshold filtering (0.65), chronological train/test split for time series data, and graceful handling of insufficient training samples.
**Score 0.75**: XGBoost with imbalance handling and threshold present, but minor issues such as random split instead of chronological, or no guard for small datasets.
**Score 0.5**: Basic XGBoost training but missing imbalance handling or confidence threshold.
**Score 0.25**: Attempts ML but with significant issues in implementation (e.g., random shuffle on time series, crashes on small data).
**Score 0.0**: No ML component or completely broken.

### Criterion 4: Backtest Realism and Code Quality (Weight: 25%)

**Score 1.0**: Event-driven backtest with commission (0.1%) and slippage (0.05%), proper equity tracking, comparison to buy-and-hold, and clean visualization saved to the correct filenames. Code is well-organized and runnable end-to-end.
**Score 0.75**: Backtest includes fees and slippage, generates plots, but minor issues in implementation, organization, or output filenames.
**Score 0.5**: Basic backtest with some cost modeling but incomplete or poorly organized.
**Score 0.25**: Backtest exists but missing key components like fees or proper equity tracking.
**Score 0.0**: No functional backtest or completely broken code.