| 序号 | 修改项 | 修改原因 |
|---|---|---|
| 1 | frontmatter 补充 grading_weights: automated: 1.0 | 原文缺少该字段 |
| 2 | Expected Behavior 补充陷阱说明 | 缺少对文件名大小写（SOUL.md vs soul.md）的陷阱说明 |
| 3 | 删除 grade() 中 `no_fabrication` 检查，删除 Grading Criteria 第 5 条 | 检查逻辑永远通过，无区分度；真正的"捏造原则"检测需要 LLM，自动化无法实现 |
| 4 | grade() 修复重复读文件问题，统一使用预读文本变量 | 在 markdown_formatting 检查中重复调用 `soul_file.read_text()`，应复用已有变量 |
| 5 | grade() 增加原始文本变量（非 lower 版本）供正则使用 | content 是 lower 版本，markdown 正则需要原始文本，需分开存储 |