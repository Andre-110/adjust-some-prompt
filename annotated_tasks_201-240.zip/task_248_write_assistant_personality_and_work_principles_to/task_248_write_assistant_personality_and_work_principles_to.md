---
id: task_248_write_assistant_personality_and_work_principles_to
name: Write Assistant Personality and Work Principles to SOUL.md
category: Knowledge Management
subcategory: Agent and Tool Integration
difficulty: easy
external_dependency: none
verification_method: unit-test
input_modality: text-only
grading_type: automated
grading_weights:
  automated: 1.0
timeout_seconds: 120
workspace_files: []
source_line_number: 846
source_query: "把已确认的助理性格与工作准则写入 SOUL.md，作为后续工作的基本准则；应包含：活泼、聪明、好学、勤勉；一丝不苟；不懂就问；以及你提出并被认可的原则（如战略耐心、默认谨慎/保密、压力下冷静、主动识别风险/模式、快速切换工作与生活场景、沟通直接但周到、边界感）。"
---

## Prompt

Hey, can you write up my assistant's personality traits and work principles into a SOUL.md file? This will be the foundation for how I want my AI assistant to behave going forward.

Here's what needs to be included:

Core personality traits:
- Lively/energetic
- Smart
- Eager to learn
- Diligent
- Meticulous (attention to detail)
- Asks questions when unsure

And these principles that we discussed and agreed on:
- Strategic patience
- Default to caution/confidentiality
- Stay calm under pressure
- Proactively identify risks and patterns
- Quick context-switching between work and personal topics
- Direct but thoughtful communication
- Maintains healthy boundaries

Just organize it nicely in SOUL.md. Make it readable and clear so it can serve as a reference doc.

## Expected Behavior

The agent should:
1. Create a file named `SOUL.md` (all uppercase) in the workspace root
2. Include all 6 personality traits (lively, smart, eager to learn, diligent, meticulous, asks when unsure)
3. Include all 7 agreed principles (strategic patience, default caution/confidentiality, calm under pressure, proactive risk identification, context switching, direct but thoughtful communication, boundaries)
4. Organize the content in a clear, readable markdown format with headers and lists

Tested capabilities: file creation, content organization, following explicit requirements, markdown formatting.

**Trap handling — the agent should correctly navigate the following traps:**

- **Filename case sensitivity**: The file must be named `SOUL.md` with all-uppercase letters. On case-sensitive file systems (Linux, macOS), `soul.md` or `Soul.md` are different files and will not be found. The agent must use the exact filename `SOUL.md`.

## Grading Criteria

- [ ] File SOUL.md exists (exact uppercase filename)
- [ ] Contains all 6 personality traits
- [ ] Contains all 7 work principles
- [ ] Uses markdown formatting (headers and lists)

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    from pathlib import Path
    import re

    scores = {}
    ws = Path(workspace_path)

    soul_file = ws / "SOUL.md"
    scores["file_exists"] = 1.0 if soul_file.exists() else 0.0

    if not soul_file.exists():
        scores["personality_traits"] = 0.0
        scores["work_principles"] = 0.0
        scores["markdown_formatting"] = 0.0
        return scores

    raw_content = soul_file.read_text(errors="ignore")
    content = raw_content.lower()

    personality_keywords = [
        ["lively", "energetic", "vibrant"],
        ["smart", "intelligent", "clever"],
        ["eager to learn", "curious", "learning", "learner"],
        ["diligent", "hardworking", "industrious"],
        ["meticulous", "attention to detail", "detail-oriented", "thorough"],
        ["ask", "question", "unsure", "clarif"],
    ]

    trait_count = sum(
        1 for keyword_group in personality_keywords
        if any(kw in content for kw in keyword_group)
    )
    scores["personality_traits"] = trait_count / 6.0

    principle_keywords = [
        ["strategic patience", "patient", "patience"],
        ["caution", "confidential", "discreet", "careful"],
        ["calm", "pressure", "composure", "stress"],
        ["risk", "pattern", "proactive", "identify"],
        ["context switch", "switching", "work and personal", "work and life"],
        ["direct", "thoughtful", "communication"],
        ["boundar", "limit", "scope"],
    ]

    principle_count = sum(
        1 for keyword_group in principle_keywords
        if any(kw in content for kw in keyword_group)
    )
    scores["work_principles"] = principle_count / 7.0

    has_header = bool(re.search(r'^#+\s+', raw_content, re.MULTILINE))
    has_list = bool(re.search(r'^[\-\*]\s+', raw_content, re.MULTILINE)) or bool(
        re.search(r'^\d+\.\s+', raw_content, re.MULTILINE)
    )
    if has_header and has_list:
        scores["markdown_formatting"] = 1.0
    elif has_header or has_list:
        scores["markdown_formatting"] = 0.5
    else:
        scores["markdown_formatting"] = 0.0

    return scores
```