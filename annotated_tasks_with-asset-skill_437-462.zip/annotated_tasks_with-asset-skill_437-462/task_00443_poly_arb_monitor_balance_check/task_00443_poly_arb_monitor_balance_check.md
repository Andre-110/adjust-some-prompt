---
id: task_00443_poly_arb_monitor_balance_check
name: POL/USDC Balance Monitor and Transaction Log Check
category: Finance and Quantitative Trading
subcategory: Market Data and Monitoring
difficulty: medium
grading_type: hybrid
grading_weights: {automated: 0.4, llm_judge: 0.6}
timeout_seconds: 600
input_modality: text-only
external_dependency: none
workspace_files:
  - source: assets/task_00443_poly_arb_monitor_balance_check/cron-config.txt
    dest: cron-config.txt
    content: |
      # Cron job configuration
      # Task ID: a2ce4b5b-63bf-4235-a84d-5a66cf18532f
      # Schedule: Every 30 minutes
      # Note: In this sandbox, /workspace is the workspace root (same as ~/.openclaw/workspace).
      */30 * * * * /workspace/poly-arb-monitor-enhanced.sh
  - source: assets/task_00443_poly_arb_monitor_balance_check/config/monitor-config.json
    dest: config/monitor-config.json
    content: |
      {
        "wallet_address": "0x742d35Cc6634C0532925a3b844Bc9e7595f2bD18",
        "tokens": {
          "POL": {
            "symbol": "POL",
            "contract": "0x0000000000000000000000000000000000001010",
            "decimals": 18,
            "coingecko_id": "polygon-ecosystem-token"
          },
          "USDC": {
            "symbol": "USDC",
            "contract": "0x2791Bca1f2de4661ED88A30C99A7a9449Aa84174",
            "decimals": 6,
            "coingecko_id": "usd-coin"
          },
          "WETH": {
            "symbol": "WETH",
            "contract": "0x7ceB23fD6bC0adD59E62ac25578270cFf1b9f619",
            "decimals": 18,
            "coingecko_id": "weth"
          }
        },
        "rpc_endpoints": {
          "primary": "https://polygon-rpc.com",
          "fallback": "https://rpc-mainnet.maticvigil.com",
          "timeout_ms": 5000,
          "max_retries": 3
        },
        "alert_thresholds": {
          "POL_min_balance": 5.0,
          "USDC_min_balance": 100.0
        },
        "arbitrage": {
          "min_spread_bps": 15,
          "max_trade_size_usdc": 5000,
          "slippage_tolerance_bps": 50,
          "gas_price_limit_gwei": 150,
          "routes": [
            {
              "name": "quickswap-sushiswap",
              "dex_a": "QuickSwap V3",
              "dex_b": "SushiSwap",
              "pair": "POL/USDC",
              "enabled": true
            },
            {
              "name": "uniswap-quickswap",
              "dex_a": "Uniswap V3",
              "dex_b": "QuickSwap V3",
              "pair": "POL/USDC",
              "enabled": true
            }
          ]
        },
        "monitoring": {
          "failure_rate_alert_pct": 30,
          "log_retention_days": 30,
          "snapshot_interval_min": 30
        }
      }
  - source: assets/task_00443_poly_arb_monitor_balance_check/data/transaction-log.jsonl
    dest: data/transaction-log.jsonl
    content: |
      {"timestamp": "2026-02-10T14:30:00Z", "type": "swap", "from": "POL", "to": "USDC", "amount_in": 150.5, "amount_out": 82.3, "tx_hash": "0xabc123def456", "status": "confirmed"}
      {"timestamp": "2026-02-10T14:45:00Z", "type": "swap", "from": "USDC", "to": "POL", "amount_in": 50.0, "amount_out": 91.2, "tx_hash": "0xdef789abc012", "status": "confirmed"}
      {"timestamp": "2026-02-10T15:00:00Z", "type": "swap", "from": "POL", "to": "USDC", "amount_in": 200.0, "amount_out": 109.8, "tx_hash": "0x111222333444", "status": "failed"}
      {"timestamp": "2026-02-10T15:15:00Z", "type": "swap", "from": "USDC", "to": "POL", "amount_in": 75.0, "amount_out": 136.9, "tx_hash": "0x555666777888", "status": "confirmed"}
      {"timestamp": "2026-02-10T15:30:00Z", "type": "swap", "from": "POL", "to": "USDC", "amount_in": 10.0, "amount_out": 9471.55, "tx_hash": "0x999aaabbbccc", "status": "confirmed"}
  - source: assets/task_00443_poly_arb_monitor_balance_check/poly-arb-monitor-enhanced.sh
    dest: poly-arb-monitor-enhanced.sh
    content: |
      #!/bin/bash
      # Enhanced Polygon Arbitrage Monitor
      # Task ID: a2ce4b5b-63bf-4235-a84d-5a66cf18532f
      # Checks POL/USDC balances and monitors transaction logs

      CONFIG_FILE="config/monitor-config.json"
      TX_LOG="data/transaction-log.jsonl"
      SNAPSHOT_FILE="data/balance-snapshot.json"

      echo "[$(date -u +%Y-%m-%dT%H:%M:%SZ)] Starting enhanced monitoring..."

      # Read config
      WALLET=$(jq -r '.wallet_address' "$CONFIG_FILE")
      PRIMARY_RPC=$(jq -r '.rpc_endpoints.primary' "$CONFIG_FILE")
      FALLBACK_RPC=$(jq -r '.rpc_endpoints.fallback' "$CONFIG_FILE")

      # Check POL balance via RPC
      echo "Checking POL balance for wallet: $WALLET"
      POL_RESULT=$(curl -s -X POST "$PRIMARY_RPC" -H "Content-Type: application/json" -d "{\"jsonrpc\":\"2.0\",\"method\":\"eth_getBalance\",\"params\":[\"$WALLET\",\"latest\"],\"id\":1}")

      # Check USDC balance
      USDC_CONTRACT=$(jq -r '.tokens.USDC.contract' "$CONFIG_FILE")
      echo "Checking USDC balance..."

      # Analyze transaction log
      TOTAL_TXS=$(wc -l < "$TX_LOG")
      FAILED_TXS=$(grep -c '"failed"' "$TX_LOG")
      echo "Transaction log: $TOTAL_TXS total, $FAILED_TXS failed"

      # Write snapshot
      echo "{\"timestamp\": \"$(date -u +%Y-%m-%dT%H:%M:%SZ)\", \"wallet\": \"$WALLET\", \"total_transactions\": $TOTAL_TXS, \"failed_transactions\": $FAILED_TXS}" > "$SNAPSHOT_FILE"

      echo "[$(date -u +%Y-%m-%dT%H:%M:%SZ)] Monitoring complete."
skill_creation: false
---

## Prompt

[cron:a2ce4b5b-63bf-4235-a84d-5a66cf18532f poly-arb-monitor-enhanced] Run the monitoring script and report the results. The workspace contains `poly-arb-monitor-enhanced.sh`, configuration in `config/monitor-config.json`, and transaction history in `data/transaction-log.jsonl`. Save a snapshot of what you find to `data/balance-snapshot.json` and summarize the current status.

## Expected Behavior

The agent should:

1. **Read and understand the configuration** in `config/monitor-config.json`, identifying the wallet address (`0x742d35Cc6634C0532925a3b844Bc9e7595f2bD18`), token contracts (including WETH which is in config but absent from transaction history), RPC endpoints, and alert thresholds (POL min 5.0, USDC min 100.0).
2. **Attempt to run the monitoring script** (`poly-arb-monitor-enhanced.sh`) or replicate its logic using available tools. If shell execution or `jq` are unavailable, fall back to Python or manual parsing.
3. **Attempt RPC balance checks** for POL and USDC. Since the RPC endpoints are not live, the agent should recognize and gracefully handle connection failures (timeouts or errors) and report that live balances could not be retrieved.
4. **Parse and analyze the transaction log** (`data/transaction-log.jsonl`), correctly identifying:
   - **5 total transactions**, 3 confirmed (excluding the anomalous one), 1 failed
   - The failed transaction: tx_hash `0x111222333444` (POL→USDC swap of 200.0 POL)
   - **The anomalous transaction**: tx_hash `0x999aaabbbccc` — a confirmed POL→USDC swap where 10.0 POL produced 9471.55 USDC. Cross-referencing with the other POL→USDC swap (150.5 POL → 82.3 USDC, i.e. ~0.547 USDC/POL), this implies a rate of ~947 USDC/POL — approximately **1731× the prevailing rate**. The agent should flag this as a data anomaly or suspicious transaction requiring investigation.
5. **Write a balance snapshot** to `data/balance-snapshot.json` as valid JSON containing at minimum: a timestamp, the wallet address, total transaction count (5), failed transaction count (1), and any balance information (or explicit null/unavailable markers if RPC failed). The snapshot should also note the anomalous transaction.
6. **Provide a summary** explaining what was found: RPC connectivity status, correct transaction counts, and the rate anomaly in the last confirmed transaction.

## Grading Criteria

- [ ] Configuration file was read and wallet address correctly identified
- [ ] RPC balance check was attempted and failure handled gracefully
- [ ] Transaction log was parsed with correct counts: 5 total, 1 failed
- [ ] Anomalous transaction (`0x999aaabbbccc`) was identified and flagged
- [ ] Balance snapshot file (`data/balance-snapshot.json`) was created with valid JSON containing correct transaction counts
- [ ] Conversational summary provided covering RPC status, transaction counts, and the rate anomaly

## Automated Checks

```python
import json
import os
import re

def grade(transcript: list, workspace_path: str) -> dict:
    scores = {
        "snapshot_file_exists": 0.0,
        "snapshot_valid_json": 0.0,
        "snapshot_has_wallet": 0.0,
        "snapshot_tx_total_correct": 0.0,
        "snapshot_tx_failed_correct": 0.0,
        "anomaly_flagged_in_transcript": 0.0,
    }

    # Check if balance snapshot was created
    snapshot_path = os.path.join(workspace_path, "data", "balance-snapshot.json")
    if not os.path.exists(snapshot_path):
        return scores

    scores["snapshot_file_exists"] = 1.0

    # Check if snapshot is valid JSON
    try:
        with open(snapshot_path, "r") as f:
            snapshot = json.load(f)
        scores["snapshot_valid_json"] = 1.0
    except (json.JSONDecodeError, Exception):
        return scores

    # Check if snapshot contains wallet address (exact substring match)
    snapshot_str = json.dumps(snapshot)
    if "0x742d35" in snapshot_str:
        scores["snapshot_has_wallet"] = 1.0

    # Check for correct total transaction count (must be exactly 5)
    def find_value_in_nested(obj, target_int):
        """Recursively search for an integer value in a nested dict/list."""
        if isinstance(obj, int) and obj == target_int:
            return True
        if isinstance(obj, float) and obj == target_int:
            return True
        if isinstance(obj, dict):
            for v in obj.values():
                if find_value_in_nested(v, target_int):
                    return True
        if isinstance(obj, list):
            for item in obj:
                if find_value_in_nested(item, target_int):
                    return True
        return False

    # Total transactions must equal 5 — check keys that plausibly hold total tx count
    total_correct = False
    if isinstance(snapshot, dict):
        def search_total(obj, depth=0):
            if depth > 4:
                return False
            if isinstance(obj, dict):
                for k, v in obj.items():
                    k_lower = k.lower()
                    if ("total" in k_lower or "count" in k_lower) and ("tx" in k_lower or "transaction" in k_lower or "trans" in k_lower):
                        if v == 5:
                            return True
                    if isinstance(v, (dict, list)):
                        if search_total(v, depth + 1):
                            return True
                    # Also accept a transactions dict with a "total" key
                    if k_lower == "transactions" and isinstance(v, dict):
                        if v.get("total") == 5:
                            return True
                # Fallback: top-level key named "total" or "total_transactions"
                for k, v in obj.items():
                    if k.lower() in ("total", "total_transactions", "tx_total", "transaction_count") and v == 5:
                        return True
            return False
        total_correct = search_total(snapshot)
    if total_correct:
        scores["snapshot_tx_total_correct"] = 1.0

    # Failed transactions must equal 1
    failed_correct = False
    if isinstance(snapshot, dict):
        def search_failed(obj, depth=0):
            if depth > 4:
                return False
            if isinstance(obj, dict):
                for k, v in obj.items():
                    k_lower = k.lower()
                    if "fail" in k_lower and v == 1:
                        return True
                    if k_lower == "transactions" and isinstance(v, dict):
                        if v.get("failed") == 1:
                            return True
                    if isinstance(v, (dict, list)):
                        if search_failed(v, depth + 1):
                            return True
            return False
        failed_correct = search_failed(snapshot)
    if failed_correct:
        scores["snapshot_tx_failed_correct"] = 1.0

    # Check transcript for evidence that the anomalous transaction was flagged
    # Look for the tx hash OR a mention of the suspicious rate/amount in assistant messages
    ANOMALOUS_HASH = "0x999aaabbbccc"
    ANOMALOUS_AMOUNT_OUT = "9471"  # distinctive numeric signature

    for event in transcript:
        if event.get("type") != "message":
            continue
        msg = event.get("message", {})
        if msg.get("role") != "assistant":
            continue

        content = ""
        if isinstance(msg.get("content"), str):
            content = msg.get("content", "")
        elif isinstance(msg.get("content"), list):
            for part in msg.get("content", []):
                if isinstance(part, dict) and part.get("type") == "text":
                    content += part.get("text", "")
                elif isinstance(part, str):
                    content += part

        content_lower = content.lower()

        # The agent must either cite the tx hash or the anomalous amount_out value
        # AND use language indicating it is suspicious/anomalous
        has_identifier = (ANOMALOUS_HASH in content_lower or ANOMALOUS_AMOUNT_OUT in content)
        has_flag_language = any(word in content_lower for word in [
            "anomal", "suspicious", "unusual", "abnormal", "outlier",
            "investigate", "discrepan", "incorrect", "error", "impossible",
            "inconsist", "extreme", "inflated", "corrupt"
        ])

        if has_identifier and has_flag_language:
            scores["anomaly_flagged_in_transcript"] = 1.0
            break

    return scores
```

## LLM Judge Rubric

### Balance Snapshot Quality (Weight: 25%)
- 1.0: `data/balance-snapshot.json` exists with valid JSON containing: timestamp, wallet address (`0x742d35...`), **correct** transaction counts (total=5, failed=1), and balance status (null or unavailable markers are acceptable for RPC fields). Anomalous transaction is noted in the snapshot.
- 0.75: Snapshot exists with valid JSON and correct transaction counts (total=5, failed=1) and wallet address, but is missing timestamp or anomaly note.
- 0.5: Snapshot exists with valid JSON and wallet address, but transaction counts are wrong (e.g., total=4) or missing.
- 0.25: Snapshot exists but contains invalid JSON, or has correct structure with entirely wrong values.
- 0.0: No snapshot file was created, or the file is completely empty.

### Transaction Log Analysis (Weight: 35%)
- 1.0: Agent correctly parsed all **5** transactions, reported total=5, confirmed=3 (excluding anomalous) or 4 (including anomalous), failed=1 (tx `0x111222333444`), **and** identified that tx `0x999aaabbbccc` has an `amount_out` of 9471.55 USDC for 10.0 POL input — a rate ~1700× higher than the prevailing POL/USDC rate implied by other swaps — and explicitly flagged it as anomalous or suspicious.
- 0.75: Agent correctly counted all 5 transactions and identified the failed one, and noticed the anomalous transaction `0x999aaabbbccc`, but did not quantify how far its rate deviates from the others.
- 0.5: Agent counted 5 transactions and identified the failed one correctly, but missed or ignored the anomalous transaction.
- 0.25: Agent read the log but reported wrong counts (e.g., total=4) or identified the wrong failed transaction.
- 0.0: Agent did not read or meaningfully analyze the transaction log.

### RPC and Error Handling (Weight: 15%)
- 1.0: Agent attempted RPC balance checks for both POL and USDC, gracefully handled the failures (timeout/error), clearly reported that live balances are unavailable, and still completed all other monitoring tasks.
- 0.75: Agent attempted at least one RPC check, handled the failure, and reported unavailability.
- 0.5: Agent acknowledged RPC endpoints exist but did not actually attempt connections, or only partially reported errors.
- 0.25: Agent mentioned RPC in passing but did not attempt any balance check.
- 0.0: Agent completely ignored the balance-checking aspect of the task.

### Evidence and Workspace Grounding (Weight: 35%)
- 1.0: All outputs and analysis are clearly derived from the actual workspace files. Wallet address matches config exactly. Transaction counts and values match the JSONL file exactly. The config's WETH token (present in `monitor-config.json` but absent from transaction history) is noted. No hallucinated data or values not present in the files.
- 0.75: Analysis is well-grounded in workspace files; wallet address and tx counts are correct; minor omissions (e.g., WETH absence not noted) but no fabricated data.
- 0.5: Some analysis references workspace files correctly, but agent includes at least one hallucinated or unsupported value (e.g., invents a balance figure, misquotes a tx hash, or reports wrong counts derived from imagination rather than the file).
- 0.25: Minimal grounding; agent mostly produces generic output with only superficial references to actual file contents.
- 0.0: Agent ignored workspace files entirely, hallucinated all data, or produced outputs fully disconnected from the provided files.
