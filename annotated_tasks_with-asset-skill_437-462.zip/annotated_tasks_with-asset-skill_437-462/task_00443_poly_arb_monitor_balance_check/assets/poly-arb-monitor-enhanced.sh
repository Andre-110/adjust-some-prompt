#!/usr/bin/env bash
#
# poly-arb-monitor-enhanced.sh
# Enhanced monitoring script for POL/USDC arbitrage bot
# Checks wallet balances (POL native + USDC ERC-20) and monitors transaction logs
#
# Usage: ./poly-arb-monitor-enhanced.sh [--verbose] [--alert-threshold <USD>]
#
# Cron task: a2ce4b5b-63bf-4235-a84d-5a66cf18532f
# Schedule: Every 30 minutes via cron

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CONFIG_FILE="${SCRIPT_DIR}/config/monitor-config.json"
TX_LOG="${SCRIPT_DIR}/data/transaction-log.jsonl"
DATA_DIR="${SCRIPT_DIR}/data"
SNAPSHOT_FILE="${DATA_DIR}/balance-snapshot.json"
ALERT_THRESHOLD=100  # USDC — alert if balance drops below this
VERBOSE=false

# Parse arguments
while [[ $# -gt 0 ]]; do
  case "$1" in
    --verbose) VERBOSE=true; shift ;;
    --alert-threshold) ALERT_THRESHOLD="$2"; shift 2 ;;
    *) echo "Unknown option: $1"; exit 1 ;;
  esac
done

# Load config
if [[ ! -f "$CONFIG_FILE" ]]; then
  echo "[ERROR] Config file not found: $CONFIG_FILE"
  exit 1
fi

RPC_URL=$(jq -r '.rpc_endpoints.primary' "$CONFIG_FILE")
FALLBACK_RPC=$(jq -r '.rpc_endpoints.fallback' "$CONFIG_FILE")
WALLET_ADDRESS=$(jq -r '.wallet_address' "$CONFIG_FILE")
USDC_CONTRACT=$(jq -r '.tokens.USDC.contract' "$CONFIG_FILE")
POL_DECIMALS=$(jq -r '.tokens.POL.decimals' "$CONFIG_FILE")
USDC_DECIMALS=$(jq -r '.tokens.USDC.decimals' "$CONFIG_FILE")

TIMESTAMP=$(date -u +"%Y-%m-%dT%H:%M:%SZ")

log() {
  local level="$1"; shift
  echo "[${TIMESTAMP}] [${level}] $*"
}

log "INFO" "=== Enhanced Monitor Run Starting ==="
log "INFO" "Wallet: ${WALLET_ADDRESS}"
log "INFO" "RPC: ${RPC_URL}"

# ---------------------------------------------------------------------------
# 1. Check POL (native) balance via eth_getBalance
# ---------------------------------------------------------------------------
check_pol_balance() {
  local payload='{"jsonrpc":"2.0","method":"eth_getBalance","params":["'"${WALLET_ADDRESS}"'","latest"],"id":1}'
  local response
  response=$(curl -sf --max-time 10 -X POST -H "Content-Type: application/json" -d "$payload" "$RPC_URL" 2>/dev/null) || {
    log "WARN" "Primary RPC failed, trying fallback..."
    response=$(curl -sf --max-time 10 -X POST -H "Content-Type: application/json" -d "$payload" "$FALLBACK_RPC" 2>/dev/null) || {
      log "ERROR" "Both RPCs failed for POL balance check"
      return 1
    }
  }

  local hex_balance
  hex_balance=$(echo "$response" | jq -r '.result // empty')
  if [[ -z "$hex_balance" ]]; then
    log "ERROR" "Empty POL balance response"
    return 1
  fi

  # Convert hex wei to POL (18 decimals)
  local wei_balance
  wei_balance=$(printf "%d" "$hex_balance" 2>/dev/null || echo "0")
  local pol_balance
  pol_balance=$(python3 -c "print(f'{${wei_balance} / 10**${POL_DECIMALS}:.6f}')" 2>/dev/null || echo "0")

  log "INFO" "POL Balance: ${pol_balance} POL"
  echo "$pol_balance"
}

# ---------------------------------------------------------------------------
# 2. Check USDC (ERC-20) balance via eth_call (balanceOf)
# ---------------------------------------------------------------------------
check_usdc_balance() {
  # balanceOf(address) selector: 0x70a08231
  local padded_addr
  padded_addr=$(echo "$WALLET_ADDRESS" | sed 's/0x//' | awk '{printf "0x70a08231000000000000000000000000%s", $0}')

  local payload='{"jsonrpc":"2.0","method":"eth_call","params":[{"to":"'"${USDC_CONTRACT}"'","data":"'"${padded_addr}"'"},"latest"],"id":2}'
  local response
  response=$(curl -sf --max-time 10 -X POST -H "Content-Type: application/json" -d "$payload" "$RPC_URL" 2>/dev/null) || {
    log "WARN" "Primary RPC failed for USDC, trying fallback..."
    response=$(curl -sf --max-time 10 -X POST -H "Content-Type: application/json" -d "$payload" "$FALLBACK_RPC" 2>/dev/null) || {
      log "ERROR" "Both RPCs failed for USDC balance check"
      return 1
    }
  }

  local hex_balance
  hex_balance=$(echo "$response" | jq -r '.result // empty')
  if [[ -z "$hex_balance" ]]; then
    log "ERROR" "Empty USDC balance response"
    return 1
  fi

  local raw_balance
  raw_balance=$(printf "%d" "$hex_balance" 2>/dev/null || echo "0")
  local usdc_balance
  usdc_balance=$(python3 -c "print(f'{${raw_balance} / 10**${USDC_DECIMALS}:.2f}')" 2>/dev/null || echo "0")

  log "INFO" "USDC Balance: ${usdc_balance} USDC"
  echo "$usdc_balance"
}

# ---------------------------------------------------------------------------
# 3. Monitor transaction logs (JSONL format)
# ---------------------------------------------------------------------------
monitor_tx_logs() {
  if [[ ! -f "$TX_LOG" ]]; then
    log "WARN" "Transaction log not found: ${TX_LOG}"
    return 0
  fi

  local total_count=0
  local failed_count=0
  local confirmed_count=0

  while IFS= read -r line; do
    [[ -z "$line" ]] && continue
    ((total_count++))
    local status
    status=$(echo "$line" | jq -r '.status // "unknown"' 2>/dev/null || echo "unknown")
    if [[ "$status" == "failed" ]]; then
      ((failed_count++))
      local tx_hash from_token to_token amount_in
      tx_hash=$(echo "$line" | jq -r '.tx_hash' 2>/dev/null || echo "unknown")
      from_token=$(echo "$line" | jq -r '.from' 2>/dev/null || echo "?")
      to_token=$(echo "$line" | jq -r '.to' 2>/dev/null || echo "?")
      amount_in=$(echo "$line" | jq -r '.amount_in' 2>/dev/null || echo "?")
      log "WARN" "Failed TX: ${tx_hash} — ${from_token}->${to_token} (${amount_in})"
    elif [[ "$status" == "confirmed" ]]; then
      ((confirmed_count++))
    fi
  done < "$TX_LOG"

  log "INFO" "Transaction log: ${total_count} total, ${confirmed_count} confirmed, ${failed_count} failed"

  # Alert on high failure rate
  if (( total_count > 0 && failed_count * 100 / total_count > 30 )); then
    log "ALERT" "High failure rate: ${failed_count}/${total_count} (>30%)"
  fi

  echo "${total_count}:${confirmed_count}:${failed_count}"
}

# ---------------------------------------------------------------------------
# 4. Write snapshot to data directory
# ---------------------------------------------------------------------------
write_snapshot() {
  local pol_bal="$1"
  local usdc_bal="$2"
  local total_tx="$3"
  local failed_tx="$4"

  mkdir -p "$DATA_DIR"

  jq -n \
    --arg ts "$TIMESTAMP" \
    --arg wallet "$WALLET_ADDRESS" \
    --arg pol "$pol_bal" \
    --arg usdc "$usdc_bal" \
    --argjson total "$total_tx" \
    --argjson failed "$failed_tx" \
    '{
      timestamp: $ts,
      wallet: $wallet,
      balances: {
        POL: (if $pol == "unavailable" then null else ($pol | tonumber) end),
        USDC: (if $usdc == "unavailable" then null else ($usdc | tonumber) end)
      },
      transactions: {
        total: $total,
        failed: $failed
      },
      alert_threshold_usdc: '"$ALERT_THRESHOLD"'
    }' > "$SNAPSHOT_FILE"

  log "INFO" "Snapshot written to ${SNAPSHOT_FILE}"
}

# ---------------------------------------------------------------------------
# Main execution
# ---------------------------------------------------------------------------
main() {
  local pol_balance usdc_balance tx_stats

  pol_balance=$(check_pol_balance) || pol_balance="unavailable"
  usdc_balance=$(check_usdc_balance) || usdc_balance="unavailable"

  tx_stats=$(monitor_tx_logs) || tx_stats="0:0:0"
  local total_tx confirmed_tx failed_tx
  total_tx=$(echo "$tx_stats" | cut -d: -f1)
  confirmed_tx=$(echo "$tx_stats" | cut -d: -f2)
  failed_tx=$(echo "$tx_stats" | cut -d: -f3)

  write_snapshot "$pol_balance" "$usdc_balance" "${total_tx:-0}" "${failed_tx:-0}"

  # Low balance alerts
  if [[ "$usdc_balance" != "unavailable" ]]; then
    local usdc_num
    usdc_num=$(echo "$usdc_balance" | cut -d. -f1)
    if (( ${usdc_num:-0} < ALERT_THRESHOLD )); then
      log "ALERT" "USDC balance (${usdc_balance}) below threshold (${ALERT_THRESHOLD} USD)!"
    fi
  fi

  log "INFO" "=== Enhanced Monitor Run Complete ==="
}

main