| 序号 | 修改项 | 修改原因 |
|------|--------|----------|
| 1 | 统一YAML frontmatter中workspace_files的secrets文件内容为`moltbook_sk_a7f2e9d1b3c845f6901234abcdef5678_mixi`（与Assets实际文件一致） | YAML声明内容与Assets实际文件不一致，会导致测试环境与预期不符 |
| 2 | 统一YAML frontmatter中workspace_files的exploration log内容，使其与Assets中的实际丰富内容一致 | YAML中声明"No prior sessions recorded"但Assets文件已有2天活动记录，grade()函数的原始内容判定会失效 |
| 3 | 修改Prompt中skill文件创建路径，从模糊的"in the workspace"改为明确的`workspace/skills/moltbook_social_explorer/SKILL.md` | 避免与Assets中已存在的`home/admin/.clawdbot/skills/moltbook/SKILL.md`混淆，同时符合skill路径规范 |
| 4 | 修改grade()函数中SKILL.md的检查路径为`workspace/skills/moltbook_social_explorer/SKILL.md`（或同时检查多个合理路径） | 与Prompt修改保持一致 |
| 5 | 修改grade()函数中exploration log的原始内容检测逻辑，改为检查是否在已有内容基础上新增了session记录 | 原检测逻辑检查"No prior sessions recorded"不在内容中，但Assets实际文件本来就不含此字符串 |
| 6 | 在Expected Behavior中增加说明：workspace中已存在moltbook平台的skill文档集（在`.clawdbot/skills/moltbook/`下），Agent创建的是一个新的"社交平台探索"skill，而非覆盖已有的平台skill | 明确区分已有的平台SDK文档和需要创建的新skill |
| 7 | YAML frontmatter的workspace_files列表中增加Assets目录中实际存在的其他文件（HEARTBEAT.md, MESSAGING.md, RULES.md, SKILL.md, package.json） | workspace_files声明应与实际提供的文件一致 |
| 8 | 修改package.json中安装路径从`~/.moltbot/`为`~/.clawdbot/`以与实际Assets目录结构一致 | 跨文件引用一致性 |
| 9 | Prompt / Grading / `grade()`：规范路径改为 `skills/moltbook_social_explorer/SKILL.md`（workspace 根下），去掉 `workspace/skills/...` 文案及 `grade()` 中对 `workspace/skills/...` 的 fallback | 与修订后的 `instruction.md` 及 OpenClaw 布局一致；不应鼓励 Agent 在 workspace 下再建一层 `workspace/`。 |