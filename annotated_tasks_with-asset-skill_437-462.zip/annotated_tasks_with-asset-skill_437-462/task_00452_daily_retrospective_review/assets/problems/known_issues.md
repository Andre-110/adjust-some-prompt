# Known Issues

## Young-Co Backend Migration

### Connection pool exhaustion under load (opened 2026-02-01)
- **Severity:** Medium
- **Affects:** Batch operations, especially under concurrent connections
- **Context:** Connection pool settings differ between staging and production environments. Staging supports max ~50 connections; production can handle 200.
- **Related lesson (MEMORY.md, 2026-02-07):** TiDB connection pool should be ≤50 for staging; production can handle 200.
- **Status:** Partially mitigated — production config is correct, staging config needs per-environment verification before each deploy.

### Deploy script SIGTERM handling (opened 2026-02-03)
- **Severity:** Medium
- **Affects:** Graceful shutdown of young-co service
- **Context:** The deploy script needs explicit SIGTERM handling; otherwise K8s sends SIGKILL after 30s grace period.
- **Status:** Known — documented in MEMORY.md, fix not yet implemented.

## Internal Docs Portal

### Feishu webhook token expiry (opened 2026-02-05)
- **Severity:** Low
- **Affects:** Automated sync operations
- **Context:** Feishu webhook tokens expire every 2 hours; must use refresh flow.
- **Status:** Workaround in place (refresh flow implemented).