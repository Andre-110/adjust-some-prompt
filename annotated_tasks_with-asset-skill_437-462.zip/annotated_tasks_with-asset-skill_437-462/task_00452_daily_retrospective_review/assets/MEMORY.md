# MEMORY.md — Long-Term Memory

## Identity
- Name: Clover
- Human: David Chen (davchen)
- Timezone: GMT+8 (Asia/Shanghai)
- Primary platform: Feishu DM

## Key Projects

### Project: Young-Co Backend Migration
- Started: 2026-01-15
- Stack: Node.js + PostgreSQL → Go + TiDB
- Repo: git@gitlab.internal:young-co/backend-v2.git
- Status: Phase 2 — API migration (target completion: 2026-02-20)
- Key contacts: Lisa Wang (PM), Kevin Zhou (backend lead), Mei Lin (QA)
- Daily deploy window: 14:00–16:00 GMT+8
- Note (2026-01-28): Kevin prefers we batch DB migrations on Wednesdays

### Project: Internal Docs Portal
- Started: 2026-01-20
- Using Feishu docs + custom wiki sync
- David wants all SOPs mirrored to Feishu knowledge base
- Folder token: fldcnAbC1234XyZ (David's workspace root)

## Preferences & Habits
- David prefers bullet-point summaries over long prose
- Morning standup at 09:30 GMT+8 — he likes a quick briefing before
- He checks Feishu first, email second
- Likes tasks tracked in daily log files, not kanban boards
- Prefers Chinese for Feishu doc titles, English for code/technical content

## Recurring Tasks
- **Daily review** at 23:00 GMT+8 (cron job: `daily-retrospective`)
- **Weekly summary** every Friday 18:00 GMT+8 → posted to Feishu doc
- **Morning briefing** at 09:00 GMT+8 — calendar + unread messages

## Lessons Learned
- 2026-01-22: Feishu doc API has a 50-block-per-request limit; batch large writes
- 2026-01-25: Always pin the Go version in CI — 1.22 broke the linter
- 2026-02-01: Don't run DB migrations during peak hours (caused 502s)
- 2026-02-03: The `young-co` deploy script needs explicit SIGTERM handling; otherwise K8s sends SIGKILL after 30s grace period
- 2026-02-05: Feishu webhook tokens expire every 2 hours; use refresh flow
- 2026-02-07: TiDB connection pool should be ≤50 for staging; production can handle 200

## Important Dates
- 2026-02-14: Young-Co demo to stakeholders (Lisa organizing)
- 2026-02-20: Phase 2 API migration deadline
- 2026-03-01: Internal docs portal launch target
