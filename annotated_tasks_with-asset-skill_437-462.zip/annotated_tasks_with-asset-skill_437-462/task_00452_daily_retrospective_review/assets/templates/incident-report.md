# Incident Report Template

## Incident: {{TITLE}}
**Date:** {{DATE}}
**Severity:** P0 / P1 / P2 / P3
**Duration:** {{DURATION}}
**Status:** Resolved / Investigating / Mitigated

---

## Timeline
| Time | Event |
|------|-------|
| | First detection |
| | Investigation started |
| | Root cause identified |
| | Fix applied |
| | Verified resolved |

## Impact
- Services affected:
- Users affected:
- Data loss: Yes / No

## Root Cause

## Resolution

## Action Items
- [ ] Short-term fix
- [ ] Long-term prevention
- [ ] Documentation update
- [ ] Monitoring improvement
