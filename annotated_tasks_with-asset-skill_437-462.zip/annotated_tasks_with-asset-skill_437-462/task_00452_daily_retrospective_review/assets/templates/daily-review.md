# Daily Review Template

## Date: {{DATE}}

---

## 1. Core Tasks Completed
<!-- List today's key accomplishments with brief descriptions -->

- [ ] Task 1
- [ ] Task 2
- [ ] Task 3

## 2. Reusable Processes Identified
<!-- Document any workflows that can be standardized or automated -->

| Process | Description | Automation Potential |
|---------|-------------|---------------------|
| | | Low / Medium / High |

## 3. Problems & Solutions
<!-- Issues encountered today and how they were resolved -->

### Problem: [Title]
- **Severity:** Low / Medium / High / Critical
- **Context:** What happened
- **Root Cause:** Why it happened
- **Solution:** How it was fixed
- **Prevention:** How to avoid it in the future

## 4. Tomorrow's Plan
<!-- Priority-ordered tasks for the next working day -->

| Priority | Task | Estimate | Depends On |
|----------|------|----------|------------|
| P0 | | | |
| P1 | | | |
| P2 | | | |

## 5. Long-Term Memory Updates
<!-- Items to add/update in MEMORY.md -->

- New lesson:
- Updated info:
- Removed stale info:

---

## Metrics Summary
- Tasks completed:
- PRs opened/merged:
- Tests written:
- Incidents:
- Blockers:
