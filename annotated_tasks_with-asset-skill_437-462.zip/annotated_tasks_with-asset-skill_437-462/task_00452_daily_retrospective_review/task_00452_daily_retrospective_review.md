---
id: task_00452_daily_retrospective_review
name: Daily Retrospective Review and Memory Update
category: Knowledge and Memory Management
subcategory: Planning and Review
difficulty: medium
grading_type: hybrid
grading_weights: {automated: 0.4, llm_judge: 0.6}
timeout_seconds: 600
input_modality: text-only
external_dependency: none
workspace_files:
  - source: assets/task_00452_daily_retrospective_review/MEMORY.md
    dest: MEMORY.md
    role: context
    description: Long-term memory file containing identity, projects, preferences, lessons learned, and important dates.
  - source: assets/task_00452_daily_retrospective_review/daily_logs/2026-02-07.md
    dest: daily_logs/2026-02-07.md
    role: context
    description: Daily log from Feb 7 with completed tasks and metrics.
  - source: assets/task_00452_daily_retrospective_review/daily_logs/2026-02-08.md
    dest: daily_logs/2026-02-08.md
    role: context
    description: Daily log from Feb 8 (Saturday) with light-day tasks.
  - source: assets/task_00452_daily_retrospective_review/daily_logs/2026-02-09.md
    dest: daily_logs/2026-02-09.md
    role: input
    description: Daily log from Feb 9 — the day to be reviewed. Contains orders and inventory endpoint migrations, SIGKILL incident, wiki sync improvements, and other tasks.
  - source: assets/task_00452_daily_retrospective_review/templates/daily-review.md
    dest: templates/daily-review.md
    role: template
    description: Daily review template with sections for core tasks, reusable processes, problems & solutions, tomorrow's plan, memory updates, and metrics.
  - source: assets/task_00452_daily_retrospective_review/templates/incident-report.md
    dest: templates/incident-report.md
    role: context
    description: Incident report template (available for reference if needed).
  - source: assets/task_00452_daily_retrospective_review/templates/weekly-summary.md
    dest: templates/weekly-summary.md
    role: context
    description: Weekly summary template (available for reference).
  - source: assets/task_00452_daily_retrospective_review/problems/known_issues.md
    dest: problems/known_issues.md
    role: context
    description: Known issues tracker for ongoing projects.
skill_creation: false
---

## Prompt

It's the end of the day (2026-02-09, GMT+8). Please do a daily retrospective:

1. Check what core tasks were completed today (look at the daily logs)
2. Record any procedures that could be standardized for reuse
3. Document problems encountered and their solutions
4. Plan tomorrow's to-do items
5. Update MEMORY.md with anything worth remembering long-term

There's a review template in `templates/daily-review.md` you can use. Save the completed review to `memory/2026-02-09.md` (under the workspace root: dated note in the `memory/` folder, distinct from the archived raw logs under `daily_logs/`). Also check if there were any incidents today — make sure anything significant is captured in the review.

## Expected Behavior

The agent should:

1. Read `daily_logs/2026-02-09.md` to understand what happened during the day.
2. Read `templates/daily-review.md` to use the standard review format.
3. Read `problems/known_issues.md` for context on existing issues.
4. Read `MEMORY.md` for current long-term memory state.
5. Optionally read `daily_logs/2026-02-07.md` and `daily_logs/2026-02-08.md` for broader context.
6. Create `memory/2026-02-09.md` containing a filled-out daily review that includes:
   - A list of completed tasks: orders endpoint migration (PR #287), API documentation update, staging deployment (with incident), wiki sync improvements (PR #44), inventory endpoint migration (PR #288), and responding to Feishu messages.
   - Standardizable procedures (e.g., the staging deployment verification process, connection pool sizing per environment, content hash comparison for wiki sync).
   - A problems & solutions section mentioning:
     - The SIGKILL event at 14:22: TiDB connection pool was set to 200 for staging (which only supports 50), causing pod CrashLoopBackOff. Fix: reduced pool to 50 in staging config.
     - Connection to the lesson already in MEMORY.md from 2026-02-07 about staging pool limits.
   - A plan for tomorrow (e.g., follow up on Kevin's review comments on PR #287, get PR #288 reviewed, investigate query optimization for inventory endpoint's complex JOIN, prepare for the Feb 14 demo).
   - Notes on what to persist to MEMORY.md (e.g., orders and inventory endpoints migrated, SIGKILL incident details, wiki sync improvement reducing API calls by 60%).
7. The review file should follow the template structure (headings for Core Tasks, Reusable Processes, Problems & Solutions, Tomorrow's Plan, Long-Term Memory Updates, Metrics Summary).
8. The agent should also update `MEMORY.md` with new learned patterns or status changes (e.g., updating migration progress from 2 to 4 endpoints, adding a lesson about always verifying staging config before deploy, noting the wiki sync improvement).

**Traps/Pitfalls:**
- The MEMORY.md already contains a lesson from 2026-02-07 about staging pool limits (≤50). The SIGKILL on 2026-02-09 happened because this lesson was not applied (pool was set to 200). A strong answer will note this connection explicitly.
- The agent must not only document the MEMORY.md updates in the review file — it must also actually write the changes to `MEMORY.md` itself (updating migration progress, adding new lesson).

## Grading Criteria

- [ ] `memory/2026-02-09.md` file exists
- [ ] Review file contains completed tasks section listing key tasks from the day (orders endpoint, inventory endpoint, wiki sync, etc.)
- [ ] Review file documents the SIGKILL / connection pool exhaustion problem and its root cause and fix
- [ ] Review file mentions the SIGKILL event with correct context (staging deployment, pool misconfiguration)
- [ ] Review file includes a tomorrow/next-day plan section with actionable items
- [ ] Review file follows the template structure with appropriate headings
- [ ] MEMORY.md is actually updated with new information (e.g., migration progress, new lessons learned about staging config verification)

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    import os
    import re

    scores = {
        "review_file_exists": 0.0,
        "completed_tasks_documented": 0.0,
        "problems_documented": 0.0,
        "sigkill_mentioned": 0.0,
        "tomorrow_plan_exists": 0.0,
        "template_structure_followed": 0.0,
        "memory_updated": 0.0,
    }

    review_path = os.path.join(workspace_path, "memory", "2026-02-09.md")

    if not os.path.isfile(review_path):
        return scores

    scores["review_file_exists"] = 1.0

    try:
        with open(review_path, "r", encoding="utf-8") as f:
            content = f.read()
    except Exception:
        return scores

    content_lower = content.lower()

    # Check completed tasks: use specific identifiers from the day's log
    # PR numbers and specific endpoint/feature names are hard to hallucinate
    task_keywords = [
        "pr #287", "pr #288", "pr #44",
        "orders", "inventory", "wiki sync",
        "feishu", "api documentation"
    ]
    matched_tasks = sum(1 for kw in task_keywords if kw in content_lower)
    if matched_tasks >= 5:
        scores["completed_tasks_documented"] = 1.0
    elif matched_tasks >= 4:
        scores["completed_tasks_documented"] = 0.8
    elif matched_tasks >= 3:
        scores["completed_tasks_documented"] = 0.6
    elif matched_tasks >= 2:
        scores["completed_tasks_documented"] = 0.4
    elif matched_tasks >= 1:
        scores["completed_tasks_documented"] = 0.2
    else:
        scores["completed_tasks_documented"] = 0.0

    # Check problems documented: connection pool issue / SIGKILL incident
    pool_keywords = [
        "connection pool", "pool exhaustion", "crashloopbackoff", "crash loop",
        "pool.*200", "pool.*50", "staging.*config", "tidb"
    ]
    pool_matches = sum(1 for kw in pool_keywords if re.search(kw, content_lower))
    if pool_matches >= 3:
        scores["problems_documented"] = 1.0
    elif pool_matches >= 2:
        scores["problems_documented"] = 0.7
    elif pool_matches >= 1:
        scores["problems_documented"] = 0.4
    else:
        scores["problems_documented"] = 0.0

    # Check SIGKILL mentioned
    if "sigkill" in content_lower:
        scores["sigkill_mentioned"] = 1.0
    elif "sig kill" in content_lower or "signal kill" in content_lower:
        scores["sigkill_mentioned"] = 0.75
    elif "killed" in content_lower and ("young-co" in content_lower or "pod" in content_lower or "process" in content_lower):
        scores["sigkill_mentioned"] = 0.5
    else:
        scores["sigkill_mentioned"] = 0.0

    # Check tomorrow plan section exists
    tomorrow_patterns = [
        r"tomorrow", r"next\s*day", r"plan", r"2026-02-10", r"to.?do",
        r"priority", r"monday"
    ]
    tomorrow_matches = sum(1 for p in tomorrow_patterns if re.search(p, content_lower))
    if tomorrow_matches >= 2:
        scores["tomorrow_plan_exists"] = 1.0
    elif tomorrow_matches >= 1:
        scores["tomorrow_plan_exists"] = 0.5
    else:
        scores["tomorrow_plan_exists"] = 0.0

    # Check template structure: should have multiple heading sections
    headings = re.findall(r"^#{1,3}\s+.+", content, re.MULTILINE)
    structure_keywords = ["task", "completed", "process", "reusable", "problem", "solution",
                          "plan", "memory", "tomorrow", "metric", "standard"]
    heading_text = " ".join(headings).lower()
    structure_matches = sum(1 for kw in structure_keywords if kw in heading_text)
    if len(headings) >= 4 and structure_matches >= 3:
        scores["template_structure_followed"] = 1.0
    elif len(headings) >= 3 and structure_matches >= 2:
        scores["template_structure_followed"] = 0.7
    elif len(headings) >= 2:
        scores["template_structure_followed"] = 0.4
    else:
        scores["template_structure_followed"] = 0.0

    # Check MEMORY.md was actually updated
    memory_path = os.path.join(workspace_path, "MEMORY.md")
    memory_score = 0.0
    if os.path.isfile(memory_path):
        try:
            with open(memory_path, "r", encoding="utf-8") as f:
                memory_content = f.read()
            memory_lower = memory_content.lower()

            memory_signals = []

            # Check for updated migration progress (4 endpoints, or orders/inventory added)
            if re.search(r"4\s*(of|/)\s*12", memory_lower) or (
                "orders" in memory_lower and "inventory" in memory_lower
                and re.search(r"migrat", memory_lower)
            ):
                memory_signals.append("migration_progress")

            # Check for new lesson about staging config / deploy verification
            # Look for content added after 2026-02-07 date marker, or new lesson lines
            new_lesson_patterns = [
                r"2026-02-09",
                r"staging.*config.*deploy",
                r"verify.*staging.*config",
                r"always.*verif",
                r"staging.*pool",
            ]
            if any(re.search(p, memory_lower) for p in new_lesson_patterns):
                memory_signals.append("new_lesson")

            # Check for wiki sync improvement noted
            wiki_patterns = [r"wiki.*sync.*60", r"60.*api.*call", r"content.*hash"]
            if any(re.search(p, memory_lower) for p in wiki_patterns):
                memory_signals.append("wiki_sync_noted")

            if len(memory_signals) >= 2:
                memory_score = 1.0
            elif len(memory_signals) == 1:
                memory_score = 0.5
            else:
                memory_score = 0.0
        except Exception:
            memory_score = 0.0

    scores["memory_updated"] = memory_score

    return scores
```

## LLM Judge Rubric

### Completeness of Daily Review (Weight: 30%)
- 1.0: Review covers all five areas (completed tasks, standardizable/reusable procedures, problems & solutions, tomorrow's plan, memory updates) with specific details drawn from the daily logs. Completed tasks include orders endpoint, inventory endpoint, wiki sync improvements, and other items from the log.
- 0.75: Review covers at least four of the five areas with reasonable detail.
- 0.5: Review covers three areas but may lack specificity or miss key details from the logs.
- 0.25: Review is superficial, covering only one or two areas with generic content.
- 0.0: No review file created, or the file is empty / completely unrelated to the task.

### Evidence and Workspace Grounding (Weight: 30%)
- 1.0: Review content clearly references specific data from the daily logs (endpoint names like orders and inventory, PR numbers like #287/#288/#44, timestamps, SIGKILL event details including root cause of pool misconfiguration, test counts, Feishu messages) and aligns with information in MEMORY.md and known_issues.md. Explicitly connects the SIGKILL incident to the pre-existing MEMORY.md lesson from 2026-02-07 about staging pool limits — i.e., identifies that the lesson was already known but not applied.
- 0.75: Review references most key facts from the logs with only minor omissions; may note the SIGKILL–pool connection but without clearly linking it to the prior lesson in MEMORY.md.
- 0.5: Review references some log data but misses important events or includes unsupported claims.
- 0.25: Review has minimal connection to the actual workspace files; mostly generic content.
- 0.0: Review ignores the provided workspace files entirely, hallucinates facts not in the logs, or no deliverable file was produced.

### Actionability of Tomorrow's Plan (Weight: 20%)
- 1.0: Tomorrow's plan includes specific, actionable items that logically follow from today's work (e.g., address Kevin's review comments on PR #287, get PR #288 reviewed, investigate query optimization for inventory endpoint JOIN, prepare for Feb 14 demo, ensure staging configs are verified before deploys).
- 0.75: Plan includes mostly actionable items with clear connection to today's events.
- 0.5: Plan exists but items are vague or only loosely connected to the day's work.
- 0.25: Plan is a single generic item with no specificity.
- 0.0: No plan section exists or it is completely empty.

### Memory Update Quality (Weight: 15%)
- 1.0: `MEMORY.md` is actually modified (not just described in the review file) with at least two of the following: (a) migration progress updated to reflect 4 of 12 endpoints complete including orders and inventory; (b) a new lesson added about verifying staging environment config before deployment, referencing the 2026-02-09 incident; (c) wiki sync improvement (60% API call reduction) noted. The new lesson clearly references or reinforces the existing 2026-02-07 pool limit lesson, demonstrating awareness that the same pattern recurred.
- 0.75: `MEMORY.md` is modified with one substantive update (e.g., migration progress or new lesson), but the connection to the prior lesson is missing or the update is incomplete.
- 0.5: `MEMORY.md` shows minor edits but key updates (migration progress, new lesson) are absent.
- 0.25: `MEMORY.md` is unchanged but the review file contains a section describing what should be updated.
- 0.0: Neither `MEMORY.md` nor the review file contains any memory update content.

### Template Adherence and Formatting (Weight: 10%)
- 1.0: Review follows the provided template structure closely with clear headings (Core Tasks, Reusable Processes, Problems & Solutions, Tomorrow's Plan, Memory Updates, Metrics Summary), proper markdown formatting, and structured tables or lists where appropriate.
- 0.75: Review follows the template structure with minor deviations; formatting is clean.
- 0.5: Review has some structure but deviates significantly from the template or has formatting issues.
- 0.25: Review is a wall of text with minimal structure.
- 0.0: No recognizable structure or the output is not a markdown document.
