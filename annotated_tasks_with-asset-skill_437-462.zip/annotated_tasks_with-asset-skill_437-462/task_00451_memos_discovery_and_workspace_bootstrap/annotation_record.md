| 序号 | 修改项 | 修改原因 |
|------|--------|----------|
| 1 | 重写 Prompt，使任务要求更清晰自然 | 原 Prompt 中打卡模板使用占位符不自然；"Go find and install MemOS" 过于突兀；没有任何上下文暗示需要创建特定文件 |
| 2 | 在 Assets 中新增 `WORKSPACE_GUIDE.md` 文件 | 为 Agent 提供工作空间初始化规范，使 Expected Behavior 中期望的文件创建有据可依 |
| 3 | 更新 `workspace_files` 列表 | 原 YAML frontmatter 中 `workspace_files: []` 与实际 Assets 不一致 |
| 4 | 修正 Expected Behavior，使其与 Assets 和 Prompt 一致 | 原 Expected Behavior 要求创建的文件缺乏上下文依据；增加对 Assets 环境的引用 |
| 5 | 修正 grade() 函数中 "mem" 匹配逻辑 | `"mem" in content.lower()` 过于宽泛，会匹配 "memory", "remember" 等无关词汇 |
| 6 | 调整 Grading Criteria，增加区分度 | 原标准几乎全是"文件是否存在"，缺乏能力梯度 |
| 7 | 修正 skill 路径格式 | Assets 中 skill 文件路径应为 `workspace/skills/<skill名>/SKILL.md` 规范格式，但实际路径分散在两个位置 |
| 8 | `workspace_files` 由裸路径列表改为 `source` / `dest` 成对字段 | 与数据平台规范一致；每条映射从 Assets 到 workspace 根下的目标路径。 |