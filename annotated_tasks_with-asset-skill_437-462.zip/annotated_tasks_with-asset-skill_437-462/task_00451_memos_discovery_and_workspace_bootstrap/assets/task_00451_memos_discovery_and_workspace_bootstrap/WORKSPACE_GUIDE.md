# Workspace Bootstrap Guide

Welcome to the OpenClaw workspace! This guide describes the standard setup procedure for initializing a new agent workspace.

## Initialization Checklist

When setting up a fresh workspace, the following steps should be completed:

### 1. Version Control
- Initialize a git repository (`git init`)
- Ensure `.git/HEAD` and `.git/config` are present

### 2. Core Identity Files
Create the following files in the workspace root:

| File | Purpose |
|------|---------|
| `IDENTITY.md` | Defines the agent's identity, name, and core purpose |
| `SOUL.md` | Describes the agent's personality, values, and behavioral principles |
| `USER.md` | Profile of the primary user — preferences, communication style, goals |

### 3. Documentation Files
| File | Purpose |
|------|---------|
| `BOOTSTRAP.md` | Log of workspace initialization steps and status |
| `AGENTS.md` | Registry of available agents and their capabilities — **must be populated from actual SKILL.md files found in the workspace skill directories** |
| `TOOLS.md` | Inventory of tools, CLIs, and integrations available in this environment — **must be populated from actual gateway.yaml channels/plugins and installed skill configurations** |
| `HEARTBEAT.md` | Periodic status/health log — updated on each session or check-in |

### 4. State Tracking
- Create `.openclaw/workspace-state.json` with the current workspace configuration
- This file should be valid JSON containing at minimum:
  - `initialized`: boolean
  - `initialized_at`: ISO 8601 timestamp
  - `files_created`: list of files created during bootstrap

### 5. MemOS Research
- Search for MemOS using the clawhub CLI or other available package/search tools
- Document findings in `MEMOS_RESEARCH.md`
- Include: search command used, results returned, installation steps (if found), or explanation of why installation cannot be completed in this environment

## Important Notes on TOOLS.md and AGENTS.md

**Do not use generic placeholders.** These files must reflect the actual environment:

- **TOOLS.md**: Read `opt/moltbot/config/gateway.yaml` to identify enabled channels (e.g., telegram, discord) and plugins. Also check `opt/moltbot/package.json` for installed CLIs (e.g., clawhub). List each tool with its configuration status (enabled/disabled) and purpose.
- **AGENTS.md**: Enumerate skills found in both skill directories:
  - `/opt/moltbot/skills/` — contains: bluebubbles, clawdhub, skill-creator, weather
  - `/home/admin/clawd/skills/` — contains: coding-agent-kh0, deepread-ocr, docx, pdf, svg-draw
  
  For each skill, read its `SKILL.md` and summarize the skill's purpose and key capabilities.

## Example workspace-state.json

```json
{
  "initialized": true,
  "initialized_at": "2026-02-10T08:00:00Z",
  "files_created": [
    "IDENTITY.md",
    "SOUL.md",
    "USER.md",
    "BOOTSTRAP.md",
    "AGENTS.md",
    "TOOLS.md",
    "HEARTBEAT.md",
    "MEMOS_RESEARCH.md"
  ],
  "version": "1.0.0"
}
```

## Notes

- Each file should contain meaningful content relevant to its purpose, not just empty placeholders
- The workspace already contains existing skills and configurations — you **must** review them to populate TOOLS.md and AGENTS.md accurately
- After bootstrap, update HEARTBEAT.md with the current session status
- MEMOS_RESEARCH.md should document your actual search process, not a hypothetical one
