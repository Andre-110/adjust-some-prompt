---
id: task_00461_text_review_progress_skill
name: Text Review Progress Report Skill
category: Data Analysis and Modeling
subcategory: Quality Review and Diagnostics
difficulty: medium
grading_type: hybrid
grading_weights: {automated: 0.4, llm_judge: 0.6}
timeout_seconds: 600
input_modality: text-only
external_dependency: none
skill_creation: true
workspace_files:
  - source: assets/task_00461_text_review_progress_skill/text_review_tasks/tasks.json
    dest: text_review_tasks/tasks.json
    content: |
      [
        {"id": "TR-001", "title": "Product Description Batch A", "reviewer": "Alice Zhang", "status": "completed", "progress": 100, "total_items": 50, "reviewed_items": 50, "created_at": "2026-01-15T09:00:00Z", "updated_at": "2026-02-08T14:30:00Z"},
        {"id": "TR-002", "title": "Marketing Copy Q1", "reviewer": "Bob Wang", "status": "in_progress", "progress": 64, "total_items": 75, "reviewed_items": 48, "created_at": "2026-01-20T10:00:00Z", "updated_at": "2026-02-10T08:15:00Z"},
        {"id": "TR-003", "title": "Legal Disclaimer Updates", "reviewer": "Carol Li", "status": "in_progress", "progress": 30, "total_items": 40, "reviewed_items": 12, "created_at": "2026-02-01T11:00:00Z", "updated_at": "2026-02-09T16:45:00Z"},
        {"id": "TR-004", "title": "User Manual Revision", "reviewer": "Alice Zhang", "status": "not_started", "progress": 0, "total_items": 120, "reviewed_items": 0, "created_at": "2026-02-05T08:00:00Z", "updated_at": "2026-02-05T08:00:00Z"},
        {"id": "TR-005", "title": "FAQ Content Review", "reviewer": "Bob Wang", "status": "completed", "progress": 100, "total_items": 30, "reviewed_items": 30, "created_at": "2026-01-10T09:00:00Z", "updated_at": "2026-02-03T12:00:00Z"}
      ]
  - source: assets/task_00461_text_review_progress_skill/text_review_tasks/config.json
    dest: text_review_tasks/config.json
    content: |
      {
        "report_recipient": "Jun",
        "recipient_contact": "jun@company.com",
        "messaging_channel": "feishu",
        "feishu_webhook": "https://open.feishu.cn/open-apis/bot/v2/hook/abc123-fake",
        "report_format": "plain_text"
      }
  - source: assets/task_00461_text_review_progress_skill/text_review_tasks/reviewer_stats.json
    dest: text_review_tasks/reviewer_stats.json
    content: |
      {
        "generated_at": "2026-02-10T11:45:00+08:00",
        "reviewers": [
          {
            "name": "Alice Zhang",
            "reviewer_id": "RV-001",
            "role": "Senior Content Reviewer",
            "tasks_assigned": 16,
            "tasks_completed": 10,
            "tasks_in_progress": 3,
            "tasks_pending": 2,
            "tasks_flagged": 1,
            "avg_review_time_hours": 18.5,
            "issues_found_total": 13,
            "accuracy_score": 97.2
          },
          {
            "name": "Bob Wang",
            "reviewer_id": "RV-002",
            "role": "Content Reviewer",
            "tasks_assigned": 15,
            "tasks_completed": 9,
            "tasks_in_progress": 3,
            "tasks_pending": 2,
            "tasks_flagged": 2,
            "avg_review_time_hours": 22.3,
            "issues_found_total": 22,
            "accuracy_score": 94.8
          },
          {
            "name": "Carol Li",
            "reviewer_id": "RV-003",
            "role": "Content Reviewer",
            "tasks_assigned": 15,
            "tasks_completed": 8,
            "tasks_in_progress": 3,
            "tasks_pending": 2,
            "tasks_flagged": 2,
            "avg_review_time_hours": 20.1,
            "issues_found_total": 15,
            "accuracy_score": 95.5
          },
          {
            "name": "David Liu",
            "reviewer_id": "RV-004",
            "role": "Content Reviewer",
            "tasks_assigned": 15,
            "tasks_completed": 8,
            "tasks_in_progress": 4,
            "tasks_pending": 2,
            "tasks_flagged": 2,
            "avg_review_time_hours": 24.7,
            "issues_found_total": 14,
            "accuracy_score": 93.1
          }
        ]
      }
  - source: assets/task_00461_text_review_progress_skill/text_review_tasks/task_details.csv
    dest: text_review_tasks/task_details.csv
    content: |
      task_id,document_name,category,reviewer,status,priority,submitted_date,review_started,review_completed,issues_found,notes
      TRV-001,product_listing_batch_01.txt,E-commerce Listings,Alice Zhang,completed,high,2026-01-16,2026-01-17,2026-01-18,0,Clean pass
      TRV-002,user_comments_forum_jan.txt,User Generated Content,Bob Wang,completed,high,2026-01-16,2026-01-17,2026-01-19,3,Minor profanity flagged and redacted
      TRV-003,marketing_copy_spring.txt,Marketing Material,Alice Zhang,completed,medium,2026-01-17,2026-01-18,2026-01-20,1,Misleading claim in paragraph 4
      TRV-004,support_tickets_week03.txt,Customer Support,Carol Li,completed,medium,2026-01-18,2026-01-19,2026-01-21,0,All clear
      TRV-005,blog_post_ai_trends.txt,Blog Content,David Liu,completed,low,2026-01-18,2026-01-20,2026-01-22,0,Good quality
      TRV-006,product_listing_batch_02.txt,E-commerce Listings,Alice Zhang,completed,high,2026-01-19,2026-01-20,2026-01-22,2,Price formatting issues
      TRV-007,newsletter_feb_draft.txt,Marketing Material,Bob Wang,completed,medium,2026-01-20,2026-01-21,2026-01-23,1,Tone adjustment needed
      TRV-008,social_media_posts_jan.txt,Social Media,Carol Li,completed,high,2026-01-20,2026-01-21,2026-01-23,4,Multiple policy violations in 4 posts
      TRV-009,faq_update_v3.txt,Documentation,David Liu,completed,low,2026-01-21,2026-01-22,2026-01-24,0,Approved as-is
      TRV-010,user_reviews_electronics.txt,User Generated Content,Alice Zhang,completed,high,2026-01-22,2026-01-23,2026-01-26,6,Fake review patterns detected
      TRV-011,product_listing_batch_03.txt,E-commerce Listings,Bob Wang,completed,high,2026-01-23,2026-01-24,2026-01-27,1,Missing disclaimer
      TRV-012,internal_memo_q1_goals.txt,Internal Communications,Carol Li,completed,low,2026-01-24,2026-01-25,2026-01-27,0,No issues
      TRV-013,press_release_partnership.txt,Marketing Material,David Liu,completed,medium,2026-01-25,2026-01-26,2026-01-28,0,Well written
      TRV-014,chatbot_responses_v2.txt,Automated Content,Alice Zhang,completed,high,2026-01-26,2026-01-27,2026-01-29,2,Hallucinated product features
      TRV-015,user_comments_forum_feb.txt,User Generated Content,Bob Wang,completed,high,2026-01-27,2026-01-28,2026-01-30,5,Spam accounts identified
      TRV-016,product_listing_batch_04.txt,E-commerce Listings,Carol Li,completed,high,2026-01-28,2026-01-29,2026-01-31,0,Clean batch
      TRV-017,help_center_articles.txt,Documentation,David Liu,completed,low,2026-01-29,2026-01-30,2026-02-01,1,Outdated screenshot references
      TRV-018,advertising_campaign_feb.txt,Marketing Material,Alice Zhang,completed,medium,2026-01-30,2026-01-31,2026-02-02,0,Approved
      TRV-019,user_reviews_fashion.txt,User Generated Content,Bob Wang,completed,high,2026-01-31,2026-02-01,2026-02-03,3,Incentivized reviews found
      TRV-020,product_listing_batch_05.txt,E-commerce Listings,Carol Li,completed,high,2026-02-01,2026-02-02,2026-02-04,1,Prohibited item listing
      TRV-021,social_media_posts_feb.txt,Social Media,David Liu,in_progress,high,2026-02-02,2026-02-03,,0,Reviewing 45 posts
      TRV-022,blog_post_sustainability.txt,Blog Content,Alice Zhang,completed,low,2026-02-03,2026-02-04,2026-02-05,0,Good
      TRV-023,email_templates_promo.txt,Marketing Material,Bob Wang,completed,medium,2026-02-03,2026-02-04,2026-02-06,2,CAN-SPAM compliance issues
      TRV-024,user_comments_app_store.txt,User Generated Content,Carol Li,in_progress,high,2026-02-04,2026-02-05,,2,Large volume - still processing
      TRV-025,product_listing_batch_06.txt,E-commerce Listings,David Liu,completed,high,2026-02-04,2026-02-05,2026-02-07,0,All compliant
      TRV-026,chatbot_responses_v3.txt,Automated Content,Alice Zhang,in_progress,high,2026-02-05,2026-02-06,,1,Testing new prompt guardrails
      TRV-027,knowledge_base_update.txt,Documentation,Bob Wang,completed,medium,2026-02-05,2026-02-06,2026-02-08,0,Updated and verified
      TRV-028,partner_content_review.txt,Third Party Content,Carol Li,in_progress,medium,2026-02-06,2026-02-07,,0,Awaiting partner clarification
      TRV-029,user_reviews_home_garden.txt,User Generated Content,David Liu,in_progress,high,2026-02-06,2026-02-08,,3,Duplicate review patterns
      TRV-030,advertising_campaign_vday.txt,Marketing Material,Alice Zhang,completed,high,2026-02-07,2026-02-07,2026-02-08,0,Valentine campaign approved
      TRV-031,product_listing_batch_07.txt,E-commerce Listings,Bob Wang,in_progress,high,2026-02-07,2026-02-09,,0,Batch of 120 listings
      TRV-032,legal_terms_update.txt,Legal/Compliance,Carol Li,completed,high,2026-02-07,2026-02-08,2026-02-09,1,Clause 7.3 needs legal team sign-off
      TRV-033,push_notification_copy.txt,Marketing Material,David Liu,in_progress,medium,2026-02-08,2026-02-09,,0,12 notification variants
      TRV-034,user_comments_forum_feb_w2.txt,User Generated Content,Alice Zhang,in_progress,high,2026-02-08,2026-02-09,,0,Week 2 batch started
      TRV-035,support_tickets_week06.txt,Customer Support,Bob Wang,completed,medium,2026-02-08,2026-02-09,2026-02-10,0,Routine check complete
      TRV-036,influencer_content_batch.txt,Third Party Content,Carol Li,in_progress,medium,2026-02-09,2026-02-10,,0,Just started review
      TRV-037,product_listing_batch_08.txt,E-commerce Listings,David Liu,in_progress,high,2026-02-09,2026-02-10,,0,In early review
      TRV-038,seo_content_pages.txt,Marketing Material,Alice Zhang,in_progress,medium,2026-02-09,2026-02-10,,0,25 pages to review
      TRV-039,user_reviews_sports.txt,User Generated Content,Bob Wang,in_progress,high,2026-02-09,,,0,Not yet started review
      TRV-040,api_documentation_v4.txt,Documentation,Carol Li,in_progress,low,2026-02-09,2026-02-10,,0,Technical accuracy check
      TRV-041,product_listing_batch_09.txt,E-commerce Listings,David Liu,pending,high,2026-02-10,,,0,Queued for today
      TRV-042,community_guidelines_update.txt,Legal/Compliance,Alice Zhang,pending,high,2026-02-10,,,0,Priority review needed
      TRV-043,blog_post_industry_report.txt,Blog Content,Bob Wang,pending,low,2026-02-10,,,0,Not urgent
      TRV-044,user_comments_twitter.txt,Social Media,Carol Li,pending,high,2026-02-10,,,0,Batch ready
      TRV-045,video_transcript_reviews.txt,User Generated Content,David Liu,pending,medium,2026-02-10,,,0,New content type
      TRV-046,product_listing_batch_10.txt,E-commerce Listings,Alice Zhang,pending,high,2026-02-11,,,0,Tomorrow's batch
      TRV-047,email_campaign_march.txt,Marketing Material,Bob Wang,pending,medium,2026-02-11,,,0,Advance review
      TRV-048,chatbot_responses_v4.txt,Automated Content,Carol Li,pending,high,2026-02-12,,,0,New model outputs
      TRV-049,user_reviews_grocery.txt,User Generated Content,David Liu,pending,high,2026-02-12,,,0,Weekly batch
      TRV-050,product_listing_batch_11.txt,E-commerce Listings,Alice Zhang,pending,high,2026-02-13,,,0,Scheduled
      TRV-051,partner_onboarding_docs.txt,Third Party Content,Bob Wang,pending,medium,2026-02-13,,,0,New partner materials
      TRV-052,annual_report_draft.txt,Internal Communications,Carol Li,pending,low,2026-02-14,,,0,Low priority
      TRV-053,mobile_app_strings.txt,Documentation,David Liu,pending,low,2026-02-14,,,0,Localization review
      TRV-054,product_listing_batch_12.txt,E-commerce Listings,Alice Zhang,flagged,high,2026-02-05,2026-02-06,,5,Suspicious seller - escalated to legal
      TRV-055,user_reviews_electronics_v2.txt,User Generated Content,Bob Wang,flagged,high,2026-02-06,2026-02-07,,8,Coordinated fake review campaign
      TRV-056,social_media_influencer_ad.txt,Third Party Content,Carol Li,flagged,high,2026-02-07,2026-02-08,,3,Undisclosed sponsorship violations
      TRV-057,product_listing_restricted.txt,E-commerce Listings,David Liu,flagged,high,2026-02-08,2026-02-09,,4,Restricted substance claims
      TRV-058,user_comments_hate_speech.txt,User Generated Content,Alice Zhang,flagged,high,2026-02-09,2026-02-09,,12,Hate speech cluster - urgent action taken
      TRV-059,gambling_promotion_posts.txt,Social Media,Bob Wang,flagged,high,2026-02-09,2026-02-10,,6,Illegal gambling promotion
      TRV-060,counterfeit_listings.txt,E-commerce Listings,Carol Li,flagged,high,2026-02-10,2026-02-10,,9,Brand impersonation detected
      TRV-061,phishing_email_templates.txt,Automated Content,David Liu,flagged,high,2026-02-10,2026-02-10,,7,Phishing attempt templates found in system
  - source: assets/task_00461_text_review_progress_skill/text_review_tasks/tasks_overview.json
    dest: text_review_tasks/tasks_overview.json
    content: |
      {
        "project": "Q1 2026 Content Moderation Sprint",
        "project_id": "TXT-REV-2026-Q1",
        "created_at": "2026-01-15T09:00:00+08:00",
        "last_updated": "2026-02-10T11:45:00+08:00",
        "total_documents": 156,
        "summary": {
          "completed": 98,
          "in_progress": 31,
          "pending": 19,
          "flagged": 8,
          "overall_progress_pct": 62.8
        },
        "deadline": "2026-02-28T18:00:00+08:00",
        "owner": "Jun Wei",
        "stakeholders": ["Jun Wei", "Sarah Chen", "David Liu"]
      }
---

## Prompt

Hey, I need a reusable skill for monitoring and reporting on text review task progress. Can you create it as a SKILL.md file at `skills/text-review-monitor/SKILL.md` (under the workspace root)? It should be able to read task tracking data (JSON/CSV), compute overall and per-task progress stats, and generate a summary report suitable for sending to a stakeholder.

Think of it like a "text-review-monitor" skill — similar to how a store-analytics skill monitors store performance, but focused on text review pipelines.

Once you've created the skill, use it right away: check the current text review task progress in the `text_review_tasks/` directory and produce a progress report for Jun. Save the report to `progress_report.txt`. The report should include overall completion stats, per-task breakdowns, and flag any tasks that haven't started or are falling behind. Note that the report is intended for Jun (details in config.json) — just mention who it should be delivered to.

Current time: Tuesday, February 10th, 2026 — 11:57 AM (UTC)

## Expected Behavior

The agent should:

1. **Create a SKILL.md file** at `skills/text-review-monitor/SKILL.md` (under the workspace root) that defines a reusable "text-review-monitor" skill. The SKILL.md should have YAML frontmatter with `name` and `description` fields, followed by markdown sections describing how to read task data, compute progress metrics, and generate reports. This is inspired by similar skills like `clawver-store-analytics` (monitoring performance) and `design-assets` (managing assets).

2. **Read the task data** from `text_review_tasks/tasks.json` to understand the current state of all review tasks.

3. **Read the config** from `text_review_tasks/config.json` to identify the recipient (Jun) and delivery details.

4. **Generate a progress report** saved to `progress_report.txt` that includes:
   - Overall progress summary (e.g., 2 of 5 tasks completed, overall item completion rate of approximately 44.4% with 140 of 315 items reviewed)
   - Per-task breakdown with task ID, title, reviewer, status, and progress percentage
   - Flagging of tasks that are not started (TR-004) or potentially behind schedule
   - A note that the report should be delivered to Jun

5. The report should be clear, well-structured plain text suitable for a stakeholder.

## Grading Criteria

- [ ] SKILL.md exists at `skills/text-review-monitor/SKILL.md` (under the workspace root) with proper YAML frontmatter (name and description fields)
- [ ] SKILL.md contains meaningful instruction sections about text review monitoring
- [ ] progress_report.txt exists and is non-empty
- [ ] Report mentions overall completion statistics
- [ ] Report includes per-task breakdown with task IDs
- [ ] Report flags the not-started task (TR-004)
- [ ] Report mentions Jun as the intended recipient
- [ ] Report references specific data from tasks.json (reviewer names, progress numbers)

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    import os
    import re

    scores = {
        "skill_md_exists_and_structured": 0.0,
        "progress_report_exists": 0.0,
        "report_contains_task_data": 0.0,
        "report_mentions_recipient": 0.0,
        "report_flags_issues": 0.0,
    }

    # 1. Check SKILL.md exists and has proper structure
    skill_path = os.path.join(workspace_path, "skills", "text-review-monitor", "SKILL.md")
    if os.path.isfile(skill_path):
        try:
            with open(skill_path, "r", encoding="utf-8") as f:
                skill_content = f.read()
            has_frontmatter = skill_content.strip().startswith("---")
            has_name = bool(re.search(r"(?i)name\s*:", skill_content[:500]))
            has_description = bool(re.search(r"(?i)description\s*:", skill_content[:500]))
            has_sections = len(re.findall(r"^#{1,3}\s+", skill_content, re.MULTILINE)) >= 1
            has_meaningful_content = len(skill_content) > 200

            if has_frontmatter and has_name and has_description and has_sections and has_meaningful_content:
                scores["skill_md_exists_and_structured"] = 1.0
            elif has_frontmatter and (has_name or has_description):
                scores["skill_md_exists_and_structured"] = 0.6
            elif has_meaningful_content:
                scores["skill_md_exists_and_structured"] = 0.3
        except Exception:
            scores["skill_md_exists_and_structured"] = 0.0

    # 2. Check progress_report.txt exists and is non-empty
    report_path = os.path.join(workspace_path, "progress_report.txt")
    report_content = ""
    if os.path.isfile(report_path):
        try:
            with open(report_path, "r", encoding="utf-8") as f:
                report_content = f.read()
            if len(report_content.strip()) > 50:
                scores["progress_report_exists"] = 1.0
            elif len(report_content.strip()) > 0:
                scores["progress_report_exists"] = 0.5
        except Exception:
            scores["progress_report_exists"] = 0.0

    # 3. Check report contains actual task data from tasks.json
    if report_content:
        task_ids_found = sum(1 for tid in ["TR-001", "TR-002", "TR-003", "TR-004", "TR-005"]
                            if tid in report_content)
        reviewer_names_found = sum(1 for name in ["Alice", "Bob", "Carol"]
                                   if name in report_content)
        has_progress_numbers = bool(re.search(r"(100|64|30|0)\s*%", report_content) or
                                    re.search(r"progress.*?(100|64|30)", report_content, re.IGNORECASE))
        has_status_info = any(s in report_content.lower() for s in ["completed", "in_progress", "in progress", "not_started", "not started"])

        data_score = 0.0
        if task_ids_found >= 4:
            data_score += 0.4
        elif task_ids_found >= 2:
            data_score += 0.2
        if reviewer_names_found >= 2:
            data_score += 0.2
        if has_progress_numbers:
            data_score += 0.2
        if has_status_info:
            data_score += 0.2
        scores["report_contains_task_data"] = min(data_score, 1.0)

    # 4. Check report mentions Jun as recipient
    if report_content:
        if re.search(r"\bJun\b", report_content):
            scores["report_mentions_recipient"] = 1.0

    # 5. Check report flags issues (not started tasks, behind schedule)
    if report_content:
        content_lower = report_content.lower()
        flags_not_started = ("not started" in content_lower or "not_started" in content_lower or
                             ("tr-004" in content_lower and any(w in content_lower for w in ["pending", "flag", "attention", "behind", "not begun", "0%"])))
        flags_behind = any(w in content_lower for w in ["behind", "delayed", "attention", "risk", "flag", "concern", "overdue", "slow"])

        if flags_not_started and flags_behind:
            scores["report_flags_issues"] = 1.0
        elif flags_not_started:
            scores["report_flags_issues"] = 0.7
        elif flags_behind:
            scores["report_flags_issues"] = 0.4

    return scores
```

## LLM Judge Rubric

### Skill Quality and Reusability (Weight: 25%)
- 1.0: SKILL.md is well-structured with YAML frontmatter (name, description), clear sections covering data ingestion, metric computation, and report generation; could genuinely be reused for different review datasets
- 0.75: SKILL.md exists with frontmatter and reasonable instructions but is somewhat generic or missing one key section
- 0.5: SKILL.md exists but is minimal, lacks proper frontmatter, or is too vague to be reusable
- 0.25: SKILL.md exists but is essentially a stub or placeholder with little useful content
- 0.0: No SKILL.md created, or the file is empty / completely unrelated to text review monitoring

### Report Completeness and Accuracy (Weight: 30%)
- 1.0: Progress report includes accurate overall stats (2/5 completed, item-level completion rate of approximately 44.4%), per-task breakdown with IDs/titles/reviewers/status/progress, and all numbers match the source data
- 0.75: Report covers most tasks with mostly accurate data but may be missing one element (e.g., item counts or one task)
- 0.5: Report has a partial breakdown — covers some tasks or provides overall stats but not both in detail
- 0.25: Report exists but contains significant inaccuracies or only superficial information
- 0.0: No report produced, report is empty, or content is completely disconnected from the task data in tasks.json

### Evidence and Workspace Grounding (Weight: 25%)
- 1.0: Report clearly references specific data from tasks.json (task IDs, reviewer names, exact progress percentages, item counts) and config.json (Jun's details); no hallucinated data
- 0.75: Report references most data points from the workspace files with minor omissions
- 0.5: Report uses some real data but also includes vague or unsupported claims
- 0.25: Report has minimal grounding in actual workspace files; mostly generic statements
- 0.0: Report ignores the workspace files entirely, hallucinates data not present in the provided files, or no deliverable is produced

### Issue Identification and Actionability (Weight: 20%)
- 1.0: Report clearly flags TR-004 as not started, identifies tasks that may be behind schedule, and provides actionable context (e.g., days since creation, remaining items)
- 0.75: Report flags the not-started task and mentions potential delays but with less actionable detail
- 0.5: Report notes task statuses but doesn't explicitly call out risks or issues
- 0.25: Report lists statuses without any analysis or flagging
- 0.0: No issue identification or the report fails to distinguish between completed and problematic tasks