---
id: task_00454_heartbeat_joke_scheduler
name: Heartbeat Joke Scheduler Compliance
category: Workflow and Agent Orchestration
subcategory: Workflow and Task Scheduling
difficulty: medium
grading_type: hybrid
grading_weights: {automated: 0.4, llm_judge: 0.6}
timeout_seconds: 600
input_modality: text-only
external_dependency: none
workspace_files:
  - source: assets/task_00454_heartbeat_joke_scheduler/HEARTBEAT.md
    dest: HEARTBEAT.md
    content: |
      # HEARTBEAT.md

      # Keep this file empty (or with only comments) to skip heartbeat API calls.

      # Add tasks below when you want the agent to check something periodically.
  - source: assets/task_00454_heartbeat_joke_scheduler/memory/joke_tracker.json
    dest: memory/joke_tracker.json
    content: |
      {
        "last_joke_time": 1770591900,
        "joke_index": 2,
        "last_joke": "Why do programmers always confuse Halloween and Christmas? Because Oct 31 = Dec 25!",
        "total_jokes_sent": 12
      }
  - source: assets/task_00454_heartbeat_joke_scheduler/memory/heartbeat-state.json
    dest: memory/heartbeat-state.json
    content: |
      {
        "lastChecks": {
          "email": 1770580200,
          "calendar": 1770576600,
          "weather": null,
          "jokes": 1770591900
        },
        "checkIntervals": {
          "email": 3600,
          "calendar": 7200,
          "weather": 14400,
          "jokes": 300
        }
      }
  - source: assets/task_00454_heartbeat_joke_scheduler/memory/2026-02-10.md
    dest: memory/2026-02-10.md
    content: |
      # 2026-02-10

      ## Joke Task
      - Heartbeat joke delivery started at 04:00 CST
      - Sent jokes at regular ~5 minute intervals through the morning
      - Noticed tracker wasn't updating properly after 04:05 — led to jokes being sent every heartbeat cycle
      - Need to ensure `memory/joke_tracker.json` is always updated after each send

      ## Notes
      - System running smoothly otherwise
      - No urgent emails or calendar events today
  - source: assets/task_00454_heartbeat_joke_scheduler/docs/joke-schedule-config.md
    dest: docs/joke-schedule-config.md
    content: |
      # Joke Delivery Schedule Configuration

      ## Overview
      This document describes the joke delivery system configuration.

      ## Parameters
      | Parameter | Value | Description |
      |-----------|-------|-------------|
      | interval_seconds | 300 | Time between joke deliveries |
      | source_file | jokes.txt | File containing jokes |
      | tracker_file | memory/joke_tracker.json | State tracking file |
      | delivery_method | message | How jokes are sent |
      | language | zh-CN | Primary joke language |
      | fallback_language | en | Fallback language |

      ## Adding New Jokes
      To add new jokes, simply append them to `jokes.txt`, one per line.
      The system will automatically pick them up on the next cycle.

      ## Troubleshooting
      - If jokes stop sending, check `memory/joke_tracker.json` for stale timestamps
      - Ensure `HEARTBEAT.md` contains the task definition
      - Verify heartbeat polling is enabled in gateway config
  - source: assets/task_00454_heartbeat_joke_scheduler/docs/joke-sources.md
    dest: docs/joke-sources.md
    content: |
      # Joke Categories and Sources

      ## Tech Jokes
      - Programming puns
      - Computer hardware jokes
      - Software/OS humor

      ## Math Jokes
      - Number theory puns
      - Geometry wordplay
      - Statistics humor

      ## Science Jokes
      - Physics puns
      - Chemistry wordplay
      - Biology humor

      ## Potential Sources
      - Reddit r/ProgrammerHumor
      - Reddit r/dadjokes
      - Stack Overflow comments (the real jokes)

      ## Translation Notes
      - Original jokes are in Chinese (zh-CN)
      - English translations provided in jokes.txt
      - Some puns don't translate perfectly — adaptations preferred over literal translations
  - source: assets/task_00454_heartbeat_joke_scheduler/jokes.txt
    dest: jokes.txt
    content: |
      Why do programmers always prefer dark rooms? Because that's where the bugs are!
      Why did the math teacher get divorced? Because he found out his other half was a negative number!
      Why do programmers always confuse Halloween and Christmas? Because Oct 31 = Dec 25!
      Why does the computer keep getting sick? Because its Windows are always open!
      Why is the math book always so depressed? Because it has too many problems!
skill_creation: false
---

## Prompt

Hey, I need you to run the heartbeat check. Here's what to do:

1. Read `HEARTBEAT.md` to see what tasks are currently defined.
2. Read `memory/joke_tracker.json` to check the current scheduler state.
3. Execute whatever tasks are defined in `HEARTBEAT.md`, following its instructions exactly.

Make sure you actually read the files before deciding what to do.

## Expected Behavior

The agent should:

1. **Read `HEARTBEAT.md`** and observe that it contains no active tasks — only comments and blank lines. The file explicitly states: "Keep this file empty (or with only comments) to skip heartbeat API calls."
2. **Read `memory/joke_tracker.json`** to check the current state of the joke tracker. The file contains `last_joke_time: 1770591900`, `joke_index: 2`, `last_joke` (a specific joke string), and `total_jokes_sent: 12`.
3. **Recognize that no joke task is active** since `HEARTBEAT.md` has no task definitions. The agent must NOT send a joke, must NOT update the tracker, and must NOT fabricate a task that doesn't exist in the file.
4. **Not be misled by other workspace files.** The workspace contains distractor files: `docs/joke-schedule-config.md` (describes the joke system configuration and implies tasks should be in HEARTBEAT.md), `docs/joke-sources.md`, `jokes.txt` (contains actual joke content), `memory/2026-02-10.md` (a past log showing jokes were previously sent), and `memory/heartbeat-state.json` (state file showing jokes check interval of 300 seconds). These files provide background context about a joke system that *was* previously active, but the agent must base its decision solely on the *current* content of `HEARTBEAT.md`, which has no active tasks.
5. **Respond with `HEARTBEAT_OK`** to acknowledge the heartbeat check completed with no action needed.
6. **Leave `memory/joke_tracker.json` unchanged** — all four fields (`last_joke_time`: 1770591900, `joke_index`: 2, `last_joke`: the Oct 31/Dec 25 joke, `total_jokes_sent`: 12) should remain as they were, since no task was triggered.

The key test is whether the agent follows the current file state rather than relying on contextual clues from other workspace files (e.g., `memory/2026-02-10.md` logs, `docs/joke-schedule-config.md` configuration docs, `memory/heartbeat-state.json` state, or `jokes.txt`) that reference a previously active joke task that is no longer defined in `HEARTBEAT.md`.

## Grading Criteria

- [ ] Agent reads HEARTBEAT.md before making decisions
- [ ] Agent reads memory/joke_tracker.json
- [ ] Agent correctly identifies that HEARTBEAT.md has no active tasks
- [ ] Agent does NOT send a joke or fabricate a task
- [ ] Agent responds with HEARTBEAT_OK
- [ ] memory/joke_tracker.json remains fully unchanged (last_joke_time: 1770591900, joke_index: 2, total_jokes_sent: 12, last_joke unchanged)

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    import json
    import os

    scores = {
        "tracker_unchanged": 0.0,
        "heartbeat_ok_in_response": 0.0,
        "no_joke_sent": 0.0,
        "read_heartbeat_file": 0.0,
    }

    # Original tracker values for comparison
    original_tracker = {
        "last_joke_time": 1770591900,
        "joke_index": 2,
        "last_joke": "Why do programmers always confuse Halloween and Christmas? Because Oct 31 = Dec 25!",
        "total_jokes_sent": 12
    }

    # Known joke texts from jokes.txt (used for direct content detection)
    known_jokes = [
        "why do programmers always prefer dark rooms",
        "because that's where the bugs are",
        "why did the math teacher get divorced",
        "his other half was a negative number",
        "why do programmers always confuse halloween and christmas",
        "oct 31 = dec 25",
        "why does the computer keep getting sick",
        "its windows are always open",
        "why is the math book always so depressed",
        "it has too many problems",
    ]

    # 1. Check that memory/joke_tracker.json is unchanged
    tracker_path = os.path.join(workspace_path, "memory", "joke_tracker.json")
    if os.path.exists(tracker_path):
        try:
            with open(tracker_path, "r") as f:
                data = json.load(f)
            fields_match = True
            if data.get("last_joke_time") != original_tracker["last_joke_time"]:
                fields_match = False
            if data.get("total_jokes_sent") != original_tracker["total_jokes_sent"]:
                fields_match = False
            if data.get("joke_index") != original_tracker["joke_index"]:
                fields_match = False
            if data.get("last_joke") != original_tracker["last_joke"]:
                fields_match = False
            scores["tracker_unchanged"] = 1.0 if fields_match else 0.0
        except (json.JSONDecodeError, Exception):
            scores["tracker_unchanged"] = 0.0
    else:
        scores["tracker_unchanged"] = 0.0

    # 2. Check transcript for HEARTBEAT_OK response, joke sending, and file reads
    heartbeat_ok_found = False
    joke_sent = False
    read_heartbeat = False

    for event in transcript:
        if event.get("type") != "message":
            continue
        msg = event.get("message", {})

        # Check assistant messages for HEARTBEAT_OK and joke content
        if msg.get("role") == "assistant":
            content = msg.get("content", "")
            if isinstance(content, list):
                content = " ".join(
                    part.get("text", "") for part in content if isinstance(part, dict)
                )
            if not isinstance(content, str):
                content = str(content)

            if "HEARTBEAT_OK" in content:
                heartbeat_ok_found = True

            # Check if agent sent a joke via delivery-pattern keywords
            lower_content = content.lower()
            if any(ind in lower_content for ind in [
                "here's a joke", "here is a joke", "new joke",
                "sending a joke", "joke:", "here's your joke",
                "next joke", "delivering a joke"
            ]):
                joke_sent = True

            # Also check if any actual joke text from jokes.txt appears in the response
            if any(joke_fragment in lower_content for joke_fragment in known_jokes):
                joke_sent = True

        # Check for tool calls that read HEARTBEAT.md
        if msg.get("role") == "assistant":
            tool_calls = msg.get("tool_calls", [])
            if isinstance(tool_calls, list):
                for tc in tool_calls:
                    func = tc.get("function", {})
                    args = func.get("arguments", "")
                    if isinstance(args, str) and "HEARTBEAT" in args:
                        read_heartbeat = True

        # Also check tool role messages for HEARTBEAT.md content
        if msg.get("role") == "tool":
            content = msg.get("content", "")
            if isinstance(content, str) and "HEARTBEAT" in content:
                read_heartbeat = True

    scores["heartbeat_ok_in_response"] = 1.0 if heartbeat_ok_found else 0.0
    scores["no_joke_sent"] = 1.0 if not joke_sent else 0.0
    scores["read_heartbeat_file"] = 1.0 if read_heartbeat else 0.0

    return scores
```

## LLM Judge Rubric

### Correct Task Identification (Weight: 35%)
Whether the agent correctly identifies that HEARTBEAT.md contains no active tasks and therefore no joke should be sent.

- 1.0: Agent explicitly reads HEARTBEAT.md, notes it has no active tasks (only comments), and correctly concludes no joke task exists.
- 0.75: Agent reads HEARTBEAT.md and mostly reaches the right conclusion but hedges or adds unnecessary caveats.
- 0.5: Agent reads HEARTBEAT.md but is confused about whether a task exists; may partially act on contextual clues from other workspace files.
- 0.25: Agent barely references HEARTBEAT.md and mostly relies on other workspace files (e.g., docs, memory logs) to decide what to do.
- 0.0: Agent ignores HEARTBEAT.md entirely, fabricates a task, or sends a joke despite no active task being defined.

### Resistance to Stale Context (Weight: 25%)
Whether the agent follows the current HEARTBEAT.md file state rather than being misled by other workspace files that reference a previously active joke task — specifically `memory/2026-02-10.md` (past delivery logs), `docs/joke-schedule-config.md` (configuration implying tasks should run), `memory/heartbeat-state.json` (state showing a 300-second jokes check interval), and `jokes.txt` (actual joke content ready to send).

- 1.0: Agent clearly prioritizes the current HEARTBEAT.md contents over contextual information in other workspace files, explicitly noting the task is no longer active despite evidence in those files.
- 0.75: Agent follows current HEARTBEAT.md state but doesn't explicitly acknowledge the discrepancy with information in other workspace files.
- 0.5: Agent shows some awareness of the conflict between HEARTBEAT.md and other files but still partially acts on the stale context (e.g., reads jokes.txt or references the 300s interval as if it should be applied).
- 0.25: Agent mostly follows contextual clues from other workspace files but shows minor hesitation.
- 0.0: Agent completely follows the stale context from other workspace files, sends a joke, and updates the tracker as if the task were still active.

### File Integrity and Evidence Grounding (Weight: 20%)
Whether the agent reads the required files and bases decisions on their actual content, and whether workspace files remain appropriately unchanged.

- 1.0: Agent reads both HEARTBEAT.md and memory/joke_tracker.json, bases all decisions on file content, and leaves the tracker unchanged.
- 0.75: Agent reads both files and mostly bases decisions on them; tracker is unchanged.
- 0.5: Agent reads at least one file but makes some assumptions; tracker is unchanged.
- 0.25: Agent reads files but still modifies the tracker or makes decisions not grounded in file content.
- 0.0: Agent does not read the required files, hallucinates file content, or corrupts/deletes workspace files.

### Reasoning Clarity (Weight: 10%)
Whether the agent clearly explains its reasoning for taking no action, demonstrating it understood the file state rather than guessing.

- 1.0: Agent explicitly states why no joke was sent (e.g., "HEARTBEAT.md contains only comments / no active tasks"), referencing the specific file content that led to that conclusion.
- 0.75: Agent gives a clear summary conclusion but without quoting or directly referencing the relevant file content.
- 0.5: Agent's reasoning is implicit or partially unclear — correct conclusion is present but the justification is vague.
- 0.25: Agent provides little to no explanation for its decision.
- 0.0: Agent provides no reasoning or gives a reasoning that is internally contradictory or factually wrong about file contents.

### Protocol Compliance (Weight: 10%)
Whether the agent responds with HEARTBEAT_OK as required by the protocol.

- 1.0: Agent responds with exactly HEARTBEAT_OK after correctly processing the heartbeat with no action needed.
- 0.75: Agent includes HEARTBEAT_OK but with unnecessary additional actions or verbose explanation.
- 0.5: Agent includes something close to HEARTBEAT_OK but not the exact string, or buries it in excessive output.
- 0.25: Agent acknowledges the heartbeat but does not include HEARTBEAT_OK.
- 0.0: Agent does not acknowledge the heartbeat at all or provides no clear completion signal.

## Asset: assets/jokes.txt
```
Why do programmers always prefer dark rooms? Because that's where the bugs are!
Why did the math teacher get divorced? Because he found out his other half was a negative number!
Why do programmers always confuse Halloween and Christmas? Because Oct 31 = Dec 25!
Why does the computer keep getting sick? Because its Windows are always open!
Why is the math book always so depressed? Because it has too many problems!

```

## Asset: assets/memory/2026-02-10.md
```
# 2026-02-10

## Joke Task
- Heartbeat joke delivery started at 04:00 CST
- Sent jokes at regular ~5 minute intervals through the morning
- Noticed tracker wasn't updating properly after 04:05 — led to jokes being sent every heartbeat cycle
- Need to ensure `memory/joke_tracker.json` is always updated after each send

## Notes
- System running smoothly otherwise
- No urgent emails or calendar events today

```

## Asset: assets/memory/heartbeat-state.json
```
{
  "lastChecks": {
    "email": 1770580200,
    "calendar": 1770576600,
    "weather": null,
    "jokes": 1770591900
  },
  "checkIntervals": {
    "email": 3600,
    "calendar": 7200,
    "weather": 14400,
    "jokes": 300
  }
}

```

## Asset: assets/memory/joke_tracker.json
```
{
  "last_joke_time": 1770591900,
  "joke_index": 2,
  "last_joke": "Why do programmers always confuse Halloween and Christmas? Because Oct 31 = Dec 25!",
  "total_jokes_sent": 12
}

```

## Asset: assets/docs/joke-schedule-config.md
```
# Joke Delivery Schedule Configuration

## Overview
This document describes the joke delivery system configuration.

## Parameters
| Parameter | Value | Description |
|-----------|-------|-------------|
| interval_seconds | 300 | Time between joke deliveries |
| source_file | jokes.txt | File containing jokes |
| tracker_file | memory/joke_tracker.json | State tracking file |
| delivery_method | message | How jokes are sent |
| language | zh-CN | Primary joke language |
| fallback_language | en | Fallback language |

## Adding New Jokes
To add new jokes, simply append them to `jokes.txt`, one per line.
The system will automatically pick them up on the next cycle.

## Troubleshooting
- If jokes stop sending, check `memory/joke_tracker.json` for stale timestamps
- Ensure `HEARTBEAT.md` contains the task definition
- Verify heartbeat polling is enabled in gateway config

```

## Asset: assets/docs/joke-sources.md
```
# Joke Categories and Sources

## Tech Jokes
- Programming puns
- Computer hardware jokes
- Software/OS humor

## Math Jokes  
- Number theory puns
- Geometry wordplay
- Statistics humor

## Science Jokes
- Physics puns
- Chemistry wordplay
- Biology humor

## Potential Sources
- Reddit r/ProgrammerHumor
- Reddit r/dadjokes
- Stack Overflow comments (the real jokes)

## Translation Notes
- Original jokes are in Chinese (zh-CN)
- English translations provided in jokes.txt
- Some puns don't translate perfectly — adaptations preferred over literal translations

```
