# Joke Categories and Sources

## Tech Jokes
- Programming puns
- Computer hardware jokes
- Software/OS humor

## Math Jokes  
- Number theory puns
- Geometry wordplay
- Statistics humor

## Science Jokes
- Physics puns
- Chemistry wordplay
- Biology humor

## Potential Sources
- Reddit r/ProgrammerHumor
- Reddit r/dadjokes
- Stack Overflow comments (the real jokes)

## Translation Notes
- Original jokes are in Chinese (zh-CN)
- English translations provided in jokes.txt
- Some puns don't translate perfectly — adaptations preferred over literal translations
