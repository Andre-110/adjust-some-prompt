# Joke Delivery Schedule Configuration

## Overview
This document describes the joke delivery system configuration.

## Parameters
| Parameter | Value | Description |
|-----------|-------|-------------|
| interval_seconds | 300 | Time between joke deliveries |
| source_file | jokes.txt | File containing jokes |
| tracker_file | memory/joke_tracker.json | State tracking file |
| delivery_method | message | How jokes are sent |
| language | zh-CN | Primary joke language |
| fallback_language | en | Fallback language |

## Adding New Jokes
To add new jokes, simply append them to `jokes.txt`, one per line.
The system will automatically pick them up on the next cycle.

## Troubleshooting
- If jokes stop sending, check `memory/joke_tracker.json` for stale timestamps
- Ensure `HEARTBEAT.md` contains the task definition
- Verify heartbeat polling is enabled in gateway config
