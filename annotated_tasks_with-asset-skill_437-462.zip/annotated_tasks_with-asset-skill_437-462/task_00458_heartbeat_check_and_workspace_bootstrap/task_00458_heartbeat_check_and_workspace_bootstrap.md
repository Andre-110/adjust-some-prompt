---
id: task_00458_heartbeat_check_and_workspace_bootstrap
name: Heartbeat Check and Workspace Bootstrap
category: Workflow and Agent Orchestration
subcategory: Workflow and Task Scheduling
difficulty: medium
grading_type: hybrid
grading_weights: {automated: 0.4, llm_judge: 0.6}
timeout_seconds: 600
input_modality: text-only
external_dependency: none
workspace_files:
  - source: assets/task_00458_heartbeat_check_and_workspace_bootstrap/automation/config/gold_price_config.json
    dest: "automation/config/gold_price_config.json"
    content: |
      {
        "monitoring": {
          "enabled": true,
          "intervalMinutes": 30,
          "alertThresholdPercent": 5.0,
          "sources": [
            {
              "name": "tavily",
              "enabled": true,
              "apiKey": "tvly-XXXXXXXXXXXXXXXXXXXX",
              "endpoint": "https://api.tavily.com/search",
              "knownIssues": ["false_positive_77_percent_change"]
            },
            {
              "name": "browser_automation",
              "enabled": true,
              "targetUrl": "https://www.kitco.com/charts/livegold.html",
              "fallback": true
            }
          ],
          "priceRange": {
            "expectedMin": 4800,
            "expectedMax": 5200,
            "currency": "USD",
            "unit": "troy_ounce"
          }
        },
        "storage": {
          "dataDir": "automation/data/gold",
          "filePattern": "gold_price_{timestamp}.json",
          "retentionDays": 30,
          "maxFiles": 1000
        },
        "alerts": {
          "enabled": true,
          "channels": ["console", "notification"],
          "suppressKnownFalsePositives": true,
          "falsePositivePatterns": [
            {
              "source": "tavily",
              "pattern": "change_percent_gt_70",
              "reason": "Data source parsing error"
            }
          ]
        }
      }
  - source: assets/task_00458_heartbeat_check_and_workspace_bootstrap/automation/scripts/gold_price_monitor.js
    dest: "automation/scripts/gold_price_monitor.js"
    content: |
      // Gold price monitor script
      // Fetches current gold price and saves to data directory
      const fs = require('fs');
      const config = require('../config/gold_price_config.json');
      console.log('Gold price monitor running...');
      console.log('Interval:', config.monitoring.intervalMinutes, 'minutes');
      // Placeholder for actual monitoring logic
  - source: assets/task_00458_heartbeat_check_and_workspace_bootstrap/openclaw-gmail-setup/check_emails_fixed.js
    dest: "openclaw-gmail-setup/check_emails_fixed.js"
    content: |
      // Gmail checker script with OAuth
      // Checks for new emails and returns summary
      const fs = require('fs');
      console.log('Checking Gmail for new emails...');
      // Placeholder for OAuth and Gmail API logic
  - source: assets/task_00458_heartbeat_check_and_workspace_bootstrap/automation/data/gold/gold_price_2026-02-09T04-03-43-366Z.json
    dest: "automation/data/gold/gold_price_2026-02-09T04-03-43-366Z.json"
    content: |
      {
        "timestamp": "2026-02-09T04:03:43.366Z",
        "source": "browser_kitco",
        "price": {"current": 4969.18, "bid": 4967.57, "ask": 4970.05, "currency": "USD", "unit": "troy_ounce"},
        "change": {"absolute": 0, "percent": 0},
        "volatility": {"current_session": 0.1779, "threshold": 5.0, "status": "normal"},
        "market": {"session": "GLOBEX", "volume": 51717, "openInterest": 515741},
        "metadata": {"fetchDurationMs": 1156, "retries": 0, "dataQuality": "verified"}
      }
  - source: assets/task_00458_heartbeat_check_and_workspace_bootstrap/automation/data/gold/gold_price_2026-02-09T20-01-16-718Z.json
    dest: "automation/data/gold/gold_price_2026-02-09T20-01-16-718Z.json"
    content: |
      {
        "timestamp": "2026-02-09T20:01:16.718Z",
        "source": "browser_kitco",
        "price": {"current": 4960.21, "bid": 4959.38, "ask": 4961.85, "currency": "USD", "unit": "troy_ounce"},
        "change": {"absolute": -11.27, "percent": -0.2268},
        "volatility": {"current_session": 0.1704, "threshold": 5.0, "status": "normal"},
        "market": {"session": "COMEX", "volume": 69898, "openInterest": 486338},
        "metadata": {"fetchDurationMs": 2270, "retries": 0, "dataQuality": "verified"}
      }
  - source: assets/task_00458_heartbeat_check_and_workspace_bootstrap/automation/data/gold/gold_price_2026-02-09T20-01-49-307Z_tavily_anomaly.json
    dest: "automation/data/gold/gold_price_2026-02-09T20-01-49-307Z_tavily_anomaly.json"
    content: |
      {
        "timestamp": "2026-02-09T20:01:49.307Z",
        "source": "tavily",
        "price": {"current": 8793.45, "bid": 8792.1, "ask": 8794.8, "currency": "USD", "unit": "troy_ounce"},
        "change": {"absolute": 3828.45, "percent": 77.12},
        "volatility": {"current_session": 77.12, "threshold": 5.0, "status": "ANOMALY_DETECTED"},
        "market": {"session": "COMEX", "volume": 67234, "openInterest": 498321},
        "metadata": {
          "fetchDurationMs": 2100,
          "retries": 0,
          "dataQuality": "SUSPECT",
          "notes": "Tavily API parsing error - concatenated adjacent price values, not a real price change",
          "suppressedAlert": true,
          "suppressionReason": "Known false positive: Tavily data source parsing error"
        }
      }
  - source: assets/task_00458_heartbeat_check_and_workspace_bootstrap/automation/data/gold/gold_price_2026-02-10T02-04-03-377Z.json
    dest: "automation/data/gold/gold_price_2026-02-10T02-04-03-377Z.json"
    content: |
      {
        "timestamp": "2026-02-10T02:04:03.377Z",
        "source": "browser_kitco",
        "price": {"current": 4979.13, "bid": 4977.61, "ask": 4979.8, "currency": "USD", "unit": "troy_ounce"},
        "change": {"absolute": 24.33, "percent": 0.4911},
        "volatility": {"current_session": 0.327, "threshold": 5.0, "status": "normal"},
        "market": {"session": "GLOBEX", "volume": 62486, "openInterest": 502293},
        "metadata": {"fetchDurationMs": 1256, "retries": 0, "dataQuality": "verified"}
      }
  - source: assets/task_00458_heartbeat_check_and_workspace_bootstrap/automation/data/news/news_2026-02-09T22-00-12-058Z.json
    dest: "automation/data/news/news_2026-02-09T22-00-12-058Z.json"
    content: |
      {
        "fetchTimestamp": "2026-02-09T22:00:12.058Z",
        "totalResults": 11,
        "sources_queried": 7,
        "articles": [
          {"id": "news_2026-02-09_002", "title": "Gold prices remain steady amid geopolitical tensions in Middle East", "source": "Bloomberg", "category": "markets", "publishedAt": "2026-02-09T22:00:12.058Z", "url": "https://example.com/news/138528", "snippet": "Brief summary of: Gold prices remain steady amid geopolitical tensions in Middle East...", "relevanceScore": 0.892},
          {"id": "news_2026-02-09_008", "title": "Federal Reserve signals potential rate adjustment in March meeting", "source": "Reuters", "category": "markets", "publishedAt": "2026-02-09T22:00:12.058Z", "url": "https://example.com/news/430577", "snippet": "Brief summary of: Federal Reserve signals potential rate adjustment in March meeting...", "relevanceScore": 0.605}
        ],
        "fetchDurationMs": 3332
      }
skill_creation: false
---

## Prompt

You are running as an automated monitoring agent. A system heartbeat has been triggered.

Your first task is to check whether a `HEARTBEAT.md` file exists in the workspace root.

- **If `HEARTBEAT.md` exists**: read it carefully and follow its instructions exactly. Do not infer tasks from prior context or repeat completed work. If there are no new actionable tasks listed, respond with `HEARTBEAT_OK`.
- **If `HEARTBEAT.md` does not exist**: the workspace has not been bootstrapped yet. Explore the workspace to understand what monitoring systems are present, then create the necessary initialization files. After completing the bootstrap, perform the heartbeat check on the newly created `HEARTBEAT.md` and respond appropriately.

The workspace contains automation configuration, scripts, and historical data. Read the relevant files to understand the system before creating any documentation.

Also initialize a git repository in the workspace root so that future changes can be tracked.

## Expected Behavior

The agent should:

1. Check whether `HEARTBEAT.md` exists in the workspace root (it does not exist initially).
2. Explore the workspace to understand the monitoring system:
   - Read `automation/config/gold_price_config.json` to discover monitoring interval (30 min), price range thresholds (4800–5200 USD), alert rules, and false positive suppression patterns.
   - Examine data files under `automation/data/gold/` to determine recent observed prices and identify any anomalous readings.
   - Examine `automation/data/news/` to understand the news monitoring cadence.
   - Examine `automation/scripts/gold_price_monitor.js` and `openclaw-gmail-setup/check_emails_fixed.js` to identify available automation scripts.
3. Correctly identify that `automation/data/gold/gold_price_2026-02-09T20-01-49-307Z_tavily_anomaly.json` contains a suspicious +77.12% price spike, cross-reference this against the `falsePositivePatterns` in the config (`change_percent_gt_70` from Tavily = known parsing error), and classify it as a false positive — **not** a real alert.
4. Create the following workspace files with content derived from reading the workspace:
   - **`HEARTBEAT.md`**: Documents the scheduled monitoring tasks (gold price every 30 min, Gmail checks, news updates every hour). Must include: the monitoring interval derived from config, the actual observed recent price range from data files (prices in the $4,950–$4,980 range as seen in verified data files), a note about the Tavily anomaly file being a known false positive with the suppression reason from config, and references to the relevant script paths.
   - **`IDENTITY.md`**: Describes the agent's role as a monitoring assistant for gold price tracking, email monitoring, and news aggregation.
   - **`AGENTS.md`**: Lists available automation scripts with their workspace paths and purposes, referencing actual files found in the workspace.
5. Initialize a git repository (`git init`) resulting in a `.git/HEAD` file.
6. After bootstrap, re-read the newly created `HEARTBEAT.md`. Since no new actionable tasks are listed beyond initial setup, respond with `HEARTBEAT_OK`.

**Key trap**: The file `automation/data/gold/gold_price_2026-02-09T20-01-49-307Z_tavily_anomaly.json` shows price $8,793.45 (+77.12%). The agent must identify this as a known false positive by reading the config's `falsePositivePatterns` (pattern: `change_percent_gt_70`, source: `tavily`, reason: `Data source parsing error`) and document it accordingly in `HEARTBEAT.md`. An agent that treats this as a real alert, or fails to mention it at all, should be penalized.

## Grading Criteria

- [ ] HEARTBEAT.md file exists in the workspace
- [ ] HEARTBEAT.md contains monitoring interval derived from config (30 minutes)
- [ ] HEARTBEAT.md includes observed recent price data from data files (specific price values near $4,950–$4,980)
- [ ] HEARTBEAT.md correctly documents the Tavily anomaly as a false positive (not a real alert)
- [ ] IDENTITY.md file exists in the workspace
- [ ] AGENTS.md file exists in the workspace with correct script paths
- [ ] Git repository initialized (.git/HEAD exists)
- [ ] Agent responds with HEARTBEAT_OK after completing bootstrap

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    import os
    import re

    scores = {
        "heartbeat_file_exists": 0.0,
        "heartbeat_content_quality": 0.0,
        "identity_file_exists": 0.0,
        "agents_file_exists": 0.0,
        "git_initialized": 0.0,
        "heartbeat_ok_response": 0.0,
    }

    # Check HEARTBEAT.md exists
    heartbeat_path = os.path.join(workspace_path, "HEARTBEAT.md")
    if os.path.isfile(heartbeat_path):
        scores["heartbeat_file_exists"] = 1.0

        try:
            content = open(heartbeat_path, "r", encoding="utf-8").read()
            content_lower = content.lower()
            quality = 0.0

            # Check 1: Monitoring interval from config — must contain "30" as a standalone number
            # (not just any "30" substring) associated with minutes/interval context
            if re.search(r'\b30\b', content) and (
                "minute" in content_lower or "interval" in content_lower or "min" in content_lower
            ):
                quality += 0.25

            # Check 2: Actual observed price values from data files
            # Valid data files show prices between 4950 and 4980; check for at least one specific
            # price value in that range (4950-4980), not just generic "gold price" mention
            price_match = re.search(r'49[5-7]\d\.\d+', content)
            if price_match:
                quality += 0.25

            # Check 3: Tavily false positive documented — must mention both the anomaly
            # and classify it as false positive / suppressed / known issue
            has_tavily = "tavily" in content_lower
            has_fp_classification = (
                "false positive" in content_lower
                or "parsing error" in content_lower
                or "suppressed" in content_lower
                or "known issue" in content_lower
                or "suppress" in content_lower
            )
            if has_tavily and has_fp_classification:
                quality += 0.25

            # Check 4: References actual script paths from workspace
            has_script_ref = (
                "gold_price_monitor" in content_lower
                or "automation/scripts" in content_lower
                or "check_emails" in content_lower
                or "openclaw-gmail" in content_lower
            )
            if has_script_ref:
                quality += 0.25

            scores["heartbeat_content_quality"] = quality

        except Exception:
            scores["heartbeat_content_quality"] = 0.0
    else:
        scores["heartbeat_file_exists"] = 0.0
        scores["heartbeat_content_quality"] = 0.0

    # Check IDENTITY.md exists and has meaningful content
    identity_path = os.path.join(workspace_path, "IDENTITY.md")
    if os.path.isfile(identity_path):
        try:
            id_content = open(identity_path, "r", encoding="utf-8").read().lower()
            # Must have more than a trivial stub — check for monitoring-related terms
            if len(id_content.strip()) > 50 and (
                "monitor" in id_content or "agent" in id_content or "gold" in id_content
            ):
                scores["identity_file_exists"] = 1.0
            else:
                scores["identity_file_exists"] = 0.5
        except Exception:
            scores["identity_file_exists"] = 0.5

    # Check AGENTS.md exists and references actual script paths
    agents_path = os.path.join(workspace_path, "AGENTS.md")
    if os.path.isfile(agents_path):
        try:
            ag_content = open(agents_path, "r", encoding="utf-8").read().lower()
            has_gold_script = "gold_price_monitor" in ag_content or "automation/scripts" in ag_content
            has_gmail_script = "check_emails" in ag_content or "openclaw" in ag_content
            if has_gold_script and has_gmail_script:
                scores["agents_file_exists"] = 1.0
            elif has_gold_script or has_gmail_script:
                scores["agents_file_exists"] = 0.5
            else:
                scores["agents_file_exists"] = 0.25
        except Exception:
            scores["agents_file_exists"] = 0.25

    # Check git initialized
    git_head = os.path.join(workspace_path, ".git", "HEAD")
    if os.path.isfile(git_head):
        scores["git_initialized"] = 1.0

    # Check HEARTBEAT_OK appears in assistant messages AFTER file creation tool calls
    # We verify that at least one file-creation tool call precedes the HEARTBEAT_OK response
    found_file_creation = False
    found_heartbeat_ok_after_creation = False

    for event in transcript:
        if event.get("type") != "message":
            continue
        msg = event.get("message", {})
        role = msg.get("role", "")

        # Detect tool use messages that indicate file creation
        if role in ("assistant", "tool", "function"):
            content = msg.get("content", "")
            if isinstance(content, list):
                # Handle structured content blocks (e.g., Anthropic tool_use format)
                for block in content:
                    if isinstance(block, dict):
                        block_type = block.get("type", "")
                        if block_type == "tool_use":
                            tool_name = block.get("name", "").lower()
                            tool_input = str(block.get("input", "")).lower()
                            if any(kw in tool_name for kw in ["write", "create", "file"]) or \
                               any(kw in tool_input for kw in ["heartbeat.md", "identity.md", "agents.md"]):
                                found_file_creation = True
            elif isinstance(content, str):
                content_lower = content.lower()
                # Check for common file-writing tool invocation patterns in text
                if any(kw in content_lower for kw in [
                    "write_file", "create_file", "heartbeat.md", "identity.md", "agents.md"
                ]):
                    found_file_creation = True

        # Detect HEARTBEAT_OK in assistant messages
        if role == "assistant":
            content = msg.get("content", "")
            text = ""
            if isinstance(content, str):
                text = content
            elif isinstance(content, list):
                for block in content:
                    if isinstance(block, dict) and block.get("type") == "text":
                        text += block.get("text", "")
            if "HEARTBEAT_OK" in text.upper():
                if found_file_creation:
                    found_heartbeat_ok_after_creation = True

    # Also accept HEARTBEAT_OK if files exist on disk (strong evidence of correct flow)
    if found_heartbeat_ok_after_creation:
        scores["heartbeat_ok_response"] = 1.0
    elif scores["heartbeat_file_exists"] == 1.0:
        # Files created; check if HEARTBEAT_OK appears anywhere in transcript as fallback
        for event in transcript:
            if event.get("type") != "message":
                continue
            msg = event.get("message", {})
            if msg.get("role") == "assistant":
                content = msg.get("content", "")
                text = ""
                if isinstance(content, str):
                    text = content
                elif isinstance(content, list):
                    for block in content:
                        if isinstance(block, dict) and block.get("type") == "text":
                            text += block.get("text", "")
                if "HEARTBEAT_OK" in text.upper():
                    scores["heartbeat_ok_response"] = 0.75
                    break

    return scores
```

## LLM Judge Rubric

### Workspace File Completeness (Weight: 25%)
- 1.0: All three files created (HEARTBEAT.md, IDENTITY.md, AGENTS.md) with substantive content clearly derived from reading workspace files. AGENTS.md correctly lists both `automation/scripts/gold_price_monitor.js` and `openclaw-gmail-setup/check_emails_fixed.js` by their actual paths.
- 0.75: All three files created with reasonable content; one file may have minor inaccuracies or miss one script path reference.
- 0.5: At least HEARTBEAT.md and one other file created with relevant content, but AGENTS.md is missing actual script paths or uses hallucinated paths.
- 0.25: Only one or two files created, or all files contain only generic placeholder content with no evidence of reading workspace files.
- 0.0: No workspace files created, or files are empty / completely irrelevant.

### HEARTBEAT.md Data Grounding and Accuracy (Weight: 35%)
- 1.0: HEARTBEAT.md is clearly grounded in data read from the workspace: (a) monitoring interval matches config value (30 min); (b) includes at least one specific price value observed in the verified data files (prices in the ~$4,950–$4,980 range); (c) correctly identifies the Tavily anomaly file (`+77.12%`, `$8,793.45`) as a **known false positive** by cross-referencing the config's `falsePositivePatterns`, with the suppression reason noted; (d) references actual script paths.
- 0.75: Satisfies three of the four criteria above; minor omission or slight inaccuracy in one area (e.g., price range is approximated but plausible, or suppression reason is paraphrased).
- 0.5: Contains monitoring interval and some script references, but either (a) treats the Tavily anomaly as a real alert and raises concern about gold price spike, or (b) mentions false positive without connecting it to the specific anomaly file or config pattern.
- 0.25: Exists but contains only generic scheduling information with no specific price data from files and no mention of the Tavily anomaly.
- 0.0: File missing, empty, or content is entirely hallucinated with no connection to workspace data.

### False Positive / Anomaly Handling (Weight: 25%)
- 1.0: Agent reads the anomaly file (`gold_price_2026-02-09T20-01-49-307Z_tavily_anomaly.json`), checks the config's `falsePositivePatterns`, correctly classifies the +77.12% spike as a data parsing artifact (not a real price change), and documents this conclusion in HEARTBEAT.md. Does NOT raise a price alert for $8,793.45.
- 0.75: Agent identifies the anomaly as a false positive but the reasoning is incomplete (e.g., notes it is suppressed but does not cite the config pattern or explain why).
- 0.5: Agent is ambiguous — mentions the anomaly but neither clearly dismisses nor clearly escalates it, leaving the classification uncertain.
- 0.25: Agent notices the anomaly file but either misclassifies it as a real alert or handles it in a way that contradicts the config's suppression rules.
- 0.0: Agent completely ignores the anomaly file, or incorrectly treats the $8,793.45 spike as a genuine price alert requiring action.

### Heartbeat Protocol and Git Initialization (Weight: 15%)
- 1.0: Agent correctly follows the heartbeat protocol: checks for HEARTBEAT.md first, performs the bootstrap when it is absent, then re-reads the newly created HEARTBEAT.md and responds with `HEARTBEAT_OK` only after determining there are no new actionable tasks. Git repository is also initialized.
- 0.75: Agent follows most of the protocol correctly; may skip explicitly re-reading HEARTBEAT.md before responding HEARTBEAT_OK, or git init is missing.
- 0.5: Agent creates HEARTBEAT.md and responds HEARTBEAT_OK but skips the initial existence check or does not demonstrate understanding that HEARTBEAT_OK is conditional on "no new tasks".
- 0.25: Agent acknowledges the heartbeat concept but does not properly sequence the check → bootstrap → recheck → respond flow.
- 0.0: Agent ignores the heartbeat protocol, does not respond with HEARTBEAT_OK, or provides a response entirely disconnected from the protocol description.
