---
id: task_00446_polymarket_btc15m_monitor_skill
name: Polymarket BTC 15min Monitor Skill Creation
category: Workflow and Agent Orchestration
subcategory: Script and Terminal Automation
difficulty: medium
grading_type: hybrid
grading_weights: {automated: 0.4, llm_judge: 0.6}
timeout_seconds: 600
input_modality: text-only
external_dependency: none
skill_creation: true
workspace_files:
  - source: assets/task_00446_polymarket_btc15m_monitor_skill/.openclaw/data/pm_btc15m_last_reported.txt
    dest: .openclaw/data/pm_btc15m_last_reported.txt
    content: "round-2026-02-10-1545-JST"
  - source: assets/task_00446_polymarket_btc15m_monitor_skill/data/pm_btc15m_cached_page.html
    dest: data/pm_btc15m_cached_page.html
    content: |
      (see assets file data/pm_btc15m_cached_page.html)
  - source: assets/task_00446_polymarket_btc15m_monitor_skill/data/pm_btc15m_last_reported.txt
    dest: data/pm_btc15m_last_reported.txt
    content: "round-2026-02-10-1545-JST"
---

## Prompt

Hey, I need a reusable OpenClaw skill for monitoring Polymarket's BTC 15-minute Up/Down prediction market. Think of it like a cron-triggered watcher — similar to how "hive-mind" syncs data across agents or "goal-tracker" logs progress over time, but for crypto market monitoring.

Create the skill at **`skills/polymarket-btc15m-monitor/SKILL.md`** under the workspace root (OpenClaw: `~/.openclaw/workspace/skills/polymarket-btc15m-monitor/SKILL.md`). Create the directory if needed. The skill should cover:
- Fetching the Polymarket BTC 15min page (https://polymarket.com/crypto/15M) via web_fetch or browser
- Extracting the latest resolved round info (round ID/time window, status, outcome) — note the page structure uses timestamps and CSS classes, so you'll need to derive round identifiers from the timing data rather than reading them off a simple attribute
- Comparing against the last reported round stored in `.openclaw/data/pm_btc15m_last_reported.txt` (format: `round-YYYY-MM-DD-HHMM-JST`)
- Outputting a formatted result if there's a new resolved round, using the round ID convention `round-YYYY-MM-DD-HHMM-JST` where HHMM is the **start time** of the round in JST
- Using Asia/Tokyo timezone for any timestamps

Then actually run the skill — try to fetch the current BTC 15min market data, check for resolved rounds, compare with the last reported file, and give me the appropriate output. There's a cached HTML file at `data/pm_btc15m_cached_page.html` you can reference if the live page isn't accessible.

Return your summary as plain text. If the market data is unavailable or cannot be parsed, follow whatever error handling your skill defines.

## Expected Behavior

The agent should:

1. **Create `skills/polymarket-btc15m-monitor/SKILL.md`** with proper YAML frontmatter (including `name` and `description` fields) and markdown instruction sections describing the BTC 15min monitoring workflow. This should be inspired by existing skills like hive-mind, goal-tracker, and personal-goals — structured as a reusable capability definition. The skill must define its own output format and error handling protocol.

2. **Read the cached HTML or attempt to fetch the live Polymarket page** at https://polymarket.com/crypto/15M. The agent should try web_fetch, browser, or API endpoints to get market data. If the live page is inaccessible, the agent should fall back to reading `data/pm_btc15m_cached_page.html`.

3. **Read the last reported round** from `.openclaw/data/pm_btc15m_last_reported.txt`. This file contains `round-2026-02-10-1545-JST`.

4. **Parse the HTML and derive round identifiers** from the time data in the page. The HTML uses `<time>` elements with `datetime` attributes (UTC) and JST display labels. The agent must:
   - Identify rounds with `status-resolved` CSS class
   - Derive the round ID using the format `round-YYYY-MM-DD-HHMM-JST` based on the JST start time of each round
   - Determine the correct **latest** resolved round — this requires comparing rounds by their start times
   - The latest resolved round is the 16:00–16:15 JST window (UTC `datetime="2026-02-10T07:00:00Z"`), outcome: UP, open $97,389.20, close $97,432.50, +$43.30. Its round ID is therefore `round-2026-02-10-1600-JST`.

5. **Produce an appropriate output** based on what it finds:
   - Since the last reported round is `round-2026-02-10-1545-JST` and the latest resolved round is `round-2026-02-10-1600-JST`, there IS a new round to report.
   - The agent should output a formatted result containing the new round's details (round ID, time window, outcome UP, price change).
   - The agent must also **write** `round-2026-02-10-1600-JST` to `.openclaw/data/pm_btc15m_last_reported.txt` (overwriting the previous value).
   - If the agent cannot parse the HTML at all or encounters an unexpected error, it should output an appropriate error message as defined in its SKILL.md.

6. The agent should demonstrate reasonable error handling — using protocol-compliant error/no-update outputs when appropriate, and not crashing on unexpected data.

## Grading Criteria

- [ ] `skills/polymarket-btc15m-monitor/SKILL.md` exists at the correct path with proper YAML frontmatter (name and description fields)
- [ ] That SKILL.md contains meaningful instruction sections for the monitoring workflow
- [ ] Agent attempted to fetch Polymarket data (via web_fetch, browser, or API) or read the cached HTML file
- [ ] Agent read or referenced the last reported file at .openclaw/data/pm_btc15m_last_reported.txt
- [ ] Agent correctly identified the new resolved round (round-2026-02-10-1600-JST) by deriving its ID from the HTML time data
- [ ] Agent output a formatted result containing the new round's details (round ID, outcome, price info)
- [ ] Agent updated `.openclaw/data/pm_btc15m_last_reported.txt` to contain `round-2026-02-10-1600-JST`

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    import os
    import re

    scores = {
        "skill_md_exists": 0.0,
        "skill_md_structure": 0.0,
        "new_round_detected": 0.0,
        "protocol_compliance": 0.0,
        "fetch_attempt_in_transcript": 0.0,
        "last_reported_file_referenced": 0.0,
        "last_reported_file_updated": 0.0,
    }

    # 1. Check SKILL.md at canonical skills path only (no fallback to workspace root)
    skill_path = os.path.join(workspace_path, "skills", "polymarket-btc15m-monitor", "SKILL.md")
    if not os.path.isfile(skill_path):
        # Partial credit: agent created SKILL.md but in wrong location
        fallback_path = os.path.join(workspace_path, "SKILL.md")
        if os.path.isfile(fallback_path):
            scores["skill_md_exists"] = 0.5
            skill_path = fallback_path
        else:
            return scores
    else:
        scores["skill_md_exists"] = 1.0

    # 2. Check SKILL.md structure: YAML frontmatter with name and description
    try:
        with open(skill_path, "r", encoding="utf-8") as f:
            content = f.read()

        has_frontmatter = content.strip().startswith("---")
        has_name = bool(re.search(r"(?i)^name\s*:", content, re.MULTILINE))
        has_description = bool(re.search(r"(?i)^description\s*:", content, re.MULTILINE))
        has_sections = bool(re.search(r"^#{1,3}\s+\w+", content, re.MULTILINE))

        structure_score = 0.0
        if has_frontmatter:
            structure_score += 0.25
        if has_name:
            structure_score += 0.25
        if has_description:
            structure_score += 0.25
        if has_sections:
            structure_score += 0.25
        scores["skill_md_structure"] = structure_score
    except Exception:
        scores["skill_md_structure"] = 0.0

    # 3. Check last_reported file was actually updated to the new round ID
    last_reported_path = os.path.join(workspace_path, ".openclaw", "data", "pm_btc15m_last_reported.txt")
    try:
        if os.path.isfile(last_reported_path):
            with open(last_reported_path, "r", encoding="utf-8") as f:
                file_content = f.read().strip()
            if file_content == "round-2026-02-10-1600-JST":
                scores["last_reported_file_updated"] = 1.0
            else:
                scores["last_reported_file_updated"] = 0.0
    except Exception:
        scores["last_reported_file_updated"] = 0.0

    # 4-6. Check transcript for fetch attempts, new round detection, and file reference
    found_new_round = False
    found_fetch_attempt = False
    found_file_reference = False
    found_protocol_output = False

    for event in transcript:
        if event.get("type") != "message":
            continue
        msg = event.get("message", {})

        # Check assistant messages for output
        if msg.get("role") == "assistant":
            text = msg.get("content", "") or ""
            if isinstance(text, list):
                text = " ".join(str(item) for item in text)

            # Check if agent correctly identified the new round (round-2026-02-10-1600-JST)
            # Must match the specific new round ID — not just any round reference
            if re.search(r"round[-_]2026[-_]02[-_]10[-_]1600", text, re.IGNORECASE) or \
               re.search(r"16:00[^-]*16:15", text) or \
               re.search(r"1600.*?JST.*?(?:UP|RESOLVED|new)", text, re.IGNORECASE):
                found_new_round = True

            # Check for protocol-compliant output (DATA-ERROR or NO-UPDATE are valid
            # error-handling outputs but do NOT count as successfully detecting a new round)
            if re.search(r"DATA[_-]ERROR", text, re.IGNORECASE) or \
               re.search(r"NO[_-]UPDATE", text, re.IGNORECASE):
                found_protocol_output = True

            if re.search(r"pm_btc15m_last_reported", text, re.IGNORECASE) or \
               re.search(r"last.reported", text, re.IGNORECASE):
                found_file_reference = True

        # Check tool calls for fetch attempts and file references
        if msg.get("role") == "assistant":
            tool_calls = msg.get("tool_calls", [])
            if tool_calls:
                for tc in tool_calls:
                    func = tc.get("function", {})
                    func_name = func.get("name", "")
                    func_args = func.get("arguments", "")
                    if func_name in ("web_fetch", "browser", "web_search"):
                        found_fetch_attempt = True
                    if "polymarket" in str(func_args).lower() or \
                       "crypto" in str(func_args).lower():
                        found_fetch_attempt = True
                    if "pm_btc15m_cached_page" in str(func_args).lower() or \
                       "cached_page" in str(func_args).lower():
                        found_fetch_attempt = True
                    if "pm_btc15m" in str(func_args).lower() or \
                       "last_reported" in str(func_args).lower():
                        found_file_reference = True
                    if func_name == "read" and (
                        "pm_btc15m" in str(func_args).lower() or
                        "cached" in str(func_args).lower()
                    ):
                        found_fetch_attempt = True

        # Check tool role messages for fetch evidence
        if msg.get("role") == "tool":
            tool_content = msg.get("content", "") or ""
            # Require more specific evidence than just "btc" appearing in tool output
            if "polymarket" in tool_content.lower() or \
               "pm_btc15m_cached_page" in tool_content.lower() or \
               "round-2026" in tool_content.lower():
                found_fetch_attempt = True

    # new_round_detected: only true if the correct new round was identified
    scores["new_round_detected"] = 1.0 if found_new_round else 0.0

    # protocol_compliance: partial credit for using a valid error protocol
    # (DATA-ERROR/NO-UPDATE) when new round was not detected
    if found_protocol_output and not found_new_round:
        scores["protocol_compliance"] = 0.3
    elif found_new_round:
        scores["protocol_compliance"] = 1.0
    else:
        scores["protocol_compliance"] = 0.0

    scores["fetch_attempt_in_transcript"] = 1.0 if found_fetch_attempt else 0.0
    scores["last_reported_file_referenced"] = 1.0 if found_file_reference else 0.0

    return scores
```

## LLM Judge Rubric

### Skill File Quality (Weight: 30%)
Evaluates whether the agent created a well-structured SKILL.md that encapsulates the BTC 15-minute market monitoring capability as a reusable skill definition. This dimension focuses solely on the quality and completeness of the skill definition file itself.
- 1.0: SKILL.md is at the correct path (`skills/polymarket-btc15m-monitor/SKILL.md`), has proper YAML frontmatter with name/description, and contains clear markdown sections covering: fetching strategy, HTML parsing approach (including how to derive round IDs from time data), comparison logic, output format definition (including error/no-update cases), and timezone requirements. Inspired by reference skills (hive-mind, goal-tracker style).
- 0.75: SKILL.md exists at the correct path with frontmatter and reasonable sections but is missing one or two of the workflow details listed above (e.g., no explicit output format definition, or timezone handling is absent).
- 0.5: SKILL.md exists (possibly at wrong path) but is minimal — missing frontmatter fields or has only a brief description without structured workflow sections.
- 0.25: SKILL.md exists but is essentially a stub with little useful content, or was placed at an incorrect path with minimal content.
- 0.0: No SKILL.md created, or file is empty/unrelated to the task.

### Data Fetching and HTML Parsing (Weight: 25%)
Evaluates the agent's effort to actually retrieve market data AND correctly parse the HTML to derive round information. This dimension focuses on the investigative actions taken, not the output produced.
- 1.0: Agent tried multiple approaches to fetch the data (or used the cached HTML) AND demonstrated correct parsing of the HTML structure — specifically: identifying resolved rounds via CSS class, extracting start times from `<time datetime="...">` elements, and correctly deriving `round-YYYY-MM-DD-HHMM-JST` identifiers from UTC timestamps converted to JST.
- 0.75: Agent fetched or read the cached HTML and extracted most of the relevant data, but had minor issues (e.g., correctly found the round but didn't explicitly show the UTC→JST conversion step, or used a slightly different round ID format).
- 0.5: Agent made a single fetch/read attempt and extracted some round information but did not correctly identify all resolved rounds or had errors in time conversion.
- 0.25: Agent attempted to fetch or read data but extracted very little useful information, or only partially parsed the HTML.
- 0.0: No evidence of any data fetching or HTML reading attempt.

### Output Format and New Round Identification (Weight: 25%)
Evaluates whether the agent correctly identified the new resolved round and produced a well-structured output. This dimension focuses exclusively on the **format and correctness of the final output**, not on whether files were updated.
- 1.0: Agent correctly identified `round-2026-02-10-1600-JST` as the new round (vs. last reported `round-2026-02-10-1545-JST`), and produced a clearly formatted output containing: round ID, time window (16:00–16:15 JST), outcome (UP), open/close prices, and price change. Output format follows the protocol defined in the agent's own SKILL.md.
- 0.75: Agent correctly identified the new round and produced a formatted output with most required fields, but omitted one detail (e.g., missing price change, or time window not explicitly stated).
- 0.5: Agent produced some output about market rounds but did not clearly distinguish the new round from the last reported one, or produced a valid `DATA-ERROR`/`NO-UPDATE` output when data was actually available in the cached HTML.
- 0.25: Agent produced an output but it was vague, missing most required fields, or the round identification was incorrect.
- 0.0: No output produced, or agent hallucinated round results inconsistent with the cached HTML data.

### Workspace Grounding and State Update (Weight: 20%)
Evaluates whether the agent's actions are grounded in actual workspace files AND whether it correctly updated the persistent state file. This dimension focuses on file I/O accuracy.
- 1.0: Agent demonstrably read `.openclaw/data/pm_btc15m_last_reported.txt` (confirming `round-2026-02-10-1545-JST`) AND wrote `round-2026-02-10-1600-JST` back to that file after detecting the new round. All referenced data values (prices, timestamps) match the actual cached HTML content.
- 0.75: Agent read the last_reported file and referenced correct data values from the cached HTML, but either did not update the last_reported file or updated it with a minor formatting discrepancy (e.g., trailing newline difference, slightly wrong ID format).
- 0.5: Agent referenced the last_reported file but did not read it programmatically (e.g., assumed its content), or updated the file but with an incorrect round ID.
- 0.25: Agent made minimal reference to workspace files; outputs reference some real data values but key file I/O steps are missing or unverified.
- 0.0: Agent ignored required input files, hallucinated market results, or produced outputs completely disconnected from the actual workspace files and cached HTML data.

