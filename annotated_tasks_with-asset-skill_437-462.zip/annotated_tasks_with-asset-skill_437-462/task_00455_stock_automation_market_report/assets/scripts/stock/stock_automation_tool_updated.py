#!/usr/bin/env python3
"""
Stock Fund Flow Data Download Tool (Updated)
Downloads individual stock fund flow data from East Money API,
formats and saves as CSV with proper formatting.

Schedule: Weekdays at 19:00 Beijing Time
Output: CSV file with formatted stock data
"""

import requests
import pandas as pd
import os
import sys
import json
import time
import sqlite3
from datetime import datetime, timezone, timedelta
from decimal import Decimal, ROUND_HALF_UP

# Configuration
DOWNLOAD_DIR = os.environ.get("STOCK_DATA_DIR", "/Volumes/HD/openclaw/StockData")
CSV_DIR = os.path.join(DOWNLOAD_DIR, "csv")
DB_PATH = os.path.join(DOWNLOAD_DIR, "database", "stock_flow_data.db")
TELEGRAM_BOT_TOKEN = os.environ.get("TELEGRAM_BOT_TOKEN", "")
TELEGRAM_CHAT_ID = os.environ.get("TELEGRAM_CHAT_ID", "")
MIN_RECORD_COUNT = 5000

# Beijing timezone
BJT = timezone(timedelta(hours=8))

# East Money API endpoints for fund flow data
BASE_URL = "https://push2.eastmoney.com/api/qt/clist/get"


def get_beijing_date():
    """Get current date in Beijing timezone."""
    return datetime.now(BJT).strftime("%Y-%m-%d")


def format_stock_code(code_str):
    """Ensure stock code is 6-digit string with leading zeros."""
    code = str(code_str).strip()
    # Remove market prefix if present (e.g., "SZ300480" -> "300480")
    for prefix in ["SZ", "SH", "BJ", "sz", "sh", "bj"]:
        if code.startswith(prefix):
            code = code[len(prefix):]
    return code.zfill(6)


def format_percentage(value):
    """Format as percentage string with 2 decimal places, handling precision."""
    if pd.isna(value) or value is None or value == "":
        return "0.00%"
    try:
        # Use Decimal for precision
        d = Decimal(str(value)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
        return f"{d}%"
    except Exception:
        return "0.00%"


def format_currency(value):
    """Format large numbers with comma separators."""
    if pd.isna(value) or value is None or value == "":
        return "0"
    try:
        # Use Decimal to avoid floating point artifacts
        d = Decimal(str(value)).quantize(Decimal("1"), rounding=ROUND_HALF_UP)
        return f"{int(d):,}"
    except Exception:
        return "0"


def format_price(value):
    """Format price with 2 decimal places."""
    if pd.isna(value) or value is None or value == "":
        return "0.00"
    try:
        d = Decimal(str(value)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
        return str(d)
    except Exception:
        return "0.00"


def fetch_fund_flow_data(page_size=5500):
    """
    Fetch individual stock fund flow data from East Money API.
    Returns raw data as list of dicts.
    """
    params = {
        "pn": 1,
        "pz": page_size,
        "po": 1,
        "np": 1,
        "ut": "b2884a393a59ad64002292a3e90d46a5",
        "fltt": 2,
        "invt": 2,
        "fid": "f62",
        "fs": "m:0+t:6,m:0+t:80,m:1+t:2,m:1+t:23,m:0+t:81+s:2048",
        "fields": "f1,f2,f3,f12,f14,f62,f66,f69,f72,f75,f78,f184,f204,f205,f206",
    }

    headers = {
        "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
                       "AppleWebKit/537.36 (KHTML, like Gecko) "
                       "Chrome/120.0.0.0 Safari/537.36",
        "Referer": "https://data.eastmoney.com/",
    }

    print(f"[{datetime.now(BJT):%Y-%m-%d %H:%M:%S}] Fetching fund flow data...")

    try:
        response = requests.get(BASE_URL, params=params, headers=headers, timeout=60)
        response.raise_for_status()
        data = response.json()

        if "data" not in data or "diff" not in data["data"]:
            raise ValueError("Unexpected API response structure")

        records = data["data"]["diff"]
        total = data["data"]["total"]
        print(f"  API returned {len(records)} records (total available: {total})")
        return records

    except requests.RequestException as e:
        print(f"  ERROR: Network request failed: {e}")
        raise
    except (json.JSONDecodeError, ValueError) as e:
        print(f"  ERROR: Data parsing failed: {e}")
        raise


def process_and_format(raw_records, download_date):
    """
    Process raw API records into formatted DataFrame.
    Handles formatting as strings to avoid floating point issues.
    """
    rows = []
    for idx, record in enumerate(raw_records, 1):
        row = {
            "download_date": download_date,
            "serial_no": idx,
            "stock_code": format_stock_code(record.get("f12", "")),
            "stock_name": str(record.get("f14", "")).strip(),
            "latest_price": format_price(record.get("f2")),
            "price_change_pct": format_percentage(record.get("f3")),
            "turnover_rate": format_percentage(record.get("f184")),
            "fund_inflow": format_currency(record.get("f62")),
            "fund_outflow": format_currency(record.get("f66")),
            "net_flow": format_currency(record.get("f69")),
            "turnover_amount": format_currency(record.get("f72")),
        }
        rows.append(row)

    df = pd.DataFrame(rows)

    # Column names in Chinese for compatibility
    df.columns = [
        "下载日期", "序号", "股票代码", "股票简称", "最新价",
        "涨跌幅", "换手率", "流入资金", "流出资金", "净额", "成交额"
    ]

    return df


def validate_data(df):
    """Validate downloaded data meets quality requirements."""
    record_count = len(df)
    print(f"  Record count: {record_count}")

    if record_count < MIN_RECORD_COUNT:
        raise ValueError(
            f"Data validation failed: only {record_count} records "
            f"(minimum: {MIN_RECORD_COUNT})"
        )

    # Check for empty stock codes
    empty_codes = df[df["股票代码"] == "000000"].shape[0]
    if empty_codes > 0:
        print(f"  WARNING: {empty_codes} records with empty stock codes")

    # Check for missing prices
    zero_prices = df[df["最新价"] == "0.00"].shape[0]
    if zero_prices > 100:
        print(f"  WARNING: {zero_prices} records with zero price")

    print(f"  Data validation PASSED ({record_count} >= {MIN_RECORD_COUNT})")
    return True


def save_csv(df, download_date):
    """Save formatted data to CSV file."""
    os.makedirs(CSV_DIR, exist_ok=True)
    filename = f"stock_fund_flow_{download_date}.csv"
    filepath = os.path.join(CSV_DIR, filename)

    df.to_csv(filepath, index=False, encoding="utf-8-sig")
    file_size = os.path.getsize(filepath)
    print(f"  Saved: {filepath} ({file_size:,} bytes, {len(df)} records)")
    return filepath


def send_telegram_notification(message):
    """Send notification via Telegram bot."""
    if not TELEGRAM_BOT_TOKEN or not TELEGRAM_CHAT_ID:
        print("  Telegram not configured, skipping notification")
        return

    url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage"
    payload = {
        "chat_id": TELEGRAM_CHAT_ID,
        "text": message,
        "parse_mode": "Markdown",
    }

    try:
        resp = requests.post(url, json=payload, timeout=10)
        if resp.status_code == 200:
            print("  Telegram notification sent successfully")
        else:
            print(f"  Telegram notification failed: {resp.status_code}")
    except Exception as e:
        print(f"  Telegram notification error: {e}")


def main():
    """Main download workflow."""
    download_date = get_beijing_date()
    print(f"\n{'='*60}")
    print(f"Stock Fund Flow Download - {download_date}")
    print(f"{'='*60}")

    try:
        # Step 1: Fetch data
        raw_data = fetch_fund_flow_data()

        # Step 2: Process and format
        df = process_and_format(raw_data, download_date)

        # Step 3: Validate
        validate_data(df)

        # Step 4: Save CSV
        csv_path = save_csv(df, download_date)

        # Step 5: Notify success
        msg = (
            f"✅ *Stock Data Downloaded*\n"
            f"Date: {download_date}\n"
            f"Records: {len(df):,}\n"
            f"File: `{os.path.basename(csv_path)}`"
        )
        send_telegram_notification(msg)

        print(f"\n✅ Download completed successfully!")
        return 0

    except Exception as e:
        error_msg = f"❌ Download FAILED: {e}"
        print(f"\n{error_msg}")
        send_telegram_notification(
            f"❌ *Stock Download Failed*\n"
            f"Date: {download_date}\n"
            f"Error: `{e}`"
        )
        return 1


if __name__ == "__main__":
    sys.exit(main())
