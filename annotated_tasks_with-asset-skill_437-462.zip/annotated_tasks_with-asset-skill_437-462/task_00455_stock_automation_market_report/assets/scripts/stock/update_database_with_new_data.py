#!/usr/bin/env python3
"""
Database Update Script for Stock Fund Flow Data
Reads the latest CSV file and inserts/updates records in SQLite database.

Schedule: Weekdays at 19:15 Beijing Time (after download completes)
"""

import sqlite3
import pandas as pd
import os
import sys
import glob
from datetime import datetime, timezone, timedelta

# Configuration
DOWNLOAD_DIR = os.environ.get("STOCK_DATA_DIR", "/Volumes/HD/openclaw/StockData")
CSV_DIR = os.path.join(DOWNLOAD_DIR, "csv")
DB_PATH = os.path.join(DOWNLOAD_DIR, "database", "stock_flow_data.db")
TELEGRAM_BOT_TOKEN = os.environ.get("TELEGRAM_BOT_TOKEN", "")
TELEGRAM_CHAT_ID = os.environ.get("TELEGRAM_CHAT_ID", "")

BJT = timezone(timedelta(hours=8))

# Database schema
CREATE_TABLE_SQL = """
CREATE TABLE IF NOT EXISTS stock_fund_flow (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    download_date TEXT NOT NULL,
    serial_no INTEGER,
    stock_code TEXT NOT NULL,
    stock_name TEXT,
    latest_price TEXT,
    price_change_pct TEXT,
    turnover_rate TEXT,
    fund_inflow TEXT,
    fund_outflow TEXT,
    net_flow TEXT,
    turnover_amount TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(download_date, stock_code)
);
"""

CREATE_INDEX_SQL = [
    "CREATE INDEX IF NOT EXISTS idx_download_date ON stock_fund_flow(download_date);",
    "CREATE INDEX IF NOT EXISTS idx_stock_code ON stock_fund_flow(stock_code);",
    "CREATE INDEX IF NOT EXISTS idx_date_code ON stock_fund_flow(download_date, stock_code);",
]


def init_database():
    """Initialize database with schema if not exists."""
    db_dir = os.path.dirname(DB_PATH)
    os.makedirs(db_dir, exist_ok=True)

    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    cursor.execute(CREATE_TABLE_SQL)
    for idx_sql in CREATE_INDEX_SQL:
        cursor.execute(idx_sql)

    conn.commit()
    return conn


def find_latest_csv(target_date=None):
    """Find the most recent CSV file, optionally for a specific date."""
    if target_date:
        pattern = os.path.join(CSV_DIR, f"stock_fund_flow_{target_date}.csv")
        files = glob.glob(pattern)
        # Also check Chinese-named files
        pattern_cn = os.path.join(CSV_DIR, f"*{target_date}*.csv")
        files.extend(glob.glob(pattern_cn))
    else:
        pattern = os.path.join(CSV_DIR, "stock_fund_flow_*.csv")
        files = glob.glob(pattern)

    if not files:
        return None

    # Return the most recently modified file
    return max(files, key=os.path.getmtime)


def load_csv_data(csv_path):
    """Load and validate CSV data."""
    df = pd.read_csv(csv_path, dtype=str, encoding="utf-8-sig")

    expected_cols = ["下载日期", "序号", "股票代码", "股票简称", "最新价",
                     "涨跌幅", "换手率", "流入资金", "流出资金", "净额", "成交额"]

    # Verify columns
    missing = set(expected_cols) - set(df.columns)
    if missing:
        raise ValueError(f"Missing columns in CSV: {missing}")

    print(f"  Loaded {len(df)} records from {os.path.basename(csv_path)}")
    return df


def insert_data(conn, df):
    """Insert data into database, handling duplicates with REPLACE."""
    cursor = conn.cursor()

    insert_sql = """
    INSERT OR REPLACE INTO stock_fund_flow
    (download_date, serial_no, stock_code, stock_name, latest_price,
     price_change_pct, turnover_rate, fund_inflow, fund_outflow,
     net_flow, turnover_amount)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """

    records = []
    for _, row in df.iterrows():
        records.append((
            row["下载日期"],
            int(row["序号"]) if row["序号"] else None,
            row["股票代码"],
            row["股票简称"],
            row["最新价"],
            row["涨跌幅"],
            row["换手率"],
            row["流入资金"],
            row["流出资金"],
            row["净额"],
            row["成交额"],
        ))

    cursor.executemany(insert_sql, records)
    conn.commit()

    inserted = cursor.rowcount
    print(f"  Inserted/updated {len(records)} records in database")
    return len(records)


def get_database_stats(conn):
    """Get summary statistics from database."""
    cursor = conn.cursor()

    cursor.execute("SELECT COUNT(*) FROM stock_fund_flow")
    total = cursor.fetchone()[0]

    cursor.execute("SELECT COUNT(DISTINCT download_date) FROM stock_fund_flow")
    dates = cursor.fetchone()[0]

    cursor.execute("SELECT MIN(download_date), MAX(download_date) FROM stock_fund_flow")
    date_range = cursor.fetchone()

    return {
        "total_records": total,
        "trading_days": dates,
        "first_date": date_range[0],
        "last_date": date_range[1],
    }


def send_notification(message):
    """Send Telegram notification."""
    if not TELEGRAM_BOT_TOKEN or not TELEGRAM_CHAT_ID:
        print("  Telegram not configured, skipping notification")
        return
    import requests
    url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage"
    try:
        requests.post(url, json={
            "chat_id": TELEGRAM_CHAT_ID,
            "text": message,
            "parse_mode": "Markdown",
        }, timeout=10)
    except Exception as e:
        print(f"  Notification error: {e}")


def main():
    """Main database update workflow."""
    today = datetime.now(BJT).strftime("%Y-%m-%d")
    print(f"\n{'='*60}")
    print(f"Database Update - {today}")
    print(f"{'='*60}")

    try:
        # Step 1: Initialize database
        conn = init_database()
        print("  Database initialized")

        # Step 2: Find latest CSV
        csv_path = find_latest_csv(today)
        if not csv_path:
            raise FileNotFoundError(f"No CSV file found for {today}")

        # Step 3: Load CSV
        df = load_csv_data(csv_path)

        # Step 4: Insert data
        count = insert_data(conn, df)

        # Step 5: Get stats
        stats = get_database_stats(conn)
        conn.close()

        # Step 6: Report
        msg = (
            f"✅ *Database Updated*\n"
            f"Date: {today}\n"
            f"Records added: {count:,}\n"
            f"Total in DB: {stats['total_records']:,}\n"
            f"Trading days: {stats['trading_days']}\n"
            f"Date range: {stats['first_date']} ~ {stats['last_date']}"
        )
        print(f"\n{msg}")
        send_notification(msg)

        return 0

    except Exception as e:
        error_msg = f"❌ Database update FAILED: {e}"
        print(f"\n{error_msg}")
        send_notification(f"❌ *DB Update Failed*\nDate: {today}\nError: `{e}`")
        return 1


if __name__ == "__main__":
    sys.exit(main())
