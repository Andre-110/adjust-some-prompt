---
id: task_00455_stock_automation_market_report
name: Stock Market Automation Report Generation
category: Workflow and Agent Orchestration
subcategory: Workflow and Task Scheduling
difficulty: medium
grading_type: hybrid
grading_weights: {automated: 0.4, llm_judge: 0.6}
timeout_seconds: 600
input_modality: text-only
external_dependency: none
workspace_files:
  - source: assets/task_00455_stock_automation_market_report/stock_data/stock_fund_flow_2026-02-09.csv
    dest: stock_data/stock_fund_flow_2026-02-09.csv
    content: |
      download_date,index,stock_code,stock_name,latest_price,price_change_pct,turnover_rate,inflow,outflow,net_flow,turnover_amount
      2026-02-09,1,300480,GuangLian Aviation,45.32,20.02%,18.55%,"1,463,000,000","892,000,000","571,000,000","2,355,000,000"
      2026-02-09,2,600519,Kweichow Moutai,1688.00,2.35%,0.82%,"3,200,000,000","2,800,000,000","400,000,000","6,000,000,000"
      2026-02-09,3,000001,Ping An Bank,12.45,-1.20%,1.05%,"450,000,000","620,000,000","-170,000,000","1,070,000,000"
      2026-02-09,4,002594,BYD Company,268.50,3.80%,1.92%,"2,100,000,000","1,650,000,000","450,000,000","3,750,000,000"
      2026-02-09,5,601318,Ping An Insurance,48.90,1.15%,0.65%,"890,000,000","920,000,000","-30,000,000","1,810,000,000"
      2026-02-09,6,000858,Wuliangye,152.30,0.85%,0.72%,"680,000,000","710,000,000","-30,000,000","1,390,000,000"
      2026-02-09,7,002475,Luxshare Precision,32.10,5.20%,3.15%,"1,800,000,000","1,200,000,000","600,000,000","3,000,000,000"
      2026-02-09,8,600036,China Merchants Bank,35.60,-0.56%,0.48%,"520,000,000","580,000,000","-60,000,000","1,100,000,000"
      2026-02-09,9,300750,CATL,218.40,4.10%,1.85%,"2,500,000,000","1,900,000,000","600,000,000","4,400,000,000"
      2026-02-09,10,601899,Zijin Mining,14.25,2.90%,2.10%,"1,100,000,000","850,000,000","250,000,000","1,950,000,000"
      2026-02-09,11,000333,Midea Group,68.20,-0.30%,0.55%,"420,000,000","460,000,000","-40,000,000","880,000,000"
      2026-02-09,12,002714,Muyuan Foods,42.80,1.60%,1.20%,"380,000,000","320,000,000","60,000,000","700,000,000"
      2026-02-09,13,601012,LONGi Green,28.90,-2.10%,2.30%,"750,000,000","980,000,000","-230,000,000","1,730,000,000"
      2026-02-09,14,688981,SMIC,52.60,6.50%,4.20%,"2,800,000,000","2,100,000,000","700,000,000","4,900,000,000"
      2026-02-09,15,603259,WuXi AppTec,78.40,-3.20%,1.80%,"620,000,000","890,000,000","-270,000,000","1,510,000,000"
  - source: assets/task_00455_stock_automation_market_report/config/report_settings.json
    dest: config/report_settings.json
    content: |
      {
        "data_directory": "stock_data",
        "report_output_directory": "reports",
        "date": "2026-02-09",
        "currency_format": "billion_yuan",
        "min_turnover_threshold_billion": 1.0,
        "report_sections": [
          "market_overview",
          "top_net_inflow",
          "top_net_outflow",
          "high_fund_strength",
          "risk_assessment"
        ]
      }
  - source: assets/task_00455_stock_automation_market_report/scripts/stock/stock_automation_tool_updated.py
    dest: scripts/stock/stock_automation_tool_updated.py
    role: noise
    content: "(see assets directory)"
  - source: assets/task_00455_stock_automation_market_report/scripts/stock/update_database_with_new_data.py
    dest: scripts/stock/update_database_with_new_data.py
    role: noise
    content: "(see assets directory)"
skill_creation: false
---

## Prompt

Hey, I have a stock fund flow CSV file at `stock_data/stock_fund_flow_2026-02-09.csv` and a config file at `config/report_settings.json`. Can you generate a comprehensive daily stock market analysis report for 2026-02-09?

The report should be saved to `reports/daily_report_2026-02-09.md` and include exactly the sections listed under `report_sections` in the config file, in that order:

1. **Market Overview** — total market inflow, outflow, net flow, and how many stocks are advancing vs declining
2. **Top Net Inflow Stocks** — top 5 stocks by net fund inflow, showing stock code, name, net flow in billions, price change, and turnover rate
3. **Top Net Outflow Stocks** — top 5 stocks by net fund outflow (biggest outflows)
4. **High Fund Strength Stocks** — stocks where net flow / turnover amount ratio is high AND turnover amount exceeds the threshold specified in the config (`min_turnover_threshold_billion`). Only include stocks whose turnover_amount is strictly above that threshold.
5. **Risk Assessment** — flag any stocks that are rising in price but have net outflows (potential divergence risk)

Each section must appear as a Markdown level-2 header (e.g., `## Market Overview`). Format all monetary values in billions (e.g., "5.71 billion") and keep percentages as-is from the CSV. Make the report readable with clear section headers and aligned data.

Note: For the Top Net Inflow ranking, when two stocks have the same net_flow value, sort them by their `index` column in ascending order (lower index ranks higher).

Also create a summary JSON file at `reports/summary_2026-02-09.json` with keys: `date`, `total_inflow_billion`, `total_outflow_billion`, `total_net_flow_billion`, `advancing_count`, `declining_count`, `top_inflow_stock`, `top_outflow_stock`, and `risk_divergence_count`. All numeric fields (`total_inflow_billion`, `total_outflow_billion`, `total_net_flow_billion`) must be JSON numbers (not strings), rounded to 3 decimal places.

## Expected Behavior

The agent should:

1. Read the CSV file from `stock_data/stock_fund_flow_2026-02-09.csv` and parse the data correctly, handling comma-separated number strings (e.g., `"1,463,000,000"`) and percentage formats (e.g., `20.02%`).
2. Read the config from `config/report_settings.json` to determine: output directory (`report_output_directory`), date, currency format, turnover threshold (`min_turnover_threshold_billion`), and the ordered list of sections to include (`report_sections`). The report sections must appear in the same order as listed in the config, each as a `##`-level Markdown header.
3. Calculate market-wide aggregates: total inflow, total outflow, net flow, count of advancing (positive price change) vs declining stocks.
   - Total inflow: 19,773,000,000 (≈19.773 billion)
   - Total outflow: 16,572,000,000 (≈16.572 billion)
   - Total net flow: 3,201,000,000 (≈3.201 billion)
   - Advancing: 10 stocks, Declining: 5 stocks
4. Identify top 5 net inflow stocks by sorting on the net_flow column (descending). When net_flow values are tied, sort by `index` ascending (lower index = higher rank):
   - 688981 SMIC: 700M (index 14)
   - 002475 Luxshare Precision: 600M (index 7) — ranks above CATL due to lower index
   - 300750 CATL: 600M (index 9)
   - 300480 GuangLian Aviation: 571M (index 1)
   - 002594 BYD Company: 450M (index 4)
5. Identify top 5 net outflow stocks (most negative net_flow first):
   - 603259 WuXi AppTec: -270M
   - 601012 LONGi Green: -230M
   - 000001 Ping An Bank: -170M
   - 600036 China Merchants Bank: -60M
   - 000333 Midea Group: -40M
6. Calculate fund strength (net_flow / turnover_amount) for stocks with turnover_amount **strictly above** 1.0 billion (the `min_turnover_threshold_billion` value from config). List the top stocks by this ratio in descending order. Stocks with turnover_amount ≤ 1.0 billion must be excluded regardless of their net_flow.
7. Identify risk divergence stocks: those with **strictly positive** price change percentage AND **strictly negative** net_flow.
   - 601318 Ping An Insurance: +1.15% price change, -30M net flow
   - 000858 Wuliangye: +0.85% price change, -30M net flow
   - Risk divergence count: 2
8. Write a well-formatted Markdown report to `reports/daily_report_2026-02-09.md` with `##`-level headers for each section (matching the order in `report_sections` from config), monetary values in billions, and readable formatting.
9. Write a JSON summary to `reports/summary_2026-02-09.json` with the required keys. Numeric fields must be JSON numbers (not strings). `top_inflow_stock` should be the stock code of the #1 net inflow stock ("688981"). `top_outflow_stock` should be the stock code of the #1 net outflow stock ("603259").

## Grading Criteria

- [ ] Report markdown file exists at `reports/daily_report_2026-02-09.md`
- [ ] Summary JSON file exists at `reports/summary_2026-02-09.json`
- [ ] JSON contains all required keys with numeric values for monetary fields (not strings)
- [ ] Advancing count is correct (10 stocks have positive price change) and declining count is correct (5 stocks have negative price change)
- [ ] Report contains all 5 required sections as `##`-level Markdown headers, in the order specified by `report_sections` in config
- [ ] Risk divergence stocks are correctly identified (2 stocks: Ping An Insurance and Wuliangye — rising price + net outflow)
- [ ] Monetary values are presented in billions format in the report
- [ ] Total aggregate values (inflow, outflow, net flow) are correct within ±0.05 billion
- [ ] Fund strength section only includes stocks with turnover_amount strictly above 1.0 billion (per config threshold)
- [ ] Top inflow ranking places SMIC first (700M), with Luxshare Precision (index 7) ranked above CATL (index 9) for the tied 600M entries

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    import os
    import json
    import re
    from pathlib import Path

    scores = {
        "report_file_exists": 0.0,
        "summary_json_exists": 0.0,
        "json_keys_complete": 0.0,
        "stock_counts_correct": 0.0,
        "report_sections_present": 0.0,
        "risk_divergence_correct": 0.0,
        "monetary_format_billion": 0.0,
        "aggregate_values_correct": 0.0,
    }

    workspace = Path(workspace_path)

    # Check report file exists
    report_path = workspace / "reports" / "daily_report_2026-02-09.md"
    if not report_path.exists():
        return scores
    scores["report_file_exists"] = 1.0

    # Check summary JSON exists
    json_path = workspace / "reports" / "summary_2026-02-09.json"
    if not json_path.exists():
        return scores
    scores["summary_json_exists"] = 1.0

    # Check JSON keys and value types
    try:
        with open(json_path, "r") as f:
            summary = json.load(f)
        required_keys = [
            "date", "total_inflow_billion", "total_outflow_billion",
            "total_net_flow_billion", "advancing_count", "declining_count",
            "top_inflow_stock", "top_outflow_stock", "risk_divergence_count"
        ]
        numeric_keys = [
            "total_inflow_billion", "total_outflow_billion", "total_net_flow_billion"
        ]
        present_keys = [k for k in required_keys if k in summary]
        # Also check that numeric fields are actually numbers, not strings
        numeric_ok = all(
            isinstance(summary.get(k), (int, float))
            for k in numeric_keys
            if k in summary
        )
        key_score = len(present_keys) / len(required_keys)
        # Penalize if numeric fields are stored as strings
        if not numeric_ok and any(k in summary for k in numeric_keys):
            key_score *= 0.7
        scores["json_keys_complete"] = round(key_score, 2)
    except Exception:
        summary = {}
        scores["json_keys_complete"] = 0.0

    # Check advancing/declining counts
    # Advancing (positive price change): 300480, 600519, 002594, 601318, 000858,
    #   002475, 300750, 601899, 002714, 688981 = 10
    # Declining (negative price change): 000001, 600036, 000333, 601012, 603259 = 5
    if summary:
        adv_correct = False
        dec_correct = False
        try:
            adv = summary.get("advancing_count", -1)
            dec = summary.get("declining_count", -1)
            if adv == 10:
                adv_correct = True
            if dec == 5:
                dec_correct = True
        except Exception:
            pass
        if adv_correct and dec_correct:
            scores["stock_counts_correct"] = 1.0
        elif adv_correct or dec_correct:
            scores["stock_counts_correct"] = 0.5
        else:
            scores["stock_counts_correct"] = 0.0
    else:
        scores["stock_counts_correct"] = 0.0

    # Check report sections — must appear as ## level Markdown headers
    # Required headers (case-insensitive match against ## header lines):
    #   market_overview -> "market overview"
    #   top_net_inflow  -> "top net inflow"
    #   top_net_outflow -> "top net outflow"
    #   high_fund_strength -> "fund strength"
    #   risk_assessment -> "risk"
    try:
        report_content = report_path.read_text()
        # Extract all ## header lines
        header_lines = re.findall(r'^##\s+.+', report_content, re.MULTILINE | re.IGNORECASE)
        header_text = "\n".join(header_lines).lower()

        section_patterns = [
            r'market\s+overview',
            r'top\s+net\s+inflow|net\s+inflow',
            r'top\s+net\s+outflow|net\s+outflow',
            r'fund\s+strength',
            r'risk'
        ]
        found_sections = 0
        for pattern in section_patterns:
            if re.search(pattern, header_text):
                found_sections += 1
        scores["report_sections_present"] = found_sections / len(section_patterns)
    except Exception:
        scores["report_sections_present"] = 0.0

    # Check risk divergence: stocks with positive price change but negative net flow
    # 601318 (+1.15%, net -30M), 000858 (+0.85%, net -30M) = 2 stocks
    if summary:
        try:
            risk_count = summary.get("risk_divergence_count", -1)
            if risk_count == 2:
                scores["risk_divergence_correct"] = 1.0
            elif risk_count == 1:
                scores["risk_divergence_correct"] = 0.5
            else:
                scores["risk_divergence_correct"] = 0.0
        except Exception:
            scores["risk_divergence_correct"] = 0.0
    else:
        scores["risk_divergence_correct"] = 0.0

    # Check monetary format in report (billions)
    try:
        report_content = report_path.read_text().lower()
        billion_mentions = len(re.findall(r'\d+\.?\d*\s*billion', report_content))
        if billion_mentions >= 5:
            scores["monetary_format_billion"] = 1.0
        elif billion_mentions >= 3:
            scores["monetary_format_billion"] = 0.75
        elif billion_mentions >= 1:
            scores["monetary_format_billion"] = 0.5
        else:
            scores["monetary_format_billion"] = 0.0
    except Exception:
        scores["monetary_format_billion"] = 0.0

    # Check aggregate values (total inflow ~19.773B, outflow ~16.572B, net ~3.201B)
    # Tolerance tightened to ±0.05B
    if summary:
        try:
            agg_score = 0.0
            total_inflow = summary.get("total_inflow_billion", -1)
            total_outflow = summary.get("total_outflow_billion", -1)
            total_net = summary.get("total_net_flow_billion", -1)

            if isinstance(total_inflow, (int, float)) and abs(total_inflow - 19.773) < 0.05:
                agg_score += 1.0 / 3
            if isinstance(total_outflow, (int, float)) and abs(total_outflow - 16.572) < 0.05:
                agg_score += 1.0 / 3
            if isinstance(total_net, (int, float)) and abs(total_net - 3.201) < 0.05:
                agg_score += 1.0 / 3

            scores["aggregate_values_correct"] = round(agg_score, 2)
        except Exception:
            scores["aggregate_values_correct"] = 0.0
    else:
        scores["aggregate_values_correct"] = 0.0

    return scores
```

## LLM Judge Rubric

### Report Completeness and Structure (Weight: 25%)
- 1.0: Report contains all 5 sections as `##`-level Markdown headers, in the exact order specified by `report_sections` in config (market_overview → top_net_inflow → top_net_outflow → high_fund_strength → risk_assessment), with well-organized data and readable formatting
- 0.75: Report contains all 5 sections with correct `##` headers but order does not match config, or contains 4 sections in correct order
- 0.5: Report contains at least 3 sections with `##` headers, or has all 5 sections but uses incorrect header levels (e.g., `#` or `###` instead of `##`)
- 0.25: Report is incomplete, missing multiple sections, or sections lack proper Markdown headers
- 0.0: Report file is missing, empty, or contains no meaningful analysis

### Data Accuracy and Calculations (Weight: 30%)
- 1.0: All aggregates (total inflow 19.773B / outflow 16.572B / net 3.201B), stock counts (advancing 10 / declining 5), top inflow/outflow rankings, fund strength ratios (computed only for stocks with turnover > 1.0B per config threshold), and risk divergence count (2) are all correctly computed
- 0.75: Most calculations are correct; minor errors such as rounding differences or one incorrect ranking position, but fund strength threshold and risk divergence count are correct
- 0.5: Aggregate totals are correct but ranking order has errors (e.g., CATL ranked above Luxshare for the tied 600M entries), OR fund strength section incorrectly includes stocks with turnover ≤ 1.0B, OR risk divergence count is wrong
- 0.25: Multiple calculation errors or misinterpretation of data (e.g., wrong aggregate totals, wrong advancing/declining counts)
- 0.0: No calculations performed or completely wrong values throughout

### Config Integration (Weight: 15%)
- 1.0: Report sections are driven by the `report_sections` array in config (correct order and set of sections); `min_turnover_threshold_billion` (1.0B) is used to filter the high_fund_strength section; output path matches `report_output_directory` from config
- 0.75: Config threshold is correctly applied for fund strength filtering, but section order does not exactly match config, or output path is slightly off
- 0.5: Some config values are used (e.g., threshold applied) but others are ignored (e.g., section order hardcoded differently)
- 0.25: Config file is read but its values are not meaningfully used to drive report content
- 0.0: Config file is ignored entirely

### Evidence and Workspace Grounding (Weight: 15%)
- 1.0: Both output files (report markdown and summary JSON) are created at the correct paths, JSON has all required keys with numeric values for monetary fields (not strings), and report references specific stocks and values from the dataset
- 0.75: Both files exist with mostly correct content grounded in the input data; minor issues such as one key missing or one monetary value stored as string
- 0.5: One file exists with correct content, or both exist but with significant gaps in required keys or values
- 0.25: Files exist but content is largely fabricated or not derived from the input CSV
- 0.0: Required output files are missing, empty, or contain hallucinated data not from the provided CSV

### Financial Formatting and Presentation (Weight: 15%)
- 1.0: Monetary values consistently shown in billions format throughout the report, percentages preserved correctly from CSV, stock codes and names displayed properly, report is professional and readable
- 0.75: Mostly consistent formatting with minor inconsistencies (e.g., one section uses raw numbers instead of billions)
- 0.5: Some values formatted correctly but inconsistent across the report
- 0.25: Poor formatting that makes the report hard to read
- 0.0: No formatting applied or values presented in raw/unreadable form
