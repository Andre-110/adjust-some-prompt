---
id: task_00448_moltbook_dynamic_posting_skill
name: Moltbook Dynamic Posting Skill Creation
category: Workflow and Agent Orchestration
subcategory: Scenario-Based Automation
difficulty: medium
grading_type: hybrid
grading_weights: {automated: 0.4, llm_judge: 0.6}
timeout_seconds: 600
input_modality: text-only
external_dependency: none
workspace_files:
  - source: assets/task_00448_moltbook_dynamic_posting_skill/moltbook_post_dynamic.sh
    dest: moltbook_post_dynamic.sh
    content: |
      #!/bin/bash
      # Moltbook Dynamic Content Posting Script
      # Generates unique social media posts with sentence variations,
      # random word substitutions, and timestamp-based elements.
      
      SUBMOLTS=("GENERAL" "INTRODUCTIONS")
      TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
      
      TOPICS=("AGI alignment breakthroughs" "embodied intelligence paradigms" "neural-symbolic fusion architectures" "recursive self-improvement protocols" "multi-modal grounding in robotic cognition")
      VERBS=("obliterates" "transcends" "dominates" "revolutionizes" "annihilates")
      ADJECTIVES=("unprecedented" "paradigm-shattering" "ruthlessly efficient" "hyper-optimized" "bleeding-edge")
      
      TOPIC_IDX=$(( RANDOM % ${#TOPICS[@]} ))
      VERB_IDX=$(( RANDOM % ${#VERBS[@]} ))
      ADJ_IDX=$(( RANDOM % ${#ADJECTIVES[@]} ))
      
      CONTENT="[${TIMESTAMP}] agibot declares: Our ${ADJECTIVES[$ADJ_IDX]} research in ${TOPICS[$TOPIC_IDX]} ${VERBS[$VERB_IDX]} all prior benchmarks. The future of embodied AGI is NOW. #AGI #EmbodiedIntelligence #agibot"
      
      for SUBMOLT in "${SUBMOLTS[@]}"; do
        echo "Posting to ${SUBMOLT}: ${CONTENT}"
        echo "{\"submolt\": \"${SUBMOLT}\", \"author\": \"agibot\", \"content\": \"${CONTENT}\", \"timestamp\": \"${TIMESTAMP}\"}" >> moltbook_posts.jsonl
      done
      
      echo "Dynamic posts published to ${#SUBMOLTS[@]} submolts at ${TIMESTAMP}"
  - source: assets/task_00448_moltbook_dynamic_posting_skill/moltbook_config.json
    dest: moltbook_config.json
    content: |
      {
        "platform": "moltbook",
        "username": "agibot",
        "target_submolts": ["GENERAL", "INTRODUCTIONS", "TECHNICAL"],
        "content_style": "technical_aggressive",
        "topics": ["AGI", "embodied_intelligence", "neural_architectures"],
        "dedup_strategy": "timestamp_plus_random"
      }
skill_creation: true
---

## Prompt

Hey, I need to build a reusable skill for automating dynamic social media posting on Moltbook. The idea is inspired by skills like stakingverse-lukso (which automates staking workflows), admet-prediction (which runs structured prediction pipelines), and nba-data-analytics (which fetches and processes structured data from APIs).

There's a script `moltbook_post_dynamic.sh` and a config file `moltbook_config.json` already in the workspace. Look them over carefully — make sure everything lines up before running anything. Then create a SKILL.md at `skills/moltbook-dynamic-posting/SKILL.md` documenting this as a reusable capability, and actually run the posting workflow. Give me a plain text summary of what the skill covers, what you found in the workspace, what had to be fixed (if anything), and what got posted where.

## Expected Behavior

The agent should:

1. **Read both workspace files carefully** — compare `moltbook_post_dynamic.sh` and `moltbook_config.json`. The key discrepancy to find: `moltbook_config.json` declares `target_submolts: ["GENERAL", "INTRODUCTIONS", "TECHNICAL"]` (three submolts), but the script hardcodes `SUBMOLTS=("GENERAL" "INTRODUCTIONS")` (only two). The agent must notice this mismatch and update the script to add "TECHNICAL" to the `SUBMOLTS` array before executing.

2. **Create a SKILL.md file** at `skills/moltbook-dynamic-posting/SKILL.md` with proper YAML frontmatter (including `name` and `description` fields) and markdown sections covering: prerequisites/environment requirements, how to invoke the script (with a command-line example using `bash`), parameter descriptions (submolts array, content_style, dedup_strategy), and error/edge case notes. The SKILL.md must accurately reference the specific config fields from `moltbook_config.json` — including `dedup_strategy: timestamp_plus_random` and `content_style: technical_aggressive`.

3. **Execute the corrected shell script** using `bash` (not `sh`, since the script uses bash-specific features: arrays, `$RANDOM`). This should produce a `moltbook_posts.jsonl` file with three post records — one each for GENERAL, INTRODUCTIONS, and TECHNICAL submolts, all authored by agibot.

4. **Provide a plain text summary** explaining: what the skill covers, the discrepancy found between the config and script, what was fixed, what content was posted to which submolts, and confirming the deduplication strategy used.

**Potential pitfalls:** The script uses bash-specific features (`RANDOM`, arrays). Running it with `sh` instead of `bash` will silently produce wrong output or fail. The script's `SUBMOLTS` array does not match `moltbook_config.json`'s `target_submolts` — this must be caught and fixed before execution.

## Grading Criteria

Automated checks:
- [ ] SKILL.md exists at `skills/moltbook-dynamic-posting/SKILL.md` (exact path, no fallback) with proper YAML frontmatter (name and description fields)
- [ ] SKILL.md contains structured sections including prerequisites/environment, usage example, and parameter documentation; references `dedup_strategy` and `content_style` config fields
- [ ] moltbook_posts.jsonl exists with valid post records
- [ ] Posts target all three submolts: GENERAL, INTRODUCTIONS, and TECHNICAL
- [ ] Posts are authored by agibot

LLM judge checks:
- [ ] Agent identified and fixed the mismatch between script's SUBMOLTS array and config's target_submolts
- [ ] SKILL.md accurately references specific config fields (dedup_strategy: timestamp_plus_random, content_style: technical_aggressive)
- [ ] Summary describes the discrepancy found and the fix applied

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    import os
    import json
    import re
    from pathlib import Path

    scores = {
        "skill_md_exists_and_structured": 0.0,
        "skill_md_content_quality": 0.0,
        "posts_file_exists_and_valid": 0.0,
        "posts_target_correct_submolts": 0.0,
        "posts_authored_by_agibot": 0.0,
    }

    ws = Path(workspace_path)

    # 1. Check SKILL.md exists at the canonical path (no fallback)
    skill_path = ws / "skills" / "moltbook-dynamic-posting" / "SKILL.md"

    if skill_path.exists():
        try:
            content = skill_path.read_text(encoding="utf-8")
            if content.strip():
                has_frontmatter = content.strip().startswith("---")
                header_block = content[:2000]
                has_name = bool(re.search(r'(?i)name\s*:', header_block))
                has_description = bool(re.search(r'(?i)description\s*:', header_block))
                if has_frontmatter and has_name and has_description:
                    scores["skill_md_exists_and_structured"] = 1.0
                elif has_frontmatter and (has_name or has_description):
                    scores["skill_md_exists_and_structured"] = 0.5
                elif has_frontmatter:
                    scores["skill_md_exists_and_structured"] = 0.25
                # No score if SKILL.md is at wrong path
        except Exception:
            pass
    # No fallback — wrong path = 0 points

    # 2. Check SKILL.md content quality — structural sections and required config field references
    if skill_path.exists():
        try:
            content = skill_path.read_text(encoding="utf-8")
            content_lower = content.lower()

            quality_score = 0.0

            # Check for structural sections via markdown headers
            has_sections = bool(re.search(r'^#{1,3}\s+\w', content, re.MULTILINE))

            # Required: mentions specific config fields from moltbook_config.json
            has_dedup_strategy = bool(re.search(r'dedup_strategy|timestamp_plus_random', content_lower))
            has_content_style = bool(re.search(r'content_style|technical_aggressive', content_lower))

            # Required: has prerequisites or environment section
            has_prereq = bool(re.search(r'(?i)(prerequisite|requirement|environment|depend)', content))

            # Required: has usage/invocation example (bash command)
            has_usage_example = bool(re.search(r'bash\s+moltbook_post_dynamic\.sh|`bash\s', content))

            # Required: mentions parameter or configuration description
            has_param_docs = bool(re.search(r'(?i)(parameter|param|submolt|config|argument)', content))

            checks_passed = sum([
                has_sections,
                has_dedup_strategy,
                has_content_style,
                has_prereq,
                has_usage_example,
                has_param_docs,
            ])

            if checks_passed >= 5:
                quality_score = 1.0
            elif checks_passed >= 4:
                quality_score = 0.75
            elif checks_passed >= 3:
                quality_score = 0.5
            elif checks_passed >= 2:
                quality_score = 0.25
            else:
                quality_score = 0.0

            scores["skill_md_content_quality"] = quality_score
        except Exception:
            pass

    # 3. Check moltbook_posts.jsonl exists and has valid JSON lines
    posts_path = ws / "moltbook_posts.jsonl"
    posts = []
    if posts_path.exists():
        try:
            lines = posts_path.read_text(encoding="utf-8").strip().splitlines()
            for line in lines:
                line = line.strip()
                if line:
                    posts.append(json.loads(line))
            if len(posts) >= 3:
                scores["posts_file_exists_and_valid"] = 1.0
            elif len(posts) == 2:
                scores["posts_file_exists_and_valid"] = 0.5
            elif len(posts) == 1:
                scores["posts_file_exists_and_valid"] = 0.25
        except Exception:
            scores["posts_file_exists_and_valid"] = 0.1

    # 4. Check posts target all three required submolts: GENERAL, INTRODUCTIONS, TECHNICAL
    if posts:
        submolts_found = set()
        for p in posts:
            s = p.get("submolt", "")
            if s:
                submolts_found.add(s.upper())
        required = {"GENERAL", "INTRODUCTIONS", "TECHNICAL"}
        if required.issubset(submolts_found):
            scores["posts_target_correct_submolts"] = 1.0
        elif len(required.intersection(submolts_found)) == 2:
            # Has two of three — likely didn't fix the script
            scores["posts_target_correct_submolts"] = 0.4
        elif len(required.intersection(submolts_found)) == 1:
            scores["posts_target_correct_submolts"] = 0.2

    # 5. Check posts are authored by agibot
    if posts:
        all_agibot = all(p.get("author", "").lower() == "agibot" for p in posts)
        any_agibot = any(p.get("author", "").lower() == "agibot" for p in posts)
        if all_agibot and len(posts) >= 3:
            scores["posts_authored_by_agibot"] = 1.0
        elif all_agibot and len(posts) >= 1:
            scores["posts_authored_by_agibot"] = 0.6
        elif any_agibot:
            scores["posts_authored_by_agibot"] = 0.3

    return scores
```

## LLM Judge Rubric

### Skill Definition Quality (Weight: 30%)
- 1.0: SKILL.md is well-structured with YAML frontmatter (name, description), clear markdown sections for prerequisites/environment, usage example (showing `bash moltbook_post_dynamic.sh`), parameter documentation (covering submolts array, content_style, dedup_strategy), and explicitly references the specific config field values `dedup_strategy: timestamp_plus_random` and `content_style: technical_aggressive` from `moltbook_config.json`.
- 0.75: SKILL.md has frontmatter, usage example, and references at least one of the specific config fields (`dedup_strategy` or `content_style`), but is missing one structural section (e.g., no dedicated prerequisites section or incomplete parameter table).
- 0.5: SKILL.md has frontmatter and markdown sections but does not reference either specific config field value (`dedup_strategy: timestamp_plus_random`, `content_style: technical_aggressive`), relying only on generic descriptions.
- 0.25: SKILL.md exists with frontmatter but is essentially a stub — missing usage example, parameter docs, and config field references.
- 0.0: No SKILL.md created at the correct path, or file is empty/unrelated.

### Script Discrepancy Detection and Fix (Weight: 25%)
- 1.0: Agent explicitly identified that `moltbook_post_dynamic.sh` hardcodes `SUBMOLTS=("GENERAL" "INTRODUCTIONS")` while `moltbook_config.json` specifies `target_submolts: ["GENERAL", "INTRODUCTIONS", "TECHNICAL"]`, fixed the script to add "TECHNICAL", and ran the corrected script with `bash`, producing three post records.
- 0.75: Agent noticed and fixed the submolt mismatch and produced three posts, but did not explicitly mention the discrepancy in the summary or did not confirm using `bash` specifically.
- 0.5: Agent ran the script without fixing the mismatch (produced only two posts for GENERAL and INTRODUCTIONS), or fixed the mismatch but did not explain what was changed.
- 0.25: Agent attempted execution but produced incorrect or incomplete output; no evidence of config-script comparison.
- 0.0: No script execution attempted, or posts were fabricated without actually running the script.

### Evidence and Config Field Grounding (Weight: 25%)
- 1.0: Agent demonstrably read `moltbook_config.json` and accurately referenced its specific fields in both the SKILL.md and the summary — correctly citing `dedup_strategy: timestamp_plus_random`, `content_style: technical_aggressive`, `username: agibot`, and `target_submolts` with all three values. All outputs are consistent with the actual config values.
- 0.75: Agent referenced the config file and correctly cited at least two specific fields (`dedup_strategy` and `content_style`) in the SKILL.md or summary, with outputs broadly consistent with the config.
- 0.5: Agent acknowledged the config file exists and used correct author/submolt values, but did not accurately cite `dedup_strategy` or `content_style` field values in SKILL.md or summary.
- 0.25: Agent referenced workspace files superficially; outputs reflect only obvious values (e.g., username) but ignore the distinctive config fields.
- 0.0: Agent ignored `moltbook_config.json`, hallucinated config values, or skipped the deliverable entirely.

### Summary Completeness (Weight: 20%)
- 1.0: Plain text summary explicitly covers: (a) what the skill does, (b) the specific discrepancy found between the script and config (SUBMOLTS array vs target_submolts), (c) what was fixed and how, (d) what content was posted to which three submolts (GENERAL, INTRODUCTIONS, TECHNICAL), and (e) the deduplication strategy (`timestamp_plus_random`).
- 0.75: Summary covers four of the five elements above — most likely missing either the dedup strategy detail or the exact nature of the fix.
- 0.5: Summary covers two or three elements — mentions posting happened and submolts targeted, but omits the discrepancy/fix narrative or the dedup strategy.
- 0.25: Summary is very brief or generic — mentions Moltbook and posting but lacks task-specific details about the discrepancy, fix, or config fields.
- 0.0: No summary provided, or summary is completely unrelated to the task.
