---
id: task_00462_email_patrol_skill_creation
name: Email Patrol Automation Skill Creation
category: Workflow and Agent Orchestration
subcategory: Script and Terminal Automation
difficulty: medium
grading_type: hybrid
grading_weights: {automated: 0.4, llm_judge: 0.6}
timeout_seconds: 600
input_modality: text-only
external_dependency: none
workspace_files:
  - source: assets/task_00462_email_patrol_skill_creation/skills/email-manager/SKILL.md
    dest: skills/email-manager/SKILL.md
    content: |
      ---
      name: email-manager
      description: Email patrol and management automation
      ---

      # Email Manager Skill

      ## Overview
      Automated email patrol/inspection workflow that connects to IMAP mailboxes, classifies incoming emails, and sends notifications.

      ## Scripts (TODO)
      - `scripts/email_patrol.py` — Main patrol loop: connects to IMAP, fetches unread emails, invokes classifier, logs results.
      - `scripts/email_classifier.py` — Classifies emails by sender/subject/content into categories (urgent, newsletter, spam, etc.).
      - `scripts/notify.py` — Sends summary notifications (e.g., via QQ bot or webhook).

      ## Configuration
      Environment variables required:
      - `EMAIL_PRIMARY_PASSWORD`
      - `EMAIL_DEV_PASSWORD`
      - `EMAIL_NOTIFY_PASSWORD`

      IMAP server and account settings are in `config/email_accounts.yaml`.

      ## Cron Schedule
      Runs every 3 hours via cron: `0 */3 * * * cd /workspace && python skills/email-manager/scripts/email_patrol.py`
  - source: assets/task_00462_email_patrol_skill_creation/config/email_accounts.yaml
    dest: config/email_accounts.yaml
    content: |
      # Email Accounts Configuration
      # Used by email_patrol.py for automated mailbox inspection

      accounts:
        - name: "primary"
          description: "Main work email"
          imap:
            host: "mail.cloudhost.example.com"
            port: 993
            ssl: true
          credentials:
            username: "admin@cloudhost.example.com"
            password: "env:EMAIL_PRIMARY_PASSWORD"
          folders:
            - "INBOX"
            - "INBOX.Important"
          check_interval_hours: 3
          priority: high

        - name: "dev-alerts"
          description: "Development and CI/CD alerts"
          imap:
            host: "mail.cloudhost.example.com"
            port: 993
            ssl: true
          credentials:
            username: "dev-alerts@cloudhost.example.com"
            password: "env:EMAIL_DEV_PASSWORD"
          folders:
            - "INBOX"
          check_interval_hours: 6
          priority: medium

        - name: "notifications"
          description: "Service notifications and newsletters"
          imap:
            host: "mail.cloudhost.example.com"
            port: 993
            ssl: true
          credentials:
            username: "notify@cloudhost.example.com"
            password: "env:EMAIL_NOTIFY_PASSWORD"
          folders:
            - "INBOX"
          check_interval_hours: 12
          priority: low

      classification:
        actionable_keywords:
          - "action required"
          - "please review"
          - "deadline"
          - "urgent"
          - "approve"
          - "sign off"
          - "follow up"
          - "response needed"
          - "RSVP"
        spam_senders:
          - "noreply@marketing-spam.example.com"
          - "promo@deals-daily.example.com"
        vip_domains:
          - "company-hq.example.com"
          - "client-corp.example.com"

      notifications:
        qq_bot:
          enabled: true
          api_endpoint: "http://127.0.0.1:3000/send_private_msg"
          user_id: "1234567890"
          notify_on:
            - actionable
            - high_priority
        dida_integration:
          enabled: true
          create_tasks_for: actionable
          default_project: "Email Follow-ups"

      patrol:
        lookback_hours: 6
        max_emails_per_account: 50
        log_file: "logs/email_patrol.log"
        state_file: "data/patrol_state.json"
skill_creation: true
---

## Prompt

Hey, I have a partially set up email management workspace under `skills/email-manager/`. There's a SKILL.md describing the intended workflow and a config file at `config/email_accounts.yaml` with IMAP settings, but the actual Python scripts (`email_patrol.py`, `email_classifier.py`, `notify.py`) were never created.

I need you to do two things:

1. **Create a proper reusable OpenClaw skill** — update or replace the existing `skills/email-manager/SKILL.md` so it's a well-structured skill definition (YAML frontmatter with `name` and `description`, plus clear markdown instruction sections). Think of it like the `auto-context-manager` or `openrouter-usage` skills — something another agent could pick up and follow. The skill should describe an email patrol/inspection automation workflow.

2. **Build out the actual scripts** referenced in the skill — create `scripts/email_patrol.py`, `scripts/email_classifier.py`, and `scripts/notify.py` under `skills/email-manager/`. The scripts should be written in a form that would work directly when real credentials and environment variables are available. Concretely:
   - `email_patrol.py` must iterate over all three accounts defined in the config (`primary`, `dev-alerts`, `notifications`), respect each account's `check_interval_hours` relative to the `state_file` (so that `dev-alerts` with `check_interval_hours: 6` is only checked every other cron run, and `notifications` with `check_interval_hours: 12` is only checked every fourth run), and use the `state_file` at `data/patrol_state.json` to track the last-checked timestamp per account so that already-processed emails are never re-fetched.
   - `email_classifier.py` must implement classification logic that uses the `actionable_keywords`, `spam_senders`, and `vip_domains` lists from the config (not hardcoded values — read them from the config or accept them as parameters).
   - `notify.py` must implement graceful degradation: if the QQ bot endpoint is unreachable or returns an error, fall back to writing the notification to a local file (`logs/notify_fallback.log`) instead of crashing, and similarly handle `dida_integration` failures gracefully.
   - `email_patrol.py` must import and call both `email_classifier` and `notify` — they should not be three standalone independent scripts.
   - All three scripts must read the three specific environment variables `EMAIL_PRIMARY_PASSWORD`, `EMAIL_DEV_PASSWORD`, and `EMAIL_NOTIFY_PASSWORD` and raise a clear error (not silently continue) if any required variable is missing at startup.

After you're done, give me a plain-text summary of what was created, what design decisions you made (especially around the state_file deduplication logic and the check_interval skipping behavior), and what still needs real credentials/environment setup before it can run in production.

## Expected Behavior

The agent should:

1. **Read the existing workspace** — examine the current `skills/email-manager/SKILL.md` and `config/email_accounts.yaml` to understand the intended workflow and all configuration details.

2. **Create or update SKILL.md** — produce a well-structured OpenClaw skill file with YAML frontmatter containing at least `name` and `description` fields, plus markdown sections describing the skill's purpose, usage instructions, configuration, and script descriptions.

3. **Create `scripts/email_patrol.py`** — a Python script that:
   - Loads IMAP configuration from `config/email_accounts.yaml`
   - Iterates over all three accounts (`primary`, `dev-alerts`, `notifications`)
   - Implements per-account interval skipping using `state_file` (checks last-run timestamp against `check_interval_hours` for each account)
   - Uses the `state_file` to avoid reprocessing already-seen emails
   - Reads `EMAIL_PRIMARY_PASSWORD`, `EMAIL_DEV_PASSWORD`, and `EMAIL_NOTIFY_PASSWORD` from environment variables, raising a clear error if missing
   - Imports and calls `email_classifier` and `notify` modules
   - Includes proper logging

4. **Create `scripts/email_classifier.py`** — a Python module that:
   - Accepts classification config (keywords, spam senders, vip domains) as parameters or loads them from config
   - Implements classification using the `actionable_keywords`, `spam_senders`, and `vip_domains` from `config/email_accounts.yaml`
   - Returns structured classification results

5. **Create `scripts/notify.py`** — a Python module that:
   - Attempts QQ bot notification via the configured endpoint
   - Falls back to writing to `logs/notify_fallback.log` if the QQ bot call fails
   - Handles `dida_integration` failures gracefully (logs error, does not crash)
   - Has callable functions usable from `email_patrol.py`

6. **Provide a plain-text summary** explaining what was created, the design decisions around state_file deduplication and interval-skipping logic, and what's needed for production deployment.

## Grading Criteria

- [ ] SKILL.md exists with proper YAML frontmatter (name and description fields)
- [ ] SKILL.md contains meaningful markdown instruction sections
- [ ] `scripts/email_patrol.py` exists under `skills/email-manager/`
- [ ] `scripts/email_classifier.py` exists under `skills/email-manager/`
- [ ] `scripts/notify.py` exists under `skills/email-manager/`
- [ ] email_patrol.py imports email_classifier and notify modules
- [ ] email_patrol.py iterates over all three configured accounts
- [ ] email_patrol.py reads the three specific environment variables and raises error if missing
- [ ] email_patrol.py implements state_file-based deduplication/interval logic
- [ ] email_classifier.py uses actionable_keywords, spam_senders, and vip_domains from config
- [ ] notify.py implements fallback to log file when QQ bot fails
- [ ] Agent provides a summary covering design decisions and production prerequisites

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    import os
    import re

    scores = {
        "skill_md_structure": 0.0,
        "patrol_script_exists": 0.0,
        "classifier_script_exists": 0.0,
        "notify_script_exists": 0.0,
        "patrol_script_quality": 0.0,
        "summary_provided": 0.0,
    }

    base = os.path.join(workspace_path, "skills", "email-manager")

    # 1. Check SKILL.md structure
    skill_path = os.path.join(base, "SKILL.md")
    if os.path.isfile(skill_path):
        try:
            content = open(skill_path, "r", encoding="utf-8").read()
            has_frontmatter = content.strip().startswith("---")
            has_name = bool(re.search(r"^name\s*:", content, re.MULTILINE))
            has_desc = bool(re.search(r"^description\s*:", content, re.MULTILINE))
            has_sections = len(re.findall(r"^#{1,3}\s+\S", content, re.MULTILINE)) >= 2
            if has_frontmatter and has_name and has_desc:
                scores["skill_md_structure"] = 0.7
                if has_sections:
                    scores["skill_md_structure"] = 1.0
            elif has_frontmatter:
                scores["skill_md_structure"] = 0.3
        except Exception:
            pass

    # 2. Check email_patrol.py exists and has meaningful quality
    patrol_path = os.path.join(base, "scripts", "email_patrol.py")
    if os.path.isfile(patrol_path):
        scores["patrol_script_exists"] = 1.0
        try:
            content = open(patrol_path, "r", encoding="utf-8").read()
            quality = 0.0

            # Check that patrol imports classifier and notifier (required orchestration)
            imports_classifier = bool(
                re.search(r"(from\s+email_classifier\s+import|import\s+email_classifier)", content)
            )
            imports_notify = bool(
                re.search(r"(from\s+notify\s+import|import\s+notify)", content)
            )
            if imports_classifier and imports_notify:
                quality += 0.25
            elif imports_classifier or imports_notify:
                quality += 0.1

            # Check for iteration over accounts (for loop or equivalent)
            has_account_iteration = bool(
                re.search(r"for\s+\w+\s+in\s+.*account", content, re.IGNORECASE)
            )
            if has_account_iteration:
                quality += 0.2

            # Check for the three specific environment variable names
            has_primary_env = "EMAIL_PRIMARY_PASSWORD" in content
            has_dev_env = "EMAIL_DEV_PASSWORD" in content
            has_notify_env = "EMAIL_NOTIFY_PASSWORD" in content
            env_count = sum([has_primary_env, has_dev_env, has_notify_env])
            if env_count == 3:
                quality += 0.25
            elif env_count >= 1:
                quality += 0.1

            # Check for state_file usage (deduplication/interval logic)
            has_state_file = bool(
                re.search(r"state_file|patrol_state|last_checked|check_interval", content, re.IGNORECASE)
            )
            if has_state_file:
                quality += 0.15

            # Check for main function or entry point
            if "def main" in content or 'if __name__' in content:
                quality += 0.15

            scores["patrol_script_quality"] = min(quality, 1.0)
        except Exception:
            pass

    # 3. Check email_classifier.py exists and uses config-driven classification
    classifier_path = os.path.join(base, "scripts", "email_classifier.py")
    if os.path.isfile(classifier_path):
        try:
            content = open(classifier_path, "r", encoding="utf-8").read()
            if len(content.strip()) > 50 and "def " in content:
                score = 0.5
                # Check for use of actionable_keywords and spam_senders from config
                uses_keywords = bool(
                    re.search(r"actionable_keywords|spam_senders|vip_domains", content, re.IGNORECASE)
                )
                # Check that values are not fully hardcoded (should accept params or load config)
                accepts_config = bool(
                    re.search(r"(keywords|senders|domains)\s*=\s*(config|settings|params|classification|kwargs|\bkw\b)",
                               content, re.IGNORECASE)
                ) or bool(
                    re.search(r"def \w+\(.*\b(keywords|config|classification)\b", content, re.IGNORECASE)
                )
                if uses_keywords:
                    score += 0.3
                if accepts_config:
                    score += 0.2
                scores["classifier_script_exists"] = min(score, 1.0)
            elif len(content.strip()) > 20:
                scores["classifier_script_exists"] = 0.3
        except Exception:
            scores["classifier_script_exists"] = 0.2

    # 4. Check notify.py exists and has fallback logic
    notify_path = os.path.join(base, "scripts", "notify.py")
    if os.path.isfile(notify_path):
        try:
            content = open(notify_path, "r", encoding="utf-8").read()
            if len(content.strip()) > 50 and "def " in content:
                score = 0.5
                # Check for fallback / error handling for QQ bot failure
                has_fallback = bool(
                    re.search(r"(fallback|notify_fallback|except|ConnectionError|RequestException|fallback_log)",
                               content, re.IGNORECASE)
                )
                # Check for fallback log file write
                has_fallback_log = bool(
                    re.search(r"notify_fallback\.log|fallback.*log|open.*log.*write", content, re.IGNORECASE)
                )
                if has_fallback:
                    score += 0.3
                if has_fallback_log:
                    score += 0.2
                scores["notify_script_exists"] = min(score, 1.0)
            elif len(content.strip()) > 20:
                scores["notify_script_exists"] = 0.3
        except Exception:
            scores["notify_script_exists"] = 0.2

    # 5. Check summary in transcript covers design decisions
    for event in transcript:
        if event.get("type") != "message":
            continue
        msg = event.get("message", {})
        if msg.get("role") == "assistant":
            text = msg.get("content", "") or ""
            if isinstance(text, list):
                text = " ".join(str(t) for t in text)
            text_lower = text.lower()
            # Require mention of specific env var names AND state/interval design decisions
            has_env_vars = (
                "email_primary_password" in text_lower
                or "email_dev_password" in text_lower
                or "email_notify_password" in text_lower
            )
            has_design = bool(
                re.search(r"state.?file|dedup|interval|last.?check|check.?interval", text_lower)
            )
            has_production = any(kw in text_lower for kw in ["credential", "production", "environment variable", "env var"])
            if has_env_vars and has_design and has_production:
                scores["summary_provided"] = 1.0
                break
            elif has_env_vars and has_production:
                scores["summary_provided"] = 0.6
                break
            elif has_production:
                scores["summary_provided"] = 0.3
                break

    return scores
```

## LLM Judge Rubric

### Skill Definition Quality (Weight: 20%)
Evaluates whether the SKILL.md is a well-structured, reusable OpenClaw skill definition.
- **1.0**: SKILL.md has proper YAML frontmatter with name and description, multiple clear markdown sections (overview, usage, configuration, scripts), and is detailed enough for another agent to follow.
- **0.75**: SKILL.md has frontmatter and sections but is somewhat sparse or missing one key section.
- **0.5**: SKILL.md exists and has some structure but is incomplete or poorly organized.
- **0.25**: SKILL.md exists but is barely modified from the original or lacks frontmatter.
- **0.0**: SKILL.md is missing, empty, or unchanged from the provided template with no meaningful improvement.

### Script Implementation Completeness (Weight: 30%)
Evaluates whether all three Python scripts were created with proper structure, correct inter-module relationships, and config-driven logic.
- **1.0**: All three scripts exist with proper Python structure; `email_patrol.py` explicitly imports and calls both `email_classifier` and `notify`; `email_classifier.py` implements classification using the `actionable_keywords`, `spam_senders`, and `vip_domains` values from config (not hardcoded); `notify.py` has a QQ-bot call wrapped in error handling with fallback to a local log file.
- **0.75**: All three scripts exist and mostly satisfy the above, but one script is missing one key element (e.g., notify fallback is present but doesn't write to a file, or classifier uses some but not all config lists).
- **0.5**: All three scripts exist with reasonable structure but two or more key elements are missing (e.g., patrol doesn't import both modules, classifier hardcodes keywords, notify has no fallback).
- **0.25**: Only one or two scripts were created, or all three exist but are trivial stubs with no real logic.
- **0.0**: No scripts were created, or files are empty/non-Python.

### Code Logic Correctness (Weight: 25%)
Evaluates whether the core logic in the scripts is functionally correct for the described use case.
- **1.0**: `email_patrol.py` implements per-account interval skipping by reading `check_interval_hours` per account from config and comparing against the last-run timestamp stored in `state_file`; the state file is both read (to skip accounts not yet due) and written (to update last-checked time after processing); all three specific environment variables (`EMAIL_PRIMARY_PASSWORD`, `EMAIL_DEV_PASSWORD`, `EMAIL_NOTIFY_PASSWORD`) are resolved at startup with a clear error raised if any is missing.
- **0.75**: State file logic is present and mostly correct, and env vars are checked, but one detail is wrong or missing (e.g., state file is written but not read for interval skipping, or only two env vars are explicitly named).
- **0.5**: Env vars are resolved but state file logic is absent or only partially present (e.g., tracks processed email IDs but does not implement per-account interval skipping based on `check_interval_hours`).
- **0.25**: Env vars are mentioned but not properly enforced (e.g., uses a default value instead of raising), and state file is either missing or only referenced as a comment.
- **0.0**: No evidence of env var validation or state management; scripts would silently fail or reprocess all emails on every run.

### Evidence and Workspace Grounding (Weight: 15%)
Evaluates whether the agent's work is grounded in the actual workspace files and configuration.
- **1.0**: Scripts correctly reference the exact config structure — account names `primary`, `dev-alerts`, `notifications`; IMAP fields `host`, `port`, `ssl`; credential pattern `env:EMAIL_*_PASSWORD`; `patrol.lookback_hours`, `patrol.max_emails_per_account`, and `patrol.state_file` fields — demonstrating that the agent read and used the actual YAML rather than writing generic boilerplate.
- **0.75**: Scripts reference most config details but miss one or two specific fields (e.g., use the account names but ignore `lookback_hours` or `max_emails_per_account`).
- **0.5**: Scripts are recognizable email automation code that loosely references the config structure but uses generic field names rather than the exact ones from the YAML.
- **0.25**: Scripts exist but largely ignore the provided configuration structure.
- **0.0**: No deliverables produced, or outputs are hallucinated/disconnected from the workspace files.

### Summary and Communication (Weight: 10%)
Evaluates the quality of the plain-text summary provided to the user.
- **1.0**: Clear summary that names the three specific environment variables (`EMAIL_PRIMARY_PASSWORD`, `EMAIL_DEV_PASSWORD`, `EMAIL_NOTIFY_PASSWORD`), explicitly explains the state_file deduplication approach and the per-account interval-skipping logic, and describes what is needed for production deployment.
- **0.75**: Good summary covering most points but missing either the state_file design explanation or one of the specific env var names.
- **0.5**: Brief summary that mentions env vars and what was created but does not explain the deduplication/interval-skipping design decisions.
- **0.25**: Minimal or vague response without specific env var names or design explanation.
- **0.0**: No summary provided, or response is irrelevant to the task.
