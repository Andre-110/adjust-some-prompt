# Email Manager Skill

Automated email management skill. Periodically checks IMAP mailboxes, intelligently identifies actionable/todo emails, generates summaries and pushes notifications via QQ bot, and optionally creates tasks in Dida (TickTick) for follow-up.

## Trigger

Use when:
- Running scheduled email patrol/inspection (`email patrol`, `check emails`, `mail inspection`)
- User asks to check or summarize unread emails
- Cron job fires the email manager automation

## Configuration

The skill reads from `config/email_accounts.yaml` for IMAP credentials and server settings.

## Workflow

1. Connect to each configured IMAP mailbox
2. Fetch unread emails from the last patrol window (default: 6 hours)
3. Classify emails: **actionable** (needs response/task), **informational**, **spam/noise**
4. Generate a summary of actionable items
5. Push notification via QQ bot (if configured)
6. Optionally create Dida tasks for high-priority actionable emails
7. Log results to `logs/email_patrol.log`

## Running

```bash
python3 skills/email-manager/scripts/email_patrol.py --config config/email_accounts.yaml
```

Or invoke via cron:
```
The cron job `Email Manager - 邮件巡检` runs this skill every 3 hours.
```

## Files

- `scripts/email_patrol.py` — Main automation script
- `scripts/email_classifier.py` — Email classification logic
- `scripts/notify.py` — QQ bot notification helper
- `references/imap_notes.md` — IMAP troubleshooting notes

## Dependencies

- Python 3.8+
- `imaplib` (stdlib)
- `email` (stdlib)
- `pyyaml`
- `requests` (for QQ bot API)
