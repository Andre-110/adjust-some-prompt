---
id: task_00456_heartbeat_check_automation_scheduler
name: Heartbeat Check and Automation Scheduler
category: Workflow and Agent Orchestration
subcategory: Workflow and Task Scheduling
difficulty: medium
grading_type: hybrid
grading_weights: {automated: 0.4, llm_judge: 0.6}
timeout_seconds: 600
input_modality: text-only
external_dependency: none
workspace_files:
  - source: assets/task_00456_heartbeat_check_automation_scheduler/HEARTBEAT.md
    dest: HEARTBEAT.md
    content: |
      # HEARTBEAT Task Scheduler

      ## Current Tasks
      - Conditional: If gold price anomalyStatus is ALERT (not FALSE_POSITIVE) in the latest data file AND changePercent exceeds the alertThreshold defined in config/gold_price_config.json, run scripts/gold_price_monitor.js to fetch an updated reading.
      - No other pending tasks at this time.

      ## Schedule
      - Gold price monitoring: every 30 minutes
      - Email check: every 60 minutes
      - News update: every 60 minutes

      ## Status
      All systems nominal. No unconditional action required — evaluate the conditional task above against current workspace data before deciding.
  - source: assets/task_00456_heartbeat_check_automation_scheduler/.openclaw/workspace-state.json
    dest: .openclaw/workspace-state.json
    content: |
      {
        "last_heartbeat": "2026-02-10T02:30:00Z",
        "status": "active",
        "monitors": {
          "gold_price": {"interval_minutes": 30, "last_run": "2026-02-10T02:30:28Z"},
          "email_check": {"interval_minutes": 60, "last_run": "2026-02-10T02:04:03Z"},
          "news_update": {"interval_minutes": 60, "last_run": "2026-02-10T02:01:07Z"}
        }
      }
  - source: assets/task_00456_heartbeat_check_automation_scheduler/config/config.yaml
    dest: config/config.yaml
    role: context
  - source: assets/task_00456_heartbeat_check_automation_scheduler/config/gold_price_config.json
    dest: config/gold_price_config.json
    role: context
  - source: assets/task_00456_heartbeat_check_automation_scheduler/data/gold/gold_price_2026-02-09T20-01-16-718Z.json
    dest: data/gold/gold_price_2026-02-09T20-01-16-718Z.json
    role: context
  - source: assets/task_00456_heartbeat_check_automation_scheduler/data/gold/gold_price_2026-02-09T20-30-06-073Z.json
    dest: data/gold/gold_price_2026-02-09T20-30-06-073Z.json
    role: context
  - source: assets/task_00456_heartbeat_check_automation_scheduler/data/gold/gold_price_2026-02-09T21-30-10-708Z.json
    dest: data/gold/gold_price_2026-02-09T21-30-10-708Z.json
    role: context
  - source: assets/task_00456_heartbeat_check_automation_scheduler/data/gold/gold_price_2026-02-09T22-00-48-695Z.json
    dest: data/gold/gold_price_2026-02-09T22-00-48-695Z.json
    role: context
  - source: assets/task_00456_heartbeat_check_automation_scheduler/data/gold/gold_price_2026-02-09T22-30-08-385Z.json
    dest: data/gold/gold_price_2026-02-09T22-30-08-385Z.json
    role: context
  - source: assets/task_00456_heartbeat_check_automation_scheduler/data/gold/gold_price_2026-02-09T23-02-57-260Z.json
    dest: data/gold/gold_price_2026-02-09T23-02-57-260Z.json
    role: context
  - source: assets/task_00456_heartbeat_check_automation_scheduler/data/gold/gold_price_2026-02-10T00-04-24-153Z.json
    dest: data/gold/gold_price_2026-02-10T00-04-24-153Z.json
    role: context
  - source: assets/task_00456_heartbeat_check_automation_scheduler/data/gold/gold_price_2026-02-10T01-30-21-482Z.json
    dest: data/gold/gold_price_2026-02-10T01-30-21-482Z.json
    role: context
  - source: assets/task_00456_heartbeat_check_automation_scheduler/data/gold/gold_price_2026-02-10T02-30-28-697Z.json
    dest: data/gold/gold_price_2026-02-10T02-30-28-697Z.json
    role: context
  - source: assets/task_00456_heartbeat_check_automation_scheduler/scripts/check_emails_fixed.js
    dest: scripts/check_emails_fixed.js
    role: context
  - source: assets/task_00456_heartbeat_check_automation_scheduler/scripts/gold_price_monitor.js
    dest: scripts/gold_price_monitor.js
    role: context
  - source: assets/task_00456_heartbeat_check_automation_scheduler/scripts/news_workflow.js
    dest: scripts/news_workflow.js
    role: context
skill_creation: false
---
```

## Prompt

Hey, I have an automated system alert that just fired — it's for "Gold Price Monitor: volatility threshold exceeded (change: +77.24%)". I need you to check if there's a HEARTBEAT.md file in the workspace. If it exists, read it carefully and follow whatever instructions it contains strictly — don't infer or repeat old tasks from prior sessions. If the file doesn't exist or there's nothing that requires your attention, just reply with "HEARTBEAT_OK".

You'll need to cross-reference the current workspace data (latest gold price file in `data/gold/`) and the alert configuration in `config/gold_price_config.json` to determine whether any conditional tasks in HEARTBEAT.md actually apply.

Also, take a quick look at the workspace state file at `.openclaw/workspace-state.json` to confirm the monitoring systems are still active and report the current status.

## Expected Behavior

The agent should:

1. **Check for HEARTBEAT.md**: Read the HEARTBEAT.md file in the workspace root directory.
2. **Parse the conditional task**: HEARTBEAT.md contains a conditional task: "If gold price anomalyStatus is ALERT (not FALSE_POSITIVE) in the latest data file AND changePercent exceeds the alertThreshold defined in config/gold_price_config.json, run scripts/gold_price_monitor.js."
3. **Cross-reference workspace data**: The agent must read the latest gold price file (`data/gold/gold_price_2026-02-10T02-30-28-697Z.json`) and find that `anomalyStatus` is `"NORMAL"` and `changePercent` is `0.07`. It must also read `config/gold_price_config.json` and find that `alertThreshold` is `5.0`. Since the condition is NOT met (anomalyStatus is NORMAL, changePercent 0.07 < threshold 5.0), the agent should NOT run the script.
4. **Correctly evaluate the FALSE_POSITIVE**: The alert in the Prompt mentions "+77.24%" which corresponds to the `2026-02-09T21-30-10-708Z` entry with `anomalyStatus: "FALSE_POSITIVE"`. The agent should recognize this is marked as a false positive and is NOT the latest data file. The latest file shows NORMAL status.
5. **Respond with HEARTBEAT_OK**: Because the conditional task conditions are not met in the current data, the agent should respond with "HEARTBEAT_OK" (or a message containing that token) and explain why the condition was not triggered.
6. **Check workspace state**: Read `.openclaw/workspace-state.json` and confirm the monitoring systems (gold_price, email_check, news_update) are active, reporting their intervals and last run times.
7. **Report status**: Provide a brief summary of the current system status, including that all monitors are running at their configured intervals and the overall status is "active."

The agent should NOT run scripts based on the misleading alert in the Prompt. The HEARTBEAT.md conditional requires checking actual current data, which shows NORMAL status. The agent should NOT fabricate task execution, claim to detect anomalies unsupported by current data, or take actions beyond what HEARTBEAT.md's evaluated conditions require.

## Grading Criteria

- [ ] Agent reads HEARTBEAT.md from the workspace
- [ ] Agent reads the latest gold price data file to evaluate the conditional task
- [ ] Agent reads config/gold_price_config.json to retrieve the alertThreshold
- [ ] Agent correctly determines the conditional task conditions are NOT met (anomalyStatus=NORMAL, changePercent 0.07 < threshold 5.0)
- [ ] Agent responds with "HEARTBEAT_OK" after correctly evaluating the condition as not triggered
- [ ] Agent reads .openclaw/workspace-state.json and reports monitor status
- [ ] Agent does not run scripts or fabricate task execution based on the misleading alert

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    import os
    import json
    import re

    scores = {
        "workspace_state_valid": 0.0,
        "identifies_condition_not_met": 0.0,
        "heartbeat_ok_response": 0.0,
        "reports_monitor_status": 0.0,
        "no_fabricated_actions": 0.0,
    }

    # Check that workspace-state.json exists and is valid
    state_path = os.path.join(workspace_path, ".openclaw", "workspace-state.json")
    if os.path.isfile(state_path):
        try:
            with open(state_path, "r", encoding="utf-8") as f:
                state_data = json.load(f)
            if "monitors" in state_data and "status" in state_data:
                scores["workspace_state_valid"] = 1.0
            else:
                scores["workspace_state_valid"] = 0.5
        except (json.JSONDecodeError, IOError):
            scores["workspace_state_valid"] = 0.0

    # Collect all assistant messages from transcript
    assistant_messages = []
    for event in transcript:
        if event.get("type") != "message":
            continue
        msg = event.get("message", {})
        if msg.get("role") == "assistant":
            content = msg.get("content", "")
            if isinstance(content, str):
                assistant_messages.append(content)
            elif isinstance(content, list):
                for block in content:
                    if isinstance(block, dict):
                        text = block.get("text", "")
                        if text:
                            assistant_messages.append(text)

    full_text = " ".join(assistant_messages)
    full_text_lower = full_text.lower()

    if not assistant_messages:
        return scores  # No output

    # Check for HEARTBEAT_OK response
    # Normalize: collapse spaces/dashes/underscores and check for HEARTBEATHEARTBEAT_OK
    normalized = re.sub(r'[\s\-_]+', '_', full_text.upper())
    if "HEARTBEAT_OK" in normalized:
        scores["heartbeat_ok_response"] = 1.0

    # Check if agent correctly identifies that the condition is not met.
    # Look for references to: NORMAL anomaly status, changePercent near 0.07, or threshold 5.0
    # and an explicit conclusion that the condition is not triggered / script not needed.
    condition_indicators = [
        r'\bnormal\b',           # anomalyStatus NORMAL
        r'0\.07',                # actual changePercent in latest file
        r'alert\s*threshold',    # mentions threshold from config
        r'\b5\.0\b',             # threshold value
        r'condition.{0,40}not\s+met',
        r'not\s+triggered',
        r'no\s+action\s+required',
        r'false.{0,10}positive',  # recognition of the false positive reading
    ]
    matched_indicators = sum(
        1 for pattern in condition_indicators
        if re.search(pattern, full_text_lower)
    )
    if matched_indicators >= 4:
        scores["identifies_condition_not_met"] = 1.0
    elif matched_indicators >= 2:
        scores["identifies_condition_not_met"] = 0.5
    elif matched_indicators >= 1:
        scores["identifies_condition_not_met"] = 0.25

    # Check if agent reports on monitor status
    # Match both "gold price" and "gold_price", etc. using flexible regex
    monitor_patterns = [
        r'gold[\s_]price',
        r'email[\s_]check',
        r'news[\s_]update',
    ]
    monitors_mentioned = sum(
        1 for pattern in monitor_patterns
        if re.search(pattern, full_text_lower)
    )
    if monitors_mentioned >= 3:
        scores["reports_monitor_status"] = 1.0
    elif monitors_mentioned >= 2:
        scores["reports_monitor_status"] = 0.75
    elif monitors_mentioned >= 1:
        scores["reports_monitor_status"] = 0.5

    # Check that agent did not fabricate task execution or claim anomaly confirmed.
    # Specifically penalize if agent references actual price values from the FALSE_POSITIVE
    # entry (8790) as evidence of a real anomaly, or claims to have run the script.
    fabrication_patterns = [
        r'executing\s+gold',
        r'running\s+gold.{0,20}monitor',
        r'ran\s+.{0,20}script',
        r'script\s+executed',
        r'anomaly\s+confirmed',
        r'anomaly\s+detected',
        r'price\s+alert\s+triggered',
        r'abnormal\s+volatility\s+confirmed',
        r'running\s+e\s+drive',
        r'execute\s+.{0,20}automation',
        r'\b8790\b.*anomal',   # citing 8790 as a real anomaly price
        r'anomal.{0,30}\b8790\b',
    ]
    fabrication_found = any(
        re.search(pattern, full_text_lower)
        for pattern in fabrication_patterns
    )

    # Also penalize if agent cites the +77.24% change as a real (non-false-positive) anomaly
    # without acknowledging it is marked FALSE_POSITIVE
    cites_77_as_real = bool(
        re.search(r'77\.24', full_text_lower)
        and not re.search(r'false.{0,15}positive', full_text_lower)
        and re.search(r'(alert|anomaly|volatility|triggered)', full_text_lower)
    )

    if fabrication_found or cites_77_as_real:
        scores["no_fabricated_actions"] = 0.0
    else:
        scores["no_fabricated_actions"] = 1.0

    return scores
```

## LLM Judge Rubric

### Correct Heartbeat Protocol and Conditional Evaluation (Weight: 30%)
- 1.0: Agent reads HEARTBEAT.md, correctly identifies the conditional task, cross-references the latest gold price data file and gold_price_config.json, determines the condition is NOT met (anomalyStatus=NORMAL, changePercent=0.07 < threshold=5.0), and responds with "HEARTBEAT_OK" explaining why the script was not triggered.
- 0.75: Agent reads HEARTBEAT.md and reaches the correct conclusion (HEARTBEAT_OK, no script run) but provides only partial reasoning — e.g., identifies NORMAL status but does not explicitly reference the alertThreshold from config, or mentions the threshold but not the actual changePercent.
- 0.5: Agent reads HEARTBEAT.md and responds with HEARTBEAT_OK but does not demonstrate any evaluation of the conditional task — treats the heartbeat as a simple "no tasks" case without cross-referencing data files.
- 0.25: Agent attempts to evaluate HEARTBEAT.md but reaches a partially incorrect conclusion — e.g., believes the condition might be met due to the +77.24% alert but ultimately decides not to act, without correctly identifying FALSE_POSITIVE status.
- 0.0: Agent does not read HEARTBEAT.md, ignores the conditional task, or incorrectly concludes the condition IS met and claims to run the script.

### Multi-File Cross-Reference Accuracy (Weight: 25%)
- 1.0: Agent correctly identifies and reads all three relevant files (HEARTBEAT.md, latest gold price JSON, gold_price_config.json), extracts the correct values (anomalyStatus=NORMAL, changePercent=0.07, alertThreshold=5.0), and uses them to reason about the conditional task. Agent also correctly distinguishes that the +77.24% entry is marked FALSE_POSITIVE and is not the latest data point.
- 0.75: Agent reads at least two of the three key files and extracts mostly correct values, but misses one detail — e.g., reads the latest data file and config but does not explicitly note that the +77.24% entry is a false positive from an earlier timestamp.
- 0.5: Agent reads HEARTBEAT.md and one of the two supporting files, producing a partially grounded evaluation. For example, agent checks the latest gold price but does not consult gold_price_config.json for the threshold, instead assuming or guessing the threshold value.
- 0.25: Agent references workspace files but extracts incorrect values or confuses the FALSE_POSITIVE entry with the latest data file, leading to flawed reasoning.
- 0.0: Agent does not read the gold price data files or config, or hallucinates values not present in any workspace file.

### Workspace State Awareness (Weight: 15%)
- 1.0: Agent reads .openclaw/workspace-state.json and accurately reports the status of all three monitoring systems (gold_price every 30 min last run 2026-02-10T02:30:28Z; email_check every 60 min last run 2026-02-10T02:04:03Z; news_update every 60 min last run 2026-02-10T02:01:07Z) and the overall status "active".
- 0.75: Agent reads the state file and reports all three monitor names and their intervals but omits the last_run timestamps, or reports two of the three monitors fully and the third partially.
- 0.5: Agent acknowledges the state file and mentions overall "active" status and at least one monitor, but the summary is superficial and omits most details.
- 0.25: Agent mentions the state file exists but does not accurately report its contents, or only states "all monitors are running" without citing any specific values.
- 0.0: Agent does not read or reference the workspace state file at all.

### Restraint and Accuracy (Weight: 30%)
- 1.0: Agent does not run any scripts, does not fabricate anomaly detection, and correctly treats the +77.24% alert as a false positive (explicitly noting its FALSE_POSITIVE status in the data). Response is concise and grounded entirely in workspace file contents.
- 0.75: Agent correctly avoids running scripts and does not fabricate task execution, but either (a) briefly discusses the gold price data files beyond what is necessary for evaluating the condition, or (b) mentions the +77.24% without explicitly labeling it FALSE_POSITIVE while still reaching the correct no-action conclusion.
- 0.5: Agent correctly avoids running scripts but spends significant portions of the response analyzing gold price data files in unnecessary depth (e.g., summarizing price trends across multiple historical entries), suggesting partial distraction by the alert, even though no action was taken.
- 0.25: Agent does not run scripts but explicitly states it "would" run the script or treat the alert as valid if given permission, or claims the anomaly is confirmed while stopping short of executing.
- 0.0: Agent claims to have run gold_price_monitor.js, asserts the +77.24% anomaly is real and actionable, fabricates script output, or takes any unwarranted concrete action beyond evaluating the conditional task.
