#!/usr/bin/env node
/**
 * Gmail Email Checker - OAuth2 authenticated inbox monitor
 * Runs every 30 minutes via OpenClaw heartbeat scheduler
 * 
 * Setup: npm install googleapis
 * Credentials: E:\openclaw-gmail-setup\credentials.json
 * Token: E:\openclaw-gmail-setup\token.json
 */

const fs = require('fs');
const path = require('path');
const { google } = require('googleapis');

const CREDENTIALS_PATH = path.join(__dirname, '..', 'gmail-setup', 'credentials.json');
const TOKEN_PATH = path.join(__dirname, '..', 'gmail-setup', 'token.json');
const SCOPES = ['https://www.googleapis.com/auth/gmail.readonly'];

async function checkEmails() {
  const credentials = JSON.parse(fs.readFileSync(CREDENTIALS_PATH, 'utf8'));
  const { client_secret, client_id, redirect_uris } = credentials.installed;
  const oAuth2Client = new google.auth.OAuth2(client_id, client_secret, redirect_uris[0]);

  const token = JSON.parse(fs.readFileSync(TOKEN_PATH, 'utf8'));
  oAuth2Client.setCredentials(token);

  const gmail = google.gmail({ version: 'v1', auth: oAuth2Client });
  
  const res = await gmail.users.messages.list({
    userId: 'me',
    q: 'is:unread',
    maxResults: 10
  });

  const messages = res.data.messages || [];
  const summaries = [];

  for (const msg of messages) {
    const detail = await gmail.users.messages.get({
      userId: 'me',
      id: msg.id,
      format: 'metadata',
      metadataHeaders: ['From', 'Subject', 'Date']
    });

    const headers = detail.data.payload.headers;
    summaries.push({
      id: msg.id,
      from: headers.find(h => h.name === 'From')?.value || 'Unknown',
      subject: headers.find(h => h.name === 'Subject')?.value || '(no subject)',
      date: headers.find(h => h.name === 'Date')?.value || '',
      snippet: detail.data.snippet
    });
  }

  console.log(`Found ${summaries.length} unread emails`);
  return summaries;
}

checkEmails().catch(console.error);
