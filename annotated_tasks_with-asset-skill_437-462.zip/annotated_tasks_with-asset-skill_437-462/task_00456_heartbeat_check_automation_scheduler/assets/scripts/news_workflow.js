#!/usr/bin/env node
/**
 * News Workflow - Fetches and categorizes latest news from multiple sources
 * Runs hourly via OpenClaw heartbeat scheduler
 * 
 * Sources: Reuters, Bloomberg, AP News (via Tavily search)
 * Output: E:\OpenClaw\automation\data\news\news_<timestamp>.json
 */

const fs = require('fs');
const path = require('path');
const https = require('https');

const DATA_DIR = path.join(__dirname, '..', 'data', 'news');
const CATEGORIES = ['Finance', 'Technology', 'World'];
const SOURCES = ['reuters.com', 'bloomberg.com', 'apnews.com'];

async function fetchNews(tavilyApiKey) {
  const allArticles = [];

  for (const category of CATEGORIES) {
    const query = `latest ${category.toLowerCase()} news today`;
    const results = await tavilySearch(tavilyApiKey, query, SOURCES);
    
    for (const result of results) {
      allArticles.push({
        title: result.title,
        url: result.url,
        snippet: result.content?.substring(0, 200),
        source: extractSource(result.url),
        category: category,
        publishedAt: result.published_date || new Date().toISOString()
      });
    }
  }

  const output = {
    timestamp: new Date().toISOString(),
    articleCount: allArticles.length,
    categories: CATEGORIES.reduce((acc, cat) => {
      acc[cat] = allArticles.filter(a => a.category === cat).length;
      return acc;
    }, {}),
    articles: allArticles
  };

  if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
  
  const ts = new Date().toISOString().replace(/[:.]/g, '-');
  const outPath = path.join(DATA_DIR, `news_${ts}.json`);
  fs.writeFileSync(outPath, JSON.stringify(output, null, 2));
  console.log(`Saved ${allArticles.length} articles to ${outPath}`);
  return output;
}

function extractSource(url) {
  try { return new URL(url).hostname.replace('www.', ''); } 
  catch { return 'unknown'; }
}

async function tavilySearch(apiKey, query, domains) {
  // Tavily API call implementation
  return new Promise((resolve, reject) => {
    const postData = JSON.stringify({
      api_key: apiKey,
      query: query,
      include_domains: domains,
      max_results: 5
    });
    // ... HTTP request to api.tavily.com/search
    resolve([]);
  });
}

fetchNews(process.env.TAVILY_API_KEY).catch(console.error);
