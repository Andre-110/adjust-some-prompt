#!/usr/bin/env node
/**
 * Gold Price Monitor - Fetches current gold spot price and checks for anomalies
 * Runs every 30 minutes via OpenClaw heartbeat scheduler
 * 
 * Config: E:\OpenClaw\automation\config\gold_price_config.json
 * Output: E:\OpenClaw\automation\data\gold\gold_price_<timestamp>.json
 */

const fs = require('fs');
const path = require('path');
const https = require('https');

const CONFIG_PATH = path.join(__dirname, '..', 'config', 'gold_price_config.json');
const DATA_DIR = path.join(__dirname, '..', 'data', 'gold');

async function fetchGoldPrice() {
  const config = JSON.parse(fs.readFileSync(CONFIG_PATH, 'utf8'));
  
  // Primary: metals-api.com, Fallback: Tavily search
  const sources = config.sources || ['metals-api', 'tavily'];
  let priceData = null;

  for (const source of sources) {
    try {
      if (source === 'metals-api') {
        priceData = await fetchFromMetalsAPI(config.metalsApiKey);
      } else if (source === 'tavily') {
        priceData = await fetchFromTavily(config.tavilyApiKey);
      }
      if (priceData) break;
    } catch (err) {
      console.error(`Source ${source} failed:`, err.message);
    }
  }

  if (!priceData) {
    throw new Error('All price sources failed');
  }

  // Anomaly detection
  const previousFiles = fs.readdirSync(DATA_DIR)
    .filter(f => f.startsWith('gold_price_'))
    .sort()
    .slice(-2);

  if (previousFiles.length > 0) {
    const lastData = JSON.parse(fs.readFileSync(path.join(DATA_DIR, previousFiles[previousFiles.length - 1])));
    const changePercent = Math.abs((priceData.price - lastData.price) / lastData.price * 100);
    
    priceData.changePercent = changePercent;
    priceData.previousPrice = lastData.price;
    
    if (changePercent > config.alertThreshold) {
      // Filter known false positives from Tavily
      if (source === 'tavily' && changePercent > 50) {
        priceData.anomalyStatus = 'FALSE_POSITIVE';
        priceData.note = 'Tavily parsing error - ignoring';
      } else {
        priceData.anomalyStatus = 'ALERT';
        console.log(`⚠️ ANOMALY DETECTED: ${changePercent.toFixed(2)}% change!`);
      }
    } else {
      priceData.anomalyStatus = 'NORMAL';
    }
  }

  // Save
  const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
  const outPath = path.join(DATA_DIR, `gold_price_${timestamp}.json`);
  fs.writeFileSync(outPath, JSON.stringify(priceData, null, 2));
  console.log(`Saved: ${outPath}`);
  return priceData;
}

fetchGoldPrice().catch(console.error);
