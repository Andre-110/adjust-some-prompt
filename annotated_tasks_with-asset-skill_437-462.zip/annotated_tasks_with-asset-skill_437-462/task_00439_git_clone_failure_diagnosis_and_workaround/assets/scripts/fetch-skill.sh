#!/usr/bin/env bash
# fetch-skill.sh — Download a skill.md from a URL and install it
# Part of the agent bootstrap workflow

set -euo pipefail

URL="${1:?Usage: fetch-skill.sh <url> [output_dir]}"
OUTPUT_DIR="${2:-.}"
FILENAME="$(basename "$URL")"

echo "[$(date '+%Y-%m-%d %H:%M:%S')] Fetching skill from: $URL"

curl -fsSL --connect-timeout 30 --max-time 120 "$URL" -o "$OUTPUT_DIR/$FILENAME"

if [ $? -eq 0 ]; then
    echo "[SUCCESS] Saved to $OUTPUT_DIR/$FILENAME ($(wc -c < "$OUTPUT_DIR/$FILENAME") bytes)"
else
    echo "[ERROR] Failed to download skill from $URL"
    exit 1
fi
