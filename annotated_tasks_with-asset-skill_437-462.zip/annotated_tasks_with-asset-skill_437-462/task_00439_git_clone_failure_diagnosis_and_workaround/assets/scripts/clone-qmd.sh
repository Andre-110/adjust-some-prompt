#!/usr/bin/env bash
# clone-qmd.sh — Clone the qmd repository from GitHub
# Used by the agent orchestrator to fetch tobi/qmd for local builds
#
# Usage: ./clone-qmd.sh [target_dir]

set -euo pipefail

REPO_URL="https://github.com/tobi/qmd.git"
TARGET_DIR="${1:-qmd}"
MAX_RETRIES=5
RETRY_DELAY=10

echo "[$(date '+%Y-%m-%d %H:%M:%S')] Cloning $REPO_URL into $TARGET_DIR ..."

attempt=0
while [ $attempt -lt $MAX_RETRIES ]; do
    attempt=$((attempt + 1))
    echo "[Attempt $attempt/$MAX_RETRIES] git clone $REPO_URL $TARGET_DIR"

    if git clone --depth 1 "$REPO_URL" "$TARGET_DIR" 2>&1; then
        echo "[SUCCESS] Repository cloned to $TARGET_DIR"
        exit 0
    fi

    echo "[WARN] Clone failed. Retrying in ${RETRY_DELAY}s..."
    sleep "$RETRY_DELAY"
done

echo "[ERROR] All $MAX_RETRIES attempts failed. Exiting with code 128."
exit 128
