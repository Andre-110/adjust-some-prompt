# Network & Proxy Environment Variables
# Source this file: source ./env-proxy.sh
# Or add to ~/.bashrc / ~/.zshrc

# === HTTP Proxy (uncomment to activate) ===
# export http_proxy="http://127.0.0.1:7890"
# export https_proxy="http://127.0.0.1:7890"
# export all_proxy="socks5://127.0.0.1:1080"

# === No-proxy list ===
export no_proxy="localhost,127.0.0.1,192.168.0.0/16,10.0.0.0/8,*.local"

# === Git-specific proxy (alternative to .gitconfig) ===
# export GIT_SSL_NO_VERIFY=0
# export GIT_CURL_VERBOSE=1

# === DNS override for GitHub (use with caution) ===
# Manually resolved IPs for github.com (as of 2026-02-09):
#   20.205.243.166
#   20.27.177.113
#   140.82.121.4
# You can add these to /etc/hosts if DNS resolution is the issue:
#   20.205.243.166 github.com
#   20.205.243.166 api.github.com

# === Mirror URLs ===
# export GITHUB_MIRROR="https://ghproxy.com/https://github.com"
# export GITHUB_MIRROR="https://hub.fastgit.xyz"
# export GITHUB_MIRROR="https://gitclone.com/github.com"
