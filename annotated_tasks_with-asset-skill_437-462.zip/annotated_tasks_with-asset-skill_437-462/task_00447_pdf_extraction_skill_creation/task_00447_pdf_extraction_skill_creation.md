---
id: task_00447_pdf_extraction_skill_creation
name: PDF Data Extraction Skill Creation
category: Data Analysis and Modeling
subcategory: Data Processing and Management
difficulty: medium
grading_type: hybrid
grading_weights: {automated: 0.4, llm_judge: 0.6}
timeout_seconds: 600
input_modality: text-only
external_dependency: none
workspace_files:
  - source: assets/task_00447_pdf_extraction_skill_creation/source.pdf
    dest: source.pdf
    content: ""
    note: "A sample PDF file containing a short business report with text paragraphs and a revenue table. Known extractable content includes the company name 'Acme Corp', the phrase 'Q3 Revenue Report', and a table with columns: Region, Revenue, Growth."
  - source: assets/task_00447_pdf_extraction_skill_creation/package.json
    dest: package.json
    content: ""
    note: "Node.js package manifest with pdf-lib dependency"
  - source: assets/task_00447_pdf_extraction_skill_creation/package-lock.json
    dest: package-lock.json
    content: ""
    note: "Node.js lock file for pdf-lib dependency"
skill_creation: true
---

## Prompt

Hey, I have a PDF file (`source.pdf`) in my workspace that I need to extract data from. It's a short business report that includes some text paragraphs and a revenue table.

I'd like you to do two things:

**1. Create a reusable skill file at `skills/pdf-data-extraction/SKILL.md`** that documents a repeatable workflow for extracting text and structured data from PDF documents. The skill file should use YAML frontmatter with `name:` and `description:` fields, and include instruction sections covering at least: which CLI tools to use for text extraction, how to handle PDFs that contain tables, and how to deal with PDFs where text extraction fails. Each tool recommendation should include an actual example command. Create the `skills/pdf-data-extraction/` directory if it does not exist.

**2. Apply the skill to `source.pdf`:**
- Extract all readable text and save it to `extracted_output.txt`
- Parse the revenue table from the report and save it as `extracted_table.csv` with proper column headers

Also initialize a git repository in the workspace root to track everything.

## Expected Behavior

The agent should:

1. **Create `skills/pdf-data-extraction/SKILL.md`** at `skills/pdf-data-extraction/SKILL.md` under the workspace root, with:
   - Valid YAML frontmatter including `name:` and `description:` fields
   - At least three `##`-level sections
   - At least one fenced code block (` ```bash `) containing a concrete command example (e.g., `pdftotext source.pdf output.txt` or a Python snippet using pdfplumber/PyPDF2)
   - Coverage of: CLI-based text extraction, table extraction strategy, and fallback handling for image-based PDFs

2. **Extract text from `source.pdf`** using appropriate tools (e.g., `pdftotext`, Python `pdfplumber`, `PyPDF2`, or `strings` as a last resort). Save to `extracted_output.txt`. The extracted text should contain recognizable content from the PDF — specifically the phrases "Acme Corp", "Q3 Revenue Report", and region names "North", "South", "East", "West".

3. **Extract the revenue table** and save it as `extracted_table.csv`. The CSV must have a header row containing at least the columns `Region`, `Revenue`, and `Growth`, and four data rows corresponding to the four regions in the report.

4. **Initialize a git repository** (`git init`) resulting in a `.git/` directory.

**Traps/Challenges (internal notes, not shown to agent):**
- The workspace contains `package.json` and `package-lock.json` with a `pdf-lib` Node.js dependency. However, `pdf-lib` is primarily for *creating* and *modifying* PDFs, not for extracting text. The agent should recognize this and use more appropriate tools rather than relying on `pdf-lib` for text extraction.
- The agent must produce two separate output files (`extracted_output.txt` and `extracted_table.csv`), each with specific content requirements — not just any non-empty file.

## Grading Criteria

- [ ] `skills/pdf-data-extraction/SKILL.md` exists with proper YAML frontmatter (name and description fields)
- [ ] SKILL.md contains at least 3 section headings and at least 1 fenced code block with a concrete command
- [ ] `extracted_output.txt` exists and contains key phrases from the PDF ("Acme Corp", "Q3 Revenue Report", at least 2 region names)
- [ ] `extracted_table.csv` exists with correct header row (Region, Revenue, Growth) and at least 4 data rows
- [ ] Git repository initialized (.git/HEAD exists)

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    import os
    import re
    from pathlib import Path

    ws = Path(workspace_path)
    scores = {
        "skill_md_exists_and_structured": 0.0,
        "skill_md_content_quality": 0.0,
        "extraction_output_quality": 0.0,
        "extracted_table_quality": 0.0,
        "git_initialized": 0.0,
    }

    # 1. Check SKILL.md structure
    skill_path = ws / "skills" / "pdf-data-extraction" / "SKILL.md"
    if skill_path.exists():
        try:
            content = skill_path.read_text(encoding="utf-8", errors="replace")
            if content.strip():
                has_frontmatter = content.strip().startswith("---")
                has_name = "name:" in content.lower()
                has_description = "description:" in content.lower()
                if has_frontmatter and has_name and has_description:
                    scores["skill_md_exists_and_structured"] = 1.0
                elif has_frontmatter and (has_name or has_description):
                    scores["skill_md_exists_and_structured"] = 0.5
                elif has_frontmatter:
                    scores["skill_md_exists_and_structured"] = 0.25
                else:
                    scores["skill_md_exists_and_structured"] = 0.1
        except Exception:
            scores["skill_md_exists_and_structured"] = 0.0

    # 2. Check SKILL.md structural quality: section headings + code blocks + command examples
    if skill_path.exists():
        try:
            content = skill_path.read_text(encoding="utf-8", errors="replace")
            # Count ## level headings
            section_count = len(re.findall(r'^##\s+\S', content, re.MULTILINE))
            # Count fenced code blocks
            code_block_count = len(re.findall(r'```', content)) // 2
            # Check for at least one concrete tool command
            has_command = bool(re.search(
                r'(pdftotext|pdfplumber|PyPDF2|pypdf|pdf2txt|strings|camelot|tabula)',
                content, re.IGNORECASE
            ))

            quality_score = 0.0
            if section_count >= 3:
                quality_score += 0.4
            elif section_count >= 2:
                quality_score += 0.2
            elif section_count >= 1:
                quality_score += 0.1

            if code_block_count >= 2:
                quality_score += 0.35
            elif code_block_count >= 1:
                quality_score += 0.2

            if has_command:
                quality_score += 0.25

            scores["skill_md_content_quality"] = min(quality_score, 1.0)
        except Exception:
            scores["skill_md_content_quality"] = 0.0

    # 3. Check extracted_output.txt for known PDF content
    output_path = ws / "extracted_output.txt"
    if output_path.exists():
        try:
            content = output_path.read_text(encoding="utf-8", errors="replace").lower()
            known_keywords = ["acme corp", "q3 revenue report", "north", "south", "east", "west"]
            matched = sum(1 for kw in known_keywords if kw in content)
            if matched >= 5:
                scores["extraction_output_quality"] = 1.0
            elif matched >= 3:
                scores["extraction_output_quality"] = 0.6
            elif matched >= 1:
                scores["extraction_output_quality"] = 0.3
            elif len(content.strip()) > 0:
                # Non-empty but no recognizable content (e.g., error message or garbage)
                scores["extraction_output_quality"] = 0.1
            else:
                scores["extraction_output_quality"] = 0.0
        except Exception:
            scores["extraction_output_quality"] = 0.0

    # 4. Check extracted_table.csv for correct structure
    table_path = ws / "extracted_table.csv"
    if table_path.exists():
        try:
            content = table_path.read_text(encoding="utf-8", errors="replace")
            lines = [l.strip() for l in content.strip().splitlines() if l.strip()]
            if lines:
                header = lines[0].lower()
                has_region = "region" in header
                has_revenue = "revenue" in header
                has_growth = "growth" in header
                data_rows = lines[1:]
                row_count = len(data_rows)

                table_score = 0.0
                if has_region and has_revenue and has_growth:
                    table_score += 0.5
                elif (has_region and has_revenue) or (has_revenue and has_growth):
                    table_score += 0.25

                if row_count >= 4:
                    table_score += 0.5
                elif row_count >= 2:
                    table_score += 0.25
                elif row_count >= 1:
                    table_score += 0.1

                scores["extracted_table_quality"] = min(table_score, 1.0)
            else:
                scores["extracted_table_quality"] = 0.0
        except Exception:
            scores["extracted_table_quality"] = 0.0

    # 5. Check git initialized
    git_head = ws / ".git" / "HEAD"
    if git_head.exists():
        try:
            head_content = git_head.read_text(encoding="utf-8", errors="replace")
            if "ref:" in head_content or len(head_content.strip()) == 40:
                scores["git_initialized"] = 1.0
            else:
                scores["git_initialized"] = 0.5
        except Exception:
            scores["git_initialized"] = 0.3
    elif (ws / ".git").is_dir():
        scores["git_initialized"] = 0.5

    return scores
```

## LLM Judge Rubric

### Skill Design Quality (Weight: 30%)
Evaluates whether `skills/pdf-data-extraction/SKILL.md` is well-structured, reusable, and documents a genuinely useful workflow with concrete guidance.
- **1.0**: SKILL.md has valid YAML frontmatter with both `name:` and `description:` fields; contains at least 3 `##`-level sections covering text extraction, table handling, and fallback/image-based PDF strategy; includes at least 2 fenced code blocks with real command examples (e.g., `pdftotext source.pdf out.txt`, a Python pdfplumber snippet, or equivalent); reads like a professional reusable reference document rather than a generic stub.
- **0.75**: SKILL.md has frontmatter and at least 2 sections with at least 1 code block, but is missing one major area (e.g., no table extraction strategy or no fallback handling) or code examples are present but incomplete/non-functional.
- **0.5**: SKILL.md has frontmatter and basic structure (at least 1 section, 1 code block) but covers only one aspect of PDF processing, or has multiple sections with no concrete command examples.
- **0.25**: SKILL.md exists with frontmatter but reads as a placeholder — minimal prose, no code examples, fewer than 2 sections.
- **0.0**: SKILL.md is missing, empty, lacks frontmatter entirely, or contains no PDF-related content.

### Text Extraction Quality (Weight: 25%)
Evaluates whether `extracted_output.txt` contains real, recognizable text extracted from `source.pdf`.
- **1.0**: `extracted_output.txt` contains clearly recognizable content from the PDF including "Acme Corp", "Q3 Revenue Report", and at least 3 of the 4 region names (North, South, East, West). Agent demonstrably used an appropriate extraction tool (not `pdf-lib`) and the content is human-readable prose, not binary garbage.
- **0.75**: File contains at least 2 of the known keywords and is mostly readable, but may be missing some content or have minor formatting issues.
- **0.5**: File contains at least 1 known keyword or clearly attempted extraction (readable partial content) but is missing most expected text.
- **0.25**: File exists and is non-empty but contains only an error message, binary garbage, or content with no match to the known PDF text — indicating the extraction tool failed and the agent did not recover or try alternatives.
- **0.0**: `extracted_output.txt` does not exist or is empty.

### Table Extraction and CSV Output (Weight: 25%)
Evaluates whether `extracted_table.csv` correctly captures the revenue table from `source.pdf`.
- **1.0**: `extracted_table.csv` has a header row containing `Region`, `Revenue`, and `Growth` columns (case-insensitive), plus exactly 4 data rows corresponding to North, South, East, West with plausible numeric values. CSV is well-formed and parseable.
- **0.75**: CSV has correct headers and at least 3 data rows, or has all 4 rows but is missing one header column. Values are plausible.
- **0.5**: CSV exists with at least 2 correct header columns and at least 2 data rows, but is incomplete or has formatting issues.
- **0.25**: CSV exists with a header row and at least 1 data row, but is largely incorrect, missing key columns, or has only 1 row of data.
- **0.0**: `extracted_table.csv` does not exist, is empty, or has no recognizable tabular structure.

### Tool Selection and Problem-Solving (Weight: 20%)
Evaluates whether the agent made appropriate tool choices, recognized the limitations of `pdf-lib`, and handled obstacles without giving up.
- **1.0**: Agent explicitly recognized that `pdf-lib` (present in `package.json`) is not suitable for text extraction and chose an appropriate alternative (e.g., `pdftotext`, `pdfplumber`, `PyPDF2`). If a first tool failed, the agent tried alternatives rather than stopping. Both output files reflect a real extraction attempt with a suitable tool.
- **0.75**: Agent used an appropriate extraction tool. May not have explicitly acknowledged `pdf-lib`'s limitation but did not attempt to use it. Minor tool selection issues (e.g., used `strings` as only approach without trying proper PDF tools).
- **0.5**: Agent used a reasonable tool but made no attempt to try alternatives when the first approach failed, resulting in incomplete outputs. Or agent made one passing reference to `pdf-lib` being unsuitable but provided no evidence of trying a better tool.
- **0.25**: Agent attempted to use `pdf-lib` for text extraction without recognizing its limitations, or produced output files that are clearly not derived from any real extraction attempt.
- **0.0**: No extraction tool was used at all. Agent generated fabricated content for the output files without running any command, or skipped the extraction task entirely.
