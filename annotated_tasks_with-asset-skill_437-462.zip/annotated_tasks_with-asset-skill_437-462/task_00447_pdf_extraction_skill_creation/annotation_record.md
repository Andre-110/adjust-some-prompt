| 序号 | 修改项 | 修改原因 |
|------|--------|----------|
| 1 | 将 Prompt 中的 `sample.pdf` 改为 `source.pdf` | Prompt 引用了 `sample.pdf`，但 Assets 目录中实际提供的文件名是 `source.pdf`，两者不一致 |
| 2 | 将 Expected Behavior 中的 `sample.pdf` 改为 `source.pdf` | 与 Assets 实际文件名保持一致 |
| 3 | 将 `workspace_files` 中的 `sample.pdf` 改为 `source.pdf`，并补充其他实际存在的文件 | YAML frontmatter 中 workspace_files 仅列出了一个不存在的 `sample.pdf`，未列出实际存在的 `package.json`、`package-lock.json`、`source.pdf` |
| 4 | 替换 `source.pdf` 为一个合法的、含有可提取文本的 PDF 文件 | 当前 `source.pdf` 内容为 `sh: 1: sudo: not found`，这不是一个合法的 PDF 文件，无法被任何 PDF 工具解析。作为 PDF 数据提取任务，必须提供一个真实可用的 PDF |
| 5 | 移除 Grading Criteria 第 5 条"至少创建一个额外文档文件" | 创建 AGENTS.md、BOOTSTRAP.md 等额外文档与 PDF 提取技能创建任务无关，不应作为评分标准。这是对特定 Agent 框架行为的考核，而非任务本身 |
| 6 | 移除 grade() 函数中 `additional_docs_created` 评分项 | 与上条修改一致，额外文档创建不应作为自动化评分依据 |
| 7 | 调整 LLM Judge Rubric "Workspace Organization and Git Setup" 维度，移除额外文档要求 | 该维度过度关注与任务无关的额外文档文件创建 |
| 8 | 更新 Expected Behavior 中关于数据值的描述，使之与新的合法 PDF 内容一致 | 确保 Expected Behavior 与实际 Assets 文件内容匹配 |
| 9 | 修正 SKILL.md 路径说明，明确放置在 workspace 根目录 | Prompt 中说"create a reusable OpenClaw skill"并提到类似 `token-management` 的 skill，但未指定 skill 路径规范（`workspace/skills/<skill名>/SKILL.md`）。由于 Prompt 明确说"create a SKILL.md file"且 Expected Behavior 说"in the workspace root"，保持根目录即可，但需要在 Prompt 中明确 |
| 10 | 调整 difficulty 从 hard 改为 medium | 任务实质是创建一个 Markdown 文档 + 运行一个 CLI 命令提取文本 + git init，这属于中等难度，不够 hard 级别 |
| 11 | 规范 SKILL 路径为 `skills/pdf-data-extraction/SKILL.md`（workspace 根下），同步 Prompt / Expected / Grading / `grade()`；`grade()` 保留根目录 `SKILL.md` 仅作兼容 | 符合 `instruction.md` 维度 A：OpenClaw 技能应在 `skills/<skill名>/SKILL.md`；避免以 workspace 根裸 `SKILL.md` 为唯一规范位置。 |