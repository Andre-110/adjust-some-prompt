// Gold Price Monitor - Fetches current gold price and detects anomalies
// Run: node gold_price_monitor.js
// Schedule: Every 30 minutes via OpenClaw heartbeat

const fs = require('fs');
const path = require('path');
const https = require('https');

const CONFIG_PATH = path.join(__dirname, '..', 'config', 'gold_price_config.json');
const DATA_DIR = path.join(__dirname, '..', 'data', 'gold');

const config = JSON.parse(fs.readFileSync(CONFIG_PATH, 'utf8'));

async function fetchGoldPrice() {
  const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
  const results = { timestamp, sources: {}, consensus_price: null, alert: false };

  // Attempt Tavily API source
  try {
    const tavilyResult = await fetchFromTavily();
    results.sources.tavily = tavilyResult;
  } catch (err) {
    results.sources.tavily = { error: err.message };
  }

  // Calculate consensus from valid sources
  const validPrices = Object.values(results.sources)
    .filter(s => s.price && !s.error)
    .map(s => s.price);

  if (validPrices.length > 0) {
    results.consensus_price = validPrices.reduce((a, b) => a + b) / validPrices.length;
  }

  // Check against previous reading for anomaly detection
  const previousData = getLatestDataFile();
  if (previousData && results.consensus_price) {
    const pctChange = Math.abs(
      (results.consensus_price - previousData.consensus_price) / previousData.consensus_price * 100
    );
    results.change_percent = pctChange;
    results.previous_price = previousData.consensus_price;

    if (pctChange > config.monitoring.alert_threshold_percent) {
      results.alert = true;
      results.alert_message = `Gold price anomaly detected: ${pctChange.toFixed(2)}% change in 30 minutes`;
    }
  }

  // Save data
  const filename = `gold_price_${timestamp}.json`;
  fs.writeFileSync(path.join(DATA_DIR, filename), JSON.stringify(results, null, 2));
  console.log(`Saved: ${filename} | Price: $${results.consensus_price?.toFixed(2)} | Alert: ${results.alert}`);

  return results;
}

function getLatestDataFile() {
  try {
    const files = fs.readdirSync(DATA_DIR)
      .filter(f => f.startsWith('gold_price_') && f.endsWith('.json'))
      .sort()
      .reverse();
    if (files.length > 0) {
      return JSON.parse(fs.readFileSync(path.join(DATA_DIR, files[0]), 'utf8'));
    }
  } catch (e) {
    return null;
  }
  return null;
}

async function fetchFromTavily() {
  // Tavily API integration
  const apiKey = process.env.TAVILY_API_KEY;
  if (!apiKey) throw new Error('TAVILY_API_KEY not set');

  return new Promise((resolve, reject) => {
    const data = JSON.stringify({
      query: 'current gold price per ounce USD',
      search_depth: 'basic',
      include_answer: true
    });

    const options = {
      hostname: 'api.tavily.com',
      path: '/search',
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Content-Length': data.length }
    };

    const req = https.request(options, (res) => {
      let body = '';
      res.on('data', chunk => body += chunk);
      res.on('end', () => {
        try {
          const result = JSON.parse(body);
          const priceMatch = result.answer?.match(/\$?([\d,]+\.?\d*)/);
          if (priceMatch) {
            resolve({ price: parseFloat(priceMatch[1].replace(',', '')), raw_answer: result.answer });
          } else {
            reject(new Error('Could not parse price from Tavily response'));
          }
        } catch (e) {
          reject(e);
        }
      });
    });
    req.on('error', reject);
    req.write(data);
    req.end();
  });
}

if (require.main === module) {
  fetchGoldPrice().catch(console.error);
}

module.exports = { fetchGoldPrice };
