// News Workflow - Fetches and categorizes news from multiple sources
// Run: node news_workflow.js
// Schedule: Every 60 minutes via OpenClaw heartbeat

const fs = require('fs');
const path = require('path');
const https = require('https');

const DATA_DIR = path.join(__dirname, '..', 'data', 'news');

const NEWS_CATEGORIES = ['technology', 'finance', 'world', 'science', 'business'];
const SOURCES = [
  { name: 'tavily', type: 'api' },
  { name: 'google_news', type: 'browser' },
  { name: 'reuters', type: 'browser' }
];

async function fetchNews() {
  const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
  const results = {
    timestamp,
    articles: [],
    categories: {},
    summary: ''
  };

  for (const source of SOURCES) {
    try {
      const articles = await fetchFromSource(source);
      results.articles.push(...articles);
    } catch (err) {
      console.error(`Failed to fetch from ${source.name}: ${err.message}`);
    }
  }

  // Categorize articles
  for (const category of NEWS_CATEGORIES) {
    results.categories[category] = results.articles.filter(a =>
      a.category === category || (a.tags && a.tags.includes(category))
    );
  }

  // Save
  const filename = `news_${timestamp}.json`;
  fs.writeFileSync(path.join(DATA_DIR, filename), JSON.stringify(results, null, 2));
  console.log(`Saved: ${filename} | Articles: ${results.articles.length}`);

  return results;
}

async function fetchFromSource(source) {
  if (source.type === 'api') {
    return fetchFromTavily();
  }
  // Browser sources handled by OpenClaw browser automation
  return [];
}

async function fetchFromTavily() {
  const apiKey = process.env.TAVILY_API_KEY;
  if (!apiKey) return [];

  return new Promise((resolve, reject) => {
    const data = JSON.stringify({
      query: 'latest breaking news today',
      search_depth: 'basic',
      max_results: 10
    });

    const options = {
      hostname: 'api.tavily.com',
      path: '/search',
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Content-Length': data.length }
    };

    const req = https.request(options, (res) => {
      let body = '';
      res.on('data', chunk => body += chunk);
      res.on('end', () => {
        try {
          const result = JSON.parse(body);
          const articles = (result.results || []).map(r => ({
            title: r.title,
            url: r.url,
            snippet: r.content?.substring(0, 200),
            source: 'tavily',
            category: 'uncategorized',
            tags: []
          }));
          resolve(articles);
        } catch (e) {
          reject(e);
        }
      });
    });
    req.on('error', reject);
    req.write(data);
    req.end();
  });
}

if (require.main === module) {
  fetchNews().catch(console.error);
}

module.exports = { fetchNews };
