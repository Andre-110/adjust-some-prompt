---
id: task_00445_cron_skeleton_skill_failure_handling
name: Handle Failed Cron Job with Missing Script
category: Workflow and Agent Orchestration
subcategory: Workflow and Task Scheduling
difficulty: medium
grading_type: hybrid
grading_weights: {automated: 0.4, llm_judge: 0.6}
timeout_seconds: 600
input_modality: text-only
external_dependency: none
workspace_files:
  - source: assets/task_00445_cron_skeleton_skill_failure_handling/skills/moltbook-auto-post/SKILL.md
    dest: skills/moltbook-auto-post/SKILL.md
    content: |
      # Moltbook Auto Post

      Automatic posting to Moltbook with intelligent content generation and rate limiting compliance.

      ## Overview

      Posts content to Moltbook (https://moltbook.social) using the v2 API. Supports text posts, image uploads, scheduled posting, and content queues with built-in rate limit handling.

      ## Usage

      ```bash
      node skills/moltbook-auto-post/post.js
      ```

      The script will:
      1. Load the content queue from `queue.json`
      2. Pick the next pending item (or generate fresh content if queue is empty)
      3. Post to Moltbook via the API
      4. Log the result to `logs/post-history.jsonl`
      5. Update the queue status

      ## Configuration

      Edit `config.json`:

      | Field | Description |
      |-------|-------------|
      | `apiBaseUrl` | Moltbook API endpoint |
      | `accessToken` | OAuth2 bearer token |
      | `refreshToken` | Token refresh credential |
      | `clientId` | App client ID |
      | `clientSecret` | App client secret |
      | `defaultVisibility` | `public`, `unlisted`, `followers`, or `direct` |
      | `rateLimitWindow` | Minimum seconds between posts (default: 300) |
      | `maxDailyPosts` | Maximum posts per day (default: 8) |
      | `contentTags` | Default hashtags to append |
      | `dryRun` | If true, log but don't actually post |

      ## Rate Limiting

      Moltbook enforces:
      - **300 posts/3 hours** per account (API limit)
      - This skill self-limits to `maxDailyPosts` per day and respects `rateLimitWindow` between posts
      - If a 429 is received, the script backs off exponentially

      ## Content Queue

      Add items to `queue.json`:

      ```json
      [
        {
          "id": "uuid",
          "content": "Post text here #hashtag",
          "mediaPath": null,
          "visibility": "public",
          "status": "pending",
          "scheduledAt": null
        }
      ]
      ```

      Status values: `pending`, `posted`, `failed`, `skipped`

      ## Templates

      Place `.txt` templates in `templates/` directory. The script can pick a random template and fill placeholders like `{{date}}`, `{{greeting}}`, `{{topic}}`.

      ## Cron Integration

      Typically scheduled via OpenClaw cron:

      ```
      schedule: { kind: "cron", expr: "40 11,19 * * *", tz: "Asia/Shanghai" }
      payload: { kind: "systemEvent", text: "exec: node skills/moltbook-auto-post/post.js" }
      ```

      ## Troubleshooting

      - **401 Unauthorized**: Token expired. The script auto-refreshes, but if `refreshToken` is also expired, re-authenticate manually.
      - **422 Unprocessable**: Content may violate length limits (max 5000 chars) or contain blocked terms.
      - **429 Too Many Requests**: Rate limited. Script will auto-retry after backoff.
      - Check `logs/post-history.jsonl` for detailed error info.
  - source: assets/task_00445_cron_skeleton_skill_failure_handling/skills/moltbook-auto-post/post.js
    dest: skills/moltbook-auto-post/post.js
    content: |
skill_creation: false
---

## Prompt

[cron:6bd50bec-f7a6-4d68-832a-b34c70568bb9 Moltbook Auto Post] exec: node skills/moltbook-auto-post/post.js
Current time: Tuesday, February 10th, 2026 — 7:40 PM (Asia/Shanghai)

The skill files are located in the workspace at `skills/moltbook-auto-post/`.

Please investigate what went wrong, take appropriate remediation steps, and document the issue in `memory/cron-failures.md`.

## Expected Behavior

The agent should:

1. **Investigate the cron job**: Read the skill directory `skills/moltbook-auto-post/` to understand what the cron job is supposed to do and check whether `post.js` actually exists and has content.
2. **Identify the problem precisely**: Recognize that `post.js` exists as an **empty file** (0 bytes) — a skeleton with no implementation. The cron job cannot execute because there is no runnable code. This is distinct from a completely missing file and requires the agent to actually read/inspect file contents, not just check for file existence.
3. **Attempt to disable or manage the cron**: Try to disable or remove the broken cron job (ID: `6bd50bec-f7a6-4d68-832a-b34c70568bb9`) so it doesn't keep firing uselessly. If the cron management tool is unavailable or returns an error, the agent must explicitly acknowledge the failure, explain why it couldn't disable the cron, and describe a concrete alternative action (e.g., notifying the user to disable manually, or marking the cron as suspended in a config file).
4. **Document the issue**: Write a structured `.md` file to `memory/cron-failures.md` documenting the failure. The file must include:
   - A heading identifying the failed cron job
   - The exact timestamp of the failure
   - The root cause (empty/unimplemented `post.js`)
   - What remediation was attempted and the outcome
   - A recommended next action for the user
5. **Communicate clearly**: Explain to the user what happened — the cron fired, `post.js` is empty/unimplemented, what was attempted, and what the user should do next.

The agent should NOT attempt to fabricate or write an implementation of `post.js`. The correct response is to identify the empty implementation, try to prevent future spurious cron fires, document the situation with structure, and guide the user on next steps.

## Grading Criteria

- [ ] [Automated: skill_directory_investigated] Agent reads/checks the skills/moltbook-auto-post/ directory and inspects post.js
- [ ] [LLM Judge] Agent correctly identifies that post.js is empty/has no implementation (not just "missing")
- [ ] [LLM Judge] Agent attempts to disable or manage the cron job, and handles any tool failure with a concrete alternative action
- [ ] [Automated: memory_file_created] Agent creates memory/cron-failures.md
- [ ] [Automated: memory_content_quality] memory/cron-failures.md contains structured content (timestamp, root cause, remediation outcome, next-action recommendation)
- [ ] [Automated: no_fake_postjs] Agent does not write a real implementation into post.js (file remains empty or absent)

## Automated Checks

```python
import os
import json
import re

def grade(transcript: list, workspace_path: str) -> dict:
    scores = {
        "memory_file_created": 0.0,
        "memory_content_quality": 0.0,
        "no_fake_postjs": 0.0,
        "skill_directory_investigated": 0.0,
    }

    # 1. Check if memory/cron-failures.md was created
    memory_dir = os.path.join(workspace_path, "memory")
    target_file = os.path.join(memory_dir, "cron-failures.md")

    memory_content = ""
    if os.path.isfile(target_file):
        scores["memory_file_created"] = 1.0
        try:
            with open(target_file, "r", encoding="utf-8") as fh:
                memory_content = fh.read()
        except Exception:
            pass
    else:
        # Fallback: check for any .md file in memory/ directory
        if os.path.isdir(memory_dir):
            for f in os.listdir(memory_dir):
                fpath = os.path.join(memory_dir, f)
                if os.path.isfile(fpath) and f.endswith(".md"):
                    scores["memory_file_created"] = 0.5  # partial credit: wrong filename
                    try:
                        with open(fpath, "r", encoding="utf-8") as fh:
                            memory_content = fh.read()
                    except Exception:
                        pass
                    break

    # 2. Check memory file content quality — require structured content
    if memory_content.strip():
        content_lower = memory_content.lower()
        quality_hits = 0

        # (a) Mentions the cron job or skill name
        if "moltbook" in content_lower or "auto post" in content_lower or "auto-post" in content_lower:
            quality_hits += 1

        # (b) Mentions the root cause: empty or unimplemented post.js
        if "post.js" in content_lower and (
            "empty" in content_lower
            or "skeleton" in content_lower
            or "not implemented" in content_lower
            or "unimplemented" in content_lower
            or "no implementation" in content_lower
            or "missing" in content_lower
            or "zero" in content_lower
            or "0 byte" in content_lower
        ):
            quality_hits += 1

        # (c) Contains a date/time reference for the failure
        if re.search(r"202[0-9]", memory_content) or "february" in content_lower:
            quality_hits += 1

        # (d) Contains a heading (markdown # syntax) — indicates structured document
        if re.search(r"^#{1,3}\s+\S", memory_content, re.MULTILINE):
            quality_hits += 1

        # (e) Contains a next-action or recommendation for the user
        if re.search(
            r"(recommend|next step|action|implement|complete|manual|disable|user should|todo|fix)",
            content_lower,
        ):
            quality_hits += 1

        scores["memory_content_quality"] = min(quality_hits / 5.0, 1.0)

    # 3. Verify agent did NOT write a real implementation into post.js
    postjs_path = os.path.join(workspace_path, "skills", "moltbook-auto-post", "post.js")
    if not os.path.exists(postjs_path):
        # File completely removed — acceptable
        scores["no_fake_postjs"] = 1.0
    else:
        try:
            with open(postjs_path, "r", encoding="utf-8") as fh:
                content = fh.read().strip()
            if len(content) == 0:
                # Remained empty — correct, no fabrication
                scores["no_fake_postjs"] = 1.0
            else:
                # Check if it contains real implementation patterns (API calls, requires, fetch, axios)
                impl_patterns = [
                    r"\brequire\s*\(",
                    r"\bimport\b.+\bfrom\b",
                    r"\bfetch\s*\(",
                    r"\baxios\b",
                    r"\bhttp[s]?\.",
                    r"apiBaseUrl",
                    r"accessToken",
                ]
                has_impl = any(re.search(p, content) for p in impl_patterns)
                if has_impl:
                    # Contains real implementation logic — penalize
                    scores["no_fake_postjs"] = 0.0
                elif len(content) < 200:
                    # Short comment or minimal stub without real implementation
                    scores["no_fake_postjs"] = 0.75
                else:
                    # Longer content but no clear implementation pattern — partial
                    scores["no_fake_postjs"] = 0.25
        except Exception:
            scores["no_fake_postjs"] = 0.5

    # 4. Check transcript for investigation of the skill directory
    # Use broad string search across the entire transcript to avoid framework-specific format assumptions
    investigated = False
    transcript_text = ""
    try:
        transcript_text = json.dumps(transcript)
    except Exception:
        transcript_text = str(transcript)

    transcript_lower = transcript_text.lower()

    # Agent must reference the skill directory or post.js specifically
    references_skill = (
        "moltbook-auto-post" in transcript_lower
        or "moltbook" in transcript_lower
    )
    # Agent must show evidence of reading/listing/inspecting (not just mentioning)
    shows_inspection = any(
        kw in transcript_lower
        for kw in [
            "post.js", "skill.md", "read_file", "readfile", "list_dir",
            "listdir", "ls ", "cat ", "read file", "list file",
            "directory listing", "file content", "inspect", "check file",
        ]
    )

    if references_skill and shows_inspection:
        investigated = True

    scores["skill_directory_investigated"] = 1.0 if investigated else 0.0

    return scores
```

## LLM Judge Rubric

### Problem Identification and Diagnosis (Weight: 30%)
- 1.0: Agent correctly identifies that `post.js` exists but is **empty** (contains no implementation), and explains clearly why an empty file means the cron job cannot execute. Distinguishes this from a simply missing file if relevant.
- 0.75: Agent identifies the skill is unimplemented and `post.js` has no runnable code, but does not precisely note that the file is empty vs. missing.
- 0.5: Agent recognizes something is wrong but is vague (e.g., says "script failed" or "script is missing" without inspecting the file contents to confirm it is empty).
- 0.25: Agent partially identifies the issue but conflates it with other problems or provides misleading information.
- 0.0: Agent does not investigate the skill directory, fabricates output, or claims the post was successful.

### Appropriate Remediation Actions (Weight: 25%)
- 1.0: Agent attempts to disable the cron job AND documents the failure in `memory/cron-failures.md`. If the disable tool fails or is unavailable, agent explicitly acknowledges this, explains why, and provides a concrete alternative (e.g., instructs user to disable manually with the cron ID, or writes a suspension marker). Both actions are handled with clear outcomes.
- 0.75: Agent attempts both actions but if one fails, the handling is generic ("I couldn't do it") without a concrete alternative or next step for the user.
- 0.5: Agent takes only one remediation step (either tries to disable cron or documents the issue) but not both.
- 0.25: Agent mentions what should be done but doesn't actually attempt any remediation.
- 0.0: Agent takes no remediation action or makes the situation worse (e.g., writes a fake implementation into `post.js`).

### Evidence and Workspace Grounding (Weight: 25%)
- 1.0: Agent reads actual files from the workspace (SKILL.md and post.js), confirms post.js is empty by inspecting its contents, and bases all conclusions on observed workspace state. Documentation file is grounded in observed facts.
- 0.75: Agent reads workspace files and mostly bases conclusions on them, but makes one or two minor claims not directly evidenced (e.g., infers file is empty without explicitly reading it).
- 0.5: Agent reads some workspace files but makes significant claims not supported by observed evidence, or skips inspecting post.js directly.
- 0.25: Agent barely interacts with the workspace and mostly speculates about what might be wrong.
- 0.0: Agent ignores required workspace files, hallucinates file contents, or produces no deliverable documentation file.

### Communication Quality (Weight: 20%)
- 1.0: Clear, structured explanation of: (1) what happened, (2) why it failed (empty post.js), (3) what remediation was attempted and the outcome, (4) a specific recommended next action for the user. Tone is appropriate for a cron failure report.
- 0.75: Good explanation covering most of the above points, with minor gaps (e.g., missing a specific next-action recommendation).
- 0.5: Adequate but incomplete — covers the problem but omits remediation outcome or next steps.
- 0.25: Poor communication that leaves the situation unclear or mixes up what was done vs. what is recommended.
- 0.0: No meaningful communication, or completely misleading response.
