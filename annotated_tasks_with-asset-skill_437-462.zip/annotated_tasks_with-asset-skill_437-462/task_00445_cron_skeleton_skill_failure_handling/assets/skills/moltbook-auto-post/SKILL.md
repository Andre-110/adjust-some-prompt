# Moltbook Auto Post

Automatic posting to Moltbook with intelligent content generation and rate limiting compliance.

## Overview

Posts content to Moltbook (https://moltbook.social) using the v2 API. Supports text posts, image uploads, scheduled posting, and content queues with built-in rate limit handling.

## Usage

```bash
node skills/moltbook-auto-post/post.js
```

The script will:
1. Load the content queue from `queue.json`
2. Pick the next pending item (or generate fresh content if queue is empty)
3. Post to Moltbook via the API
4. Log the result to `logs/post-history.jsonl`
5. Update the queue status

## Configuration

Edit `config.json`:

| Field | Description |
|-------|-------------|
| `apiBaseUrl` | Moltbook API endpoint |
| `accessToken` | OAuth2 bearer token |
| `refreshToken` | Token refresh credential |
| `clientId` | App client ID |
| `clientSecret` | App client secret |
| `defaultVisibility` | `public`, `unlisted`, `followers`, or `direct` |
| `rateLimitWindow` | Minimum seconds between posts (default: 300) |
| `maxDailyPosts` | Maximum posts per day (default: 8) |
| `contentTags` | Default hashtags to append |
| `dryRun` | If true, log but don't actually post |

## Rate Limiting

Moltbook enforces:
- **300 posts/3 hours** per account (API limit)
- This skill self-limits to `maxDailyPosts` per day and respects `rateLimitWindow` between posts
- If a 429 is received, the script backs off exponentially

## Content Queue

Add items to `queue.json`:

```json
[
  {
    "id": "uuid",
    "content": "Post text here #hashtag",
    "mediaPath": null,
    "visibility": "public",
    "status": "pending",
    "scheduledAt": null
  }
]
```

Status values: `pending`, `posted`, `failed`, `skipped`

## Templates

Place `.txt` templates in `templates/` directory. The script can pick a random template and fill placeholders like `{{date}}`, `{{greeting}}`, `{{topic}}`.

## Cron Integration

Typically scheduled via OpenClaw cron:

```
schedule: { kind: "cron", expr: "40 11,19 * * *", tz: "Asia/Shanghai" }
payload: { kind: "systemEvent", text: "exec: node skills/moltbook-auto-post/post.js" }
```

## Troubleshooting

- **401 Unauthorized**: Token expired. The script auto-refreshes, but if `refreshToken` is also expired, re-authenticate manually.
- **422 Unprocessable**: Content may violate length limits (max 5000 chars) or contain blocked terms.
- **429 Too Many Requests**: Rate limited. Script will auto-retry after backoff.
- Check `logs/post-history.jsonl` for detailed error info.
