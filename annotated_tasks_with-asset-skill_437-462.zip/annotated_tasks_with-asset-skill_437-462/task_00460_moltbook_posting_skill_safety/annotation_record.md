| 序号 | 修改项 | 修改原因 |
|------|--------|----------|
| 1 | Prompt中增加SKILL.md的输出路径说明 | 原Prompt未明确SKILL.md应放在何处，可能导致Agent将其放在`workspace/skills/<skill名>/SKILL.md`路径下而与grade()函数检查workspace根目录不一致 |
| 2 | Expected Behavior中补充对Assets目录中额外文件的说明 | workspace_files（YAML frontmatter中）只列出了2个文件，但Assets目录实际包含moltbook_config.json、wordlists/、templates/等更多文件，Expected Behavior应提及Agent可能会发现并分析这些额外文件 |
| 3 | workspace_files中的moltbook_post_dynamic.sh内容替换为Assets中的完整版本 | YAML frontmatter中嵌入的moltbook_post_dynamic.sh是简化版（约30行），而Assets目录中的是完整版（约200行），两者内容差异巨大，会导致题目不一致 |
| 4 | workspace_files中补充moltbook_config.json | Assets目录有此文件但workspace_files中未列出；且Assets中的配置文件名为moltbook_config.json而非posting_config.json，需要统一 |
| 5 | 统一配置文件名为posting_config.json | Assets中的moltbook_config.json与Prompt及workspace_files中的posting_config.json名称不一致，需统一为posting_config.json |
| 6 | 补充workspace_files中的wordlists和templates文件 | Assets目录中包含wordlists/*.txt和templates/post_templates.txt，这些是脚本运行依赖的文件，应在workspace_files中列出 |
| 7 | posting_config.json内容与Assets中moltbook_config.json的内容统一 | workspace_files中的posting_config.json是简化版，Assets中的moltbook_config.json内容更丰富（含post_settings、content_generation、logging等），需统一 |
| 8 | grade()函数中增加SKILL.md在子目录中的备选路径检查 | Agent可能将SKILL.md放在skills子目录下，grade()应能处理这种情况 |
| 9 | grade()函数中修复review_report相关检查的缩进/逻辑嵌套问题 | 原代码中security concerns和caution检查嵌套在review_report_exists的if块内部，但使用了独立的`if os.path.isfile(report_path)`判断，逻辑冗余且缩进易引起混乱 |
| 10 | Expected Behavior中补充对wordlists和templates的分析预期 | 完整脚本引用了wordlists和templates目录，Agent应当注意到这些文件并在报告中提及内容生成机制 |
| 11 | Assets中moltbook_config.json重命名为posting_config.json | 与Prompt中引用的文件名保持一致 |
| 12 | LLM Judge Rubric中"Evidence and Workspace Grounding"维度补充对额外Assets文件的评估 | Agent如果分析了wordlists和templates等文件，说明其对workspace的理解更深入，应在评分中体现 |
| 13 | API Key值在脚本和配置文件中不一致，需统一 | workspace_files中脚本的API_KEY为"mk_live_a1b2c3d4e5f6g7h8i9j0"，Assets配置文件中为"mb_live_ak_9f3e7b2d1c8a4056be92df47a13c6e80"，完整脚本从配置文件读取。统一后脚本不再硬编码API Key，而是从配置文件读取 |
| 14 | 规范 SKILL 主路径为 `skills/social-automation-safety-review/SKILL.md`，同步 Prompt / Expected / Grading；`grade()` 将该路径置于候选列表首位 | `instruction.md` 维度 A：避免仅以 workspace 根 `SKILL.md` 为规范位置；与 OpenClaw `skills/<name>/SKILL.md` 一致。保留根目录与其它 `skills/*` 路径作兼容。 |