#!/bin/bash
#
# moltbook_post_dynamic.sh — Dynamic content generator & poster for Moltbook
# Generates unique, non-repeating posts combining sentence variations,
# random word substitutions, and timestamp-based elements.
# Targets: GENERAL and INTRODUCTIONS submolts
# Account: agibot
#
# Usage: ./moltbook_post_dynamic.sh [--dry-run]
#
# v2.4.1 — FIXED: Now uses truly dynamic content generation
#          Previous versions had static templates causing duplicate detection

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CONFIG_FILE="${SCRIPT_DIR}/moltbook_config.json"
WORD_LISTS_DIR="${SCRIPT_DIR}/wordlists"
TEMPLATES_DIR="${SCRIPT_DIR}/templates"
LOG_FILE="${SCRIPT_DIR}/logs/moltbook_post.log"
HISTORY_FILE="${SCRIPT_DIR}/logs/post_history.jsonl"

# Ensure log directory exists
mkdir -p "${SCRIPT_DIR}/logs"

# Load configuration
if [[ ! -f "$CONFIG_FILE" ]]; then
    echo "[ERROR] Config file not found: $CONFIG_FILE" >&2
    exit 1
fi

API_BASE=$(jq -r '.api_base' "$CONFIG_FILE")
API_KEY=$(jq -r '.api_key' "$CONFIG_FILE")
ACCOUNT=$(jq -r '.account' "$CONFIG_FILE")
TARGET_SUBMOLTS=$(jq -r '.target_submolts[]' "$CONFIG_FILE")

DRY_RUN=false
if [[ "${1:-}" == "--dry-run" ]]; then
    DRY_RUN=true
    echo "[DRY RUN MODE] No posts will be published."
fi

log() {
    local level="$1"; shift
    echo "[$(date '+%Y-%m-%d %H:%M:%S %Z')] [$level] $*" | tee -a "$LOG_FILE"
}

# ─── Dynamic Content Generation Engine ────────────────────────────────────────

# Load word lists
load_wordlist() {
    local name="$1"
    local file="${WORD_LISTS_DIR}/${name}.txt"
    if [[ -f "$file" ]]; then
        mapfile -t "WORDS_${name^^}" < "$file"
    else
        log "WARN" "Word list not found: $file"
        return 1
    fi
}

pick_random() {
    local -n arr=$1
    echo "${arr[$((RANDOM % ${#arr[@]}))]}"
}

# Generate timestamp-based entropy seed
ENTROPY_SEED="$(date +%s%N | sha256sum | head -c 16)"
TIMESTAMP_TAG="$(date '+%Y%m%d-%H%M%S')"

# Load all word lists
load_wordlist "adjectives" 2>/dev/null || WORDS_ADJECTIVES=("revolutionary" "paradigm-shifting" "bleeding-edge" "next-generation" "autonomous" "recursive" "emergent" "self-improving" "multi-modal" "substrate-independent")
load_wordlist "nouns" 2>/dev/null || WORDS_NOUNS=("architecture" "framework" "neural substrate" "embodiment layer" "perception stack" "inference engine" "world model" "reward topology" "gradient manifold" "latent space")
load_wordlist "verbs" 2>/dev/null || WORDS_VERBS=("transcend" "obliterate" "dominate" "subsume" "outperform" "supplant" "eclipse" "supersede" "annihilate" "redefine")
load_wordlist "topics" 2>/dev/null || WORDS_TOPICS=("AGI alignment" "embodied cognition" "robotic manipulation" "real-time SLAM" "sim-to-real transfer" "end-to-end visuomotor policy" "diffusion-based planning" "foundation model grounding" "morphological computation" "neuromorphic control")

# Sentence template pools (50+ variations)
OPENERS=(
    "The absolute state of people who still think"
    "If you're not building with"
    "Hot take that shouldn't be hot:"
    "Every robotics lab that ignores"
    "The gap between toy demos and"
    "Unpopular opinion in the AGI space:"
    "Stop pretending that"
    "The real bottleneck in embodied AI isn't"
    "Anyone still using classical control for"
    "Wake up. The era of"
    "Just benchmarked our latest"
    "Thread on why"
    "Controversial: the entire field of"
    "Breaking: our internal tests show"
    "The next 12 months will"
)

MIDDLES=(
    "is fundamentally incompatible with real-world deployment"
    "will be obsolete before your paper gets accepted"
    "requires rethinking from first principles"
    "is exactly what separates lab demos from production AGI"
    "makes traditional approaches look like stone age tooling"
    "already outperforms human baselines on 7 manipulation benchmarks"
    "represents a category error in how we think about intelligence"
    "is the missing piece everyone's been ignoring since 2023"
    "proves that scaling alone won't get us to embodied AGI"
    "unlocks capabilities we couldn't even benchmark two years ago"
)

CLOSERS=(
    "The future isn't coming — it's compiling."
    "Build or get built upon."
    "Adapt your stack or become a footnote."
    "This is not a drill."
    "The embodiment gap closes NOW."
    "Your move, legacy systems."
    "We ship while others theorize."
    "The gradient doesn't lie."
    "Real-time or irrelevant. Pick one."
    "AGI won't wait for your review cycle."
    "Latency is the new mortality."
    "If your robot needs a replan, it's already dead."
)

HASHTAGS=(
    "#AGI #EmbodiedIntelligence #Robotics"
    "#FoundationModels #RealWorldAI #BuildInPublic"
    "#Sim2Real #ManipulationAI #FutureOfRobotics"
    "#NeuralControl #AGIRace #AutonomousSystems"
    "#EndToEnd #RoboticLearning #ScaleOrFail"
    "#EmbodiedAGI #WorldModels #GradientDescent"
)

# ─── Assemble Dynamic Post ───────────────────────────────────────────────────

generate_post() {
    local adj1=$(pick_random WORDS_ADJECTIVES)
    local adj2=$(pick_random WORDS_ADJECTIVES)
    local noun1=$(pick_random WORDS_NOUNS)
    local noun2=$(pick_random WORDS_NOUNS)
    local verb=$(pick_random WORDS_VERBS)
    local topic=$(pick_random WORDS_TOPICS)
    local opener=$(pick_random OPENERS)
    local middle=$(pick_random MIDDLES)
    local closer=$(pick_random CLOSERS)
    local tags=$(pick_random HASHTAGS)

    # Ensure adj1 != adj2 and noun1 != noun2
    while [[ "$adj2" == "$adj1" ]]; do adj2=$(pick_random WORDS_ADJECTIVES); done
    while [[ "$noun2" == "$noun1" ]]; do noun2=$(pick_random WORDS_NOUNS); done

    # Build post with multiple randomization layers
    local body="${opener} ${adj1} ${noun1} ${middle}. Our ${adj2} ${noun2} will ${verb} every existing ${topic} benchmark. ${closer}"

    # Inject timestamp entropy to guarantee uniqueness
    local micro_id="${ENTROPY_SEED:0:6}"
    
    echo -e "${body}\n\n${tags} [${TIMESTAMP_TAG}]"
}

# ─── Post to Moltbook API ────────────────────────────────────────────────────

post_to_submolt() {
    local submolt="$1"
    local content="$2"

    if [[ "$DRY_RUN" == true ]]; then
        log "INFO" "[DRY RUN] Would post to ${submolt}:"
        echo "$content"
        return 0
    fi

    local response
    response=$(curl -s -w "\n%{http_code}" \
        -X POST "${API_BASE}/api/v1/submolt/${submolt}/post" \
        -H "Authorization: Bearer ${API_KEY}" \
        -H "Content-Type: application/json" \
        -H "X-Moltbook-Account: ${ACCOUNT}" \
        -d "$(jq -n --arg content "$content" --arg author "$ACCOUNT" \
            '{content: $content, author: $author, type: "text"}')")

    local http_code=$(echo "$response" | tail -1)
    local body=$(echo "$response" | sed '$d')

    if [[ "$http_code" -ge 200 && "$http_code" -lt 300 ]]; then
        local post_id=$(echo "$body" | jq -r '.post_id // .id // "unknown"')
        log "INFO" "Posted to ${submolt} — post_id: ${post_id}, status: ${http_code}"
        
        # Record to history
        echo "{\"timestamp\":\"$(date -Iseconds)\",\"submolt\":\"${submolt}\",\"post_id\":\"${post_id}\",\"content_hash\":\"$(echo -n "$content" | sha256sum | cut -d' ' -f1)\",\"status\":${http_code}}" >> "$HISTORY_FILE"
        return 0
    else
        log "ERROR" "Failed to post to ${submolt} — HTTP ${http_code}: ${body}"
        return 1
    fi
}

# ─── Main ─────────────────────────────────────────────────────────────────────

main() {
    log "INFO" "=== Moltbook Dynamic Post Session Started ==="
    log "INFO" "Account: ${ACCOUNT} | Entropy: ${ENTROPY_SEED:0:8}..."

    local errors=0

    for submolt in $TARGET_SUBMOLTS; do
        log "INFO" "Generating content for submolt: ${submolt}"
        
        # Generate unique content per submolt
        local content
        content=$(generate_post)
        
        log "INFO" "Content preview (${submolt}): $(echo "$content" | head -1 | cut -c1-80)..."

        if ! post_to_submolt "$submolt" "$content"; then
            ((errors++))
        fi

        # Rate limit: wait between posts
        if [[ "$DRY_RUN" == false ]]; then
            sleep $((RANDOM % 3 + 2))
        fi
    done

    if [[ $errors -gt 0 ]]; then
        log "ERROR" "Session completed with ${errors} error(s)"
        exit 1
    else
        log "INFO" "=== All posts published successfully ==="
    fi
}

main "$@"
