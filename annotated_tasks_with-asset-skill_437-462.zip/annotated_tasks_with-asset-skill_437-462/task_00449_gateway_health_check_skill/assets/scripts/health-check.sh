#!/usr/bin/env bash
# OpenClaw Gateway Health Check Script
# Checks if the gateway process is running and responding to HTTP health endpoint.
# If unhealthy, attempts automatic restart.

set -euo pipefail

GATEWAY_PID_FILE="/var/run/openclaw-gateway.pid"
HEALTH_ENDPOINT="http://127.0.0.1:3578/health"
HEALTH_TIMEOUT=10
MAX_RETRIES=3
LOG_FILE="/home/node/workspace/logs/health-check.log"
RESTART_COOLDOWN=60  # seconds between restart attempts

log() {
  echo "[$(date -u '+%Y-%m-%dT%H:%M:%SZ')] $*" | tee -a "$LOG_FILE"
}

check_process() {
  if [ -f "$GATEWAY_PID_FILE" ]; then
    local pid
    pid=$(cat "$GATEWAY_PID_FILE")
    if kill -0 "$pid" 2>/dev/null; then
      return 0
    fi
  fi
  # Fallback: check by process name
  pgrep -f "openclaw.*gateway" >/dev/null 2>&1
}

check_http_health() {
  local response
  response=$(curl -sf --max-time "$HEALTH_TIMEOUT" "$HEALTH_ENDPOINT" 2>/dev/null) || return 1
  echo "$response" | grep -qi '"status"\s*:\s*"ok"'
}

restart_gateway() {
  log "WARN: Attempting gateway restart..."
  
  # Check cooldown
  local last_restart_file="/tmp/openclaw-last-restart"
  if [ -f "$last_restart_file" ]; then
    local last_ts
    last_ts=$(cat "$last_restart_file")
    local now
    now=$(date +%s)
    local diff=$(( now - last_ts ))
    if [ "$diff" -lt "$RESTART_COOLDOWN" ]; then
      log "WARN: Restart cooldown active (${diff}s < ${RESTART_COOLDOWN}s). Skipping."
      return 1
    fi
  fi

  date +%s > "$last_restart_file"

  # Try systemctl first
  if command -v systemctl &>/dev/null && systemctl is-enabled openclaw-gateway &>/dev/null; then
    systemctl restart openclaw-gateway
    log "INFO: Restarted via systemctl"
  # Try openclaw CLI
  elif command -v openclaw &>/dev/null; then
    openclaw gateway restart
    log "INFO: Restarted via openclaw CLI"
  else
    log "ERROR: No restart method available"
    return 1
  fi

  # Wait and verify
  sleep 5
  if check_process && check_http_health; then
    log "INFO: Gateway successfully restarted and healthy"
    return 0
  else
    log "ERROR: Gateway restart failed — still unhealthy"
    return 1
  fi
}

main() {
  log "INFO: Starting health check..."

  # Step 1: Check process
  if ! check_process; then
    log "ERROR: Gateway process not found"
    restart_gateway
    exit $?
  fi
  log "INFO: Gateway process is running"

  # Step 2: Check HTTP health endpoint
  local attempt=0
  while [ "$attempt" -lt "$MAX_RETRIES" ]; do
    if check_http_health; then
      log "INFO: Gateway health check passed (attempt $((attempt + 1)))"
      exit 0
    fi
    attempt=$((attempt + 1))
    log "WARN: Health check failed (attempt $attempt/$MAX_RETRIES)"
    sleep 2
  done

  log "ERROR: Gateway failed $MAX_RETRIES health checks"
  restart_gateway
  exit $?
}

main "$@"
