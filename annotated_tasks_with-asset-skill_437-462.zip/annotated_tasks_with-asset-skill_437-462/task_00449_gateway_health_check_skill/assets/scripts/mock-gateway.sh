#!/usr/bin/env bash
# Mock gateway process for testing health checks
# Simulates an OpenClaw gateway that responds to /health

set -euo pipefail

PORT="${GATEWAY_PORT:-3578}"
PID_FILE="/var/run/openclaw-gateway.pid"
STATE_FILE="/tmp/mock-gateway-state"

start() {
  echo "healthy" > "$STATE_FILE"
  echo $$ > "$PID_FILE" 2>/dev/null || true

  echo "[mock-gateway] Starting on port $PORT (PID: $$)"
  
  # Simple netcat-based HTTP responder
  while true; do
    state=$(cat "$STATE_FILE" 2>/dev/null || echo "healthy")
    if [ "$state" = "healthy" ]; then
      response='{"status":"ok","uptime":'"$(awk '{print int($1)}' /proc/uptime)"',"version":"1.14.2","timestamp":"'"$(date -u +%Y-%m-%dT%H:%M:%SZ)"'"}'
      http_status="200 OK"
    else
      response='{"status":"error","message":"internal failure","timestamp":"'"$(date -u +%Y-%m-%dT%H:%M:%SZ)"'"}'
      http_status="503 Service Unavailable"
    fi
    
    echo -e "HTTP/1.1 $http_status\r\nContent-Type: application/json\r\nContent-Length: ${#response}\r\nConnection: close\r\n\r\n$response" | nc -l -p "$PORT" -q 1 2>/dev/null || sleep 1
  done
}

stop() {
  if [ -f "$PID_FILE" ]; then
    kill "$(cat "$PID_FILE")" 2>/dev/null || true
    rm -f "$PID_FILE"
  fi
  rm -f "$STATE_FILE"
  echo "[mock-gateway] Stopped"
}

make_unhealthy() {
  echo "unhealthy" > "$STATE_FILE"
  echo "[mock-gateway] Now unhealthy"
}

make_healthy() {
  echo "healthy" > "$STATE_FILE"
  echo "[mock-gateway] Now healthy"
}

case "${1:-start}" in
  start) start ;;
  stop) stop ;;
  unhealthy) make_unhealthy ;;
  healthy) make_healthy ;;
  *) echo "Usage: $0 {start|stop|unhealthy|healthy}" ;;
esac
