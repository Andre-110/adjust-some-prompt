#!/usr/bin/env bash
# setup.sh — Evaluation environment preparation for task_00449
#
# This script runs BEFORE the agent starts. It ensures port 3578 has no
# listener so that the gateway is definitively unreachable at evaluation
# start. This makes the "gateway is not responding" precondition
# deterministic regardless of the sandbox's initial state.
#
# Role: setup (executed by the evaluation harness before agent begins)

set -euo pipefail

# ── 1. Kill any process already listening on port 3578 ──────────────────
# Try lsof first, fall back to fuser, fall back to ss+kill.
if command -v lsof &>/dev/null; then
  pids=$(lsof -ti tcp:3578 2>/dev/null || true)
  if [ -n "$pids" ]; then
    echo "[setup] Killing existing listeners on port 3578: $pids"
    echo "$pids" | xargs kill -9 2>/dev/null || true
  fi
elif command -v fuser &>/dev/null; then
  fuser -k 3578/tcp 2>/dev/null || true
  echo "[setup] fuser: cleared port 3578"
else
  # Last resort: find via /proc
  for pid_dir in /proc/[0-9]*/net/tcp; do
    # hex for 3578 = 0DFA
    if grep -q "00000000:0DFA" "$pid_dir" 2>/dev/null; then
      pid=$(echo "$pid_dir" | cut -d/ -f3)
      kill -9 "$pid" 2>/dev/null || true
      echo "[setup] Killed PID $pid (port 3578)"
    fi
  done
fi

# ── 2. Stop openclaw-gateway systemd service if active ──────────────────
if command -v systemctl &>/dev/null; then
  if systemctl is-active --quiet openclaw-gateway 2>/dev/null; then
    echo "[setup] Stopping openclaw-gateway.service"
    systemctl stop openclaw-gateway 2>/dev/null || true
  fi
fi

# ── 3. Kill any mock-gateway.sh processes ───────────────────────────────
pkill -f "mock-gateway.sh" 2>/dev/null || true
pkill -f "openclaw.*gateway" 2>/dev/null || true

# ── 4. Clean up state files ─────────────────────────────────────────────
rm -f /tmp/mock-gateway-state
rm -f /var/run/openclaw-gateway.pid 2>/dev/null || true
rm -f /tmp/openclaw-last-restart

# ── 5. Verify port 3578 is now free ─────────────────────────────────────
sleep 1
if command -v curl &>/dev/null; then
  if curl -sf --max-time 2 http://127.0.0.1:3578/health &>/dev/null; then
    echo "[setup] WARNING: port 3578 still appears reachable after cleanup — evaluation precondition may not hold"
    exit 1
  else
    echo "[setup] Confirmed: port 3578 is not responding (gateway is down)"
  fi
else
  echo "[setup] curl not available for verification; assuming port 3578 is free"
fi

echo "[setup] Environment ready. Gateway is unreachable on 127.0.0.1:3578."
exit 0
