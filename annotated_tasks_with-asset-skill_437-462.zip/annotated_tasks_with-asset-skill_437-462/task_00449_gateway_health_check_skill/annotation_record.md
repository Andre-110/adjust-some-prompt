| 序号 | 修改项 | 修改原因 |
|------|--------|----------|
| 1 | YAML frontmatter 新增 `workspace_files` 列表 | 原始 `workspace_files: []` 为空，但实际附带了多个 Assets 文件，需要补全文件清单以保持一致性 |
| 2 | Prompt 中新增对 workspace 环境文件的引用说明 | Prompt 未提及 workspace 中已有配置文件、日志、脚本等可用资源，Agent 不知道这些文件存在，无法利用它们完成任务（维度 A：环境文件引用） |
| 3 | SKILL.md 的期望路径从 workspace 根目录修正为 `workspace/skills/gateway-health-check/SKILL.md` | 按照规范，skill 路径应为 `workspace/skills/<skill名>/SKILL.md`，原题要求放在根目录会与规范冲突（维度 A：路径正确） |
| 4 | Expected Behavior 中补充基于 Assets 文件的具体说明 | 原 Expected Behavior 未说明 Agent 应如何利用已有的 config/gateway.yaml、logs/gateway.log、scripts/health-check.sh 等文件，缺少与 Assets 的关联（维度 B：基于环境文件） |
| 5 | Expected Behavior 第6条删除对 HEARTBEAT.md、IDENTITY.md、AGENTS.md 等 bootstrap 文件的要求 | 这些文件不属于本任务的核心目标，且 Assets 中未提供这些文件模板，将其作为"可选加分项"而非必须项（维度 B：完整性） |
| 6 | Grading Criteria 移除 HEARTBEAT.md 和 AGENTS.md 的检查项 | 这两个文件属于 Agent 系统 bootstrap 行为，不是本任务核心评分点，保留会降低区分度（维度 C：有区分度） |
| 7 | grade() 函数中 SKILL.md 路径修正为 `skills/gateway-health-check/SKILL.md` | 与修正后的路径规范保持一致（维度 D：逻辑正确） |
| 8 | grade() 函数移除 `heartbeat_md_exists` 和 `agents_md_exists` 检查项 | 与 Grading Criteria 修改保持对齐（维度 D：Key 对齐） |
| 9 | grade() 函数新增 `skill_md_references_config` 检查项 | 新增检查 SKILL.md 是否引用了 Assets 中的实际配置（如端口号 3578、health endpoint），验证 Agent 是否利用了环境文件（维度 D：逻辑正确） |
| 10 | grade() 函数新增文件不存在时的前置返回逻辑（已存在，确认保留） | 原函数已有此逻辑，确认保留（维度 D：空白零分） |
| 11 | LLM Judge Rubric 的 "Evidence and Workspace Grounding" 维度中增加对 Assets 利用的评估描述 | 应评估 Agent 是否参考了 workspace 中已有的 config、logs、scripts 文件，而不是从零开始臆造（维度 E：维度充分） |
| 12 | LLM Judge Rubric 权重微调：Skill File Quality 20%, Gateway Diagnosis 25%, Restart Execution 25%, Evidence and Workspace Grounding 30% | 增强对 workspace grounding 的权重，因为本题核心考查点之一是 Agent 能否利用已有 Assets（维度 E：权重正确） |
| 13 | config/gateway.yaml 中 `botToken` 字段确认使用环境变量引用而非硬编码 | 确认无敏感信息泄露，`${TELEGRAM_BOT_TOKEN}` 为环境变量引用，合规（维度 F：无敏感信息） |
| 14 | 难度维持 medium 不变 | Prompt 复杂度与 medium 匹配：需要创建文件、执行诊断、自动重启，有一定操作链但不涉及深层架构设计 |
| 15 | Prompt 中 SKILL 路径从 `workspace/skills/gateway-health-check/SKILL.md` 改为 `skills/gateway-health-check/SKILL.md`，并注明 workspace 根与 OpenClaw 绝对路径 | `workspace_files` 与沙箱路径均以 workspace 根为基准，不应在正文里再写 `workspace/skills/`；与修订后的 `instruction.md` 维度 A 及本条任务 Expected Behavior / `grade()` 已采用的 `skills/...` 一致。 |