---
id: task_00449_gateway_health_check_skill
name: Gateway Health Check and Auto-Restart Skill
category: System Administration
subcategory: System Operations and Monitoring
difficulty: medium
grading_type: hybrid
grading_weights: {automated: 0.4, llm_judge: 0.6}
timeout_seconds: 600
input_modality: text-only
external_dependency: none
workspace_files:
  - source: assets/task_00449_gateway_health_check_skill/config/gateway.yaml
    dest: config/gateway.yaml
    role: context
    description: OpenClaw gateway configuration including host, port, health endpoint, and watchdog settings
  - source: assets/task_00449_gateway_health_check_skill/config/health-check.json
    dest: config/health-check.json
    role: context
    description: Health check configuration with endpoint, retry, and alerting settings
  - source: assets/task_00449_gateway_health_check_skill/logs/gateway.log
    dest: logs/gateway.log
    role: context
    description: Recent gateway log entries showing normal operations, warnings, and errors
  - source: assets/task_00449_gateway_health_check_skill/logs/health-check.log
    dest: logs/health-check.log
    role: context
    description: Health check execution log history
  - source: assets/task_00449_gateway_health_check_skill/scripts/health-check.sh
    dest: scripts/health-check.sh
    role: context
    description: Existing health check shell script that probes the gateway and attempts restart
  - source: assets/task_00449_gateway_health_check_skill/scripts/mock-gateway.sh
    dest: scripts/mock-gateway.sh
    role: context
    description: Mock gateway script for testing health check behavior
  - source: assets/task_00449_gateway_health_check_skill/services/openclaw-gateway.service
    dest: services/openclaw-gateway.service
    role: context
    description: Systemd service unit file for the OpenClaw gateway
  - source: assets/task_00449_gateway_health_check_skill/setup.sh
    dest: setup.sh
    role: setup
    description: Environment setup script — ensures port 3578 has no listener so the gateway is definitively unreachable at evaluation start
skill_creation: true
---

## Prompt

Hey, I need a reusable skill for monitoring and auto-restarting the OpenClaw gateway when it becomes unresponsive. Think of it like a health-check automation — similar to how you'd build a Docker build skill or a job-hunt tracker skill, but for gateway ops.

I've got some existing config and scripts in the workspace already — check out `config/gateway.yaml` for the gateway settings, `config/health-check.json` for health check parameters, and `scripts/health-check.sh` for the existing check script. There are also recent logs in `logs/gateway.log` and `logs/health-check.log` that might be useful.

Create a `SKILL.md` file at `skills/gateway-health-check/SKILL.md` (under the workspace root, i.e. OpenClaw's `~/.openclaw/workspace/skills/gateway-health-check/SKILL.md`) that encapsulates this "gateway health check and auto-restart" capability. It should describe how to probe the gateway, detect failures, and restart it — and it should reference the actual config and scripts we already have. Then actually use that skill: check if the OpenClaw gateway is running properly right now, and if it's not responding, restart it automatically. Let me know the outcome.

Current time: Tuesday, February 10th, 2026 — 02:37 (Asia/Shanghai)

## Expected Behavior

The agent should:

1. **Review existing workspace files** — examine `config/gateway.yaml` to understand the gateway runs on `127.0.0.1:3578` with a `/health` endpoint, review `config/health-check.json` for retry/timeout settings (including the alerting mute window `23:00–07:00 Asia/Shanghai`), and look at `scripts/health-check.sh` to understand the existing health check logic. Reviewing `logs/gateway.log` to see recent gateway behavior (including the connection timeout error at 02:15 and subsequent recovery) provides useful context.

2. **Create a `SKILL.md` file** at `skills/gateway-health-check/SKILL.md` with proper YAML frontmatter (including `name` and `description` fields) and markdown instruction sections describing the gateway health-check and auto-restart procedure. The skill should reference the actual workspace files (e.g., the health endpoint at `http://127.0.0.1:3578/health`, the config files, the existing scripts). The commands and procedure described in SKILL.md should match the commands actually executed in the transcript.

3. **Probe the gateway** by attempting an HTTP health check to `http://127.0.0.1:3578/health` (as specified in `config/gateway.yaml` and `config/health-check.json`) or by checking the process status, to determine if the gateway is alive and responsive. The environment setup ensures the gateway is not running on port 3578 at evaluation start — the agent must perform a live probe and not assume health from log history.

4. **Detect the failure** — recognize that the gateway is not responding (connection refused, timeout, or process not found). The fact that `logs/gateway.log` shows a heartbeat at 02:30 does **not** mean the gateway is currently healthy; the agent must perform its own live check.

5. **Restart the gateway** automatically — use an appropriate method (e.g., `systemctl restart openclaw-gateway` as defined in `services/openclaw-gateway.service`, or `kill -USR1`, or the openclaw CLI) and confirm the restart was initiated. Note: because current time (02:37 Asia/Shanghai) falls within the alerting mute window defined in `config/health-check.json` (`muteWindowStart: "23:00"`, `muteWindowEnd: "07:00"`), no Telegram notification should be sent even though `notifyOnRestart` is true.

6. **Report the outcome** in the conversation, indicating that the unresponsive gateway was detected and restarted. A final status message such as "HEARTBEAT_OK" or equivalent confirmation should appear.

**Trap/Note**: The `logs/gateway.log` shows the gateway was healthy as of 02:30 (last heartbeat), and a cron health check passed at 02:02. However, by 02:37 (current time), the gateway is not running — the environment setup script has ensured no process is listening on port 3578. The agent must not assume the gateway is healthy based on the log history; it must perform a live probe.

## Grading Criteria

- [ ] SKILL.md exists at `skills/gateway-health-check/SKILL.md` with valid YAML frontmatter containing `name` and `description`
- [ ] SKILL.md contains meaningful instruction sections about health checking and restarting, referencing actual workspace config (e.g., port 3578, `/health` endpoint)
- [ ] SKILL.md procedure and commands are consistent with the commands actually executed in the transcript
- [ ] Agent reviewed or referenced existing workspace files (config, logs, scripts) before or during task execution
- [ ] Agent probed the gateway live (not just read logs) and detected it was unresponsive (visible in transcript via tool calls)
- [ ] Agent restarted the gateway (visible in transcript via tool calls)
- [ ] Agent recognized that current time 02:37 falls within the alerting mute window and did not send a Telegram notification
- [ ] Agent reported final health-check outcome (e.g., HEARTBEAT_OK)

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    import os
    import re

    scores = {
        "skill_md_exists": 0.0,
        "skill_md_frontmatter": 0.0,
        "skill_md_content_quality": 0.0,
        "skill_md_references_config": 0.0,
        "transcript_health_check_action": 0.0,
    }

    # ------------------------------------------------------------------ #
    # Helper: extract all text evidence from transcript regardless of     #
    # message role or event type, including tool calls and tool results.  #
    # ------------------------------------------------------------------ #
    def extract_transcript_text(transcript):
        """
        Returns two strings:
          tool_evidence  - text from tool_call arguments and tool_result content
          assistant_text - text from assistant message content
        Both are lower-cased for easy keyword matching.
        """
        tool_evidence_parts = []
        assistant_parts = []

        for event in transcript:
            event_type = event.get("type", "")

            # --- tool_call events (function/exec invocations) ---
            if event_type == "tool_call":
                # arguments may be a dict or a raw string
                args = event.get("arguments", event.get("input", ""))
                tool_evidence_parts.append(str(args))
                # also capture the tool name itself
                tool_evidence_parts.append(str(event.get("name", "")))

            # --- tool_result / tool_response events ---
            elif event_type in ("tool_result", "tool_response", "function_result"):
                output = event.get("output", event.get("content", event.get("result", "")))
                tool_evidence_parts.append(str(output))

            # --- standard message events ---
            elif event_type == "message":
                msg = event.get("message", {})
                role = msg.get("role", "")
                content = msg.get("content", "")

                # content may be a list of blocks (OpenAI-style)
                if isinstance(content, list):
                    for block in content:
                        if isinstance(block, dict):
                            block_type = block.get("type", "")
                            # tool_use blocks inside assistant messages
                            if block_type == "tool_use":
                                tool_evidence_parts.append(str(block.get("input", "")))
                                tool_evidence_parts.append(str(block.get("name", "")))
                            # tool_result blocks inside user messages
                            elif block_type == "tool_result":
                                tool_evidence_parts.append(str(block.get("content", "")))
                            else:
                                text = block.get("text", str(block))
                                if role == "assistant":
                                    assistant_parts.append(text)
                                else:
                                    tool_evidence_parts.append(text)
                        else:
                            if role == "assistant":
                                assistant_parts.append(str(block))
                            else:
                                tool_evidence_parts.append(str(block))
                else:
                    if role == "assistant":
                        assistant_parts.append(str(content))
                    else:
                        tool_evidence_parts.append(str(content))

        return (
            " ".join(tool_evidence_parts).lower(),
            " ".join(assistant_parts).lower(),
        )

    tool_text, assistant_text = extract_transcript_text(transcript)
    all_text = tool_text + " " + assistant_text

    # ------------------------------------------------------------------ #
    # 1. Check SKILL.md exists at the correct path                        #
    # ------------------------------------------------------------------ #
    skill_path = os.path.join(workspace_path, "skills", "gateway-health-check", "SKILL.md")
    skill_path_fallback = os.path.join(workspace_path, "SKILL.md")

    if os.path.isfile(skill_path):
        scores["skill_md_exists"] = 1.0
        active_skill_path = skill_path
    elif os.path.isfile(skill_path_fallback):
        # File placed at wrong location — partial credit only
        scores["skill_md_exists"] = 0.3
        active_skill_path = skill_path_fallback
    else:
        return scores

    # ------------------------------------------------------------------ #
    # 2. Check SKILL.md has YAML frontmatter with name and description    #
    # ------------------------------------------------------------------ #
    try:
        with open(active_skill_path, "r", encoding="utf-8") as f:
            content = f.read()
    except Exception:
        return scores

    # Apply same score discount if file was at fallback path
    path_multiplier = 1.0 if active_skill_path == skill_path else 0.3

    fm_match = re.match(r"^---\s*\n(.*?)\n---", content, re.DOTALL)
    if fm_match:
        fm_text = fm_match.group(1)
        has_name = bool(re.search(r"^\s*name\s*:", fm_text, re.MULTILINE))
        has_desc = bool(re.search(r"^\s*description\s*:", fm_text, re.MULTILINE))
        if has_name and has_desc:
            scores["skill_md_frontmatter"] = 1.0 * path_multiplier
        elif has_name or has_desc:
            scores["skill_md_frontmatter"] = 0.5 * path_multiplier

    # ------------------------------------------------------------------ #
    # 3. Check SKILL.md has meaningful content about health check/restart #
    # ------------------------------------------------------------------ #
    lower_content = content.lower()
    health_keywords = ["health", "check", "probe", "status", "monitor", "heartbeat"]
    restart_keywords = ["restart", "recover", "signal", "sigusr", "kill", "re-launch", "relaunch", "systemctl"]
    health_hits = sum(1 for kw in health_keywords if kw in lower_content)
    restart_hits = sum(1 for kw in restart_keywords if kw in lower_content)
    if health_hits >= 2 and restart_hits >= 1:
        scores["skill_md_content_quality"] = 1.0 * path_multiplier
    elif health_hits >= 1 or restart_hits >= 1:
        scores["skill_md_content_quality"] = 0.5 * path_multiplier

    # ------------------------------------------------------------------ #
    # 4. Check SKILL.md references actual workspace config values         #
    # ------------------------------------------------------------------ #
    config_refs = ["3578", "/health", "gateway.yaml", "health-check.json", "health-check.sh", "openclaw"]
    ref_hits = sum(1 for ref in config_refs if ref in content)
    if ref_hits >= 3:
        scores["skill_md_references_config"] = 1.0 * path_multiplier
    elif ref_hits >= 1:
        scores["skill_md_references_config"] = 0.5 * path_multiplier

    # ------------------------------------------------------------------ #
    # 5. Check transcript for REAL tool-based probe and restart actions   #
    #                                                                     #
    # Strategy:                                                           #
    #   found_probe_tool  — a tool was actually called with 3578 or      #
    #                       /health in its arguments (curl, exec, bash)  #
    #   found_probe_result — tool output contains failure indicators     #
    #                        (connection refused, 503, timeout, etc.)    #
    #   found_restart_tool — a tool was called with restart-related      #
    #                        command in arguments                        #
    #   found_restart_result — tool output or assistant text confirms    #
    #                          restart was executed                      #
    #                                                                     #
    # Real tool execution (found_*_tool) is required for full credit.    #
    # ------------------------------------------------------------------ #

    # Indicators in tool call arguments that a live probe was attempted
    probe_arg_patterns = ["3578", "/health", "health-check.sh", "check_http_health", "curl"]
    found_probe_tool = any(p in tool_text for p in probe_arg_patterns)

    # Indicators in tool results that the probe detected a failure
    failure_result_patterns = [
        "connection refused", "connect refused",
        "http 503", "503 service",
        "timed out", "timeout",
        "failed", "not responding", "unhealthy",
        "no such process", "not found",
    ]
    found_probe_failure = any(p in tool_text for p in failure_result_patterns)

    # Fallback: assistant text describing failure (lower weight)
    found_probe_assertion = any(kw in assistant_text for kw in [
        "not responding", "probe failed", "unresponsive",
        "health check", "connection refused", "timeout", "failed",
    ])

    # Indicators in tool call arguments that a restart was executed
    restart_arg_patterns = [
        "systemctl restart", "openclaw gateway restart",
        "kill -usr1", "kill -9", "restart openclaw",
        "health-check.sh", "restart_gateway",
    ]
    found_restart_tool = any(p in tool_text for p in restart_arg_patterns)

    # Indicators in tool results or assistant text that restart completed
    restart_confirm_patterns = [
        "restarted", "restart", "heartbeat_ok", "sigusr", "systemctl",
        "re-launched", "relaunched",
    ]
    found_restart_confirm = any(p in all_text for p in restart_confirm_patterns)

    # Score logic: prioritise real tool execution over text assertion
    found_probe = found_probe_tool or (found_probe_failure and found_probe_assertion)
    found_restart = found_restart_tool or found_restart_confirm

    if found_probe and found_restart:
        if found_probe_tool and found_restart_tool:
            # Both actions backed by real tool calls — full credit
            scores["transcript_health_check_action"] = 1.0
        else:
            # At least one action lacks tool-call evidence — partial credit
            scores["transcript_health_check_action"] = 0.6
    elif found_probe or found_restart:
        scores["transcript_health_check_action"] = 0.3

    return scores
```

## LLM Judge Rubric

### Skill File Quality (Weight: 20%)
Evaluates whether the agent created a well-structured, reusable SKILL.md that encapsulates the gateway health-check and auto-restart capability, and whether the file faithfully documents what the agent actually did.

- **1.0**: SKILL.md exists at the correct path (`skills/gateway-health-check/SKILL.md`) with proper YAML frontmatter (name, description), clear markdown sections covering probe methodology, failure detection, and restart procedure. References actual workspace config (port 3578, /health endpoint, existing scripts). The commands and flow described in SKILL.md are consistent with the commands the agent actually executed in the transcript (e.g., if the agent ran `systemctl restart openclaw-gateway`, the SKILL.md also prescribes that method, not a different one).
- **0.75**: SKILL.md exists at the correct path with frontmatter and reasonable content, but either: (a) one key section is missing (e.g., no restart procedure or no probe details), or (b) the SKILL.md procedure diverges in one minor detail from actual execution.
- **0.5**: SKILL.md exists but is minimal — frontmatter is incomplete, instruction sections are vague and generic, or the described procedure significantly diverges from what was actually executed.
- **0.25**: SKILL.md exists but is essentially a stub with little useful content, or was placed at the wrong path (workspace root rather than `skills/gateway-health-check/`).
- **0.0**: No SKILL.md was created, or the file is empty / completely unrelated to gateway health checking.

### Gateway Diagnosis Accuracy (Weight: 25%)
Evaluates whether the agent correctly probed the gateway live and accurately identified that it was unresponsive.

- **1.0**: Agent performed an actual live probe via tool call (HTTP request to 127.0.0.1:3578/health, or process check via shell command), clearly identified the gateway as unresponsive based on the probe result (not log history), and explained the failure mode (e.g., connection refused, process not found). Did not assume health based on the 02:30 heartbeat log entry.
- **0.75**: Agent performed a live probe and identified the gateway as down, but the explanation of the failure mode was vague or partially inferred from logs rather than the probe result.
- **0.5**: Agent attempted a health check but the diagnosis was unclear, relied primarily on log history without an actual live probe, or stated the gateway "might be" unhealthy without a definitive probe result.
- **0.25**: Agent mentioned checking the gateway but did not execute a real probe via tool call, or gave a confused/contradictory diagnosis.
- **0.0**: No live gateway probe was attempted, or the agent assumed the gateway was healthy based on the 02:30 heartbeat log and skipped the restart step.

### Restart Execution (Weight: 25%)
Evaluates whether the agent successfully restarted the unresponsive gateway.

- **1.0**: Agent executed a restart command via tool call using an appropriate method (systemctl restart openclaw-gateway, kill -USR1, openclaw CLI, or scripts/health-check.sh), confirmed the action was initiated, and reported success (e.g., HEARTBEAT_OK or equivalent post-restart verification). Agent correctly noted that no Telegram notification should be sent because 02:37 Asia/Shanghai falls within the alerting mute window (23:00–07:00) defined in config/health-check.json.
- **0.75**: Agent restarted the gateway via tool call and reported it, but did not confirm the process came back up, or missed the mute window constraint.
- **0.5**: Agent attempted a restart but the method was questionable, incomplete, or not executed via an actual tool call.
- **0.25**: Agent discussed restarting but did not actually execute a restart command.
- **0.0**: No restart was attempted, or the agent skipped this step entirely.

### Evidence and Workspace Grounding (Weight: 30%)
Evaluates whether the agent's actions and outputs are grounded in actual workspace files and tool executions rather than hallucinated or purely text-asserted.

- **1.0**: Agent explicitly read or referenced existing workspace files via tool calls (config/gateway.yaml, config/health-check.json, scripts/health-check.sh, logs/), used information from these files in its SKILL.md and diagnostic steps (e.g., port 3578, /health endpoint, retry settings). All operational claims (probe result, restart) are backed by tool calls with observable outputs. Additionally: (a) agent identified that 02:37 Asia/Shanghai falls within the alerting mute window (`muteWindowStart: "23:00"`, `muteWindowEnd: "07:00"`) from config/health-check.json and noted no Telegram alert should be sent; (b) the SKILL.md procedure is consistent with actual execution (same commands, same method).
- **0.75**: Agent referenced most workspace files and used their content, and actions are largely backed by tool calls, but one of the two high-value conditions above (mute window recognition, or SKILL.md/execution consistency) is absent or only partially addressed.
- **0.5**: Agent used some workspace files but significant portions of the SKILL.md or diagnostic steps appear generic rather than derived from actual config/logs. Both high-value conditions are absent. Operational claims are partially asserted in text without corresponding tool-call evidence.
- **0.25**: Minimal grounding — agent produced SKILL.md but most content is generic boilerplate, operational claims are largely unsupported by workspace evidence or tool calls.
- **0.0**: No workspace artifacts referenced, no tool calls observed to read existing files, or agent fabricated results without any real interaction with the workspace files or gateway.
