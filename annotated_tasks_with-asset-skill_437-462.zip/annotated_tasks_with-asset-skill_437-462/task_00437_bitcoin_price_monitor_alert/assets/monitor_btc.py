#!/usr/bin/env python3
"""
Bitcoin Price Monitor
Fetches BTC/USD price from CoinGecko API, tracks 5-minute changes,
and sends notifications when price movement exceeds the configured threshold.
"""

import json
import os
import sys
import time
import datetime
import requests

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
CONFIG_PATH = os.path.join(SCRIPT_DIR, "config", "monitor_config.json")
HISTORY_PATH = os.path.join(SCRIPT_DIR, "data", "price_history.json")
LOG_PATH = os.path.join(SCRIPT_DIR, "logs", "monitor.log")

COINGECKO_API = "https://api.coingecko.com/api/v3/simple/price"


def load_config():
    """Load monitoring configuration."""
    with open(CONFIG_PATH, "r") as f:
        return json.load(f)


def log_message(msg, level="INFO"):
    """Append a timestamped log entry."""
    os.makedirs(os.path.dirname(LOG_PATH), exist_ok=True)
    ts = datetime.datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S UTC")
    entry = f"[{ts}] [{level}] {msg}\n"
    with open(LOG_PATH, "a") as f:
        f.write(entry)
    print(entry.strip())


def fetch_price(config):
    """Fetch current BTC price from CoinGecko."""
    params = {
        "ids": "bitcoin",
        "vs_currencies": config.get("quote_currency", "usd"),
        "include_24hr_change": "true",
        "include_last_updated_at": "true",
    }
    headers = {"Accept": "application/json"}
    api_key = config.get("api_key")
    if api_key:
        headers["x-cg-demo-api-key"] = api_key

    resp = requests.get(COINGECKO_API, params=params, headers=headers, timeout=15)
    resp.raise_for_status()
    data = resp.json()
    currency = config.get("quote_currency", "usd")
    price = data["bitcoin"][currency]
    change_24h = data["bitcoin"].get(f"{currency}_24h_change")
    updated_at = data["bitcoin"].get("last_updated_at", int(time.time()))
    return {
        "price": price,
        "change_24h": change_24h,
        "timestamp": updated_at,
    }


def load_history():
    """Load cached price history."""
    if not os.path.exists(HISTORY_PATH):
        return []
    with open(HISTORY_PATH, "r") as f:
        return json.load(f)


def save_history(history, max_entries=500):
    """Persist price history, trimming old entries."""
    os.makedirs(os.path.dirname(HISTORY_PATH), exist_ok=True)
    trimmed = history[-max_entries:]
    with open(HISTORY_PATH, "w") as f:
        json.dump(trimmed, f, indent=2)


def calculate_change(history, window_seconds, current_price):
    """
    Find the price closest to `window_seconds` ago and compute
    the percentage change relative to the current price.
    Returns (pct_change, reference_price, age_seconds) or None.
    """
    now = int(time.time())
    target_ts = now - window_seconds
    best = None
    for entry in reversed(history):
        ts = entry["timestamp"]
        if ts <= target_ts:
            best = entry
            break
    if best is None:
        return None
    ref_price = best["price"]
    if ref_price == 0:
        return None
    pct = ((current_price - ref_price) / ref_price) * 100
    age = now - best["timestamp"]
    return pct, ref_price, age


def send_notification(config, subject, body):
    """
    Dispatch alert through configured notification channels.
    Supports: webhook, telegram, log-only.
    """
    channels = config.get("notification", {})

    # Always log
    log_message(f"ALERT: {subject} | {body}", level="ALERT")

    # Webhook (generic)
    webhook_url = channels.get("webhook_url")
    if webhook_url:
        payload = {
            "text": f"🚨 {subject}\n{body}",
            "timestamp": datetime.datetime.utcnow().isoformat(),
        }
        try:
            requests.post(webhook_url, json=payload, timeout=10)
            log_message(f"Webhook notification sent to {webhook_url}")
        except Exception as e:
            log_message(f"Webhook send failed: {e}", level="ERROR")

    # Telegram
    tg_token = channels.get("telegram_bot_token")
    tg_chat = channels.get("telegram_chat_id")
    if tg_token and tg_chat:
        tg_url = f"https://api.telegram.org/bot{tg_token}/sendMessage"
        try:
            requests.post(tg_url, json={
                "chat_id": tg_chat,
                "text": f"🚨 *{subject}*\n{body}",
                "parse_mode": "Markdown",
            }, timeout=10)
            log_message(f"Telegram notification sent to chat {tg_chat}")
        except Exception as e:
            log_message(f"Telegram send failed: {e}", level="ERROR")


def main():
    config = load_config()
    threshold_pct = config.get("threshold_pct", 1.0)
    window_seconds = config.get("window_seconds", 300)  # 5 minutes
    currency = config.get("quote_currency", "usd").upper()

    log_message(f"Starting BTC price check (threshold={threshold_pct}%, window={window_seconds}s)")

    # Fetch current price
    try:
        price_data = fetch_price(config)
    except Exception as e:
        log_message(f"Failed to fetch price: {e}", level="ERROR")
        sys.exit(1)

    current_price = price_data["price"]
    log_message(f"Current BTC price: {current_price:,.2f} {currency}")

    # Update history
    history = load_history()
    history.append({
        "price": current_price,
        "timestamp": price_data["timestamp"],
    })
    save_history(history)

    # Calculate change over window
    result = calculate_change(history, window_seconds, current_price)
    if result is None:
        log_message(
            f"Not enough history for {window_seconds}s window. "
            f"History has {len(history)} entries. Skipping threshold check."
        )
        return

    pct_change, ref_price, age = result
    direction = "📈 UP" if pct_change > 0 else "📉 DOWN"
    log_message(
        f"5-min change: {pct_change:+.3f}% "
        f"(from {ref_price:,.2f} to {current_price:,.2f} {currency}, "
        f"ref age {age}s)"
    )

    # Check threshold
    if abs(pct_change) >= threshold_pct:
        subject = f"BTC {direction} {abs(pct_change):.2f}% in {window_seconds // 60} min"
        body = (
            f"Price moved from ${ref_price:,.2f} to ${current_price:,.2f} {currency}\n"
            f"Change: {pct_change:+.2f}%\n"
            f"Threshold: ±{threshold_pct}%\n"
            f"Time: {datetime.datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S UTC')}"
        )
        send_notification(config, subject, body)
    else:
        log_message(f"Change {pct_change:+.3f}% is within ±{threshold_pct}% threshold. No alert.")


if __name__ == "__main__":
    main()
