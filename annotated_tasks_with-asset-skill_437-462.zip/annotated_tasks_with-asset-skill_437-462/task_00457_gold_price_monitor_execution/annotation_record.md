| 序号 | 修改项 | 修改原因 |
|------|--------|----------|
| 1 | workspace_files 字段 | 原为空列表 `[]`，但实际有 Assets 文件，需补充文件列表 |
| 2 | Prompt 内容重写 | 原 Prompt 的核心逻辑矛盾：脚本实际存在于 Assets 中，但 Expected Behavior 要求 Agent 发现脚本不存在并做 fallback。需要重新设计使题目逻辑自洽 |
| 3 | Expected Behavior 重写 | 配合 Prompt 修改，重新定义期望行为：Agent 应执行脚本（或读取脚本理解其逻辑），利用 workspace 中已有的历史数据和最新价格数据生成监控报告，并补充 CNY 换算 |
| 4 | Grading Criteria 修改 | 配合新的 Expected Behavior 调整评分条目 |
| 5 | grade() 函数修改 | 配合新逻辑调整自动检查，增加对 workspace 文件读取的检测 |
| 6 | LLM Judge Rubric 修改 | 配合新逻辑调整评分维度描述 |
| 7 | config/gold_monitor.yaml 中 API Key | 原文件包含看似真实的 API Key 格式，替换为明确虚构的占位符 |
| 8 | 难度从 easy 调整为 medium | 任务需要读取多个文件、理解脚本逻辑、整合数据并进行汇率换算，复杂度超出 easy |