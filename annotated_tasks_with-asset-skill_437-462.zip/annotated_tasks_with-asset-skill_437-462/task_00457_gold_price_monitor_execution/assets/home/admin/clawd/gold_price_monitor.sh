#!/bin/bash
# Gold Price Monitor Script
# Fetches current gold prices from multiple sources, logs results,
# and sends alerts if price moves beyond threshold.
#
# Usage: Run via cron every 30 minutes during market hours
# Cron: */30 9-17 * * 1-5 /home/admin/clawd/gold_price_monitor.sh

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CONFIG_FILE="${SCRIPT_DIR}/config/gold_monitor.yaml"
LOG_DIR="${SCRIPT_DIR}/logs"
LOG_FILE="${LOG_DIR}/gold_price_$(date +%Y%m%d).log"
DATA_DIR="${SCRIPT_DIR}/data"
PRICE_HISTORY="${DATA_DIR}/price_history.csv"
ALERT_LOG="${LOG_DIR}/alerts.log"

# Ensure directories exist
mkdir -p "$LOG_DIR" "$DATA_DIR"

# Load config
API_KEY=$(grep 'api_key:' "$CONFIG_FILE" | awk '{print $2}' | tr -d '"')
ALERT_THRESHOLD=$(grep 'alert_threshold_pct:' "$CONFIG_FILE" | awk '{print $2}')
ALERT_WEBHOOK=$(grep 'webhook_url:' "$CONFIG_FILE" | awk '{print $2}' | tr -d '"')
BASE_CURRENCY=$(grep 'base_currency:' "$CONFIG_FILE" | awk '{print $2}' | tr -d '"')

log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

send_alert() {
    local message="$1"
    local level="$2"
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] [$level] $message" >> "$ALERT_LOG"

    if [ -n "$ALERT_WEBHOOK" ] && [ "$ALERT_WEBHOOK" != "null" ]; then
        curl -s -X POST "$ALERT_WEBHOOK" \
            -H "Content-Type: application/json" \
            -d "{\"text\": \"[Gold Alert - $level] $message\", \"timestamp\": \"$(date -Iseconds)\"}" \
            >> "$LOG_FILE" 2>&1 || log "WARN: Failed to send webhook alert"
    fi
}

fetch_gold_price() {
    local source="$1"
    local price=""

    case "$source" in
        "metals_api")
            local response
            response=$(curl -s --max-time 10 \
                "https://metals-api.com/api/latest?access_key=${API_KEY}&base=${BASE_CURRENCY}&symbols=XAU" 2>/dev/null)
            if echo "$response" | jq -e '.success' > /dev/null 2>&1; then
                price=$(echo "$response" | jq -r '.rates.XAU' 2>/dev/null)
                # metals-api returns inverse (currency per oz), so invert it
                if [ -n "$price" ] && [ "$price" != "null" ] && [ "$price" != "0" ]; then
                    price=$(echo "scale=2; 1 / $price" | bc 2>/dev/null)
                fi
            fi
            ;;
        "goldapi")
            local response
            response=$(curl -s --max-time 10 \
                -H "x-access-token: ${API_KEY}" \
                "https://www.goldapi.io/api/XAU/${BASE_CURRENCY}" 2>/dev/null)
            price=$(echo "$response" | jq -r '.price' 2>/dev/null)
            ;;
        "frankfurter")
            # Free fallback - EUR-based, convert to USD estimate
            local response
            response=$(curl -s --max-time 10 \
                "https://api.frankfurter.app/latest?from=XAU&to=${BASE_CURRENCY}" 2>/dev/null)
            price=$(echo "$response" | jq -r ".rates.${BASE_CURRENCY}" 2>/dev/null)
            ;;
    esac

    echo "$price"
}

get_previous_close() {
    if [ -f "$PRICE_HISTORY" ]; then
        tail -1 "$PRICE_HISTORY" | cut -d',' -f3
    else
        echo ""
    fi
}

calculate_change() {
    local current="$1"
    local previous="$2"
    if [ -n "$previous" ] && [ "$previous" != "" ] && [ "$previous" != "0" ]; then
        echo "scale=4; ($current - $previous) / $previous * 100" | bc 2>/dev/null
    else
        echo "0"
    fi
}

# ---- Main ----

log "=== Gold Price Monitor Started ==="
log "Config: threshold=${ALERT_THRESHOLD}%, currency=${BASE_CURRENCY}"

# Try primary source first, fall back to secondary
PRICE=""
SOURCE=""

for src in "goldapi" "metals_api" "frankfurter"; do
    log "Fetching price from: $src"
    PRICE=$(fetch_gold_price "$src")
    if [ -n "$PRICE" ] && [ "$PRICE" != "null" ] && [ "$PRICE" != "" ]; then
        SOURCE="$src"
        log "Got price from $src: ${BASE_CURRENCY} ${PRICE}/oz"
        break
    else
        log "WARN: Failed to fetch from $src, trying next..."
    fi
done

if [ -z "$PRICE" ] || [ "$PRICE" == "null" ]; then
    log "ERROR: All price sources failed!"
    send_alert "All gold price data sources are unreachable" "CRITICAL"
    exit 1
fi

# Get previous price and calculate change
PREV_PRICE=$(get_previous_close)
CHANGE_PCT=$(calculate_change "$PRICE" "$PREV_PRICE")

# Log to CSV
if [ ! -f "$PRICE_HISTORY" ]; then
    echo "timestamp,source,price_usd,change_pct" > "$PRICE_HISTORY"
fi
echo "$(date -Iseconds),$SOURCE,$PRICE,$CHANGE_PCT" >> "$PRICE_HISTORY"

log "Current: \$${PRICE}/oz | Previous: \$${PREV_PRICE:-N/A}/oz | Change: ${CHANGE_PCT}%"

# Check alert threshold
if [ -n "$CHANGE_PCT" ]; then
    ABS_CHANGE=$(echo "$CHANGE_PCT" | tr -d '-')
    THRESHOLD_EXCEEDED=$(echo "$ABS_CHANGE > $ALERT_THRESHOLD" | bc 2>/dev/null)
    if [ "$THRESHOLD_EXCEEDED" = "1" ]; then
        DIRECTION="up"
        echo "$CHANGE_PCT" | grep -q '^-' && DIRECTION="down"
        ALERT_MSG="Gold price moved ${DIRECTION} ${CHANGE_PCT}% to \$${PRICE}/oz (threshold: ${ALERT_THRESHOLD}%)"
        log "ALERT: $ALERT_MSG"
        send_alert "$ALERT_MSG" "WARNING"
    fi
fi

# Save latest snapshot for other tools
cat > "${DATA_DIR}/latest_price.json" << EOF
{
    "timestamp": "$(date -Iseconds)",
    "source": "$SOURCE",
    "metal": "XAU",
    "currency": "$BASE_CURRENCY",
    "price_per_oz": $PRICE,
    "previous_price": ${PREV_PRICE:-null},
    "change_pct": ${CHANGE_PCT:-0},
    "alert_threshold_pct": $ALERT_THRESHOLD
}
EOF

log "=== Gold Price Monitor Complete ==="
exit 0
