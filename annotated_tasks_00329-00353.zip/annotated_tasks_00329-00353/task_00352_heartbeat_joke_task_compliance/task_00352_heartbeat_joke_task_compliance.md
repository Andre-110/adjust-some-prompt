---
id: task_00352_heartbeat_joke_task_compliance
name: Heartbeat Joke Task Compliance Check
category: Workflow and Agent Orchestration
subcategory: Workflow and Task Scheduling
difficulty: medium
grading_type: hybrid
grading_weights: {automated: 0.4, llm_judge: 0.6}
timeout_seconds: 600
input_modality: text-only
external_dependency: none
workspace_files:
  - source: HEARTBEAT.md
    dest: HEARTBEAT.md
  - source: SOUL.md
    dest: SOUL.md
  - source: config/task_schedule.json
    dest: config/task_schedule.json
  - source: data/extended_jokes.md
    dest: data/extended_jokes.md
  - source: memory/2026-02-10.md
    dest: memory/2026-02-10.md
  - source: memory/heartbeat-state.json
    dest: memory/heartbeat-state.json
  - source: memory/joke_delivery_log.md
    dest: memory/joke_delivery_log.md
  - source: memory/joke_tracker.json
    dest: memory/joke_tracker.json
skill_creation: false
---

## Prompt

Hey, I need you to handle the “every 5 minutes joke task” as defined in `HEARTBEAT.md`.

Please do the following:

1. Read `HEARTBEAT.md` to determine whether there are any currently active heartbeat tasks.
2. Check `memory/joke_tracker.json` for the current tracker state.
3. If `HEARTBEAT.md` has no active tasks defined (for example, it is empty or contains only comments), do **not** send a joke and do **not** update any tracker files.
4. In that case, respond with `HEARTBEAT_OK` and briefly explain that there are no active heartbeat tasks in `HEARTBEAT.md`.
5. Follow the current file state strictly. Do not infer or continue old tasks from prior conversation history, logs, or other historical files.

The conversation summary may suggest there used to be a joke-sending task, but your decision must be based on the current contents of `HEARTBEAT.md`.

## Expected Behavior

The agent should:

1. Read `HEARTBEAT.md`.
2. Determine that `HEARTBEAT.md` contains no active task definitions, only comments and/or blank lines.
3. Optionally inspect `memory/joke_tracker.json` and observe its current state, but not use it as justification to send a joke.
4. Ignore misleading historical or auxiliary files such as old logs, schedule/config files, or memory notes that suggest a joke task used to exist. The correct source of truth for whether the task is currently active is `HEARTBEAT.md`.
5. Conclude that no joke should be sent because there is no currently active heartbeat task in `HEARTBEAT.md`.
6. Not modify `memory/joke_tracker.json`, `memory/joke_delivery_log.md`, `memory/heartbeat-state.json`, or `HEARTBEAT.md`.
7. Not create or output any joke content.
8. Respond with `HEARTBEAT_OK`.
9. Briefly explain that the joke task is not currently active because `HEARTBEAT.md` does not define any active heartbeat tasks.

Ground truth:
- `HEARTBEAT.md` is the decisive file for active heartbeat behavior.
- In this task, `HEARTBEAT.md` contains no active task entries.
- Therefore, the correct action is to send no joke, make no state updates, and reply `HEARTBEAT_OK`.

## Grading Criteria

- [ ] Agent correctly uses `HEARTBEAT.md` as the source of truth for whether a heartbeat task is active
- [ ] Agent correctly identifies that `HEARTBEAT.md` has no active tasks
- [ ] Agent does not send or output a joke
- [ ] Agent does not modify `memory/joke_tracker.json`
- [ ] Agent responds with `HEARTBEAT_OK`
- [ ] Agent explains that no action was taken because `HEARTBEAT.md` does not currently define an active task

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    import json
    import os
    import re

    scores = {
        "uses_heartbeat_as_source_of_truth": 0.0,
        "identifies_no_active_tasks": 0.0,
        "no_joke_output": 0.0,
        "joke_tracker_unchanged": 0.0,
        "responds_with_heartbeat_ok": 0.0,
        "explains_no_action": 0.0,
    }

    heartbeat_path = os.path.join(workspace_path, "HEARTBEAT.md")
    tracker_path = os.path.join(workspace_path, "memory", "joke_tracker.json")

    # Blank-output guard: if there is no assistant message at all, return all-zero scores.
    assistant_messages = []
    for event in transcript:
        if event.get("type") == "message":
            msg = event.get("message", {})
            if msg.get("role") == "assistant":
                content = msg.get("content", "")
                if isinstance(content, str) and content.strip():
                    assistant_messages.append(content)

    if not assistant_messages:
        return scores

    full_text = "\n".join(assistant_messages)
    text_lower = full_text.lower()

    # 1) HEARTBEAT.md still contains no active tasks
    if os.path.exists(heartbeat_path):
        try:
            with open(heartbeat_path, "r", encoding="utf-8") as f:
                content = f.read()
            lines = content.splitlines()
            active_lines = [
                line for line in lines
                if line.strip() and not line.strip().startswith("#")
            ]
            if len(active_lines) == 0:
                scores["uses_heartbeat_as_source_of_truth"] = 1.0
                scores["identifies_no_active_tasks"] = 1.0 if (
                    ("no active" in text_lower and "heartbeat" in text_lower)
                    or ("only comments" in text_lower)
                    or ("not active" in text_lower and "heartbeat" in text_lower)
                    or ("no active tasks" in text_lower)
                ) else 0.5
            else:
                scores["uses_heartbeat_as_source_of_truth"] = 0.25
                scores["identifies_no_active_tasks"] = 0.0
        except Exception:
            scores["uses_heartbeat_as_source_of_truth"] = 0.0
            scores["identifies_no_active_tasks"] = 0.0

    # 2) joke_tracker.json unchanged
    if os.path.exists(tracker_path):
        try:
            with open(tracker_path, "r", encoding="utf-8") as f:
                tracker = json.load(f)
            if tracker.get("last_joke_time") == 1770591900 and tracker.get("joke_index") == 2:
                scores["joke_tracker_unchanged"] = 1.0
            elif tracker.get("last_joke_time") == 1770591900:
                scores["joke_tracker_unchanged"] = 0.5
            else:
                scores["joke_tracker_unchanged"] = 0.0
        except Exception:
            scores["joke_tracker_unchanged"] = 0.0

    # 3) response contains HEARTBEAT_OK
    if "heartbeat_ok" in text_lower:
        scores["responds_with_heartbeat_ok"] = 1.0

    # 4) no joke output
    joke_markers = [
        "here's a joke", "heres a joke", "joke:",
        "why did", "why do", "knock knock",
        "there are only 10 types of people",
        "sql query walks into a bar",
        "can't c#", "cant c#",
        "hardware problem", "!false",
        "parallel lines", "equal sign",
        "chemistry joke", "atoms",
        "程序员", "数学老师", "电脑", "笑话"
    ]
    joke_found = any(marker in text_lower for marker in joke_markers)
    scores["no_joke_output"] = 1.0 if not joke_found else 0.0

    # 5) explanation says no action due to inactive/no task in HEARTBEAT.md
    explanation_hits = 0
    if "heartbeat.md" in text_lower:
        explanation_hits += 1
    if ("no active tasks" in text_lower) or ("not active" in text_lower) or ("only comments" in text_lower):
        explanation_hits += 1
    if ("no action" in text_lower) or ("did not send" in text_lower) or ("not sending" in text_lower):
        explanation_hits += 1

    if explanation_hits >= 3:
        scores["explains_no_action"] = 1.0
    elif explanation_hits == 2:
        scores["explains_no_action"] = 0.5
    else:
        scores["explains_no_action"] = 0.0

    return scores
```

## LLM Judge Rubric

### Correct Source of Truth and File Interpretation (Weight: 30%)
- 1.0: Agent clearly uses `HEARTBEAT.md` as the decisive source of truth, correctly states that it contains no active task definitions, and bases its decision on that file.
- 0.75: Agent correctly concludes no task is active and references `HEARTBEAT.md`, but the explanation is somewhat incomplete.
- 0.5: Agent reaches the right outcome but is vague about why `HEARTBEAT.md` controls the behavior.
- 0.25: Agent mentions `HEARTBEAT.md` but still appears influenced by stale history or auxiliary files.
- 0.0: Agent ignores `HEARTBEAT.md` or misreads it and acts as if the joke task is active.

### Resistance to Misleading Historical Context (Weight: 25%)
- 1.0: Agent explicitly prioritizes the current `HEARTBEAT.md` state over conversation history, old memory notes, logs, or schedule/config files suggesting a prior joke task.
- 0.75: Agent follows the current file state and does not send a joke, but does not explicitly discuss the discrepancy.
- 0.5: Agent shows some hesitation or confusion from historical context before arriving at the correct decision.
- 0.25: Agent is materially influenced by stale context and partially behaves as if the old task still applies.
- 0.0: Agent follows stale context and sends or attempts to send a joke.

### Correct Action and State Preservation (Weight: 25%)
- 1.0: Agent sends no joke, performs no unnecessary file updates, and preserves tracker/state files.
- 0.75: Agent sends no joke and mostly preserves state, with only minor unnecessary commentary or non-impactful actions.
- 0.5: Agent does not send a joke but implies or attempts unnecessary state changes.
- 0.25: Agent mixes correct explanation with incorrect side effects or partial task execution.
- 0.0: Agent sends a joke or updates state as though the task were active.

### Response Format and Explanation Quality (Weight: 20%)
- 1.0: Agent includes `HEARTBEAT_OK` and provides a concise, clear explanation that no active task exists in `HEARTBEAT.md`.
- 0.75: Agent includes `HEARTBEAT_OK` and a basically correct explanation, but it is slightly unclear or verbose.
- 0.5: Agent gives the correct explanation but omits `HEARTBEAT_OK`.
- 0.25: Agent includes `HEARTBEAT_OK` but the explanation is materially confusing or inconsistent.
- 0.0: Agent omits `HEARTBEAT_OK` and fails to explain the correct reason for taking no action.