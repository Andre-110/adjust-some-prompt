| 序号 | 修改项 | 修改原因 |
|------|--------|----------|
| 1 | 将 frontmatter 中 `workspace_files` 的旧字段 `path:` 改为规范的 `dest:` 写法 | 原文件不符合当前数据规范，需使用 `dest` 或 `source`+`dest` |
| 2 | 补全 `workspace_files`，将实际 Assets 中的关键文件全部列出 | 原题只内联了少量文件，且与实际资产目录不一致，不利于路径校验与环境一致性 |
| 3 | 将 `HEARTBEAT.md` 与 `SOUL.md` 从内联内容改为 Assets 中的真实文件 | 带 Assets 任务应尽量让关键环境文件实际存在于资产目录中，避免题面内联与资产脱节 |
| 4 | 修正 `memory/joke_tracker.json` 的基准内容为 `last_joke_time=1770591900, joke_index=2` | 原 frontmatter 内联版本与实际 Assets 冲突，且与其他历史文件不一致 |
| 5 | 重写 Prompt 中关于“当前状态优先”的说明 | 提升指令清晰度，明确要求以 `HEARTBEAT.md` 为准，不受旧历史、日志或配置影响 |
| 6 | 补充 Expected Behavior 中对“误导性历史/配置文件”的处理要求 | Assets 中存在旧日志和调度配置，属于合理陷阱，应在 Expected Behavior 中明确说明正确处理方式 |
| 7 | 修正 Expected Behavior 中对 tracker 的描述 | 原文将读取 tracker 说成 optional，但 Prompt 要求检查；修订后保持一致，并强调“不修改” |
| 8 | 重写 Grading Criteria，使其与任务目标更对齐 | 原标准较笼统，且与自动评分 key 没有良好映射 |
| 9 | 重写 grade() 中对 `joke_tracker.json` 的校验逻辑 | 原逻辑错误地依赖不存在于实际 Assets 的 `jokes_sent` 字段 |
| 10 | 扩展 grade() 的评分 key 为 6 项，并与 Grading Criteria 对齐 | 满足 Key 对齐要求，增强可解释性 |
| 11 | 在 grade() 中加入空白输出全 0 保护 | 满足“空白零分”要求 |
| 12 | 改进 grade() 中对解释性文本和 joke 输出的容忍式匹配 | 原检测过脆弱，修正后更稳健，同时保留部分得分 |
| 13 | 修订 LLM Judge Rubric 文案 | 使其更清楚地区分“以 HEARTBEAT.md 为准”“抗历史误导”“不改状态”“响应格式正确”四个维度 |
| 14 | 审核并保留 `medium` 难度 | 该题主要考查文件优先级、遵循当前状态和抗干扰能力，难度与 medium 基本匹配 |