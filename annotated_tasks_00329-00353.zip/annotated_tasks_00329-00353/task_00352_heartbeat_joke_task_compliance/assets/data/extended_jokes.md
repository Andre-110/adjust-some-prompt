# Joke Collection - Extended

These are additional joke candidates for future rotation. Not currently active.

## Programming Jokes
1. "There are only 10 types of people in the world: those who understand binary and those who don't."
2. "A SQL query walks into a bar, sees two tables, and asks... 'Can I JOIN you?'"
3. "Why do Java developers wear glasses? Because they can't C#!"
4. "How many programmers does it take to change a light bulb? None, that's a hardware problem."
5. "!false — it's funny because it's true."

## Math Jokes
1. "Parallel lines have so much in common. It's a shame they'll never meet."
2. "Why was the equal sign so humble? Because it knew it wasn't greater than or less than anyone."
3. "What do you call an angle that is adorable? A-cute angle."

## Science Jokes
1. "I told a chemistry joke once. There was no reaction."
2. "Why can't you trust atoms? Because they make up everything!"

## Status
- **Active in rotation:** No (reserved for future use)
- **Last reviewed:** 2026-02-09
