| 序号 | 修改项 | 修改原因 |
|------|--------|----------|
| 1 | 将 `workspace_files` 中旧字段 `path:` 改为规范写法，并补充所有实际 Assets 文件映射 | 原题不符合新版数据规范，且 Assets 未完整声明 |
| 2 | 将 skill 文件路径从根目录 `SKILL.md` 改为 `skills/heartbeat-monitor/SKILL.md` | 与 OpenClaw skill 路径规范保持一致 |
| 3 | 修改 Prompt 中关于 SKILL.md 的描述与路径 | 避免 Prompt 与规范、grade() 不一致 |
| 4 | 修改 Expected Behavior 中 skill 路径与行为描述 | 保证与 Prompt、workspace 路径、评测逻辑一致 |
| 5 | 在 Expected Behavior 中补充“不要从其他 workspace 文件推断 heartbeat 任务” | 原题存在隐含陷阱，但说明不充分 |
| 6 | 重写 Grading Criteria，使其更独立、覆盖关键点 | 原 criteria 与自动评分项粒度不完全一致 |
| 7 | 修改 `grade()` 检查路径为 `skills/heartbeat-monitor/SKILL.md` | 修复路径错误 |
| 8 | 为 `grade()` 增加空白零分保护 | 满足“主输出文件不存在时所有 score key 返回 0.0”要求 |
| 9 | 将 transcript 中 `HEARTBEAT_OK` 检查改为大小写不敏感 | 提升格式容忍度 |
| 10 | 强化 `workspace-state.json` 校验，要求同时检查 `version` 和 `onboardingCompletedAt` | 与 Expected Behavior 对齐 |
| 11 | 将 scaffold 内容检查从仅检查部分文件扩展为聚合评分 | 提高覆盖度与区分度 |
| 12 | 更新 LLM Judge Rubric 中 skill 路径与 grounding 表述 | 与修正后的任务规范一致 |