# Server Migration Notes

## Migration Plan: Legacy API → Cloud Native

**Target Date:** 2025-01-20
**Status:** In Progress

### Phase 1: Database Migration (Complete)
- [x] Export PostgreSQL 13 data from legacy server
- [x] Import into Cloud SQL (PostgreSQL 15)
- [x] Validate row counts and checksums
- [x] Update connection strings in vault

### Phase 2: Service Migration (In Progress)
- [x] Containerize auth-service
- [x] Containerize api-gateway
- [ ] Containerize worker-service
- [ ] Containerize notification-service
- [ ] Update CI/CD pipelines

### Phase 3: DNS Cutover (Pending)
- [ ] Configure DNS failover
- [ ] Test with canary traffic (5%)
- [ ] Full cutover
- [ ] Decommission legacy servers

### Contacts
| Role | Name | Slack |
|------|------|-------|
| Lead | Jordan Patel | @jordan.patel |
| DBA | Sam Nakamura | @sam.n |
| SRE | Casey Zhou | @casey.z |

### Notes
- Legacy server lease expires 2025-02-28
- Budget approved for 3-month cloud overlap period
- Elasticsearch cluster needs separate migration (blocked on licensing)
