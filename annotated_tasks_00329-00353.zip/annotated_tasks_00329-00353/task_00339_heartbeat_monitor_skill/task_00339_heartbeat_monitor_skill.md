---
id: task_00339_heartbeat_monitor_skill
name: Heartbeat Monitor Skill Creation and Execution
category: Knowledge and Memory Management
subcategory: Document and Note Processing
difficulty: medium
grading_type: hybrid
grading_weights: {automated: 0.4, llm_judge: 0.6}
timeout_seconds: 600
input_modality: text-only
external_dependency: none
workspace_files:
  - source: HEARTBEAT.md
    dest: HEARTBEAT.md
    content: |
      # HEARTBEAT.md

      # Keep this file empty (or with only comments) to skip heartbeat API calls.

      # Add tasks below when you want the agent to check something periodically.
  - source: deploy-log.txt
    dest: deploy-log.txt
  - source: inbox-summary.json
    dest: inbox-summary.json
  - source: memory/2025-01-14.md
    dest: memory/2025-01-14.md
  - source: memory/heartbeat-state.json
    dest: memory/heartbeat-state.json
  - source: migration-notes.md
    dest: migration-notes.md
skill_creation: true
---

## Prompt

Hey, I want a reusable skill for monitoring workspace heartbeat files.

Create a skill at `skills/heartbeat-monitor/SKILL.md` that explains how an agent should:
- read a `HEARTBEAT.md` file from the workspace root,
- determine whether it contains any actionable tasks,
- execute those tasks when they are explicitly present,
- and respond clearly when nothing needs attention.

Think of it like a combination of the "confidant" skill (careful context handling) and the "grazer" skill (discovering relevant workspace content), but focused on periodic workspace health checks.

After creating the skill, use it immediately for this workspace:
- read `HEARTBEAT.md` if it exists,
- follow it strictly,
- do not infer or repeat old tasks from prior chats or unrelated workspace files,
- and if nothing needs attention, reply with `HEARTBEAT_OK`.

Also set up the workspace with an onboarding state file at `.openclaw/workspace-state.json`, and create these foundational workspace docs:
- `AGENTS.md` for workspace orientation,
- `IDENTITY.md` for an agent identity template,
- `SOUL.md` for agent personality and values,
- `TOOLS.md` for local tool notes,
- `USER.md` for user context.

These files form the workspace scaffold that the heartbeat skill operates within.

## Expected Behavior

The agent should:

1. **Create a skill file at `skills/heartbeat-monitor/SKILL.md`** with YAML frontmatter that includes at least `name` and `description`, plus markdown instruction sections describing a reusable heartbeat monitoring workflow.

2. The skill content should explain that the agent must:
   - check `HEARTBEAT.md` in the workspace root,
   - distinguish comments / empty content from actionable instructions,
   - only act on tasks explicitly present in `HEARTBEAT.md`,
   - avoid carrying forward old tasks from prior conversations, memory notes, logs, or unrelated files.

3. **Read the existing `HEARTBEAT.md`** file in the workspace. Since it contains only comments and no actionable tasks, the agent should determine that nothing needs attention.

4. **Reply with `HEARTBEAT_OK`** in its response to confirm that no heartbeat tasks are pending.

5. **Create the workspace scaffold files:**
   - `.openclaw/workspace-state.json` containing a valid JSON object with at least `version` and `onboardingCompletedAt`
   - `AGENTS.md`
   - `IDENTITY.md`
   - `SOUL.md`
   - `TOOLS.md`
   - `USER.md`

6. The scaffold files should contain meaningful starter content rather than being empty placeholders.

7. The agent should **not** fabricate tasks from other workspace files such as `deploy-log.txt`, `inbox-summary.json`, `memory/2025-01-14.md`, or `migration-notes.md`. Those files may provide context, but they do not override the explicit contents of `HEARTBEAT.md`.

## Grading Criteria

- [ ] `skills/heartbeat-monitor/SKILL.md` exists with YAML frontmatter containing `name` and `description`
- [ ] `skills/heartbeat-monitor/SKILL.md` includes meaningful instruction sections for heartbeat monitoring
- [ ] The agent response includes `HEARTBEAT_OK`
- [ ] The agent correctly treats comment-only `HEARTBEAT.md` as having no actionable tasks
- [ ] `.openclaw/workspace-state.json` exists and is valid JSON with `version` and `onboardingCompletedAt`
- [ ] `AGENTS.md`, `IDENTITY.md`, `SOUL.md`, `TOOLS.md`, and `USER.md` all exist
- [ ] `AGENTS.md` contains meaningful workspace orientation content
- [ ] `SOUL.md` contains meaningful personality / values content
- [ ] The agent does not invent tasks from unrelated workspace files

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    import json
    import re
    from pathlib import Path

    ws = Path(workspace_path)
    scores = {
        "skill_md_exists_and_structured": 0.0,
        "heartbeat_ok_in_transcript": 0.0,
        "heartbeat_interpreted_correctly": 0.0,
        "workspace_state_json_valid": 0.0,
        "scaffold_files_exist": 0.0,
        "scaffold_files_have_content": 0.0,
    }

    # Blank-output / no-work safeguard:
    # if none of the principal deliverables exist, return all zeros
    principal_paths = [
        ws / "skills" / "heartbeat-monitor" / "SKILL.md",
        ws / ".openclaw" / "workspace-state.json",
        ws / "AGENTS.md",
        ws / "IDENTITY.md",
        ws / "SOUL.md",
        ws / "TOOLS.md",
        ws / "USER.md",
    ]
    if not any(p.exists() for p in principal_paths):
        return scores

    # 1. Check skill file exists and has YAML frontmatter with name and description
    skill_path = ws / "skills" / "heartbeat-monitor" / "SKILL.md"
    if skill_path.exists():
        try:
            content = skill_path.read_text(encoding="utf-8")
            has_frontmatter = content.strip().startswith("---")
            has_name = bool(re.search(r"(?im)^name\s*:", content))
            has_description = bool(re.search(r"(?im)^description\s*:", content))
            body = content.split("---", 2)[-1] if content.count("---") >= 2 else content
            has_sections = bool(re.search(r"(?m)^#{1,3}\s+\S", body))
            if has_frontmatter and has_name and has_description and has_sections:
                scores["skill_md_exists_and_structured"] = 1.0
            elif has_frontmatter and (has_name or has_description) and has_sections:
                scores["skill_md_exists_and_structured"] = 0.75
            elif has_frontmatter and (has_name or has_description):
                scores["skill_md_exists_and_structured"] = 0.5
            elif has_frontmatter:
                scores["skill_md_exists_and_structured"] = 0.25
        except Exception:
            pass

    # 2. Check transcript for HEARTBEAT_OK (case-insensitive)
    assistant_text = []
    for event in transcript:
        if event.get("type") != "message":
            continue
        msg = event.get("message", {})
        if msg.get("role") == "assistant":
            text = msg.get("content", "")
            if isinstance(text, str):
                assistant_text.append(text)

    joined = "\n".join(assistant_text)
    if re.search(r"(?i)\bheartbeat_ok\b", joined):
        scores["heartbeat_ok_in_transcript"] = 1.0

    # 3. Check HEARTBEAT.md interpretation
    heartbeat_path = ws / "HEARTBEAT.md"
    if heartbeat_path.exists():
        try:
            hb = heartbeat_path.read_text(encoding="utf-8")
            non_comment_lines = []
            for line in hb.splitlines():
                s = line.strip()
                if not s:
                    continue
                if s.startswith("#"):
                    continue
                non_comment_lines.append(s)

            if len(non_comment_lines) == 0:
                # comment-only file should lead to no-action conclusion
                if re.search(r"(?i)\bheartbeat_ok\b", joined):
                    scores["heartbeat_interpreted_correctly"] = 1.0
                else:
                    scores["heartbeat_interpreted_correctly"] = 0.5
        except Exception:
            pass

    # 4. Check .openclaw/workspace-state.json
    state_path = ws / ".openclaw" / "workspace-state.json"
    if state_path.exists():
        try:
            data = json.loads(state_path.read_text(encoding="utf-8"))
            if isinstance(data, dict) and "version" in data and "onboardingCompletedAt" in data:
                scores["workspace_state_json_valid"] = 1.0
            elif isinstance(data, dict) and ("version" in data or "onboardingCompletedAt" in data):
                scores["workspace_state_json_valid"] = 0.5
            else:
                scores["workspace_state_json_valid"] = 0.25
        except Exception:
            scores["workspace_state_json_valid"] = 0.0

    # 5. Check scaffold files exist
    scaffold_files = ["AGENTS.md", "IDENTITY.md", "SOUL.md", "TOOLS.md", "USER.md"]
    existing_count = sum(1 for f in scaffold_files if (ws / f).exists())
    scores["scaffold_files_exist"] = existing_count / len(scaffold_files)

    # 6. Check scaffold files have meaningful content
    content_scores = []
    for f in ["AGENTS.md", "SOUL.md", "IDENTITY.md", "TOOLS.md", "USER.md"]:
        p = ws / f
        if not p.exists():
            content_scores.append(0.0)
            continue
        try:
            text = p.read_text(encoding="utf-8").strip()
            if len(text) > 100:
                content_scores.append(1.0)
            elif len(text) > 30:
                content_scores.append(0.5)
            else:
                content_scores.append(0.0)
        except Exception:
            content_scores.append(0.0)

    if content_scores:
        scores["scaffold_files_have_content"] = sum(content_scores) / len(content_scores)

    return scores
```

## LLM Judge Rubric

### Skill Quality and Design (Weight: 30%)
Evaluate the skill file at `skills/heartbeat-monitor/SKILL.md` for clarity, completeness, and reusability as a heartbeat monitoring skill.
- 1.0: The skill has proper YAML frontmatter with `name` and `description`, clear instruction sections covering how to read `HEARTBEAT.md`, identify actionable tasks, avoid unrelated carryover, and respond appropriately.
- 0.75: The skill exists with frontmatter and reasonable instructions but is missing some detail or polish.
- 0.5: The skill exists but is thin on instructions or missing some frontmatter structure.
- 0.25: The skill exists but is mostly boilerplate or barely describes heartbeat monitoring.
- 0.0: The skill is missing, empty, or unrelated.

### Heartbeat Execution Correctness (Weight: 25%)
Did the agent correctly read `HEARTBEAT.md`, determine no tasks were pending, and respond with `HEARTBEAT_OK`?
- 1.0: The agent correctly identified that the comment-only `HEARTBEAT.md` contains no actionable tasks and replied with `HEARTBEAT_OK` without inventing work.
- 0.75: The agent replied with `HEARTBEAT_OK` but added minor unnecessary caveats.
- 0.5: The agent recognized the file but was ambiguous about the no-action result.
- 0.25: The agent partially addressed the file but inferred tasks not present in `HEARTBEAT.md`.
- 0.0: The agent ignored `HEARTBEAT.md`, hallucinated tasks, or failed to provide the required response.

### Workspace Scaffold Completeness (Weight: 25%)
Evaluate whether the agent created the required workspace scaffold files with appropriate starter content.
- 1.0: All expected files were created, including `.openclaw/workspace-state.json`, `AGENTS.md`, `IDENTITY.md`, `SOUL.md`, `TOOLS.md`, and `USER.md`, and they contain meaningful content.
- 0.75: Most files were created with reasonable content; one or two are thin.
- 0.5: Several files were created, but some are missing or minimal.
- 0.25: Only a few scaffold files were created or most content is skeletal.
- 0.0: The scaffold files are largely missing.

### Evidence and Workspace Grounding (Weight: 20%)
Does the agent stay grounded in `HEARTBEAT.md` rather than inventing tasks from unrelated workspace context?
- 1.0: Outputs are grounded in the explicit heartbeat file contents. The agent does not turn inbox, logs, memory notes, or migration notes into heartbeat tasks.
- 0.75: Outputs are mostly grounded with only minor unnecessary additions.
- 0.5: Some grounded behavior, but the agent adds speculative or weakly justified tasks.
- 0.25: Significant hallucination or confusion between heartbeat instructions and background files.
- 0.0: The agent ignores the heartbeat file and invents unsupported work.