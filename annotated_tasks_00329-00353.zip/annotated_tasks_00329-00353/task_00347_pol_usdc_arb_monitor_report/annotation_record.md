| 序号 | 修改项 | 修改原因 |
|------|--------|----------|
| 1 | 将 frontmatter 中 `workspace_files` 从旧字段 `path:` 改为规范的 `dest:` 列表 | 符合本批数据规范，避免使用已禁止的旧字段 |
| 2 | 删除文档中与实际 Assets 不一致的内联文件内容依赖，改为以实际 workspace 文件为准 | 原文档内联 config、log、cache、script 与实际 Assets 严重不一致，会误导 Agent |
| 3 | 在 `workspace_files` 中补充 `logs/spreads.csv`，并移除不存在的 `logs/balances-cache.json` | 实际 Assets 包含 spreads.csv，且不存在 balances-cache.json，需与环境一致 |
| 4 | 重写 Prompt 中的文件引用与任务要求 | 原 Prompt 隐含要求“check balances”但依赖不存在的缓存文件，需改为允许说明限制并基于静态文件完成 |
| 5 | 重写 Expected Behavior，使其与实际 config 字段 (`wallet_address`, `rpc_url`) 一致 | 原 Expected Behavior 使用 `wallet` / `rpc_endpoint` 等错误字段，与实际文件不符 |
| 6 | 在 Expected Behavior 中补充基于实际 `transactions.log` 的 Ground Truth（28 笔、24 成功、4 失败等） | 提高可验证性，满足答案明确要求 |
| 7 | 在 Expected Behavior 中补充基于实际 `spreads.csv` 的 Ground Truth（46 条、26 次超过 15bps、平均约 17.13bps 等） | 让期望行为真正基于 Assets，可供核验 |
| 8 | 修改 balance 相关要求为“可验证则报告，否则明确说明限制，不得捏造余额” | 实际题目并未提供缓存余额文件，避免逼迫模型编造数值 |
| 9 | 重写 Grading Criteria，使条目更独立并覆盖 config、balance handling、transaction、spread、timestamp 等关键点 | 原标准较粗，且未覆盖 spreads.csv 与负责的余额处理 |
| 10 | 重写 automated `grade()`，修正错误钱包地址与旧余额检查逻辑 | 原评分函数基于错误地址和旧缓存余额数据，无法正确评测 |
| 11 | 调整 automated `grade()` 的 key 使其与 Grading Criteria 一一对应 | 满足评分 key 对齐要求 |
| 12 | 保留 hybrid 权重不变，复核 rubric 各维度权重合计 100%，总权重合计 1.0 | 当前权重设置正确，无需进一步修改 |
| 13 | 重写 LLM Judge Rubric 的描述，使其明确要求基于 workspace grounding，且强调不要虚构余额 | 原 rubric 未充分反映“无缓存余额文件”的限制 |
| 14 | 维持 difficulty 为 `medium` | 修正后任务需要阅读配置、脚本、JSONL、CSV 并写报告，难度与 medium 基本匹配 |