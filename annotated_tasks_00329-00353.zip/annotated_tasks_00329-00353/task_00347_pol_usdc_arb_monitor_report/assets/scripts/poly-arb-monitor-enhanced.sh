#!/usr/bin/env bash
#
# poly-arb-monitor-enhanced.sh
# Enhanced monitoring script for POL/USDC arbitrage bot
# Checks token balances, monitors transaction logs, and alerts on anomalies
#
# Usage: ./poly-arb-monitor-enhanced.sh [--config <path>] [--verbose]
#
# Requires: curl, jq, bc
# Config: ../config/monitor-config.json

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DEFAULT_CONFIG="${SCRIPT_DIR}/../config/monitor-config.json"
LOG_DIR="${SCRIPT_DIR}/../logs"
DATA_DIR="${SCRIPT_DIR}/../data"

# Parse arguments
CONFIG_PATH="$DEFAULT_CONFIG"
VERBOSE=false
while [[ $# -gt 0 ]]; do
    case $1 in
        --config) CONFIG_PATH="$2"; shift 2 ;;
        --verbose) VERBOSE=true; shift ;;
        *) echo "Unknown option: $1"; exit 1 ;;
    esac
done

# Load config
if [[ ! -f "$CONFIG_PATH" ]]; then
    echo "[ERROR] Config file not found: $CONFIG_PATH"
    exit 1
fi

RPC_URL=$(jq -r '.rpc_url' "$CONFIG_PATH")
WALLET_ADDRESS=$(jq -r '.wallet_address' "$CONFIG_PATH")
POL_CONTRACT=$(jq -r '.tokens.POL.contract' "$CONFIG_PATH")
USDC_CONTRACT=$(jq -r '.tokens.USDC.contract' "$CONFIG_PATH")
POL_DECIMALS=$(jq -r '.tokens.POL.decimals' "$CONFIG_PATH")
USDC_DECIMALS=$(jq -r '.tokens.USDC.decimals' "$CONFIG_PATH")
MIN_POL_BALANCE=$(jq -r '.alerts.min_pol_balance' "$CONFIG_PATH")
MIN_USDC_BALANCE=$(jq -r '.alerts.min_usdc_balance' "$CONFIG_PATH")
ALERT_WEBHOOK=$(jq -r '.alerts.webhook_url // empty' "$CONFIG_PATH")
SPREAD_THRESHOLD=$(jq -r '.strategy.spread_threshold_bps' "$CONFIG_PATH")

TIMESTAMP=$(date -u +"%Y-%m-%dT%H:%M:%SZ")
LOG_FILE="${LOG_DIR}/monitor-$(date -u +%Y%m%d).log"

log() {
    local level="$1"; shift
    echo "[${TIMESTAMP}] [${level}] $*" | tee -a "$LOG_FILE"
}

log_verbose() {
    if $VERBOSE; then
        log "DEBUG" "$@"
    fi
}

# ─── ERC-20 Balance Query ───────────────────────────────────────────
# balanceOf(address) selector: 0x70a08231
get_erc20_balance() {
    local token_contract="$1"
    local decimals="$2"
    local padded_addr
    padded_addr=$(printf '%064s' "${WALLET_ADDRESS#0x}" | tr ' ' '0')

    local payload
    payload=$(cat <<EOF
{
    "jsonrpc": "2.0",
    "method": "eth_call",
    "params": [{
        "to": "${token_contract}",
        "data": "0x70a08231${padded_addr}"
    }, "latest"],
    "id": 1
}
EOF
)

    local response
    response=$(curl -s -X POST "$RPC_URL" \
        -H "Content-Type: application/json" \
        -d "$payload" \
        --connect-timeout 10 \
        --max-time 15)

    local hex_balance
    hex_balance=$(echo "$response" | jq -r '.result // "0x0"')

    if [[ "$hex_balance" == "null" || "$hex_balance" == "0x" ]]; then
        echo "0"
        return
    fi

    # Convert hex to decimal and apply decimals
    local raw_balance
    raw_balance=$(printf '%d' "$hex_balance" 2>/dev/null || echo "0")
    echo "scale=6; $raw_balance / (10 ^ $decimals)" | bc -l
}

# ─── Native MATIC/POL Balance ──────────────────────────────────────
get_native_balance() {
    local payload
    payload=$(cat <<EOF
{
    "jsonrpc": "2.0",
    "method": "eth_getBalance",
    "params": ["${WALLET_ADDRESS}", "latest"],
    "id": 1
}
EOF
)

    local response
    response=$(curl -s -X POST "$RPC_URL" \
        -H "Content-Type: application/json" \
        -d "$payload" \
        --connect-timeout 10 \
        --max-time 15)

    local hex_balance
    hex_balance=$(echo "$response" | jq -r '.result // "0x0"')
    local raw_balance
    raw_balance=$(printf '%d' "$hex_balance" 2>/dev/null || echo "0")
    echo "scale=6; $raw_balance / (10 ^ 18)" | bc -l
}

# ─── Transaction Log Analysis ──────────────────────────────────────
analyze_tx_logs() {
    local tx_log="${LOG_DIR}/transactions.log"
    if [[ ! -f "$tx_log" ]]; then
        log "WARN" "Transaction log not found: $tx_log"
        return
    fi

    local total_txs failed_txs last_tx_time avg_gas_used
    total_txs=$(wc -l < "$tx_log" 2>/dev/null || echo "0")
    failed_txs=$(grep -c '"status":"failed"' "$tx_log" 2>/dev/null || echo "0")
    last_tx_time=$(tail -1 "$tx_log" 2>/dev/null | jq -r '.timestamp // "N/A"')
    avg_gas_used=$(jq -r '.gas_used // 0' "$tx_log" 2>/dev/null | awk '{sum+=$1; n++} END {if(n>0) printf "%.0f", sum/n; else print "0"}')

    log "INFO" "=== Transaction Log Summary ==="
    log "INFO" "Total transactions: $total_txs"
    log "INFO" "Failed transactions: $failed_txs"
    log "INFO" "Last transaction: $last_tx_time"
    log "INFO" "Average gas used: $avg_gas_used"

    # Alert if failure rate > 10%
    if [[ "$total_txs" -gt 0 ]]; then
        local fail_rate
        fail_rate=$(echo "scale=2; $failed_txs * 100 / $total_txs" | bc -l)
        if (( $(echo "$fail_rate > 10" | bc -l) )); then
            log "ALERT" "High failure rate: ${fail_rate}% ($failed_txs/$total_txs)"
            send_alert "High TX failure rate: ${fail_rate}%"
        fi
    fi
}

# ─── Spread Monitoring ─────────────────────────────────────────────
check_recent_spreads() {
    local spread_log="${LOG_DIR}/spreads.csv"
    if [[ ! -f "$spread_log" ]]; then
        log_verbose "No spread log found"
        return
    fi

    local avg_spread profitable_count total_count
    total_count=$(tail -n +2 "$spread_log" | wc -l)
    profitable_count=$(tail -n +2 "$spread_log" | awk -F',' -v thresh="$SPREAD_THRESHOLD" '$4 > thresh {count++} END {print count+0}')
    avg_spread=$(tail -n +2 "$spread_log" | awk -F',' '{sum+=$4; n++} END {if(n>0) printf "%.2f", sum/n; else print "0"}')

    log "INFO" "=== Spread Analysis (last 24h) ==="
    log "INFO" "Observations: $total_count"
    log "INFO" "Profitable opportunities: $profitable_count"
    log "INFO" "Average spread: ${avg_spread} bps"
}

# ─── Alert Function ────────────────────────────────────────────────
send_alert() {
    local message="$1"
    if [[ -n "$ALERT_WEBHOOK" ]]; then
        curl -s -X POST "$ALERT_WEBHOOK" \
            -H "Content-Type: application/json" \
            -d "{\"text\": \"[POL-ARB] ${message}\", \"timestamp\": \"${TIMESTAMP}\"}" \
            --connect-timeout 5 || true
    fi
    log "ALERT" "$message"
}

# ─── Cache Balance Data ────────────────────────────────────────────
cache_balance() {
    local pol_bal="$1" usdc_bal="$2" native_bal="$3"
    local cache_file="${DATA_DIR}/balance-cache.json"
    cat > "$cache_file" <<EOF
{
    "timestamp": "${TIMESTAMP}",
    "wallet": "${WALLET_ADDRESS}",
    "balances": {
        "POL": ${pol_bal},
        "USDC": ${usdc_bal},
        "MATIC_NATIVE": ${native_bal}
    },
    "alerts_triggered": false
}
EOF
}

# ═══════════════════════════════════════════════════════════════════
# MAIN
# ═══════════════════════════════════════════════════════════════════
log "INFO" "========================================"
log "INFO" "Enhanced POL/USDC Arbitrage Monitor"
log "INFO" "Wallet: ${WALLET_ADDRESS}"
log "INFO" "RPC: ${RPC_URL}"
log "INFO" "========================================"

# 1. Check balances
log "INFO" "Fetching token balances..."
POL_BALANCE=$(get_erc20_balance "$POL_CONTRACT" "$POL_DECIMALS")
USDC_BALANCE=$(get_erc20_balance "$USDC_CONTRACT" "$USDC_DECIMALS")
NATIVE_BALANCE=$(get_native_balance)

log "INFO" "POL Balance:    ${POL_BALANCE}"
log "INFO" "USDC Balance:   ${USDC_BALANCE}"
log "INFO" "Native Balance: ${NATIVE_BALANCE}"

# 2. Balance alerts
if (( $(echo "$POL_BALANCE < $MIN_POL_BALANCE" | bc -l) )); then
    send_alert "Low POL balance: ${POL_BALANCE} (min: ${MIN_POL_BALANCE})"
fi

if (( $(echo "$USDC_BALANCE < $MIN_USDC_BALANCE" | bc -l) )); then
    send_alert "Low USDC balance: ${USDC_BALANCE} (min: ${MIN_USDC_BALANCE})"
fi

if (( $(echo "$NATIVE_BALANCE < 0.5" | bc -l) )); then
    send_alert "Low native balance for gas: ${NATIVE_BALANCE} MATIC"
fi

# 3. Analyze transaction logs
analyze_tx_logs

# 4. Check spreads
check_recent_spreads

# 5. Cache current balances
cache_balance "$POL_BALANCE" "$USDC_BALANCE" "$NATIVE_BALANCE"

log "INFO" "Monitor run complete."
exit 0
