| 序号 | 修改项 | 修改原因 |
|------|--------|----------|
| 1 | 将 `workspace_files` 中的 `path:` 改为 `dest:` | 符合本批数据规范，避免使用旧字段 |
| 2 | 重写 `## Prompt` | 原 Prompt 描述的 bug 与真实 workflow 文件不一致 |
| 3 | 重写 `## Expected Behavior` | 原 Expected Behavior 基于不存在的字段 bug，无法作为真实 ground truth |
| 4 | 重写 `## Grading Criteria` | 原评分标准检查错误目标，不能有效评测实际修复 |
| 5 | 重写 `## Automated Checks` 中的 `grade()` | 原自动评分逻辑与实际 Assets 严重错位，需改为检查真实 workflow 中的解析修复 |
| 6 | 重写 `## LLM Judge Rubric` | 原 rubric 围绕错误问题陈述，需与实际任务目标对齐 |
| 7 | 保留 `AWS_Blog_Monitor_RSS.json` 资产不改 | Assets 本身结构真实、可解析，问题主要在任务文档与其错配 |