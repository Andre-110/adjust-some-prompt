---
id: task_00332_n8n_workflow_rss_bug_fix
name: Debug and Fix n8n AWS Blog Monitor RSS Workflow
category: Data Analysis and Modeling
subcategory: Data Processing and Management
difficulty: hard
grading_type: hybrid
grading_weights: {automated: 0.4, llm_judge: 0.6}
timeout_seconds: 600
input_modality: text-only
external_dependency: none
workspace_files:
  - source: AWS_Blog_Monitor_RSS.json
    dest: AWS_Blog_Monitor_RSS.json
  - source: aws_blog_monitor.py
    dest: aws_blog_monitor.py
  - source: test_aws_parser.py
    dest: test_aws_parser.py
  - source: skills/n8n/SKILL.md
    dest: skills/n8n/SKILL.md
  - source: skills/n8n-workflow-automation/SKILL.md
    dest: skills/n8n-workflow-automation/SKILL.md
skill_creation: false
---

## Prompt

I need help fixing an n8n workflow in `AWS_Blog_Monitor_RSS.json` that monitors the AWS blog RSS feed.

The main problem is in the **"Extract Article Links"** code node. Right now it tries to parse the RSS XML with a very brittle regex, and the code comments already hint at the issues: it does not handle CDATA or namespaced content well, it misses article titles, and it may fail on some `<link>` variations.

Please update the workflow so that the **"Extract Article Links"** node extracts article URLs and titles more reliably from the RSS response, while keeping the workflow JSON valid.

You can use `aws_blog_monitor.py` as a reference for how the feed is handled more robustly, and update `test_aws_parser.py` if you think extra coverage is useful.

Also create a short `fix_summary.md` describing:
- what was broken,
- what you changed,
- and why the new extraction is more reliable.

## Expected Behavior

The agent should:

1. Read `AWS_Blog_Monitor_RSS.json` and inspect the **"Extract Article Links"** code node.
2. Notice that the current implementation is fragile because it:
   - uses a regex that only extracts `<link>...</link>` values,
   - does not extract article titles correctly (it hardcodes `"Unknown"`),
   - relies on brittle XML parsing logic that can break on CDATA, namespaced tags, or format variations.
3. Read `aws_blog_monitor.py` as a reference showing that feed parsing should be done in a structured, robust way rather than with simplistic string matching.
4. Modify `AWS_Blog_Monitor_RSS.json` so the **"Extract Article Links"** node is improved. Acceptable fixes include:
   - using more robust parsing logic for RSS items,
   - extracting both URL and title from each item,
   - avoiding the original brittle single-regex approach,
   - preserving valid n8n workflow JSON structure.
5. Keep downstream compatibility so the node still returns objects usable by later workflow steps, with at least:
   - `url`
   - `title`
6. Create `fix_summary.md` summarizing the issue and the fix.
7. Optionally update `test_aws_parser.py` with additional tests, but this is not required for full credit.

## Grading Criteria

- [ ] `AWS_Blog_Monitor_RSS.json` remains valid JSON after modification
- [ ] The **"Extract Article Links"** node is modified
- [ ] The brittle original `<link>`-only regex approach is removed or meaningfully improved
- [ ] The node now extracts article titles instead of hardcoding `"Unknown"`
- [ ] The node still returns items containing a usable `url`
- [ ] `fix_summary.md` is created and explains the fix

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    import json
    from pathlib import Path

    scores = {
        "workflow_json_valid": 0.0,
        "extract_node_modified": 0.0,
        "brittle_regex_fixed": 0.0,
        "title_extraction_fixed": 0.0,
        "url_output_preserved": 0.0,
        "fix_summary_created": 0.0,
    }

    ws = Path(workspace_path)
    workflow_path = ws / "AWS_Blog_Monitor_RSS.json"

    if not workflow_path.exists():
        return scores

    try:
        workflow = json.loads(workflow_path.read_text())
        scores["workflow_json_valid"] = 1.0
    except Exception:
        return scores

    extract_node = None
    for node in workflow.get("nodes", []):
        name = node.get("name", "").lower()
        if "extract" in name and "article" in name:
            extract_node = node
            break

    if extract_node is None:
        return scores

    params = extract_node.get("parameters", {})
    code = params.get("jsCode", "") or params.get("functionCode", "") or params.get("code", "")
    if not code:
        return scores

    code_lower = code.lower()

    original_signatures = [
        "const linkpattern = /<link>([^<]+)<\\/link>/g;",
        "title: 'unknown'",
        "title: \"unknown\"",
    ]

    changed_markers = 0
    if "linkpattern" not in code_lower:
        changed_markers += 1
    if "'unknown'" not in code_lower and '"unknown"' not in code_lower:
        changed_markers += 1
    if "xmldata" in code_lower and ("title" in code_lower or "matchall" in code_lower or "item" in code_lower):
        changed_markers += 1

    if changed_markers >= 2:
        scores["extract_node_modified"] = 1.0
    elif changed_markers == 1:
        scores["extract_node_modified"] = 0.5

    if "const linkpattern = /<link>([^<]+)<\\/link>/g;" not in code:
        if any(marker in code_lower for marker in ["matchall", "<item", "title", "parser", "xml", "cdata"]):
            scores["brittle_regex_fixed"] = 1.0
        else:
            scores["brittle_regex_fixed"] = 0.5

    if "'unknown'" not in code_lower and '"unknown"' not in code_lower:
        if "title" in code_lower:
            scores["title_extraction_fixed"] = 1.0
        else:
            scores["title_extraction_fixed"] = 0.5

    if "url" in code_lower:
        scores["url_output_preserved"] = 1.0

    summary_path = ws / "fix_summary.md"
    if summary_path.exists():
        try:
            content = summary_path.read_text().strip()
            if len(content) > 50:
                scores["fix_summary_created"] = 1.0
            elif len(content) > 10:
                scores["fix_summary_created"] = 0.5
        except Exception:
            pass

    return scores
```

## LLM Judge Rubric

### Bug Analysis and Grounding (Weight: 25%)
- 1.0: Correctly explains that the real issue is brittle RSS/XML parsing in the "Extract Article Links" node, including missing title extraction and regex fragility, with evidence from the workspace
- 0.75: Identifies the main parsing problem and at least one concrete consequence
- 0.5: Identifies only part of the real issue or gives a partly generic explanation
- 0.25: Provides minimal analysis with weak grounding in the actual files
- 0.0: Misidentifies the task or describes bugs that are not present in the workspace

### Code Fix Quality (Weight: 35%)
- 1.0: The updated node uses materially more robust extraction logic, captures both URL and title, and keeps the workflow valid
- 0.75: The fix improves reliability and captures title/url, but still has some minor fragility
- 0.5: The fix partially improves extraction but leaves important issues unresolved
- 0.25: Minimal or superficial edits with little functional improvement
- 0.0: No valid fix or the workflow JSON is broken

### Workspace Use and Consistency (Weight: 20%)
- 1.0: The response is clearly based on the actual workflow and references `aws_blog_monitor.py` appropriately
- 0.75: Uses the workflow correctly and makes reasonable use of the reference file
- 0.5: Uses some workspace context but misses important file-specific details
- 0.25: Barely engages with the provided files
- 0.0: Ignores the workspace contents

### Documentation and Summary (Weight: 20%)
- 1.0: `fix_summary.md` clearly describes the original bug, the implemented fix, and why it is more reliable
- 0.75: Summary is complete but somewhat brief
- 0.5: Summary exists but lacks detail on either the bug or the reasoning
- 0.25: Summary is very minimal
- 0.0: No useful summary file