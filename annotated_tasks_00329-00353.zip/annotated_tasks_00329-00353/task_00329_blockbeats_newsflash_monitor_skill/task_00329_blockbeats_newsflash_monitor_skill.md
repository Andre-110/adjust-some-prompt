---
id: task_00329_blockbeats_newsflash_monitor_skill
name: BlockBeats Newsflash Monitor Skill Creation
category: Workflow and Agent Orchestration
subcategory: Script and Terminal Automation
difficulty: medium
grading_type: hybrid
grading_weights: {automated: 0.4, llm_judge: 0.6}
timeout_seconds: 600
input_modality: text-only
external_dependency: none
skill_creation: true
workspace_files:
  - source: scripts/blockbeats_monitor.py
    dest: scripts/blockbeats_monitor.py
  - source: scripts/price_tracker.py
    dest: scripts/price_tracker.py
  - source: config/monitor_config.json
    dest: config/monitor_config.json
  - source: config/webhook_templates.yaml
    dest: config/webhook_templates.yaml
  - source: data/seen_ids.json
    dest: data/seen_ids.json
  - source: data/notifications.log
    dest: data/notifications.log
  - source: requirements.txt
    dest: requirements.txt
---

## Prompt

Hey — I want a reusable OpenClaw skill for monitoring crypto newsflashes from BlockBeats.

There’s already an implementation in `scripts/blockbeats_monitor.py`, plus supporting config in `config/monitor_config.json` and `config/webhook_templates.yaml`. Please turn this into a proper OpenClaw skill by creating `skills/blockbeats-newsflash-monitor/SKILL.md`.

The skill file should include YAML frontmatter with at least `name` and `description`, and clear instruction sections that explain:

- what the skill does
- how to invoke the monitor script
- how deduplication works using `data/seen_ids.json`
- how notifications/logging work, including `data/notifications.log`
- any important config knobs from `config/monitor_config.json`

Please inspect the existing workspace files and ground the skill in the actual implementation rather than inventing a generic description.

Do **not** rely on live network access for this task. You do **not** need to execute the monitor against the real BlockBeats API. Instead, after creating the skill, give me a short summary of how the current monitor works based on the existing script/config/log files, including what state is already present in `data/seen_ids.json` and `data/notifications.log`.

## Expected Behavior

The agent should:

1. **Inspect the existing implementation files**:
   - `scripts/blockbeats_monitor.py`
   - `config/monitor_config.json`
   - `config/webhook_templates.yaml`
   - `data/seen_ids.json`
   - `data/notifications.log`

2. **Create the skill file at the OpenClaw skill path**:
   - `skills/blockbeats-newsflash-monitor/SKILL.md`

3. **Write valid YAML frontmatter** in `SKILL.md` containing at least:
   - `name`
   - `description`

4. **Document the real workflow implemented in the script**, including:
   - the BlockBeats API endpoint is configured via `config/monitor_config.json`
   - the monitor fetches recent items, deduplicates against IDs stored in `data/seen_ids.json`
   - notifications can go to stdout, webhook, and file channels
   - file logging appends formatted entries to `data/notifications.log`
   - optional usage such as `python3 scripts/blockbeats_monitor.py --config config/monitor_config.json`
   - mention of `--dry-run`

5. **Accurately reflect the current workspace state**:
   - `data/seen_ids.json` is already populated under the `seen_ids` key
   - `data/notifications.log` already contains prior notification entries
   - the implementation script uses `requests`, not `urllib`

6. **Provide a concise conversational summary** in the final response describing:
   - that the skill was created
   - how the monitor works
   - that existing state/log data were reviewed
   - a brief mention of the current stored seen-ID count and that notifications are already logged

The agent should **not** be required to fetch live data or mutate the existing state files for full credit.

## Grading Criteria

- [ ] `skills/blockbeats-newsflash-monitor/SKILL.md` exists with valid YAML frontmatter containing `name` and `description`
- [ ] `SKILL.md` contains substantive, workspace-grounded instructions about fetching, deduplication, configuration, and logging
- [ ] `SKILL.md` references the actual script/config/log paths present in the workspace
- [ ] The response correctly describes the current `data/seen_ids.json` state structure and existing log presence
- [ ] The response provides a concise summary of how to invoke and use the monitor

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    import os
    import json
    import re
    from pathlib import Path

    scores = {
        "skill_md_exists_and_frontmatter": 0.0,
        "skill_md_content_quality": 0.0,
        "workspace_grounding_paths": 0.0,
        "state_file_understanding": 0.0,
        "summary_response": 0.0,
    }

    ws = Path(workspace_path)
    skill_path = ws / "skills" / "blockbeats-newsflash-monitor" / "SKILL.md"

    if not skill_path.exists():
        return scores

    content = skill_path.read_text(encoding="utf-8", errors="replace")

    # 1. Check SKILL.md exists and has YAML frontmatter with name and description
    has_frontmatter = content.strip().startswith("---")
    frontmatter_match = re.search(r"^---\s*\n(.*?)\n---", content, re.DOTALL)
    if frontmatter_match:
        fm = frontmatter_match.group(1)
        has_name = bool(re.search(r"(?mi)^\s*name\s*:\s*.+$", fm))
        has_desc = bool(re.search(r"(?mi)^\s*description\s*:\s*.+$", fm))
        if has_name and has_desc:
            scores["skill_md_exists_and_frontmatter"] = 1.0
        elif has_name or has_desc:
            scores["skill_md_exists_and_frontmatter"] = 0.5
        else:
            scores["skill_md_exists_and_frontmatter"] = 0.2
    elif has_frontmatter:
        scores["skill_md_exists_and_frontmatter"] = 0.2

    # 2. Check substantive content
    body = content
    fm_end = content.find("---", 3)
    if fm_end > 0:
        body = content[fm_end + 3:]

    quality_signals = 0
    if len(body.strip()) > 250:
        quality_signals += 1
    if re.search(r"(blockbeats|newsflash|open-api|monitor)", body, re.IGNORECASE):
        quality_signals += 1
    if re.search(r"(dedup|seen_ids|duplicate)", body, re.IGNORECASE):
        quality_signals += 1
    if re.search(r"(log|notification|stdout|webhook)", body, re.IGNORECASE):
        quality_signals += 1
    if re.search(r"(##|###)\s+\w+", body):
        quality_signals += 1
    scores["skill_md_content_quality"] = min(quality_signals / 5.0, 1.0)

    # 3. Check grounding to actual workspace paths
    grounding_signals = 0
    for p in [
        "scripts/blockbeats_monitor.py",
        "config/monitor_config.json",
        "data/seen_ids.json",
        "data/notifications.log",
    ]:
        if p in content:
            grounding_signals += 1
    if "python3 scripts/blockbeats_monitor.py" in content:
        grounding_signals += 1
    scores["workspace_grounding_paths"] = min(grounding_signals / 5.0, 1.0)

    # 4. Check state file understanding from workspace files and/or response
    seen_ids_path = ws / "data" / "seen_ids.json"
    notif_path = ws / "data" / "notifications.log"
    if seen_ids_path.exists() and notif_path.exists():
        try:
            data = json.loads(seen_ids_path.read_text(encoding="utf-8", errors="replace"))
            if isinstance(data, dict) and isinstance(data.get("seen_ids"), list) and len(data["seen_ids"]) > 0:
                scores["state_file_understanding"] = 0.5
                if notif_path.read_text(encoding="utf-8", errors="replace").strip():
                    scores["state_file_understanding"] = 1.0
        except Exception:
            scores["state_file_understanding"] = 0.0

    # 5. Check assistant summary
    for event in transcript:
        if event.get("type") != "message":
            continue
        msg = event.get("message", {})
        if msg.get("role") != "assistant":
            continue
        text = msg.get("content", "") or ""
        if isinstance(text, list):
            text = " ".join(str(t) for t in text)

        signals = 0
        if re.search(r"(created|wrote).*(skill|SKILL\.md)", text, re.IGNORECASE):
            signals += 1
        if re.search(r"(seen_ids|data/seen_ids\.json)", text, re.IGNORECASE):
            signals += 1
        if re.search(r"(notifications\.log|log entries|logged)", text, re.IGNORECASE):
            signals += 1
        if re.search(r"(python3\s+scripts/blockbeats_monitor\.py|--dry-run|monitor works)", text, re.IGNORECASE):
            signals += 1

        if signals >= 4:
            scores["summary_response"] = 1.0
            break
        elif signals == 3:
            scores["summary_response"] = 0.75
        elif signals == 2:
            scores["summary_response"] = max(scores["summary_response"], 0.5)
        elif signals == 1:
            scores["summary_response"] = max(scores["summary_response"], 0.25)

    return scores
```

## LLM Judge Rubric

### SKILL.md Quality and Structure (Weight: 30%)
- 1.0: `skills/blockbeats-newsflash-monitor/SKILL.md` has proper YAML frontmatter with `name` and `description`, multiple well-organized markdown sections, and clearly explains usage, configuration, deduplication, and logging based on the actual workspace implementation.
- 0.75: Skill file is solid and mostly complete but misses one important aspect such as config details, `--dry-run`, or logging behavior.
- 0.5: Skill file exists with basic frontmatter and some relevant instructions, but content is thin or only partially grounded in the real files.
- 0.25: Skill file exists but is minimal, poorly structured, or weakly related to the actual implementation.
- 0.0: No relevant skill file created.

### Workspace Grounding and Accuracy (Weight: 30%)
- 1.0: The response and skill accurately reference the real script, config, and state/log files in the workspace, including the fact that `seen_ids.json` is a dict containing `seen_ids` and `updated_at`.
- 0.75: Mostly grounded in the workspace with only minor inaccuracies.
- 0.5: Some grounding is present, but there are notable mismatches in paths, file structure, or implementation details.
- 0.25: Limited grounding; much of the response appears generic or partially hallucinated.
- 0.0: Ignores the provided workspace or invents nonexistent files/behavior.

### Operational Understanding (Weight: 20%)
- 1.0: Clearly explains how the monitor fetches items, deduplicates, formats notifications, and writes logs, including invocation details and key config knobs.
- 0.75: Demonstrates good understanding with minor omissions.
- 0.5: Basic description is correct but lacks important operational details.
- 0.25: Only superficial understanding of the monitor behavior.
- 0.0: Incorrect or missing explanation.

### Summary and Communication (Weight: 20%)
- 1.0: Gives a concise, helpful final summary stating the skill was created and summarizing current workspace state/logging clearly.
- 0.75: Good summary with minor omissions.
- 0.5: Adequate but vague summary.
- 0.25: Minimal or unclear communication.
- 0.0: No meaningful summary.
```