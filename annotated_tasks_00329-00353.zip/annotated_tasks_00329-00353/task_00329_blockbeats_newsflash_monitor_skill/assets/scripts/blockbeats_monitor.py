#!/usr/bin/env python3
"""
BlockBeats Newsflash Monitor
Fetches latest crypto newsflash items from the BlockBeats open API,
deduplicates against previously seen IDs, and forwards new items
to configured notification channels.

Usage:
    python3 scripts/blockbeats_monitor.py [--config config/monitor_config.json]

Designed to be run periodically via cron or OpenClaw scheduled task.
"""

import argparse
import html
import json
import os
import re
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

import requests

SCRIPT_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = SCRIPT_DIR.parent
DEFAULT_CONFIG = PROJECT_ROOT / "config" / "monitor_config.json"
STATE_FILE = PROJECT_ROOT / "data" / "seen_ids.json"


def load_config(config_path: str | None = None) -> dict:
    """Load monitor configuration from JSON file."""
    path = Path(config_path) if config_path else DEFAULT_CONFIG
    if not path.exists():
        print(f"[ERROR] Config file not found: {path}", file=sys.stderr)
        sys.exit(1)
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def load_seen_ids() -> set:
    """Load previously seen newsflash IDs from state file."""
    if not STATE_FILE.exists():
        return set()
    with open(STATE_FILE, "r", encoding="utf-8") as f:
        data = json.load(f)
    return set(data.get("seen_ids", []))


def save_seen_ids(seen_ids: set) -> None:
    """Persist seen newsflash IDs to state file."""
    STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
    # Keep only the most recent 500 IDs to avoid unbounded growth
    ids_list = sorted(seen_ids, reverse=True)[:500]
    with open(STATE_FILE, "w", encoding="utf-8") as f:
        json.dump({"seen_ids": ids_list, "updated_at": datetime.now(timezone.utc).isoformat()}, f, indent=2)


def strip_html(text: str) -> str:
    """Remove HTML tags and decode entities."""
    text = re.sub(r"<br\s*/?>", "\n", text)
    text = re.sub(r"<[^>]+>", "", text)
    text = html.unescape(text)
    return text.strip()


def fetch_newsflash(config: dict) -> list[dict]:
    """Fetch latest newsflash items from BlockBeats API."""
    api_url = config["api"]["base_url"]
    params = {
        "size": config["api"].get("page_size", 20),
        "page": 1,
        "type": config["api"].get("flash_type", "push"),
    }
    headers = {
        "User-Agent": "BlockBeatsMonitor/1.0",
        "Accept": "application/json",
    }

    try:
        resp = requests.get(api_url, params=params, headers=headers, timeout=config["api"].get("timeout", 15))
        resp.raise_for_status()
        payload = resp.json()
    except requests.RequestException as e:
        print(f"[ERROR] API request failed: {e}", file=sys.stderr)
        return []

    if payload.get("status") != 0:
        print(f"[ERROR] API returned status {payload.get('status')}: {payload.get('message')}", file=sys.stderr)
        return []

    items = payload.get("data", {}).get("data", [])
    return items


def format_newsflash(item: dict, config: dict) -> str:
    """Format a single newsflash item for notification."""
    title = item.get("title", "Untitled")
    content = strip_html(item.get("content", ""))
    link = item.get("link", "")
    ts = int(item.get("create_time", 0))
    time_str = datetime.fromtimestamp(ts, tz=timezone.utc).strftime("%Y-%m-%d %H:%M UTC") if ts else "Unknown"

    template = config.get("notification", {}).get("template", "default")

    if template == "compact":
        msg = f"📰 {title}\n🕐 {time_str}"
        if link:
            msg += f"\n🔗 {link}"
    else:
        msg = f"🔔 BlockBeats Newsflash\n\n📰 {title}\n\n{content}"
        if link:
            msg += f"\n\n🔗 {link}"
        msg += f"\n🕐 {time_str}"

    return msg


def notify(message: str, config: dict) -> None:
    """Send notification via configured channels."""
    channels = config.get("notification", {}).get("channels", [])

    for channel in channels:
        ch_type = channel.get("type")

        if ch_type == "webhook":
            _notify_webhook(message, channel)
        elif ch_type == "stdout":
            print(message)
            print("---")
        elif ch_type == "file":
            _notify_file(message, channel)
        else:
            print(f"[WARN] Unknown notification channel type: {ch_type}", file=sys.stderr)


def _notify_webhook(message: str, channel: dict) -> None:
    """Send notification via webhook (e.g., Feishu, Discord, Slack)."""
    url = channel.get("url")
    if not url:
        print("[WARN] Webhook URL not configured", file=sys.stderr)
        return

    payload_format = channel.get("format", "text")
    if payload_format == "feishu":
        payload = {
            "msg_type": "text",
            "content": {"text": message},
        }
    elif payload_format == "discord":
        payload = {"content": message}
    elif payload_format == "slack":
        payload = {"text": message}
    else:
        payload = {"text": message}

    try:
        resp = requests.post(url, json=payload, timeout=10)
        resp.raise_for_status()
    except requests.RequestException as e:
        print(f"[ERROR] Webhook notification failed: {e}", file=sys.stderr)


def _notify_file(message: str, channel: dict) -> None:
    """Append notification to a log file."""
    filepath = Path(channel.get("path", "data/notifications.log"))
    filepath.parent.mkdir(parents=True, exist_ok=True)
    with open(filepath, "a", encoding="utf-8") as f:
        f.write(f"[{datetime.now(timezone.utc).isoformat()}]\n{message}\n{'='*60}\n\n")


def run_monitor(config: dict) -> int:
    """Main monitor loop: fetch, deduplicate, notify."""
    print(f"[INFO] BlockBeats monitor running at {datetime.now(timezone.utc).isoformat()}")

    items = fetch_newsflash(config)
    if not items:
        print("[INFO] No newsflash items retrieved.")
        return 0

    seen_ids = load_seen_ids()
    new_items = []

    for item in items:
        item_id = item.get("id")
        if item_id and item_id not in seen_ids:
            new_items.append(item)
            seen_ids.add(item_id)

    if not new_items:
        print(f"[INFO] No new items (checked {len(items)} items, all previously seen).")
        return 0

    print(f"[INFO] Found {len(new_items)} new newsflash item(s).")

    # Sort by creation time ascending so oldest fires first
    new_items.sort(key=lambda x: int(x.get("create_time", 0)))

    count = 0
    for item in new_items:
        message = format_newsflash(item, config)
        notify(message, config)
        count += 1
        # Rate-limit between notifications
        delay = config.get("notification", {}).get("delay_seconds", 1)
        if delay > 0 and count < len(new_items):
            time.sleep(delay)

    save_seen_ids(seen_ids)
    print(f"[INFO] Processed {count} new newsflash item(s). State saved.")
    return count


def main():
    parser = argparse.ArgumentParser(description="BlockBeats Newsflash Monitor")
    parser.add_argument("--config", type=str, help="Path to config file", default=None)
    parser.add_argument("--dry-run", action="store_true", help="Fetch and display without notifying")
    args = parser.parse_args()

    config = load_config(args.config)

    if args.dry_run:
        config.setdefault("notification", {})["channels"] = [{"type": "stdout"}]

    new_count = run_monitor(config)
    sys.exit(0 if new_count >= 0 else 1)


if __name__ == "__main__":
    main()
