#!/usr/bin/env python3
"""
Crypto Price Tracker (DEPRECATED)
----------------------------------
This script was previously used for real-time price monitoring via CoinGecko API.
Replaced by the BlockBeats newsflash monitor for news-driven alerts.
Kept for reference only.

Usage:
    python3 scripts/price_tracker.py --coins bitcoin,ethereum --interval 60
"""

import argparse
import json
import sys
import time
from datetime import datetime, timezone

import requests

COINGECKO_API = "https://api.coingecko.com/api/v3"


def fetch_prices(coins: list[str], vs_currency: str = "usd") -> dict:
    """Fetch current prices from CoinGecko."""
    url = f"{COINGECKO_API}/simple/price"
    params = {
        "ids": ",".join(coins),
        "vs_currencies": vs_currency,
        "include_24hr_change": "true",
    }
    resp = requests.get(url, params=params, timeout=10)
    resp.raise_for_status()
    return resp.json()


def format_price_alert(data: dict, thresholds: dict) -> str | None:
    """Generate alert message if price change exceeds threshold."""
    alerts = []
    for coin, info in data.items():
        change = info.get("usd_24h_change", 0) or 0
        threshold = thresholds.get(coin, 5.0)
        if abs(change) >= threshold:
            direction = "📈" if change > 0 else "📉"
            alerts.append(f"{direction} {coin.upper()}: ${info['usd']:,.2f} ({change:+.1f}% 24h)")
    return "\n".join(alerts) if alerts else None


def main():
    parser = argparse.ArgumentParser(description="Crypto Price Tracker")
    parser.add_argument("--coins", default="bitcoin,ethereum,solana", help="Comma-separated coin IDs")
    parser.add_argument("--interval", type=int, default=300, help="Check interval in seconds")
    parser.add_argument("--threshold", type=float, default=5.0, help="Alert threshold (% change)")
    args = parser.parse_args()

    coins = args.coins.split(",")
    thresholds = {c: args.threshold for c in coins}

    print(f"[INFO] Tracking: {', '.join(coins)} | Interval: {args.interval}s | Threshold: {args.threshold}%")

    while True:
        try:
            data = fetch_prices(coins)
            alert = format_price_alert(data, thresholds)
            if alert:
                print(f"\n[{datetime.now(timezone.utc).isoformat()}] ALERT:\n{alert}")
            else:
                print(f"[{datetime.now(timezone.utc).isoformat()}] No significant changes.")
        except Exception as e:
            print(f"[ERROR] {e}", file=sys.stderr)
        time.sleep(args.interval)


if __name__ == "__main__":
    main()
