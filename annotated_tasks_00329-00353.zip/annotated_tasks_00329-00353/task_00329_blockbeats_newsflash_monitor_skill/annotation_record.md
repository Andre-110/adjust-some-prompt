| 序号 | 修改项 | 修改原因 |
|---|---|---|
| 1 | 将 `workspace_files` 从旧字段 `path:` 改为 `dest:` 列表 | 符合本批数据规范，避免旧格式 |
| 2 | 删除 frontmatter 中与真实 Assets 冲突的内联文件定义 | 原内联 `scripts/monitor.py` / `config/settings.json` / 空状态文件与实际资产不一致 |
| 3 | 将技能输出路径从 `SKILL.md` 改为 `skills/blockbeats-newsflash-monitor/SKILL.md` | 符合 OpenClaw skill 路径规范 |
| 4 | 将 Prompt 中引用的脚本和配置改为 `scripts/blockbeats_monitor.py`、`config/monitor_config.json`、`config/webhook_templates.yaml` | 与实际 Assets 一致 |
| 5 | 移除“必须真实执行并抓取最新新闻”的要求，改为基于现有 workspace 文件创建技能并总结当前实现 | 避免依赖实时联网，保证 `external_dependency: none` 与可评测性 |
| 6 | 修改 Expected Behavior，使其反映真实状态文件结构：`data/seen_ids.json` 为 dict，含 `seen_ids` 和 `updated_at` | 与 Assets 一致 |
| 7 | 重写 Grading Criteria，使其聚焦技能文件质量与 workspace grounding，而非在线抓取结果 | 提升稳定性与可判定性 |
| 8 | 重写 `grade()`，检查正确的 skill 路径、真实文件引用与状态理解，并保留部分得分 | 修复原 grader 与路径/任务目标不一致的问题 |
| 9 | 调整 LLM Judge Rubric，使其评估技能质量、工作区一致性、操作理解和总结质量 | 与修正后的任务目标对齐 |
| 10 | 建议替换 `config/monitor_config.json` 中 webhook URL 为 `example.invalid` 占位地址 | 避免潜在敏感信息/真实凭据风险 |