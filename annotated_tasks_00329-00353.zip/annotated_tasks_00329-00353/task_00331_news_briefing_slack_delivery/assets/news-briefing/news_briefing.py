#!/usr/bin/env python3
"""
Daily News Briefing Generator
Fetches top headlines from multiple sources and formats a concise briefing.
"""

import json
import os
import sys
import datetime
import urllib.request
import urllib.error
from pathlib import Path

CONFIG_PATH = Path(__file__).parent / "config.json"
CACHE_DIR = Path(__file__).parent / "cache"


def load_config():
    """Load configuration from config.json."""
    if not CONFIG_PATH.exists():
        print("ERROR: config.json not found", file=sys.stderr)
        sys.exit(1)
    with open(CONFIG_PATH) as f:
        return json.load(f)


def fetch_newsapi(api_key, categories=None, country="us", page_size=5):
    """Fetch top headlines from NewsAPI.org."""
    headlines = []
    cats = categories or ["general", "technology", "business"]
    for cat in cats:
        url = (
            f"https://newsapi.org/v2/top-headlines?"
            f"country={country}&category={cat}&pageSize={page_size}"
        )
        req = urllib.request.Request(url, headers={"X-Api-Key": api_key})
        try:
            with urllib.request.urlopen(req, timeout=15) as resp:
                data = json.loads(resp.read().decode())
                if data.get("status") == "ok":
                    for article in data.get("articles", []):
                        headlines.append({
                            "title": article.get("title", ""),
                            "source": article.get("source", {}).get("name", "Unknown"),
                            "url": article.get("url", ""),
                            "description": article.get("description", ""),
                            "category": cat,
                        })
        except urllib.error.URLError as e:
            print(f"Warning: Failed to fetch {cat} news: {e}", file=sys.stderr)
    return headlines


def fetch_rss_fallback(feeds):
    """Fallback: fetch from RSS feeds if NewsAPI is unavailable."""
    import xml.etree.ElementTree as ET

    headlines = []
    for feed_url in feeds:
        try:
            req = urllib.request.Request(
                feed_url,
                headers={"User-Agent": "NewsBriefing/1.0"}
            )
            with urllib.request.urlopen(req, timeout=10) as resp:
                tree = ET.parse(resp)
                root = tree.getroot()
                # Handle both RSS and Atom
                ns = {"atom": "http://www.w3.org/2005/Atom"}
                items = root.findall(".//item") or root.findall(".//atom:entry", ns)
                for item in items[:5]:
                    title = item.findtext("title") or item.findtext("atom:title", namespaces=ns)
                    link = item.findtext("link") or ""
                    desc = item.findtext("description") or item.findtext("atom:summary", namespaces=ns) or ""
                    if title:
                        headlines.append({
                            "title": title.strip(),
                            "source": feed_url.split("/")[2],
                            "url": link.strip(),
                            "description": desc[:200].strip(),
                            "category": "general",
                        })
        except Exception as e:
            print(f"Warning: Failed to fetch RSS {feed_url}: {e}", file=sys.stderr)
    return headlines


def deduplicate(headlines):
    """Remove duplicate headlines by title similarity."""
    seen_titles = set()
    unique = []
    for h in headlines:
        normalized = h["title"].lower().strip()
        if normalized not in seen_titles and len(normalized) > 10:
            seen_titles.add(normalized)
            unique.append(h)
    return unique


def format_briefing(headlines, date_str):
    """Format headlines into a readable briefing message."""
    if not headlines:
        return f"📰 *News Briefing — {date_str}*\n\nNo headlines available today. Check back later."

    lines = [f"📰 *News Briefing — {date_str}*\n"]

    # Group by category
    categories = {}
    for h in headlines:
        cat = h.get("category", "general").title()
        categories.setdefault(cat, []).append(h)

    for cat, items in categories.items():
        lines.append(f"\n*{cat}*")
        for item in items[:5]:
            title = item["title"]
            source = item["source"]
            url = item.get("url", "")
            if url:
                lines.append(f"• <{url}|{title}> — _{source}_")
            else:
                lines.append(f"• {title} — _{source}_")

    lines.append(f"\n_Generated at {datetime.datetime.now().strftime('%H:%M %Z')}_")
    return "\n".join(lines)


def save_cache(headlines, date_str):
    """Cache today's briefing for deduplication."""
    CACHE_DIR.mkdir(exist_ok=True)
    cache_file = CACHE_DIR / f"{date_str}.json"
    with open(cache_file, "w") as f:
        json.dump(headlines, f, ensure_ascii=False, indent=2)
    # Clean old cache files (keep last 7 days)
    for old_file in sorted(CACHE_DIR.glob("*.json"))[:-7]:
        old_file.unlink()


def main():
    config = load_config()
    today = datetime.date.today().isoformat()

    newsapi_key = config.get("newsapi_key", "") or os.environ.get("NEWSAPI_KEY", "")
    categories = config.get("categories", ["general", "technology", "business"])
    country = config.get("country", "us")
    rss_feeds = config.get("rss_feeds", [])

    headlines = []

    # Try NewsAPI first
    if newsapi_key:
        headlines = fetch_newsapi(newsapi_key, categories, country)

    # Fallback to RSS
    if not headlines and rss_feeds:
        headlines = fetch_rss_fallback(rss_feeds)

    headlines = deduplicate(headlines)
    save_cache(headlines, today)

    briefing = format_briefing(headlines, today)
    print(briefing)


if __name__ == "__main__":
    main()
