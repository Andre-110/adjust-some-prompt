"""
Helper utilities for the news briefing pipeline.
Includes text cleaning, Slack formatting, and analytics.
"""

import re
import html
import datetime
from typing import List, Dict, Optional


def clean_html(raw_html: str) -> str:
    """Strip HTML tags and decode entities from RSS descriptions."""
    text = re.sub(r"<[^>]+>", "", raw_html)
    text = html.unescape(text)
    return text.strip()


def truncate(text: str, max_len: int = 200) -> str:
    """Truncate text to max_len characters with ellipsis."""
    if len(text) <= max_len:
        return text
    return text[:max_len - 1].rsplit(" ", 1)[0] + "…"


def slack_escape(text: str) -> str:
    """Escape special Slack mrkdwn characters."""
    for char in ["&", "<", ">"]:
        text = text.replace(char, {"&": "&amp;", "<": "&lt;", ">": "&gt;"}[char])
    return text


def format_slack_blocks(headlines: List[Dict], date_str: str) -> List[Dict]:
    """Format headlines as Slack Block Kit blocks for richer rendering."""
    blocks = [
        {
            "type": "header",
            "text": {
                "type": "plain_text",
                "text": f"📰 News Briefing — {date_str}",
                "emoji": True,
            },
        },
        {"type": "divider"},
    ]

    categories: Dict[str, List[Dict]] = {}
    for h in headlines:
        cat = h.get("category", "general").title()
        categories.setdefault(cat, []).append(h)

    for cat, items in categories.items():
        blocks.append({
            "type": "section",
            "text": {
                "type": "mrkdwn",
                "text": f"*{cat}*",
            },
        })
        for item in items[:5]:
            title = slack_escape(item["title"])
            source = slack_escape(item.get("source", ""))
            url = item.get("url", "")
            desc = truncate(clean_html(item.get("description", "")), 150)
            if url:
                text = f"<{url}|{title}>\n_{source}_ — {desc}"
            else:
                text = f"*{title}*\n_{source}_ — {desc}"
            blocks.append({
                "type": "section",
                "text": {"type": "mrkdwn", "text": text},
            })

    blocks.append({"type": "divider"})
    blocks.append({
        "type": "context",
        "elements": [
            {
                "type": "mrkdwn",
                "text": f"Generated at {datetime.datetime.now().strftime('%Y-%m-%d %H:%M %Z')} | News Briefing Bot v1.2",
            }
        ],
    })

    return blocks


def compute_stats(cache_dir: str, days: int = 7) -> Dict:
    """Compute basic stats from cached briefings."""
    import json
    from pathlib import Path

    stats = {"total_articles": 0, "sources": {}, "categories": {}}
    cache = Path(cache_dir)

    for f in sorted(cache.glob("*.json"))[-days:]:
        try:
            with open(f) as fh:
                articles = json.load(fh)
                stats["total_articles"] += len(articles)
                for a in articles:
                    src = a.get("source", "Unknown")
                    cat = a.get("category", "general")
                    stats["sources"][src] = stats["sources"].get(src, 0) + 1
                    stats["categories"][cat] = stats["categories"].get(cat, 0) + 1
        except (json.JSONDecodeError, IOError):
            continue

    return stats
