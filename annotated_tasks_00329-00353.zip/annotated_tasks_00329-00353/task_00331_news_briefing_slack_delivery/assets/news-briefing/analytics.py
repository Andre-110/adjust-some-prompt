#!/usr/bin/env python3
"""
News Briefing Analytics
Generates weekly reports on news coverage patterns and source distribution.
Run: python3 analytics.py [--days 7] [--output report.json]
"""

import json
import argparse
import datetime
from pathlib import Path
from collections import Counter

CACHE_DIR = Path(__file__).parent / "cache"


def load_cached_briefings(days: int = 7):
    """Load cached briefing data for the past N days."""
    articles = []
    today = datetime.date.today()
    for i in range(days):
        d = today - datetime.timedelta(days=i)
        cache_file = CACHE_DIR / f"{d.isoformat()}.json"
        if cache_file.exists():
            with open(cache_file) as f:
                try:
                    data = json.load(f)
                    for item in data:
                        item["date"] = d.isoformat()
                    articles.extend(data)
                except json.JSONDecodeError:
                    continue
    return articles


def generate_report(articles):
    """Generate analytics report from articles."""
    if not articles:
        return {"status": "no_data", "message": "No cached briefings found."}

    source_counts = Counter(a.get("source", "Unknown") for a in articles)
    category_counts = Counter(a.get("category", "general") for a in articles)
    daily_counts = Counter(a.get("date", "unknown") for a in articles)

    return {
        "period": {
            "start": min(a.get("date", "") for a in articles),
            "end": max(a.get("date", "") for a in articles),
        },
        "total_articles": len(articles),
        "unique_sources": len(source_counts),
        "top_sources": source_counts.most_common(10),
        "category_breakdown": dict(category_counts),
        "daily_counts": dict(sorted(daily_counts.items())),
        "avg_per_day": round(len(articles) / max(len(daily_counts), 1), 1),
    }


def main():
    parser = argparse.ArgumentParser(description="News briefing analytics")
    parser.add_argument("--days", type=int, default=7, help="Number of days to analyze")
    parser.add_argument("--output", type=str, default=None, help="Output file path")
    args = parser.parse_args()

    articles = load_cached_briefings(args.days)
    report = generate_report(articles)

    output = json.dumps(report, indent=2, ensure_ascii=False)

    if args.output:
        with open(args.output, "w") as f:
            f.write(output)
        print(f"Report saved to {args.output}")
    else:
        print(output)


if __name__ == "__main__":
    main()
