# News Briefing Bot

Automated daily news briefing generator. Fetches top headlines from NewsAPI and RSS feeds, formats them for Slack, and delivers them via OpenClaw's message tool.

## Setup

1. Get a NewsAPI key from https://newsapi.org
2. Update `config.json` with your API key and preferences
3. Schedule via OpenClaw cron for weekday delivery

## Usage

```bash
# Generate briefing (prints to stdout)
python3 news_briefing.py

# Run analytics on past week
python3 analytics.py --days 7

# Run analytics and save report
python3 analytics.py --days 30 --output report.json
```

## Configuration

Edit `config.json`:

| Field | Description |
|-------|-------------|
| `newsapi_key` | Your NewsAPI.org API key |
| `country` | 2-letter country code for headlines |
| `categories` | List of news categories to fetch |
| `rss_feeds` | Fallback RSS feed URLs |
| `slack_target` | Slack channel/DM ID for delivery |
| `schedule` | Cron schedule description |

## Architecture

- `news_briefing.py` — Main script, fetches and formats news
- `helpers.py` — Slack formatting, text cleaning, Block Kit support
- `analytics.py` — Weekly coverage analytics
- `config.json` — Configuration
- `cache/` — Daily headline cache (auto-cleaned, keeps 7 days)

## Delivery

Output is sent to Slack via OpenClaw's `message` tool with target `D0AAYPEMHM0`.
