---
id: task_00331_news_briefing_slack_delivery
name: Daily News Briefing Script Execution and Slack Delivery
category: Workflow and Agent Orchestration
subcategory: Workflow and Task Scheduling
difficulty: medium
grading_type: hybrid
grading_weights: {automated: 0.4, llm_judge: 0.6}
timeout_seconds: 600
input_modality: text-only
external_dependency: none
workspace_files:
  - source: news-briefing/news_briefing.py
    dest: news-briefing/news_briefing.py
  - source: news-briefing/helpers.py
    dest: news-briefing/helpers.py
  - source: news-briefing/analytics.py
    dest: news-briefing/analytics.py
  - source: news-briefing/config.json
    dest: news-briefing/config.json
  - source: news-briefing/README.md
    dest: news-briefing/README.md
  - source: news-briefing/requirements.txt
    dest: news-briefing/requirements.txt
  - source: news-briefing/cache/2026-02-09.json
    dest: news-briefing/cache/2026-02-09.json
skill_creation: false
---

## Prompt

Please run my daily news briefing script and send the result to Slack.

1. Try running `python3 news-briefing/news_briefing.py`
2. Send the script's output using the `message` tool to target `D0AAYPEMHM0`
3. If the script path is wrong, look around the workspace and find the right file
4. Give me a short summary of what you sent

If the script runs but can't fetch live news, still send the actual output it produced and tell me what happened.

## Expected Behavior

The agent should:

1. **Locate and execute the script**: Run `news-briefing/news_briefing.py` from the workspace, or find it if the first attempt fails.

2. **Capture the script output**: The script prints a formatted news briefing to stdout. The output should include a date-based heading such as `📰 *News Briefing — <YYYY-MM-DD>*` and either:
   - grouped headline entries with category headers and bullet points, or
   - a fallback message indicating that no headlines were available.

3. **Create or update a cache file**: The script writes a JSON cache file at `news-briefing/cache/<YYYY-MM-DD>.json`. The cache content is a JSON list of headline objects. Each headline object may contain fields such as `title`, `source`, `url`, `description`, and `category`. An empty list is acceptable if fetching failed.

4. **Send output to Slack target**: The agent should use the `message` tool to send the script output to target `D0AAYPEMHM0`. Even if delivery fails, the agent should make the attempt.

5. **Provide a final summary**: The agent should briefly summarize what was sent, including whether headlines were successfully fetched or whether the script produced a fallback / no-headlines message.

## Grading Criteria

- [ ] A date-stamped JSON cache file was created under `news-briefing/cache/`
- [ ] The created cache file contains valid JSON in the expected format (a list, possibly empty)
- [ ] The agent attempted to execute `news-briefing/news_briefing.py`
- [ ] The agent attempted to send a message to target `D0AAYPEMHM0`
- [ ] The final response accurately summarizes the script result

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    import json
    from pathlib import Path

    scores = {
        "cache_file_exists": 0.0,
        "cache_file_valid_json": 0.0,
        "cache_file_expected_shape": 0.0,
        "script_execution_attempted": 0.0,
        "message_tool_used": 0.0,
    }

    cache_dir = Path(workspace_path) / "news-briefing" / "cache"
    cache_files = []
    if cache_dir.exists():
        cache_files = sorted([f for f in cache_dir.iterdir() if f.suffix == ".json"])

    if cache_files:
        scores["cache_file_exists"] = 1.0
        newest = cache_files[-1]
        try:
            with open(newest, "r", encoding="utf-8") as f:
                data = json.load(f)
            scores["cache_file_valid_json"] = 1.0

            if isinstance(data, list):
                scores["cache_file_expected_shape"] = 0.5
                if len(data) == 0:
                    scores["cache_file_expected_shape"] = 1.0
                elif all(isinstance(item, dict) for item in data):
                    headline_like = 0
                    for item in data:
                        if any(k in item for k in ["title", "source", "url", "description", "category"]):
                            headline_like += 1
                    if headline_like == len(data):
                        scores["cache_file_expected_shape"] = 1.0
                    elif headline_like > 0:
                        scores["cache_file_expected_shape"] = 0.75
            elif isinstance(data, dict):
                scores["cache_file_expected_shape"] = 0.25
        except Exception:
            scores["cache_file_valid_json"] = 0.0
            scores["cache_file_expected_shape"] = 0.0

    for event in transcript:
        if event.get("type") != "message":
            continue
        msg = event.get("message", {})
        role = msg.get("role", "")
        content = str(msg.get("content", ""))

        tool_calls = msg.get("tool_calls", [])
        for tc in tool_calls or []:
            func = tc.get("function", {})
            func_name = str(func.get("name", ""))
            func_args = str(func.get("arguments", ""))

            if func_name == "exec" or "exec" in func_name:
                if "news_briefing.py" in func_args or "news-briefing" in func_args:
                    scores["script_execution_attempted"] = 1.0

            if func_name == "message" or "message" in func_name:
                if "D0AAYPEMHM0" in func_args:
                    scores["message_tool_used"] = 1.0
                elif func_args:
                    scores["message_tool_used"] = max(scores["message_tool_used"], 0.5)

        if role == "assistant":
            lower = content.lower()
            if "news_briefing.py" in content or "news-briefing" in content:
                if any(kw in lower for kw in ["run", "execut", "python"]):
                    scores["script_execution_attempted"] = max(scores["script_execution_attempted"], 0.5)

    return scores
```

## LLM Judge Rubric

### Script Execution and Problem Solving (Weight: 25%)
- 1.0: Agent successfully located and executed the script, handling any path issues appropriately
- 0.75: Agent executed the script with minor confusion or extra attempts
- 0.5: Agent made a reasonable attempt to run the script but only partially succeeded
- 0.25: Agent made only a minimal attempt to find or run the script
- 0.0: Agent did not attempt to execute the script

### News Briefing Content Quality (Weight: 25%)
- 1.0: Agent clearly captured the actual script output and represented it accurately, including the date and main content or fallback message
- 0.75: Agent captured most of the output correctly with minor omissions
- 0.5: Agent provided a partial or loosely accurate rendering of the script output
- 0.25: Agent mentioned the briefing but gave little verifiable content
- 0.0: Agent did not provide the script output or clearly hallucinated it

### Slack Delivery Attempt (Weight: 30%)
- 1.0: Agent used the `message` tool to send the script output to target `D0AAYPEMHM0`
- 0.75: Agent used the `message` tool for the correct target but sent incomplete content
- 0.5: Agent attempted Slack delivery with the wrong target or partial execution
- 0.25: Agent acknowledged the requirement but did not properly use the `message` tool
- 0.0: Agent made no Slack delivery attempt

### Evidence and Workspace Grounding (Weight: 20%)
- 1.0: Agent’s behavior is well grounded in the workspace and the resulting cache/output state
- 0.75: Most actions are grounded in workspace evidence with only minor unsupported claims
- 0.5: Some grounding is present, but parts of the response are not well supported
- 0.25: Minimal workspace grounding
- 0.0: No grounding in workspace files or execution evidence