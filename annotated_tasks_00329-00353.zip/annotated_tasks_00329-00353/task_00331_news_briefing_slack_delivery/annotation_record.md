| 序号 | 修改项 | 修改原因 |
|------|--------|----------|
| 1 | 将 frontmatter 中 `workspace_files` 从旧格式 `path:` 改为 `source` / `dest` | 现有字段不符合数据规范，且无法明确区分包内路径与 workspace 路径 |
| 2 | 修正 Prompt 中写死的绝对路径为 workspace 相对路径 `news-briefing/news_briefing.py` | 绝对路径不符合规范，也降低题目可移植性 |
| 3 | 补充 Prompt 中“如果抓取失败也要发送实际输出”的说明 | 当前脚本依赖外部网络，运行可能得到 fallback 结果，需要明确期望行为 |
| 4 | 重写 Expected Behavior 中关于脚本输出格式的描述 | 原描述称输出为 source + numbered headlines，与实际脚本输出格式不符 |
| 5 | 重写 Expected Behavior 中关于 cache 文件结构的描述 | 原描述称 cache JSON 含 `date` 和 `sources` 字段，但实际脚本写入的是 headline object 列表 |
| 6 | 调整 Grading Criteria，使其与 automated checks 和 LLM rubric 分工更一致 | 原 criteria 与 automated score keys 未完全对齐 |
| 7 | 修改 automated `grade()` 中缓存文件结构检查逻辑 | 原逻辑按错误的 JSON 结构评分，会误判 |
| 8 | 保留并强化 transcript 中脚本执行和 message tool 调用检查 | 确保核心行为可自动验证 |
| 9 | 将 `config.json` 中疑似真实格式 API key 替换为明显虚构占位值 | 避免敏感信息或仿真过强的凭证出现在数据集中 |
| 10 | 建议删除 `__pycache__/` 下 `.pyc` 文件 | 二进制缓存文件无助于任务完成，属于噪声资产 |
| 11 | 审核 `README.md`、`analytics.py`、`helpers.py` 与主脚本的一致性 | 确认 assets 整体结构合理、内容真实且可支撑任务 |