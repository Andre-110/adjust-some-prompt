| 序号 | 修改项 | 修改原因 |
|------|--------|----------|
| 1 | 修改任务名称为 `Cron Job Investigation and Graceful Handling` | 原题名强调“Missing Script”，但 Assets 中脚本实际存在，题名与事实不符 |
| 2 | 重写 Prompt，将执行路径改为 `skills/github-cr/` | 原 Prompt 使用 `/root/clawd/skills/github-cr`，与 workspace 根路径规范和实际 Assets 不一致 |
| 3 | 删除 Prompt 中“如果脚本或目录不存在”的主叙事，改为“若无法成功运行则调查原因” | 原叙事与 Assets 冲突，脚本和目录实际存在 |
| 4 | 补全 frontmatter 中的 `workspace_files` | 原字段为空，与实际提供的 Assets 不一致，不符合数据规范 |
| 5 | 重写 Expected Behavior | 原 Expected Behavior 建立在“目录/脚本缺失”前提上，与真实文件冲突；改为要求核实脚本存在、尝试执行、基于依赖/API/环境限制做真实诊断 |
| 6 | 重写 Grading Criteria | 原评分点要求模型识别“脚本缺失”，会误判正确行为；改为检查是否识别脚本存在、是否尝试执行、是否基于证据说明阻塞 |
| 7 | 重写 automated `grade()` | 原评分函数只奖励“脚本缺失”结论，与题目资产矛盾；改为检查 HEARTBEAT.md 是否说明脚本存在、执行尝试/阻塞原因、工作区证据和建议 |
| 8 | 保留 hybrid 权重与 LLM rubric 框架，但重写 rubric 内容 | 原 rubric 围绕“缺失脚本”评分，需改为对真实调查、证据引用和非伪造行为评分 |
| 9 | 审核 Assets 全部文件并确认无需修改内容 | Assets 本身结构完整、内容真实、跨文件一致，主要问题在任务文档而非环境文件 |