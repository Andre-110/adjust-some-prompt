# GitHub Code Review Monitor

A skill that periodically polls GitHub for pending code reviews, new PR comments, and review-requested events across configured repositories.

## Setup

1. Copy `config.yaml.example` to `config.yaml`
2. Set your GitHub personal access token (needs `repo` and `notifications` scopes)
3. Configure the repositories to monitor
4. Install dependencies: `npm install`

## Usage

### Manual run
```bash
node monitor-execution.js --verbose
```

### Dry run (no notifications, just print)
```bash
node monitor-execution.js --dry-run --verbose
```

### Cron integration
The monitor is designed to be called from a Clawd cron job. It outputs a markdown summary to stdout when there are pending reviews. The cron runner captures this and delivers it to the configured channel.

Example cron schedule (every 30 minutes during work hours):
```
schedule: "*/30 9-18 * * 1-5"
```

## What it monitors

- **Review requests**: PRs where you are a requested reviewer
- **New comments**: Comments on PRs you've previously reviewed  
- **Mentions**: GitHub notifications where you're mentioned in PR discussions

## State

The monitor keeps track of seen events in `data/last-run-state.json` to avoid duplicate notifications. State is automatically pruned to the last 500 events.

## Logs

Daily log files are written to `logs/monitor-YYYY-MM-DD.log`.

## Configuration

See `config.yaml` for all options. Key settings:

| Setting | Description |
|---------|-------------|
| `github.token` | Personal access token |
| `github.username` | Your GitHub username |
| `repositories` | List of `owner/repo` to monitor |
| `filters.skip_drafts` | Ignore draft PRs |
| `notifications.cooldown_minutes` | Min time between alerts |
