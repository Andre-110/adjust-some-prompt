#!/usr/bin/env node
/**
 * GitHub Code Review Monitor — Execution Script
 * 
 * Polls GitHub API for pending code reviews, new PR comments,
 * and review-requested events across configured repositories.
 * Sends notifications via configured channels when action is needed.
 * 
 * Usage: node monitor-execution.js [--dry-run] [--verbose]
 */

const fs = require('fs');
const path = require('path');
const { Octokit } = require('@octokit/rest');
const yaml = require('js-yaml');

const config = yaml.load(
  fs.readFileSync(path.join(__dirname, 'config.yaml'), 'utf8')
);

const STATE_FILE = path.join(__dirname, 'data', 'last-run-state.json');
const LOG_DIR = path.join(__dirname, 'logs');

// --- helpers ---------------------------------------------------------------

function loadState() {
  try {
    return JSON.parse(fs.readFileSync(STATE_FILE, 'utf8'));
  } catch {
    return { lastPollTimestamp: null, seenEvents: [] };
  }
}

function saveState(state) {
  fs.mkdirSync(path.dirname(STATE_FILE), { recursive: true });
  fs.writeFileSync(STATE_FILE, JSON.stringify(state, null, 2));
}

function appendLog(entry) {
  const today = new Date().toISOString().slice(0, 10);
  const logFile = path.join(LOG_DIR, `monitor-${today}.log`);
  fs.mkdirSync(LOG_DIR, { recursive: true });
  const line = `[${new Date().toISOString()}] ${JSON.stringify(entry)}\n`;
  fs.appendFileSync(logFile, line);
}

function formatTimestamp(iso) {
  return new Date(iso).toLocaleString('en-US', {
    timeZone: config.timezone || 'Asia/Shanghai',
    dateStyle: 'medium',
    timeStyle: 'short',
  });
}

// --- core ------------------------------------------------------------------

async function fetchPendingReviews(octokit, repo) {
  const [owner, name] = repo.split('/');
  const { data: pulls } = await octokit.pulls.list({
    owner,
    repo: name,
    state: 'open',
    sort: 'updated',
    direction: 'desc',
    per_page: 30,
  });

  const pending = [];

  for (const pr of pulls) {
    const { data: reviews } = await octokit.pulls.listReviews({
      owner,
      repo: name,
      pull_number: pr.number,
    });

    const { data: requestedReviewers } =
      await octokit.pulls.listRequestedReviewers({
        owner,
        repo: name,
        pull_number: pr.number,
      });

    const myUsername = config.github.username;

    const needsMyReview = requestedReviewers.users.some(
      (u) => u.login === myUsername
    );

    const latestMyReview = reviews
      .filter((r) => r.user.login === myUsername)
      .sort((a, b) => new Date(b.submitted_at) - new Date(a.submitted_at))[0];

    if (needsMyReview) {
      pending.push({
        type: 'review_requested',
        repo,
        pr_number: pr.number,
        title: pr.title,
        author: pr.user.login,
        url: pr.html_url,
        created_at: pr.created_at,
        updated_at: pr.updated_at,
      });
    }

    // Check for new comments after my last review
    if (latestMyReview) {
      const { data: comments } = await octokit.pulls.listReviewComments({
        owner,
        repo: name,
        pull_number: pr.number,
        since: latestMyReview.submitted_at,
      });

      const newReplies = comments.filter(
        (c) =>
          c.user.login !== myUsername &&
          new Date(c.created_at) > new Date(latestMyReview.submitted_at)
      );

      if (newReplies.length > 0) {
        pending.push({
          type: 'new_comments_after_review',
          repo,
          pr_number: pr.number,
          title: pr.title,
          author: pr.user.login,
          url: pr.html_url,
          comment_count: newReplies.length,
          latest_comment: newReplies[0].body.slice(0, 200),
        });
      }
    }
  }

  return pending;
}

async function fetchRecentNotifications(octokit, since) {
  const params = { all: false, per_page: 50 };
  if (since) params.since = since;

  const { data: notifications } = await octokit.activity.listNotificationsForAuthenticatedUser(params);

  return notifications
    .filter((n) => n.reason === 'review_requested' || n.reason === 'mention')
    .map((n) => ({
      id: n.id,
      reason: n.reason,
      repo: n.repository.full_name,
      title: n.subject.title,
      type: n.subject.type,
      url: n.subject.url,
      updated_at: n.updated_at,
    }));
}

function buildSummary(pendingReviews, notifications, state) {
  const newItems = [];

  for (const item of pendingReviews) {
    const key = `${item.repo}#${item.pr_number}:${item.type}`;
    if (!state.seenEvents.includes(key)) {
      newItems.push(item);
      state.seenEvents.push(key);
    }
  }

  // Trim seen events to last 500
  if (state.seenEvents.length > 500) {
    state.seenEvents = state.seenEvents.slice(-500);
  }

  if (newItems.length === 0 && notifications.length === 0) {
    return null; // nothing new
  }

  let summary = `📋 **GitHub CR Monitor** — ${formatTimestamp(new Date().toISOString())}\n\n`;

  if (newItems.length > 0) {
    summary += `### Pending Reviews (${newItems.length})\n\n`;
    for (const item of newItems) {
      if (item.type === 'review_requested') {
        summary += `- 🔍 **[${item.repo}#${item.pr_number}](${item.url})** — ${item.title}\n`;
        summary += `  Author: @${item.author} | Updated: ${formatTimestamp(item.updated_at)}\n`;
      } else if (item.type === 'new_comments_after_review') {
        summary += `- 💬 **[${item.repo}#${item.pr_number}](${item.url})** — ${item.comment_count} new comment(s)\n`;
        summary += `  > ${item.latest_comment.slice(0, 120)}…\n`;
      }
    }
    summary += '\n';
  }

  if (notifications.length > 0) {
    summary += `### Notifications (${notifications.length})\n\n`;
    for (const n of notifications.slice(0, 10)) {
      summary += `- [${n.reason}] ${n.repo}: ${n.title}\n`;
    }
  }

  return summary;
}

// --- main ------------------------------------------------------------------

async function main() {
  const dryRun = process.argv.includes('--dry-run');
  const verbose = process.argv.includes('--verbose');

  if (verbose) console.log('Starting GitHub CR monitor...');

  const octokit = new Octokit({ auth: config.github.token });
  const state = loadState();

  const allPending = [];
  for (const repo of config.repositories) {
    if (verbose) console.log(`Checking ${repo}...`);
    try {
      const items = await fetchPendingReviews(octokit, repo);
      allPending.push(...items);
    } catch (err) {
      console.error(`Error checking ${repo}:`, err.message);
      appendLog({ level: 'error', repo, error: err.message });
    }
  }

  const notifications = await fetchRecentNotifications(
    octokit,
    state.lastPollTimestamp
  );

  const summary = buildSummary(allPending, notifications, state);

  state.lastPollTimestamp = new Date().toISOString();
  saveState(state);

  if (summary) {
    appendLog({
      level: 'info',
      action: 'summary_generated',
      pending_count: allPending.length,
      notification_count: notifications.length,
    });

    if (dryRun) {
      console.log('[DRY RUN]\n');
      console.log(summary);
    } else {
      // Output summary to stdout for the cron caller to pick up
      console.log(summary);
    }
  } else {
    if (verbose) console.log('No new code review activity.');
    appendLog({ level: 'info', action: 'no_new_activity' });
    process.exit(0);
  }
}

main().catch((err) => {
  console.error('Fatal error:', err);
  appendLog({ level: 'fatal', error: err.message, stack: err.stack });
  process.exit(1);
});
