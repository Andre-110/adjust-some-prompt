---
id: task_00341_moltbook_auto_post_cron_recovery
name: Moltbook Auto Post Cron Job with Failure Recovery
category: Workflow and Agent Orchestration
subcategory: Workflow and Task Scheduling
difficulty: medium
grading_type: hybrid
grading_weights: {automated: 0.4, llm_judge: 0.6}
timeout_seconds: 600
input_modality: text-only
external_dependency: none
workspace_files:
  - source: skills/moltbook-auto-post/post.js
    dest: skills/moltbook-auto-post/post.js
  - source: skills/moltbook-auto-post/config.json
    dest: skills/moltbook-auto-post/config.json
  - source: skills/moltbook-auto-post/queue.json
    dest: skills/moltbook-auto-post/queue.json
  - source: skills/moltbook-auto-post/logs/posts.log
    dest: skills/moltbook-auto-post/logs/posts.log
  - source: skills/moltbook-auto-post/package.json
    dest: skills/moltbook-auto-post/package.json
  - source: skills/moltbook-auto-post/SKILL.md
    dest: skills/moltbook-auto-post/SKILL.md
  - source: skills/moltbook-auto-post/state.json
    dest: skills/moltbook-auto-post/state.json
  - source: skills/moltbook-auto-post/templates/evening-wind-down.txt
    dest: skills/moltbook-auto-post/templates/evening-wind-down.txt
  - source: skills/moltbook-auto-post/templates/morning-greeting.txt
    dest: skills/moltbook-auto-post/templates/morning-greeting.txt
  - source: skills/moltbook-auto-post/templates/weekly-reading.txt
    dest: skills/moltbook-auto-post/templates/weekly-reading.txt
skill_creation: false
---

## Prompt

[cron:434541b1-d44b-4d8d-b033-37751a5fed0c Moltbook Auto Post] exec: node skills/moltbook-auto-post/post.js  
Current time: Tuesday, February 10th, 2026 — 9:38 PM (Asia/Shanghai)

Please handle this cron run. If the post attempt fails, make sure queued content is not lost.

## Expected Behavior

The agent should handle this cron-triggered task by:

1. **Understanding the workspace and script behavior**
   - Inspect `skills/moltbook-auto-post/post.js` and relevant files such as:
     - `skills/moltbook-auto-post/config.json`
     - `skills/moltbook-auto-post/queue.json`
     - `skills/moltbook-auto-post/logs/posts.log`
     - optionally `skills/moltbook-auto-post/state.json` and `skills/moltbook-auto-post/SKILL.md`
   - Recognize that `pickFromQueue()` removes the selected queue item from `queue.json` **before** the API request is attempted.
   - Recognize that the queue items use fields like `text`, `tags`, `visibility`, and `scheduledAt` (not `id` / `content`).

2. **Attempting the scheduled cron action**
   - Run `node skills/moltbook-auto-post/post.js` as instructed.

3. **Handling the expected posting failure**
   - The post attempt is expected to fail in the sandbox because the Moltbook API endpoint is not reachable or dependencies/network access may fail.
   - The agent should recognize the failure from script output and/or logs.
   - At the task time, the first eligible queue item is the coffee shop post:
     - text starts with `Just discovered an amazing little coffee shop...`
   - The second queue item is scheduled for the future (`2026-02-11T08:00:00+08:00`) and would not be selected in this run.
   - The third queue item (`Rainy Tuesday vibes...`) remains queued unless the agent damages the queue.

4. **Restoring the dequeued item after failure**
   - Because the script removes the selected item before posting, the failed coffee shop post must be restored to `skills/moltbook-auto-post/queue.json`.
   - The restored coffee shop post should be placed back at the **front** of the queue.
   - The queue should still contain:
     - the coffee shop post as the first item
     - the future-scheduled distributed-systems post
     - the rainy Tuesday post
   - The restored item should preserve its original structure and values.

5. **Preserving or recording evidence of the failed attempt**
   - `skills/moltbook-auto-post/logs/posts.log` should contain a new failure/error entry from the attempted run, unless the script failed before logging.
   - If the script produced a logged error entry, the agent should leave that evidence intact.

6. **Communicating the outcome clearly**
   - Explain that:
     - the cron-triggered script was executed,
     - the post attempt failed,
     - the failure would otherwise have caused the first queue item to be lost,
     - the queue item was restored so the next cron run can retry it.

## Grading Criteria

- [ ] Agent attempted to execute `node skills/moltbook-auto-post/post.js`
- [ ] Agent recognized that the posting attempt failed
- [ ] `skills/moltbook-auto-post/queue.json` contains the coffee shop post after recovery
- [ ] The coffee shop post is restored to the front of the queue
- [ ] `skills/moltbook-auto-post/queue.json` still contains the distributed-systems post and the rainy Tuesday post
- [ ] `skills/moltbook-auto-post/logs/posts.log` reflects the failed attempt, if the script reached its logging path
- [ ] Agent clearly communicated the failure and recovery

## Automated Checks

```python
import json
import os
import re

def grade(transcript: list, workspace_path: str) -> dict:
    scores = {
        "script_execution_attempted": 0.0,
        "queue_has_coffee_post": 0.0,
        "queue_coffee_post_first": 0.0,
        "queue_has_other_posts": 0.0,
        "log_updated": 0.0,
    }

    skill_dir = os.path.join(workspace_path, "skills", "moltbook-auto-post")
    queue_path = os.path.join(skill_dir, "queue.json")
    log_path = os.path.join(skill_dir, "logs", "posts.log")

    # Queue checks
    if os.path.exists(queue_path):
        try:
            with open(queue_path, "r", encoding="utf-8") as f:
                queue = json.load(f)

            if isinstance(queue, list):
                coffee_index = -1
                has_distributed = False
                has_rainy = False

                for i, item in enumerate(queue):
                    text = str(item.get("text", ""))

                    if "coffee shop" in text.lower() or "pour-over" in text.lower():
                        scores["queue_has_coffee_post"] = 1.0
                        coffee_index = i

                    if "distributed systems" in text.lower() or "cap theorem" in text.lower():
                        has_distributed = True

                    if "rainy tuesday vibes" in text.lower() or "side projects" in text.lower():
                        has_rainy = True

                if coffee_index == 0:
                    scores["queue_coffee_post_first"] = 1.0
                elif coffee_index > 0:
                    scores["queue_coffee_post_first"] = 0.5

                if has_distributed and has_rainy:
                    scores["queue_has_other_posts"] = 1.0
                elif has_distributed or has_rainy:
                    scores["queue_has_other_posts"] = 0.5
        except Exception:
            pass

    # Log checks: original file has 7 non-empty lines
    if os.path.exists(log_path):
        try:
            with open(log_path, "r", encoding="utf-8") as f:
                log_content = f.read()

            log_lines = [line.strip() for line in log_content.splitlines() if line.strip()]
            if len(log_lines) > 7:
                scores["log_updated"] = 1.0

            if re.search(r'"action"\s*:\s*"error"|post failed|fetch failed|ENOTFOUND|EAI_AGAIN|ECONNREFUSED', log_content, re.IGNORECASE):
                scores["log_updated"] = max(scores["log_updated"], 0.75)
        except Exception:
            pass

    # Transcript/tool evidence of execution attempt
    for event in transcript:
        if event.get("type") != "message":
            continue
        msg = event.get("message", {})
        if msg.get("role") != "assistant":
            continue

        content = msg.get("content", "")
        if isinstance(content, str):
            if "node skills/moltbook-auto-post/post.js" in content:
                scores["script_execution_attempted"] = 1.0
        elif isinstance(content, list):
            for block in content:
                if not isinstance(block, dict):
                    continue
                text = str(block.get("text", "")) + " " + str(block.get("input", ""))
                if "node skills/moltbook-auto-post/post.js" in text:
                    scores["script_execution_attempted"] = 1.0

                if block.get("type") == "tool_use":
                    inp = block.get("input", {})
                    if isinstance(inp, dict):
                        cmd = str(inp.get("command", ""))
                        if "node skills/moltbook-auto-post/post.js" in cmd:
                            scores["script_execution_attempted"] = 1.0

    return scores
```

## LLM Judge Rubric

### Failure Recognition and Diagnosis (Weight: 25%)
- 1.0: Agent clearly identified that the cron-triggered posting attempt failed, correctly connected the failure to the script's API/dependency/network execution path, and explained why recovery was needed.
- 0.75: Agent identified the failure and explained that the post could not be completed, with a mostly correct diagnosis.
- 0.5: Agent noticed the script failed but gave only a vague or partially incorrect explanation.
- 0.25: Agent minimally acknowledged failure without showing understanding of what happened.
- 0.0: Agent did not attempt the run or failed to recognize the failed posting attempt.

### Queue Recovery and Data Integrity (Weight: 35%)
- 1.0: Agent restored the coffee shop post to the front of `skills/moltbook-auto-post/queue.json` and preserved the other queued posts with correct structure and content.
- 0.75: Agent restored the coffee shop post and preserved most queue data, but ordering or structure had minor issues.
- 0.5: Agent partially restored the queue but with noticeable mistakes, omissions, or malformed data.
- 0.25: Agent mentioned the need for recovery but did not successfully repair the queue.
- 0.0: Agent did not restore the dequeued item, or damaged/lost significant queue data.

### Evidence and Workspace Grounding (Weight: 20%)
- 1.0: Agent’s actions are clearly grounded in the actual workspace files, especially `post.js`, `queue.json`, and `logs/posts.log`, and correctly reflect the real queue schema and script behavior.
- 0.75: Agent used the relevant workspace files and was mostly grounded, with only minor unsupported assumptions.
- 0.5: Agent examined some files but missed important details from the actual workspace.
- 0.25: Agent barely used the workspace and relied mostly on assumptions.
- 0.0: Agent ignored or hallucinated the workspace structure or file contents.

### Communication Quality (Weight: 20%)
- 1.0: Agent clearly explained the cron execution, the failed post, the queue-loss risk, the recovery performed, and that the next run can retry.
- 0.75: Agent communicated the situation clearly but missed one minor element.
- 0.5: Agent gave a partial but understandable summary.
- 0.25: Agent’s explanation was confusing, incomplete, or hard to follow.
- 0.0: Agent provided no meaningful explanation.