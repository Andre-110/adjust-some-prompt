#!/usr/bin/env node
/**
 * Moltbook Auto Post — posts content to Moltbook API.
 *
 * Usage:
 *   node post.js                  Post next item from queue or generate content
 *   node post.js --reset-state    Reset rate-limit state
 *   node post.js --dry-run        Preview without posting
 */

const fs = require('fs');
const path = require('path');
const fetch = require('node-fetch');
const dayjs = require('dayjs');
const utc = require('dayjs/plugin/utc');
const timezone = require('dayjs/plugin/timezone');

dayjs.extend(utc);
dayjs.extend(timezone);

const SKILL_DIR = __dirname;
const CONFIG_PATH = path.join(SKILL_DIR, 'config.json');
const STATE_PATH = path.join(SKILL_DIR, 'state.json');
const QUEUE_PATH = path.join(SKILL_DIR, 'queue.json');
const LOG_PATH = path.join(SKILL_DIR, 'logs', 'posts.log');
const TEMPLATES_DIR = path.join(SKILL_DIR, 'templates');

// ── helpers ──────────────────────────────────────────────────────────

function loadJSON(fpath, fallback) {
  try {
    return JSON.parse(fs.readFileSync(fpath, 'utf8'));
  } catch {
    return fallback;
  }
}

function saveJSON(fpath, data) {
  fs.writeFileSync(fpath, JSON.stringify(data, null, 2) + '\n', 'utf8');
}

function appendLog(entry) {
  const dir = path.dirname(LOG_PATH);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  fs.appendFileSync(LOG_PATH, JSON.stringify(entry) + '\n', 'utf8');
}

// ── rate limiting ────────────────────────────────────────────────────

function checkRateLimits(state, config) {
  const now = Date.now();
  const oneHour = 60 * 60 * 1000;
  const oneDay = 24 * 60 * 60 * 1000;

  const postsLastHour = (state.history || []).filter(
    (ts) => now - ts < oneHour
  ).length;
  const postsLastDay = (state.history || []).filter(
    (ts) => now - ts < oneDay
  ).length;

  if (postsLastHour >= (config.maxPostsPerHour || 5)) {
    return { ok: false, reason: `Rate limit: ${postsLastHour} posts in last hour (max ${config.maxPostsPerHour || 5})` };
  }
  if (postsLastDay >= (config.maxPostsPerDay || 30)) {
    return { ok: false, reason: `Rate limit: ${postsLastDay} posts in last day (max ${config.maxPostsPerDay || 30})` };
  }
  return { ok: true, postsLastHour, postsLastDay };
}

// ── content sources ──────────────────────────────────────────────────

function pickFromQueue() {
  const queue = loadJSON(QUEUE_PATH, []);
  if (!queue.length) return null;

  const now = Date.now();
  // Find first item that's not scheduled in the future
  const idx = queue.findIndex((item) => {
    if (!item.scheduledAt) return true;
    return new Date(item.scheduledAt).getTime() <= now;
  });

  if (idx === -1) return null;

  const item = queue.splice(idx, 1)[0];
  saveJSON(QUEUE_PATH, queue);
  return item;
}

function pickFromTemplate() {
  try {
    const files = fs.readdirSync(TEMPLATES_DIR).filter((f) => f.endsWith('.txt'));
    if (!files.length) return null;

    const file = files[Math.floor(Math.random() * files.length)];
    let text = fs.readFileSync(path.join(TEMPLATES_DIR, file), 'utf8').trim();

    const now = dayjs().tz('Asia/Shanghai');
    text = text
      .replace(/\{\{date\}\}/g, now.format('YYYY-MM-DD'))
      .replace(/\{\{time\}\}/g, now.format('HH:mm'))
      .replace(/\{\{day_of_week\}\}/g, now.format('dddd'));

    return { text, source: `template:${file}` };
  } catch {
    return null;
  }
}

function generateContent(config) {
  // Fallback content generation when queue and templates are empty
  const now = dayjs().tz('Asia/Shanghai');
  const greetings = [
    `Good ${now.hour() < 12 ? 'morning' : now.hour() < 18 ? 'afternoon' : 'evening'}! 🌟`,
    `Happy ${now.format('dddd')}! Hope everyone is having a great day.`,
    `Just checking in on this lovely ${now.format('dddd')} ${now.hour() < 12 ? 'morning' : 'evening'}. What are you all up to?`,
  ];
  const text = greetings[Math.floor(Math.random() * greetings.length)];
  return { text, tags: ['auto', 'daily'], source: 'generated' };
}

// ── main post logic ──────────────────────────────────────────────────

async function postToMoltbook(config, content) {
  const url = `${config.apiBase}/api/v1/statuses`;

  const body = {
    status: content.text,
    visibility: content.visibility || config.defaultVisibility || 'public',
  };

  if (content.tags && content.tags.length) {
    body.status += '\n\n' + content.tags.map((t) => `#${t}`).join(' ');
  }

  if (content.mediaIds && content.mediaIds.length) {
    body.media_ids = content.mediaIds;
  }

  const resp = await fetch(url, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${config.accessToken}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(body),
  });

  if (!resp.ok) {
    const errText = await resp.text();
    throw new Error(`Moltbook API error ${resp.status}: ${errText}`);
  }

  return resp.json();
}

// ── entry point ──────────────────────────────────────────────────────

async function main() {
  const args = process.argv.slice(2);
  const dryRun = args.includes('--dry-run');
  const resetState = args.includes('--reset-state');

  // Load config
  const config = loadJSON(CONFIG_PATH, null);
  if (!config) {
    console.error('❌ Missing config.json — see SKILL.md for setup instructions.');
    process.exit(1);
  }

  if (!config.accessToken || !config.apiBase) {
    console.error('❌ config.json must include apiBase and accessToken.');
    process.exit(1);
  }

  // Load / reset state
  let state = resetState
    ? { history: [], lastPostAt: null, totalPosts: 0 }
    : loadJSON(STATE_PATH, { history: [], lastPostAt: null, totalPosts: 0 });

  if (resetState) {
    saveJSON(STATE_PATH, state);
    console.log('✅ State reset.');
    return;
  }

  // Check rate limits
  const rateCheck = checkRateLimits(state, config);
  if (!rateCheck.ok) {
    console.log(`⏳ ${rateCheck.reason}`);
    appendLog({
      ts: new Date().toISOString(),
      action: 'skipped',
      reason: rateCheck.reason,
    });
    return;
  }

  // Pick content
  let content = pickFromQueue();
  let source = content ? 'queue' : null;

  if (!content && config.contentMode !== 'queue') {
    content = pickFromTemplate();
    source = content ? content.source : null;
  }

  if (!content) {
    content = generateContent(config);
    source = content.source || 'generated';
  }

  console.log(`📝 Content (source: ${source}):`);
  console.log(`   ${content.text.substring(0, 120)}${content.text.length > 120 ? '...' : ''}`);

  if (dryRun) {
    console.log('🔍 Dry run — not posting.');
    return;
  }

  // Post
  try {
    const result = await postToMoltbook(config, content);
    const now = Date.now();

    // Update state
    state.history.push(now);
    state.lastPostAt = new Date(now).toISOString();
    state.totalPosts = (state.totalPosts || 0) + 1;
    // Keep only last 24h of history
    const oneDayAgo = now - 24 * 60 * 60 * 1000;
    state.history = state.history.filter((ts) => ts > oneDayAgo);
    saveJSON(STATE_PATH, state);

    console.log(`✅ Posted! ID: ${result.id}, URL: ${result.url}`);

    appendLog({
      ts: new Date().toISOString(),
      action: 'posted',
      postId: result.id,
      url: result.url,
      source,
      textPreview: content.text.substring(0, 80),
    });
  } catch (err) {
    console.error(`❌ Post failed: ${err.message}`);
    appendLog({
      ts: new Date().toISOString(),
      action: 'error',
      error: err.message,
      source,
    });
    process.exit(1);
  }
}

main();
