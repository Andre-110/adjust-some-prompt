| 序号 | 修改项 | 修改原因 |
|------|--------|----------|
| 1 | 将 frontmatter 中 `workspace_files` 从旧字段 `path:` 改为规范的 `dest:` 列表 | 符合当前数据规范，避免使用废弃字段 |
| 2 | 删除任务文档中与真实 Assets 不一致的内联文件内容引用，改为基于实际 workspace 文件描述 | 原 task 文档中的 `post.js`、`config.json`、`queue.json`、`logs/posts.log` 与实际 Assets 完全不一致 |
| 3 | 重写 Prompt，增加一句自然说明“如果失败请确保队列内容不丢失” | 提高自然度与任务意图清晰度 |
| 4 | 重写 Expected Behavior，使其基于真实 `post.js` 行为和真实 `queue.json` 结构 | 原 Expected Behavior 假设了错误的数据结构和错误的 Ground Truth |
| 5 | 将恢复目标从虚构的 `post-001` / `post-002` 改为真实队列中的咖啡贴文、distributed-systems 贴文、rainy Tuesday 贴文 | 与 Assets 保持一致，确保可验证 |
| 6 | 重写 Grading Criteria，使每条可独立验证并覆盖核心能力 | 原 criteria 依赖错误字段和错误答案 |
| 7 | 重写 `grade()` 中的队列检查逻辑，从 `id/content` 改为真实的 `text` 字段匹配 | 原评分脚本无法正确读取真实 queue 内容 |
| 8 | 调整 `grade()` 中日志检查基线，从“原始 2 条日志”改为真实 Assets 的 7 条日志 | 原日志条数假设错误 |
| 9 | 保留 transcript 中对执行命令的检测，但改为匹配完整命令 `node skills/moltbook-auto-post/post.js` | 提高判定准确性 |
| 10 | 调整 LLM Judge Rubric 中的恢复描述，使其与真实队列和脚本行为一致 | 原 rubric 建立在错误 Ground Truth 上 |
| 11 | 修改 `skills/moltbook-auto-post/config.json` 中疑似真实长 token 为明显虚构测试值 | 避免潜在敏感信息风险 |
| 12 | 修改 `skills/moltbook-auto-post/SKILL.md`，移除与代码不一致的 `dotenv` 依赖说明和未实现模板变量 | 提升 Assets 跨文件一致性 |
```