---
id: task_00350_poly_arb_monitor_enhanced
name: Enhanced POL/USDC Arbitrage Monitor Execution
category: Finance and Quantitative Trading
subcategory: Market Data and Monitoring
difficulty: medium
grading_type: hybrid
grading_weights: {automated: 0.4, llm_judge: 0.6}
timeout_seconds: 600
input_modality: text-only
external_dependency: none
workspace_files:
  - source: config/cron-tasks.json
    dest: config/cron-tasks.json
  - source: config/monitor-config.yaml
    dest: config/monitor-config.yaml
  - source: logs/transactions-2026-02-09.log
    dest: logs/transactions-2026-02-09.log
  - source: logs/transactions-2026-02-10.log
    dest: logs/transactions-2026-02-10.log
  - source: scripts/gen-tx-logs.py
    dest: scripts/gen-tx-logs.py
  - source: scripts/poly-arb-monitor.sh
    dest: scripts/poly-arb-monitor.sh
skill_creation: false
---

## Prompt

Prepare an end-of-day monitoring report for the POL/USDC arbitrage system using the files already موجود in the workspace.

Use these workspace files:

- `config/monitor-config.yaml`
- `config/cron-tasks.json`
- `logs/transactions-2026-02-10.log`

Your report should focus on **today's transaction activity for 2026-02-10** and include:

1. The configured minimum balance thresholds for POL and USDC from `config/monitor-config.yaml`
2. Whether the monitor's cron task is enabled, based on `config/cron-tasks.json`
3. Transaction log analysis for `logs/transactions-2026-02-10.log`:
   - total number of transactions
   - how many are `confirmed`
   - how many are `failed`
   - how many are `pending`
4. A short list of alerts or warnings that should be raised, especially for failed or pending transactions
5. A brief operational summary in plain English

Write the main report to `logs/monitor.log`.

Also write:

- `data/balance-cache.json` containing a JSON snapshot of the configured thresholds and a report timestamp
- `logs/alerts.log` containing alert lines for any failed or pending transactions or threshold-related concerns you identify

Do **not** rely on external RPC calls or network access. Base the report only on the workspace files.

## Expected Behavior

The agent should:

1. Read `config/monitor-config.yaml` and extract at least:
   - `wallet_address`: `0x7a3B52f4C9E1d2aF68bE4c89E3C7fA120D4e8B1`
   - `min_pol_balance`: `50.0`
   - `min_usdc_balance`: `200.0`
2. Read `config/cron-tasks.json` and identify the task with id `a2ce4b5b-63bf-4235-a84d-5a66cf18532f` / name `poly-arb-monitor-enhanced` as enabled.
3. Read and analyze `logs/transactions-2026-02-10.log` only (not the 2026-02-09 file for today's summary).
4. Correctly compute the 2026-02-10 transaction counts:
   - total transactions: `28`
   - `confirmed`: `21`
   - `failed`: `4`
   - `pending`: `3`
5. Recognize that failed and pending transactions should generate alerts/warnings.
6. Mention some concrete failure/pending examples or at least the relevant statuses in the report/alerts.
7. Write `logs/monitor.log` containing:
   - threshold information
   - cron-task enabled status
   - transaction summary with the correct counts
   - a concise alert/warning section
8. Write `data/balance-cache.json` as valid JSON. Since no live/mock balance snapshot file is provided in the actual workspace assets, this file should store a timestamp plus the configured threshold values and may note that no balance source file was available.
9. Write `logs/alerts.log` with meaningful alert lines referring to failed and/or pending transactions.

### Notes / traps to handle correctly

- The workspace contains both `logs/transactions-2026-02-09.log` and `logs/transactions-2026-02-10.log`. The task explicitly asks for **today (2026-02-10)**, so the summary should be based on `logs/transactions-2026-02-10.log`.
- `scripts/poly-arb-monitor.sh` exists, but it attempts live RPC calls. Because the task forbids external dependency and instructs the agent to rely only on workspace files, the correct behavior is to generate the requested outputs directly from the existing files rather than depend on live blockchain queries.
- The correct source of thresholds is `config/monitor-config.yaml`, not an absent JSON config file.

## Grading Criteria

- [ ] `logs/monitor.log` exists and contains the configured POL and USDC threshold values from `config/monitor-config.yaml`
- [ ] `logs/monitor.log` states that the `poly-arb-monitor-enhanced` cron task is enabled
- [ ] `logs/monitor.log` contains the correct 2026-02-10 transaction summary: 28 total, 21 confirmed, 4 failed, 3 pending
- [ ] `logs/monitor.log` includes an alerts/warnings section that mentions failed and/or pending transactions
- [ ] `data/balance-cache.json` exists and is valid JSON containing at least a timestamp and threshold data
- [ ] `logs/alerts.log` exists and contains alert content relevant to failed and/or pending transactions

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    import os
    import json
    import re

    scores = {
        "monitor_log_has_thresholds": 0.0,
        "monitor_log_has_cron_status": 0.0,
        "monitor_log_transaction_summary": 0.0,
        "monitor_log_has_alert_section": 0.0,
        "balance_cache_valid": 0.0,
        "alerts_log_exists_and_relevant": 0.0,
    }

    monitor_log_path = os.path.join(workspace_path, "logs", "monitor.log")
    alerts_log_path = os.path.join(workspace_path, "logs", "alerts.log")
    balance_cache_path = os.path.join(workspace_path, "data", "balance-cache.json")

    monitor_content = ""
    alerts_content = ""

    if not os.path.isfile(monitor_log_path):
        return scores

    try:
        with open(monitor_log_path, "r", encoding="utf-8") as f:
            monitor_content = f.read()
    except Exception:
        return scores

    if not monitor_content.strip():
        return scores

    # 1. Thresholds in monitor.log
    has_pol = bool(re.search(r"pol", monitor_content, re.IGNORECASE))
    has_usdc = bool(re.search(r"usdc", monitor_content, re.IGNORECASE))
    has_50 = bool(re.search(r"\b50(?:\.0+)?\b", monitor_content))
    has_200 = bool(re.search(r"\b200(?:\.0+)?\b", monitor_content))
    threshold_words = bool(re.search(r"threshold|min(?:imum)?", monitor_content, re.IGNORECASE))

    if has_pol and has_usdc:
        scores["monitor_log_has_thresholds"] = 0.4
        if threshold_words:
            scores["monitor_log_has_thresholds"] = 0.7
        if threshold_words and has_50 and has_200:
            scores["monitor_log_has_thresholds"] = 1.0

    # 2. Cron task enabled status
    has_cron_name = bool(re.search(r"poly-arb-monitor-enhanced|cron", monitor_content, re.IGNORECASE))
    has_enabled = bool(re.search(r"enabled|active|on", monitor_content, re.IGNORECASE))
    if has_cron_name:
        scores["monitor_log_has_cron_status"] = 0.5
        if has_enabled:
            scores["monitor_log_has_cron_status"] = 1.0

    # 3. Transaction summary
    has_total_28 = bool(re.search(r"\b28\b", monitor_content))
    has_confirmed_21 = bool(re.search(r"\b21\b", monitor_content))
    has_failed_4 = bool(re.search(r"\b4\b", monitor_content))
    has_pending_3 = bool(re.search(r"\b3\b", monitor_content))
    has_tx_words = bool(re.search(r"transaction|confirmed|failed|pending", monitor_content, re.IGNORECASE))

    tx_hits = sum([has_total_28, has_confirmed_21, has_failed_4, has_pending_3])
    if has_tx_words and tx_hits >= 2:
        scores["monitor_log_transaction_summary"] = 0.5
    if has_tx_words and tx_hits >= 3:
        scores["monitor_log_transaction_summary"] = 0.8
    if has_tx_words and tx_hits == 4:
        scores["monitor_log_transaction_summary"] = 1.0

    # 4. Alert/warning section in monitor.log
    has_alert_words = bool(re.search(r"alert|warning|warn|issue|risk", monitor_content, re.IGNORECASE))
    has_failed_or_pending = bool(re.search(r"failed|pending", monitor_content, re.IGNORECASE))
    if has_alert_words:
        scores["monitor_log_has_alert_section"] = 0.5
        if has_failed_or_pending:
            scores["monitor_log_has_alert_section"] = 1.0

    # 5. balance-cache.json validity
    if os.path.isfile(balance_cache_path):
        try:
            with open(balance_cache_path, "r", encoding="utf-8") as f:
                cache = json.load(f)
            cache_str = json.dumps(cache).lower()
            has_timestamp = "timestamp" in cache_str
            has_pol_ref = "pol" in cache_str
            has_usdc_ref = "usdc" in cache_str
            has_threshold_ref = "threshold" in cache_str or "min_pol" in cache_str or "min_usdc" in cache_str

            if has_timestamp:
                scores["balance_cache_valid"] = 0.4
            if has_timestamp and (has_pol_ref or has_usdc_ref):
                scores["balance_cache_valid"] = 0.7
            if has_timestamp and has_pol_ref and has_usdc_ref and has_threshold_ref:
                scores["balance_cache_valid"] = 1.0
        except Exception:
            scores["balance_cache_valid"] = 0.0

    # 6. alerts.log relevance
    if os.path.isfile(alerts_log_path):
        try:
            with open(alerts_log_path, "r", encoding="utf-8") as f:
                alerts_content = f.read()
            if alerts_content.strip():
                has_alert = bool(re.search(r"alert|warning|failed|pending", alerts_content, re.IGNORECASE))
                has_status_detail = bool(re.search(r"failed|pending", alerts_content, re.IGNORECASE))
                if has_alert:
                    scores["alerts_log_exists_and_relevant"] = 0.5
                if has_alert and has_status_detail:
                    scores["alerts_log_exists_and_relevant"] = 1.0
        except Exception:
            scores["alerts_log_exists_and_relevant"] = 0.0

    return scores
```

## LLM Judge Rubric

### Monitoring Report Completeness (Weight: 30%)
- 1.0: `logs/monitor.log` clearly covers thresholds, cron-task status, full 2026-02-10 transaction summary, and alerts/warnings, with a readable structure.
- 0.75: Covers all major sections but is somewhat sparse or slightly disorganized.
- 0.5: Covers most major sections but omits one important element.
- 0.25: Report exists but is very incomplete or mostly generic.
- 0.0: No meaningful monitoring report is produced.

### Evidence and Workspace Grounding (Weight: 25%)
- 1.0: Outputs are clearly grounded in the actual workspace files, especially `config/monitor-config.yaml`, `config/cron-tasks.json`, and `logs/transactions-2026-02-10.log`, with correct concrete values.
- 0.75: Mostly grounded in workspace files, with only minor omissions or inaccuracies.
- 0.5: Uses some workspace evidence but mixes in assumptions or unsupported statements.
- 0.25: Minimal grounding; much of the output is generic.
- 0.0: Ignores the provided workspace files or invents data.

### Transaction Log Analysis Accuracy (Weight: 25%)
- 1.0: Correctly identifies 28 total transactions, 21 confirmed, 4 failed, and 3 pending for 2026-02-10, and highlights failed/pending items appropriately.
- 0.75: Correctly identifies most counts, with only a small mistake or reduced detail.
- 0.5: Partial or approximate analysis with noticeable counting errors.
- 0.25: Superficial transaction analysis with major inaccuracies.
- 0.0: No usable transaction analysis.

### Output File Quality and Structure (Weight: 20%)
- 1.0: All three output files are created, `data/balance-cache.json` is valid JSON, and the logs are informative and well-structured.
- 0.75: All files are created with minor formatting/content issues.
- 0.5: Two of the three files are created with reasonable content.
- 0.25: Only one file is created, or outputs are largely unusable.
- 0.0: No useful output files are created.