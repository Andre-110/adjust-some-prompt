| 序号 | 修改项 | 修改原因 |
|------|--------|----------|
| 1 | 将 frontmatter 中的 `workspace_files` 从旧格式 `path:` 改为规范格式 `dest:` | 本批数据规范禁止只写旧字段 `path:` |
| 2 | 删除原题面内联的伪造 `config/monitor-config.json`、`logs/transactions.log`、`data/mock-balances.json` 依赖，改为引用真实 Assets 文件 | 原 Prompt/Expected Behavior 与实际 Assets 不一致，引用了不存在的工作区文件 |
| 3 | 将 Prompt 改写为基于 `config/monitor-config.yaml`、`config/cron-tasks.json`、`logs/transactions-2026-02-10.log` 生成报告 | 保证任务可执行、路径正确、且与 workspace 根下真实文件一致 |
| 4 | 在 Prompt 中明确禁止依赖外部 RPC/网络访问 | `scripts/poly-arb-monitor.sh` 会尝试真实 RPC 调用，但题目 `external_dependency: none`，需要避免错误执行路径 |
| 5 | 重写 Expected Behavior 中的 Ground Truth | 原 Expected Behavior 的“7 total / 5 success / 2 failed”与真实交易日志不符 |
| 6 | 将交易统计答案修正为 2026-02-10 日志的真实值：28 total / 21 confirmed / 4 failed / 3 pending | 与实际 Assets 数据一致，保证可验证 |
| 7 | 在 Expected Behavior 中补充“不要误用 2026-02-09 日志”的陷阱说明 | 目录中存在两天日志，属于合理数据陷阱，应在期望行为中说明 |
| 8 | 调整 `data/balance-cache.json` 的任务要求，改为保存时间戳和阈值快照，而不强制伪造不存在的余额源数据 | 实际 Assets 中没有 `data/mock-balances.json`，不能要求模型引用不存在的数据 |
| 9 | 重写 Grading Criteria，使其覆盖阈值、cron 状态、当日交易统计、alerts 和 JSON 输出 | 原标准依赖错误文件和错误答案，无法独立验证 |
| 10 | 重写 `grade()` 函数 | 原评分逻辑基于错误路径、错误统计值，且无法正确评估真实 workspace 下的解答 |
| 11 | 保持 LLM Judge Rubric 为 4 个维度，但将描述改为与真实 Assets 和正确 Ground Truth 对齐 | 原 rubric 中的计数与文件引用不正确 |
| 12 | 保留 `difficulty: medium` 不变 | 修正后任务仍为中等难度：需要读 YAML/JSONL、多文件交叉核对并生成多个输出文件，但不涉及复杂编程 |