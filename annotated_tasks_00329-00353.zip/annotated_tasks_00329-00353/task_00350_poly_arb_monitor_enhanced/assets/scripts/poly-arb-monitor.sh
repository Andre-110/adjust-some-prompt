#!/usr/bin/env bash
# poly-arb-monitor.sh — Enhanced POL/USDC arbitrage monitor
# Checks wallet balances, monitors recent transactions, and logs anomalies.
# Called by cron job: a2ce4b5b-63bf-4235-a84d-5a66cf18532f
#
# Usage: ./poly-arb-monitor.sh [--dry-run] [--verbose]

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
ROOT_DIR="$(dirname "$SCRIPT_DIR")"
CONFIG_FILE="${ROOT_DIR}/config/monitor-config.yaml"
LOG_DIR="${ROOT_DIR}/logs"
BALANCE_CACHE="${ROOT_DIR}/data/balance-cache.json"
ALERT_LOG="${LOG_DIR}/alerts.log"

# ── Parse flags ──────────────────────────────────────────────
DRY_RUN=false
VERBOSE=false
for arg in "$@"; do
  case $arg in
    --dry-run)  DRY_RUN=true ;;
    --verbose)  VERBOSE=true ;;
  esac
done

# ── Load config ──────────────────────────────────────────────
if [ ! -f "$CONFIG_FILE" ]; then
  echo "[FATAL] Config not found: $CONFIG_FILE" >&2
  exit 1
fi

# Parse YAML values (lightweight — no yq dependency)
RPC_URL=$(grep 'rpc_url:' "$CONFIG_FILE" | head -1 | awk '{print $2}' | tr -d '"')
WALLET=$(grep 'wallet_address:' "$CONFIG_FILE" | head -1 | awk '{print $2}' | tr -d '"')
POL_CONTRACT=$(grep 'pol_token:' "$CONFIG_FILE" | head -1 | awk '{print $2}' | tr -d '"')
USDC_CONTRACT=$(grep 'usdc_token:' "$CONFIG_FILE" | head -1 | awk '{print $2}' | tr -d '"')
MIN_POL=$(grep 'min_pol_balance:' "$CONFIG_FILE" | head -1 | awk '{print $2}')
MIN_USDC=$(grep 'min_usdc_balance:' "$CONFIG_FILE" | head -1 | awk '{print $2}')
SLIPPAGE_TOLERANCE=$(grep 'slippage_tolerance:' "$CONFIG_FILE" | head -1 | awk '{print $2}')

TIMESTAMP=$(date -u +"%Y-%m-%dT%H:%M:%SZ")
TX_LOG="${LOG_DIR}/transactions-$(date -u +%Y-%m-%d).log"

log() { echo "[$TIMESTAMP] $*" | tee -a "${LOG_DIR}/monitor.log"; }
alert() { echo "[$TIMESTAMP] ALERT: $*" | tee -a "$ALERT_LOG"; }

log "=== Enhanced Monitor Run ==="
log "Wallet: $WALLET"
log "RPC: $RPC_URL"
log "Dry run: $DRY_RUN | Verbose: $VERBOSE"

# ── ERC-20 balanceOf selector: 0x70a08231 ───────────────────
encode_balance_call() {
  local addr="${1#0x}"
  printf '0x70a08231%064s' "$addr" | sed 's/ /0/g'
}

fetch_balance() {
  local token_addr="$1"
  local label="$2"
  local calldata
  calldata=$(encode_balance_call "$WALLET")

  local payload
  payload=$(cat <<EOF
{"jsonrpc":"2.0","id":1,"method":"eth_call","params":[{"to":"${token_addr}","data":"${calldata}"},"latest"]}
EOF
  )

  if $DRY_RUN; then
    log "[DRY-RUN] Would call eth_call for $label on $token_addr"
    echo "0"
    return
  fi

  local response
  response=$(curl -sf -X POST "$RPC_URL" \
    -H "Content-Type: application/json" \
    -d "$payload" 2>/dev/null) || {
    alert "RPC call failed for $label ($token_addr)"
    echo "-1"
    return
  }

  # Extract hex result and convert to decimal
  local hex_result
  hex_result=$(echo "$response" | grep -oP '"result"\s*:\s*"0x\K[0-9a-fA-F]+' | head -1)
  if [ -z "$hex_result" ]; then
    alert "Empty result for $label balance"
    echo "-1"
    return
  fi

  printf '%d\n' "0x$hex_result" 2>/dev/null || echo "-1"
}

# ── Fetch balances ───────────────────────────────────────────
log "Fetching POL balance..."
POL_RAW=$(fetch_balance "$POL_CONTRACT" "POL")
POL_BALANCE=$(echo "scale=6; $POL_RAW / 1000000000000000000" | bc 2>/dev/null || echo "0")

log "Fetching USDC balance..."
USDC_RAW=$(fetch_balance "$USDC_CONTRACT" "USDC")
USDC_BALANCE=$(echo "scale=6; $USDC_RAW / 1000000" | bc 2>/dev/null || echo "0")

log "POL balance: $POL_BALANCE (raw: $POL_RAW)"
log "USDC balance: $USDC_BALANCE (raw: $USDC_RAW)"

# ── Update balance cache ────────────────────────────────────
cat > "$BALANCE_CACHE" <<EOF
{
  "timestamp": "$TIMESTAMP",
  "wallet": "$WALLET",
  "balances": {
    "POL": { "raw": "$POL_RAW", "formatted": "$POL_BALANCE", "decimals": 18 },
    "USDC": { "raw": "$USDC_RAW", "formatted": "$USDC_BALANCE", "decimals": 6 }
  },
  "thresholds": {
    "min_pol": $MIN_POL,
    "min_usdc": $MIN_USDC
  }
}
EOF

# ── Threshold alerts ─────────────────────────────────────────
if [ "$(echo "$POL_BALANCE < $MIN_POL" | bc 2>/dev/null)" = "1" ]; then
  alert "POL balance ($POL_BALANCE) below minimum ($MIN_POL)"
fi
if [ "$(echo "$USDC_BALANCE < $MIN_USDC" | bc 2>/dev/null)" = "1" ]; then
  alert "USDC balance ($USDC_BALANCE) below minimum ($MIN_USDC)"
fi

# ── Scan transaction logs ───────────────────────────────────
if [ -f "$TX_LOG" ]; then
  FAILED_COUNT=$(grep -c '"status":"failed"' "$TX_LOG" 2>/dev/null || echo 0)
  TOTAL_TX=$(wc -l < "$TX_LOG" 2>/dev/null || echo 0)
  log "Transaction log: $TOTAL_TX entries, $FAILED_COUNT failed"

  if [ "$FAILED_COUNT" -gt 3 ]; then
    alert "High failure rate: $FAILED_COUNT failed out of $TOTAL_TX transactions today"
  fi

  # Check for stuck/pending transactions older than 10 minutes
  if $VERBOSE; then
    PENDING=$(grep '"status":"pending"' "$TX_LOG" 2>/dev/null || true)
    if [ -n "$PENDING" ]; then
      log "Pending transactions found:"
      echo "$PENDING" | tail -5
    fi
  fi
else
  log "No transaction log for today yet."
fi

# ── Gas price check ──────────────────────────────────────────
if ! $DRY_RUN; then
  GAS_RESPONSE=$(curl -sf -X POST "$RPC_URL" \
    -H "Content-Type: application/json" \
    -d '{"jsonrpc":"2.0","id":1,"method":"eth_gasPrice","params":[]}' 2>/dev/null) || true

  if [ -n "$GAS_RESPONSE" ]; then
    GAS_HEX=$(echo "$GAS_RESPONSE" | grep -oP '"result"\s*:\s*"0x\K[0-9a-fA-F]+' | head -1)
    if [ -n "$GAS_HEX" ]; then
      GAS_WEI=$(printf '%d' "0x$GAS_HEX" 2>/dev/null || echo 0)
      GAS_GWEI=$(echo "scale=2; $GAS_WEI / 1000000000" | bc 2>/dev/null || echo "?")
      log "Current gas price: ${GAS_GWEI} Gwei"

      if [ "$(echo "$GAS_GWEI > 500" | bc 2>/dev/null)" = "1" ]; then
        alert "Gas price spike: ${GAS_GWEI} Gwei — pausing arb execution recommended"
      fi
    fi
  fi
fi

# ── Summary ──────────────────────────────────────────────────
log "Monitor run complete."
log "POL=$POL_BALANCE | USDC=$USDC_BALANCE | Alerts=$(wc -l < "$ALERT_LOG" 2>/dev/null || echo 0) total"
exit 0
