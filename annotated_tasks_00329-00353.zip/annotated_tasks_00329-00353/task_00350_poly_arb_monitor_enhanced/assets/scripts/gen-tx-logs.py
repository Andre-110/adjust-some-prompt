import json, random, datetime

random.seed(42)
base_time = datetime.datetime(2026, 2, 10, 0, 0, 0)

dexes = ["quickswap_v3", "uniswap_v3_polygon", "sushiswap"]
statuses = ["confirmed", "confirmed", "confirmed", "confirmed", "confirmed",
            "confirmed", "confirmed", "failed", "pending"]
pairs = ["POL/USDC", "USDC/POL"]

lines = []
for i in range(28):
    ts = base_time + datetime.timedelta(minutes=random.randint(0, 1080))
    tx_hash = "0x" + "".join(random.choices("0123456789abcdef", k=64))
    status = random.choice(statuses)
    pair = random.choice(pairs)
    dex_in = random.choice(dexes[:2])
    dex_out = random.choice([d for d in dexes[:2] if d != dex_in])

    if pair == "POL/USDC":
        amt_in = round(random.uniform(20, 500), 4)
        amt_out = round(amt_in * random.uniform(0.42, 0.46), 4)
        token_in, token_out = "POL", "USDC"
    else:
        amt_in = round(random.uniform(10, 200), 4)
        amt_out = round(amt_in * random.uniform(2.15, 2.35), 4)
        token_in, token_out = "USDC", "POL"

    profit = round(random.uniform(-0.30, 1.80), 4)
    gas_used = random.randint(120000, 380000)
    gas_price_gwei = round(random.uniform(30, 180), 2)

    entry = {
        "timestamp": ts.strftime("%Y-%m-%dT%H:%M:%SZ"),
        "tx_hash": tx_hash,
        "status": status,
        "pair": pair,
        "dex_buy": dex_in,
        "dex_sell": dex_out,
        "amount_in": amt_in,
        "token_in": token_in,
        "amount_out": amt_out,
        "token_out": token_out,
        "profit_usd": profit,
        "gas_used": gas_used,
        "gas_price_gwei": gas_price_gwei,
        "block_number": 68400000 + random.randint(0, 50000),
        "wallet": "0x7a3B52f4C9E1d2aF68bE4c89E3C7fA120D4e8B1"
    }
    lines.append(json.dumps(entry))

lines.sort(key=lambda l: json.loads(l)["timestamp"])
with open("/home/node/workspace/logs/transactions-2026-02-10.log", "w") as f:
    f.write("\n".join(lines) + "\n")

# Also generate yesterday's log
lines2 = []
base2 = datetime.datetime(2026, 2, 9, 0, 0, 0)
for i in range(35):
    ts = base2 + datetime.timedelta(minutes=random.randint(0, 1440))
    tx_hash = "0x" + "".join(random.choices("0123456789abcdef", k=64))
    status = random.choice(["confirmed"]*8 + ["failed"])
    pair = random.choice(pairs)
    dex_in = random.choice(dexes[:2])
    dex_out = random.choice([d for d in dexes[:2] if d != dex_in])
    if pair == "POL/USDC":
        amt_in = round(random.uniform(20, 500), 4)
        amt_out = round(amt_in * random.uniform(0.42, 0.46), 4)
        token_in, token_out = "POL", "USDC"
    else:
        amt_in = round(random.uniform(10, 200), 4)
        amt_out = round(amt_in * random.uniform(2.15, 2.35), 4)
        token_in, token_out = "USDC", "POL"
    profit = round(random.uniform(-0.25, 2.10), 4)
    gas_used = random.randint(120000, 380000)
    gas_price_gwei = round(random.uniform(28, 150), 2)
    entry = {
        "timestamp": ts.strftime("%Y-%m-%dT%H:%M:%SZ"),
        "tx_hash": tx_hash,
        "status": status,
        "pair": pair,
        "dex_buy": dex_in,
        "dex_sell": dex_out,
        "amount_in": amt_in,
        "token_in": token_in,
        "amount_out": amt_out,
        "token_out": token_out,
        "profit_usd": profit,
        "gas_used": gas_used,
        "gas_price_gwei": gas_price_gwei,
        "block_number": 68350000 + random.randint(0, 50000),
        "wallet": "0x7a3B52f4C9E1d2aF68bE4c89E3C7fA120D4e8B1"
    }
    lines2.append(json.dumps(entry))

lines2.sort(key=lambda l: json.loads(l)["timestamp"])
with open("/home/node/workspace/logs/transactions-2026-02-09.log", "w") as f:
    f.write("\n".join(lines2) + "\n")

print("Generated transaction logs for 2026-02-09 and 2026-02-10")
