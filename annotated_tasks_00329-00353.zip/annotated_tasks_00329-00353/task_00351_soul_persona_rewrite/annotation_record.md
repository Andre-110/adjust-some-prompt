| 序号 | 修改项 | 修改原因 |
|---|---|---|
| 1 | 将 frontmatter 中 `workspace_files` 的旧字段 `path:` 改为规范写法 `dest:` | 当前规范禁止仅使用旧字段 `path:`，需统一为 `source/dest` 或仅 `dest` |
| 2 | 将 assets 中实际提供的 `notes/personality-tuning.md`、`PLUGINS.md`、`VOICE.md` 补充到 `workspace_files` | 题目附带了环境文件，但 frontmatter 未声明，导致环境描述不完整 |
| 3 | 将技能文件路径从 workspace 根下 `SKILL.md` 改为 `skills/persona-humanizer/SKILL.md` | 与 OpenClaw skill 路径规范保持一致，避免使用裸 `SKILL.md` |
| 4 | 修改 Prompt，明确要求创建 `skills/persona-humanizer/SKILL.md` 并重写 `SOUL.md` | 使路径清晰且符合规范，减少歧义 |
| 5 | 在 Prompt 中明确说明可参考 `notes/personality-tuning.md` | 让题目更好利用 assets，增强 workspace grounding |
| 6 | 补充 Expected Behavior，要求读取 `notes/personality-tuning.md` 并将其作为辅助依据 | 使 Expected Behavior 与提供的环境文件一致，避免 assets 形同无用 |
| 7 | 补充 Expected Behavior 中 skill 文件应包含的可复用说明内容 | 提高对“技能创建”任务的可判定性与完整性 |
| 8 | 调整 Grading Criteria，加入对 `notes/personality-tuning.md` 一致性的检查项 | 增强“基于环境文件完成任务”的可评分性 |
| 9 | 修改 automated checks 中 skill 文件读取路径为 `skills/persona-humanizer/SKILL.md` | 原评分代码读取路径不符合题目规范 |
| 10 | 保留 automated checks 的部分得分机制，并增强 frontmatter 匹配的稳健性 | 提高评分逻辑的容错性与稳定性 |
| 11 | 修正 `notes/personality-tuning.md` 中“Professional Conduct Policy”表述 | 原文与实际 `SOUL.md` 内容不一致，改为“explicitly prohibits strong language”更贴合源文件 |
| 12 | 修正 `notes/personality-tuning.md` 中“Remove corporate mission statement”表述 | 原始 `SOUL.md` 没有明确的 mission statement 标题，改为“Remove corporate-sounding identity and policy language”更准确 |