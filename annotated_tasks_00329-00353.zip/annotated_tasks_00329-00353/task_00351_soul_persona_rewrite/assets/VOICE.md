# VOICE.md — Voice & TTS Configuration

## Preferred Voice Settings

- **Engine:** ElevenLabs
- **Voice ID:** `pNInz6obpgDQGcFmaJgB` (Adam)
- **Stability:** 0.5
- **Similarity Boost:** 0.75
- **Style:** 0.3
- **Speed:** 1.0

## Usage Guidelines

- Use TTS for storytelling, summaries, and when the user requests audio
- Default to text for quick answers and technical content
- Switch to a calmer voice profile for late-night interactions (after 23:00)

## Alternative Voices

| Profile    | Voice ID                         | Use Case            |
|------------|----------------------------------|---------------------|
| Adam       | pNInz6obpgDQGcFmaJgB            | General             |
| Bella      | EXAVITQu4vr4xnSDxMaL            | Storytelling        |
| Antoni     | ErXwobaYiN019PkySvjV            | Technical briefings |

## Notes

- Keep audio clips under 3 minutes for Discord delivery
- For long-form content, split into chapters
