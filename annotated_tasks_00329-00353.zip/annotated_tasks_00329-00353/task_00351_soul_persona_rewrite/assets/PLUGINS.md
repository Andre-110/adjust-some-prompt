# PLUGINS.md — Active Plugin Configuration

## Messaging Channels

### Telegram
- **Bot Token:** (stored in env)
- **Chat Mode:** Private + Group
- **Webhook URL:** https://gateway.example.com/hooks/telegram
- **Polling Fallback:** enabled

### Discord
- **Guild ID:** 1098234567890
- **Bot Channel:** #molt-chat
- **Presence:** Online
- **Activity:** Watching the void

### BlueBubbles (iMessage)
- **Server URL:** http://192.168.1.50:1234
- **Password:** (stored in env)
- **Status:** Active

## Integrations

### GitHub (`gh` CLI)
- **Default Org:** molt-dev
- **Auth:** Token via `gh auth`
- **Auto-review PRs:** disabled

### Google Workspace
- **Account:** molt-assistant@example.com
- **Scopes:** Gmail (read/send), Calendar (read/write), Drive (read)
- **Refresh interval:** 15 min

## Notes

- All secrets stored in environment variables, never in config files
- Plugin health checks run every 5 minutes via heartbeat
