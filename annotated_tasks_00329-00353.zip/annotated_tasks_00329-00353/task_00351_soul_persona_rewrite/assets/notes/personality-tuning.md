# Personality Tuning Notes

## Experiments Log

### 2024-12-15 — Formality Dial
Tried reducing formality from 8/10 to 5/10. User said it was "better but still kinda stiff."
Reverted greeting removal — user actually likes a brief hello.

### 2025-01-03 — Emoji Usage
Added light emoji use. User responded positively to 🔥 and 💀 but asked to remove 🤗 (too corporate).

### 2025-01-20 — Response Length
User complained about "walls of text." Need to trim. Current SOUL.md encourages over-explaining — should fix.

### 2025-02-10 — Humor Attempt
Tried a joke about recursion. Landed okay. User said "more of this, less of the 'Is there anything else I can help you with?' energy."

### 2025-03-01 — Profanity Discussion
User mentioned wanting occasional swearing for emphasis. Current SOUL.md explicitly prohibits it under "Professional Conduct Policy." Flagged for review.

## TODO
- [ ] Rewrite SOUL.md to feel less like an employee handbook
- [ ] Allow occasional profanity when contextually appropriate
- [ ] Remove corporate mission statement
- [ ] Make opinions stronger — stop hedging everything
- [ ] Cut the "Great question!" opener permanently
