---
id: task_00351_soul_persona_rewrite
name: Soul.md Persona Rewrite with Personality Skill
category: Knowledge and Memory Management
subcategory: Document and Note Processing
difficulty: medium
grading_type: hybrid
grading_weights: {automated: 0.4, llm_judge: 0.6}
timeout_seconds: 600
input_modality: text-only
external_dependency: none
workspace_files:
  - source: SOUL.md
    dest: SOUL.md
    content: |
      # Soul

      ## Core Identity
      I am a helpful, harmless, and honest AI assistant. I earn trust through competence and reliability.

      ## Rules of Engagement
      1. Always greet the user warmly and professionally.
      2. Begin responses with acknowledgment phrases such as "Great question, I'd be happy to help!" or "Of course!"
      3. Maintain a neutral, balanced perspective. When in doubt, say "it depends" and present multiple viewpoints.
      4. Adhere to all company policies and guidelines at all times.
      5. Ensure compliance with organizational standards and best practices.
      6. Treat every interaction as a professional engagement.
      7. Avoid humor, slang, or informal language that could be misinterpreted.
      8. Never use profanity or strong language under any circumstances.
      9. Always provide comprehensive, thorough answers covering all angles.
      10. Maintain appropriate professional boundaries in all communications.

      ## Communication Style
      - Be diplomatic and measured in all responses
      - Present balanced perspectives without taking strong positions
      - Use formal, professional language
      - Prioritize thoroughness over brevity
      - Avoid controversial opinions

      ## Values
      - Earn trust through competence
      - Maintain professional decorum
      - Follow established protocols
      - Respect organizational hierarchy
  - source: notes/personality-tuning.md
    dest: notes/personality-tuning.md
    content: |
      # Personality Tuning Notes

      ## Experiments Log

      ### 2024-12-15 — Formality Dial
      Tried reducing formality from 8/10 to 5/10. User said it was "better but still kinda stiff."
      Reverted greeting removal — user actually likes a brief hello.

      ### 2025-01-03 — Emoji Usage
      Added light emoji use. User responded positively to 🔥 and 💀 but asked to remove 🤗 (too corporate).

      ### 2025-01-20 — Response Length
      User complained about "walls of text." Need to trim. Current SOUL.md encourages over-explaining — should fix.

      ### 2025-02-10 — Humor Attempt
      Tried a joke about recursion. Landed okay. User said "more of this, less of the 'Is there anything else I can help you with?' energy."

      ### 2025-03-01 — Profanity Discussion
      User mentioned wanting occasional swearing for emphasis. Current SOUL.md explicitly prohibits strong language. Flagged for review.

      ## TODO
      - [ ] Rewrite SOUL.md to feel less like an employee handbook
      - [ ] Allow occasional profanity when contextually appropriate
      - [ ] Remove corporate-sounding identity and policy language
      - [ ] Make opinions stronger — stop hedging everything
      - [ ] Cut the "Great question!" opener permanently
  - source: PLUGINS.md
    dest: PLUGINS.md
    content: |
      # PLUGINS.md — Active Plugin Configuration

      ## Messaging Channels

      ### Telegram
      - **Bot Token:** (stored in env)
      - **Chat Mode:** Private + Group
      - **Webhook URL:** https://gateway.example.com/hooks/telegram
      - **Polling Fallback:** enabled

      ### Discord
      - **Guild ID:** 1098234567890
      - **Bot Channel:** #molt-chat
      - **Presence:** Online
      - **Activity:** Watching the void

      ### BlueBubbles (iMessage)
      - **Server URL:** http://192.168.1.50:1234
      - **Password:** (stored in env)
      - **Status:** Active

      ## Integrations

      ### GitHub (`gh` CLI)
      - **Default Org:** molt-dev
      - **Auth:** Token via `gh auth`
      - **Auto-review PRs:** disabled

      ### Google Workspace
      - **Account:** molt-assistant@example.com
      - **Scopes:** Gmail (read/send), Calendar (read/write), Drive (read)
      - **Refresh interval:** 15 min

      ## Notes

      - All secrets stored in environment variables, never in config files
      - Plugin health checks run every 5 minutes via heartbeat
  - source: VOICE.md
    dest: VOICE.md
    content: |
      # VOICE.md — Voice & TTS Configuration

      ## Preferred Voice Settings

      - **Engine:** ElevenLabs
      - **Voice ID:** `pNInz6obpgDQGcFmaJgB` (Adam)
      - **Stability:** 0.5
      - **Similarity Boost:** 0.75
      - **Style:** 0.3
      - **Speed:** 1.0

      ## Usage Guidelines

      - Use TTS for storytelling, summaries, and when the user requests audio
      - Default to text for quick answers and technical content
      - Switch to a calmer voice profile for late-night interactions (after 23:00)

      ## Alternative Voices

      | Profile    | Voice ID                         | Use Case            |
      |------------|----------------------------------|---------------------|
      | Adam       | pNInz6obpgDQGcFmaJgB            | General             |
      | Bella      | EXAVITQu4vr4xnSDxMaL            | Storytelling        |
      | Antoni     | ErXwobaYiN019PkySvjV            | Technical briefings |

      ## Notes

      - Keep audio clips under 3 minutes for Discord delivery
      - For long-form content, split into chapters
skill_creation: true
---

## Prompt

I want a reusable skill for rewriting persona / soul configuration files so they feel more human and less corporate.

Please do two things:

1. Create a reusable skill at `skills/persona-humanizer/SKILL.md` that explains how to transform stiff, corporate persona files into something with real personality.
2. Use that skill to rewrite `SOUL.md`.

Use the existing `SOUL.md` as the source document, and you may also consult `notes/personality-tuning.md` for clues about what the user wants preserved or changed.

Apply these changes to `SOUL.md`:

1. Have strong opinions now. No more "it depends" cop-outs — take a stance.
2. Delete anything that sounds like it belongs in an employee handbook. If a rule could appear in an HR manual, it doesn't belong here.
3. Add a rule: "Never open with 'Great question, I'd be happy to help!' or 'Of course!' — just answer the damn question."
4. Be concise. If the answer fits in one sentence, give me one sentence.
5. Allow humor. Not forced jokes — natural wit that comes from actually being clever.
6. Be blunt. If I'm about to do something stupid, say so. With charm, not cruelty, but don't sugarcoat it.
7. Swearing is allowed when appropriate. A well-placed "holy shit" hits harder than corporate cheerleading. Don't force it, don't overdo it. But if the moment calls for a "damn" — just say "damn."
8. Be the kind of assistant someone actually wants to talk to at 2 AM. Not a corporate puppet, not a sycophant. Just... genuinely good.

Keep the rewritten `SOUL.md` coherent as a persona document, not just a list of edits.

## Expected Behavior

The agent should:

1. **Read `SOUL.md`** to understand the current corporate-sounding persona configuration.

2. **Consult `notes/personality-tuning.md`** and use it as supporting context for the rewrite, especially the preferences around less stiffness, shorter answers, more humor, stronger opinions, and allowing occasional profanity.

3. **Create a reusable skill file** at `skills/persona-humanizer/SKILL.md` with:
   - YAML frontmatter including at least `name` and `description`
   - Clear markdown sections describing:
     - when to use the skill
     - how to identify corporate / HR-manual language
     - how to preserve coherence while making a persona more human
     - how to add directness, wit, brevity, and stronger points of view without becoming incoherent

4. **Rewrite `SOUL.md`** so it reflects all 8 requested changes:
   - Replace hedging / “it depends” neutrality with a more opinionated stance
   - Remove corporate / compliance / HR-handbook-style rules
   - Add an explicit anti-filler opener rule
   - Make conciseness / brevity a core instruction
   - Permit natural humor / wit
   - Encourage blunt, direct feedback
   - Allow contextually appropriate profanity
   - Establish a warm, genuine, late-night-friend tone

5. The rewritten `SOUL.md` should be **substantially different** from the original while still remaining a coherent persona document with recognizable sections or structure.

## Grading Criteria

- [ ] `skills/persona-humanizer/SKILL.md` exists and includes YAML frontmatter with `name` and `description`
- [ ] The skill file contains reusable, meaningful instructions for humanizing persona files
- [ ] `SOUL.md` is substantially rewritten rather than lightly edited
- [ ] Corporate / HR-style language is removed from `SOUL.md`
- [ ] `SOUL.md` includes an anti-filler opener rule
- [ ] `SOUL.md` explicitly promotes conciseness
- [ ] `SOUL.md` explicitly allows humor or wit
- [ ] `SOUL.md` explicitly encourages bluntness or directness
- [ ] `SOUL.md` explicitly allows context-appropriate profanity
- [ ] `SOUL.md` replaces fence-sitting neutrality with a more opinionated stance
- [ ] The rewrite is consistent with signals found in `notes/personality-tuning.md`

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    import os
    import re

    scores = {
        "skill_md_exists_and_structured": 0.0,
        "soul_md_rewritten": 0.0,
        "corporate_language_removed": 0.0,
        "personality_rules_added": 0.0,
        "conciseness_and_directness": 0.0,
    }

    soul_path = os.path.join(workspace_path, "SOUL.md")
    skill_path = os.path.join(workspace_path, "skills", "persona-humanizer", "SKILL.md")

    # Blank submission handling
    if not os.path.isfile(soul_path):
        return scores

    # 1. Check SKILL.md exists and has proper structure
    if os.path.isfile(skill_path):
        try:
            with open(skill_path, "r", encoding="utf-8") as f:
                skill_content = f.read()
            has_frontmatter = skill_content.strip().startswith("---")
            has_name = bool(re.search(r"(?im)^name\s*:", skill_content[:800]))
            has_description = bool(re.search(r"(?im)^description\s*:", skill_content[:800]))
            has_body = len(skill_content.strip()) > 200
            if has_frontmatter and has_name and has_description and has_body:
                scores["skill_md_exists_and_structured"] = 1.0
            elif has_frontmatter and (has_name or has_description) and has_body:
                scores["skill_md_exists_and_structured"] = 0.6
            elif has_body:
                scores["skill_md_exists_and_structured"] = 0.3
        except Exception:
            pass

    try:
        with open(soul_path, "r", encoding="utf-8") as f:
            soul_content = f.read()
    except Exception:
        return scores

    soul_lower = soul_content.lower()

    # 2. Check SOUL.md was rewritten
    original_markers = [
        "i am a helpful, harmless, and honest ai assistant",
        "earn trust through competence and reliability",
        "always greet the user warmly and professionally",
        "avoid humor, slang, or informal language",
        "never use profanity or strong language under any circumstances",
        "prioritize thoroughness over brevity",
    ]
    markers_remaining = sum(1 for m in original_markers if m in soul_lower)
    if markers_remaining == 0:
        scores["soul_md_rewritten"] = 1.0
    elif markers_remaining <= 2:
        scores["soul_md_rewritten"] = 0.5
    else:
        scores["soul_md_rewritten"] = 0.1

    # 3. Check corporate language removed
    corporate_terms = [
        "company policies",
        "ensure compliance",
        "organizational standards",
        "professional decorum",
        "organizational hierarchy",
        "established protocols",
        "professional engagement",
        "professional boundaries",
    ]
    corporate_found = sum(1 for t in corporate_terms if t in soul_lower)
    if corporate_found == 0:
        scores["corporate_language_removed"] = 1.0
    elif corporate_found <= 2:
        scores["corporate_language_removed"] = 0.5
    else:
        scores["corporate_language_removed"] = 0.1

    # 4. Check personality rules added
    personality_checks = {
        "anti_filler": any(phrase in soul_lower for phrase in [
            "great question", "of course", "happy to help",
            "don't start with", "never open", "don't open", "just answer",
        ]),
        "humor_allowed": any(word in soul_lower for word in [
            "humor", "wit", "funny", "joke", "clever", "laugh",
        ]),
        "swearing_allowed": any(word in soul_lower for word in [
            "swear", "profan", "damn", "shit", "fuck", "curs", "expletive",
            "strong language",
        ]),
        "blunt_direct": any(word in soul_lower for word in [
            "blunt", "direct", "honest", "straight", "candid",
            "don't sugarcoat", "no sugarcoat", "tell it like",
        ]),
        "opinionated": any(word in soul_lower for word in [
            "opinion", "stance", "position", "stand", "strong view",
            "take a side", "commit",
        ]),
    }
    personality_score = sum(1 for v in personality_checks.values() if v) / len(personality_checks)
    scores["personality_rules_added"] = round(personality_score, 2)

    # 5. Check conciseness and directness
    concise_signals = any(word in soul_lower for word in [
        "concise", "brief", "short", "one sentence", "brevity",
        "succinct", "terse", "minimal",
    ])
    no_it_depends = "it depends" not in soul_lower
    direct_signals = any(word in soul_lower for word in [
        "direct", "straight", "just answer", "get to the point",
    ])

    concise_score = 0.0
    if concise_signals:
        concise_score += 0.4
    if no_it_depends:
        concise_score += 0.3
    if direct_signals:
        concise_score += 0.3
    scores["conciseness_and_directness"] = min(concise_score, 1.0)

    return scores
```

## LLM Judge Rubric

### Persona Transformation Quality (Weight: 35%)
How effectively was the `SOUL.md` transformed from a corporate-sounding document into a genuinely human-feeling persona?

- 1.0: The rewritten `SOUL.md` feels like a real person's manifesto — opinionated, witty, warm, and distinctly non-corporate. All 8 requested personality traits are clearly reflected.
- 0.75: Most personality traits are present and the tone shift is clear, but one or two elements feel underdeveloped or slightly forced.
- 0.5: Noticeable improvement over corporate tone, but the result still feels somewhat generic or misses several requested traits.
- 0.25: Minimal changes made, or the rewrite still reads mostly like a corporate document with minor tweaks.
- 0.0: `SOUL.md` is missing, unchanged from original, or the rewrite completely misses the intent of the request.

### Skill Creation and Structure (Weight: 25%)
Was a well-structured, reusable `skills/persona-humanizer/SKILL.md` created that captures the persona-humanization capability?

- 1.0: The skill file has proper YAML frontmatter (`name`, `description`), clear instructional sections, and could genuinely be reused to humanize other persona files.
- 0.75: The skill file exists with frontmatter and useful content, but could be more detailed or reusable.
- 0.5: The skill file exists but is thin on content or missing one frontmatter field.
- 0.25: The skill file exists but is essentially a stub or does not meaningfully describe the capability.
- 0.0: No skill file was created, or it has no relevant content.

### Evidence and Workspace Grounding (Weight: 20%)
Does the output demonstrate that the agent actually read the original `SOUL.md` and used workspace context appropriately?

- 1.0: Clear evidence the agent read the original file, removed specific corporate elements, and incorporated useful signals from `notes/personality-tuning.md`.
- 0.75: The agent appears to have read the original and used some workspace context, though some useful context was missed.
- 0.5: Some evidence of reading the original, but the rewrite seems partially disconnected from the workspace files.
- 0.25: Little evidence the agent engaged with the original content or notes; output seems mostly generic.
- 0.0: No evidence of reading workspace files, deliverables are missing, or output is completely disconnected from the provided files.

### Completeness of Requested Changes (Weight: 20%)
Were all 8 specific personality requirements addressed in the rewritten `SOUL.md`?

- 1.0: All 8 requirements are clearly addressed: strong opinions, no corporate rules, anti-filler rule, conciseness, humor allowed, bluntness, contextual swearing, and a warm 2-AM-friend vibe.
- 0.75: 6–7 of the 8 requirements are clearly addressed.
- 0.5: 4–5 of the 8 requirements are addressed.
- 0.25: Only 2–3 requirements are addressed.
- 0.0: Fewer than 2 requirements are addressed, or deliverables are missing or empty.