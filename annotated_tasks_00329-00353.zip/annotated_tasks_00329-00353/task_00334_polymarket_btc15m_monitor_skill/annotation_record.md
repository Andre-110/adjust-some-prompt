| 序号 | 修改项 | 修改原因 |
|------|--------|----------|
| 1 | 将 frontmatter 中 `workspace_files` 从旧字段 `path:` 改为规范的 `source` / `dest` 映射，并补齐全部关键 assets | 原字段格式不符合本批规范，且原列表未覆盖实际任务依赖文件 |
| 2 | 重写 Prompt，使任务以本地 workspace 数据为依据完成一次监控运行 | 原 Prompt 过度依赖实时外网，且与当前 assets 所示事实冲突 |
| 3 | 将 skill 路径从 workspace 根 `SKILL.md` 改为 `skills/polymarket-btc15m-monitor/SKILL.md` | 符合 skill 路径规范 |
| 4 | 重写 Expected Behavior | 原 Expected Behavior 错误断言“市场不可用”，与 snapshot/history/state 文件矛盾 |
| 5 | 修订 Grading Criteria | 原标准偏向奖励 `DATA-ERROR/NO-UPDATE`，无法覆盖本题真实正确答案 |
| 6 | 重写 `grade()` | 原评分逻辑检查错误路径、错误状态和错误 ground truth，不能正确评分 |
| 7 | 保留 `difficulty: medium` | 虽然任务不再依赖实时网页抓取，但仍包含 skill 创建、状态比较、文件更新与多文件推理，medium 合理 |
| 8 | 修正 `config/pm_btc15m_cron.json` 中绝对路径与实时抓取措辞 | 与 workspace 相对路径规范不一致，且应避免将正确性绑定到实时外网 |
| 9 | 修正 `config/polymarket_markets.yaml` 中绝对路径 | 与 Prompt、grade()、workspace 语义不统一 |
| 10 | 修正 `logs/pm_monitor_runs.log` 中自相矛盾记录 | 原日志存在 “0645 与 0615 相同” 这类明显逻辑错误，且与 state 文件冲突 |
| 11 | 修正 `scripts/pm_btc15m_monitor.sh` 中绝对路径 | 与 workspace 任务环境不一致 |
| 12 | 明确 `.openclaw/data/pm_btc15m_last_reported.txt` 为真实 workspace 文件 | 原资产文件位置与题面引用路径不一致，影响可执行性和可评分性 |