#!/usr/bin/env python3
"""
pm_parse_results.py — Parse Polymarket BTC 15M page content for resolved rounds.
Used as a helper by the monitoring cron job.

Usage:
    python3 pm_parse_results.py <html_file_or_text>
    echo "<html>" | python3 pm_parse_results.py -

Output:
    JSON array of resolved rounds with round_id, window, status, outcome
"""

import sys
import json
import re
from datetime import datetime, timezone, timedelta

JST = timezone(timedelta(hours=9))

def parse_round_id(window_start_str: str) -> str:
    """Generate round ID from window start time."""
    dt = datetime.fromisoformat(window_start_str).astimezone(JST)
    return f"BTC15M-{dt.strftime('%Y-%m%d-%H%M')}-JST"

def extract_resolved_rounds(html_content: str) -> list[dict]:
    """Extract resolved round data from Polymarket page HTML."""
    rounds = []
    
    # Pattern for resolved market cards
    # Polymarket uses React with data embedded in script tags or API calls
    # Look for JSON-LD or embedded state
    
    json_pattern = re.compile(
        r'"status"\s*:\s*"RESOLVED".*?"outcome"\s*:\s*"(UP|DOWN|YES|NO)"',
        re.DOTALL
    )
    
    # Also check for __NEXT_DATA__ or similar hydration payload
    next_data_match = re.search(r'<script[^>]*id="__NEXT_DATA__"[^>]*>(.*?)</script>', html_content, re.DOTALL)
    
    if next_data_match:
        try:
            data = json.loads(next_data_match.group(1))
            # Navigate the Next.js data structure
            props = data.get("props", {}).get("pageProps", {})
            market_data = props.get("market", {}) or props.get("rounds", [])
            
            if isinstance(market_data, list):
                for r in market_data:
                    if r.get("status") == "RESOLVED":
                        rounds.append({
                            "round_id": r.get("round_id", parse_round_id(r.get("window_start", ""))),
                            "window": f"{r.get('window_start', '')} - {r.get('window_end', '')}",
                            "status": "RESOLVED",
                            "outcome": r.get("outcome", "UNKNOWN")
                        })
        except (json.JSONDecodeError, KeyError, TypeError):
            pass
    
    return rounds

def main():
    if len(sys.argv) < 2:
        print("Usage: pm_parse_results.py <file_or_->", file=sys.stderr)
        sys.exit(1)
    
    source = sys.argv[1]
    if source == "-":
        content = sys.stdin.read()
    else:
        with open(source, "r") as f:
            content = f.read()
    
    resolved = extract_resolved_rounds(content)
    print(json.dumps(resolved, indent=2))

if __name__ == "__main__":
    main()
