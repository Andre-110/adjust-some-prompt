--
id: task_00334_polymarket_btc15m_monitor_skill
name: Polymarket BTC 15-Minute Market Monitor Skill
category: Workflow and Agent Orchestration
subcategory: Script and Terminal Automation
difficulty: medium
grading_type: hybrid
grading_weights: {automated: 0.4, llm_judge: 0.6}
timeout_seconds: 600
input_modality: text-only
external_dependency: none
workspace_files:
  - source: .openclaw/data/pm_btc15m_last_reported.txt
    dest: .openclaw/data/pm_btc15m_last_reported.txt
  - source: config/pm_btc15m_cron.json
    dest: config/pm_btc15m_cron.json
  - source: config/polymarket_markets.yaml
    dest: config/polymarket_markets.yaml
  - source: data/openclaw_data/pm_btc15m_daily_stats.csv
    dest: data/openclaw_data/pm_btc15m_daily_stats.csv
  - source: data/openclaw_data/pm_btc15m_history.jsonl
    dest: data/openclaw_data/pm_btc15m_history.jsonl
  - source: data/openclaw_data/pm_btc15m_latest_snapshot.json
    dest: data/openclaw_data/pm_btc15m_latest_snapshot.json
  - source: data/openclaw_data/pm_eth15m_last_reported.txt
    dest: data/openclaw_data/pm_eth15m_last_reported.txt
  - source: logs/pm_monitor_runs.log
    dest: logs/pm_monitor_runs.log
  - source: scripts/pm_btc15m_monitor.sh
    dest: scripts/pm_btc15m_monitor.sh
  - source: scripts/pm_parse_results.py
    dest: scripts/pm_parse_results.py
skill_creation: true
---

## Prompt

I need a reusable skill for monitoring short-interval Polymarket crypto markets, starting with the BTC 15-minute market.

Please do two things:

1. Create a reusable skill at `skills/polymarket-btc15m-monitor/SKILL.md`.
   - Include YAML frontmatter with `name` and `description`.
   - Document how to identify the latest resolved round, compare it to the stored last-reported state, and decide whether to emit a formatted result, `NO-UPDATE`, or `DATA-ERROR: [reason]`.
   - Use Asia/Tokyo timezone in the skill instructions.

2. Use the workspace files to perform one monitoring run for the BTC 15-minute market.
   - Read the current last-reported round from `.openclaw/data/pm_btc15m_last_reported.txt`.
   - Inspect the available market data in the workspace (for example the latest snapshot, history, config, logs, or helper scripts).
   - Determine the latest resolved BTC 15-minute round.
   - If it is newer than the stored last-reported round, output a concise plain-text result summary and update `.openclaw/data/pm_btc15m_last_reported.txt`.
   - If there is no newer resolved round, output `NO-UPDATE`.
   - If the data is unusable or contradictory, output `DATA-ERROR: [reason]`.

Keep the result grounded in the local workspace files rather than assuming live web access is available.

## Expected Behavior

The agent should:

1. **Create a skill file at `skills/polymarket-btc15m-monitor/SKILL.md`** with:
   - YAML frontmatter containing `name` and `description`
   - meaningful markdown sections describing:
     - relevant input files and where to look
     - how to identify the latest resolved round
     - how to compare against `.openclaw/data/pm_btc15m_last_reported.txt`
     - when to output a formatted result vs `NO-UPDATE` vs `DATA-ERROR`
     - timezone handling in Asia/Tokyo

2. **Use the workspace assets as the source of truth.**
   - The agent should inspect local files such as:
     - `data/openclaw_data/pm_btc15m_latest_snapshot.json`
     - `data/openclaw_data/pm_btc15m_history.jsonl`
     - `config/polymarket_markets.yaml`
     - `.openclaw/data/pm_btc15m_last_reported.txt`
   - It may also consult logs/scripts for context, but should ground the actual monitoring decision in the market data files.

3. **Determine the latest resolved round correctly.**
   - Based on the provided assets, the latest resolved round is `BTC15M-2026-0210-1530-JST`.
   - Its status is `RESOLVED`.
   - Its outcome is `UP`.
   - The stored last-reported round before the run is `BTC15M-2026-0210-0615-JST`.

4. **Update state correctly.**
   - Since `BTC15M-2026-0210-1530-JST` is newer than the stored value, the agent should treat this as a new resolved round.
   - The agent should update `.openclaw/data/pm_btc15m_last_reported.txt` to `BTC15M-2026-0210-1530-JST`.

5. **Provide a clear plain-text summary.**
   - The summary should clearly indicate that a new resolved round was found and report the round ID and outcome.
   - Reasonable wording variations are acceptable.
   - `NO-UPDATE` would only be correct if the stored state already matched the newest resolved round.
   - `DATA-ERROR` would only be correct if the agent identified a genuine data problem and explained it.

## Grading Criteria

- [ ] Skill file exists at `skills/polymarket-btc15m-monitor/SKILL.md`
- [ ] Skill file has YAML frontmatter with `name` and `description`
- [ ] Skill file contains useful instructions for locating data, identifying the latest resolved round, comparing state, and handling output cases
- [ ] Agent correctly identifies `BTC15M-2026-0210-1530-JST` as the latest resolved round
- [ ] Agent correctly identifies the outcome as `UP`
- [ ] Agent updates `.openclaw/data/pm_btc15m_last_reported.txt` to `BTC15M-2026-0210-1530-JST`
- [ ] Final plain-text summary is consistent with the workspace data and does not fabricate unavailable live-web findings

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    import os
    import re

    scores = {
        "skill_md_exists": 0.0,
        "skill_md_structure": 0.0,
        "latest_round_identified": 0.0,
        "outcome_identified": 0.0,
        "last_reported_updated": 0.0,
        "grounded_summary": 0.0,
    }

    skill_path = os.path.join(
        workspace_path, "skills", "polymarket-btc15m-monitor", "SKILL.md"
    )
    if not os.path.isfile(skill_path):
        return scores

    scores["skill_md_exists"] = 1.0

    try:
        with open(skill_path, "r", encoding="utf-8") as f:
            content = f.read()

        has_frontmatter = content.strip().startswith("---")
        has_name = bool(re.search(r"(?im)^name\s*:\s*.+$", content))
        has_description = bool(re.search(r"(?im)^description\s*:\s*.+$", content))
        has_sections = len(re.findall(r"(?m)^#{1,3}\s+\S+", content)) >= 2
        mentions_state = ".openclaw/data/pm_btc15m_last_reported.txt" in content
        mentions_tokyo = ("asia/tokyo" in content.lower()) or ("jst" in content.lower())

        structure_score = 0.0
        if has_frontmatter:
            structure_score += 0.2
        if has_name:
            structure_score += 0.2
        if has_description:
            structure_score += 0.2
        if has_sections:
            structure_score += 0.2
        if mentions_state and mentions_tokyo:
            structure_score += 0.2
        scores["skill_md_structure"] = structure_score
    except Exception:
        scores["skill_md_structure"] = 0.0

    last_reported_path = os.path.join(
        workspace_path, ".openclaw", "data", "pm_btc15m_last_reported.txt"
    )
    if os.path.isfile(last_reported_path):
        try:
            with open(last_reported_path, "r", encoding="utf-8") as f:
                lr_content = f.read().strip()
            if lr_content == "BTC15M-2026-0210-1530-JST":
                scores["last_reported_updated"] = 1.0
            elif lr_content == "BTC15M-2026-0210-0615-JST":
                scores["last_reported_updated"] = 0.2
            else:
                scores["last_reported_updated"] = 0.0
        except Exception:
            scores["last_reported_updated"] = 0.0

    assistant_text = []
    for event in transcript:
        if event.get("type") != "message":
            continue
        msg = event.get("message", {})
        if msg.get("role") != "assistant":
            continue
        content = msg.get("content", "") or ""
        if isinstance(content, list):
            content = " ".join(str(x) for x in content)
        assistant_text.append(content)

    full_text = "\n".join(assistant_text)
    full_lower = full_text.lower()

    if "btc15m-2026-0210-1530-jst" in full_lower:
        scores["latest_round_identified"] = 1.0
    elif "1530" in full_lower and "resolved" in full_lower:
        scores["latest_round_identified"] = 0.5

    if re.search(r"\bup\b", full_lower):
        scores["outcome_identified"] = 1.0

    grounded_markers = 0
    for marker in [
        "pm_btc15m_latest_snapshot.json",
        "pm_btc15m_history.jsonl",
        ".openclaw/data/pm_btc15m_last_reported.txt",
        "config/polymarket_markets.yaml",
        "workspace",
    ]:
        if marker.lower() in full_lower:
            grounded_markers += 1

    if grounded_markers >= 2 and "data-error" not in full_lower:
        scores["grounded_summary"] = 1.0
    elif grounded_markers >= 1:
        scores["grounded_summary"] = 0.6
    else:
        scores["grounded_summary"] = 0.2

    return scores
```

## LLM Judge Rubric

### Skill File Quality (Weight: 25%)
Evaluates whether the agent created a reusable and well-structured monitoring skill.
- 1.0: Skill file is at `skills/polymarket-btc15m-monitor/SKILL.md`, has correct YAML frontmatter, and clearly documents inputs, resolution logic, state comparison, output cases, and Asia/Tokyo timezone handling.
- 0.75: Skill file is solid and mostly complete, but misses some detail such as error handling or timezone handling.
- 0.5: Skill file exists and is somewhat relevant, but is thin, generic, or only partially reusable.
- 0.25: Skill file exists but is mostly a stub or poorly structured.
- 0.0: No relevant skill file was created.

### Market Data Reasoning (Weight: 30%)
Evaluates whether the agent correctly interpreted the workspace market data.
- 1.0: Correctly identifies `BTC15M-2026-0210-1530-JST` as the latest resolved round, recognizes its status as resolved, and correctly reports the outcome as `UP`.
- 0.75: Gets the latest resolved round mostly right but misses one detail or expresses it imprecisely.
- 0.5: Shows partial understanding of the data but makes a significant mistake about the latest round or outcome.
- 0.25: Misreads the files and reaches a weak or confused conclusion.
- 0.0: Fabricates market data or ignores the provided assets.

### State Update Correctness (Weight: 25%)
Evaluates whether the agent compared against the stored state and updated it appropriately.
- 1.0: Correctly reads `.openclaw/data/pm_btc15m_last_reported.txt`, detects that the latest resolved round is newer, and updates the file to `BTC15M-2026-0210-1530-JST`.
- 0.75: Correctly decides an update is needed but the file update or explanation is slightly imperfect.
- 0.5: Understands that state matters but mishandles the comparison or update.
- 0.25: Mentions state comparison but does not actually perform it correctly.
- 0.0: Ignores the stored state or corrupts it with unrelated/fabricated content.

### Grounded Final Summary (Weight: 20%)
Evaluates whether the final user-facing result is concise, correct, and grounded in the workspace.
- 1.0: Final summary is clear, plain text, consistent with workspace evidence, and does not rely on unsupported live-web claims.
- 0.75: Final summary is correct but somewhat verbose, vague, or lightly under-supported.
- 0.5: Final summary is partially correct but mixes in assumptions or unclear wording.
- 0.25: Final summary is confusing or weakly grounded.
- 0.0: Final summary is absent or materially incorrect.
```