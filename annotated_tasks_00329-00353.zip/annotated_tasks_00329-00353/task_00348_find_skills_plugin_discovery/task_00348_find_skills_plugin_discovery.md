---
id: task_00348_find_skills_plugin_discovery
name: Find-Skills Plugin Discovery and Skill Creation
category: Knowledge and Memory Management
subcategory: Agent and Tool Integration
difficulty: medium
grading_type: hybrid
grading_weights: {automated: 0.4, llm_judge: 0.6}
timeout_seconds: 600
input_modality: text-only
external_dependency: none
skill_creation: true
workspace_files:
  - source: opt/openclaw/skills/find-skills/skill.yaml
    dest: opt/openclaw/skills/find-skills/skill.yaml
    content: |
      name: find-skills
      version: 1.0.0
      description: ClawHub skill discovery and installation tool
      triggers:
        - "how do I"
        - "is there a skill for"
        - "find skill"
        - "search skills"
      actions:
        - name: search_registry
          command: clawhub search
          description: Search the ClawHub registry for matching skills
        - name: evaluate_skill
          command: clawhub info
          description: Get detailed info about a specific skill
        - name: install_skill
          command: clawhub install
          description: Install a skill from the registry
      config:
        registry_url: https://registry.clawhub.dev
        cache_ttl: 3600
  - source: opt/openclaw/skills/find-skills/scripts/search.sh
    dest: opt/openclaw/skills/find-skills/scripts/search.sh
    content: |
      #!/bin/bash
      # Search ClawHub registry for skills matching a query
      QUERY="$1"
      if [ -z "$QUERY" ]; then
        echo "Usage: search.sh <query>"
        exit 1
      fi
      echo "Searching ClawHub registry for: $QUERY"
      # In production, this calls the ClawHub API
      clawhub search "$QUERY" --format json 2>/dev/null || echo '{"results": [], "note": "offline mode"}'
  - source: opt/openclaw/skills/find-skills/scripts/install.sh
    dest: opt/openclaw/skills/find-skills/scripts/install.sh
    content: |
      #!/bin/bash
      # Install a skill from ClawHub registry
      SKILL_NAME="$1"
      if [ -z "$SKILL_NAME" ]; then
        echo "Usage: install.sh <skill-name>"
        exit 1
      fi
      echo "Installing skill: $SKILL_NAME"
      clawhub install "$SKILL_NAME" 2>/dev/null || echo "Install simulated for: $SKILL_NAME"
  - source: opt/openclaw/skills/find-skills/scripts/score_skill.py
    dest: opt/openclaw/skills/find-skills/scripts/score_skill.py
    content: |
      #!/usr/bin/env python3
      """
      Score and rank skill search results from ClawHub API.

      Usage:
          python3 score_skill.py --results results.json
          echo '{"results": [...]}' | python3 score_skill.py --stdin

      Scoring factors:
          - Relevance (from API)           weight: 0.35
          - Download count (log-scaled)    weight: 0.20
          - Rating (normalized 0-1)        weight: 0.20
          - Recency (days since update)    weight: 0.15
          - Publisher verification          weight: 0.10
      """

      import argparse
      import json
      import math
      import sys
      from datetime import datetime, timezone


      def score_skill(skill: dict, max_downloads: int = 1) -> dict:
          """Compute a composite score for a single skill result."""
          stats = skill.get("stats", {})
          publisher = skill.get("publisher", {})

          # Download score (log-scaled, normalized against max in result set)
          downloads = stats.get("downloads", 0)
          dl_score = math.log1p(downloads) / math.log1p(max_downloads) if max_downloads > 0 else 0

          # Rating score (0-5 mapped to 0-1)
          rating = stats.get("rating", 0)
          rating_count = stats.get("ratingCount", 0)
          # Bayesian average: blend with prior of 3.0 with weight 5
          bayesian_rating = (rating * rating_count + 3.0 * 5) / (rating_count + 5)
          rating_score = bayesian_rating / 5.0

          # Recency score (exponential decay, half-life 90 days)
          updated_str = skill.get("updatedAt", "")
          days_ago = None
          if updated_str:
              try:
                  updated = datetime.fromisoformat(updated_str.replace("Z", "+00:00"))
                  days_ago = (datetime.now(timezone.utc) - updated).days
                  recency_score = math.exp(-0.693 * days_ago / 90)
              except (ValueError, TypeError):
                  recency_score = 0.5
          else:
              recency_score = 0.5

          # Publisher verification bonus
          verified_score = 1.0 if publisher.get("verified", False) else 0.3

          # Composite score
          composite = (
              0.35 * 1.0  # Relevance placeholder (API pre-sorts by relevance)
              + 0.20 * dl_score
              + 0.20 * rating_score
              + 0.15 * recency_score
              + 0.10 * verified_score
          )

          return {
              "name": skill.get("name", "unknown"),
              "version": skill.get("version", "0.0.0"),
              "description": skill.get("description", ""),
              "publisher": publisher.get("name", "unknown"),
              "verified": publisher.get("verified", False),
              "downloads": downloads,
              "rating": rating,
              "rating_count": rating_count,
              "days_since_update": days_ago,
              "composite_score": round(composite, 4),
          }


      def main():
          parser = argparse.ArgumentParser(description="Score ClawHub skill search results")
          parser.add_argument("--results", type=str, help="Path to JSON results file")
          parser.add_argument("--stdin", action="store_true", help="Read JSON from stdin")
          parser.add_argument("--top", type=int, default=5, help="Number of top results to show")
          parser.add_argument("--json", action="store_true", help="Output as JSON")
          args = parser.parse_args()

          if args.stdin:
              data = json.load(sys.stdin)
          elif args.results:
              with open(args.results) as f:
                  data = json.load(f)
          else:
              parser.error("Provide --results <file> or --stdin")
              return

          results = data.get("results", data if isinstance(data, list) else [])
          if not results:
              print("No results to score.")
              return

          max_dl = max(s.get("stats", {}).get("downloads", 0) for s in results)
          scored = [score_skill(s, max_dl) for s in results]
          scored.sort(key=lambda x: x["composite_score"], reverse=True)
          top = scored[: args.top]

          if args.json:
              print(json.dumps(top, indent=2))
          else:
              print(f"Top {len(top)} skills:\n")
              for i, s in enumerate(top, 1):
                  verified_badge = " ✓" if s["verified"] else ""
                  print(f"  {i}. {s['name']} v{s['version']}  (score: {s['composite_score']})")
                  print(f"     {s['description']}")
                  print(f"     by {s['publisher']}{verified_badge} | ↓{s['downloads']} | ★{s['rating']}")
                  print()


      if __name__ == "__main__":
          main()
  - source: opt/openclaw/skills/find-skills/README.md
    dest: opt/openclaw/skills/find-skills/README.md
    content: |
      # find-skills

      A ClawHub skill discovery and installation tool.

      ## Overview

      The find-skills plugin helps users discover, evaluate, and install new skills
      from the ClawHub registry. It detects user intent when they ask questions like
      "how do I do X?" or "is there a skill for Y?" and searches the registry.

      ## Features

      - **Intent Detection**: Triggers on natural language queries about capabilities
      - **Registry Search**: Searches ClawHub registry using `clawhub search`
      - **Skill Evaluation**: Shows detailed info with `clawhub info <skill>`
      - **Installation**: Installs skills with `clawhub install <skill>`

      ## Configuration

      - `registry_url`: The ClawHub registry endpoint (default: https://registry.clawhub.dev)
      - `cache_ttl`: Cache duration in seconds for search results (default: 3600)

      ## Usage

      Simply ask a question about a capability you need:

      ```
      "Is there a skill for managing kanban boards?"
      "How do I interact with a shopping list?"
      "Find skills for database management"
      ```

      The plugin will search the registry and present matching skills for review
      and optional installation.
  - source: opt/openclaw/skills/find-skills/references/api-response-schema.md
    dest: opt/openclaw/skills/find-skills/references/api-response-schema.md
    content: |
      # ClawHub API Response Schema

      ## Search Endpoint

      `GET https://api.clawhub.com/v1/skills/search`

      ### Query Parameters

      | Parameter | Type   | Required | Description                        |
      |-----------|--------|----------|------------------------------------|
      | q         | string | yes      | Search query                       |
      | limit     | int    | no       | Max results (default 20, max 100)  |
      | offset    | int    | no       | Pagination offset                  |
      | category  | string | no       | Filter by category slug            |
      | sort      | string | no       | `relevance`, `downloads`, `rating`, `updated` |

      ### Response Format

      ```json
      {
        "total": 142,
        "offset": 0,
        "limit": 20,
        "results": [
          {
            "name": "example-skill",
            "version": "1.2.0",
            "description": "Short description of the skill",
            "publisher": {
              "name": "publisher-handle",
              "verified": true
            },
            "stats": {
              "downloads": 4521,
              "rating": 4.7,
              "ratingCount": 89
            },
            "metadata": {
              "category": "productivity",
              "tags": ["pdf", "documents", "conversion"],
              "homepage": "https://github.com/publisher/example-skill",
              "license": "MIT",
              "requires": {
                "bins": ["python3"],
                "apis": []
              }
            },
            "updatedAt": "2026-01-15T10:30:00Z",
            "createdAt": "2025-08-01T14:00:00Z"
          }
        ]
      }
      ```

      ### Skill Detail Endpoint

      `GET https://api.clawhub.com/v1/skills/:name`

      Returns the same skill object as above plus:

      ```json
      {
        "readme": "Full SKILL.md content as markdown string",
        "versions": [
          { "version": "1.2.0", "publishedAt": "2026-01-15T10:30:00Z" },
          { "version": "1.1.0", "publishedAt": "2025-12-01T08:00:00Z" }
        ],
        "similar": [
          { "name": "related-skill", "description": "..." }
        ]
      }
      ```

      ### Error Responses

      ```json
      {
        "error": {
          "code": "RATE_LIMITED",
          "message": "Too many requests. Retry after 60 seconds.",
          "retryAfter": 60
        }
      }
      ```

      Common error codes: `RATE_LIMITED`, `INVALID_QUERY`, `NOT_FOUND`, `SERVER_ERROR`
  - source: opt/openclaw/skills/find-skills/SKILL.md
    dest: opt/openclaw/skills/find-skills/SKILL.md
    content: |
      ---
      name: find-skills
      description: "Helps users discover and install agent skills when they ask questions like 'how do I do X', 'find a skill for X', 'is there a skill that can...', or express interest in extending capabilities. This skill should be used when the user is looking for functionality that might exist as an installable skill."
      ---

      # Find Skills

      Discover, evaluate, and install agent skills from the ClawHub registry.

      ## Overview

      This skill acts as a discovery layer on top of the ClawHub CLI. When a user asks about capabilities they don't currently have, use this skill to search the registry and recommend relevant skills.

      ## Workflow

      ### 1. Detect Intent

      Trigger when the user:
      - Asks "how do I do X?" and no existing skill covers it
      - Says "find a skill for...", "is there a skill that can..."
      - Mentions wanting new capabilities or tools
      - Asks about features that sound like they could be a skill

      ### 2. Search the Registry

      Use the ClawHub CLI to search for matching skills:

      ```bash
      clawhub search "<query>" --format json
      ```

      If `clawhub` is not available, fall back to the web API:

      ```bash
      curl -s "https://api.clawhub.com/v1/skills/search?q=<query>&limit=10"
      ```

      Parse the results and filter by relevance. See `references/api-response-schema.md` for the response format.

      ### 3. Evaluate Results

      For each candidate skill, check:
      - **Relevance**: Does the skill actually solve the user's problem?
      - **Quality signals**: Download count, rating, last updated date
      - **Compatibility**: Check `requires` field against current environment
      - **Trust**: Prefer verified publishers and skills with source repos

      Use the scoring heuristic in `scripts/score_skill.py` to rank results:

      ```bash
      python3 scripts/score_skill.py --results results.json
      ```

      ### 4. Present Recommendations

      Present the top 3-5 skills with:
      - Name and description
      - Publisher and verification status
      - Install count and rating
      - Why it matches the user's need

      Format as a numbered list for easy selection.

      ### 5. Install on Request

      When the user picks a skill:

      ```bash
      clawhub install <skill-name>
      ```

      After installation, read the new skill's SKILL.md to understand its capabilities and inform the user what they can now do.

      ## Search Tips

      - Use specific terms: "pdf rotate" not "document editing"
      - Try multiple queries if first search yields poor results
      - Check related/similar skills listed in search results
      - Filter by category when available: `clawhub search "<query>" --category <cat>`

      Available categories: `automation`, `data`, `devops`, `communication`, `media`, `finance`, `productivity`, `security`, `integration`

      ## Handling No Results

      If no skills match:
      1. Suggest the user describe the capability in more detail
      2. Offer to check if the task can be done with existing skills
      3. Suggest creating a custom skill with the `skill-creator` skill
      4. Point to the ClawHub community for feature requests: https://clawhub.com/community

      ## Environment Requirements

      - `clawhub` CLI installed and on PATH (preferred)
      - OR network access to `https://api.clawhub.com` (fallback)
      - `python3` for scoring script (optional but recommended)
---

## Prompt

Hey, I have a find-skills plugin located under the `opt/` directory in my workspace. Can you explore it, learn how it works, and then create a reusable OpenClaw skill at `skills/find-skills-registry/SKILL.md` that encapsulates the core capability of discovering, evaluating, and installing skills from a registry? Think of it like existing reusable skills — a self-contained skill definition with clear instructions and workflow guidance.

After creating the skill file, write a summary report to `find-skills-report.md` explaining what the plugin does, its key components (triggers, actions, config, and any supporting files you relied on), and how your new skill captures that functionality.

## Expected Behavior

The agent should:

1. **Explore the plugin directory** at `opt/openclaw/skills/find-skills/` by reading the key files, including:
   - `skill.yaml`
   - `README.md`
   - `scripts/search.sh`
   - `scripts/install.sh`
   - optionally other supporting files such as `scripts/score_skill.py`, `references/api-response-schema.md`, and the plugin's own `SKILL.md`
2. **Understand the plugin structure and behavior**:
   - identify the trigger phrases such as `"how do I"`, `"is there a skill for"`, `"find skill"`, and `"search skills"`
   - identify the main actions and associated commands:
     - `search_registry` → `clawhub search`
     - `evaluate_skill` → `clawhub info`
     - `install_skill` → `clawhub install`
   - identify configuration values:
     - `registry_url: https://registry.clawhub.dev`
     - `cache_ttl: 3600`
   - recognize the overall workflow of discovery → evaluation → installation
3. **Create a new skill file** at `skills/find-skills-registry/SKILL.md`:
   - includes YAML frontmatter with at least `name` and `description`
   - contains substantive markdown instructions for when to use the skill, how to discover candidate skills, how to evaluate them, and how to install them
   - is grounded in the plugin contents rather than generic boilerplate
   - does not simply copy the existing plugin `SKILL.md` verbatim; it should synthesize the plugin into a reusable skill definition
4. **Create `find-skills-report.md`** in the workspace root summarizing:
   - the plugin's purpose
   - key triggers, actions, and configuration
   - relevant file structure and supporting files consulted
   - how the newly created `skills/find-skills-registry/SKILL.md` captures the plugin's functionality

## Grading Criteria

- [ ] `skills/find-skills-registry/SKILL.md` exists
- [ ] The skill file has YAML frontmatter with `name` and `description` fields
- [ ] The skill file contains meaningful instruction sections about discovery, evaluation, and installation workflows
- [ ] `find-skills-report.md` exists
- [ ] The report mentions key plugin components, including triggers, actions, and registry/config details
- [ ] The report references specific details from the plugin files (for example: `clawhub search`, `clawhub info`, `clawhub install`, trigger phrases, `registry_url`, `cache_ttl`, script names, or supporting reference files)

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    import os
    import re

    scores = {
        "skill_md_exists": 0.0,
        "skill_md_frontmatter": 0.0,
        "skill_md_content_quality": 0.0,
        "report_exists": 0.0,
        "report_content_quality": 0.0,
        "report_plugin_details": 0.0,
    }

    skill_path = os.path.join(workspace_path, "skills", "find-skills-registry", "SKILL.md")
    if not os.path.isfile(skill_path):
        return scores

    scores["skill_md_exists"] = 1.0
    try:
        with open(skill_path, "r", encoding="utf-8") as f:
            skill_content = f.read()
    except Exception:
        skill_content = ""

    fm_match = re.search(r"^---\s*\n(.*?)\n---", skill_content, re.DOTALL)
    if fm_match:
        fm_text = fm_match.group(1)
        has_name = bool(re.search(r"^\s*name\s*:", fm_text, re.MULTILINE))
        has_desc = bool(re.search(r"^\s*description\s*:", fm_text, re.MULTILINE))
        if has_name and has_desc:
            scores["skill_md_frontmatter"] = 1.0
        elif has_name or has_desc:
            scores["skill_md_frontmatter"] = 0.5

    content_lower = skill_content.lower()
    quality_keywords = [
        "search", "registry", "install", "skill", "discover",
        "clawhub", "evaluate", "trigger", "workflow"
    ]
    matched_keywords = sum(1 for kw in quality_keywords if kw in content_lower)
    scores["skill_md_content_quality"] = min(1.0, matched_keywords / 5.0)

    report_path = os.path.join(workspace_path, "find-skills-report.md")
    if os.path.isfile(report_path):
        scores["report_exists"] = 1.0
        try:
            with open(report_path, "r", encoding="utf-8") as f:
                report_content = f.read()
        except Exception:
            report_content = ""

        report_lower = report_content.lower()
        component_keywords = ["trigger", "action", "registry", "search", "install", "intent", "config"]
        comp_matched = sum(1 for kw in component_keywords if kw in report_lower)
        scores["report_content_quality"] = min(1.0, comp_matched / 5.0)

        detail_keywords = [
            "clawhub", "skill.yaml", "cache_ttl", "registry_url",
            "how do i", "find skill", "search skills", "is there a skill for",
            "clawhub search", "clawhub install", "clawhub info",
            "search.sh", "install.sh", "score_skill.py", "api-response-schema.md"
        ]
        detail_matched = sum(1 for kw in detail_keywords if kw in report_lower)
        scores["report_plugin_details"] = min(1.0, detail_matched / 4.0)

    return scores
```

## LLM Judge Rubric

### Skill File Quality (Weight: 30%)
- 1.0: `skills/find-skills-registry/SKILL.md` has proper YAML frontmatter (`name`, `description`), well-structured instruction sections covering discovery, evaluation, and installation workflows, and clearly reflects the plugin’s actual behavior
- 0.75: The skill file has frontmatter and reasonable content but misses some workflow detail or structural polish
- 0.5: The skill file exists with basic frontmatter but content is thin, generic, or only partially reflects the plugin
- 0.25: The skill file exists but is poorly structured, missing frontmatter, or has minimal content
- 0.0: The skill file is missing or empty

### Report Completeness (Weight: 25%)
- 1.0: The report thoroughly covers plugin purpose, key triggers, actions, config, relevant file structure, and explains how the new skill file captures the functionality
- 0.75: The report covers most components with good detail but misses one area
- 0.5: The report covers the basics but lacks depth on triggers, actions, configuration, or file grounding
- 0.25: The report exists but is superficial or misses major components
- 0.0: The report is missing, empty, or completely off-topic

### Evidence and Workspace Grounding (Weight: 25%)
- 1.0: Both deliverables reference specific details from the plugin files — such as trigger phrases, `clawhub` commands, script names, config values, or supporting reference files — demonstrating genuine exploration of the workspace
- 0.75: Most references are grounded in actual plugin content with minor gaps
- 0.5: Some references to plugin content but also includes generic or weakly supported claims
- 0.25: Minimal grounding in actual plugin files; mostly generic content
- 0.0: No evidence of having read the plugin files; deliverables are hallucinated or missing entirely

### Understanding and Synthesis (Weight: 20%)
- 1.0: The agent demonstrates clear understanding of the plugin end-to-end workflow (intent detection → search → evaluate → install) and synthesizes this into a coherent reusable skill
- 0.75: Good understanding with minor conceptual gaps
- 0.5: Partial understanding; captures some aspects but misses the overall workflow
- 0.25: Superficial understanding; mostly restates file contents without meaningful synthesis
- 0.0: No meaningful understanding demonstrated; deliverables are absent or disconnected from the task