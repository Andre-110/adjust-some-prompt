| 序号 | 修改项 | 修改原因 |
|------|--------|----------|
| 1 | 将 `workspace_files` 中旧字段 `path:` 改为规范写法 `dest:` | 当前数据规范禁止继续使用旧字段 `path:` |
| 2 | 补齐 `workspace_files` 中遗漏的 assets 文件：`scripts/score_skill.py`、`references/api-response-schema.md`、插件目录下已有 `SKILL.md` | 题目实际依赖/可参考文件应在元数据中完整列出，保证环境描述一致 |
| 3 | 将输出技能文件路径从 workspace 根 `SKILL.md` 改为 `skills/find-skills-registry/SKILL.md` | 符合 OpenClaw 技能路径规范，避免与系统要求冲突 |
| 4 | 同步修改 Prompt 中关于输出文件位置的描述 | 与技能路径规范及自动评分保持一致 |
| 5 | 同步修改 Expected Behavior 中关于技能文件位置和要求的描述 | 保持任务说明一致，避免歧义 |
| 6 | 同步修改 Grading Criteria 中关于技能文件存在性与内容的检查对象 | 与新的规范路径对齐 |
| 7 | 修改 `grade()` 中技能文件读取路径为 `skills/find-skills-registry/SKILL.md` | 原评分逻辑读取错误路径，无法正确评分 |
| 8 | 在 `grade()` 中增加主输出文件不存在时直接返回全 0 | 满足“空白零分”要求 |
| 9 | 扩充 `grade()` 对内容质量关键词的覆盖 | 提高评分区分度，兼顾 discovery/evaluation/install 等关键能力 |
| 10 | 扩充 report 细节检查关键词，纳入 `score_skill.py` 和 `api-response-schema.md` | 更好评估是否真实探索了 workspace 文件 |
| 11 | 修改 LLM Judge Rubric 中技能文件路径与措辞 | 与修正后的任务目标一致 |
| 12 | 修复 assets 中 `scripts/score_skill.py` 里 `days_ago` 可能未定义的问题 | 提升环境文件质量，避免潜在运行错误 |
| 13 | 在 Expected Behavior 中强调“不要原样复制已有插件 SKILL.md，而是进行综合归纳” | 避免任务被已有 asset 中的 `SKILL.md` 干扰，确保考察 synthesis 能力 |