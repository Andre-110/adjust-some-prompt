---
name: find-skills
description: "Helps users discover and install agent skills when they ask questions like 'how do I do X', 'find a skill for X', 'is there a skill that can...', or express interest in extending capabilities. This skill should be used when the user is looking for functionality that might exist as an installable skill."
---

# Find Skills

Discover, evaluate, and install agent skills from the ClawHub registry.

## Overview

This skill acts as a discovery layer on top of the ClawHub CLI. When a user asks about capabilities they don't currently have, use this skill to search the registry and recommend relevant skills.

## Workflow

### 1. Detect Intent

Trigger when the user:
- Asks "how do I do X?" and no existing skill covers it
- Says "find a skill for...", "is there a skill that can..."
- Mentions wanting new capabilities or tools
- Asks about features that sound like they could be a skill

### 2. Search the Registry

Use the ClawHub CLI to search for matching skills:

```bash
clawhub search "<query>" --format json
```

If `clawhub` is not available, fall back to the web API:

```bash
curl -s "https://api.clawhub.com/v1/skills/search?q=<query>&limit=10"
```

Parse the results and filter by relevance. See `references/api-response-schema.md` for the response format.

### 3. Evaluate Results

For each candidate skill, check:
- **Relevance**: Does the skill actually solve the user's problem?
- **Quality signals**: Download count, rating, last updated date
- **Compatibility**: Check `requires` field against current environment
- **Trust**: Prefer verified publishers and skills with source repos

Use the scoring heuristic in `scripts/score_skill.py` to rank results:

```bash
python3 scripts/score_skill.py --results results.json
```

### 4. Present Recommendations

Present the top 3-5 skills with:
- Name and description
- Publisher and verification status
- Install count and rating
- Why it matches the user's need

Format as a numbered list for easy selection.

### 5. Install on Request

When the user picks a skill:

```bash
clawhub install <skill-name>
```

After installation, read the new skill's SKILL.md to understand its capabilities and inform the user what they can now do.

## Search Tips

- Use specific terms: "pdf rotate" not "document editing"
- Try multiple queries if first search yields poor results
- Check related/similar skills listed in search results
- Filter by category when available: `clawhub search "<query>" --category <cat>`

Available categories: `automation`, `data`, `devops`, `communication`, `media`, `finance`, `productivity`, `security`, `integration`

## Handling No Results

If no skills match:
1. Suggest the user describe the capability in more detail
2. Offer to check if the task can be done with existing skills
3. Suggest creating a custom skill with the `skill-creator` skill
4. Point to the ClawHub community for feature requests: https://clawhub.com/community

## Environment Requirements

- `clawhub` CLI installed and on PATH (preferred)
- OR network access to `https://api.clawhub.com` (fallback)
- `python3` for scoring script (optional but recommended)
