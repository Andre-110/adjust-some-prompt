# ClawHub API Response Schema

## Search Endpoint

`GET https://api.clawhub.com/v1/skills/search`

### Query Parameters

| Parameter | Type   | Required | Description                        |
|-----------|--------|----------|------------------------------------|
| q         | string | yes      | Search query                       |
| limit     | int    | no       | Max results (default 20, max 100)  |
| offset    | int    | no       | Pagination offset                  |
| category  | string | no       | Filter by category slug            |
| sort      | string | no       | `relevance`, `downloads`, `rating`, `updated` |

### Response Format

```json
{
  "total": 142,
  "offset": 0,
  "limit": 20,
  "results": [
    {
      "name": "example-skill",
      "version": "1.2.0",
      "description": "Short description of the skill",
      "publisher": {
        "name": "publisher-handle",
        "verified": true
      },
      "stats": {
        "downloads": 4521,
        "rating": 4.7,
        "ratingCount": 89
      },
      "metadata": {
        "category": "productivity",
        "tags": ["pdf", "documents", "conversion"],
        "homepage": "https://github.com/publisher/example-skill",
        "license": "MIT",
        "requires": {
          "bins": ["python3"],
          "apis": []
        }
      },
      "updatedAt": "2026-01-15T10:30:00Z",
      "createdAt": "2025-08-01T14:00:00Z"
    }
  ]
}
```

### Skill Detail Endpoint

`GET https://api.clawhub.com/v1/skills/:name`

Returns the same skill object as above plus:

```json
{
  "readme": "Full SKILL.md content as markdown string",
  "versions": [
    { "version": "1.2.0", "publishedAt": "2026-01-15T10:30:00Z" },
    { "version": "1.1.0", "publishedAt": "2025-12-01T08:00:00Z" }
  ],
  "similar": [
    { "name": "related-skill", "description": "..." }
  ]
}
```

### Error Responses

```json
{
  "error": {
    "code": "RATE_LIMITED",
    "message": "Too many requests. Retry after 60 seconds.",
    "retryAfter": 60
  }
}
```

Common error codes: `RATE_LIMITED`, `INVALID_QUERY`, `NOT_FOUND`, `SERVER_ERROR`
