#!/usr/bin/env python3
"""
Score and rank skill search results from ClawHub API.

Usage:
    python3 score_skill.py --results results.json
    echo '{"results": [...]}' | python3 score_skill.py --stdin

Scoring factors:
    - Relevance (from API)           weight: 0.35
    - Download count (log-scaled)    weight: 0.20
    - Rating (normalized 0-1)        weight: 0.20
    - Recency (days since update)    weight: 0.15
    - Publisher verification          weight: 0.10
"""

import argparse
import json
import math
import sys
from datetime import datetime, timezone


def score_skill(skill: dict, max_downloads: int = 1) -> dict:
    """Compute a composite score for a single skill result."""
    stats = skill.get("stats", {})
    metadata = skill.get("metadata", {})
    publisher = skill.get("publisher", {})

    # Download score (log-scaled, normalized against max in result set)
    downloads = stats.get("downloads", 0)
    dl_score = math.log1p(downloads) / math.log1p(max_downloads) if max_downloads > 0 else 0

    # Rating score (0-5 mapped to 0-1)
    rating = stats.get("rating", 0)
    rating_count = stats.get("ratingCount", 0)
    # Bayesian average: blend with prior of 3.0 with weight 5
    bayesian_rating = (rating * rating_count + 3.0 * 5) / (rating_count + 5)
    rating_score = bayesian_rating / 5.0

    # Recency score (exponential decay, half-life 90 days)
    updated_str = skill.get("updatedAt", "")
    if updated_str:
        try:
            updated = datetime.fromisoformat(updated_str.replace("Z", "+00:00"))
            days_ago = (datetime.now(timezone.utc) - updated).days
            recency_score = math.exp(-0.693 * days_ago / 90)
        except (ValueError, TypeError):
            recency_score = 0.5
    else:
        recency_score = 0.5

    # Publisher verification bonus
    verified_score = 1.0 if publisher.get("verified", False) else 0.3

    # Composite score
    composite = (
        0.35 * 1.0  # Relevance placeholder (API pre-sorts by relevance)
        + 0.20 * dl_score
        + 0.20 * rating_score
        + 0.15 * recency_score
        + 0.10 * verified_score
    )

    return {
        "name": skill.get("name", "unknown"),
        "version": skill.get("version", "0.0.0"),
        "description": skill.get("description", ""),
        "publisher": publisher.get("name", "unknown"),
        "verified": publisher.get("verified", False),
        "downloads": downloads,
        "rating": rating,
        "rating_count": rating_count,
        "days_since_update": days_ago if updated_str else None,
        "composite_score": round(composite, 4),
    }


def main():
    parser = argparse.ArgumentParser(description="Score ClawHub skill search results")
    parser.add_argument("--results", type=str, help="Path to JSON results file")
    parser.add_argument("--stdin", action="store_true", help="Read JSON from stdin")
    parser.add_argument("--top", type=int, default=5, help="Number of top results to show")
    parser.add_argument("--json", action="store_true", help="Output as JSON")
    args = parser.parse_args()

    if args.stdin:
        data = json.load(sys.stdin)
    elif args.results:
        with open(args.results) as f:
            data = json.load(f)
    else:
        parser.error("Provide --results <file> or --stdin")
        return

    results = data.get("results", data if isinstance(data, list) else [])
    if not results:
        print("No results to score.")
        return

    max_dl = max(s.get("stats", {}).get("downloads", 0) for s in results)
    scored = [score_skill(s, max_dl) for s in results]
    scored.sort(key=lambda x: x["composite_score"], reverse=True)
    top = scored[: args.top]

    if args.json:
        print(json.dumps(top, indent=2))
    else:
        print(f"Top {len(top)} skills:\n")
        for i, s in enumerate(top, 1):
            verified_badge = " ✓" if s["verified"] else ""
            print(f"  {i}. {s['name']} v{s['version']}  (score: {s['composite_score']})")
            print(f"     {s['description']}")
            print(f"     by {s['publisher']}{verified_badge} | ↓{s['downloads']} | ★{s['rating']}")
            print()


if __name__ == "__main__":
    main()
