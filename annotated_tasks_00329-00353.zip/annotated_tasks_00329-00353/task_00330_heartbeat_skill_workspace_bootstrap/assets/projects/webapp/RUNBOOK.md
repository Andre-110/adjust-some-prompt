# Deployment Runbook — DevStack Webapp

## Pre-deploy Checklist

1. Run `npm test` — all tests must pass
2. Run `npm audit` — no critical vulnerabilities
3. Check SSL cert validity on target host
4. Verify DB migrations are up to date
5. Tag release in git

## Deploy Steps

```bash
ssh deploy@devstack.internal
cd /opt/webapp
git pull origin main
npm ci --production
pm2 restart webapp
```

## Rollback

```bash
ssh deploy@devstack.internal
cd /opt/webapp
git checkout <previous-tag>
npm ci --production
pm2 restart webapp
```

## Post-deploy

- Verify health endpoint: `curl -k https://devstack.internal/health`
- Check logs: `pm2 logs webapp --lines 50`
- Monitor error rate in Grafana for 15 minutes
