# DevStack Infrastructure Notes

## Hosts

| Hostname                  | IP             | Role              | OS           |
|---------------------------|----------------|-------------------|--------------|
| devstack.internal         | 10.0.1.10      | Primary app server| Ubuntu 22.04 |
| db.devstack.internal      | 10.0.1.20      | PostgreSQL 15     | Ubuntu 22.04 |
| cache.devstack.internal   | 10.0.1.30      | Redis 7.2         | Alpine 3.18  |
| api.devstack.internal     | 10.0.1.40      | API Gateway       | Ubuntu 22.04 |

## SSL Certificates

- Wildcard cert `*.devstack.internal` issued by internal CA
- Issued: 2025-03-22
- Expires: **2026-03-22**
- Stored in: `/etc/ssl/devstack/` on each host and backed up in `certs/`

## Maintenance Windows

- Tuesday 02:00–04:00 UTC — DB maintenance
- Sunday 03:00–05:00 UTC — Full system backups

## Escalation

- On-call: ops-team@devstack.example.com
- PagerDuty: #devstack-alerts channel
