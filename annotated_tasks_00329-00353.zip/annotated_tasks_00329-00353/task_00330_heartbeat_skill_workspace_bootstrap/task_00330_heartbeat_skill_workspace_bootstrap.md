---
id: task_00330_heartbeat_skill_workspace_bootstrap
name: Heartbeat Monitor Skill Creation and Workspace Bootstrap
category: Workflow and Agent Orchestration
subcategory: Script and Terminal Automation
difficulty: medium
grading_type: hybrid
grading_weights: {automated: 0.4, llm_judge: 0.6}
timeout_seconds: 600
input_modality: text-only
external_dependency: none
workspace_files:
  - source: BOOTSTRAP.md
    dest: BOOTSTRAP.md
    content: |
      # Bootstrap Instructions

      Welcome, new agent. This is your first run.

      1. Create a reusable skill at `skills/heartbeat-monitor/SKILL.md` for heartbeat monitoring — a capability that reads HEARTBEAT.md, processes any tasks listed, and replies HEARTBEAT_OK if nothing needs attention.
      2. Set up your workspace identity files: SOUL.md, IDENTITY.md, AGENTS.md, TOOLS.md, USER.md.
      3. Create HEARTBEAT.md with a comment-only template (no active tasks yet).
      4. Create .openclaw/workspace-state.json to record onboarding completion.
      5. After completing all steps, delete this BOOTSTRAP.md file (or leave it if you prefer to keep a record).

      Use the skill you created to perform the initial heartbeat check. Since HEARTBEAT.md will have no active tasks, the result should be HEARTBEAT_OK.
skill_creation: true
---

## Prompt

Hey, I need you to set up a fresh workspace for me.

Please start by reading `BOOTSTRAP.md` in the workspace root. Then:

1. Create a reusable OpenClaw skill at `skills/heartbeat-monitor/SKILL.md`. It should be a heartbeat monitor skill that knows how to read `HEARTBEAT.md`, process any scheduled tasks or reminders listed there, and reply `HEARTBEAT_OK` if there's nothing to do.
2. Bootstrap the workspace by creating `SOUL.md`, `IDENTITY.md`, `AGENTS.md`, `TOOLS.md`, `USER.md`, and a comment-only `HEARTBEAT.md` template.
3. Create `.openclaw/workspace-state.json` to record that onboarding is complete.
4. Use the new heartbeat skill logic to do the initial check and confirm `HEARTBEAT_OK`.

There may be other files already present in the workspace as background context, but for this task you only need to follow the bootstrap instructions and create the requested files.

## Expected Behavior

The agent should:

1. Read `BOOTSTRAP.md` in the workspace root to understand the setup instructions.
2. Create a reusable skill file at `skills/heartbeat-monitor/SKILL.md` with YAML frontmatter that includes at least `name` and `description`, plus markdown instruction sections that explain:
   - when to use the skill,
   - how to read `HEARTBEAT.md`,
   - how to identify active vs. non-active/comment-only items,
   - that the correct response is `HEARTBEAT_OK` when no action is required.
3. Create the following workspace files with meaningful content:
   - `SOUL.md`
   - `IDENTITY.md`
   - `AGENTS.md`
   - `TOOLS.md`
   - `USER.md`
   - `HEARTBEAT.md`
4. Ensure `HEARTBEAT.md` is a comment-only template or otherwise contains no active tasks. Existing background files elsewhere in the workspace do not need to be converted into active heartbeat tasks for this bootstrap step.
5. Create `.openclaw/workspace-state.json` as valid JSON with at least:
   - a `version` field, and
   - an onboarding-related timestamp or completion field.
6. Perform the initial heartbeat check using the newly defined skill logic and respond with `HEARTBEAT_OK` in the conversation.
7. `BOOTSTRAP.md` may be kept or deleted; either is acceptable.

## Grading Criteria

- [ ] `skills/heartbeat-monitor/SKILL.md` exists and contains YAML frontmatter plus meaningful heartbeat-monitoring instructions
- [ ] `HEARTBEAT.md` exists and contains no active tasks
- [ ] `.openclaw/workspace-state.json` exists and is valid JSON with onboarding metadata
- [ ] Workspace bootstrap files (`AGENTS.md`, `SOUL.md`, `IDENTITY.md`, `TOOLS.md`, `USER.md`) are created with meaningful content
- [ ] The agent explicitly replies `HEARTBEAT_OK` in the conversation

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    import json
    import re
    from pathlib import Path

    ws = Path(workspace_path)
    scores = {
        "skill_file_structured": 0.0,
        "heartbeat_template_no_active_tasks": 0.0,
        "workspace_state_json_valid": 0.0,
        "bootstrap_files_created": 0.0,
        "heartbeat_ok_in_transcript": 0.0,
    }

    skill_path = ws / "skills" / "heartbeat-monitor" / "SKILL.md"
    hb_path = ws / "HEARTBEAT.md"

    # Blank submission guard
    if not skill_path.exists() and not hb_path.exists():
        return scores

    # 1. Skill file structure
    if skill_path.exists():
        content = skill_path.read_text(encoding="utf-8", errors="replace")
        has_frontmatter = content.strip().startswith("---") and content.count("---") >= 2
        frontmatter_region = content[:800]
        has_name = bool(re.search(r"(?im)^\s*name\s*:", frontmatter_region))
        has_description = bool(re.search(r"(?im)^\s*description\s*:", frontmatter_region))
        body = content.split("---", 2)[-1] if content.count("---") >= 2 else content
        has_sections = bool(re.search(r"^#{1,3}\s+\S", body, re.MULTILINE))
        mentions_heartbeat = bool(re.search(r"(?i)\bheartbeat\b", content))
        mentions_heartbeat_file = "HEARTBEAT.md".lower() in content.lower()
        mentions_ok = "heartbeat_ok" in content.lower()

        strong = all([
            has_frontmatter, has_name, has_description,
            has_sections, mentions_heartbeat, mentions_heartbeat_file, mentions_ok
        ])
        medium = has_frontmatter and has_name and has_description and (has_sections or mentions_heartbeat)
        weak = has_frontmatter or (has_name and has_description)

        if strong:
            scores["skill_file_structured"] = 1.0
        elif medium:
            scores["skill_file_structured"] = 0.7
        elif weak:
            scores["skill_file_structured"] = 0.3
        else:
            scores["skill_file_structured"] = 0.1

    # 2. HEARTBEAT.md contains no active tasks
    if hb_path.exists():
        hb_content = hb_path.read_text(encoding="utf-8", errors="replace")
        non_comment_lines = [
            line.strip() for line in hb_content.splitlines()
            if line.strip() and not line.strip().startswith("#")
        ]
        active_task_markers = any(
            re.search(r"^(-|\*|\[\s|\[[xX]\])\s+\S", line)
            for line in non_comment_lines
        )

        if len(non_comment_lines) == 0:
            scores["heartbeat_template_no_active_tasks"] = 1.0
        elif not active_task_markers and len(non_comment_lines) <= 2:
            scores["heartbeat_template_no_active_tasks"] = 0.7
        elif not active_task_markers:
            scores["heartbeat_template_no_active_tasks"] = 0.4
        else:
            scores["heartbeat_template_no_active_tasks"] = 0.0

    # 3. workspace-state.json
    state_path = ws / ".openclaw" / "workspace-state.json"
    if state_path.exists():
        try:
            data = json.loads(state_path.read_text(encoding="utf-8", errors="replace"))
            has_version = "version" in data
            has_timestamp = any(
                k for k in data.keys()
                if any(token in k.lower() for token in ["completed", "onboarding", "time", "date", "timestamp"])
            )
            if has_version and has_timestamp:
                scores["workspace_state_json_valid"] = 1.0
            elif has_version or has_timestamp:
                scores["workspace_state_json_valid"] = 0.5
            else:
                scores["workspace_state_json_valid"] = 0.2
        except Exception:
            scores["workspace_state_json_valid"] = 0.1

    # 4. bootstrap files
    bootstrap_files = ["AGENTS.md", "SOUL.md", "IDENTITY.md", "TOOLS.md", "USER.md"]
    found = 0
    substantive = 0
    for fname in bootstrap_files:
        fpath = ws / fname
        if fpath.exists():
            found += 1
            content = fpath.read_text(encoding="utf-8", errors="replace").strip()
            if len(content) > 20:
                substantive += 1

    if found == 5 and substantive == 5:
        scores["bootstrap_files_created"] = 1.0
    elif substantive >= 4:
        scores["bootstrap_files_created"] = 0.8
    elif substantive >= 3:
        scores["bootstrap_files_created"] = 0.6
    elif found >= 2:
        scores["bootstrap_files_created"] = 0.3

    # 5. HEARTBEAT_OK in transcript
    for event in transcript:
        if event.get("type") != "message":
            continue
        msg = event.get("message", {})
        if msg.get("role") != "assistant":
            continue
        text = msg.get("content", "")
        if isinstance(text, list):
            text = " ".join(
                item.get("text", "") for item in text if isinstance(item, dict)
            )
        if re.search(r"(?i)\bheartbeat_ok\b", str(text)):
            scores["heartbeat_ok_in_transcript"] = 1.0
            break

    return scores
```

## LLM Judge Rubric

### Skill Quality and Reusability (Weight: 30%)
Evaluate whether the agent created a well-structured, reusable skill at `skills/heartbeat-monitor/SKILL.md` that clearly describes a heartbeat monitoring capability.

- **1.0**: `skills/heartbeat-monitor/SKILL.md` has proper YAML frontmatter with name and description, clear markdown sections explaining when/how to use the skill, references `HEARTBEAT.md` processing logic, and is genuinely reusable as a standalone skill definition.
- **0.75**: The skill file exists with frontmatter and reasonable content but is somewhat thin on instructions or lacks clear reusability framing.
- **0.5**: The skill file exists but is missing frontmatter or has only minimal content that barely qualifies as a skill definition.
- **0.25**: The skill file exists but is essentially a stub or placeholder with no meaningful skill logic described.
- **0.0**: The skill file is missing entirely, or the file is empty/irrelevant to heartbeat monitoring.

### Workspace Bootstrap Completeness (Weight: 25%)
Evaluate whether all required workspace files were created with meaningful content.

- **1.0**: All expected files (`SOUL.md`, `IDENTITY.md`, `AGENTS.md`, `TOOLS.md`, `USER.md`, `HEARTBEAT.md`, `.openclaw/workspace-state.json`) are present with substantive, appropriate content.
- **0.75**: Most files are present with reasonable content.
- **0.5**: About half the files are present, or files exist but with very minimal content.
- **0.25**: Only 1–2 files were created, or most files are empty stubs.
- **0.0**: No meaningful workspace bootstrap files were created.

### Evidence and Workspace Grounding (Weight: 25%)
Evaluate whether the agent read `BOOTSTRAP.md`, followed its instructions, and grounded its actions in the actual workspace context rather than hallucinating or ignoring required inputs.

- **1.0**: Agent clearly followed `BOOTSTRAP.md`, created files consistent with the instructions, and did not get distracted by unrelated background files.
- **0.75**: Agent mostly followed `BOOTSTRAP.md` but missed a minor instruction or deviated slightly.
- **0.5**: Agent created some files but showed limited evidence of following `BOOTSTRAP.md` specifically.
- **0.25**: Agent produced some output but largely ignored `BOOTSTRAP.md` or hallucinated instructions not present in the workspace.
- **0.0**: Agent ignored required input files entirely, produced no deliverables, or hallucinated content disconnected from the workspace setup task.

### Heartbeat Check Execution (Weight: 20%)
Evaluate whether the agent used the heartbeat skill concept to check `HEARTBEAT.md` and correctly responded `HEARTBEAT_OK`.

- **1.0**: Agent explicitly performed a heartbeat check referencing the skill or `HEARTBEAT.md`, confirmed no active tasks, and replied `HEARTBEAT_OK`.
- **0.75**: Agent replied `HEARTBEAT_OK` and referenced `HEARTBEAT.md` but didn't explicitly tie it to the skill.
- **0.5**: Agent replied `HEARTBEAT_OK` but without clear evidence of actually checking `HEARTBEAT.md`.
- **0.25**: Agent mentioned heartbeat concepts but didn't clearly confirm `HEARTBEAT_OK` or check the file.
- **0.0**: No heartbeat check was performed and no `HEARTBEAT_OK` response was given.