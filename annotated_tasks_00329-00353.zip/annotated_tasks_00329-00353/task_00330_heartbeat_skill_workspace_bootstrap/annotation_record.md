| 序号 | 修改项 | 修改原因 |
|------|--------|----------|
| 1 | 将 frontmatter 中 `workspace_files` 的旧字段 `path:` 改为规范写法 `dest:` | 符合数据规范，避免旧字段不兼容 |
| 2 | 将技能文件路径从根目录 `SKILL.md` 改为 `skills/heartbeat-monitor/SKILL.md` | 符合 OpenClaw skill 路径规范 |
| 3 | 修改 `BOOTSTRAP.md` 内联内容中的技能路径描述 | 保证 BOOTSTRAP 指令与规范一致 |
| 4 | 修改 Prompt 中关于技能文件位置的表述 | 消除路径歧义，和评分逻辑保持一致 |
| 5 | 在 Prompt 中补充“其他文件仅为背景信息”的说明 | 避免 assets 噪声误导模型把历史信息当作必须处理的 active tasks |
| 6 | 修改 Expected Behavior 中技能文件路径与要求 | 与规范及 Prompt 对齐 |
| 7 | 在 Expected Behavior 中补充：已有背景文件无需转成 active heartbeat tasks | 解决 assets 与“comment-only HEARTBEAT template”之间的语义冲突 |
| 8 | 重写 Grading Criteria 为 5 条 | 与 automated checks 的 score keys 一一对应，减少重叠 |
| 9 | 修改 `grade()` 中技能文件读取路径 | 修正路径错误，确保能正确评分 |
| 10 | 为 `grade()` 添加 blank submission guard | 满足“主输出文件不存在时全 0”要求 |
| 11 | 放宽 transcript 中 `HEARTBEAT_OK` 的匹配为大小写不敏感 | 提高格式容忍度 |
| 12 | 调整 automated score key 命名 | 与 Grading Criteria 对齐 |
| 13 | 将 `difficulty` 从 `hard` 调整为 `medium` | 题目主要考查文件创建与简单规范遵循，难度不达 hard |