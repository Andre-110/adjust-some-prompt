#!/usr/bin/env bash
# poly-arb-monitor.sh — Enhanced POL/USDC Arbitrage Monitor
# Checks wallet balances, monitors recent transaction logs, and alerts on anomalies.
# Called by cron job: a2ce4b5b-63bf-4235-a84d-5a66cf18532f
#
# Usage: ./poly-arb-monitor.sh [--config <path>] [--dry-run]
#
# Exit codes:
#   0  OK
#   1  Config missing / invalid
#   2  RPC unreachable
#   3  Balance below threshold
#   4  Suspicious tx detected

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
WORKSPACE="$(dirname "$SCRIPT_DIR")"
CONFIG="${1:-$WORKSPACE/config/monitor-config.yaml}"
LOG_DIR="$WORKSPACE/logs"
TIMESTAMP="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
DRY_RUN=false

# ── Parse flags ──────────────────────────────────────────────
while [[ $# -gt 0 ]]; do
  case "$1" in
    --config) CONFIG="$2"; shift 2 ;;
    --dry-run) DRY_RUN=true; shift ;;
    *) shift ;;
  esac
done

# ── Helpers ──────────────────────────────────────────────────
log() { echo "[$TIMESTAMP] $*" | tee -a "$LOG_DIR/monitor.log"; }
err() { log "ERROR: $*" >&2; }

require_cmd() {
  for cmd in "$@"; do
    command -v "$cmd" >/dev/null 2>&1 || { err "Missing dependency: $cmd"; exit 1; }
  done
}

require_cmd curl jq

# ── Load config ──────────────────────────────────────────────
if [[ ! -f "$CONFIG" ]]; then
  err "Config file not found: $CONFIG"
  exit 1
fi

# Parse YAML (lightweight — uses grep/sed, no yq dependency)
get_cfg() {
  grep -E "^\s*${1}:" "$CONFIG" | head -1 | sed "s/.*:\s*//" | tr -d '"' | tr -d "'"
}

RPC_URL="$(get_cfg rpc_url)"
WALLET="$(get_cfg wallet_address)"
POL_CONTRACT="$(get_cfg pol_token_address)"
USDC_CONTRACT="$(get_cfg usdc_token_address)"
MIN_POL="$(get_cfg min_pol_balance)"
MIN_USDC="$(get_cfg min_usdc_balance)"
ALERT_WEBHOOK="$(get_cfg alert_webhook)"
TX_LOG="$LOG_DIR/transactions.log"

log "Starting enhanced monitor run"
log "Wallet: $WALLET"
log "RPC: $RPC_URL"

# ── Balance check (ERC-20 balanceOf via eth_call) ────────────
check_balance() {
  local token_addr="$1"
  local token_name="$2"
  local min_balance="$3"

  # balanceOf(address) selector = 0x70a08231
  local padded_wallet
  padded_wallet="$(echo "$WALLET" | sed 's/^0x//' | awk '{printf "%064s\n", $0}' | tr ' ' '0')"
  local call_data="0x70a08231${padded_wallet}"

  local payload
  payload=$(jq -n \
    --arg to "$token_addr" \
    --arg data "$call_data" \
    '{jsonrpc:"2.0",id:1,method:"eth_call",params:[{to:$to,data:$data},"latest"]}')

  local result
  result=$(curl -sf -X POST "$RPC_URL" \
    -H "Content-Type: application/json" \
    -d "$payload" 2>/dev/null) || {
    err "RPC call failed for $token_name balance"
    return 2
  }

  local hex_balance
  hex_balance=$(echo "$result" | jq -r '.result // "0x0"')
  local balance
  balance=$(python3 -c "print(int('${hex_balance}', 16))" 2>/dev/null || echo 0)

  # Convert from wei (18 decimals for POL, 6 for USDC)
  local decimals=18
  [[ "$token_name" == "USDC" ]] && decimals=6
  local human_balance
  human_balance=$(python3 -c "print(round(${balance} / 10**${decimals}, 4))")

  log "$token_name balance: $human_balance"

  # Threshold check
  local below
  below=$(python3 -c "print(1 if ${human_balance} < ${min_balance} else 0)")
  if [[ "$below" == "1" ]]; then
    err "$token_name balance ($human_balance) below minimum ($min_balance)"
    send_alert "LOW_BALANCE" "$token_name balance $human_balance < $min_balance"
    return 3
  fi
  return 0
}

# ── Transaction log analysis ─────────────────────────────────
analyze_tx_log() {
  if [[ ! -f "$TX_LOG" ]]; then
    log "No transaction log found at $TX_LOG — skipping analysis"
    return 0
  fi

  local total_txns failed_txns last_hour_txns suspicious_count
  total_txns=$(wc -l < "$TX_LOG" | tr -d ' ')
  failed_txns=$(grep -c '"status":"failed"' "$TX_LOG" 2>/dev/null || echo 0)
  last_hour_txns=$(awk -v cutoff="$(date -u -d '1 hour ago' +%Y-%m-%dT%H:%M:%S 2>/dev/null || date -u -v-1H +%Y-%m-%dT%H:%M:%S 2>/dev/null || echo '2026-02-09T17:54:00')" \
    -F'"timestamp":"' '{split($2,a,"\""); if(a[1]>=cutoff) count++} END{print count+0}' "$TX_LOG")
  suspicious_count=$(grep -c '"suspicious":true' "$TX_LOG" 2>/dev/null || echo 0)

  log "TX analysis — total: $total_txns | failed: $failed_txns | last_hour: $last_hour_txns | suspicious: $suspicious_count"

  # Alert if failure rate > 20%
  if [[ "$total_txns" -gt 0 ]]; then
    local fail_pct
    fail_pct=$(python3 -c "print(round(${failed_txns}/${total_txns}*100, 1))")
    if (( $(echo "$fail_pct > 20" | bc -l 2>/dev/null || python3 -c "print(1 if ${fail_pct}>20 else 0)") )); then
      err "High failure rate: ${fail_pct}%"
      send_alert "HIGH_FAILURE_RATE" "Tx failure rate ${fail_pct}% (${failed_txns}/${total_txns})"
      return 4
    fi
  fi

  # Alert on suspicious transactions
  if [[ "$suspicious_count" -gt 0 ]]; then
    err "Suspicious transactions detected: $suspicious_count"
    send_alert "SUSPICIOUS_TX" "$suspicious_count suspicious transactions found"
    return 4
  fi

  return 0
}

# ── Alert dispatch ───────────────────────────────────────────
send_alert() {
  local alert_type="$1"
  local message="$2"

  log "ALERT [$alert_type]: $message"

  if [[ -n "$ALERT_WEBHOOK" && "$ALERT_WEBHOOK" != "null" && "$DRY_RUN" == "false" ]]; then
    curl -sf -X POST "$ALERT_WEBHOOK" \
      -H "Content-Type: application/json" \
      -d "$(jq -n --arg t "$alert_type" --arg m "$message" --arg ts "$TIMESTAMP" \
        '{type:$t,message:$m,timestamp:$ts,wallet:"'"$WALLET"'"}')" \
      >/dev/null 2>&1 || log "WARNING: Failed to send webhook alert"
  fi

  # Append to alert log
  echo "{\"timestamp\":\"$TIMESTAMP\",\"type\":\"$alert_type\",\"message\":\"$message\"}" \
    >> "$LOG_DIR/alerts.jsonl"
}

# ── Gas price check ──────────────────────────────────────────
check_gas() {
  local payload='{"jsonrpc":"2.0","id":1,"method":"eth_gasPrice","params":[]}'
  local result
  result=$(curl -sf -X POST "$RPC_URL" \
    -H "Content-Type: application/json" \
    -d "$payload" 2>/dev/null) || {
    err "Gas price check failed"
    return 2
  }
  local gas_hex
  gas_hex=$(echo "$result" | jq -r '.result // "0x0"')
  local gas_gwei
  gas_gwei=$(python3 -c "print(round(int('${gas_hex}', 16) / 1e9, 2))")
  log "Current gas price: ${gas_gwei} Gwei"
}

# ── Main ─────────────────────────────────────────────────────
main() {
  local exit_code=0

  check_gas || true

  check_balance "$POL_CONTRACT" "POL" "$MIN_POL" || exit_code=$?
  check_balance "$USDC_CONTRACT" "USDC" "$MIN_USDC" || exit_code=$?
  analyze_tx_log || exit_code=$?

  # Write status file for dashboard
  jq -n \
    --arg ts "$TIMESTAMP" \
    --arg wallet "$WALLET" \
    --argjson exit "$exit_code" \
    '{last_run:$ts, wallet:$wallet, exit_code:$exit, status:(if $exit==0 then "healthy" else "alert" end)}' \
    > "$LOG_DIR/last-run-status.json"

  log "Monitor run complete — exit code: $exit_code"
  return $exit_code
}

main
