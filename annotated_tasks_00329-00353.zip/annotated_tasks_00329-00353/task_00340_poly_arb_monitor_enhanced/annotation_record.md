| 序号 | 修改项 | 修改原因 |
|------|--------|----------|
| 1 | 将 frontmatter 中 `workspace_files` 从旧版 `path:` 内联文件改为 assets 版 `dest:` 列表 | 原文不符合本批数据规范，且与实际 Assets 不一致 |
| 2 | 删除文档中虚构的 `config/monitor-config.json`，统一改为 `config/monitor-config.yaml` | 实际 workspace 使用 YAML 配置，原文路径错误 |
| 3 | 重写 Prompt，明确需检查脚本、配置、日志并追加 `logs/monitor.log` | 提升指令清晰度，并与实际文件结构一致 |
| 4 | 重写 Expected Behavior，使其基于真实 Assets 内容 | 原 Expected Behavior 基于旧版内联数据，Ground Truth 错误 |
| 5 | 在 Expected Behavior 中加入最新余额的明确答案：POL `321.7028`、USDC `1686.1435` | 提供可验证的 Ground Truth |
| 6 | 在 Expected Behavior 中加入失败交易说明（`EXECUTION_REVERTED`、`OUT_OF_GAS`） | 使交易分析要求具体且可验证 |
| 7 | 在 Expected Behavior 中加入“低余额告警与阈值不一致”的异常识别要求 | Assets 中存在合理陷阱，但原文未说明 |
| 8 | 重写 Grading Criteria | 使条目更独立、覆盖关键能力、具备区分度 |
| 9 | 重写 grade() 函数 | 原评分逻辑依赖旧版 8 行日志、错误钱包地址、错误配置文件名，无法正确评分 |
| 10 | 调整 LLM Judge Rubric 使其更关注 workspace grounding 和 anomaly detection | 更符合当前 assets 版题目真实考点 |
| 11 | 修改 `config/monitor-config.yaml` 中的 RPC URL 为明显占位值 | 避免真实样式敏感信息 |
| 12 | 修改 `config/monitor-config.yaml` 中的 Slack webhook 为明显占位值 | 避免真实样式敏感信息 |