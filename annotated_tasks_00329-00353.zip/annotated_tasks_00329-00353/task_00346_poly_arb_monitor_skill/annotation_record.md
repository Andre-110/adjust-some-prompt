| 序号 | 修改项 | 修改原因 |
|------|--------|----------|
| 1 | 将 `workspace_files` 中的旧字段 `path:` 改为规范的 `source` + `dest` | 当前数据规范禁止只写旧字段 `path:`，需要提供清晰的包内路径到 workspace 路径映射 |
| 2 | 将 Prompt、Expected Behavior、Grading Criteria 中的配置文件路径统一为 `config/arb-config.json` | 原题面引用 `config/monitor-config.json`，但实际 Assets 中存在的是 `config/arb-config.json`，存在跨文件不一致 |
| 3 | 为 Assets 新增 `logs/transactions.log` | 原题面要求解析该日志文件，但资产目录中缺失该文件，导致任务无法按题意完成 |
| 4 | 将 skill 文件路径从 workspace 根下 `SKILL.md` 改为 `skills/poly-arb-monitor/SKILL.md` | 按 OpenClaw 规范，技能文件应位于 `skills/<skill名>/SKILL.md` |
| 5 | 重写 Expected Behavior，使其引用实际配置值和日志事实 | 原 Expected Behavior 过于泛化，Ground Truth 不够明确，也未与实际 Assets 对齐 |
| 6 | 重写 Grading Criteria，使其更聚焦关键能力点 | 原 criteria 较分散，且与自动评分键没有很好对齐 |
| 7 | 重写 `grade()` 中的 skill 路径检查 | 原评分函数检查的是根目录 `SKILL.md`，与规范不符 |
| 8 | 重写 `grade()` 中的文件路径引用与报告检查逻辑 | 原逻辑依赖错误文件路径，且对关键字段与事实校验不够稳健 |
| 9 | 增加 blank submission guard，确保主输出缺失时返回全 0 | 满足“空白零分”要求 |
| 10 | 强化 transaction summary 的 grounding 检查 | 原自动评分仅做较弱关键词匹配，无法有效区分是否真的读取了日志 |
| 11 | 保留 `scripts/poly-arb-monitor-enhanced.sh` 但不作为主任务必需输入 | 该脚本与题目日志格式不完全一致，可作为背景参考，但不应成为题目矛盾来源 |
| 12 | 建议将配置中的 `discord_webhook` 改为更明显的占位值 | 避免出现类似真实敏感信息的字段形式，提高 Assets 安全性 |