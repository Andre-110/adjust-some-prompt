#!/usr/bin/env bash
###############################################################################
# poly-arb-monitor-enhanced.sh
# Enhanced monitoring script for POL/USDC arbitrage bot
# Checks on-chain balances via RPC + scans transaction logs for anomalies
#
# Usage:  ./poly-arb-monitor-enhanced.sh [--verbose] [--alert-threshold <USD>]
# Cron:   Called by cron job a2ce4b5b-63bf-4235-a84d-5a66cf18532f
###############################################################################

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CONFIG_FILE="${SCRIPT_DIR}/../config/arb-config.json"
TX_LOG_DIR="${SCRIPT_DIR}/../logs"
REPORT_FILE="${SCRIPT_DIR}/../data/monitor-report-$(date +%Y%m%d-%H%M%S).json"

# Defaults
VERBOSE=false
ALERT_THRESHOLD=50  # USD

while [[ $# -gt 0 ]]; do
  case "$1" in
    --verbose) VERBOSE=true; shift ;;
    --alert-threshold) ALERT_THRESHOLD="$2"; shift 2 ;;
    *) echo "Unknown option: $1"; exit 1 ;;
  esac
done

# ------------------------------------------------------------------
# Load config
# ------------------------------------------------------------------
if [[ ! -f "$CONFIG_FILE" ]]; then
  echo "[ERROR] Config not found: $CONFIG_FILE"
  exit 1
fi

WALLET=$(jq -r '.wallet_address' "$CONFIG_FILE")
RPC_URL=$(jq -r '.rpc_endpoints[0]' "$CONFIG_FILE")
USDC_CONTRACT=$(jq -r '.tokens.USDC.contract' "$CONFIG_FILE")
POL_DECIMALS=$(jq -r '.tokens.POL.decimals' "$CONFIG_FILE")
USDC_DECIMALS=$(jq -r '.tokens.USDC.decimals' "$CONFIG_FILE")

$VERBOSE && echo "[INFO] Wallet:  $WALLET"
$VERBOSE && echo "[INFO] RPC:     $RPC_URL"
$VERBOSE && echo "[INFO] USDC:    $USDC_CONTRACT"

# ------------------------------------------------------------------
# 1. Check native POL balance  (eth_getBalance)
# ------------------------------------------------------------------
echo "[$(date -u +%FT%TZ)] Checking POL balance..."

POL_HEX=$(curl -sf -X POST "$RPC_URL" \
  -H "Content-Type: application/json" \
  -d "{\"jsonrpc\":\"2.0\",\"method\":\"eth_getBalance\",\"params\":[\"$WALLET\",\"latest\"],\"id\":1}" \
  | jq -r '.result')

if [[ -z "$POL_HEX" || "$POL_HEX" == "null" ]]; then
  echo "[ERROR] Failed to fetch POL balance"
  POL_BALANCE="error"
else
  POL_WEI=$(printf "%d" "$POL_HEX" 2>/dev/null || echo 0)
  POL_BALANCE=$(echo "scale=6; $POL_WEI / 10^$POL_DECIMALS" | bc)
  echo "[OK]   POL balance: $POL_BALANCE"
fi

# ------------------------------------------------------------------
# 2. Check USDC balance  (ERC-20 balanceOf)
# ------------------------------------------------------------------
echo "[$(date -u +%FT%TZ)] Checking USDC balance..."

# balanceOf(address) selector = 0x70a08231
PADDED_WALLET="000000000000000000000000${WALLET#0x}"
CALL_DATA="0x70a08231${PADDED_WALLET}"

USDC_HEX=$(curl -sf -X POST "$RPC_URL" \
  -H "Content-Type: application/json" \
  -d "{\"jsonrpc\":\"2.0\",\"method\":\"eth_call\",\"params\":[{\"to\":\"$USDC_CONTRACT\",\"data\":\"$CALL_DATA\"},\"latest\"],\"id\":2}" \
  | jq -r '.result')

if [[ -z "$USDC_HEX" || "$USDC_HEX" == "null" ]]; then
  echo "[ERROR] Failed to fetch USDC balance"
  USDC_BALANCE="error"
else
  USDC_RAW=$(printf "%d" "$USDC_HEX" 2>/dev/null || echo 0)
  USDC_BALANCE=$(echo "scale=2; $USDC_RAW / 10^$USDC_DECIMALS" | bc)
  echo "[OK]   USDC balance: $USDC_BALANCE"
fi

# ------------------------------------------------------------------
# 3. Monitor transaction logs
# ------------------------------------------------------------------
echo "[$(date -u +%FT%TZ)] Scanning transaction logs..."

FAILED_COUNT=0
TOTAL_TX=0
LAST_TX_TIME=""
LARGE_SLIPPAGE=0

for logfile in "$TX_LOG_DIR"/tx-log-*.jsonl; do
  [[ -f "$logfile" ]] || continue
  while IFS= read -r line; do
    TOTAL_TX=$((TOTAL_TX + 1))
    status=$(echo "$line" | jq -r '.status // "unknown"')
    slippage=$(echo "$line" | jq -r '.slippage_bps // 0')
    ts=$(echo "$line" | jq -r '.timestamp // empty')

    if [[ "$status" == "failed" || "$status" == "reverted" ]]; then
      FAILED_COUNT=$((FAILED_COUNT + 1))
    fi

    if (( $(echo "$slippage > 100" | bc -l) )); then
      LARGE_SLIPPAGE=$((LARGE_SLIPPAGE + 1))
    fi

    [[ -n "$ts" ]] && LAST_TX_TIME="$ts"
  done < "$logfile"
done

echo "[OK]   Total transactions: $TOTAL_TX"
echo "[OK]   Failed/reverted:    $FAILED_COUNT"
echo "[OK]   High slippage (>1%): $LARGE_SLIPPAGE"
echo "[OK]   Last tx timestamp:  ${LAST_TX_TIME:-N/A}"

# ------------------------------------------------------------------
# 4. Generate report
# ------------------------------------------------------------------
cat > "$REPORT_FILE" <<EOF
{
  "generated_at": "$(date -u +%FT%TZ)",
  "wallet": "$WALLET",
  "balances": {
    "POL": "$POL_BALANCE",
    "USDC": "$USDC_BALANCE"
  },
  "transactions": {
    "total": $TOTAL_TX,
    "failed": $FAILED_COUNT,
    "high_slippage": $LARGE_SLIPPAGE,
    "last_timestamp": "${LAST_TX_TIME:-null}"
  },
  "alert_threshold_usd": $ALERT_THRESHOLD,
  "alerts": []
}
EOF

# ------------------------------------------------------------------
# 5. Alert logic
# ------------------------------------------------------------------
ALERTS=()

if [[ "$USDC_BALANCE" != "error" ]] && (( $(echo "$USDC_BALANCE < $ALERT_THRESHOLD" | bc -l) )); then
  ALERTS+=("USDC balance ($USDC_BALANCE) below threshold ($ALERT_THRESHOLD)")
fi

if [[ "$POL_BALANCE" != "error" ]] && (( $(echo "$POL_BALANCE < 1.0" | bc -l) )); then
  ALERTS+=("POL balance ($POL_BALANCE) critically low — may not cover gas")
fi

FAIL_RATE=0
if (( TOTAL_TX > 0 )); then
  FAIL_RATE=$(echo "scale=2; $FAILED_COUNT * 100 / $TOTAL_TX" | bc)
fi
if (( $(echo "$FAIL_RATE > 15" | bc -l) )); then
  ALERTS+=("Failure rate ${FAIL_RATE}% exceeds 15% threshold")
fi

if (( LARGE_SLIPPAGE > 3 )); then
  ALERTS+=("$LARGE_SLIPPAGE transactions with >1% slippage detected")
fi

# Write alerts into report
ALERTS_JSON="[]"
for a in "${ALERTS[@]+"${ALERTS[@]}"}"; do
  ALERTS_JSON=$(echo "$ALERTS_JSON" | jq --arg m "$a" '. + [$m]')
done
TMP=$(mktemp)
jq --argjson alerts "$ALERTS_JSON" '.alerts = $alerts' "$REPORT_FILE" > "$TMP" && mv "$TMP" "$REPORT_FILE"

echo ""
if [[ ${#ALERTS[@]} -gt 0 ]]; then
  echo "⚠️  ALERTS (${#ALERTS[@]}):"
  for a in "${ALERTS[@]}"; do echo "  - $a"; done
else
  echo "✅ All checks passed — no alerts."
fi

echo ""
echo "Report saved: $REPORT_FILE"
exit 0
