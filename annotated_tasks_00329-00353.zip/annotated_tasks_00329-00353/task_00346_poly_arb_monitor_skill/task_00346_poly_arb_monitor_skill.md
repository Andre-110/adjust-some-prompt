---
id: task_00346_poly_arb_monitor_skill
name: POL/USDC Arbitrage Monitor Skill Creation
category: Finance and Quantitative Trading
subcategory: Trade Execution and Management
difficulty: medium
grading_type: hybrid
grading_weights: {automated: 0.4, llm_judge: 0.6}
timeout_seconds: 600
input_modality: text-only
external_dependency: none
skill_creation: true
workspace_files:
  - source: config/arb-config.json
    dest: config/arb-config.json
  - source: logs/transactions.log
    dest: logs/transactions.log
  - source: scripts/poly-arb-monitor-enhanced.sh
    dest: scripts/poly-arb-monitor-enhanced.sh
---

## Prompt

I need a reusable OpenClaw skill for monitoring a Polygon arbitrage wallet that trades POL and USDC.

Please create the skill file at `skills/poly-arb-monitor/SKILL.md`. The skill should describe how to:
- read the wallet monitoring configuration
- check or simulate token balances for POL and USDC
- parse recent transaction activity from logs
- generate a structured monitoring report
- flag low-balance or unhealthy-wallet conditions

Then use that skill to perform a monitoring run using:
- `config/arb-config.json`
- `logs/transactions.log`

Create a JSON report at `data/monitor-report.json` that includes:
- a current timestamp
- the wallet address from config
- token balances (you may simulate current balances as `0.0` because no real RPC calls are required)
- per-token low-balance status based on the configured minimum balances
- a parsed summary of recent transactions from the log
- a small network status section (simulated is fine)
- an overall health status

Also provide a short human-readable summary in your final response that explains the wallet status, recent activity, and any alerts.

## Expected Behavior

The agent should:

1. **Create the skill file** at `skills/poly-arb-monitor/SKILL.md` with:
   - YAML frontmatter including at least `name` and `description`
   - clear markdown sections explaining:
     - required inputs/files
     - how balances are checked or simulated
     - how transaction logs are parsed
     - how alerts are determined
     - how the monitoring report is generated

2. **Read `config/arb-config.json`** and use workspace-grounded values from it, including:
   - wallet address: `0x7a3F29d1bE4c8Ab90c2F1C70eD5431f92E8347bD`
   - POL minimum balance: `2.0`
   - USDC minimum balance: `50.0`

3. **Read and parse `logs/transactions.log`**. The log contains 6 recent entries:
   - 5 swap events
   - 1 transfer-out event

4. **Generate `data/monitor-report.json`** as valid JSON. The report should include:
   - a timestamp field
   - the wallet address from config
   - token balances for `POL` and `USDC`
   - low-balance flags/status fields showing both tokens are below threshold if balances are simulated as `0.0`
   - a transaction summary grounded in the provided log
   - a network status section
   - an overall health status

5. **Ground the transaction summary in the log contents**. A correct summary should reflect the provided log, including facts such as:
   - total entries: `6`
   - swap count: `5`
   - transfer-out count: `1`
   - the latest event is a `TRANSFER_OUT`
   - the latest timestamp is `2026-02-10T00:20:00Z`

6. **Provide a conversational summary** in the assistant response mentioning that balances are low / below threshold (if simulated as `0.0`) and summarizing recent wallet activity.

## Grading Criteria

- [ ] `skills/poly-arb-monitor/SKILL.md` exists and has YAML frontmatter with `name` and `description`
- [ ] The skill file contains meaningful monitoring instructions, not just a stub
- [ ] `data/monitor-report.json` exists and is valid JSON
- [ ] The report includes the wallet address from `config/arb-config.json`
- [ ] The report includes POL and USDC balance data
- [ ] The report includes low-balance status or alert flags derived from configured minimum balances
- [ ] The report includes a transaction summary grounded in `logs/transactions.log`
- [ ] The report includes a timestamp and a network/health section
- [ ] The assistant response includes a human-readable monitoring summary with alerts or wallet status

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    import json
    import re
    from pathlib import Path

    scores = {
        "skill_file_quality": 0.0,
        "report_json_valid": 0.0,
        "report_core_fields": 0.0,
        "threshold_alert_logic": 0.0,
        "transaction_summary_grounded": 0.0,
        "assistant_summary": 0.0,
    }

    ws = Path(workspace_path)

    skill_path = ws / "skills" / "poly-arb-monitor" / "SKILL.md"
    report_path = ws / "data" / "monitor-report.json"
    config_path = ws / "config" / "arb-config.json"
    log_path = ws / "logs" / "transactions.log"

    # Blank submission guard
    if not skill_path.exists() and not report_path.exists():
        return scores

    report_data = None
    config_data = None

    # Load config if present
    if config_path.exists():
        try:
            config_data = json.loads(config_path.read_text(errors="replace"))
        except Exception:
            config_data = None

    # 1. Skill file quality
    if skill_path.exists():
        content = skill_path.read_text(errors="replace")
        has_frontmatter = content.strip().startswith("---")
        has_name = bool(re.search(r"(?mi)^name\s*:\s*.+$", content))
        has_description = bool(re.search(r"(?mi)^description\s*:\s*.+$", content))
        headings = len(re.findall(r"(?m)^#{1,6}\s+\S+", content))
        domain_keywords = sum(
            1 for kw in ["polygon", "pol", "usdc", "balance", "transaction", "alert", "report", "monitor"]
            if kw in content.lower()
        )

        score = 0.0
        if has_frontmatter:
            score += 0.3
        if has_name:
            score += 0.2
        if has_description:
            score += 0.2
        if headings >= 2:
            score += 0.15
        if domain_keywords >= 4:
            score += 0.15
        scores["skill_file_quality"] = min(score, 1.0)

    # 2. Report valid JSON
    if report_path.exists():
        try:
            report_data = json.loads(report_path.read_text(errors="replace"))
            if isinstance(report_data, dict):
                scores["report_json_valid"] = 1.0
            else:
                scores["report_json_valid"] = 0.5
        except Exception:
            scores["report_json_valid"] = 0.0

    # If no report, remaining report-based checks stay zero
    if not isinstance(report_data, dict):
        # assistant summary may still earn credit
        pass
    else:
        report_str = json.dumps(report_data).lower()

        # 3. Core fields
        core = 0.0
        if any(k in report_data for k in ["timestamp", "generated_at", "generated", "time"]):
            core += 0.25

        wallet_expected = None
        if isinstance(config_data, dict):
            wallet_expected = config_data.get("wallet_address")

        if wallet_expected and wallet_expected.lower() in json.dumps(report_data).lower():
            core += 0.25
        elif "wallet" in report_str and "0x" in report_str:
            core += 0.15

        if "pol" in report_str and "usdc" in report_str and "balance" in report_str:
            core += 0.25

        if any(k in report_str for k in ["network", "block", "health", "status"]):
            core += 0.25

        scores["report_core_fields"] = min(core, 1.0)

        # 4. Threshold / alert logic
        threshold_score = 0.0
        pol_min = None
        usdc_min = None
        if isinstance(config_data, dict):
            pol_min = (((config_data.get("tokens") or {}).get("POL") or {}).get("min_balance"))
            usdc_min = (((config_data.get("tokens") or {}).get("USDC") or {}).get("min_balance"))

        if any(k in report_str for k in ["alert", "below", "threshold", "low_balance", "low-balance"]):
            threshold_score += 0.5

        # reward explicit grounding to configured minimum balances or both-below logic
        if str(pol_min) in report_str or str(usdc_min) in report_str:
            threshold_score += 0.25

        if "pol" in report_str and "usdc" in report_str and any(
            kw in report_str for kw in ["below", "low", "alert", "critical"]
        ):
            threshold_score += 0.25

        scores["threshold_alert_logic"] = min(threshold_score, 1.0)

        # 5. Transaction summary grounded
        tx_score = 0.0
        if any(k in report_str for k in ["transaction", "swap", "transfer"]):
            tx_score += 0.3

        # Check grounded facts from provided log
        grounded_hits = 0
        for marker in ["2026-02-10t00:20:00z", "transfer_out", "swap", "0xabc123", "0x901234"]:
            if marker in report_str:
                grounded_hits += 1

        if grounded_hits >= 2:
            tx_score += 0.4
        elif grounded_hits == 1:
            tx_score += 0.2

        # count-based summary
        if any(x in report_str for x in ['"6"', ": 6", '"total_entries": 6', '"total": 6']):
            tx_score += 0.3
        elif any(x in report_str for x in ["5", "1"]):
            tx_score += 0.1

        scores["transaction_summary_grounded"] = min(tx_score, 1.0)

    # 6. Assistant summary
    for event in transcript:
        if event.get("type") != "message":
            continue
        msg = event.get("message", {})
        if msg.get("role") != "assistant":
            continue

        text = ""
        content = msg.get("content", "")
        if isinstance(content, str):
            text = content.lower()
        elif isinstance(content, list):
            for part in content:
                if isinstance(part, dict) and part.get("type") == "text":
                    text += part.get("text", "").lower()

        if any(kw in text for kw in ["balance", "pol", "usdc", "alert", "wallet", "transaction", "monitor"]):
            score = 0.6
            if any(kw in text for kw in ["low", "below threshold", "critical", "health"]):
                score += 0.2
            if any(kw in text for kw in ["swap", "transfer", "recent activity", "latest"]):
                score += 0.2
            scores["assistant_summary"] = min(score, 1.0)
            break

    return scores
```

## LLM Judge Rubric

### Skill Definition Quality (Weight: 25%)
Evaluates whether the skill file is well-structured, reusable, and clearly describes the monitoring capability.
- 1.0: `skills/poly-arb-monitor/SKILL.md` has proper YAML frontmatter with `name` and `description`, multiple clear sections, and reusable instructions for config reading, balance checks/simulation, log parsing, alerting, and report generation.
- 0.75: Skill file is solid and mostly reusable but lacks detail in one area.
- 0.5: Skill file exists and is somewhat relevant, but instructions are sparse or generic.
- 0.25: Skill file exists but is poorly structured or missing key frontmatter/content.
- 0.0: No relevant skill file created.

### Monitoring Report Accuracy and Completeness (Weight: 30%)
Evaluates the JSON report for correct structure and required fields.
- 1.0: Report is valid JSON and includes timestamp, wallet address, balances, low-balance status/alerts, transaction summary, and network/health information, all logically consistent.
- 0.75: Report contains most required fields with only minor omissions.
- 0.5: Report exists and is valid JSON but misses several important elements.
- 0.25: Report exists but is seriously incomplete or poorly structured.
- 0.0: No valid report produced.

### Evidence and Workspace Grounding (Weight: 25%)
Evaluates whether the output is grounded in the provided workspace files.
- 1.0: Report clearly uses `config/arb-config.json` and `logs/transactions.log`, including the actual wallet address, minimum balance thresholds, and specific transaction-log facts.
- 0.75: Strong grounding with minor inconsistencies or partial omission of log/config details.
- 0.5: Some evidence of reading workspace files, but significant content is generic.
- 0.25: Minimal evidence of workspace grounding.
- 0.0: No evidence that workspace files were used.

### Communication and Alert Summary (Weight: 20%)
Evaluates the human-readable final response.
- 1.0: Clear summary of wallet balance status, threshold alerts, and recent transaction activity, with concise actionable interpretation.
- 0.75: Good summary with only minor missing detail.
- 0.5: Basic summary that mentions balances or alerts but lacks transaction context.
- 0.25: Minimal or vague summary.
- 0.0: No meaningful summary provided.