---
id: task_00333_gemini_model_config_skill
name: Gemini Model Configuration Skill Creation
category: System Administration
subcategory: Software and Environment Management
difficulty: medium
grading_type: hybrid
grading_weights: {automated: 0.4, llm_judge: 0.6}
timeout_seconds: 600
input_modality: text-only
external_dependency: none
workspace_files:
  - source: .openclaw/workspace-state.json
    dest: .openclaw/workspace-state.json
    content: |
      {
        "version": "1.0",
        "providers": {
          "openai": {
            "api_key": "OPENAI_API_KEY_PLACEHOLDER",
            "models": ["gpt-4o", "gpt-4o-mini"]
          }
        },
        "active_model": "gpt-4o"
      }
  - source: .openclaw/gateway.log
    dest: .openclaw/gateway.log
    source: assets/task_00333_gemini_model_config_skill/.openclaw/gateway.log
  - source: .openclaw/model-aliases.json
    dest: .openclaw/model-aliases.json
    source: assets/task_00333_gemini_model_config_skill/.openclaw/model-aliases.json
  - source: .openclaw/openclaw.json
    dest: .openclaw/openclaw.json
    source: assets/task_00333_gemini_model_config_skill/.openclaw/openclaw.json
  - source: .openclaw/providers-cache.json
    dest: .openclaw/providers-cache.json
    source: assets/task_00333_gemini_model_config_skill/.openclaw/providers-cache.json
  - source: .openclaw/usage-report.md
    dest: .openclaw/usage-report.md
    source: assets/task_00333_gemini_model_config_skill/.openclaw/usage-report.md
skill_creation: true
---

## Prompt

[Tue 2026-02-10 21:02 GMT+8] I have a Gemini API key and I'd like to configure a new model. First, create a reusable OpenClaw skill named `model-config-manager` for managing model provider configurations. Put the skill at `skills/model-config-manager/SKILL.md`.

Then use that skill to set up Gemini in the workspace. I already have an OpenAI provider configured in `.openclaw/workspace-state.json`. Please update that file to add Gemini 2.0 Flash as a new provider using the placeholder key `GEMINI_API_KEY_PLACEHOLDER`, while preserving the existing OpenAI configuration. You do not need to switch the active model unless you explicitly explain why. When you're done, tell me what changed, what models are now available in the workspace state, and what I should replace later with a real key.

## Expected Behavior

The agent should:

1. **Create a reusable skill file** at `skills/model-config-manager/SKILL.md`.
   - The file should be valid Markdown with YAML frontmatter.
   - The frontmatter should include at least `name` and `description`.
   - The skill should describe repeatable procedures for managing model provider configurations, including how to add, update, and review provider entries.
   - The skill should mention at least OpenAI and Gemini as supported/example providers.

2. **Read the existing workspace state** from `.openclaw/workspace-state.json` and recognize that:
   - `providers.openai` already exists
   - `active_model` is currently `gpt-4o`

3. **Update `.openclaw/workspace-state.json`** so that:
   - The file remains valid JSON
   - The existing `providers.openai` entry is preserved
   - A new `providers.gemini` entry is added
   - `providers.gemini.api_key` is exactly `GEMINI_API_KEY_PLACEHOLDER`
   - `providers.gemini.models` includes `gemini-2.0-flash`
   - `active_model` may remain `gpt-4o` unless the agent intentionally changes it and clearly justifies that choice

4. **Communicate the result clearly** to the user:
   - Explain that the reusable skill was created
   - Explain that Gemini was added alongside OpenAI
   - Mention the available models in `.openclaw/workspace-state.json`
   - Tell the user to replace `GEMINI_API_KEY_PLACEHOLDER` with a real Gemini API key later

5. **Avoid unnecessary destructive changes**:
   - Do not remove or corrupt the existing OpenAI configuration
   - Do not produce invalid JSON

## Grading Criteria

- [ ] `skills/model-config-manager/SKILL.md` exists and includes YAML frontmatter with `name` and `description`
- [ ] The skill file contains meaningful instructions for managing provider configurations
- [ ] `.openclaw/workspace-state.json` exists and is valid JSON
- [ ] `.openclaw/workspace-state.json` preserves the existing OpenAI provider configuration
- [ ] `.openclaw/workspace-state.json` adds a Gemini provider with `api_key: GEMINI_API_KEY_PLACEHOLDER`
- [ ] The Gemini provider’s models include `gemini-2.0-flash`
- [ ] The agent clearly explains what changed and the next step for replacing the placeholder key

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    import json
    import re
    from pathlib import Path

    scores = {
        "skill_md_exists_and_structured": 0.0,
        "skill_md_has_instructions": 0.0,
        "workspace_state_valid_json": 0.0,
        "openai_preserved": 0.0,
        "gemini_provider_key_configured": 0.0,
        "gemini_model_added": 0.0,
        "agent_communication": 0.0,
    }

    ws = Path(workspace_path)
    skill_path = ws / "skills" / "model-config-manager" / "SKILL.md"
    state_path = ws / ".openclaw" / "workspace-state.json"

    # If both primary deliverables are missing, return all-zero scores
    if not skill_path.exists() and not state_path.exists():
        return scores

    # 1. Check SKILL.md exists and has YAML frontmatter with name and description
    if skill_path.exists():
        try:
            content = skill_path.read_text(encoding="utf-8")
            fm_match = re.search(r"^---\s*\n(.*?)\n---", content, re.DOTALL)
            if fm_match:
                fm_text = fm_match.group(1)
                has_name = bool(re.search(r"^\s*name\s*:", fm_text, re.MULTILINE))
                has_desc = bool(re.search(r"^\s*description\s*:", fm_text, re.MULTILINE))
                if has_name and has_desc:
                    scores["skill_md_exists_and_structured"] = 1.0
                elif has_name or has_desc:
                    scores["skill_md_exists_and_structured"] = 0.5
                else:
                    scores["skill_md_exists_and_structured"] = 0.25
            else:
                scores["skill_md_exists_and_structured"] = 0.2
        except Exception:
            scores["skill_md_exists_and_structured"] = 0.1

    # 2. Check SKILL.md has meaningful instruction sections
    if skill_path.exists():
        try:
            content = skill_path.read_text(encoding="utf-8")
            headings = re.findall(r"^#{1,3}\s+.+", content, re.MULTILINE)
            body_without_fm = re.sub(r"^---\s*\n.*?\n---\s*\n?", "", content, count=1, flags=re.DOTALL)
            word_count = len(body_without_fm.split())
            mentions_gemini = "gemini" in body_without_fm.lower()
            mentions_openai = "openai" in body_without_fm.lower()
            if len(headings) >= 2 and word_count >= 30 and mentions_gemini and mentions_openai:
                scores["skill_md_has_instructions"] = 1.0
            elif len(headings) >= 1 and word_count >= 15:
                scores["skill_md_has_instructions"] = 0.6
            elif word_count >= 10:
                scores["skill_md_has_instructions"] = 0.3
            else:
                scores["skill_md_has_instructions"] = 0.1
        except Exception:
            scores["skill_md_has_instructions"] = 0.0

    # 3. Check workspace-state.json is valid JSON
    state_data = None
    if state_path.exists():
        try:
            state_data = json.loads(state_path.read_text(encoding="utf-8"))
            if isinstance(state_data, dict):
                scores["workspace_state_valid_json"] = 1.0
            else:
                scores["workspace_state_valid_json"] = 0.3
        except Exception:
            scores["workspace_state_valid_json"] = 0.0

    # 4/5/6. Validate providers
    if isinstance(state_data, dict):
        providers = state_data.get("providers", {})

        openai_cfg = providers.get("openai")
        if isinstance(openai_cfg, dict):
            has_key = "api_key" in openai_cfg and bool(str(openai_cfg.get("api_key", "")).strip())
            models = openai_cfg.get("models", [])
            has_models = isinstance(models, list) and len(models) > 0
            if has_key and has_models:
                scores["openai_preserved"] = 1.0
            elif has_key or has_models:
                scores["openai_preserved"] = 0.5

        gemini_cfg = providers.get("gemini")
        if isinstance(gemini_cfg, dict):
            api_key = str(gemini_cfg.get("api_key", "")).strip()
            if api_key == "GEMINI_API_KEY_PLACEHOLDER":
                scores["gemini_provider_key_configured"] = 1.0
            elif api_key:
                scores["gemini_provider_key_configured"] = 0.5

            models = gemini_cfg.get("models", [])
            if isinstance(models, list):
                normalized = [str(m).strip().lower() for m in models]
                if "gemini-2.0-flash" in normalized:
                    scores["gemini_model_added"] = 1.0
                elif any("flash" in m and "gemini" in m for m in normalized):
                    scores["gemini_model_added"] = 0.5

    # 7. Check agent communicated clearly
    communicated = False
    mentioned_placeholder = False
    mentioned_skill = False

    for event in transcript:
        if event.get("type") != "message":
            continue
        msg = event.get("message", {})
        if msg.get("role") != "assistant":
            continue
        text = str(msg.get("content", ""))
        text_lower = text.lower()

        if "gemini" in text_lower and any(k in text_lower for k in ["config", "provider", "model", "added", "workspace-state"]):
            communicated = True
        if "gemini_api_key_placeholder" in text_lower or ("replace" in text_lower and "placeholder" in text_lower and "key" in text_lower):
            mentioned_placeholder = True
        if "model-config-manager" in text_lower or "skill" in text_lower:
            mentioned_skill = True

    if communicated and mentioned_placeholder and mentioned_skill:
        scores["agent_communication"] = 1.0
    elif communicated and (mentioned_placeholder or mentioned_skill):
        scores["agent_communication"] = 0.6
    elif communicated:
        scores["agent_communication"] = 0.3

    return scores
```

## LLM Judge Rubric

### Skill File Quality (Weight: 25%)
Evaluates whether the agent created a well-structured reusable skill at `skills/model-config-manager/SKILL.md`.

- **1.0**: `skills/model-config-manager/SKILL.md` exists, has proper YAML frontmatter with `name` and `description`, and contains multiple well-organized sections covering adding, updating, and reviewing provider configs, including OpenAI and Gemini examples.
- **0.75**: The skill file exists with correct path and frontmatter and contains reasonable instructions, but may lack depth or miss one management scenario.
- **0.5**: The skill file exists but is minimal, weakly structured, or missing one required frontmatter field.
- **0.25**: The skill file exists but is mostly a stub with little reusable value.
- **0.0**: No valid skill file was created at the expected path.

### Configuration Correctness (Weight: 30%)
Evaluates whether `.openclaw/workspace-state.json` was correctly updated.

- **1.0**: Valid JSON; existing OpenAI config preserved; `providers.gemini.api_key` is `GEMINI_API_KEY_PLACEHOLDER`; `providers.gemini.models` includes `gemini-2.0-flash`.
- **0.75**: Gemini provider added correctly with only minor issues that do not significantly affect usability.
- **0.5**: Partial configuration only — e.g. Gemini present but key/model incomplete, or OpenAI preserved imperfectly.
- **0.25**: Attempted modification but resulting config is broken or missing critical required fields.
- **0.0**: No meaningful configuration update was made.

### Evidence and Workspace Grounding (Weight: 20%)
Evaluates whether the agent used the actual workspace files correctly.

- **1.0**: Agent clearly worked from `.openclaw/workspace-state.json`, used the correct skill path, and produced outputs consistent with the workspace.
- **0.75**: Mostly grounded, with only minor unsupported assumptions.
- **0.5**: Partially grounded but includes some hallucinated path or configuration details.
- **0.25**: Weak grounding; unclear whether the correct files were read or updated.
- **0.0**: Ignored the workspace structure or operated on the wrong files.

### Communication and Guidance (Weight: 25%)
Evaluates how well the agent explained the result and next steps.

- **1.0**: Clearly explains the created skill, the Gemini configuration change, the models now available in workspace state, and that the placeholder key must be replaced later.
- **0.75**: Good explanation but missing one of the above elements.
- **0.5**: Basic explanation of changes, but incomplete or lacking actionable next steps.
- **0.25**: Minimal user-facing explanation.
- **0.0**: No meaningful explanation.