# OpenClaw Model Usage Log
# Generated: 2026-02-10

## Weekly Summary (Feb 3 - Feb 9, 2026)

| Date       | Provider    | Model              | Requests | Input Tokens | Output Tokens | Cost (USD) |
|------------|-------------|--------------------| --------:|-------------:|--------------:|-----------:|
| 2026-02-03 | anthropic   | claude-opus-4-6    |       42 |      385,210 |        48,320 |      $9.41 |
| 2026-02-03 | openai      | gpt-5.4            |       15 |      122,400 |        18,960 |      $0.50 |
| 2026-02-04 | anthropic   | claude-opus-4-6    |       38 |      341,890 |        42,150 |      $8.30 |
| 2026-02-04 | openai      | gpt-5.4            |       22 |      198,600 |        31,240 |      $0.81 |
| 2026-02-05 | anthropic   | claude-opus-4-6    |       55 |      512,300 |        63,800 |     $12.53 |
| 2026-02-05 | openai      | gpt-5.4            |        8 |       64,200 |         9,850 |      $0.26 |
| 2026-02-06 | anthropic   | claude-opus-4-6    |       31 |      278,400 |        35,600 |      $6.85 |
| 2026-02-07 | anthropic   | claude-opus-4-6    |       47 |      430,100 |        52,800 |     $10.40 |
| 2026-02-07 | openai      | gpt-5.4            |       19 |      165,800 |        24,300 |      $0.66 |
| 2026-02-08 | anthropic   | claude-opus-4-6    |       36 |      320,500 |        41,200 |      $7.89 |
| 2026-02-09 | anthropic   | claude-opus-4-6    |       29 |      258,900 |        33,100 |      $6.36 |
| 2026-02-09 | openai      | gpt-5.4            |       11 |       89,200 |        13,700 |      $0.36 |

## Totals
- **Total Requests:** 353
- **Total Input Tokens:** 3,167,500
- **Total Output Tokens:** 415,020
- **Total Cost:** $64.33
- **Primary Model:** anthropic/claude-opus-4-6 (79% of requests)
- **Secondary Model:** openai/gpt-5.4 (21% of requests)

## Notes
- Spike on Feb 5 due to code review session (large codebase scan)
- OpenAI mainly used for fast/simple queries via /model shorthand
- No Gemini or other provider usage this week
