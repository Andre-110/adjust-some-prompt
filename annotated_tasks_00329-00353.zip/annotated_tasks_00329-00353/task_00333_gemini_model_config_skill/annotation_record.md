| 序号 | 修改项 | 修改原因 |
|------|--------|----------|
| 1 | 将 frontmatter 中 `workspace_files` 的旧字段 `path:` 改为规范写法，并补充所有实际提供的 assets 映射 | 旧格式不符合带 Assets 版数据规范，且原题未声明实际环境文件 |
| 2 | 将内联 `.openclaw/workspace-state.json` 中 OpenAI key 改为 `OPENAI_API_KEY_PLACEHOLDER` | 避免出现形似真实敏感信息的字符串 |
| 3 | 将 Prompt 中技能文件位置从根目录 `SKILL.md` 改为 `skills/model-config-manager/SKILL.md` | 符合 OpenClaw skill 路径规范 |
| 4 | 重写 Expected Behavior 中关于技能文件路径的描述 | 原文要求在 workspace 根创建 `SKILL.md`，与规范冲突 |
| 5 | 在 Expected Behavior 中明确 `providers.gemini.api_key` 必须为 `GEMINI_API_KEY_PLACEHOLDER`，并说明可保留 `active_model` 不变 | 提升答案判定明确性，减少歧义 |
| 6 | 调整 Grading Criteria，使其与规范技能路径和关键配置点一一对应 | 提高可独立验证性与覆盖度 |
| 7 | 重写 automated `grade()`，改为检查 `skills/model-config-manager/SKILL.md` | 原评分逻辑只检查根目录 `SKILL.md`，与规范冲突 |
| 8 | 在 `grade()` 中将 Gemini key 检查从“存在 api_key”提升为“匹配指定 placeholder” | 原逻辑过松，无法准确验证 Ground Truth |
| 9 | 在 `grade()` 中将 Gemini model 检查拆成独立项 | 与评分标准更好对齐，支持更清晰的部分得分 |
| 10 | 强化 `agent_communication` 检查，要求覆盖技能、Gemini 配置、placeholder 替换提示中的至少关键内容 | 提高评分信号质量 |
| 11 | 修改 LLM Judge Rubric 中对技能文件的路径要求 | 保持 rubric 与 prompt / grading / automated checks 一致 |
| 12 | 修正 `.openclaw/openclaw.json` 中形似真实 API key 和 bot token 的占位内容 | 满足 Assets 无敏感信息要求 |