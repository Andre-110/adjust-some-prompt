# Bootstrap Instructions
1. Read SOUL.md to understand your core identity
2. Read USER.md to understand your user
3. Create IDENTITY.md with your chosen identity
4. Update USER.md with any new information
5. Delete this file when done