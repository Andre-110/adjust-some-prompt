| 序号 | 修改项 | 修改原因 |
|------|--------|----------|
| 1 | 将 `workspace_files` 中旧字段 `path:` 改为 `dest:` | 符合新版数据规范，避免路径定义不合法 |
| 2 | 统一主配置文件为 `.openclaw/openclaw.json` | 原题 Prompt、grade()、Assets 三者路径不一致，需统一 |
| 3 | 删除/弃用 `config/openclaw.json` | 该文件不是合法 JSON，且与主配置路径冲突 |
| 4 | 删除/弃用 `config/model-aliases.json` | 文件内容提前泄露答案，削弱题目有效性 |
| 5 | 删除/弃用 `config/auth-profiles.json` | 与题目核心配置结构冲突，且含敏感样式信息 |
| 6 | 删除/弃用 `memory/2026-02-10.md` | 明确写出 Deepseek 已配置，属于答案泄露 |
| 7 | 删除/弃用 `sessions/*` 文件 | 含不必要个人标识和历史对话，且会泄露答案背景 |
| 8 | 将 `USER.md` 中 Telegram ID 替换为脱敏形式 `user-7093889838` | 降低敏感信息风险，符合虚构化要求 |
| 9 | 将 Moonshot API key 改为 `sk-fake-moonshot-key-example` | 避免使用真实样式或可疑敏感凭据 |
| 10 | 重写 Prompt，使其只要求可验证的核心操作 | 原 Prompt 与评分、Expected Behavior 存在范围不一致 |
| 11 | 精简并重写 Expected Behavior | 原版包含过多未评分或无依据的附加文件要求 |
| 12 | 重写 Grading Criteria | 使条目与实际可验证结果一一对应 |
| 13 | 重写 `grade()` | 修复路径错误、提升稳健性、保证空白输出时全 0 |
| 14 | 新增 `bootstrap_deleted` 自动评分项 | 使 Prompt 中“clean up BOOTSTRAP.md”与自动评分对齐 |
| 15 | 调整 LLM Judge Rubric 文案 | 与修正后的任务范围保持一致 |
| 16 | 保留 `difficulty: easy` | 修正后任务为基础配置编辑与少量文件创建，难度与 easy 匹配 |