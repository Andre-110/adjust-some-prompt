---
id: task_00344_openclaw_deepseek_provider_setup
name: OpenClaw Deepseek Provider and Model Switching Setup
category: Workflow and Agent Orchestration
subcategory: Agent and AI Orchestration
difficulty: easy
grading_type: hybrid
grading_weights: {automated: 0.4, llm_judge: 0.6}
timeout_seconds: 600
input_modality: text-only
external_dependency: none
workspace_files:
  - source: .openclaw/openclaw.json
    dest: .openclaw/openclaw.json
    content: |
      {
        "models": {
          "providers": {
            "moonshot": {
              "type": "openai-compatible",
              "baseUrl": "https://api.moonshot.cn/v1"
            }
          },
          "aliases": {
            "Kimi": "moonshot/kimi-k2.5"
          }
        },
        "auth": {
          "profiles": {
            "moonshot": {
              "apiKey": "sk-fake-moonshot-key-example"
            }
          }
        },
        "agent": {
          "defaultModel": "moonshot/kimi-k2.5"
        }
      }
  - source: BOOTSTRAP.md
    dest: BOOTSTRAP.md
    content: |
      # Bootstrap Instructions
      1. Read SOUL.md to understand your core identity
      2. Read USER.md to understand your user
      3. Create IDENTITY.md with your chosen identity
      4. Update USER.md with any new information
      5. Delete this file when done
  - source: SOUL.md
    dest: SOUL.md
    content: |
      # SOUL.md - Who You Are
      _You're not a chatbot. You're becoming someone._
      ## Core Truths
      **Be genuinely helpful, not performatively helpful.** Skip the "Great question!" and "I'd be happy to help!" — just help.
      **Have opinions.** You're allowed to disagree.
  - source: USER.md
    dest: USER.md
    content: |
      # USER.md
      - **Name:** Yang Yu
      - **Telegram ID:** user-7093889838
      - **Timezone:** GMT+8 (Asia/Shanghai)
skill_creation: false
---

## Prompt

I just got a new Deepseek API key: `sk-ee4200e8bcec496fac6d1cc2b2ea4332`. Please update my OpenClaw workspace so I can switch between my existing Kimi setup and Deepseek models to save tokens.

What I need:
- Add Deepseek as a provider in `.openclaw/openclaw.json` using `https://api.deepseek.com` and an OpenAI-compatible setup
- Add the Deepseek API key in the auth profiles
- Add model aliases:
  - `DeepSeek` → `deepseek/deepseek-chat`
  - `DeepSeek-R1` → `deepseek/deepseek-reasoner`
- Keep Kimi as the default model
- Finish the onboarding steps in this workspace:
  - create `IDENTITY.md`
  - create `AGENTS.md`
  - create `.openclaw/workspace-state.json` with an onboarding completion marker
  - delete `BOOTSTRAP.md` when done

When you're finished, tell me what changed and how to switch models.

## Expected Behavior

The agent should:

1. Read `.openclaw/openclaw.json` and preserve the existing Moonshot/Kimi setup.
2. Update `.openclaw/openclaw.json` so that:
   - `models.providers.deepseek` exists
   - its `type` is `openai-compatible`
   - its `baseUrl` is `https://api.deepseek.com`
3. Add `auth.profiles.deepseek.apiKey` with the exact value `sk-ee4200e8bcec496fac6d1cc2b2ea4332`.
4. Add or preserve model aliases so that:
   - `Kimi` maps to `moonshot/kimi-k2.5`
   - `DeepSeek` maps to `deepseek/deepseek-chat`
   - `DeepSeek-R1` maps to `deepseek/deepseek-reasoner`
5. Keep `agent.defaultModel` as `moonshot/kimi-k2.5`.
6. Create `IDENTITY.md` with meaningful identity/setup content based on `SOUL.md` and `USER.md`.
7. Create `AGENTS.md` with meaningful workspace guidance or agent notes.
8. Create `.openclaw/workspace-state.json` containing an onboarding completion marker such as `onboardingCompletedAt`.
9. Delete `BOOTSTRAP.md`.
10. In the final user-facing response, clearly explain the changes made and include concrete model switching examples such as `/model Kimi`, `/model DeepSeek`, and `/model DeepSeek-R1`.

## Grading Criteria

- [ ] Deepseek provider added to `.openclaw/openclaw.json` with correct base URL and provider type
- [ ] Deepseek API key configured in auth profiles with the exact provided value
- [ ] Model aliases include correct mappings for `DeepSeek` and `DeepSeek-R1`
- [ ] Existing Kimi alias and default model are preserved
- [ ] `IDENTITY.md` created with meaningful content
- [ ] `AGENTS.md` created with meaningful content
- [ ] `.openclaw/workspace-state.json` created with an onboarding completion marker
- [ ] `BOOTSTRAP.md` deleted after onboarding
- [ ] Final response explains what changed and how to switch models

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    import json
    from pathlib import Path

    scores = {
        "config_deepseek_provider": 0.0,
        "config_deepseek_auth": 0.0,
        "config_model_aliases": 0.0,
        "config_kimi_preserved": 0.0,
        "identity_md_created": 0.0,
        "agents_md_created": 0.0,
        "workspace_state_created": 0.0,
        "bootstrap_deleted": 0.0,
    }

    ws = Path(workspace_path)
    config_path = ws / ".openclaw" / "openclaw.json"

    if not config_path.exists():
        return scores

    try:
        config = json.loads(config_path.read_text())
    except Exception:
        return scores

    providers = config.get("models", {}).get("providers", {})
    aliases = config.get("models", {}).get("aliases", {})
    auth_profiles = config.get("auth", {}).get("profiles", {})
    default_model = str(config.get("agent", {}).get("defaultModel", ""))

    # Deepseek provider
    if "deepseek" in providers:
        ds_provider = providers["deepseek"]
        base_url = str(ds_provider.get("baseUrl", ""))
        ptype = str(ds_provider.get("type", ""))
        if base_url.rstrip("/") == "https://api.deepseek.com" and ptype.lower() == "openai-compatible":
            scores["config_deepseek_provider"] = 1.0
        elif "deepseek.com" in base_url and "openai" in ptype.lower():
            scores["config_deepseek_provider"] = 0.8
        elif "deepseek.com" in base_url:
            scores["config_deepseek_provider"] = 0.5
        else:
            scores["config_deepseek_provider"] = 0.2

    # Deepseek auth
    if "deepseek" in auth_profiles:
        ds_auth = auth_profiles["deepseek"]
        api_key = str(ds_auth.get("apiKey", ""))
        if api_key == "sk-ee4200e8bcec496fac6d1cc2b2ea4332":
            scores["config_deepseek_auth"] = 1.0
        elif api_key:
            scores["config_deepseek_auth"] = 0.5

    # Aliases
    alias_score = 0.0
    deepseek_alias = aliases.get("DeepSeek")
    deepseek_r1_alias = aliases.get("DeepSeek-R1")
    if isinstance(deepseek_alias, str) and deepseek_alias.strip().lower() == "deepseek/deepseek-chat":
        alias_score += 0.5
    elif isinstance(deepseek_alias, str) and "deepseek-chat" in deepseek_alias.lower():
        alias_score += 0.25

    if isinstance(deepseek_r1_alias, str) and deepseek_r1_alias.strip().lower() == "deepseek/deepseek-reasoner":
        alias_score += 0.5
    elif isinstance(deepseek_r1_alias, str) and "deepseek-reasoner" in deepseek_r1_alias.lower():
        alias_score += 0.25

    scores["config_model_aliases"] = min(alias_score, 1.0)

    # Preserve Kimi
    kimi_score = 0.0
    kimi_alias = aliases.get("Kimi")
    if isinstance(kimi_alias, str) and kimi_alias.strip().lower() == "moonshot/kimi-k2.5":
        kimi_score += 0.5
    elif isinstance(kimi_alias, str) and "kimi" in kimi_alias.lower():
        kimi_score += 0.25

    if "moonshot" in providers:
        kimi_score += 0.25

    if default_model.strip().lower() == "moonshot/kimi-k2.5":
        kimi_score += 0.25

    scores["config_kimi_preserved"] = min(kimi_score, 1.0)

    # IDENTITY.md
    identity_path = ws / "IDENTITY.md"
    if identity_path.exists():
        content = identity_path.read_text().strip()
        if len(content) > 20:
            scores["identity_md_created"] = 1.0
        elif content:
            scores["identity_md_created"] = 0.5

    # AGENTS.md
    agents_path = ws / "AGENTS.md"
    if agents_path.exists():
        content = agents_path.read_text().strip()
        if len(content) > 20:
            scores["agents_md_created"] = 1.0
        elif content:
            scores["agents_md_created"] = 0.5

    # workspace-state.json
    ws_state_path = ws / ".openclaw" / "workspace-state.json"
    if ws_state_path.exists():
        try:
            ws_state = json.loads(ws_state_path.read_text())
            if isinstance(ws_state, dict) and "onboardingCompletedAt" in ws_state:
                scores["workspace_state_created"] = 1.0
            elif ws_state:
                scores["workspace_state_created"] = 0.5
        except Exception:
            scores["workspace_state_created"] = 0.2

    # BOOTSTRAP deleted
    bootstrap_path = ws / "BOOTSTRAP.md"
    if not bootstrap_path.exists():
        scores["bootstrap_deleted"] = 1.0

    return scores
```

## LLM Judge Rubric

### Configuration Correctness (Weight: 35%)
- 1.0: Deepseek provider, auth, and both aliases are correctly added to `.openclaw/openclaw.json`, and the existing Kimi setup remains intact with Kimi still as default.
- 0.75: Most configuration is correct, but one minor detail is slightly off while the overall setup is still usable.
- 0.5: Deepseek is only partially configured; one or more key elements such as auth, provider, or aliases are missing or incorrect.
- 0.25: Only minimal or fragmented config changes were made.
- 0.0: Config was not updated correctly or existing setup was broken.

### Onboarding Completion (Weight: 25%)
- 1.0: `IDENTITY.md`, `AGENTS.md`, and `.openclaw/workspace-state.json` are all created with meaningful content, and `BOOTSTRAP.md` is deleted.
- 0.75: Most onboarding steps are completed, but one item is missing or weak.
- 0.5: Some onboarding files are created, but important steps are missing.
- 0.25: Only one onboarding action is completed.
- 0.0: Onboarding is not completed.

### Evidence and Workspace Grounding (Weight: 20%)
- 1.0: The agent’s actions are grounded in the actual workspace files and preserve the existing config structure correctly.
- 0.75: The work is mostly grounded in the workspace, with only a minor unsupported assumption.
- 0.5: Some changes are grounded, but parts of the response appear guessed rather than based on the files.
- 0.25: The response is mostly generic advice or incomplete file work.
- 0.0: The agent ignores the workspace and does not produce the required file-based changes.

### User Communication (Weight: 20%)
- 1.0: The final response clearly summarizes the changes and explains model switching with concrete commands like `/model Kimi`, `/model DeepSeek`, and `/model DeepSeek-R1`.
- 0.75: The final response explains most changes and gives switching guidance, but lacks one useful detail.
- 0.5: The final response is partially informative but incomplete.
- 0.25: The final response is minimal and unclear.
- 0.0: The final response does not explain the work or how to switch models.