#!/usr/bin/env python3
"""
Mag 7 Stock Price Monitor
=========================
Monitors the Magnificent Seven stocks (AAPL, MSFT, GOOGL, AMZN, NVDA, META, TSLA)
for abnormal price movements (±3% or more) using Yahoo Finance data.
Sends alerts via DingTalk webhook when anomalies are detected.

Usage:
    python stock_monitor.py                  # Run once
    python stock_monitor.py --dry-run        # Run without sending notifications
    python stock_monitor.py --test-notify    # Send a test DingTalk message
"""

import os
import sys
import json
import time
import hmac
import hashlib
import base64
import logging
import argparse
import urllib.parse
import urllib.request
from datetime import datetime, timezone, timedelta
from pathlib import Path

import yaml

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

CONFIG_PATH = Path(__file__).parent / "config.yaml"
PRICE_CACHE_PATH = Path(__file__).parent / "data" / "last_prices.json"


def load_config(path: str | Path = CONFIG_PATH) -> dict:
    """Load YAML configuration and resolve environment variable placeholders."""
    with open(path) as f:
        cfg = yaml.safe_load(f)
    # Resolve ${ENV_VAR} patterns in dingtalk section
    dt = cfg.get("dingtalk", {})
    for key in ("webhook_url", "secret"):
        val = dt.get(key, "")
        if "${" in val:
            for env_var in _extract_env_vars(val):
                val = val.replace(f"${{{env_var}}}", os.environ.get(env_var, ""))
            dt[key] = val
    return cfg


def _extract_env_vars(s: str) -> list[str]:
    """Extract ${VAR_NAME} patterns from string."""
    import re
    return re.findall(r"\$\{(\w+)\}", s)


# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------

def setup_logging(cfg: dict) -> logging.Logger:
    log_cfg = cfg.get("logging", {})
    log_dir = Path(log_cfg.get("file", "logs/monitor.log")).parent
    log_dir.mkdir(parents=True, exist_ok=True)

    from logging.handlers import RotatingFileHandler

    logger = logging.getLogger("stock_monitor")
    logger.setLevel(getattr(logging, log_cfg.get("level", "INFO")))

    fmt = logging.Formatter("%(asctime)s [%(levelname)s] %(message)s", datefmt="%Y-%m-%d %H:%M:%S")

    fh = RotatingFileHandler(
        log_cfg.get("file", "logs/monitor.log"),
        maxBytes=log_cfg.get("max_bytes", 10_485_760),
        backupCount=log_cfg.get("backup_count", 5),
    )
    fh.setFormatter(fmt)
    logger.addHandler(fh)

    sh = logging.StreamHandler()
    sh.setFormatter(fmt)
    logger.addHandler(sh)

    return logger


# ---------------------------------------------------------------------------
# Yahoo Finance Data Fetcher
# ---------------------------------------------------------------------------

def fetch_stock_data(ticker: str, cfg: dict) -> dict | None:
    """
    Fetch recent price data for a single ticker from Yahoo Finance.

    Returns dict with keys: ticker, current_price, previous_close, change_pct, volume,
    avg_volume, timestamp.  Returns None on failure.
    """
    yf_cfg = cfg.get("yahoo_finance", {})
    base_url = yf_cfg.get("base_url", "https://query1.finance.yahoo.com/v8/finance/chart")
    interval = yf_cfg.get("interval", "1d")
    range_ = yf_cfg.get("range", "5d")
    timeout = yf_cfg.get("timeout", 10)

    url = f"{base_url}/{ticker}?interval={interval}&range={range_}"
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
    }

    req = urllib.request.Request(url, headers=headers)

    for attempt in range(yf_cfg.get("max_retries", 3)):
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                data = json.loads(resp.read().decode())

            result = data["chart"]["result"][0]
            meta = result["meta"]
            quotes = result["indicators"]["quote"][0]
            closes = [c for c in quotes["close"] if c is not None]
            volumes = [v for v in quotes["volume"] if v is not None]

            if len(closes) < 2:
                return None

            current_price = meta.get("regularMarketPrice", closes[-1])
            previous_close = meta.get("chartPreviousClose", closes[-2])
            change_pct = ((current_price - previous_close) / previous_close) * 100
            avg_volume = sum(volumes) / len(volumes) if volumes else 0

            return {
                "ticker": ticker,
                "current_price": round(current_price, 2),
                "previous_close": round(previous_close, 2),
                "change_pct": round(change_pct, 2),
                "volume": volumes[-1] if volumes else 0,
                "avg_volume": round(avg_volume),
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }

        except Exception as e:
            if attempt < yf_cfg.get("max_retries", 3) - 1:
                time.sleep(yf_cfg.get("retry_delay", 2))
            else:
                logging.getLogger("stock_monitor").error(f"Failed to fetch {ticker}: {e}")
                return None


# ---------------------------------------------------------------------------
# Anomaly Detection
# ---------------------------------------------------------------------------

def detect_anomalies(stock_data: list[dict], cfg: dict) -> list[dict]:
    """
    Check each stock for price change exceeding threshold.
    Returns list of anomaly dicts.
    """
    threshold = cfg.get("thresholds", {}).get("price_change_pct", 3.0)
    vol_mult = cfg.get("thresholds", {}).get("volume_spike_multiplier", 2.5)
    anomalies = []

    for stock in stock_data:
        if stock is None:
            continue
        reasons = []
        if abs(stock["change_pct"]) >= threshold:
            direction = "📈 UP" if stock["change_pct"] > 0 else "📉 DOWN"
            reasons.append(f"Price {direction} {stock['change_pct']:+.2f}%")
        if stock["avg_volume"] > 0 and stock["volume"] > stock["avg_volume"] * vol_mult:
            reasons.append(f"Volume spike: {stock['volume']:,} vs avg {stock['avg_volume']:,}")

        if reasons:
            anomalies.append({**stock, "reasons": reasons})

    return anomalies


# ---------------------------------------------------------------------------
# DingTalk Notification
# ---------------------------------------------------------------------------

def _sign_dingtalk(secret: str) -> tuple[str, str]:
    """Generate DingTalk webhook signature."""
    timestamp = str(round(time.time() * 1000))
    string_to_sign = f"{timestamp}\n{secret}"
    hmac_code = hmac.new(
        secret.encode("utf-8"),
        string_to_sign.encode("utf-8"),
        digestmod=hashlib.sha256,
    ).digest()
    sign = urllib.parse.quote_plus(base64.b64encode(hmac_code).decode())
    return timestamp, sign


def build_markdown_message(anomalies: list[dict], cfg: dict) -> dict:
    """Build a DingTalk markdown message payload."""
    cst = timezone(timedelta(hours=8))
    now_str = datetime.now(cst).strftime("%Y-%m-%d %H:%M:%S CST")

    title = f"⚠️ Stock Alert — {len(anomalies)} anomal{'y' if len(anomalies)==1 else 'ies'} detected"
    lines = [f"## {title}", f"> Scan time: {now_str}", ""]

    for a in anomalies:
        emoji = "🔴" if a["change_pct"] < 0 else "🟢"
        lines.append(f"### {emoji} {a['ticker']}")
        lines.append(f"- **Price:** ${a['current_price']:,.2f}  (prev close ${a['previous_close']:,.2f})")
        lines.append(f"- **Change:** {a['change_pct']:+.2f}%")
        for r in a.get("reasons", []):
            lines.append(f"- {r}")
        lines.append("")

    at_all = any(abs(a["change_pct"]) >= cfg.get("dingtalk", {}).get("at_all_threshold", 5.0) for a in anomalies)

    payload = {
        "msgtype": "markdown",
        "markdown": {"title": title, "text": "\n".join(lines)},
        "at": {"isAtAll": at_all},
    }
    return payload


def send_dingtalk(payload: dict, cfg: dict, logger: logging.Logger) -> bool:
    """Send a message via DingTalk group robot webhook."""
    dt_cfg = cfg.get("dingtalk", {})
    webhook_url = dt_cfg.get("webhook_url", "")
    secret = dt_cfg.get("secret", "")

    if not webhook_url:
        logger.error("DingTalk webhook URL not configured")
        return False

    if secret:
        ts, sign = _sign_dingtalk(secret)
        sep = "&" if "?" in webhook_url else "?"
        webhook_url = f"{webhook_url}{sep}timestamp={ts}&sign={sign}"

    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(
        webhook_url,
        data=data,
        headers={"Content-Type": "application/json"},
        method="POST",
    )

    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            result = json.loads(resp.read().decode())
            if result.get("errcode") == 0:
                logger.info("DingTalk notification sent successfully")
                return True
            else:
                logger.error(f"DingTalk API error: {result}")
                return False
    except Exception as e:
        logger.error(f"Failed to send DingTalk notification: {e}")
        return False


# ---------------------------------------------------------------------------
# Price Cache (for trend tracking)
# ---------------------------------------------------------------------------

def save_price_cache(stock_data: list[dict]):
    """Persist latest prices to JSON for trend tracking."""
    PRICE_CACHE_PATH.parent.mkdir(parents=True, exist_ok=True)
    cache = {}
    for s in stock_data:
        if s:
            cache[s["ticker"]] = {
                "price": s["current_price"],
                "change_pct": s["change_pct"],
                "timestamp": s["timestamp"],
            }
    with open(PRICE_CACHE_PATH, "w") as f:
        json.dump(cache, f, indent=2)


def load_price_cache() -> dict:
    """Load previous price cache."""
    if PRICE_CACHE_PATH.exists():
        with open(PRICE_CACHE_PATH) as f:
            return json.load(f)
    return {}


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(description="Mag 7 Stock Price Monitor")
    parser.add_argument("--dry-run", action="store_true", help="Detect anomalies but skip notifications")
    parser.add_argument("--test-notify", action="store_true", help="Send a test DingTalk message")
    parser.add_argument("--config", default=str(CONFIG_PATH), help="Path to config YAML")
    args = parser.parse_args()

    cfg = load_config(args.config)
    logger = setup_logging(cfg)

    logger.info("=" * 60)
    logger.info("Stock monitor started")

    if args.test_notify:
        test_payload = {
            "msgtype": "text",
            "text": {"content": "🔔 Stock Monitor test message — DingTalk integration is working!"},
        }
        ok = send_dingtalk(test_payload, cfg, logger)
        sys.exit(0 if ok else 1)

    # Fetch data for all tickers
    tickers = cfg.get("tickers", [])
    logger.info(f"Fetching data for {len(tickers)} tickers: {', '.join(tickers)}")
    stock_data = []
    for t in tickers:
        sd = fetch_stock_data(t, cfg)
        if sd:
            logger.info(f"  {t}: ${sd['current_price']:,.2f} ({sd['change_pct']:+.2f}%)")
        else:
            logger.warning(f"  {t}: FETCH FAILED")
        stock_data.append(sd)

    # Detect anomalies
    anomalies = detect_anomalies(stock_data, cfg)

    if anomalies:
        logger.warning(f"🚨 {len(anomalies)} anomalies detected!")
        for a in anomalies:
            logger.warning(f"  {a['ticker']}: {a['change_pct']:+.2f}% — {', '.join(a['reasons'])}")

        if args.dry_run:
            logger.info("Dry run — skipping DingTalk notification")
            payload = build_markdown_message(anomalies, cfg)
            logger.info(f"Would send:\n{json.dumps(payload, indent=2, ensure_ascii=False)}")
        else:
            payload = build_markdown_message(anomalies, cfg)
            send_dingtalk(payload, cfg, logger)
    else:
        logger.info("✅ No anomalies detected — all stocks within normal range")

    # Save price cache
    save_price_cache(stock_data)
    logger.info("Price cache updated")
    logger.info("Monitor run complete")


if __name__ == "__main__":
    main()
