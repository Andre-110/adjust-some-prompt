| 序号 | 修改项 | 修改原因 |
|------|--------|----------|
| 1 | 将 frontmatter 中 `difficulty` 从 `hard` 改为 `medium` | 现有资产已提供完整配置、样例数据和参考脚本，整体难度低于 hard，更接近 medium |
| 2 | 将 `workspace_files` 从旧格式 `path:` 改为合规的 `dest:` 列表 | 本批数据规范禁止继续使用旧字段 `path:` |
| 3 | 将题面引用的 `config.json`、`sample_prices.json` 改为实际存在的 `config.yaml`、`data/mock_prices.json`、`data/last_prices.json` 等 | Prompt 与 Assets 文件名不一致，导致任务不可正确执行或评分 |
| 4 | 在 Prompt 中明确 `stock_monitor.py` 是可参考资产，但仍要求产出 `monitor.py` | 避免 agent 因已有参考脚本而混淆交付物要求，也避免评分与任务要求不一致 |
| 5 | 修正 Expected Behavior 中异常股票结论，从仅 TSLA 改为 NVDA 和 TSLA 均为异常 | 根据 `data/mock_prices.json`，NVDA +4.24%、TSLA -7.93% 均超过 ±3% 阈值 |
| 6 | 补充 Expected Behavior 对 fallback 数据优先级和字段完整性的说明 | `data/mock_prices.json` 含价格、涨跌幅、成交量，较适合作为本题 fallback 的 Ground Truth |
| 7 | 重写 Grading Criteria，使各条目更独立、可单独验证，并与实际资产文件名对齐 | 原 criteria 与真实文件名不一致，且部分条目表述不够独立 |
| 8 | 修改 Automated Checks，新增 `report_has_key_fields`、`monitor_reads_config` 等 score key | 提高评分覆盖面，使其与 Grading Criteria 更一致 |
| 9 | 修改 Automated Checks 中异常检测逻辑，使其支持识别 NVDA 与 TSLA 两个关键异常 | 原评分逻辑偏向仅检查 TSLA，不符合实际 fallback 数据 |
| 10 | 保留 “attempted live data fetch” 检查，但允许最终使用本地 fallback 完成任务 | 与 Prompt 和 Expected Behavior 保持一致，兼容无网络环境 |
| 11 | 更新 LLM Judge Rubric 中 anomaly Ground Truth，从仅 TSLA 改为 NVDA 和 TSLA | Rubric 必须与实际资产中的可验证答案一致 |
| 12 | 建议替换 `.env` 中看似真实的 DingTalk token/secret 为明显虚构占位值 | 避免敏感信息风险，满足 Assets 无敏感信息要求 |