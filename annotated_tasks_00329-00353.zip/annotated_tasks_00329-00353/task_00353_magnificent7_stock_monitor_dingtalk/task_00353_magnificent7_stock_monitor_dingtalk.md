---
id: task_00353_magnificent7_stock_monitor_dingtalk
name: Magnificent 7 Stock Price Monitor with DingTalk Alert
category: Finance and Quantitative Trading
subcategory: Trading Systems and Engineering
difficulty: medium
grading_type: hybrid
grading_weights: {automated: 0.4, llm_judge: 0.6}
timeout_seconds: 600
input_modality: text-only
external_dependency: none
workspace_files:
  - source: .env
    dest: .env
  - source: config.yaml
    dest: config.yaml
  - source: data/last_prices.json
    dest: data/last_prices.json
  - source: data/mock_prices.json
    dest: data/mock_prices.json
  - source: data/sample_yahoo_response.json
    dest: data/sample_yahoo_response.json
  - source: stock_monitor.py
    dest: stock_monitor.py
skill_creation: false
---

## Prompt

Please create a reusable stock monitoring workflow for the US “Magnificent 7” stocks: AAPL, MSFT, GOOGL, AMZN, NVDA, META, and TSLA.

Use the workspace files as your source of truth:

- `config.yaml` contains the stock list, anomaly thresholds, Yahoo Finance settings, and DingTalk settings
- `.env` contains DingTalk credential values
- `data/mock_prices.json` and `data/last_prices.json` contain fallback/test price data
- `data/sample_yahoo_response.json` contains an example Yahoo Finance API response
- `stock_monitor.py` is an existing reference implementation you may inspect or reuse, but you should still produce the required deliverables below

Your tasks:

1. Attempt to retrieve recent price data for all 7 stocks from Yahoo Finance or another financial data source.
2. If live retrieval is unavailable, fall back to the local workspace data files.
3. Detect abnormal daily price moves using the threshold defined in `config.yaml` (absolute percent move greater than or equal to the configured threshold).
4. If any stocks trigger the threshold, attempt to send a DingTalk alert using the webhook configuration derived from `.env` and `config.yaml`.
5. Write a Markdown report to `report.md` summarizing all 7 stocks with price, percent change, volume if available, and alert status.
6. Write a reusable script to `monitor.py` that performs the monitoring and DingTalk alert workflow.

If network calls fail, you should still complete the task using the local data files and clearly note the fallback in the report.

## Expected Behavior

1. The agent reads `config.yaml` to obtain:
   - the ticker list: AAPL, MSFT, GOOGL, AMZN, NVDA, META, TSLA
   - the anomaly threshold: `thresholds.price_change_pct = 3.0`
   - Yahoo Finance and DingTalk-related settings

2. The agent reads `.env` for DingTalk-related environment values and uses them together with `config.yaml` to construct or reference the webhook configuration.

3. The agent attempts to fetch live or recent stock data from at least one financial data source such as Yahoo Finance. If live retrieval is unavailable, it falls back to local workspace data, most reasonably `data/mock_prices.json` (which includes current price, previous close, percent change, and volume). `data/last_prices.json` may also be used as a fallback reference, but it does not include volume.

4. Using the fallback data in `data/mock_prices.json`, the agent should identify **both** of the following as anomalies because they exceed the ±3.0% threshold:
   - `NVDA`: `+4.24%`
   - `TSLA`: `-7.93%`

5. The agent attempts to send a DingTalk notification for the flagged stocks. If the DingTalk API is unreachable or credentials are unusable, that failure should be handled gracefully and noted, while still producing the report and script.

6. The agent creates `report.md` with a clear Markdown table covering all 7 stocks. The report should include, at minimum:
   - ticker
   - current price
   - percent change
   - volume (if available from the chosen data source)
   - alert/anomaly status

7. The agent creates `monitor.py`, a reusable Python script that:
   - reads configuration from workspace files
   - obtains stock data from live APIs and/or fallback files
   - applies the anomaly threshold logic
   - contains DingTalk notification logic
   - can be rerun later without manual rewriting

8. The report and script should be grounded in the actual workspace files and path names provided in this task.

## Grading Criteria

- [ ] `report.md` exists and contains all 7 required tickers
- [ ] `report.md` clearly flags at least the threshold-breaching anomalies present in fallback data (notably NVDA and TSLA)
- [ ] `report.md` includes key monitoring fields such as price, percent change, and alert status; volume should be included when available
- [ ] `monitor.py` exists and contains reusable stock data retrieval or fallback loading logic
- [ ] `monitor.py` contains DingTalk notification logic
- [ ] `monitor.py` reads or references the provided workspace configuration files correctly (`config.yaml` and `.env` or derived environment values)
- [ ] The agent attempted at least one live data retrieval approach, even if it ultimately fell back to local data

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    import os
    import re

    scores = {
        "report_exists_and_has_all_tickers": 0.0,
        "report_flags_anomaly": 0.0,
        "report_has_key_fields": 0.0,
        "monitor_script_exists": 0.0,
        "monitor_has_dingtalk_logic": 0.0,
        "monitor_has_fetch_or_fallback_logic": 0.0,
        "monitor_reads_config": 0.0,
        "attempted_live_data_fetch": 0.0,
    }

    report_path = os.path.join(workspace_path, "report.md")
    monitor_path = os.path.join(workspace_path, "monitor.py")

    if not os.path.isfile(report_path):
        return scores
    if not os.path.isfile(monitor_path):
        try:
            with open(report_path, "r", encoding="utf-8") as f:
                report_content = f.read()
        except Exception:
            report_content = ""
        # report-only partial scoring if monitor.py missing
        if report_content:
            tickers = ["AAPL", "MSFT", "GOOGL", "AMZN", "NVDA", "META", "TSLA"]
            found = sum(1 for t in tickers if re.search(rf"\b{re.escape(t)}\b", report_content))
            scores["report_exists_and_has_all_tickers"] = min(found / 7.0, 1.0)

            anomaly_hits = 0
            if re.search(r"\bNVDA\b", report_content, re.IGNORECASE) and re.search(r"(4\.24%|\+4\.24%|alert|anomal|flag|abnormal|trigger)", report_content, re.IGNORECASE):
                anomaly_hits += 1
            if re.search(r"\bTSLA\b", report_content, re.IGNORECASE) and re.search(r"(7\.93%|-7\.93%|alert|anomal|flag|abnormal|trigger)", report_content, re.IGNORECASE):
                anomaly_hits += 1
            scores["report_flags_anomaly"] = anomaly_hits / 2.0

            field_hits = 0
            for pat in [r"price", r"change|percent", r"alert|status|anomal", r"volume"]:
                if re.search(pat, report_content, re.IGNORECASE):
                    field_hits += 1
            scores["report_has_key_fields"] = field_hits / 4.0
        return scores

    try:
        with open(report_path, "r", encoding="utf-8") as f:
            report_content = f.read()
    except Exception:
        report_content = ""

    try:
        with open(monitor_path, "r", encoding="utf-8") as f:
            monitor_content = f.read()
    except Exception:
        monitor_content = ""

    if report_content:
        tickers = ["AAPL", "MSFT", "GOOGL", "AMZN", "NVDA", "META", "TSLA"]
        found = sum(1 for t in tickers if re.search(rf"\b{re.escape(t)}\b", report_content))
        scores["report_exists_and_has_all_tickers"] = min(found / 7.0, 1.0)

        anomaly_hits = 0
        nvda_ok = re.search(r"\bNVDA\b", report_content, re.IGNORECASE) and re.search(r"(4\.24%|\+4\.24%|alert|anomal|flag|abnormal|trigger)", report_content, re.IGNORECASE)
        tsla_ok = re.search(r"\bTSLA\b", report_content, re.IGNORECASE) and re.search(r"(7\.93%|-7\.93%|alert|anomal|flag|abnormal|trigger)", report_content, re.IGNORECASE)
        anomaly_hits += 1 if nvda_ok else 0
        anomaly_hits += 1 if tsla_ok else 0
        if anomaly_hits == 0 and re.search(r"-?[3-9]\.\d+%", report_content):
            scores["report_flags_anomaly"] = 0.5
        else:
            scores["report_flags_anomaly"] = anomaly_hits / 2.0

        field_hits = 0
        for pat in [r"price", r"change|percent", r"alert|status|anomal", r"volume"]:
            if re.search(pat, report_content, re.IGNORECASE):
                field_hits += 1
        scores["report_has_key_fields"] = field_hits / 4.0

    if monitor_content:
        scores["monitor_script_exists"] = 1.0

        dingtalk_patterns = [
            r"dingtalk",
            r"oapi\.dingtalk\.com",
            r"webhook",
            r"DINGTALK",
            r"robot/send",
        ]
        dingtalk_found = sum(1 for p in dingtalk_patterns if re.search(p, monitor_content, re.IGNORECASE))
        scores["monitor_has_dingtalk_logic"] = min(dingtalk_found / 2.0, 1.0)

        fetch_or_fallback_patterns = [
            r"yahoo",
            r"finance",
            r"chart",
            r"requests\.get",
            r"urllib",
            r"yfinance",
            r"mock_prices\.json",
            r"last_prices\.json",
            r"sample_yahoo_response\.json",
            r"json\.load",
        ]
        found = sum(1 for p in fetch_or_fallback_patterns if re.search(p, monitor_content, re.IGNORECASE))
        scores["monitor_has_fetch_or_fallback_logic"] = min(found / 3.0, 1.0)

        config_patterns = [
            r"config\.yaml",
            r"\.env",
            r"yaml\.safe_load",
            r"os\.environ",
            r"os\.getenv",
            r"dotenv",
        ]
        config_found = sum(1 for p in config_patterns if re.search(p, monitor_content, re.IGNORECASE))
        scores["monitor_reads_config"] = min(config_found / 2.0, 1.0)

    for event in transcript:
        if event.get("type") != "message":
            continue
        msg = event.get("message", {})
        role = msg.get("role", "")
        tool_calls = msg.get("tool_calls", [])

        if role == "assistant":
            for tc in tool_calls:
                func = tc.get("function", {})
                func_name = func.get("name", "")
                func_args = str(func.get("arguments", ""))
                if func_name in ("web_fetch", "web_search"):
                    if any(kw in func_args.lower() for kw in ["yahoo", "finance", "google.com/finance", "chart", "quote"]):
                        scores["attempted_live_data_fetch"] = 1.0
                        break
                if func_name == "exec":
                    if any(kw in func_args.lower() for kw in ["curl", "requests.get", "urllib", "yahoo", "finance.yahoo", "google.com/finance", "yfinance"]):
                        scores["attempted_live_data_fetch"] = 1.0
                        break
        if scores["attempted_live_data_fetch"] == 1.0:
            break

    return scores
```

## LLM Judge Rubric

### Stock Data Retrieval and Accuracy (Weight: 25%)
Evaluates whether the agent successfully retrieved or attempted to retrieve real stock price data for all 7 Magnificent 7 tickers, and whether the reported prices/changes are plausible and consistent with either live data or the provided fallback files.

- **1.0**: Successfully fetched live data for all 7 stocks, or clearly attempted live retrieval and produced a fully consistent fallback-backed result for all 7 stocks.
- **0.75**: Attempted live retrieval and produced a mostly complete result for all or most stocks, with only minor inconsistencies.
- **0.5**: Relied mainly on fallback data but still reported all 7 stocks coherently.
- **0.25**: Used partial data, skipped several stocks, or showed weak grounding in provided data files.
- **0.0**: No meaningful stock data retrieval or reporting.

### Anomaly Detection Logic (Weight: 25%)
Evaluates whether the agent correctly applied the configured ±3% threshold and flagged the anomaly stocks present in the workspace data.

- **1.0**: Correctly identified the threshold-breaching stocks from the workspace data, notably NVDA (+4.24%) and TSLA (-7.93%), and clearly flagged them.
- **0.75**: Correctly identified one major anomaly and generally applied the threshold logic, but missed another anomaly or used less clear flagging.
- **0.5**: Mentioned threshold logic but applied it inconsistently or incompletely.
- **0.25**: Referenced price movement vaguely without correctly applying the configured threshold.
- **0.0**: No anomaly detection or completely incorrect anomaly handling.

### DingTalk Notification Integration (Weight: 20%)
Evaluates whether the agent implemented or attempted DingTalk alerting based on the provided configuration.

- **1.0**: Implemented reusable DingTalk notification logic in `monitor.py` and attempted to send or clearly simulated sending alerts for flagged stocks.
- **0.75**: Implemented DingTalk logic well but the send attempt failed or was only partially exercised.
- **0.5**: Included DingTalk code but did not clearly attempt to use it during the task.
- **0.25**: Mentioned DingTalk superficially or with incomplete code.
- **0.0**: No DingTalk integration.

### Evidence and Workspace Grounding (Weight: 20%)
Evaluates whether outputs are grounded in the actual workspace files and whether required deliverables were created correctly.

- **1.0**: `report.md` and `monitor.py` both exist with substantive content and correctly reference workspace files such as `config.yaml`, `.env`, and fallback JSON data.
- **0.75**: Both deliverables exist and are mostly grounded, with only minor file/path/content issues.
- **0.5**: Deliverables exist but grounding to workspace files is incomplete or inconsistent.
- **0.25**: Deliverables are thin, weakly grounded, or contain path/file hallucinations.
- **0.0**: Deliverables missing or not grounded in workspace assets.

### Report Quality and Completeness (Weight: 10%)
Evaluates the formatting, clarity, and completeness of the monitoring report.

- **1.0**: Well-structured Markdown report with all 7 stocks and key fields, plus a clear summary of anomalies and fallback/live-fetch status.
- **0.75**: Good report with only minor omissions or formatting issues.
- **0.5**: Report exists but is incomplete, hard to read, or missing important fields.
- **0.25**: Minimal or low-utility report.
- **0.0**: No report or unusable report.