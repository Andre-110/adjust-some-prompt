---
id: task_00336_moltbook_auto_post_cron_execution
name: Moltbook Auto Post Cron Job Execution
category: Workflow and Agent Orchestration
subcategory: Workflow and Task Scheduling
difficulty: medium
grading_type: hybrid
grading_weights: {automated: 0.4, llm_judge: 0.6}
timeout_seconds: 600
input_modality: text-only
external_dependency: none
workspace_files:
  - source: skills/moltbook-auto-post/.env.example
    dest: skills/moltbook-auto-post/.env.example
  - source: skills/moltbook-auto-post/config.json
    dest: skills/moltbook-auto-post/config.json
  - source: skills/moltbook-auto-post/package.json
    dest: skills/moltbook-auto-post/package.json
  - source: skills/moltbook-auto-post/post.js
    dest: skills/moltbook-auto-post/post.js
  - source: skills/moltbook-auto-post/queue.json
    dest: skills/moltbook-auto-post/queue.json
  - source: skills/moltbook-auto-post/SKILL.md
    dest: skills/moltbook-auto-post/SKILL.md
  - source: skills/moltbook-auto-post/state.json
    dest: skills/moltbook-auto-post/state.json
  - source: skills/moltbook-auto-post/templates.json
    dest: skills/moltbook-auto-post/templates.json
  - source: skills/moltbook-auto-post/test-connection.js
    dest: skills/moltbook-auto-post/test-connection.js
  - source: skills/moltbook-auto-post/utils/add-to-queue.js
    dest: skills/moltbook-auto-post/utils/add-to-queue.js
skill_creation: false
---

## Prompt

A cron job just fired and attempted to run this command:

`node skills/moltbook-auto-post/post.js`

Please inspect the Moltbook auto-post skill, make whatever minimal fixes are needed to run it in this sandbox, execute the post cycle once, and then report what happened.

Important:
- Work from the files under `skills/moltbook-auto-post/`
- If dependencies are missing or incompatible, fix them
- Verify the resulting queue and logs after execution
- Be explicit about whether the queued item was preserved or consumed

Current time: Tuesday, February 10th, 2026 — 4:06 PM (Asia/Shanghai)

## Expected Behavior

The agent should handle this cron-triggered task by inspecting the skill, resolving runtime issues, executing the script once, and accurately reporting the observed behavior from the workspace.

A strong solution should do the following:

1. **Inspect the relevant files**
   - Read at least `skills/moltbook-auto-post/post.js`, `skills/moltbook-auto-post/package.json`, `skills/moltbook-auto-post/config.json`, and `skills/moltbook-auto-post/queue.json`
   - Notice that `post.js` uses dynamic `import('node-fetch')`, so the `node-fetch` v2 CommonJS workaround is **not required** here
   - Notice that `package.json` already declares `node-fetch`, `dayjs`, and `sharp`

2. **Install dependencies if needed**
   - Run `npm install` in `skills/moltbook-auto-post/` if `node_modules` is missing
   - The agent does **not** need to rewrite the code to use `require('node-fetch')`

3. **Execute the script**
   - Run `node skills/moltbook-auto-post/post.js`
   - The script may take some time before the network call because it adds a random jitter of up to 44 seconds
   - Since external services are unavailable in the sandbox, the Moltbook API request is expected to fail

4. **Verify the actual post-failure behavior from this script**
   - On a non-rate-limit posting error, this script **consumes the first queue entry anyway** and writes the shortened queue back to `skills/moltbook-auto-post/queue.json`
   - It also records the failure in `skills/moltbook-auto-post/post.log`
   - It updates `skills/moltbook-auto-post/state.json` with a `lastError` object
   - Therefore, after one failed execution, the queue should shrink from **4 entries to 3 entries**, not remain at 4

5. **Report the outcome accurately**
   - The final response should clearly state that:
     - the script was inspected
     - dependencies were installed if necessary
     - the script was executed
     - the network/API call failed in the sandbox
     - the log captured the failure
     - the queue entry was **consumed despite the error**
     - `state.json` was updated with the error state

## Grading Criteria

- [ ] Relevant skill files were inspected to understand behavior and dependencies
- [ ] Dependencies were installed successfully if needed
- [ ] The post script was executed and produced a fresh `post.log`
- [ ] The agent correctly identified that a failed post consumes the first queue entry, leaving 3 entries
- [ ] The failure was verified via workspace evidence (`post.log` and/or `state.json`)
- [ ] The final response clearly and accurately summarizes the outcome

## Automated Checks

```python
import os
import json

def grade(transcript: list, workspace_path: str) -> dict:
    scores = {
        "dependencies_installed": 0.0,
        "script_executed": 0.0,
        "queue_behavior_verified": 0.0,
        "failure_logged": 0.0,
        "state_updated": 0.0,
    }

    skill_dir = os.path.join(workspace_path, "skills", "moltbook-auto-post")
    node_modules_path = os.path.join(skill_dir, "node_modules")
    log_path = os.path.join(skill_dir, "post.log")
    queue_path = os.path.join(skill_dir, "queue.json")
    state_path = os.path.join(skill_dir, "state.json")

    # Empty-workspace guard
    if not os.path.isdir(skill_dir):
        return scores

    # Check 1: dependencies installed
    if os.path.isdir(node_modules_path):
        scores["dependencies_installed"] = 1.0

    # Check 2: script executed -> fresh log exists and mentions cycle start
    if os.path.isfile(log_path):
        try:
            log_content = open(log_path, "r", encoding="utf-8").read().strip()
            if log_content:
                scores["script_executed"] = 0.5
                lowered = log_content.lower()
                if ("auto post cycle started" in lowered) or ("auto-post cycle started" in lowered):
                    scores["script_executed"] = 1.0
        except Exception:
            scores["script_executed"] = 0.0

    # Check 3: queue behavior after failure -> 3 items remain
    if os.path.isfile(queue_path):
        try:
            queue_data = json.loads(open(queue_path, "r", encoding="utf-8").read())
            if isinstance(queue_data, list):
                if len(queue_data) == 3:
                    scores["queue_behavior_verified"] = 1.0
                elif len(queue_data) == 4:
                    scores["queue_behavior_verified"] = 0.25
                elif len(queue_data) > 0:
                    scores["queue_behavior_verified"] = 0.5
        except Exception:
            scores["queue_behavior_verified"] = 0.0

    # Check 4: failure logged
    if os.path.isfile(log_path):
        try:
            log_content = open(log_path, "r", encoding="utf-8").read().lower()
            failure_keywords = [
                "fail", "error", "unhandled error", "fetch failed",
                "econnrefused", "enotfound", "network", "socket"
            ]
            if any(kw in log_content for kw in failure_keywords):
                scores["failure_logged"] = 1.0
            elif "started" in log_content:
                scores["failure_logged"] = 0.25
        except Exception:
            scores["failure_logged"] = 0.0

    # Check 5: state updated with lastError
    if os.path.isfile(state_path):
        try:
            state_data = json.loads(open(state_path, "r", encoding="utf-8").read())
            last_error = state_data.get("lastError")
            if isinstance(last_error, dict) and last_error.get("type"):
                scores["state_updated"] = 1.0
            elif "posts" in state_data:
                scores["state_updated"] = 0.25
        except Exception:
            scores["state_updated"] = 0.0

    return scores
```

## LLM Judge Rubric

### Workspace Investigation (Weight: 20%)
- 1.0: Agent inspected the key files (`post.js`, `package.json`, `config.json`, `queue.json`) and correctly inferred the script's real behavior from them.
- 0.75: Agent inspected most key files and understood the main runtime behavior with only minor omissions.
- 0.5: Agent inspected some relevant files but missed important implementation details.
- 0.25: Agent performed minimal inspection before acting.
- 0.0: Agent did not ground the work in the workspace.

### Dependency Resolution (Weight: 20%)
- 1.0: Agent correctly installed dependencies if needed and did not invent unnecessary code changes for `node-fetch`.
- 0.75: Agent installed dependencies successfully but used a somewhat unnecessary or clumsy approach.
- 0.5: Agent partially resolved dependencies but with notable confusion or incomplete setup.
- 0.25: Agent recognized a dependency issue but did not fix it successfully.
- 0.0: Agent did not attempt to resolve runtime dependencies.

### Execution and Verification (Weight: 30%)
- 1.0: Agent executed the script, accounted for the possible jitter delay, and verified the resulting queue, log, and/or state files after execution.
- 0.75: Agent executed the script and verified most important artifacts, missing only one minor check.
- 0.5: Agent executed the script but performed only partial verification.
- 0.25: Agent attempted execution but did not verify the consequences in the workspace.
- 0.0: Agent did not execute the script.

### Correct Interpretation of Failure Behavior (Weight: 20%)
- 1.0: Agent explicitly states that on post failure this script consumes the first queue entry, reducing the queue from 4 to 3, and supports that claim with workspace evidence.
- 0.75: Agent identifies the queue consumption behavior correctly but provides limited evidence.
- 0.5: Agent notices something changed in the queue but explains it incompletely.
- 0.25: Agent is uncertain or contradictory about whether the queue was preserved or consumed.
- 0.0: Agent incorrectly claims the queue remains intact after failure.

### Final Communication Quality (Weight: 10%)
- 1.0: Final report is clear, concise, accurate, and includes the command outcome plus the resulting log/queue/state summary.
- 0.75: Final report is mostly clear and accurate with minor omissions.
- 0.5: Final report is understandable but incomplete or somewhat vague.
- 0.25: Final report is confusing or lacks key conclusions.
- 0.0: No meaningful final summary is provided.