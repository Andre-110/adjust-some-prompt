#!/usr/bin/env node
// Quick utility to add a post to the queue from the command line
// Usage: node utils/add-to-queue.js "Post text here" --tags=tag1,tag2 --visibility=public

const fs = require('fs');
const path = require('path');

const QUEUE_PATH = path.join(__dirname, '..', 'queue.json');

function main() {
  const args = process.argv.slice(2);
  if (args.length === 0 || args[0] === '--help') {
    console.log('Usage: node add-to-queue.js "Post text" [--tags=a,b,c] [--visibility=public|followers|private]');
    process.exit(0);
  }

  const text = args[0];
  let tags = [];
  let visibility = 'public';

  for (const arg of args.slice(1)) {
    if (arg.startsWith('--tags=')) {
      tags = arg.replace('--tags=', '').split(',').map(t => t.trim());
    } else if (arg.startsWith('--visibility=')) {
      visibility = arg.replace('--visibility=', '');
    }
  }

  const queue = JSON.parse(fs.readFileSync(QUEUE_PATH, 'utf8'));
  queue.push({
    text,
    media: [],
    tags,
    visibility,
    scheduledFor: null,
    addedAt: new Date().toISOString(),
  });

  fs.writeFileSync(QUEUE_PATH, JSON.stringify(queue, null, 2) + '\n');
  console.log(`Added to queue (position ${queue.length}): "${text.substring(0, 50)}..."`);
}

main();
