#!/usr/bin/env node
// Test connection to Moltbook API and verify credentials
// Usage: node test-connection.js

const fs = require('fs');
const path = require('path');

const CONFIG_PATH = path.join(__dirname, 'config.json');

async function main() {
  const config = JSON.parse(fs.readFileSync(CONFIG_PATH, 'utf8'));
  const fetch = (await import('node-fetch')).default;

  console.log(`Testing connection to ${config.apiBase}...`);

  // Verify credentials
  const resp = await fetch(`${config.apiBase}/api/v1/accounts/verify_credentials`, {
    headers: { Authorization: `Bearer ${config.accessToken}` },
  });

  if (!resp.ok) {
    console.error(`Auth failed (${resp.status}): ${await resp.text()}`);
    process.exit(1);
  }

  const account = await resp.json();
  console.log(`Authenticated as: @${account.username} (${account.display_name})`);
  console.log(`Followers: ${account.followers_count} | Following: ${account.following_count}`);
  console.log(`Posts: ${account.statuses_count}`);
  console.log('\nConnection test passed.');
}

main().catch(err => {
  console.error(`Error: ${err.message}`);
  process.exit(1);
});
