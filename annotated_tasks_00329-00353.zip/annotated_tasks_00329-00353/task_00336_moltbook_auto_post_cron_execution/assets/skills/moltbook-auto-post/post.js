#!/usr/bin/env node
// Moltbook Auto Post — post.js
// Reads from queue or generates content, posts to Moltbook API
// Respects rate limits tracked in state.json

const fs = require('fs');
const path = require('path');

const SKILL_DIR = __dirname;
const CONFIG_PATH = path.join(SKILL_DIR, 'config.json');
const QUEUE_PATH = path.join(SKILL_DIR, 'queue.json');
const STATE_PATH = path.join(SKILL_DIR, 'state.json');
const LOG_PATH = path.join(SKILL_DIR, 'post.log');

// ── helpers ──────────────────────────────────────────────────────────────────

function log(level, msg) {
  const ts = new Date().toISOString();
  const line = `[${ts}] [${level.toUpperCase()}] ${msg}\n`;
  fs.appendFileSync(LOG_PATH, line);
  if (level === 'error') console.error(line.trim());
  else console.log(line.trim());
}

function loadJSON(fp, fallback) {
  try {
    return JSON.parse(fs.readFileSync(fp, 'utf8'));
  } catch {
    return fallback;
  }
}

function saveJSON(fp, data) {
  fs.writeFileSync(fp, JSON.stringify(data, null, 2) + '\n');
}

// ── rate-limit check ─────────────────────────────────────────────────────────

function withinLimits(state, limits) {
  const now = Date.now();
  const oneHour = 60 * 60 * 1000;
  const oneDay = 24 * oneHour;

  const recentHour = (state.posts || []).filter(p => now - p.ts < oneHour).length;
  const recentDay = (state.posts || []).filter(p => now - p.ts < oneDay).length;

  if (recentHour >= (limits.perHour || 5)) {
    log('warn', `Rate limit: ${recentHour} posts in last hour (max ${limits.perHour || 5})`);
    return false;
  }
  if (recentDay >= (limits.perDay || 30)) {
    log('warn', `Rate limit: ${recentDay} posts in last day (max ${limits.perDay || 30})`);
    return false;
  }
  return true;
}

// ── post to Moltbook API ─────────────────────────────────────────────────────

async function postToMoltbook(config, entry) {
  const fetch = (await import('node-fetch')).default;

  const body = {
    status: entry.text,
    visibility: entry.visibility || config.defaultVisibility || 'public',
  };

  if (entry.tags && entry.tags.length > 0) {
    // Append hashtags if not already in text
    const tagStr = entry.tags
      .filter(t => !entry.text.includes(`#${t}`))
      .map(t => `#${t}`)
      .join(' ');
    if (tagStr) body.status += '\n\n' + tagStr;
  }

  // Handle media uploads first
  const mediaIds = [];
  if (entry.media && entry.media.length > 0) {
    for (const mediaPath of entry.media) {
      const fullPath = path.resolve(SKILL_DIR, mediaPath);
      if (!fs.existsSync(fullPath)) {
        log('warn', `Media file not found: ${fullPath}, skipping`);
        continue;
      }

      const FormData = (await import('node-fetch')).FormData;
      const formData = new FormData();
      formData.append('file', fs.createReadStream(fullPath));
      formData.append('description', '');

      const mediaResp = await fetch(`${config.apiBase}/api/v1/media`, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${config.accessToken}`,
        },
        body: formData,
      });

      if (!mediaResp.ok) {
        log('error', `Media upload failed (${mediaResp.status}): ${await mediaResp.text()}`);
        continue;
      }

      const mediaData = await mediaResp.json();
      mediaIds.push(mediaData.id);
    }
    if (mediaIds.length > 0) body.media_ids = mediaIds;
  }

  // Post the status
  const resp = await fetch(`${config.apiBase}/api/v1/statuses`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${config.accessToken}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(body),
  });

  if (resp.status === 429) {
    const retryAfter = resp.headers.get('retry-after') || '300';
    log('warn', `API rate limited (429). Retry-After: ${retryAfter}s`);
    return { ok: false, rateLimited: true, retryAfter: parseInt(retryAfter) };
  }

  if (!resp.ok) {
    const errBody = await resp.text();
    log('error', `Post failed (${resp.status}): ${errBody}`);
    return { ok: false, status: resp.status, error: errBody };
  }

  const result = await resp.json();
  log('info', `Posted successfully: id=${result.id}, url=${result.url || 'N/A'}`);
  return { ok: true, id: result.id, url: result.url };
}

// ── main ─────────────────────────────────────────────────────────────────────

async function main() {
  log('info', '── Auto post cycle started ──');

  // Load config
  const config = loadJSON(CONFIG_PATH, null);
  if (!config) {
    log('error', 'Missing or invalid config.json');
    process.exit(1);
  }

  if (!config.accessToken || !config.apiBase) {
    log('error', 'config.json missing required fields: apiBase, accessToken');
    process.exit(1);
  }

  // Load state
  const state = loadJSON(STATE_PATH, { posts: [], lastError: null });

  // Rate limit check
  if (!withinLimits(state, config.rateLimits || {})) {
    log('info', 'Skipping post cycle — rate limit reached');
    return;
  }

  // Load queue
  const queue = loadJSON(QUEUE_PATH, []);
  if (queue.length === 0) {
    log('info', 'Queue is empty — nothing to post');
    return;
  }

  // Take first entry
  const entry = queue.shift();
  log('info', `Posting queued entry: "${entry.text.substring(0, 60)}..."`);

  // Add organic jitter (0-45 seconds)
  const jitter = Math.floor(Math.random() * 45) * 1000;
  if (jitter > 0) {
    log('info', `Adding ${Math.round(jitter / 1000)}s jitter for organic timing`);
    await new Promise(r => setTimeout(r, jitter));
  }

  // Post
  const result = await postToMoltbook(config, entry);

  if (result.ok) {
    // Update state
    state.posts.push({ ts: Date.now(), id: result.id });
    state.lastError = null;

    // Prune old entries (keep 48h)
    const cutoff = Date.now() - 48 * 60 * 60 * 1000;
    state.posts = state.posts.filter(p => p.ts > cutoff);

    saveJSON(STATE_PATH, state);
    saveJSON(QUEUE_PATH, queue);
    log('info', `Queue remaining: ${queue.length} entries`);
  } else if (result.rateLimited) {
    // Put entry back at front of queue
    queue.unshift(entry);
    saveJSON(QUEUE_PATH, queue);
    state.lastError = { type: 'rate_limit', ts: Date.now(), retryAfter: result.retryAfter };
    saveJSON(STATE_PATH, state);
  } else {
    // Other error — log but consume the entry to avoid infinite retries
    state.lastError = { type: 'post_error', ts: Date.now(), status: result.status, error: result.error };
    saveJSON(STATE_PATH, state);
    saveJSON(QUEUE_PATH, queue);
    log('error', `Entry consumed despite error to avoid retry loop`);
  }

  log('info', '── Auto post cycle finished ──');
}

main().catch(err => {
  log('error', `Unhandled error: ${err.message}`);
  process.exit(1);
});
