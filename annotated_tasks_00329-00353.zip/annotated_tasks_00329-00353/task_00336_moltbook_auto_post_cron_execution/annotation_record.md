| 序号 | 修改项 | 修改原因 |
|------|--------|----------|
| 1 | 将 frontmatter 中 `workspace_files` 从旧字段 `path` 改为规范的 `dest` 列表，并补全实际存在的关键 assets | 原文不符合新版数据规范；且 frontmatter 只内联了少量文件，与实际 Assets 目录不一致 |
| 2 | 将 difficulty 从 `easy` 调整为 `medium` | 任务要求检查代码、处理 npm 依赖、执行脚本并验证运行后状态，复杂度高于 easy |
| 3 | 重写 Prompt | 原 Prompt 仅给出 cron 命令，过于简陋，且未明确需要检查运行结果；新 Prompt 更清晰且更像真实运维请求 |
| 4 | 重写 Expected Behavior | 原 Expected Behavior 与实际脚本/Assets 严重不符：错误声称需要 `node-fetch@2`、错误声称失败后队列保持 4 条；实际脚本使用动态 import，失败时会消费队列首项 |
| 5 | 修正对 `node-fetch` 的描述 | 实际 `post.js` 使用 `await import('node-fetch')`，无需因 CommonJS 改写到 v2；原文属于错误引导 |
| 6 | 修正队列行为说明为“失败后从 4 条变为 3 条” | 与 `post.js` 实际逻辑一致：非 rate-limit 错误会 `queue.shift()` 后保存 |
| 7 | 增加对 `state.json` 更新的期望说明 | 实际脚本失败时会写入 `lastError`，这是关键可验证行为，原文遗漏 |
| 8 | 重写 Grading Criteria | 原 criteria 建立在错误 ground truth（队列保持 4 条）上，且覆盖不完整 |
| 9 | 重写 `grade()` | 原评分函数与实际任务不符：错误检查 `node-fetch` v2 目录、错误检查队列保留 4 条、未检查 `state.json` 更新；同时增加空白场景全 0 防护 |
| 10 | 保持 automated/llm_judge 权重为 0.4/0.6，不做改动 | 两者之和为 1.0，符合规范 |
| 11 | 重写 LLM Judge Rubric | 原 rubric 中依赖错误前提（如必须处理 node-fetch v2、队列必须保留），需与真实代码行为对齐 |
| 12 | 删除初始 Assets 中的 `skills/moltbook-auto-post/post.log` | 该文件是运行产物，预置会干扰“是否执行脚本”的判定，降低评测有效性 |
| 13 | 脱敏 `.env.example` 中的 access token | 原内容包含看似真实敏感凭据，不符合“无敏感信息”要求 |
| 14 | 脱敏 `config.json` 中的 access token 和 userId | 同上，避免伪真实敏感数据残留在环境文件中 |
| 15 | 保留 `SKILL.md` 路径为 `skills/moltbook-auto-post/SKILL.md` 并确保文档整体引用规范 | 符合 OpenClaw skill 路径规范 |