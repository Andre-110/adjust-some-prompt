# Streamer Management Data Project

## Overview
Internal data management system for tracking streamers, contracts, and platform metrics.

## Directory Structure
```
data/              - All data files (CSV, JSON)
schemas/           - Data schema definitions
scripts/           - Utility and validation scripts
```

## Data Files

| File | Description |
|------|-------------|
| `data/streamers.csv` | Core streamer profiles and streaming metrics |
| `data/main_form.csv` | Contract and business relationship details |
| `data/platform_stats.json` | Daily platform-level aggregated stats |
| `data/categories.json` | Content category definitions and rules |

## Schema
See `schemas/data_schema.json` for complete field definitions and validation rules.

## Validation
Run `python3 scripts/validate_data.py` to check data completeness against the schema.

## Known Issues
- [ ] Fan count data not yet integrated into streamers table
- [ ] Several main_form records have incomplete fields (pending contracts)
- [ ] Platform stats fan count sync pending API integration
