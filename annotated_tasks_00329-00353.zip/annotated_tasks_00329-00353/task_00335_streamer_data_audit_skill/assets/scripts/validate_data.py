#!/usr/bin/env python3
"""
Data validation script for streamer management project.
Checks both streamers.csv and main_form.csv for completeness and consistency.
"""

import csv
import json
import sys
from pathlib import Path

DATA_DIR = Path(__file__).parent.parent / "data"
SCHEMA_PATH = Path(__file__).parent.parent / "schemas" / "data_schema.json"


def load_schema():
    with open(SCHEMA_PATH) as f:
        return json.load(f)


def validate_streamers(schema):
    issues = []
    required_fields = [
        k for k, v in schema["tables"]["streamers"]["fields"].items()
        if v.get("required", False)
    ]

    with open(DATA_DIR / "streamers.csv") as f:
        reader = csv.DictReader(f)
        headers = reader.fieldnames or []

        # Check missing columns
        for field in required_fields:
            if field not in headers:
                issues.append(f"[streamers] Missing required column: {field}")

        # Check row completeness
        for i, row in enumerate(reader, start=2):
            for field in required_fields:
                if field in row and not row[field].strip():
                    issues.append(f"[streamers] Row {i}: Empty required field '{field}'")

    return issues


def validate_main_form(schema):
    issues = []
    required_fields = [
        k for k, v in schema["tables"]["main_form"]["fields"].items()
        if v.get("required", False)
    ]

    with open(DATA_DIR / "main_form.csv") as f:
        reader = csv.DictReader(f)
        headers = reader.fieldnames or []

        for field in required_fields:
            if field not in headers:
                issues.append(f"[main_form] Missing required column: {field}")

        for i, row in enumerate(reader, start=2):
            for field in required_fields:
                if field in row and not row[field].strip():
                    issues.append(f"[main_form] Row {i} (ID={row.get('streamer_id','?')}): Empty required field '{field}'")

    return issues


def main():
    schema = load_schema()
    all_issues = []
    all_issues.extend(validate_streamers(schema))
    all_issues.extend(validate_main_form(schema))

    if all_issues:
        print(f"Found {len(all_issues)} data issue(s):\n")
        for issue in all_issues:
            print(f"  ⚠️  {issue}")
        sys.exit(1)
    else:
        print("✅ All data validated successfully.")
        sys.exit(0)


if __name__ == "__main__":
    main()
