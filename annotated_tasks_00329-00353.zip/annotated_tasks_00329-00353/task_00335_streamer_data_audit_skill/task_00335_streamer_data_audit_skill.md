---
id: task_00335_streamer_data_audit_skill
name: Streamer Data Audit and Completion Skill
category: Data Analysis and Modeling
subcategory: Data Processing and Management
difficulty: medium
grading_type: hybrid
grading_weights: {automated: 0.4, llm_judge: 0.6}
timeout_seconds: 600
input_modality: text-only
external_dependency: none
skill_creation: true
workspace_files:
  - source: README.md
    dest: README.md
  - source: data/streamers.csv
    dest: data/streamers.csv
  - source: data/main_form.csv
    dest: data/main_form.csv
  - source: data/platform_stats.json
    dest: data/platform_stats.json
  - source: data/categories.json
    dest: data/categories.json
  - source: schemas/data_schema.json
    dest: schemas/data_schema.json
  - source: scripts/validate_data.py
    dest: scripts/validate_data.py
---

## Prompt

I need a reusable skill for auditing tabular datasets against a schema and generating a structured gap analysis report.

Please do two things:

1. Create a reusable skill at `skills/data-audit/SKILL.md` that explains how to:
   - compare CSV files against a schema definition,
   - detect missing required columns,
   - detect missing required cell values,
   - summarize completeness by table,
   - and document any repair steps or unresolved gaps.

2. Use that skill on the files in this workspace and produce:
   - `audit_report.json`
   - `streamers_fixed.csv`

Use these workspace files:
- `schemas/data_schema.json`
- `data/streamers.csv`
- `data/main_form.csv`
- `data/platform_stats.json`

Requirements:
- Audit both tables defined in the schema.
- In `data/streamers.csv`, identify that the required `fans_count` column is missing.
- In `data/main_form.csv`, identify missing required cell values by row and field.
- Include completeness percentages for each table in `audit_report.json`.
- Create `streamers_fixed.csv` by adding the missing `fans_count` column to the streamers data and filling it from `data/platform_stats.json`.
- Preserve the original rows and existing columns from `data/streamers.csv`.

You may also consult `README.md` and `scripts/validate_data.py` if helpful, but your outputs should be based on the actual schema and data files in the workspace.

## Expected Behavior

The agent should:

1. **Create a reusable skill file** at `skills/data-audit/SKILL.md` with:
   - YAML frontmatter including at least `name` and `description`
   - clear procedural guidance for schema-vs-data auditing
   - instructions for reporting missing required columns, missing required values, completeness metrics, and data repair notes

2. **Read and analyze**:
   - `schemas/data_schema.json`
   - `data/streamers.csv`
   - `data/main_form.csv`
   - `data/platform_stats.json`

3. **Correctly identify the key data issues**:
   - In `data/streamers.csv`, the required column `fans_count` is missing entirely.
   - In `data/main_form.csv`, required fields contain empty values in multiple rows. The required missing cells are:

   For `S002`:
   - `contact_person`
   - `contact_phone`
   - `bank_account`
   - `brand_tier`

   For `S003`:
   - `monthly_rate_cny`
   - `commission_pct`
   - `bank_account`
   - `payment_method`
   - `contract_start`
   - `contract_end`
   - `brand_tier`
   - `content_rating`

   For `S004`:
   - `content_rating`

   For `S005`:
   - `monthly_rate_cny`
   - `contact_phone`
   - `contract_end`

   For `S006`:
   - `monthly_rate_cny`
   - `commission_pct`
   - `contact_person`
   - `contact_phone`
   - `bank_account`
   - `payment_method`
   - `contract_start`
   - `contract_end`
   - `brand_tier`
   - `content_rating`

   For `S008`:
   - `monthly_rate_cny`
   - `commission_pct`
   - `bank_account`
   - `payment_method`
   - `contract_start`
   - `contract_end`
   - `brand_tier`

   For `S009`:
   - `monthly_rate_cny`
   - `commission_pct`
   - `contact_person`
   - `contact_phone`
   - `bank_account`
   - `payment_method`
   - `contract_start`
   - `contract_end`
   - `brand_tier`
   - `content_rating`

   For `S010`:
   - `contact_phone`
   - `payment_method`
   - `content_rating`

   For `S011`:
   - `monthly_rate_cny`
   - `commission_pct`
   - `bank_account`
   - `payment_method`
   - `contract_start`
   - `contract_end`
   - `brand_tier`

   For `S012`:
   - `contact_person`
   - `contact_phone`
   - `bank_account`
   - `payment_method`
   - `contract_start`
   - `contract_end`
   - `content_rating`

   For `S013`:
   - `brand_tier`

   For `S014`:
   - `monthly_rate_cny`
   - `commission_pct`
   - `contact_person`
   - `contact_phone`
   - `bank_account`
   - `payment_method`
   - `contract_start`
   - `contract_end`
   - `brand_tier`
   - `content_rating`

4. **Produce `audit_report.json`** as valid JSON with content equivalent to:
   - missing required columns per table
   - missing required cells per table, with row identification (row number and/or `streamer_id`)
   - completeness metrics per table

   Ground-truth completeness values:
   - `streamers`: required-column completeness is incomplete because `fans_count` is missing; at minimum the report should clearly mark 1 missing required column out of 15 required fields.
   - `main_form`: all required columns are present, but many required cells are empty. There are 15 rows × 12 required fields = 180 required cells total, of which 111 are filled and 69 are missing, so completeness should be about **61.7%** for required cells.

   Any reasonable JSON structure is acceptable if it is accurate and explicit.

5. **Produce `streamers_fixed.csv`** by adding a `fans_count` column and filling these values from `data/platform_stats.json`:
   - `S001` → `186000`
   - `S002` → `143000`
   - `S003` → `52000`
   - `S004` → `231000`
   - `S005` → `318000`
   - `S006` → `27000`
   - `S007` → `402000`
   - `S008` → `97000`
   - `S009` → `35000`
   - `S010` → `256000`
   - `S011` → `61000`
   - `S012` → `88000`
   - `S013` → `126000`
   - `S014` → `19000`
   - `S015` → `345000`

6. The agent should preserve the existing rows and values from `data/streamers.csv`, only adding the `fans_count` column.

## Grading Criteria

- [ ] `skills/data-audit/SKILL.md` exists and includes YAML frontmatter with `name` and `description`
- [ ] The skill contains reusable instructions for schema-based data auditing
- [ ] `audit_report.json` exists and is valid JSON
- [ ] `audit_report.json` identifies `fans_count` as a missing required column in the streamers table
- [ ] `audit_report.json` reports missing required cell values in `main_form`
- [ ] `audit_report.json` includes explicit completeness metrics
- [ ] `streamers_fixed.csv` exists and contains a `fans_count` column
- [ ] `streamers_fixed.csv` contains the correct fan count values for all 15 streamers
- [ ] Outputs are grounded in the actual workspace file paths and schema

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    import json
    import csv
    from pathlib import Path

    ws = Path(workspace_path)
    scores = {
        "skill_md_exists": 0.0,
        "audit_report_valid": 0.0,
        "audit_report_content": 0.0,
        "streamers_fixed_csv": 0.0,
        "fans_count_values": 0.0,
    }

    skill_path = ws / "skills" / "data-audit" / "SKILL.md"
    report_path = ws / "audit_report.json"
    fixed_path = ws / "streamers_fixed.csv"

    if not skill_path.exists() and not report_path.exists() and not fixed_path.exists():
        return scores

    # 1. SKILL.md
    if skill_path.exists():
        content = skill_path.read_text(encoding="utf-8", errors="replace")
        has_frontmatter = content.strip().startswith("---")
        head = content[:800].lower()
        has_name = "name:" in head
        has_description = "description:" in head
        body = content.split("---", 2)
        has_body = len(body) >= 3 and len(body[2].strip()) > 120
        has_audit_terms = all(term in content.lower() for term in [
            "schema", "missing", "column", "completeness"
        ])
        if has_frontmatter and has_name and has_description and has_body and has_audit_terms:
            scores["skill_md_exists"] = 1.0
        elif has_frontmatter and has_body:
            scores["skill_md_exists"] = 0.6
        else:
            scores["skill_md_exists"] = 0.3

    # 2. audit_report.json valid
    report_data = None
    if report_path.exists():
        try:
            report_data = json.loads(report_path.read_text(encoding="utf-8", errors="replace"))
            if isinstance(report_data, dict):
                scores["audit_report_valid"] = 1.0
            else:
                scores["audit_report_valid"] = 0.4
        except Exception:
            scores["audit_report_valid"] = 0.0

    # 3. audit_report.json content
    if isinstance(report_data, dict):
        report_str = json.dumps(report_data, ensure_ascii=False).lower()
        content_score = 0.0

        if "fans_count" in report_str and "streamers" in report_str:
            content_score += 0.35

        missing_keywords = [
            "monthly_rate_cny", "commission_pct", "contact_person", "contact_phone",
            "bank_account", "payment_method", "contract_start", "contract_end",
            "brand_tier", "content_rating"
        ]
        found_missing = sum(1 for kw in missing_keywords if kw in report_str)
        if found_missing >= 8:
            content_score += 0.35
        elif found_missing >= 5:
            content_score += 0.2
        elif found_missing >= 2:
            content_score += 0.1

        if any(k in report_str for k in ["completeness", "percent", "%", "filled", "missing_required_cells"]):
            content_score += 0.3

        scores["audit_report_content"] = min(content_score, 1.0)

    # 4. streamers_fixed.csv structure and content
    expected_fans = {
        "S001": 186000,
        "S002": 143000,
        "S003": 52000,
        "S004": 231000,
        "S005": 318000,
        "S006": 27000,
        "S007": 402000,
        "S008": 97000,
        "S009": 35000,
        "S010": 256000,
        "S011": 61000,
        "S012": 88000,
        "S013": 126000,
        "S014": 19000,
        "S015": 345000,
    }

    if fixed_path.exists():
        try:
            with open(fixed_path, "r", encoding="utf-8", errors="replace") as f:
                reader = csv.DictReader(f)
                fieldnames = reader.fieldnames or []
                rows = list(reader)

            if "fans_count" in fieldnames:
                scores["streamers_fixed_csv"] = 1.0
            elif any("fan" in (fn or "").lower() for fn in fieldnames):
                scores["streamers_fixed_csv"] = 0.5
            else:
                scores["streamers_fixed_csv"] = 0.2

            if "fans_count" in fieldnames and len(rows) >= 15:
                correct = 0
                for row in rows:
                    sid = (row.get("streamer_id") or "").strip()
                    fc = (row.get("fans_count") or "").strip().replace(",", "")
                    if sid in expected_fans:
                        try:
                            if int(fc) == expected_fans[sid]:
                                correct += 1
                        except Exception:
                            pass
                scores["fans_count_values"] = correct / 15.0
        except Exception:
            scores["streamers_fixed_csv"] = 0.1
            scores["fans_count_values"] = 0.0

    return scores
```

## LLM Judge Rubric

### Skill Definition Quality (Weight: 20%)
- 1.0: `skills/data-audit/SKILL.md` is well-structured, includes YAML frontmatter (`name`, `description`), and gives clear reusable instructions for schema-based auditing and reporting
- 0.75: Skill file is solid and mostly reusable but misses some clarity or detail
- 0.5: Skill file exists but is minimal or only partially reusable
- 0.25: A partial or poorly formed skill file exists
- 0.0: No relevant skill file exists

### Audit Report Accuracy (Weight: 35%)
- 1.0: `audit_report.json` correctly identifies the missing `fans_count` column, accurately reports the required missing cells in `main_form`, and includes reasonable completeness metrics grounded in the schema and data
- 0.75: Report captures most major issues with only minor omissions
- 0.5: Report identifies the main issues but is incomplete or somewhat inaccurate
- 0.25: Report exists but misses major required issues
- 0.0: No valid, grounded audit report exists

### Data Repair Quality (Weight: 25%)
- 1.0: `streamers_fixed.csv` preserves the original streamers data and correctly adds `fans_count` for all 15 streamers using `data/platform_stats.json`
- 0.75: Most fan counts are correct, with only minor mistakes
- 0.5: File exists and includes the new column, but several values are wrong or missing
- 0.25: File exists but the repair is mostly incorrect
- 0.0: No usable repaired streamers file exists

### Workspace Grounding and Evidence (Weight: 20%)
- 1.0: Outputs are clearly grounded in `schemas/data_schema.json`, `data/streamers.csv`, `data/main_form.csv`, and `data/platform_stats.json`, with specific references to actual rows/fields
- 0.75: Outputs are mostly grounded, with minor unsupported claims
- 0.5: Some grounding is evident, but parts are generic or weakly supported
- 0.25: Minimal evidence of using the actual workspace files
- 0.0: Outputs ignore the workspace files or are hallucinated