| 序号 | 修改项 | 修改原因 |
|------|--------|----------|
| 1 | 将 frontmatter 中 `workspace_files` 从旧字段 `path:` 改为 `source`/`dest` 映射 | 符合新版数据规范，且与实际 Assets 目录结构一致 |
| 2 | 删除 frontmatter 中内联的虚构数据文件定义，改为引用真实 Assets | 原内联内容与实际资产完全不一致，导致题目不可执行 |
| 3 | 修正 Prompt 中文件路径为 `schemas/data_schema.json`、`data/streamers.csv`、`data/main_form.csv`、`data/platform_stats.json` | 原 Prompt 路径与实际 workspace 不一致 |
| 4 | 将技能输出路径从根目录 `SKILL.md` 改为 `skills/data-audit/SKILL.md` | 符合 OpenClaw skill 路径规范 |
| 5 | 重写 Expected Behavior，使其基于真实 `main_form.csv` 缺失情况 | 原 Expected Behavior 对应的是另一套数据，Ground Truth 错误 |
| 6 | 更新 Expected Behavior 中 completeness 的 Ground Truth（main_form 约 61.7%） | 使其可验证并与真实数据一致 |
| 7 | 扩展 `streamers_fixed.csv` 的 Ground Truth 为 15 个 streamer | 真实数据有 15 行，不是原题中的 5 行 |
| 8 | 重写 automated checks，使其检查 `skills/data-audit/SKILL.md` | 原检查路径不规范，且与任务目标不一致 |
| 9 | 重写 automated checks 的 fan count 校验逻辑为 15 个 streamer | 原校验值基于错误数据集 |
| 10 | 调整 Grading Criteria，使其覆盖路径规范、workspace grounding 和真实 schema/data | 提高可评分性与一致性 |
| 11 | 修订 LLM Judge Rubric 中的路径和 grounding 描述 | 与修正后的任务和 workspace 一致 |
| 12 | 修改 `data/platform_stats.json`，加入 `streamer_fans_count` 映射 | 原 assets 无法支持“回填 fans_count”这一核心任务 |
| 13 | 建议更新 README 对 `platform_stats.json` 的说明 | 提升跨文件一致性 |
| 14 | 建议将 `data/streamers.csv` 中邮箱统一替换为 `@example.com` | 进一步降低敏感信息风险，符合规范 |