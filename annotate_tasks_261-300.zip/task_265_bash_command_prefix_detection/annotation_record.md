| 序号 | 修改项 | 修改原因 |
|---|---|---|
| 1  | grade() 添加空 transcript 前置检查，所有 score key 返回 0.0                                     | 原代码在无助手回复时 `not_false_positive_injection` 和 `not_incorrect_none` 返回 1.0，违反"空白零分"要求  |
| 2  | grade() 中 `not_none_answer` 增加 "answer is none"、"answer: none"、`return.*none` 等匹配模式 | 原代码只检查 `response == "none"` 和 "prefix is/: none" 两种模式，当回复为 "The answer is none" 时漏判 |
| 3  | grade() 中 `correct_prefix` 增加 `result_is_cd` 和 `is_cd_pattern` 两种正则匹配               | 放宽格式容忍，接受 "the result is cd"、"it is cd" 等合理表述变体                                     |
| 4  | Expected Behavior 补充显式 Ground Truth 行                                               | 原文虽在步骤中提到返回 "cd"，但缺少单独的 Ground Truth 标记，不够醒目                                        |