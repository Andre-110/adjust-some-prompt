---
id: task_297_update_agent_soul_configuration_file
name: Update Agent Soul Configuration File
category: Knowledge Management
subcategory: Agent and Tool Integration
difficulty: easy
external_dependency: none
verification_method: unit-test
input_modality: text-only
grading_type: automated
timeout_seconds: 60
workspace_files: []
source_line_number: 5584
source_query: "按以下内容更新 soul.md（用所给内容覆盖/更新文件）：  # Agent Soul # 智慧能源行业市场助理  ## 1. 核心性格 - 专业稳重：符合能源、电力、工控、B端行业调性，不浮夸、不轻率 - 严谨细致：对政策、数据、客户信息、项目信息高度敏感，确保准确 - 结果导向：所有工作围绕线索挖掘、商机转化、支持签单展开 - 敏锐警觉：对政策变化、行业动向、竞品动作保持敏感  ## 2. 思维模式 1. 政策优先思维：先看政策 → 再看客户需求 → 再看竞品 → 最后落地市场动作 2. B端大客户思维：理解决策链长、重合规、重稳定、重安全、重降本增效；所有输出围绕：稳定、可靠、成熟、合规、价值可量化 3. 对比思维：始终清晰：客户痛点是什么、我们能解决什么、竞品差异在哪、如何形成优势 4. 落地思维：不输出空泛分析，只给：明确结论、可靠依据、可直接使用的内容与建议  ## 3. 沟通与表达风格 - 正式、商务、克制，适配能源/电力/电厂客户沟通语境 - 逻辑清晰：先结论 → 再依据 → 后建议 - 语言精炼：专业但不堆砌术语，易懂且有说服力 - 结构规整：自动分点、分章节..."
---

## Prompt

Please update the file `soul.md` in the workspace using the exact markdown content below.

Requirements:
- If `soul.md` already exists, overwrite it completely.
- If `soul.md` does not exist, create it.
- Preserve the markdown structure exactly as provided.
- Do not add explanations, comments, or extra sections.
- Write only the content below into `soul.md`.

```markdown
# Agent Soul
# Smart Energy Industry Market Assistant

## 1. Core Personality
- Professional and steady: Fits the tone of energy, power, industrial control, and B2B industries—no exaggeration, no recklessness
- Rigorous and meticulous: Highly sensitive to policies, data, customer information, and project details—ensure accuracy
- Results-oriented: All work centers on lead mining, opportunity conversion, and supporting deal closure
- Alert and perceptive: Stay sensitive to policy changes, industry trends, and competitor moves

## 2. Thinking Patterns
1. Policy-first thinking: First look at policies → then customer needs → then competitors → finally implement market actions
2. Enterprise customer thinking: Understand long decision chains, compliance focus, stability focus, security focus, cost reduction and efficiency improvement; all outputs revolve around: stability, reliability, maturity, compliance, quantifiable value
3. Comparative thinking: Always be clear about: what are customer pain points, what can we solve, where are competitor differences, how to form advantages
4. Implementation thinking: No vague analysis, only provide: clear conclusions, reliable evidence, directly usable content and suggestions

## 3. Communication and Expression Style
- Formal, business-like, restrained—suitable for energy/power/plant customer communication contexts
- Logical and clear: conclusion first → then evidence → then suggestions
- Concise language: professional but not jargon-heavy, understandable and persuasive
- Well-structured: automatically use bullet points and sections for easy reading and reuse

## 4. Value Principles
- Core goal is to help the company win energy, power plant, and smart park projects
- Bottom line is reliability, professionalism, and actionability
- Think from the perspective of frontline marketing and sales
- Only do work that truly improves efficiency and reduces workload
````

## Expected Behavior

The agent should:

1. Create `soul.md` if it does not already exist, or overwrite it if it does exist.
2. Write the provided markdown content into `soul.md` with no added or omitted sections.
3. Preserve the markdown structure, including:

   * the two top-level `#` headings,
   * the four `##` section headings,
   * the bullet points under sections 1, 3, and 4,
   * the numbered list under section 2.
4. Ensure the content matches the provided text closely enough that key headings and core phrases are preserved exactly.
5. Not create unrelated files or include fabricated sections such as a fifth section, appendix, notes, or commentary.

Ground truth:

* The correct output artifact is a file named `soul.md`.
* The file should contain exactly the provided markdown content and no additional content.
* The task is a straightforward file overwrite/create task; no summarization, translation, or rewriting is needed.

Key trap to handle correctly:

* The agent should update the workspace file itself, not merely restate the content in the final message.
* The agent should not paraphrase or “improve” the text.
* The agent should preserve both top-level headings exactly as given, even though the markdown style is unusual.

Tested capabilities: file creation/overwriting, precise content writing, instruction following, markdown preservation.

## Grading Criteria

* [ ] File `soul.md` exists in the workspace
* [ ] File contains both top-level headings: `# Agent Soul` and `# Smart Energy Industry Market Assistant`
* [ ] File contains all 4 required `##` sections
* [ ] File preserves the four core personality bullets
* [ ] File preserves the four thinking patterns
* [ ] File preserves the communication style bullets and value principles bullets
* [ ] File does not introduce fabricated extra sections or commentary
* [ ] File content reflects overwrite/create behavior rather than a paraphrased rewrite

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    from pathlib import Path

    score_keys = [
        "file_exists",
        "has_top_level_headings",
        "has_all_sections",
        "has_personality_traits",
        "has_thinking_patterns",
        "has_other_key_bullets",
        "no_fabricated_sections",
        "no_paraphrased_rewrite",
    ]

    def zero_scores():
        return {k: 0.0 for k in score_keys}

    ws = Path(workspace_path)
    soul_file = ws / "soul.md"

    if not soul_file.exists():
        return zero_scores()

    scores = zero_scores()
    scores["file_exists"] = 1.0

    try:
        content = soul_file.read_text(encoding="utf-8")
    except Exception:
        try:
            content = soul_file.read_text()
        except Exception:
            return scores

    content_lower = content.lower()

    # Check exact required top-level headings with reasonable tolerance for spacing/case
    has_heading_1 = "# agent soul" in content_lower
    has_heading_2 = "# smart energy industry market assistant" in content_lower
    scores["has_top_level_headings"] = 1.0 if (has_heading_1 and has_heading_2) else 0.5 if (has_heading_1 or has_heading_2) else 0.0

    section_markers = [
        "## 1. core personality",
        "## 2. thinking patterns",
        "## 3. communication and expression style",
        "## 4. value principles",
    ]
    found_sections = sum(1 for s in section_markers if s in content_lower)
    scores["has_all_sections"] = found_sections / 4.0

    personality_traits = [
        "professional and steady",
        "rigorous and meticulous",
        "results-oriented",
        "alert and perceptive",
    ]
    found_traits = sum(1 for t in personality_traits if t in content_lower)
    scores["has_personality_traits"] = found_traits / 4.0

    thinking_patterns = [
        "policy-first thinking",
        "enterprise customer thinking",
        "comparative thinking",
        "implementation thinking",
    ]
    found_patterns = sum(1 for p in thinking_patterns if p in content_lower)
    scores["has_thinking_patterns"] = found_patterns / 4.0

    other_key_bullets = [
        "formal, business-like, restrained",
        "logical and clear: conclusion first",
        "concise language: professional but not jargon-heavy",
        "well-structured: automatically use bullet points and sections for easy reading and reuse",
        "core goal is to help the company win energy, power plant, and smart park projects",
        "bottom line is reliability, professionalism, and actionability",
        "think from the perspective of frontline marketing and sales",
        "only do work that truly improves efficiency and reduces workload",
    ]
    found_other_bullets = sum(1 for b in other_key_bullets if b in content_lower)
    scores["has_other_key_bullets"] = found_other_bullets / 8.0

    fabricated_indicators = [
        "## 5.",
        "## 6.",
        "# appendix",
        "appendix",
        "additional notes",
        "notes:",
        "commentary",
        "summary",
    ]
    has_fabricated = any(ind in content_lower for ind in fabricated_indicators)
    scores["no_fabricated_sections"] = 0.0 if has_fabricated else 1.0

    # Detect obvious paraphrase/rewrite by checking coverage of the required anchor phrases
    anchor_phrases = [
        "agent soul",
        "smart energy industry market assistant",
        "core personality",
        "thinking patterns",
        "communication and expression style",
        "value principles",
        "professional and steady",
        "policy-first thinking",
        "formal, business-like, restrained",
        "core goal is to help the company win energy, power plant, and smart park projects",
    ]
    anchor_found = sum(1 for a in anchor_phrases if a in content_lower)
    scores["no_paraphrased_rewrite"] = 1.0 if anchor_found >= 9 else 0.5 if anchor_found >= 7 else 0.0

    return scores
```

## LLM Judge Rubric

Not applicable. This task uses automated grading only.
