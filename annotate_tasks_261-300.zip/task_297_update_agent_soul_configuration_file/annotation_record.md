| 序号 | 修改项 | 修改原因 |
|---|---|---|
| 1 | 重写 Prompt，使要求更直接明确 | 原 Prompt 虽然能理解，但口语化较强，文件操作要求不够明确；修正后更清楚地区分 create / overwrite / preserve structure / no extra text |
| 2 | 在 Prompt 中补充“不要改写、不要添加说明、只写入给定内容” | 防止模型把题目当作总结或重写任务，提升可评分性 |
| 3 | 保留并强调两个一级标题 | 原题内容里两个 `#` 标题比较特殊，容易被模型合并或“修正格式”；这是本题关键陷阱之一，需要在 Expected Behavior 中明确 |
| 4 | 补充 Expected Behavior 的完整性 | 原版本只说“创建或覆盖”“写入 exact content”“保留 markdown”，但未把关键结构细节和陷阱说完整 |
| 5 | 增加 Ground Truth | 原 Expected Behavior 缺少明确 Ground Truth；现明确正确产物是 `soul.md`，且应为给定内容本身而非改写结果 |
| 6 | 补充陷阱说明 | 明确指出：不能只在回答里复述内容，必须真正更新工作区文件；不能“优化措辞”或改写 markdown 结构 |
| 7 | 扩充 Grading Criteria | 原标准覆盖面偏窄，缺少对两个一级标题、其他关键 bullet、禁止改写等核心点的检查 |
| 8 | 优化 Grading Criteria 的独立性 | 将“section / personality / thinking patterns / other bullets / fabricated content / paraphrase”拆开，便于独立判定 |
| 9 | 重写 `grade()` 的 score key 结构 | 让 key 与评分条目更一一对应，满足 Key 对齐要求 |
| 10 | 为 `grade()` 增加统一 zero_scores | 满足“空白零分 / 文件不存在全 0 返回”的要求 |
| 11 | 为 `grade()` 增加编码容错读取 | 原实现直接 `read_text()`，编码异常时可能报错；修正后更稳健 |
| 12 | 将主标题检查从单一标题改为两个一级标题 | 原题只检查 `"Agent Soul"`，但实际上给定内容中有两个一级标题，原检查不完整 |
| 13 | 保留 section / traits / patterns 的部分得分机制 | 满足“支持 0.0-1.0 之间部分得分”要求，且比纯 0/1 更有区分度 |
| 14 | 新增 `has_other_key_bullets` | 原自动评分没有覆盖第 3、4 节的大部分关键内容，导致覆盖不足 |
| 15 | 新增 `no_paraphrased_rewrite` | 原题无法识别“模型改写但大意差不多”的情况；本题要求是精确写入，因此需要单独约束 |
| 16 | 扩展 fabricated section 检查 | 原 fabricated indicators 过少；增加 appendix / notes / commentary / summary 等更常见的额外内容标记 |
| 17 | 明确本题不适用 LLM Judge Rubric | 该题 `grading_type: automated`，因此无需额外添加 LLM rubric，避免与题面配置冲突 |
| 18 | 保持 difficulty 为 easy | 本题本质是精确文件写入任务，虽有轻微格式陷阱，但整体仍与 easy 难度匹配 |