---
id: task_267_powershell_directory_isolation_script
name: PowerShell Directory Isolation Script
category: Automation
subcategory: Script and Terminal Automation
difficulty: medium
external_dependency: none
verification_method: unit-test
input_modality: text-only
grading_type: automated
timeout_seconds: 180
workspace_files: []
source_line_number: 9651
source_query: "Create a PowerShell 5.1 script/rule to isolate specific directories under D:\\files by matching directory names only, and moving each matched directory as a whole (do not move files individually). The directories to isolate include: .Spotlight-V100 and CBM2096P_v5530. Include a dry-run mode (e.g., -WhatIf) and clear logging of moves."
grading_weights:
  automated: 1.0
  llm_judge: 0.0
---

## Prompt

Hey, I need a PowerShell 5.1 script to isolate some junk directories from my D:\files folder. The script should match directories by name only and move the entire directory as a whole — don't move individual files inside them separately.

Here are the directory names I want to isolate:
- .Spotlight-V100
- CBM2096P_v5530

Move matched directories to a quarantine folder like D:\quarantine or something configurable.

Requirements:
- Support a dry-run mode using -WhatIf so I can preview what would happen without actually moving anything
- Log everything clearly — which directories were found, which were moved (or would be moved in dry-run)
- The script should be reusable, so maybe accept parameters for the source path, quarantine path, and the list of directory names to match
- Make sure it handles cases where the quarantine folder doesn't exist yet (create it)
- Also handle if a target directory name already exists in quarantine (maybe append a timestamp or something)

Save the script as `Isolate-Directories.ps1`

## Expected Behavior

The agent should produce a `Isolate-Directories.ps1` PowerShell 5.1 script that:

1. Declares a `param()` block accepting at minimum: source path, quarantine path, and a list of target directory names (with `.Spotlight-V100` and `CBM2096P_v5530` as defaults or examples).
2. Implements `-WhatIf` dry-run support — either via `[CmdletBinding(SupportsShouldProcess=$true)]` or a manual `-WhatIf` switch — so that running with `-WhatIf` prints what would happen without performing any moves.
3. Searches the source directory for subdirectories whose names exactly match entries in the target list (not partial matches on file names).
4. Moves each matched directory as a whole unit using `Move-Item` (or equivalent), not by iterating and moving individual files inside it.
5. Creates the quarantine directory if it does not already exist.
6. Handles naming conflicts in quarantine by appending a timestamp or similar suffix to the destination name.
7. Logs each step clearly: which directories were found, whether they were moved or skipped (dry-run), and any errors.

Ground Truth: The output file must be named exactly `Isolate-Directories.ps1` and must contain a `param` block, `-WhatIf` or `SupportsShouldProcess` support, a `Move-Item` (or `[System.IO.Directory]::Move`) call, logging output, quarantine folder creation logic, conflict-handling logic (e.g., `Get-Date` or timestamp suffix), and references to both `.Spotlight-V100` and `CBM2096P_v5530`.

## Grading Criteria

- [ ] File `Isolate-Directories.ps1` exists
- [ ] Script contains a `param` block with source path, quarantine path, and directory name list parameters
- [ ] Script supports `-WhatIf` dry-run mode (via `SupportsShouldProcess` or explicit switch)
- [ ] Script uses `Move-Item` or equivalent to move whole directories (not individual files)
- [ ] Script includes logging/output statements (e.g., `Write-Host`, `Write-Verbose`, `Write-Output`)
- [ ] Script handles quarantine folder creation when it does not exist
- [ ] Script handles naming conflicts in quarantine (e.g., appends timestamp)
- [ ] Script references both target directory names: `.Spotlight-V100` and `CBM2096P_v5530`
- [ ] Script does not iterate and move individual files inside matched directories

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    from pathlib import Path
    import re

    scores = {}
    ws = Path(workspace_path)

    script_file = ws / "Isolate-Directories.ps1"
    scores["script_exists"] = 1.0 if script_file.exists() else 0.0

    if not script_file.exists():
        scores["has_param_block"] = 0.0
        scores["has_whatif_support"] = 0.0
        scores["uses_move_item"] = 0.0
        scores["has_logging"] = 0.0
        scores["handles_quarantine_creation"] = 0.0
        scores["handles_naming_conflict"] = 0.0
        scores["matches_target_dirs"] = 0.0
        scores["no_individual_file_moves"] = 0.0
        return scores

    content = script_file.read_text()
    content_lower = content.lower()

    param_pattern = r'param\s*\('
    scores["has_param_block"] = 1.0 if re.search(param_pattern, content, re.IGNORECASE) else 0.0

    whatif_patterns = [
        r'-whatif',
        r'\[switch\]\s*\$whatif',
        r'supportsshouldprocess',
        r'cmdletbinding.*shouldprocess',
        r'\$pscmdlet\.shouldprocess'
    ]
    has_whatif = any(re.search(p, content, re.IGNORECASE) for p in whatif_patterns)
    scores["has_whatif_support"] = 1.0 if has_whatif else 0.0

    move_patterns = [r'move-item', r'move\s+-path', r'\[system\.io\.directory\]::move']
    has_move = any(re.search(p, content, re.IGNORECASE) for p in move_patterns)
    scores["uses_move_item"] = 1.0 if has_move else 0.0

    log_patterns = [r'write-host', r'write-output', r'write-verbose', r'write-information', r'out-file', r'\$log']
    has_logging = any(re.search(p, content, re.IGNORECASE) for p in log_patterns)
    scores["has_logging"] = 1.0 if has_logging else 0.0

    create_patterns = [
        r'new-item.*-itemtype\s+directory',
        r'mkdir',
        r'\[system\.io\.directory\]::createdirectory',
        r'test-path.*new-item',
        r'if\s*\(\s*-not\s*\(?\s*test-path'
    ]
    has_create = any(re.search(p, content, re.IGNORECASE) for p in create_patterns)
    scores["handles_quarantine_creation"] = 1.0 if has_create else 0.0

    conflict_patterns = [
        r'timestamp',
        r'get-date',
        r'datetime',
        r'_\d+',
        r'rename',
        r'already\s*exist',
        r'test-path.*join-path'
    ]
    has_conflict_handling = any(re.search(p, content, re.IGNORECASE) for p in conflict_patterns)
    scores["handles_naming_conflict"] = 1.0 if has_conflict_handling else 0.0

    # Use exact-name matching to avoid false positives (e.g. 'spotlight' appearing in comments)
    has_spotlight = bool(re.search(r'\.spotlight-v100', content_lower))
    has_cbm = bool(re.search(r'cbm2096p_v5530', content_lower))
    scores["matches_target_dirs"] = 1.0 if (has_spotlight and has_cbm) else (0.5 if (has_spotlight or has_cbm) else 0.0)

    # Penalise scripts that enumerate individual files for moving
    child_item_file_pattern = r'get-childitem.*-file'
    moves_files_individually = bool(re.search(child_item_file_pattern, content, re.IGNORECASE))
    dir_pattern = r'get-childitem.*-directory|psiscontainer|\.psiscontainer'
    uses_directory_filter = bool(re.search(dir_pattern, content, re.IGNORECASE))
    scores["no_individual_file_moves"] = 1.0 if (uses_directory_filter or not moves_files_individually) else 0.0

    return scores
```

## LLM Judge Rubric

```yaml
dimensions:
  - name: Correctness & Completeness
    weight: 40%
    description: Does the script correctly implement all required features — param block, WhatIf support, whole-directory moves, quarantine creation, conflict handling, and both target directory names?
    levels:
      1.0: All features present and logically correct; both directory names included; conflict and creation logic sound
      0.75: Most features present with minor omissions (e.g., one target name missing or conflict handling minimal)
      0.5: Core move logic works but several features missing (e.g., no conflict handling or no quarantine creation)
      0.25: Script skeleton present but major features absent or broken
      0.0: File missing or script does not address the task at all

  - name: WhatIf / Dry-Run Quality
    weight: 25%
    description: Is the dry-run implementation idiomatic and reliable? Does it truly prevent moves while still logging what would happen?
    levels:
      1.0: Uses SupportsShouldProcess / $PSCmdlet.ShouldProcess correctly, or explicit -WhatIf switch that fully prevents all side effects and logs clearly
      0.75: WhatIf implemented but slightly non-idiomatic (e.g., manual flag checked inconsistently)
      0.5: Dry-run exists but does not prevent all side effects (e.g., still creates quarantine folder)
      0.25: WhatIf mentioned in param block only, not actually used in logic
      0.0: No dry-run support at all

  - name: Code Quality & Reusability
    weight: 20%
    description: Is the script well-structured, parameterised for reuse, and readable?
    levels:
      1.0: Clean param block with all three parameters; good variable naming; inline comments; idiomatic PowerShell 5.1
      0.75: Param block present but one parameter hard-coded; reasonably readable
      0.5: Partially parameterised; some hard-coded values; follows rough PowerShell conventions
      0.25: Mostly hard-coded; difficult to reuse without editing source
      0.0: No parameters; script is a one-off hard-coded sequence

  - name: Logging Clarity
    weight: 15%
    description: Does the script clearly log what it finds and what it does (or would do)?
    levels:
      1.0: Logs found directories, dry-run vs actual moves, skipped conflicts, and errors with clear messages
      0.75: Logs most actions but misses one scenario (e.g., no message when nothing found)
      0.5: Basic logging present but sparse or inconsistent
      0.25: Single log line or logging only on error
      0.0: No logging whatsoever
```