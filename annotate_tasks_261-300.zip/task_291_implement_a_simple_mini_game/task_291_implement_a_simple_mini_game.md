---
id: task_291_implement_a_simple_mini_game
name: Implement a Simple Mini-Game
category: Automation
subcategory: Script and Terminal Automation
difficulty: easy
external_dependency: none
verification_method: unit-test
input_modality: text-only
grading_type: hybrid
grading_weights:
  automated: 0.4
  llm_judge: 0.6
timeout_seconds: 180
workspace_files: []
source_line_number: 1362
source_query: "Implement a simple mini-game (choose a reasonable game) and provide runnable code plus brief instructions on how to play."
---

## Prompt

Please create a simple terminal game in Python that I can run and play from the command line.

You may choose any reasonable mini-game format, such as a number guessing game, rock-paper-scissors, or a short text-based adventure, as long as it is simple, interactive, and fully playable in the terminal.

Save the game code to `game.py` and write a short `README.md` that explains:
- how to run the game
- how the player interacts with it
- how the game ends or how to quit

Keep the solution self-contained and runnable with the Python standard library only.

## Expected Behavior

The agent should:

1. Create `game.py` containing a complete Python terminal game that runs with the standard library only.
2. Implement an interactive gameplay flow that reads user input and responds meaningfully to it.
3. Include a clear gameplay loop or turn structure so the user can actually play at least one full round/session.
4. Provide a clear ending condition, such as win/lose, completion, or an explicit quit path.
5. Create `README.md` with concise instructions covering how to run the game, how to play, and how/when the game ends.
6. Ensure the Python code is syntactically valid and reasonably runnable as submitted.

Traps / special handling:
- The task does **not** require any specific game type; any simple terminal mini-game is acceptable if it is interactive and playable.
- The task does **not** require advanced features such as graphics, persistence, networking, or external packages.
- The agent should not leave placeholder code, incomplete pseudocode, or documentation-only output.

Ground truth:
- Correct output must include both `game.py` and `README.md`.
- `game.py` must contain executable Python code for a playable terminal game.
- `README.md` must explain running and playing the game.

Tested capabilities: Python programming, interactive script design, basic game logic, documentation writing.

## Grading Criteria

- [ ] `game.py` exists
- [ ] `README.md` exists
- [ ] `game.py` has valid Python syntax
- [ ] `game.py` includes user input handling for interactivity
- [ ] `game.py` includes substantive game flow or main gameplay logic
- [ ] `game.py` includes a clear end condition or quit path
- [ ] `README.md` includes instructions for running the game
- [ ] `README.md` includes brief instructions for how to play the game

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    from pathlib import Path
    import ast

    ws = Path(workspace_path)

    scores = {
        "game_file_exists": 0.0,
        "readme_exists": 0.0,
        "valid_python_syntax": 0.0,
        "has_input_handling": 0.0,
        "has_game_logic": 0.0,
        "has_end_condition": 0.0,
        "readme_has_run_instructions": 0.0,
        "readme_has_play_instructions": 0.0,
    }

    game_file = ws / "game.py"
    readme_file = ws / "README.md"

    if game_file.exists():
        scores["game_file_exists"] = 1.0

    if readme_file.exists():
        scores["readme_exists"] = 1.0

    if game_file.exists():
        try:
            code = game_file.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            code = ""

        if code.strip():
            try:
                ast.parse(code)
                scores["valid_python_syntax"] = 1.0
            except SyntaxError:
                scores["valid_python_syntax"] = 0.0

        code_lower = code.lower()

        # Interactivity
        input_markers = ["input(", "sys.stdin", "stdin.readline", "getpass("]
        if any(marker in code_lower for marker in input_markers):
            scores["has_input_handling"] = 1.0

        # Substantive gameplay logic
        has_loop = ("while " in code_lower) or ("for " in code_lower)
        has_branching = ("if " in code_lower)
        has_function_or_main = ("def " in code_lower) or ('if __name__ == "__main__"' in code_lower) or ("if __name__ == '__main__'" in code_lower)
        if (has_loop and has_branching) or (has_loop and has_function_or_main):
            scores["has_game_logic"] = 1.0
        elif len(code.strip()) >= 100 and has_branching and has_function_or_main:
            scores["has_game_logic"] = 0.5

        # End condition / quit path
        end_keywords = [
            "win", "won", "lose", "lost", "game over", "congratulations",
            "correct", "you got it", "quit", "exit", "end", "bye",
            "thanks for playing", "play again"
        ]
        end_markers = ["break", "return", "sys.exit", "exit(", "quit("]
        has_end_text = any(keyword in code_lower for keyword in end_keywords)
        has_end_control = any(marker in code_lower for marker in end_markers)
        if has_end_text or has_end_control:
            scores["has_end_condition"] = 1.0

    # If README is missing, both README-related items remain 0.0
    if readme_file.exists():
        try:
            readme_content = readme_file.read_text(encoding="utf-8", errors="ignore").lower()
        except Exception:
            readme_content = ""

        run_keywords = [
            "python game.py", "python3 game.py", "run", "execute",
            "start", "launch", "command line", "terminal"
        ]
        if any(keyword in readme_content for keyword in run_keywords):
            scores["readme_has_run_instructions"] = 1.0

        play_keywords = [
            "guess", "type", "enter", "choose", "input", "player",
            "how to play", "instructions", "quit", "exit", "win", "lose"
        ]
        if any(keyword in readme_content for keyword in play_keywords):
            scores["readme_has_play_instructions"] = 1.0

    return scores
````

## LLM Judge Rubric

### Dimension 1: Game Playability and Completeness (40%)

**1.0** - The submission provides a clearly playable terminal game with a coherent gameplay loop, meaningful user interaction, and a clear ending or quit path. The game feels complete for a simple mini-game.
**0.75** - The game is playable and mostly complete, but may be slightly repetitive, simplistic, or rough around the edges.
**0.5** - The game has some playable elements, but interaction, flow, or ending behavior is incomplete or confusing.
**0.25** - The code resembles a game idea but is barely playable or largely incomplete.
**0.0** - No meaningful playable game is provided.

### Dimension 2: Code Quality and Robustness (30%)

**1.0** - Code is clear, organized, syntactically correct, and uses reasonable Python structure for a simple script.
**0.75** - Code is valid and understandable, with minor structure or readability issues.
**0.5** - Code runs or nearly runs, but has notable organization, clarity, or reliability problems.
**0.25** - Code is poorly structured, fragile, or difficult to follow, even if partially functional.
**0.0** - Code is missing, non-runnable, or fundamentally broken.

### Dimension 3: User Experience in Terminal (15%)

**1.0** - Prompts, feedback, and outputs are clear and help the player understand what to do at each step.
**0.75** - The game is understandable overall, with only minor UX issues.
**0.5** - Some prompts or outputs are unclear, making play somewhat confusing.
**0.25** - The user experience is poor and the player may struggle to understand how to interact.
**0.0** - There is effectively no usable terminal interaction experience.

### Dimension 4: Documentation Quality (15%)

**1.0** - `README.md` clearly explains how to run the game, how to play, and how the game ends or how to quit.
**0.75** - README covers most of the necessary instructions with small omissions.
**0.5** - README exists but is incomplete or only partially helpful.
**0.25** - README is minimal and gives little practical guidance.
**0.0** - README is missing or not useful.