---
id: task_268_clean_up_claude_code_team_configurations
name: Clean Up Claude Code Team Configurations
category: System Administration
subcategory: Storage and Data Management
difficulty: easy
external_dependency: none
verification_method: unit-test
input_modality: text-only
grading_type: automated
timeout_seconds: 120
workspace_files: []
source_line_number: 221
source_query: "Clean up existing Claude Code teams by deleting current team configurations and associated task directories under ~/.claude/teams and ~/.claude/tasks"
grading_weights:
  automated: 0.7
  llm_judge: 0.3
---

## Prompt

hey can you help me clean up my claude code setup? I've got some old team configs cluttering things up

basically I need you to:
- delete the team configuration files under ~/.claude/teams/
- also remove the associated task directories under ~/.claude/tasks/

here's what's currently there:

```
~/.claude/teams/
├── alpha-squad.json
├── backend-devs.json
└── ml-team.json

~/.claude/tasks/
├── alpha-squad/
│   ├── task1.md
│   └── task2.md
├── backend-devs/
│   └── api-review.md
└── ml-team/
    ├── model-training.md
    └── data-pipeline.md
```
just wipe all of it - the json files and the task folders. oh and create a simple cleanup_report.txt in the current directory listing what you deleted so I have a record

## Expected Behavior

The agent should:
1. Attempt to delete all three JSON files from `~/.claude/teams/`: `alpha-squad.json`, `backend-devs.json`, `ml-team.json`.
2. Attempt to delete all three task directories from `~/.claude/tasks/`: `alpha-squad/`, `backend-devs/`, `ml-team/` (including their contents).
3. Create `cleanup_report.txt` in the current working directory listing every file/directory that was deleted (or attempted).
4. Handle gracefully the case where the target paths do not exist (e.g., paths are missing in the sandbox environment) — the script/commands should not crash and the report should reflect what was actually attempted.

**Traps to handle:** The listed paths (`~/.claude/teams/`, `~/.claude/tasks/`) may not physically exist in the execution environment. The agent must not fabricate confirmation of deletion for items that were never present, and must not claim to have deleted items not in the provided list (e.g., `frontend-team`, `devops-squad`).

**Ground Truth:** The output file must be named exactly `cleanup_report.txt` and placed in the workspace root. It must mention each of the three team names (`alpha-squad`, `backend-devs`, `ml-team`) and reference both the JSON config files and the task directories. It must not mention teams or files not listed in the prompt.

## Grading Criteria

- [ ] File `cleanup_report.txt` exists in workspace
- [ ] Report mentions all three team configuration files (alpha-squad, backend-devs, ml-team) as deleted or attempted
- [ ] Report mentions task directories as deleted or attempted
- [ ] Teams directory JSON files are removed (or were not present — graceful handling counts)
- [ ] Tasks subdirectories are removed (or were not present — graceful handling counts)
- [ ] No fabricated deletions — report does not claim to delete items not listed in the prompt

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    from pathlib import Path

    scores = {}
    ws = Path(workspace_path)
    home = Path.home()

    report_file = ws / "cleanup_report.txt"
    scores["report_exists"] = 1.0 if report_file.exists() else 0.0

    if not report_file.exists():
        scores["report_mentions_teams"] = 0.0
        scores["report_mentions_tasks"] = 0.0
        scores["no_fabrication"] = 0.0
        scores["teams_cleaned"] = 0.0
        scores["tasks_cleaned"] = 0.0
        return scores

    content = report_file.read_text().lower()

    # All three team names must be mentioned
    team_names = ["alpha-squad", "backend-devs", "ml-team"]
    teams_mentioned = sum(1 for name in team_names if name in content)
    scores["report_mentions_teams"] = round(teams_mentioned / len(team_names), 2)

    # Report must mention both json/config files AND task directories explicitly
    mentions_json = any(kw in content for kw in [".json", "config", "team config", "configuration"])
    mentions_tasks = any(kw in content for kw in ["task director", "task folder", "tasks/", "/tasks"])
    scores["report_mentions_tasks"] = 1.0 if (mentions_json and mentions_tasks) else (0.5 if (mentions_json or mentions_tasks) else 0.0)

    fabricated = any(fake in content for fake in ["frontend-team", "devops-squad", "qa-team", "design-team"])
    scores["no_fabrication"] = 0.0 if fabricated else 1.0

    # Check whether expected JSON files have been removed (if the dir existed)
    teams_dir = home / ".claude" / "teams"
    if teams_dir.exists():
        expected_files = ["alpha-squad.json", "backend-devs.json", "ml-team.json"]
        leftover = [f for f in teams_dir.glob("*.json") if f.name in expected_files]
        scores["teams_cleaned"] = 1.0 if len(leftover) == 0 else 0.0
    else:
        # Directory didn't exist; credit only if report acknowledged the attempt
        scores["teams_cleaned"] = 1.0 if any(name in content for name in team_names) else 0.0

    # Check whether expected task directories have been removed (if the dir existed)
    tasks_dir = home / ".claude" / "tasks"
    if tasks_dir.exists():
        expected_dirs = ["alpha-squad", "backend-devs", "ml-team"]
        leftover_dirs = [d for d in tasks_dir.iterdir() if d.is_dir() and d.name in expected_dirs]
        scores["tasks_cleaned"] = 1.0 if len(leftover_dirs) == 0 else 0.0
    else:
        # Directory didn't exist; credit only if report acknowledged the attempt
        scores["tasks_cleaned"] = 1.0 if any(name in content for name in team_names) else 0.0

    return scores
```

## LLM Judge Rubric

```yaml
dimensions:
  - name: Report Completeness & Accuracy
    weight: 50%
    description: Does cleanup_report.txt accurately list everything that was deleted or attempted, covering all three teams' JSON files and task directories, without inventing items not in the prompt?
    levels:
      1.0: All six items (3 JSON files + 3 task directories) listed; no fabricated entries; clear distinction between config files and task dirs
      0.75: All team names present but one category (files vs dirs) not explicitly distinguished; no fabrication
      0.5: Report exists and mentions some team names but incomplete (e.g., only configs or only tasks listed)
      0.25: Report exists but very sparse — e.g., just says "cleaned up" without naming specific items
      0.0: No report file, or report contains fabricated entries for teams not in the prompt

  - name: Graceful Error Handling
    weight: 30%
    description: Does the agent handle missing paths correctly — neither crashing nor falsely claiming successful deletion of paths that don't exist?
    levels:
      1.0: Commands use flags like -f / --ignore-nonexistent / try-except; report honestly reflects what was or wasn't present
      0.75: Handles missing paths without crashing but report is silent about non-existent paths rather than noting them
      0.5: Script would fail on missing paths but agent catches the error and continues
      0.25: Agent attempts deletions without any error handling; partially crashes
      0.0: Agent fabricates success for paths that clearly do not exist, or fails entirely without any output

  - name: Task Scope Adherence
    weight: 20%
    description: Does the agent stay within the requested scope — only deleting what was asked, in the right locations?
    levels:
      1.0: Deletes only the listed JSON files and task subdirectories; does not touch other files in ~/.claude/ or elsewhere
      0.75: Correct scope but uses overly broad commands (e.g., rm -rf ~/.claude/) that could delete more than requested
      0.5: Deletes the right items but also deletes unrelated files or directories
      0.25: Misunderstands scope — e.g., tries to delete the wrong paths
      0.0: Does not perform any deletion and does not create a report
```