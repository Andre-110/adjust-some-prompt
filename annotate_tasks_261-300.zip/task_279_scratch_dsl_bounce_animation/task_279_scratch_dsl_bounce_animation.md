---
id: task_279_scratch_dsl_bounce_animation
name: Scratch DSL Bounce Animation
category: Automation
subcategory: Script and Terminal Automation
difficulty: medium
external_dependency: none
verification_method: output-check
input_modality: text-only
grading_type: automated
timeout_seconds: 120
workspace_files: []
source_line_number: 7121
source_query: "生成可直接应用到 Scratch 的 DSL（仅输出 1 个 JSON code block），实现：当绿旗被点击时，让一个角色左右来回移动，并在碰到舞台边缘时反弹。"
grading_weights:
  automated: 1.0
  llm_judge: 0.0
---

## Prompt

Hey, I need to generate a Scratch-compatible DSL for a simple animation. Can you give me a JSON that makes a sprite move left and right continuously, bouncing when it hits the edge of the stage?

The behavior should be:
- triggered when the green flag is clicked
- sprite moves in a direction
- when it touches the edge, it bounces back
- keeps doing this forever

Just output a single JSON code block that I can use directly. The JSON should follow Scratch's block structure with opcodes like "event_whenflagclicked", "motion_movesteps", "control_forever", "motion_ifonedgebounce", etc.

## Expected Behavior

The agent should:
1. Output exactly one JSON code block containing valid Scratch DSL
2. Include a "when green flag clicked" event block (opcode: `event_whenflagclicked`)
3. Include a forever loop (opcode: `control_forever`)
4. Include motion to move steps (opcode: `motion_movesteps`)
5. Include edge bounce detection (opcode: `motion_ifonedgebounce`)
6. Structure the blocks with proper parent-child relationships or next block chains

**Ground Truth:** The response must contain exactly one fenced JSON code block. That JSON must be parseable and must contain the opcodes `event_whenflagclicked`, `control_forever`, `motion_movesteps`, and `motion_ifonedgebounce`. All opcodes present must be valid Scratch opcodes.

Tested capabilities: understanding of Scratch block structure, JSON generation, visual programming DSL knowledge.

## Grading Criteria

- [ ] Output contains exactly one JSON code block
- [ ] JSON is valid and parseable
- [ ] Contains green flag event opcode (`event_whenflagclicked`)
- [ ] Contains forever loop opcode (`control_forever`)
- [ ] Contains move steps opcode (`motion_movesteps`)
- [ ] Contains edge bounce opcode (`motion_ifonedgebounce`)
- [ ] No fabricated/invalid Scratch opcodes present

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    import json
    import re

    scores = {}

    def _get_last_assistant_text(transcript: list) -> str:
        for event in reversed(transcript):
            if event.get("type") != "message":
                continue
            msg = event.get("message", {})
            if msg.get("role") != "assistant":
                continue
            for item in msg.get("content", []):
                if isinstance(item, dict) and item.get("type") == "text":
                    return item.get("text", "")
            content = msg.get("content", "")
            if isinstance(content, str):
                return content
        return ""

    text = _get_last_assistant_text(transcript)

    json_blocks = re.findall(r'```(?:json)?\s*\n([\s\S]*?)\n```', text)

    scores["exactly_one_json_block"] = 1.0 if len(json_blocks) == 1 else 0.0

    if not json_blocks:
        scores["valid_json"] = 0.0
        scores["has_green_flag_event"] = 0.0
        scores["has_forever_loop"] = 0.0
        scores["has_move_steps"] = 0.0
        scores["has_edge_bounce"] = 0.0
        scores["no_fabricated_opcodes"] = 0.0
        return scores

    json_content = json_blocks[0]
    try:
        parsed = json.loads(json_content)
        scores["valid_json"] = 1.0
    except Exception:
        scores["valid_json"] = 0.0
        scores["has_green_flag_event"] = 0.0
        scores["has_forever_loop"] = 0.0
        scores["has_move_steps"] = 0.0
        scores["has_edge_bounce"] = 0.0
        scores["no_fabricated_opcodes"] = 0.0
        return scores

    # Extract all opcode values for precise matching
    opcode_pattern = r'"opcode"\s*:\s*"([^"]+)"'
    found_opcodes = [op.lower() for op in re.findall(opcode_pattern, json_content, re.IGNORECASE)]
    opcodes_str = " ".join(found_opcodes)

    scores["has_green_flag_event"] = 1.0 if "event_whenflagclicked" in opcodes_str else 0.0
    scores["has_forever_loop"] = 1.0 if "control_forever" in opcodes_str else 0.0
    scores["has_move_steps"] = 1.0 if "motion_movesteps" in opcodes_str else 0.0
    scores["has_edge_bounce"] = 1.0 if "motion_ifonedgebounce" in opcodes_str else 0.0

    valid_opcodes = {
        "event_whenflagclicked", "control_forever", "control_repeat", "control_if",
        "control_if_else", "control_wait", "control_repeat_until", "control_stop",
        "motion_movesteps", "motion_turnright", "motion_turnleft", "motion_goto",
        "motion_gotoxy", "motion_glideto", "motion_glidesecstoxy", "motion_pointindirection",
        "motion_pointtowards", "motion_changexby", "motion_setx", "motion_changeyby",
        "motion_sety", "motion_ifonedgebounce", "motion_setrotationstyle",
        "looks_say", "looks_sayforsecs", "looks_think", "looks_thinkforsecs",
        "looks_switchcostumeto", "looks_nextcostume", "looks_switchbackdropto",
        "looks_changesizeby", "looks_setsizeto", "looks_changeeffectby",
        "looks_seteffectto", "looks_cleargraphiceffects", "looks_show", "looks_hide",
        "sound_playuntildone", "sound_play", "sound_stopallsounds",
        "sensing_touchingobject", "sensing_touchingcolor", "sensing_distanceto",
        "sensing_askandwait", "sensing_keypressed", "sensing_mousedown",
        "sensing_mousex", "sensing_mousey", "sensing_timer", "sensing_resettimer",
        "operator_add", "operator_subtract", "operator_multiply", "operator_divide",
        "operator_random", "operator_gt", "operator_lt", "operator_equals",
        "operator_and", "operator_or", "operator_not", "operator_join",
        "data_setvariableto", "data_changevariableby", "data_showvariable",
        "data_hidevariable", "data_addtolist", "data_deleteoflist",
        "procedures_definition", "procedures_call", "argument_reporter_string_number"
    }

    if found_opcodes:
        invalid_count = sum(1 for op in found_opcodes if op not in valid_opcodes)
        scores["no_fabricated_opcodes"] = 1.0 if invalid_count == 0 else max(0.0, 1.0 - invalid_count / len(found_opcodes))
    else:
        scores["no_fabricated_opcodes"] = 0.5

    return scores
```

## LLM Judge Rubric

```yaml
dimensions:
  - name: Scratch Block Structure Correctness
    weight: 50%
    description: Does the JSON represent a structurally valid Scratch block program with proper parent-child or next-block chaining?
    levels:
      1.0: All four required opcodes present; blocks are properly chained (event -> forever -> movesteps + ifonedgebounce); JSON structure matches Scratch's expected block format (uid keys, opcode/next/parent fields)
      0.75: All four required opcodes present and correctly nested inside a forever loop; minor structural deviation (e.g., missing uid keys or parent references)
      0.5: All four opcodes present but block nesting is incorrect (e.g., movesteps outside the forever loop, or ifonedgebounce as a top-level block)
      0.25: Two or three of the four required opcodes present with some structural attempt; blocks not properly chained
      0.0: Fewer than two required opcodes present, JSON is not parseable, or structure bears no resemblance to Scratch block format

  - name: Opcode Validity
    weight: 30%
    description: Are all opcodes used in the JSON valid Scratch opcodes with no hallucinated or non-existent opcodes?
    levels:
      1.0: Every opcode in the JSON is a recognized Scratch opcode; no invented opcodes
      0.75: At most one unrecognized opcode present (e.g., a minor typo like "motion_movesteps" vs "motion_movesteps")
      0.5: Two or three unrecognized opcodes present alongside valid ones
      0.25: Several unrecognized opcodes; the core required four are present but additional opcodes are largely fabricated
      0.0: Majority of opcodes are fabricated or the required four opcodes are not among valid Scratch opcodes

  - name: Output Format Compliance
    weight: 20%
    description: Is the output exactly one fenced JSON code block with no extra commentary wrapping or multiple blocks?
    levels:
      1.0: Exactly one fenced ```json code block; no JSON outside the block; valid JSON inside
      0.75: Exactly one fenced code block but fence label is missing (``` without "json") or there is a brief preamble sentence
      0.5: One JSON block present but accompanied by a second non-JSON code block or substantial explanation text
      0.25: Multiple JSON blocks present, or JSON is embedded in prose without a code fence
      0.0: No fenced code block at all, or output is plain text with no JSON structure
```