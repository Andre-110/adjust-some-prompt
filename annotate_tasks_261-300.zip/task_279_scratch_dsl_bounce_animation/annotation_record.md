| 序号 | 修改项 | 修改原因 |
|------|--------|--------|
| 1 | 新增 `grading_weights: automated: 1.0, llm_judge: 0.0` | 原文件缺少该字段，维度 E 要求两者之和为 1.0 |
| 2 | **Expected Behavior** 补充 Ground Truth | 原版无明确可验证答案；补充了必须包含的 4 个 opcode 和格式要求作为 Ground Truth |
| 3 | **grade() `has_move_steps` 逻辑收紧**：从 `"move" in json_str` 改为仅匹配 opcode 列表中的 `"motion_movesteps"` | 原 `"move" in json_str` 会匹配 "movement"、"movesteps" 等任意含 "move" 的词，过于宽泛；改为从提取的 opcode 列表中精确匹配，区分度更强 |
| 4 | **grade() `has_edge_bounce` 逻辑收紧**：从 `"edge" in json_str` 改为仅匹配 `"motion_ifonedgebounce"` | 原条件极宽，任何含 "edge" 的词都命中；同上改为精确 opcode 匹配 |
| 5 | **grade() `has_green_flag_event`、`has_forever_loop` 同步改为 opcode 列表匹配** | 与上两项保持一致，统一从 `found_opcodes` 列表匹配，避免子串误判 |
| 6 | **grade() `no_fabricated_opcodes` 改为比例部分得分** | 原版只做全有或全无（invalid_count == 0 得 1.0，否则得 0）；改为 `1.0 - invalid_count/len(found_opcodes)` 按比例给分，支持部分得分 |
| 7 | **grade() `exactly_one_json_block` 的 else 分支修复**：改为检查 `not json_blocks` | 原版在 `len(json_blocks) >= 1` 时进入处理，在 0 个 block 时进 else 分支；现改为更清晰的 `if not json_blocks` 提前返回全 0，避免多个 block 时漏处理 `exactly_one_json_block` |
| 8 | **新增 `## LLM Judge Rubric`**（3 个维度，权重总和 100%） | 原文件完全缺少该部分；新增 Scratch Block Structure (50%)、Opcode Validity (30%)、Output Format Compliance (20%)，各含 5 个等级描述 |