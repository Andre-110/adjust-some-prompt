| 序号 | 修改项 | 修改原因 |
|------|--------|--------|
| 1 | **Expected Behavior** 补充 Ground Truth | 原版无明确可验证的答案约束；补充了各字段的合法取值范围和预期方向 |
| 2 | **Grading Criteria** 第 1 条拆分为两条，第 9 条重命名为"Analysis content is relevant to news" | 原第 1 条合并了 `valid_json` 和 `has_all_fields` 两个 key；拆分后 9 条与 9 个 key 一一对应。同时将"Analysis logic is coherent"改为更准确的"content relevance"与 key 语义对齐 |
| 3 | **grade() `has_all_fields` 改为部分得分** | 原版只做全有或全无判断；改为 `present / len(required_fields)` 按比例给分，支持部分得分 |
| 4 | **grade() `valid_stocks_format` 改为部分得分** | 原版要求所有股票全部合格才给 1.0，否则给 0；改为 `valid_stocks / len(stocks)`，4 只中 3 只合格得 0.75，区分度更强 |
| 5 | **grade() `valid_trading_suggestion` 补充中文值** | 原 source_query 中 trading_suggestion 约束为中文"短线/波段/观望"，agent 可能输出中文；补充"短线"/"波段"/"观望"到合法值列表 |
| 6 | **grade() `no_fabricated_nonsense` 重命名为 `content_relevance`，阈值从 2 提高到 3，并加入部分得分** | 原名语义不准；阈值 2 过低（几乎必然得分，无区分度）；改为匹配 3 个以上关键词得满分、1–2 个得 0.5、0 个得 0，并补充中文关键词 |
| 7 | **grade() 统一 `all_zero` 字典**：key 名与修改后的 Grading Criteria 对齐，`no_fabricated_nonsense` → `content_relevance` | 保持提前返回字典与函数其余部分 key 名一致 |
| 8 | **grade() `impact_type_bullish` 补充中文"利好"** | agent 可能输出原始中文值，补充后格式更容忍 |
| 9 | **grade() `tourism_industry_mentioned` 补充中文关键词** | 同上，补充"旅游"/"酒店"/"消费"提高格式容忍度 |
| 10 | **LLM Judge Rubric 补全各等级描述** | 原 5 个维度每个只有一句话，完全缺少 1.0/0.75/0.5/0.25/0.0 各等级的具体说明，违反维度 E 第 3 条；为每个维度补全了全部 5 个等级描述 |