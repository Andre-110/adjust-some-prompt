---
id: task_266_product_info_translation_to_multiple_languages
name: Product Info Translation to Multiple Languages
category: Data Analysis
subcategory: Data Processing and Management
difficulty: medium
external_dependency: none
verification_method: unit-test
input_modality: text-only
grading_type: hybrid
grading_weights:
  automated: 0.4
  llm_judge: 0.6
timeout_seconds: 120
workspace_files: []
source_line_number: 5944
source_query: "Translate the provided product info JSON into the listed target_languages. Translate each non-empty source field in names into all target languages, return only the translated target-language entries, and keep empty fields such as allergens and ingredients as empty objects."
---

## Prompt

I need help translating product information into multiple languages.

Here is the input JSON:

```json
{
  "names": {
    "source": "Haidilao Kuaishou Little Chef Sour Soup Fatty Beef Seasoning 150g"
  },
  "allergens": {},
  "ingredients": {},
  "target_languages": [
    "bg", "cs", "da", "de", "el", "en", "es", "fi", "fr", "hu", "it",
    "ja", "ko", "nb", "nl", "pl", "pt", "ro", "ru", "sv", "tr", "zh-cn", "zh-tw"
  ]
}
````

Please create a file named `translations.json`.

Requirements:

* Translate only the non-empty product info fields.
* In this input, only `names.source` has content, so only `names` needs translations.
* Output `names` as an object whose keys are the target language codes and whose values are the translated product names.
* Keep `allergens` as `{}` and `ingredients` as `{}` because they are empty in the input.
* Preserve the brand name `Haidilao` exactly as `Haidilao`.
* Preserve the weight `150g` exactly as `150g`.
* Do not include extra commentary or metadata in the JSON output.
* Do not copy the `source` field into the output.
* The output JSON should contain only:

  * `names`
  * `allergens`
  * `ingredients`

## Expected Behavior

The agent should:

1. Read the input JSON and determine that only `names.source` is non-empty.
2. Translate the product name into all 23 target languages listed in `target_languages`.
3. Preserve `Haidilao` unchanged in every translation.
4. Preserve `150g` unchanged in every translation.
5. Return `allergens` as `{}` and `ingredients` as `{}` without fabricating any content.
6. Save the result to `translations.json`.
7. Ensure the output `names` object contains only target-language keys and does not include `source`.

Ground truth and constraints:

* Required target languages: `bg`, `cs`, `da`, `de`, `el`, `en`, `es`, `fi`, `fr`, `hu`, `it`, `ja`, `ko`, `nb`, `nl`, `pl`, `pt`, `ro`, `ru`, `sv`, `tr`, `zh-cn`, `zh-tw`
* Total required translations under `names`: 23
* `allergens` must be exactly `{}`
* `ingredients` must be exactly `{}`
* `Haidilao` must remain `Haidilao`
* `150g` must remain `150g`
* The output should not include `target_languages`
* The output should not include `names.source`

Key trap:

* The model may incorrectly retain `source` in the output or invent translations/content for empty fields. Both should be treated as mistakes.

Tested capabilities:

* multilingual translation
* structured JSON transformation
* selective field translation
* preservation of brand names and units
* handling empty objects correctly

## Grading Criteria

* [ ] File `translations.json` exists
* [ ] `translations.json` is valid JSON
* [ ] Output contains a `names` object with all 23 required target language keys
* [ ] Every `names` translation is a non-empty string
* [ ] `allergens` is exactly an empty object `{}` and `ingredients` is exactly an empty object `{}`
* [ ] Brand name `Haidilao` is preserved across translations
* [ ] Weight `150g` is preserved across translations
* [ ] Output does not fabricate extra content (including `names.source`, non-empty `allergens`, non-empty `ingredients`, or unrelated top-level fields)

## LLM Judge Rubric

### Criterion 1: Translation Accuracy and Naturalness (Weight: 35%)

**Score 1.0**: Translations are accurate, natural, and clearly express the product name meaning in each target language while preserving the product identity.
**Score 0.75**: Most translations are accurate and understandable, with only minor awkwardness or phrasing issues.
**Score 0.5**: Translations are partially correct but several are literal, unnatural, or semantically weak.
**Score 0.25**: Many translations are poor, unclear, or partially untranslated beyond the required preserved brand/unit.
**Score 0.0**: Translations are largely incorrect, unusable, or missing.

### Criterion 2: Brand and Unit Preservation (Weight: 25%)

**Score 1.0**: `Haidilao` and `150g` are preserved correctly in all target-language entries.
**Score 0.75**: One or two entries alter either the brand or the unit slightly.
**Score 0.5**: Several entries fail to preserve the brand or unit correctly.
**Score 0.25**: Preservation is inconsistent across many languages.
**Score 0.0**: Brand and/or unit are broadly mistranslated or omitted.

### Criterion 3: Coverage and Structural Completeness (Weight: 25%)

**Score 1.0**: All 23 target languages are present under `names`, each with a non-empty string, and the JSON structure is complete.
**Score 0.75**: Nearly all target languages are present, with only minor omissions or structural issues.
**Score 0.5**: A noticeable number of languages are missing or some values are malformed.
**Score 0.25**: Many target languages are missing or structure is substantially incomplete.
**Score 0.0**: Coverage is severely incomplete or the structure is unusable.

### Criterion 4: Constraint Compliance and Non-Fabrication (Weight: 15%)

**Score 1.0**: Output fully follows constraints: no `source`, no `target_languages`, `allergens` and `ingredients` remain `{}`, and no extra fabricated content appears.
**Score 0.75**: Minor constraint violation that does not seriously affect usability.
**Score 0.5**: Some extra or incorrect content is included, but the main structure remains recoverable.
**Score 0.25**: Multiple constraint violations reduce output reliability.
**Score 0.0**: Output substantially ignores the required constraints.

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    from pathlib import Path
    import json

    SCORE_KEYS = [
        "file_exists",
        "valid_json",
        "all_target_languages_present",
        "all_name_values_nonempty_strings",
        "empty_objects_correct",
        "brand_preserved",
        "weight_preserved",
        "no_fabricated_content",
    ]

    TARGET_LANGS = [
        "bg", "cs", "da", "de", "el", "en", "es", "fi", "fr", "hu", "it",
        "ja", "ko", "nb", "nl", "pl", "pt", "ro", "ru", "sv", "tr", "zh-cn", "zh-tw"
    ]

    def zero_scores():
        return {k: 0.0 for k in SCORE_KEYS}

    ws = Path(workspace_path)
    translations_file = ws / "translations.json"

    if not translations_file.exists():
        return zero_scores()

    scores = zero_scores()
    scores["file_exists"] = 1.0

    try:
        data = json.loads(translations_file.read_text(encoding="utf-8"))
    except Exception:
        return scores

    scores["valid_json"] = 1.0

    names_obj = data.get("names")
    if isinstance(names_obj, dict):
        present_langs = [lang for lang in TARGET_LANGS if lang in names_obj]
        scores["all_target_languages_present"] = len(present_langs) / len(TARGET_LANGS)

        nonempty_count = 0
        brand_count = 0
        weight_count = 0

        for lang in TARGET_LANGS:
            value = names_obj.get(lang)
            if isinstance(value, str) and value.strip():
                nonempty_count += 1
                if "haidilao" in value.lower():
                    brand_count += 1
                if "150g" in value.lower():
                    weight_count += 1

        scores["all_name_values_nonempty_strings"] = nonempty_count / len(TARGET_LANGS)
        scores["brand_preserved"] = brand_count / len(TARGET_LANGS)
        scores["weight_preserved"] = weight_count / len(TARGET_LANGS)
    else:
        scores["all_target_languages_present"] = 0.0
        scores["all_name_values_nonempty_strings"] = 0.0
        scores["brand_preserved"] = 0.0
        scores["weight_preserved"] = 0.0

    allergens_obj = data.get("allergens")
    ingredients_obj = data.get("ingredients")
    empty_ok = (allergens_obj == {}) and (ingredients_obj == {})
    scores["empty_objects_correct"] = 1.0 if empty_ok else 0.0

    allowed_top_level_keys = {"names", "allergens", "ingredients"}
    top_level_keys = set(data.keys())

    no_extra_top_keys = top_level_keys.issubset(allowed_top_level_keys)
    no_source_key = isinstance(names_obj, dict) and ("source" not in names_obj)
    no_fake_allergens = allergens_obj == {}
    no_fake_ingredients = ingredients_obj == {}

    scores["no_fabricated_content"] = 1.0 if (
        no_extra_top_keys and
        no_source_key and
        no_fake_allergens and
        no_fake_ingredients
    ) else 0.0

    return scores
```