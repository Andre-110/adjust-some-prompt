| 序号 | 修改项 | 修改原因 |
|---|---|---|
| 1  | 修改 `difficulty` 为 `medium` | 任务涉及 23 种语言翻译、JSON 结构约束、品牌和计量单位保留、空字段处理，复杂度高于 easy。                                       |
| 2  | 修订 Prompt                  | 保持自然请求风格，同时补足“只翻译非空字段”和“只输出目标语言键”的约束，减少歧义。                                                |
| 3  | 补全 Expected Behavior       | 增加 Ground Truth：仅 `names` 需要翻译，`allergens`/`ingredients` 必须保持 `{}`，`names` 仅保留 23 个目标语言键。 |
| 4  | 重写 Grading Criteria        | 让标准与自动评分 key 更清晰对齐，并覆盖语言覆盖、品牌保留、重量保留、空字段不伪造。                                              |
| 5  | 重写 `grade()`               | 增加统一 score key、空白零分、部分得分，并增加对 `names` 是否混入非目标语言键的检查。                                      |
| 6  | 增强格式容忍                     | 保留对 `Haidilao`/`haidilao` 和 `150g`/`150G` 的宽松匹配，同时避免因个别语言轻微格式差异导致过严判分。                    |
| 7  | 修正空字段检查                    | 明确 Ground Truth 是 `allergens == {}` 且 `ingredients == {}`，并单独保留 `no_fabrication` 检查。      |
| 8  | 补全 LLM Judge Rubric        | 原文件缺失完整分档描述；现补齐 4 个维度、总权重 100%、每档说明。                                                      |