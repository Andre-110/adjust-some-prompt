| 序号 | 修改项 | 修改原因 |
|---|---|---|
| 1 | 在 frontmatter 中新增 `grading_weights` | 原文件缺少该字段，按要求需保证 `automated + llm_judge = 1.0` |
| 2 | 优化 Prompt 表述 | 原 Prompt 虽基本清晰，但“Save it to a file...”略简略，补充“JSON format”和必填字段后更明确、可执行 |
| 3 | 补全 Expected Behavior 中的 Ground Truth | 原版本是泛化描述，缺少更明确的标准答案字段定义，不利于一致判分 |
| 4 | 删除 Expected Behavior 中“Optionally calculate total value” 的模糊写法，改为“如包含则必须正确” | 原表述会让可选字段与正确性标准不清晰，修正后更利于验证 |
| 5 | 在 Grading Criteria 中增加“company name”检查项 | 原标准未覆盖 `Alibaba`，与 Prompt/Expected Behavior 不完全对齐 |
| 6 | 重写 `grade()` 的字段提取逻辑 | 原实现大量依赖全文字符串包含，容易误判，不能稳定区分正确 JSON 与错误 JSON |
| 7 | 修复 `grade()` 对 JSON 结构的判定方式 | 原实现只要文本里出现数字或关键词就可能得分，没有真正基于字段校验 |
| 8 | 提升 `grade()` 的格式容忍度 | 原实现对大小写和字段别名支持不足，修正后支持如 `symbol`/`ticker`、`qty`/`quantity` 等合理变体 |
| 9 | 增加 `company_name` 对应 score key | 原 score key 与 Grading Criteria 不完全一一对应，修正后对齐 |
| 10 | 改进 `correct_action` 的部分得分逻辑 | 原实现只有 0/1，不能体现部分得分要求；修正后支持 0.5 |
| 11 | 改进 `no_fabrication` 判分逻辑 | 原逻辑通过查找“错误 ticker/价格”字符串来判造假，容易漏判或误判；修正为检查关键字段是否与真实值矛盾 |
| 12 | 保留并强化“空白零分”前置检查 | 原文件已有部分处理，但我统一整理为初始化全 0 并在文件不存在/JSON 非法时直接返回，更稳健 |
| 13 | 新增完整 LLM Judge Rubric | 原文件缺失该部分，不满足标注规范 |
| 14 | 为 LLM Judge Rubric 设置 3 个评分维度且权重合计 100% | 满足 rubric 维度充分、权重正确的要求 |
| 15 | 保持 difficulty 为 `easy` 不变 | 任务仍属于简单结构化信息写入，难度与题意匹配，无需调整 |
