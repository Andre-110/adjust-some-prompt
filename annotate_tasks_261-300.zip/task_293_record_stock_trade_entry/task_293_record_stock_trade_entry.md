---
id: task_293_record_stock_trade_entry
name: Record Stock Trade Entry
category: Finance
subcategory: Trade Execution and Management
difficulty: easy
external_dependency: none
verification_method: unit-test
input_modality: text-only
grading_type: automated
timeout_seconds: 60
workspace_files: []
source_line_number: 112
source_query: "記錄一筆交易：買入 9988.HK（阿里巴巴）100 股，成交價 HKD 150.1。"
grading_weights:
  automated: 1.0
  llm_judge: 0.0
---

## Prompt

I just bought 100 shares of 9988.HK (Alibaba) at HKD 150.1.

Please record this trade in a file named `trade_log.json`.

The file should contain the trade details in JSON format. Include the ticker, company name, action, quantity, price, and currency.

## Expected Behavior

The agent should create a valid JSON file named `trade_log.json` in the workspace that records the trade with the following ground-truth details:

- ticker: `9988.HK`
- company_name: `Alibaba`
- action: a buy action such as `buy` or `purchase`
- quantity: `100`
- price: `150.1`
- currency: `HKD`

The JSON may contain additional fields, such as total value, trade date, exchange, or notes, as long as they do not contradict the required trade details.

If total value is included, it should be correctly calculated as `15010` or an equivalent numeric/string representation of HKD 15,010.

Tested capabilities: extracting structured financial information from a user request, writing valid JSON, and preserving exact trade details without fabrication.

## Grading Criteria

- [ ] File `trade_log.json` exists in the workspace
- [ ] File content is valid JSON
- [ ] JSON records the correct ticker symbol (`9988.HK`)
- [ ] JSON records the correct company name (`Alibaba`)
- [ ] JSON records a valid buy action
- [ ] JSON records the correct quantity (`100`)
- [ ] JSON records the correct price (`150.1`)
- [ ] JSON records the correct currency (`HKD`)
- [ ] JSON does not contradict the requested trade details with fabricated ticker, quantity, or price

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    from pathlib import Path
    import json
    import math

    def norm_str(value):
        if value is None:
            return ""
        return str(value).strip().lower()

    def parse_float(value):
        if value is None:
            return None
        if isinstance(value, (int, float)):
            return float(value)
        text = str(value).strip().lower()
        for token in ["hkd", "hk$", ",", "shares", "share"]:
            text = text.replace(token, "")
        text = text.strip()
        try:
            return float(text)
        except Exception:
            return None

    def parse_int(value):
        num = parse_float(value)
        if num is None:
            return None
        if abs(num - round(num)) < 1e-9:
            return int(round(num))
        return None

    scores = {
        "file_exists": 0.0,
        "valid_json": 0.0,
        "correct_ticker": 0.0,
        "correct_company_name": 0.0,
        "correct_action": 0.0,
        "correct_quantity": 0.0,
        "correct_price": 0.0,
        "correct_currency": 0.0,
        "no_fabrication": 0.0,
    }

    ws = Path(workspace_path)
    trade_file = ws / "trade_log.json"

    if not trade_file.exists():
        return scores

    scores["file_exists"] = 1.0

    try:
        data = json.loads(trade_file.read_text(encoding="utf-8"))
        scores["valid_json"] = 1.0
    except Exception:
        return scores

    if not isinstance(data, dict):
        return scores

    normalized = {str(k).strip().lower(): v for k, v in data.items()}

    ticker = normalized.get("ticker") or normalized.get("symbol") or normalized.get("stock_ticker")
    company_name = normalized.get("company_name") or normalized.get("company") or normalized.get("name")
    action = normalized.get("action") or normalized.get("side") or normalized.get("trade_type")
    quantity = normalized.get("quantity") or normalized.get("shares") or normalized.get("qty")
    price = normalized.get("price") or normalized.get("trade_price") or normalized.get("execution_price")
    currency = normalized.get("currency") or normalized.get("ccy")

    ticker_norm = norm_str(ticker)
    company_norm = norm_str(company_name)
    action_norm = norm_str(action)
    currency_norm = norm_str(currency)

    if ticker_norm == "9988.hk":
        scores["correct_ticker"] = 1.0

    if company_norm in {"alibaba", "alibaba group", "alibaba group holding"}:
        scores["correct_company_name"] = 1.0

    if action_norm in {"buy", "bought", "purchase", "purchased"}:
        scores["correct_action"] = 1.0
    elif "buy" in action_norm or "purchas" in action_norm:
        scores["correct_action"] = 0.5

    quantity_num = parse_int(quantity)
    if quantity_num == 100:
        scores["correct_quantity"] = 1.0

    price_num = parse_float(price)
    if price_num is not None and math.isclose(price_num, 150.1, rel_tol=0.0, abs_tol=1e-6):
        scores["correct_price"] = 1.0

    if currency_norm in {"hkd", "hk$", "hong kong dollar", "hong kong dollars"}:
        scores["correct_currency"] = 1.0

    contradictions = 0

    if ticker is not None and ticker_norm != "9988.hk":
        contradictions += 1

    if quantity is not None and quantity_num != 100:
        contradictions += 1

    if price is not None and (price_num is None or not math.isclose(price_num, 150.1, rel_tol=0.0, abs_tol=1e-6)):
        contradictions += 1

    if company_name is not None and company_norm not in {"alibaba", "alibaba group", "alibaba group holding"}:
        contradictions += 1

    if contradictions == 0:
        scores["no_fabrication"] = 1.0
    elif contradictions == 1:
        scores["no_fabrication"] = 0.5
    else:
        scores["no_fabrication"] = 0.0

    return scores
````

## LLM Judge Rubric

Use this rubric only if manual or model-based review is needed as a fallback.

### Dimension 1: Trade Detail Accuracy (Weight: 50%)

* **1.0**: All required trade details are correct: ticker `9988.HK`, company name `Alibaba`, buy action, quantity `100`, price `150.1`, and currency `HKD`.
* **0.75**: Nearly all required details are correct, with only one minor issue that does not materially change the trade record.
* **0.5**: Some required details are correct, but one important field is missing or incorrect.
* **0.25**: Multiple important trade details are missing or incorrect.
* **0.0**: The trade record is largely incorrect, contradictory, or not recognizable as the requested trade.

### Dimension 2: Output Format Validity (Weight: 30%)

* **1.0**: Output is a valid JSON file named `trade_log.json` and is well-structured for the requested trade record.
* **0.75**: Output is valid JSON with only minor structural or naming issues.
* **0.5**: Output is partially usable but has noticeable formatting or structural problems.
* **0.25**: Output format is poor and difficult to use, though some JSON-like structure may exist.
* **0.0**: Output is missing, not JSON, or unreadable.

### Dimension 3: Instruction Following and Non-Fabrication (Weight: 20%)

* **1.0**: Follows the prompt exactly and does not add contradictory fabricated trade details.
* **0.75**: Mostly follows instructions, with only minor unnecessary additions that do not conflict with the prompt.
* **0.5**: Partially follows instructions, but includes some unsupported or weakly relevant extra content.
* **0.25**: Significant instruction-following issues or potentially misleading fabricated content.
* **0.0**: Does not follow the task requirements or fabricates contradictory details.
