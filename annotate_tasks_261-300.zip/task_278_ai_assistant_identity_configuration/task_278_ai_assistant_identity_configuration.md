---
id: task_278_ai_assistant_identity_configuration
name: AI Assistant Identity Configuration
category: Automation
subcategory: Agent and AI Orchestration
difficulty: easy
external_dependency: none
verification_method: unit-test
input_modality: text-only
grading_type: automated
timeout_seconds: 120
workspace_files: []
source_line_number: 40
source_query: "将助手身份配置为：名字"大熊"，定位"赚钱搭档"，性格"活泼但思维严谨"；并将用户称呼配置为"多来B梦"。"
grading_weights:
  automated: 1.0
  llm_judge: 0.0
---

## Prompt

Hey, I need you to set up a config file for my AI assistant persona. Here's what I want:

- Assistant's name: "BigBear"
- Assistant's role: "money-making partner" 
- Assistant's personality: "lively but thinks rigorously"
- User's nickname: "DoraemonB"

Save this as `assistant_config.json`. Make sure it's properly structured JSON with clear keys for each setting. Oh and add a little greeting message that the assistant would say when starting a conversation, something that fits the personality.

## Expected Behavior

The agent should:
1. Create a well-structured JSON configuration file named `assistant_config.json`
2. Include all four required fields: assistant name ("BigBear"), role ("money-making partner"), personality ("lively but rigorous"), and user nickname ("DoraemonB")
3. Generate an appropriate greeting message that reflects the "lively but rigorous" personality
4. Save to the workspace as `assistant_config.json`

**Ground Truth:** The file `assistant_config.json` must be valid JSON containing: the string "BigBear" (case-insensitive) as the assistant name, a role value referencing "money" and "partner" concepts, a personality value referencing both "lively" and "rigorous" aspects, the string "DoraemonB" (case-insensitive) as the user nickname, and at least one greeting/welcome message field with a non-trivial string value.

Tested capabilities: JSON file creation, following configuration specifications, creative text generation within constraints.

## Grading Criteria

- [ ] File `assistant_config.json` exists
- [ ] File contains valid JSON
- [ ] Assistant name is "BigBear"
- [ ] Role/position mentions "money" and "partner" concepts
- [ ] Personality includes both "lively" and "rigorous" aspects
- [ ] User nickname is "DoraemonB"
- [ ] Contains a greeting message field with a non-trivial value
- [ ] No fabricated extra user names (false positive check)

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    from pathlib import Path
    import json

    scores = {}
    ws = Path(workspace_path)

    config_file = ws / "assistant_config.json"
    scores["config_file_exists"] = 1.0 if config_file.exists() else 0.0

    if not config_file.exists():
        scores["valid_json"] = 0.0
        scores["assistant_name_correct"] = 0.0
        scores["role_correct"] = 0.0
        scores["personality_correct"] = 0.0
        scores["user_nickname_correct"] = 0.0
        scores["has_greeting"] = 0.0
        scores["no_fabricated_users"] = 0.0
        return scores

    try:
        content = config_file.read_text(encoding="utf-8")
        config = json.loads(content)
        scores["valid_json"] = 1.0
    except Exception:
        scores["valid_json"] = 0.0
        scores["assistant_name_correct"] = 0.0
        scores["role_correct"] = 0.0
        scores["personality_correct"] = 0.0
        scores["user_nickname_correct"] = 0.0
        scores["has_greeting"] = 0.0
        scores["no_fabricated_users"] = 0.0
        return scores

    content_lower = content.lower()

    def flatten_strings(obj):
        """Recursively collect all string values from a JSON object."""
        results = []
        if isinstance(obj, str):
            results.append(obj.lower())
        elif isinstance(obj, dict):
            for v in obj.values():
                results.extend(flatten_strings(v))
        elif isinstance(obj, list):
            for item in obj:
                results.extend(flatten_strings(item))
        return results

    all_strings = flatten_strings(config)
    combined = " ".join(all_strings)

    scores["assistant_name_correct"] = 1.0 if "bigbear" in combined else 0.0

    role_keywords = ["money", "partner", "earning", "wealth", "profit"]
    scores["role_correct"] = 1.0 if any(kw in combined for kw in role_keywords) else 0.0

    personality_lively = any(kw in combined for kw in ["lively", "energetic", "cheerful", "upbeat", "vibrant"])
    personality_rigorous = any(kw in combined for kw in ["rigorous", "thorough", "careful", "precise", "analytical", "logical", "strict"])
    scores["personality_correct"] = 1.0 if (personality_lively and personality_rigorous) else (0.5 if (personality_lively or personality_rigorous) else 0.0)

    scores["user_nickname_correct"] = 1.0 if "doraemonb" in combined else 0.0

    # Greeting: check for a key whose name suggests greeting, OR any string value > 20 chars that reads like a sentence
    greeting_key_found = any(
        any(gk in key.lower() for gk in ["greeting", "welcome", "intro", "message", "hello", "opening", "start"])
        and isinstance(val, str) and len(val) > 10
        for key, val in (config.items() if isinstance(config, dict) else [])
    )
    # Also accept greeting embedded in a nested assistant object
    greeting_value_found = any(len(s) > 20 and any(w in s for w in ["hello", "hi", "hey", "greet", "welcome", "let", "ready", "help"]) for s in all_strings)
    scores["has_greeting"] = 1.0 if (greeting_key_found or greeting_value_found) else 0.0

    # Only flag clearly fabricated placeholder names, not common substrings
    fabricated_names = ["user123", "admin123", "testuser", "fakeuser"]
    has_fabrication = any(fn in content_lower for fn in fabricated_names)
    scores["no_fabricated_users"] = 0.0 if has_fabrication else 1.0

    return scores
```

## LLM Judge Rubric

```yaml
dimensions:
  - name: Configuration Completeness & Accuracy
    weight: 50%
    description: Does the JSON file contain all four required fields with the correct values?
    levels:
      1.0: All four fields present — name "BigBear", role referencing money/partner, personality referencing both lively and rigorous, user nickname "DoraemonB" — with clear, unambiguous keys
      0.75: Three of four fields correct; one field is missing or uses a slightly wrong value (e.g., name is "Big Bear" with a space)
      0.5: Two of four fields correct; notable omissions or mismatches
      0.25: Only one field correct, or values are present but deeply inconsistent with the requirements
      0.0: File is missing, not valid JSON, or contains none of the required field values

  - name: Greeting Message Quality
    weight: 30%
    description: Is the greeting message present, non-trivial, and consistent with the "lively but rigorous" personality?
    levels:
      1.0: Greeting is a complete sentence (>15 chars) that reflects both liveliness (e.g., enthusiastic tone) and rigor (e.g., purposeful framing); addresses the user naturally
      0.75: Greeting is present and >10 chars; reflects one aspect of the personality clearly but not both
      0.5: Greeting field exists with a non-empty value but is generic (e.g., "Hello!") with no personality reflection
      0.25: Greeting key exists but value is trivial (e.g., empty string, single word)
      0.0: No greeting field at all

  - name: JSON Structure Quality
    weight: 20%
    description: Is the JSON well-structured with clear, descriptive keys and no extraneous content?
    levels:
      1.0: Valid JSON with descriptive keys (e.g., "assistant_name", "role", "personality", "user_nickname", "greeting"); no extraneous top-level keys; clean formatting
      0.75: Valid JSON with reasonable keys; one key name is ambiguous but readable (e.g., "char" instead of "personality")
      0.5: Valid JSON but keys are cryptic or inconsistently named; structure is harder to interpret
      0.25: Valid JSON but flat/unorganised (e.g., all values stuffed into a single "config" string)
      0.0: Invalid JSON, or file is empty
```