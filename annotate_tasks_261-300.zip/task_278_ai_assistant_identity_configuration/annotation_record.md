| 序号 | 修改项 | 修改原因 |
|------|--------|--------|
| 1 | 新增 `grading_weights: automated: 1.0, llm_judge: 0.0` | 原文件缺少该字段，维度 E 要求两者之和为 1.0 |
| 2 | **Expected Behavior** 补充 Ground Truth | 原版无明确可验证的答案；补充了文件名、各字段必须包含的值作为 Ground Truth |
| 3 | **grade() 引入 `flatten_strings()` 递归辅助函数** | 原版只搜索二层嵌套，`has_greeting` 等检测逻辑不能处理更深的嵌套结构；改为递归收集所有字符串值，逻辑更健壮 |
| 4 | **grade() `has_greeting` 逻辑修复** | 原版只检查顶层 key 名是否含 greeting 关键词，且要求值长度 >5（门槛过低）；改为：(a) 检查 key 名+值长度 >10，(b) 同时检查任意嵌套字符串值是否形似问候语，两者取或，覆盖更多合理写法 |
| 5 | **grade() `no_fabricated_users` 收窄检测词** | 原 `"john"` 会误匹配 "johnson"、"johnny" 等正常词，`"alice"`/`"bob"` 也可能出现在说明文字中；改为只检测明显的测试占位符 `user123`/`admin123`/`testuser`/`fakeuser`，避免误判 |
| 6 | **grade() `personality_correct` 增加部分得分** | 原版只做全有或全无；改为 lively+rigorous 均有得 1.0，只有其中一个得 0.5，两个都没有得 0.0 |
| 7 | **新增 `## LLM Judge Rubric`**（3 个维度，权重总和 100%） | 原文件完全缺少该部分；新增 Configuration Completeness (50%)、Greeting Quality (30%)、JSON Structure (20%)，各含 5 个等级描述 |