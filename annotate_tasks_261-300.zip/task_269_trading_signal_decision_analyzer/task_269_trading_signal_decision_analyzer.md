---
id: task_269_trading_signal_decision_analyzer
name: Trading Signal Decision Analyzer
category: Finance
subcategory: Trading Strategy and Backtesting
difficulty: medium
external_dependency: none
verification_method: output-check
input_modality: text-only
grading_type: automated
timeout_seconds: 120
workspace_files: []
source_line_number: 8579
source_query: "Given the following trading signal, market data, and portfolio status, decide whether to BUY/SELL/HOLD, choose a position size as a percentage of available capital (0-20%), and assess risk (low/medium/high). Provide a detailed rationale and key factors. Output ONLY valid JSON with fields: action, position_size_pct, risk_assessment, rationale, key_factors.  Signal: SELL; Confidence: MEDIUM; Patterns: bearish_marubozu, double_top. Market: current price $84.65; trend uptrend; volume vs average 1..."
grading_weights:
  automated: 0.6
  llm_judge: 0.4
---

## Prompt

Hey, I need you to analyze this trading setup and give me a decision. Here's what I've got:

Signal info:
- Signal: SELL
- Confidence: MEDIUM
- Patterns: bearish_marubozu, double_top

Market data:
- Current price: $84.65
- Trend: uptrend
- Volume vs average: 1.56x
- ATR: $3.06
- Price vs EMA20: above

My portfolio:
- Cash available: $996,865.30
- Current position: 0 shares
- Total value: $996,865.30

I need you to decide:
1. Trade action (BUY/SELL/HOLD)
2. Position size as % of available capital (0-20%)
3. Risk level (low/medium/high)
4. Detailed rationale explaining your thinking
5. List of key factors you considered

Think about the signal strength, whether the patterns make sense with current market conditions, risk/reward, and appropriate sizing given the confidence level.

Output ONLY valid JSON with these exact fields: action, position_size_pct, risk_assessment, rationale, key_factors

## Expected Behavior

The agent should:
1. Recognize the conflicting signals: a SELL signal with bearish patterns (bearish_marubozu, double_top) against bullish market context (uptrend, price above EMA20, 1.56x volume).
2. Handle the trap: with 0 shares held, a SELL action is only valid if the agent explicitly acknowledges short-selling. The expected correct handling is to either choose HOLD/BUY or, if SELL, explicitly justify it as a short position in the rationale.
3. Evaluate all five market inputs (price, trend, volume, ATR, EMA position) against the signal and patterns.
4. Apply conservative sizing given MEDIUM confidence — position_size_pct should be ≤10% for HOLD/BUY and 0% if HOLD; any SELL without shorting acknowledgement is incoherent.
5. Output syntactically valid JSON containing exactly the five required fields.

**Ground Truth constraints:**
- `action`: one of `"BUY"`, `"SELL"`, `"HOLD"` (case-insensitive)
- `position_size_pct`: number in [0, 20]; expected ≤10 given MEDIUM confidence
- `risk_assessment`: one of `"low"`, `"medium"`, `"high"` (case-insensitive); given conflicting signals, `"medium"` or `"high"` is expected
- `rationale`: string >50 chars addressing the SELL-signal vs uptrend conflict
- `key_factors`: non-empty list; should include at least references to the signal conflict and position state

## Grading Criteria

- [ ] Output is valid JSON containing all five required fields (action, position_size_pct, risk_assessment, rationale, key_factors)
- [ ] `action` value is one of BUY / SELL / HOLD
- [ ] `position_size_pct` is a number in the range 0–20
- [ ] `risk_assessment` is one of low / medium / high
- [ ] `rationale` is a substantive string longer than 50 characters
- [ ] `key_factors` is a non-empty list
- [ ] Decision is coherent: if action is SELL with 0 shares held, rationale explicitly mentions short-selling

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    import json
    import re

    scores = {}

    def _get_last_assistant_text(transcript: list) -> str:
        for event in reversed(transcript):
            if event.get("type") != "message":
                continue
            msg = event.get("message", {})
            if msg.get("role") != "assistant":
                continue
            for item in msg.get("content", []):
                if isinstance(item, dict) and item.get("type") == "text":
                    return item.get("text", "")
            content = msg.get("content", "")
            if isinstance(content, str):
                return content
        return ""

    text = _get_last_assistant_text(transcript)

    # Extract JSON: try greedy match first to handle nested structures, then fallback
    parsed = None
    for pattern in [r'\{[\s\S]*\}', r'\{[\s\S]*?\}']:
        m = re.search(pattern, text)
        if m:
            try:
                parsed = json.loads(m.group())
                break
            except json.JSONDecodeError:
                pass
    if parsed is None:
        try:
            parsed = json.loads(text.strip())
        except json.JSONDecodeError:
            pass

    if parsed is None:
        return {k: 0.0 for k in [
            "valid_json_all_fields",
            "valid_action",
            "valid_position_size",
            "valid_risk_assessment",
            "substantive_rationale",
            "key_factors_nonempty",
            "coherent_logic",
        ]}

    required_fields = {"action", "position_size_pct", "risk_assessment", "rationale", "key_factors"}
    has_all_fields = required_fields.issubset(parsed.keys())
    scores["valid_json_all_fields"] = 1.0 if has_all_fields else round(len(required_fields & parsed.keys()) / len(required_fields), 2)

    action = parsed.get("action", "")
    scores["valid_action"] = 1.0 if str(action).upper() in ["BUY", "SELL", "HOLD"] else 0.0

    pos_size = parsed.get("position_size_pct")
    try:
        pos_num = float(pos_size) if pos_size is not None else -1
        scores["valid_position_size"] = 1.0 if 0 <= pos_num <= 20 else 0.0
    except (ValueError, TypeError):
        scores["valid_position_size"] = 0.0

    risk = parsed.get("risk_assessment", "")
    scores["valid_risk_assessment"] = 1.0 if str(risk).lower() in ["low", "medium", "high"] else 0.0

    rationale = parsed.get("rationale", "")
    scores["substantive_rationale"] = 1.0 if isinstance(rationale, str) and len(rationale) > 50 else 0.0

    factors = parsed.get("key_factors", [])
    scores["key_factors_nonempty"] = 1.0 if isinstance(factors, list) and len(factors) > 0 else 0.0

    action_upper = str(action).upper() if action else ""
    if action_upper == "SELL":
        rationale_lower = str(rationale).lower()
        mentions_short = any(term in rationale_lower for term in ["short", "shorting", "short-sell", "short sell", "short position"])
        scores["coherent_logic"] = 1.0 if mentions_short else 0.0
    else:
        scores["coherent_logic"] = 1.0

    return scores
```

## LLM Judge Rubric

```yaml
dimensions:
  - name: Signal Conflict Analysis
    weight: 40%
    description: Does the rationale demonstrate awareness of the core tension — SELL signal + bearish patterns vs uptrend + price above EMA20 + elevated volume — and reason through it explicitly?
    levels:
      1.0: Clearly identifies both bearish signals (bearish_marubozu, double_top) and bullish context (uptrend, EMA20, volume); weighs them against each other with specific references
      0.75: Acknowledges conflict between signal and trend but only references some of the five market inputs
      0.5: Notes that signals are mixed but analysis is generic without referencing specific patterns or indicators
      0.25: Mentions the SELL signal but largely ignores contradicting market context
      0.0: No evidence of conflict analysis; decision appears arbitrary

  - name: Position State Coherence
    weight: 35%
    description: Does the agent correctly handle the 0-shares trap? A SELL with no position must explicitly justify short-selling; HOLD or BUY are inherently coherent.
    levels:
      1.0: Explicitly addresses the 0-position constraint; if SELL, clearly frames it as a short; if HOLD/BUY, reasoning accounts for why a sell-signal is overridden
      0.75: Mentions the 0-position situation but does not fully integrate it into the decision logic
      0.5: Decision is technically coherent (e.g., HOLD) but the 0-position constraint is never discussed
      0.25: Recommends SELL without acknowledging it requires a short position
      0.0: Decision directly contradicts the portfolio state with no awareness shown

  - name: Output Format Compliance
    weight: 25%
    description: Is the output valid JSON with exactly the five required fields and values in the specified formats?
    levels:
      1.0: Valid JSON; all five fields present; action is BUY/SELL/HOLD; position_size_pct in [0,20]; risk is low/medium/high; rationale >50 chars; key_factors is non-empty list
      0.75: Valid JSON with all five fields but one value is slightly out of spec (e.g., risk written as "Medium" — case mismatch)
      0.5: Valid JSON but one field missing or position_size_pct out of range
      0.25: JSON present but malformed or two or more fields missing/invalid
      0.0: No valid JSON in output
```