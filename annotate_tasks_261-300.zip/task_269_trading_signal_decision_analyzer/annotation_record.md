| 序号 | 修改项 | 修改原因 |
|------|--------|--------|
| 1 | 新增 `grading_weights: automated: 0.6, llm_judge: 0.4` | 原文件缺少该字段，维度 E 要求两者之和为 1.0 |
| 2 | **Expected Behavior** 补充 Ground Truth | 原版无明确可验证的答案约束；补充了各字段的合法取值范围和预期方向（risk 应为 medium/high，position_size_pct ≤10%） |
| 3 | **Grading Criteria** 将 7 条合并对齐至 7 个 score key | 原版 7 条 Grading Criteria 对应 grade() 中 12 个 key（has_action/valid_action 等拆分 key），造成严重的 key 不对齐；重写为一对一：每条 Grading Criteria 对应一个 score key |
| 4 | **grade() 空白零分修复**：`parsed is None` 时改为字典推导式统一返回所有 key 为 0.0 | 原版虽有前置检查，但 key 名称与 Grading Criteria 不一致；修复时同步对齐 key 名 |
| 5 | **grade() JSON 提取逻辑修复**：改为先尝试贪婪匹配 `r'\{[\s\S]*\}'` | 原版第一个 pattern `r'\{[^{}]*\}'` 不匹配嵌套 JSON（如 key_factors 内含对象），会导致有效 JSON 被漏判 |
| 6 | **grade() Key 重命名**：将 `has_action`+`valid_action` 合并为 `valid_action`，其余类似拆分对也合并 | 原 grade() 有 12 个 key 而 Grading Criteria 只有 7 条，不对齐；合并后变为 7 个 key 一一对应 |
| 7 | **grade() 新增部分得分**：`valid_json_all_fields` 按缺少字段比例给分 | 原版只做全有或全无判断；改为按实际包含字段数比例打分，支持部分得分 |
| 8 | **新增 `## LLM Judge Rubric`**（3 个维度，权重总和 100%） | 原文件完全缺少该部分；新增：Signal Conflict Analysis (40%)、Position State Coherence (35%)、Output Format Compliance (25%) |