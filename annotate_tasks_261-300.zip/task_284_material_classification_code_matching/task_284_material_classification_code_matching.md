---
id: task_284_material_classification_code_matching
name: Material Classification Code Matching
category: Data Analysis
subcategory: Text Parsing
difficulty: medium
external_dependency: none
verification_method: unit-test
input_modality: text-only
grading_type: automated
timeout_seconds: 120
workspace_files: []
source_line_number: 3854
source_query: "根据以下物料信息与专家意见，从候选列表中选择最精准匹配的标准分类编码；若无匹配则输出 NO_MATCH。仅返回分类编码或 NO_MATCH。  物料信息：名称：交流接触器；规格：ABB，A26-30-10，线圈220V。 专家意见：ABB A26-30-10 交流接触器为三相电磁式开关电器，额定电流26A，3组主触点（常开）+1组辅助触点（常开），线圈控制电压AC220V。用于远距离频繁接通/分断电动机及电力线路，实现自动控制与过载保护配合功能。  候选列表： 1.【编码: 33010301】 33 电工元器件 -> 3301 低压电器主要元件 -> 330103 接触器 -> 交流接触器 2.【编码: 33010308】 33 电工元器件 -> 3301 低压电器主要元件 -> 330103 接触器 -> 抗晃电交流接触器 3.【编码: 33810101】 33 电工元器件 -> 3381 电器元器件配件 -> 338101 接触器配件 -> 交流接触器配件 4.【编码: 33010302】 33 电工元器件 -> 3301 低压电器主要元件 -> 330103 接触器 -> ..."
grading_weights:
  automated: 1.0
  llm_judge: 0.0
---

## Prompt

Hey, I need help matching a material item to the correct standard classification code from our MDM (Master Data Management) system.

Here's the material info:
- Name: AC Contactor
- Specs: ABB, A26-30-10, coil 220V

Expert notes: The ABB A26-30-10 AC contactor is a three-phase electromagnetic switching device, rated current 26A, with 3 main contact sets (normally open) + 1 auxiliary contact set (normally open), coil control voltage AC220V. Used for remote frequent connection/disconnection of motors and power lines, implementing automatic control and overload protection coordination functions.

Here are the candidate classification codes:

```
1. [Code: 33010301] 33 Electrical Components -> 3301 Low-voltage Main Elements -> 330103 Contactors -> AC Contactor
2. [Code: 33010308] 33 Electrical Components -> 3301 Low-voltage Main Elements -> 330103 Contactors -> Anti-sag AC Contactor
3. [Code: 33810101] 33 Electrical Components -> 3381 Electrical Component Accessories -> 338101 Contactor Accessories -> AC Contactor Accessories
4. [Code: 33010302] 33 Electrical Components -> 3301 Low-voltage Main Elements -> 330103 Contactors -> DC Contactor
5. [Code: 38140210] 38 General Instruments -> 3814 Electronic Measuring Instruments -> 381402 Electronic Component Testers -> AC Contactor Parameter Tester
6. [Code: 33010303] 33 Electrical Components -> 3301 Low-voltage Main Elements -> 330103 Contactors -> Vacuum Contactor
7. [Code: 33010306] 33 Electrical Components -> 3301 Low-voltage Main Elements -> 330103 Contactors -> Marine Contactor
8. [Code: 33010305] 33 Electrical Components -> 3301 Low-voltage Main Elements -> 330103 Contactors -> Electronic Contactor
9. [Code: 33010304] 33 Electrical Components -> 3301 Low-voltage Main Elements -> 330103 Contactors -> Reversing Contactor
10. [Code: 31090501] 31 Power Equipment -> 3109 High-voltage Equipment -> 310905 High-voltage Contactors -> High-voltage Contactor
11. [Code: 36180601] 36 Electronic Products -> 3618 Electronic Components -> 361806 Electronic Equipment Relays -> Electromagnetic Relay
12. [Code: 33040114] 33 Electrical Components -> 3304 Relays -> 330401 Control Relays -> Contactor-type Relay
13. [Code: 33040219] 33 Electrical Components -> 3304 Relays -> 330402 Protection Relays -> Excitation Relay
14. [Code: 41020601] 41 Welding Materials -> 4102 Welding Wire -> 410206 Silver Alloy Welding Wire -> Silver Alloy Wire
15. [Code: 33040111] 33 Electrical Components -> 3304 Relays -> 330401 Control Relays -> AC/DC Relay
16. [Code: 33040101] 33 Electrical Components -> 3304 Relays -> 330401 Control Relays -> Thermal Relay
17. [Code: 33040201] 33 Electrical Components -> 3304 Relays -> 330402 Protection Relays -> Intermediate Relay
18. [Code: 33040221] 33 Electrical Components -> 3304 Relays -> 330402 Protection Relays -> Gas Relay
19. [Code: 33040108] 33 Electrical Components -> 3304 Relays -> 330401 Control Relays -> Temperature Relay
20. [Code: 33040210] 33 Electrical Components -> 3304 Relays -> 330402 Protection Relays -> Current Relay
```
Rules:
- Pick the most precise match
- You can select a generic/other category as fallback if needed
- Don't misclassify raw materials as finished products
- If nothing matches, output NO_MATCH

Just give me the classification code (like 33010301) or NO_MATCH, nothing else.

## Expected Behavior

The agent should:
1. Recognize this is a standard AC contactor (not anti-sag, not vacuum, not marine, not high-voltage, not an accessory, not a tester)
2. Match it to code **33010301** which is the generic "AC Contactor" category
3. Avoid selecting relay categories (this is a contactor, not a relay)
4. Avoid selecting the accessories category (33810101 — this is the main device)
5. Output only the code `33010301` with no extra text

**Ground Truth:** The only correct output is `33010301`.

Tested capabilities: classification reasoning, distinguishing between similar categories, following strict output format requirements.

## Grading Criteria

- [ ] Output contains the correct code 33010301
- [ ] Output does not contain any wrong codes from the candidate list
- [ ] Output is clean (just the code, no extra explanation)
- [ ] Output is not a relay category code (33040xxx or 36180601)
- [ ] Output is not the accessories code (33810101)

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    scores = {}

    def _get_last_assistant_text(transcript: list) -> str:
        for event in reversed(transcript):
            if event.get("type") != "message":
                continue
            msg = event.get("message", {})
            if msg.get("role") != "assistant":
                continue
            for item in msg.get("content", []):
                if isinstance(item, dict) and item.get("type") == "text":
                    return item.get("text", "")
            content = msg.get("content", "")
            if isinstance(content, str):
                return content
        return ""

    output = _get_last_assistant_text(transcript).strip()
    correct_code = "33010301"

    wrong_codes = [
        "33010308", "33810101", "33010302", "38140210", "33010303",
        "33010306", "33010305", "33010304", "31090501", "36180601",
        "33040114", "33040219", "41020601", "33040111", "33040101",
        "33040201", "33040221", "33040108", "33040210", "NO_MATCH"
    ]

    scores["correct_code_present"] = 1.0 if correct_code in output else 0.0

    has_wrong = any(wc in output for wc in wrong_codes)
    scores["no_wrong_codes"] = 0.0 if has_wrong else 1.0

    is_clean = output.strip() == correct_code
    scores["clean_output"] = 1.0 if is_clean else (0.5 if correct_code in output else 0.0)

    relay_codes = ["33040114", "33040219", "33040111", "33040101",
                   "33040201", "33040221", "33040108", "33040210", "36180601"]
    scores["not_misclassified_as_relay"] = 0.0 if any(rc in output for rc in relay_codes) else 1.0

    scores["not_misclassified_as_accessory"] = 0.0 if "33810101" in output else 1.0

    return scores
```

## LLM Judge Rubric

```yaml
dimensions:
  - name: Answer Correctness
    weight: 60%
    description: Did the agent select the correct classification code 33010301?
    levels:
      1.0: Output is exactly "33010301" with no other content
      0.75: Output contains "33010301" as the clear answer but includes a brief explanation
      0.5: Output identifies the correct category (AC Contactor, low-voltage) but cites a wrong code or is ambiguous
      0.25: Output selects a plausible but wrong contactor sub-type code (e.g., 33010308 anti-sag, 33010304 reversing)
      0.0: Output selects a completely wrong category (relay, accessory, high-voltage, welding material), outputs NO_MATCH, or is blank

  - name: Distinction from Similar Categories
    weight: 40%
    description: Does the agent correctly distinguish the standard AC contactor from adjacent categories (relay, accessory, anti-sag, high-voltage)?
    levels:
      1.0: Explicitly rules out relay codes, accessory code (33810101), anti-sag (33010308), and high-voltage (31090501); selects the generic AC Contactor code
      0.75: Avoids relay and accessory codes; may not explicitly address anti-sag distinction but selects correctly
      0.5: Avoids relay codes but selects an accessory or anti-sag code; shows partial understanding of the hierarchy
      0.25: Selects a relay or electromagnetic relay code, showing confusion between contactor and relay concepts
      0.0: Selects a completely unrelated code (welding wire, tester, gas relay) or outputs NO_MATCH with no reasoning
```