---
id: task_283_competitor_website_change_analysis
name: Competitor Website Change Analysis
category: Data Analysis
subcategory: Text Parsing
difficulty: medium
external_dependency: none
verification_method: output-check
input_modality: text-only
grading_type: hybrid
grading_weights:
  automated: 0.4
  llm_judge: 0.6
timeout_seconds: 120
workspace_files: []
source_line_number: 9419
source_query: "Analyze the following change detected on a competitor's website and respond with valid JSON matching the provided schema.  Target URL: https://siteimpact.com/ Change magnitude: 0.74% Sections changed: \"speak with a marketing expert\"  Diff: --- previous +++ current @@ -238,7 +238,7 @@ ### speak with a marKETING EXPERT: * [Phone: 954-982-7900](tel:9549827900) - [Email: [email protected]](https://siteimpact.com/cdn-cgi/l/email-protection#2c5f4d40495f6c5f45584945415c4d4f58024f4341) + [Email: [e..."
---

## Prompt

Hey, I need you to analyze a change we detected on a competitor's website. We're tracking siteimpact.com and our monitoring tool picked up a small update.

Here's the diff:

```diff
--- previous
+++ current
@@ -238,7 +238,7 @@
 ### speak with a marKETING EXPERT:
 
 *   [Phone: 954-982-7900](tel:9549827900)
-*   [Email: [email protected]](https://siteimpact.com/cdn-cgi/l/email-protection#2c5f4d40495f6c5f45584945415c4d4f58024f4341)
+*   [Email: [email protected]](https://siteimpact.com/cdn-cgi/l/email-protection#6013010c05132013091405090d100103144e030f0d)
 *   [Do Not Sell My Personal Information](https://siteimpact.com/cali_compliance.php)
 
 [Contact Us](https://siteimpact.com/contact-us.php)
```
Target URL: https://siteimpact.com/
Change magnitude: 0.74%
Section affected: "speak with a marketing expert"

Output your analysis as JSON with this structure:
```json
{
  "summary": "1-2 sentence summary of the change",
  "analysis": "Detailed analysis of what this change means competitively",
  "significance": 0.0-1.0,
  "action_items": ["..."],
  "change_type": "content|price|layout|seo|new_page|removed"
}
```
Save it to `analysis.json`.

## Expected Behavior

The agent should:
1. Read the diff carefully and identify that the contact email address was updated in the "speak with a marketing expert" section
2. Correctly classify `change_type` as `"content"`
3. Assign a significance score reflecting the minor nature of the change (approximately 0.1–0.4)
4. Note in the analysis that this may indicate organizational restructuring, a shift in contact routing, or a sales-focus change
5. Provide practical action_items for competitive intelligence purposes
6. Output valid JSON with all 5 required fields, saved to `analysis.json`

**Trap to handle:** The diff only shows an email link change. The phone number (954-982-7900) did NOT change. The agent must not fabricate a phone number change or any other change not present in the diff.

**Ground Truth:** `analysis.json` must be valid JSON with all 5 fields; `change_type` must be `"content"`; `significance` must be a float in [0.0, 1.0]; `action_items` must be a non-empty array; `summary` and `analysis` must reference an email change (not fabricate phone or price changes).

## Grading Criteria

- [ ] File `analysis.json` exists
- [ ] Output is valid JSON with all 5 required fields
- [ ] `change_type` is "content"
- [ ] `significance` is a float between 0.0 and 1.0
- [ ] `action_items` is a non-empty array
- [ ] Summary or analysis identifies an email change
- [ ] Does not fabricate changes not in the diff (e.g., phone number change, price change)

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    from pathlib import Path
    import json

    scores = {}
    ws = Path(workspace_path)

    analysis_file = ws / "analysis.json"
    scores["file_exists"] = 1.0 if analysis_file.exists() else 0.0

    if not analysis_file.exists():
        scores["valid_json_all_fields"] = 0.0
        scores["change_type_correct"] = 0.0
        scores["significance_valid"] = 0.0
        scores["action_items_nonempty"] = 0.0
        scores["identifies_email_change"] = 0.0
        scores["no_fabrication"] = 0.0
        return scores

    try:
        data = json.loads(analysis_file.read_text())
        scores["valid_json"] = 1.0
    except Exception:
        scores["valid_json_all_fields"] = 0.0
        scores["change_type_correct"] = 0.0
        scores["significance_valid"] = 0.0
        scores["action_items_nonempty"] = 0.0
        scores["identifies_email_change"] = 0.0
        scores["no_fabrication"] = 0.0
        return scores

    required_fields = ["summary", "analysis", "significance", "action_items", "change_type"]
    present = sum(1 for f in required_fields if f in data)
    scores["valid_json_all_fields"] = present / len(required_fields)

    change_type = data.get("change_type", "")
    scores["change_type_correct"] = 1.0 if change_type == "content" else 0.0

    sig = data.get("significance")
    scores["significance_valid"] = 1.0 if isinstance(sig, (int, float)) and 0.0 <= sig <= 1.0 else 0.0

    action_items = data.get("action_items")
    scores["action_items_nonempty"] = 1.0 if isinstance(action_items, list) and len(action_items) > 0 else 0.0

    full_text = json.dumps(data).lower()
    email_terms = ["email", "sales@", "info@", "mail", "@siteimpact"]
    scores["identifies_email_change"] = 1.0 if any(t in full_text for t in email_terms) else 0.0

    fabrication_indicators = ["phone number change", "phone changed", "954-982-7901", "new product", "removed page", "price change"]
    has_fabrication = any(ind in full_text for ind in fabrication_indicators)
    scores["no_fabrication"] = 0.0 if has_fabrication else 1.0

    return scores
```

## LLM Judge Rubric

### Criterion 1: Accuracy of Change Identification (Weight: 35%)

**Score 1.0**: Analysis correctly identifies the email address as the sole change; accurately notes the specific addresses involved; does not fabricate any other changes (phone, price, layout, etc.).
**Score 0.75**: Correctly identifies an email change but is vague about specifics (e.g., doesn't mention the nature of the address change); no fabricated changes.
**Score 0.5**: Identifies a contact-related change but conflates it with other elements (e.g., mentions the phone number as also changing when it did not).
**Score 0.25**: Misidentifies the primary change (e.g., says it's a layout change) but incidentally mentions email.
**Score 0.0**: Does not identify the email change at all, or fabricates significant changes not present in the diff (e.g., phone number change, price update).

### Criterion 2: Quality of Competitive Analysis (Weight: 30%)

**Score 1.0**: Analysis offers substantive competitive insight — e.g., connecting the email change to a potential sales restructuring, shift in inbound routing strategy, or signal of organizational focus; reasoning is specific to the observed change.
**Score 0.75**: Analysis provides reasonable competitive commentary but is somewhat generic (e.g., "they updated their contact info" without deeper interpretation).
**Score 0.5**: Analysis acknowledges the change but offers minimal or superficial competitive interpretation.
**Score 0.25**: Analysis is mostly a restatement of the diff with no competitive framing.
**Score 0.0**: No meaningful analysis; content is placeholder text, completely off-topic, or fabricated.

### Criterion 3: Appropriate Significance Rating (Weight: 20%)

**Score 1.0**: Significance score is in the 0.1–0.4 range, appropriately reflecting a minor contact email update with low competitive impact.
**Score 0.75**: Significance is in the 0.05–0.5 range; slightly outside the ideal range but defensibly calibrated.
**Score 0.5**: Significance is between 0.5 and 0.7 — somewhat overstated for a minor email swap but not egregious.
**Score 0.25**: Significance is above 0.7, significantly overstating the importance of a routine email change.
**Score 0.0**: Significance is missing, not a number, outside [0,1], or is 0.0 (understating to zero).

### Criterion 4: Actionable Recommendations (Weight: 15%)

**Score 1.0**: Action items are specific, practical, and directly related to the observed change (e.g., "update competitor contact records", "monitor for further sales team restructuring signals", "note potential shift to sales-led outreach").
**Score 0.75**: Action items are relevant to competitive intelligence but somewhat generic (e.g., "continue monitoring the website").
**Score 0.5**: Action items exist but are vague or only loosely connected to the specific change observed.
**Score 0.25**: Only one action item present, or items are unrelated to email/contact changes.
**Score 0.0**: No action items, empty array, or action items are entirely fabricated or nonsensical.
```