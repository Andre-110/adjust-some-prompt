| 序号 | 修改项 | 修改原因 |
|------|--------|--------|
| 1 | **Prompt 中的邮件地址替换为 obfuscated 形式** | 原 Prompt 直接显示 `[email protected]` 和 `[email protected]`，将核心答案（info→sales 的变化）完全泄露给被评测 agent；改为使用 CDN 混淆保护格式（与原始 source_query 一致），不直接暴露邮件地址内容，符合真实网站监控场景 |
| 2 | **Expected Behavior** 明确陷阱说明和 Ground Truth | 原版陷阱描述不够显式；补充了"phone number 未变，不得捏造"的陷阱说明，以及包含 5 个字段约束的 Ground Truth |
| 3 | **Grading Criteria** 重组为 7 条，与 grade() 7 个 key 一一对齐 | 原 8 条 Grading Criteria 对应 grade() 中只有 6-7 个 key（第 4 条"identifies email change"无 key，第 7 条"action_items is array"与"non-empty"语义不同）；重写后：`valid_json_all_fields`、`change_type_correct`、`significance_valid`、`action_items_nonempty`、`identifies_email_change`、`no_fabrication` 六 key 加 `file_exists` 共 7 条完全对应 |
| 4 | **grade() `has_all_fields` 改为部分得分并重命名为 `valid_json_all_fields`** | 原版全有或全无；改为 `present/len(required_fields)` 按比例给分，key 名更准确 |
| 5 | **grade() 新增 `identifies_email_change` key** | 原版无对应检测；补充检测 summary/analysis 是否提及 email 关键词，与 Grading Criteria 第 6 条对齐 |
| 6 | **grade() `action_items_is_array` 改为 `action_items_nonempty`** | 原版只检查是否为 list，空 list 也得满分；改为要求非空，与 Grading Criteria 第 5 条语义对齐 |
| 7 | **grade() `no_fabrication` 修复 typo**：`"phone number chang"` → `"phone number change"` | 原字符串缺少字母 "e"，无法匹配 "phone number change" |
| 8 | **LLM Judge Rubric 补全各等级描述** | 原 4 个维度每个只有一句话，完全缺少 1.0/0.75/0.5/0.25/0.0 各等级的具体说明，违反维度 E 第 3 条；为每个维度补全了全部 5 个等级描述 |