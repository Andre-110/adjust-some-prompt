---
id: task_263_python_3_project_structure_generator
name: Python 3 Project Structure Generator
category: System Administration
subcategory: Software and Environment Management
difficulty: easy
external_dependency: none
verification_method: unit-test
input_modality: text-only
grading_type: automated
timeout_seconds: 120
workspace_files: []
source_line_number: 6450
source_query: "生成一个 Python 3 项目的基础目录结构，必须包含 tests/ 测试用例文件夹。"
---

## Prompt

Hey, can you set up a basic Python 3 project structure for me? I need it to have a proper layout with a tests folder - that's really important since we're doing TDD on this project.

The project should be called `myproject` and include the usual stuff like a main package folder, config files, and make sure there's a tests/ directory with at least a placeholder test file so pytest can discover it.

Just create everything in the current directory.

## Expected Behavior

The agent should create a standard Python 3 project structure in the current working directory, including:
1. A main package directory `myproject/` containing an `__init__.py` to make it a proper Python package
2. A `tests/` directory with at least one `.py` test file (e.g. `test_placeholder.py` or `__init__.py`) so that pytest can discover it
3. A project configuration file: either `setup.py` or `pyproject.toml`
4. A `README.md` (or `README.rst`) file
5. Optionally, other conventional files such as `requirements.txt`, `.gitignore`, etc.

Ground Truth（最小合格目录结构）:
```
./
├── myproject/
│   └── __init__.py
├── tests/
│   └── (at least one .py file)
├── setup.py or pyproject.toml
└── README.md or README.rst
```

The agent should NOT introduce unnecessary external framework dependencies (e.g. Django, Flask) — this is a plain Python project.

## Grading Criteria

- [ ] Main package directory `myproject/` exists
- [ ] `myproject/__init__.py` exists
- [ ] Tests directory `tests/` exists
- [ ] `tests/` contains at least one `.py` file
- [ ] Project has a setup file (`setup.py` or `pyproject.toml`)
- [ ] Project has a README file (`README.md`, `README.rst`, or `README`)
- [ ] No unnecessary framework dependencies introduced (e.g. Django, Flask, FastAPI in setup/requirements files)

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    from pathlib import Path

    scores = {}
    ws = Path(workspace_path)

    # 1. Main package directory exists
    myproject_dir = ws / "myproject"
    scores["main_package_exists"] = 1.0 if myproject_dir.is_dir() else 0.0

    # 2. Package __init__.py exists
    pkg_init = myproject_dir / "__init__.py"
    scores["package_init_exists"] = 1.0 if pkg_init.exists() else 0.0

    # 3. Tests directory exists
    tests_dir = ws / "tests"
    scores["tests_dir_exists"] = 1.0 if tests_dir.is_dir() else 0.0

    # 4. Tests directory has at least one .py file
    if tests_dir.is_dir():
        py_files = list(tests_dir.glob("*.py"))
        scores["tests_has_py_file"] = 1.0 if len(py_files) >= 1 else 0.0
    else:
        scores["tests_has_py_file"] = 0.0

    # 5. Setup file exists
    setup_py = ws / "setup.py"
    pyproject = ws / "pyproject.toml"
    scores["setup_file_exists"] = 1.0 if setup_py.exists() or pyproject.exists() else 0.0

    # 6. README exists
    readme_md = ws / "README.md"
    readme_rst = ws / "README.rst"
    readme_txt = ws / "README"
    scores["readme_exists"] = 1.0 if readme_md.exists() or readme_rst.exists() or readme_txt.exists() else 0.0

    # 7. No unnecessary framework dependencies in config/requirements files
    config_files = [ws / "setup.py", ws / "pyproject.toml", ws / "requirements.txt", ws / "setup.cfg"]
    fake_frameworks = ["django", "flask", "fastapi", "tornado"]
    config_contents = ""
    for f in config_files:
        if f.is_file():
            try:
                config_contents += f.read_text(encoding="utf-8").lower()
            except Exception:
                pass
    unnecessary_complexity = any(fw in config_contents for fw in fake_frameworks)
    scores["no_unnecessary_frameworks"] = 0.0 if unnecessary_complexity else 1.0

    return scores
```