| 序号 | 修改项 | 修改原因 |
|---|---|---|
| 1  | Expected Behavior 补充 Ground Truth 最小合格目录结构的树形图                                                                  | 原文缺少可验证对错的明确答案，只有笼统描述                                                                     |
| 2  | Expected Behavior 补充"不应引入不必要的框架依赖"说明                                                                            | 原文 Grading Criteria 和 grade() 都检查了此项，但 Expected Behavior 中未提及，解题路径不完整                     |
| 3  | Grading Criteria 第 6 条增加 `README`（无扩展名）作为可接受格式                                                                  | 原 Criteria 只写了 `README.md or README.rst`，但 grade() 中同时接受裸 `README`，Criteria 与 grade() 不对齐 |
| 4  | grade() 中 `no_unnecessary_frameworks` 检查范围从全目录递归扫描改为仅扫描配置文件（setup.py/pyproject.toml/requirements.txt/setup.cfg） | 原逻辑扫描所有 `.py/.txt/.toml/.cfg` 文件内容，如果 README 或代码注释中提到 "unlike flask" 等会误判为引入了框架，产生假阳性     |
