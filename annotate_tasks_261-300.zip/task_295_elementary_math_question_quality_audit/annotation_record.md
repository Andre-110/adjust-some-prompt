| 序号 | 修改项 | 修改原因 |
|---|---|---|
| 1  | `difficulty: hard -> medium` | 任务核心是核验单道选择题并识别一个明确的 SVG 泄露陷阱，复杂度不足以支撑 hard，更符合 medium。                                                               |
| 2  | 重写 `## Prompt`               | 原 Prompt 虽基本可用，但输出 schema 与 source_query 中的判错语义不完全一致，且“exact format”表述过硬、不够自然；同时补充了“issues 仅填适用项”“无问题时空数组”等约束，使指令更清晰。 |
| 3  | 补充并细化 `## Expected Behavior` | 原 Expected Behavior 有正确结论，但对“为何必须判错”“issues 应只包含 svg_error”“confidence 合理取值”等说明不够完整。                                  |
| 4  | 重写 `## Grading Criteria`     | 原条目与 `grade()` 返回 key 数量不一致，违反“Key 对齐”；同时部分条目区分度偏弱，已改为 6 条、可独立验证。                                                     |
| 5  | 重写 `## Automated Checks`     | 原 `grade()` 存在 key 未与 Criteria 一一对应、JSON 抽取较脆弱、confidence 大小写不容忍、未单独校验 reason 是否提到 SVG 泄露等问题；已增强容错并保证空白输出全 0。         |
| 6  | 调整 `## LLM Judge Rubric`     | 原 rubric 基本合格，但“Reasoning Quality”要求与“只输出 JSON”存在轻微张力，已改成更贴近该任务实际可观察输出的维度；并保留权重和为 100%。                               |
| 7  | 轻微修正 `source_query`          | 使其与当前任务文件中的英文输出 schema 更一致，减少元数据与正文不一致。