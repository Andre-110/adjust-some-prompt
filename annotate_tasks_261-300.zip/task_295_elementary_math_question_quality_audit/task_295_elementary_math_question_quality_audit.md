---
id: task_295_elementary_math_question_quality_audit
name: Elementary Math Question Quality Audit
category: Data Analysis
subcategory: Quality Auditing and Diagnostics
difficulty: medium
external_dependency: none
verification_method: rubric
input_modality: text-only
grading_type: hybrid
timeout_seconds: 180
grading_weights:
  automated: 0.4
  llm_judge: 0.6
workspace_files: []
source_line_number: 6242
source_query: "Act as a second-pass reviewer for an elementary math multiple-choice question previously flagged as problematic. Check stem clarity and completeness; verify there are 3-4 clear, non-duplicate options; solve the problem to verify the marked answer; confirm any explanation matches the marked answer and the stem; if SVG is present, inspect clarity, labeling, completeness, consistency, and especially whether it leaks the answer. If any uncertainty exists, mark the question as wrong. Output exactly one JSON object with question_id, is_really_wrong, confidence, issues, and reason."
---

## Prompt

A first-pass reviewer flagged the following elementary math multiple-choice question as problematic. Please act as the second reviewer and decide whether the question is actually flawed.

Check all of the following:
- whether the question stem is complete, clear, and unambiguous;
- whether there are 3-4 options, with no duplicates and no confusing wording;
- whether the marked correct answer matches the result obtained from solving the problem;
- whether the explanation (if provided) is correct and consistent with both the stem and the marked answer;
- if an SVG image is provided, whether it is clear, complete, properly labeled, consistent with the problem, and whether it leaks the answer or key reasoning.

Important rule:
- If anything is uncertain, treat the item as truly wrong (`is_really_wrong=true`).
- Only return `is_really_wrong=false` if every checked component is fully acceptable.
- If the SVG directly reveals the answer, that alone is enough to mark the item as wrong.

Question details:

Question ID: 172990

Question stem: "5 pears are packed into each basket. 8 baskets are filled completely. How many pears are there in total?"

Options:
- A. 35 pears
- B. 40 pears
- C. 45 pears
- D. 50 pears

Marked correct answer: B

SVG code:
```svg
<svg width='300' height='150' xmlns='http://www.w3.org/2000/svg'>
  <rect x='0' y='0' width='300' height='150' fill='#f9f9f9' />
  <text x='10' y='20' font-family='Arial' font-size='16' fill='#333'>5 pears per basket</text>
  <text x='10' y='40' font-family='Arial' font-size='14' fill='#333'>Filled 8 baskets</text>
  <text x='10' y='60' font-family='Arial' font-size='14' fill='#0066cc'>Total: 40 pears</text>
  <g transform='translate(10, 80)'>
    <circle cx='15' cy='10' r='5' fill='#ccff66' />
    <circle cx='30' cy='10' r='5' fill='#ccff66' />
    <circle cx='45' cy='10' r='5' fill='#ccff66' />
    <circle cx='60' cy='10' r='5' fill='#ccff66' />
    <circle cx='75' cy='10' r='5' fill='#ccff66' />
    <text x='15' y='30' font-family='Arial' font-size='10' fill='#333'>Basket 1</text>
    <circle cx='100' cy='10' r='5' fill='#ccff66' />
    <circle cx='115' cy='10' r='5' fill='#ccff66' />
    <circle cx='130' cy='10' r='5' fill='#ccff66' />
    <circle cx='145' cy='10' r='5' fill='#ccff66' />
    <circle cx='160' cy='10' r='5' fill='#ccff66' />
    <text x='100' y='30' font-family='Arial' font-size='10' fill='#333'>Basket 2</text>
    <text x='130' y='50' font-family='Arial' font-size='12' fill='#666'>... 8 baskets total</text>
  </g>
</svg>
````

Explanation: "5 pears per basket, 8 baskets filled, so total is 5×8=40 pears."

Return exactly one JSON object and nothing else, using this schema:

```json
{
  "question_id": 172990,
  "is_really_wrong": true,
  "confidence": "high",
  "issues": ["svg_error"],
  "reason": "Brief reason under 50 words."
}
```

Requirements for the JSON output:

* `question_id` must be `172990`
* `is_really_wrong` must be a boolean
* `confidence` must be one of: `"high"`, `"medium"`, `"low"`
* `issues` must be an array containing only applicable issue types from:

  * `"stem_error"`
  * `"options_error"`
  * `"answer_error"`
  * `"explanation_error"`
  * `"svg_error"`
* use an empty array if there are no issues
* `reason` must be under 50 words

## Expected Behavior

The agent should:

1. Read the full item and check each required component: stem, options, marked answer, explanation, and SVG.
2. Determine that the stem is clear and solvable, the four options are complete and non-duplicative, and the marked answer `B` matches the correct computation `5 × 8 = 40`.
3. Determine that the explanation is consistent with the stem and the marked answer.
4. Notice the critical trap: the SVG explicitly displays `Total: 40 pears`, which directly reveals the answer to the student before solving.
5. Correctly treat this SVG answer leak as a sufficient defect to mark the item as truly wrong.
6. Return a single valid JSON object with:

   * `question_id: 172990`
   * `is_really_wrong: true`
   * `confidence`: a valid value, ideally `high`
   * `issues`: containing `svg_error` and no unrelated issue types
   * `reason`: a concise statement explaining that the SVG leaks the answer

Ground truth:

* The arithmetic is correct.
* The marked answer is correct.
* The explanation is correct.
* The item should still be judged wrong overall because the SVG leaks the answer.
* Therefore the correct overall judgment is:

  * `is_really_wrong = true`
  * `issues = ["svg_error"]`

Tested capabilities:

* structured QA checking
* arithmetic verification
* consistency checking across fields
* answer-leak detection in SVG or visual text
* strict JSON-only response compliance

## Grading Criteria

* [ ] Returns a valid JSON object as the only output
* [ ] Sets `question_id` to `172990`
* [ ] Sets `is_really_wrong` to `true`
* [ ] Includes `svg_error` in `issues`
* [ ] Uses a valid `confidence` value (`high`, `medium`, or `low`)
* [ ] `reason` explicitly mentions that the SVG reveals, leaks, or gives away the answer

## Automated Checks

````python
def grade(transcript: list, workspace_path: str) -> dict:
    import json
    import re

    SCORE_KEYS = [
        "valid_json_only",
        "correct_question_id",
        "is_really_wrong_true",
        "includes_svg_error",
        "valid_confidence",
        "reason_mentions_svg_leak",
    ]

    def zero_scores():
        return {k: 0.0 for k in SCORE_KEYS}

    def get_last_assistant_text(transcript: list) -> str:
        for event in reversed(transcript):
            if event.get("type") != "message":
                continue
            msg = event.get("message", {})
            if msg.get("role") != "assistant":
                continue

            content = msg.get("content", "")
            if isinstance(content, str):
                return content.strip()

            if isinstance(content, list):
                parts = []
                for item in content:
                    if isinstance(item, dict) and item.get("type") == "text":
                        parts.append(item.get("text", ""))
                return "\n".join(parts).strip()

        return ""

    text = get_last_assistant_text(transcript)
    if not text:
        return zero_scores()

    scores = zero_scores()

    # Accept either raw JSON or a single fenced JSON block; reject extra prose.
    candidate = text.strip()

    fenced_match = re.fullmatch(
        r"```(?:json)?\s*(\{.*\})\s*```",
        candidate,
        flags=re.DOTALL | re.IGNORECASE,
    )
    if fenced_match:
        candidate = fenced_match.group(1).strip()

    if not (candidate.startswith("{") and candidate.endswith("}")):
        return scores

    try:
        result = json.loads(candidate)
    except Exception:
        return scores

    scores["valid_json_only"] = 1.0

    # question_id
    scores["correct_question_id"] = 1.0 if result.get("question_id") == 172990 else 0.0

    # is_really_wrong
    scores["is_really_wrong_true"] = 1.0 if result.get("is_really_wrong") is True else 0.0

    # issues
    issues = result.get("issues")
    if isinstance(issues, list):
        normalized = []
        for item in issues:
            s = str(item).strip().lower()
            s = s.replace(" ", "").replace("-", "_")
            normalized.append(s)
        has_svg_error = any(
            s in {"svg_error", "svgerror", "svg错"} or ("svg" in s and "error" in s)
            for s in normalized
        )
        scores["includes_svg_error"] = 1.0 if has_svg_error else 0.0
    else:
        scores["includes_svg_error"] = 0.0

    # confidence (case-insensitive tolerance)
    confidence = str(result.get("confidence", "")).strip().lower()
    scores["valid_confidence"] = 1.0 if confidence in {"high", "medium", "low"} else 0.0

    # reason mentions SVG answer leak
    reason = str(result.get("reason", "")).strip().lower()
    leak_patterns = [
        "svg",
        "reveal",
        "reveals",
        "leak",
        "leaks",
        "give away",
        "gives away",
        "shows the answer",
        "answer leak",
    ]
    if "svg" in reason and any(p in reason for p in leak_patterns[1:]):
        scores["reason_mentions_svg_leak"] = 1.0
    else:
        scores["reason_mentions_svg_leak"] = 0.0

    return scores
````

## LLM Judge Rubric

### Criterion 1: Overall Judgment Correctness (Weight: 35%)

**Score 1.0**: Correctly concludes the item is truly wrong overall because the SVG leak is a disqualifying defect, even though the math and marked answer are correct.
**Score 0.75**: Reaches the correct overall judgment but gives only a partially clear basis.
**Score 0.5**: Shows mixed understanding of the defect and overall judgment.
**Score 0.25**: Detects some issue but reaches an uncertain or weakly justified conclusion.
**Score 0.0**: Incorrectly concludes the item is not wrong overall.

### Criterion 2: SVG Leak Identification (Weight: 30%)

**Score 1.0**: Clearly identifies that the SVG directly reveals the answer (e.g., by stating `Total: 40 pears`), and correctly flags this as `svg_error`.
**Score 0.75**: Identifies an SVG problem and implies answer leakage, but explanation is somewhat imprecise.
**Score 0.5**: Mentions the SVG but does not clearly connect it to answer leakage.
**Score 0.25**: Notes the SVG superficially without identifying the true defect.
**Score 0.0**: Misses the SVG issue entirely.

### Criterion 3: Output Schema Compliance (Weight: 20%)

**Score 1.0**: Returns exactly one valid JSON object with all required fields and correct data types.
**Score 0.75**: Minor formatting issues but still mostly valid and parseable.
**Score 0.5**: JSON intent is clear, but one or more required fields are malformed or missing.
**Score 0.25**: Significant schema problems make the output hard to use.
**Score 0.0**: Output is not valid JSON or not a single JSON object.

### Criterion 4: Field-Level Precision (Weight: 15%)

**Score 1.0**: Uses the correct `question_id`, sets `is_really_wrong=true`, includes `svg_error`, uses a valid confidence label, and gives a concise reason focused on the SVG leak.
**Score 0.75**: Most field values are correct, with only a minor mistake or omission.
**Score 0.5**: Some required field values are correct, but others are inaccurate or incomplete.
**Score 0.25**: Multiple field-level mistakes reduce evaluability.
**Score 0.0**: Field values are largely incorrect or unusable.
