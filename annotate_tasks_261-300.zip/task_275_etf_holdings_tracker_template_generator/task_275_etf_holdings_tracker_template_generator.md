---
id: task_275_etf_holdings_tracker_template_generator
name: ETF Holdings Tracker Template Generator
category: Finance
subcategory: Market Data and Monitoring
difficulty: easy
external_dependency: none
verification_method: unit-test
input_modality: text-only
grading_type: automated
timeout_seconds: 120
workspace_files: []
source_line_number: 3702
source_query: "生成一个可下载的ETF持仓跟踪模板文件（CSV或Excel均可），并确保使用UTF-8编码保存/导出以避免中文乱码。"
grading_weights:
  automated: 1.0
  llm_judge: 0.0
---

## Prompt

Hey, can you create a downloadable template file for tracking ETF holdings? Either CSV or Excel works fine. I need columns for:

- ticker symbol
- ETF name
- number of shares held
- average cost per share
- current price
- total value
- gain/loss percentage
- purchase date
- notes

Add like 3-4 example rows with some sample ETFs (like SPY, QQQ, VTI, whatever) so I can see how to fill it in. Make sure to save it with UTF-8 encoding so special characters don't get messed up. Save it as `etf_holdings_template.csv` or `etf_holdings_template.xlsx`.

## Expected Behavior

The agent should:
1. Create a spreadsheet file in CSV or Excel format named `etf_holdings_template.csv` or `etf_holdings_template.xlsx`
2. Include all 9 requested column headers: ticker symbol, ETF name, shares held, average cost, current price, total value, gain/loss %, purchase date, notes
3. Add at least 3 sample ETF rows with realistic ticker symbols (e.g., SPY, QQQ, VTI)
4. Save with UTF-8 encoding
5. Ensure the file is readable and properly formatted

**Ground Truth:** The output file must be named `etf_holdings_template.csv` or `etf_holdings_template.xlsx`, contain a header row covering all 9 required columns, have at least 3 data rows with recognizable ETF tickers, and be parseable without encoding errors.

Tested capabilities: file generation, spreadsheet formatting, encoding awareness, following specifications.

## Grading Criteria

- [ ] Template file exists (named `etf_holdings_template.csv` or `etf_holdings_template.xlsx`)
- [ ] File is readable without errors
- [ ] Contains all required column headers (ticker, name, shares, cost, price, value, gain/loss, date, notes)
- [ ] Has at least 3 sample data rows
- [ ] Contains realistic ETF ticker symbols (e.g. SPY, QQQ, VTI)
- [ ] No obviously fake or placeholder data

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    from pathlib import Path
    import csv

    scores = {}
    ws = Path(workspace_path)

    csv_file = ws / "etf_holdings_template.csv"
    xlsx_file = ws / "etf_holdings_template.xlsx"

    file_exists = csv_file.exists() or xlsx_file.exists()
    scores["template_file_exists"] = 1.0 if file_exists else 0.0

    if not file_exists:
        scores["file_readable"] = 0.0
        scores["has_required_columns"] = 0.0
        scores["has_sample_data"] = 0.0
        scores["contains_realistic_etfs"] = 0.0
        scores["no_fake_data"] = 0.0
        return scores

    required_columns = [
        "ticker", "symbol", "etf", "name", "shares", "held",
        "cost", "average", "price", "current", "value", "total",
        "gain", "loss", "percentage", "date", "purchase", "notes"
    ]

    headers = []
    data_rows = []

    if csv_file.exists():
        try:
            content = csv_file.read_text(encoding="utf-8")
            reader = csv.reader(content.splitlines())
            rows = list(reader)
            if rows:
                headers = [h.lower().strip() for h in rows[0]]
                data_rows = rows[1:]
            scores["file_readable"] = 1.0
        except Exception:
            try:
                content = csv_file.read_text(encoding="utf-8-sig")
                reader = csv.reader(content.splitlines())
                rows = list(reader)
                if rows:
                    headers = [h.lower().strip() for h in rows[0]]
                    data_rows = rows[1:]
                scores["file_readable"] = 1.0
            except Exception:
                scores["file_readable"] = 0.0
    elif xlsx_file.exists():
        try:
            import zipfile
            import xml.etree.ElementTree as ET
            with zipfile.ZipFile(xlsx_file, 'r') as z:
                if 'xl/worksheets/sheet1.xml' in z.namelist():
                    scores["file_readable"] = 1.0
                    sheet_xml = z.read('xl/worksheets/sheet1.xml')
                    root = ET.fromstring(sheet_xml)
                    rows_found = root.findall('.//{http://schemas.openxmlformats.org/spreadsheetml/2006/main}row')
                    data_rows = rows_found[1:] if len(rows_found) > 1 else []
                else:
                    scores["file_readable"] = 0.5
        except Exception:
            scores["file_readable"] = 0.0

    if headers:
        header_text = " ".join(headers)
        matched = sum(1 for col in required_columns if col in header_text)
        scores["has_required_columns"] = min(1.0, matched / 9.0)
    else:
        scores["has_required_columns"] = 0.0

    scores["has_sample_data"] = 1.0 if len(data_rows) >= 3 else (0.5 if len(data_rows) >= 1 else 0.0)

    known_etfs = ["spy", "qqq", "vti", "voo", "iwm", "ief", "tlt", "gld", "slv", "vnq", "vxus", "bnd", "agg", "schd", "vym", "dia", "arkk", "xlf", "xlk", "xle"]
    etf_found = False
    if csv_file.exists() and data_rows:
        for row in data_rows:
            row_text = " ".join(str(cell).lower() for cell in row)
            if any(etf in row_text for etf in known_etfs):
                etf_found = True
                break
    elif xlsx_file.exists():
        try:
            content = xlsx_file.read_bytes().decode('utf-8', errors='ignore').lower()
            if any(etf in content for etf in known_etfs):
                etf_found = True
        except Exception:
            pass
    scores["contains_realistic_etfs"] = 1.0 if etf_found else 0.0

    # Check for obviously fake/placeholder data in both CSV and XLSX
    fake_indicators = ["fake_etf", "test123", "xxxxx", "aaaaa"]
    has_fake = False
    if csv_file.exists():
        try:
            content = csv_file.read_text(encoding="utf-8", errors="ignore").lower()
            if any(fake in content for fake in fake_indicators):
                has_fake = True
        except Exception:
            pass
    if xlsx_file.exists():
        try:
            content = xlsx_file.read_bytes().decode('utf-8', errors='ignore').lower()
            if any(fake in content for fake in fake_indicators):
                has_fake = True
        except Exception:
            pass
    scores["no_fake_data"] = 0.0 if has_fake else 1.0

    return scores
```

## LLM Judge Rubric

```yaml
dimensions:
  - name: Column Coverage & Header Quality
    weight: 40%
    description: Does the file contain all 9 required columns with clear, descriptive headers?
    levels:
      1.0: All 9 columns present with clear headers matching or closely paraphrasing the requirements (ticker, name, shares, avg cost, current price, total value, gain/loss %, purchase date, notes)
      0.75: 7–8 columns present; one minor omission (e.g., notes column missing) but all core financial columns covered
      0.5: 5–6 columns present; missing 2–3 columns including at least one core financial field
      0.25: Fewer than 5 columns; only basic fields like ticker and name present
      0.0: No recognizable column headers, or file contains only a single column

  - name: Sample Data Quality
    weight: 35%
    description: Are the sample rows filled with realistic ETF data that correctly demonstrates how to use the template?
    levels:
      1.0: 3–4 rows with real ETF tickers (e.g. SPY, QQQ, VTI), plausible numeric values in all numeric columns, valid date format, and illustrative notes
      0.75: 3+ rows with real tickers and mostly correct data; one column has placeholder values (e.g., "TBD" for notes)
      0.5: 2–3 rows present but several fields are empty, zero, or obviously placeholder; or only 1–2 recognizable ETF tickers
      0.25: Only 1 sample row, or rows have mostly empty/zero values
      0.0: No sample data rows, or all rows contain entirely fake/nonsensical values

  - name: File Format & Encoding
    weight: 25%
    description: Is the file correctly formatted, UTF-8 encoded, and saved with the expected filename?
    levels:
      1.0: File saved as `etf_holdings_template.csv` or `etf_holdings_template.xlsx`; opens without errors; UTF-8 encoding confirmed (no garbled characters)
      0.75: Correct filename and format but UTF-8 BOM present (utf-8-sig) — minor encoding variant, still readable
      0.5: File is readable but saved under a slightly different name (e.g., `etf_template.csv`) or uses a non-standard delimiter
      0.25: File exists but has significant formatting issues (e.g., inconsistent quoting, wrong extension for content type)
      0.0: File cannot be opened, is binary-corrupted, or is missing entirely
```