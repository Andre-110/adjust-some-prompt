---
id: task_300_quick_access_methods_for_server_scripts
name: Quick Access Methods for Server Scripts
category: System Administration
subcategory: Software and Environment Management
difficulty: easy
external_dependency: none
verification_method: unit-test
input_modality: text-only
grading_type: automated
timeout_seconds: 120
workspace_files: []
source_line_number: 617
source_query: "Give practical ways to quickly locate and run project scripts after SSH login, such as bash aliases, PATH updates, symlinks in /usr/local/bin, shell functions, or bookmark/jump-file approaches, and include copy-pasteable setup commands."
---

## Prompt

I SSH into our server a lot, and I keep wasting time locating the same project scripts. They currently live in different directories:

- `/home/devops/scripts/deploy.sh` — main deployment script
- `/home/devops/scripts/backup.sh` — database backup
- `/opt/myproject/bin/healthcheck.py` — service health monitor
- `/var/tools/logrotate_custom.sh` — custom log rotation

Please create a practical markdown guide that shows several ways to access these more quickly after login.

Requirements:
- Save the guide as `quick_access_guide.md`
- Include at least 4 distinct approaches
- Include real shell commands I can copy and paste
- Cover both user-level methods (for example aliases or shell config) and system-level methods where appropriate (for example symlinks in `/usr/local/bin`)
- Use the actual paths above in your examples
- Keep the guide realistic: do not invent shell features or commands that do not exist

Examples of acceptable approaches include:
- bash aliases
- adding directories to `PATH`
- symlinks or wrapper scripts in `/usr/local/bin`
- shell functions
- a bookmark/jump-file approach

The guide should be concise but complete enough that I can follow each method directly.

## Expected Behavior

The agent should:
1. Create `quick_access_guide.md` in the workspace.
2. Provide a practical markdown guide rather than just a short answer in chat.
3. Include at least 4 genuinely distinct quick-access approaches.
4. Include copy-pasteable shell commands for each method.
5. Use the actual script paths from the prompt in examples.
6. Cover common and valid techniques such as aliases, PATH updates, symlinks, shell functions, or a realistic bookmark/jump-file method.
7. Avoid fabricated shell features or fake commands.
8. Distinguish methods appropriately:
   - user-shell methods should normally modify files like `~/.bashrc` or `~/.profile`
   - system-wide launcher methods may use `/usr/local/bin` and may require `sudo`
9. Mention enough setup detail that a user could reproduce the method without guessing.

Tested capabilities:
- shell usability knowledge
- practical Linux command writing
- PATH and shell startup file understanding
- symlink and wrapper-script setup
- producing a structured markdown guide in a file

## Grading Criteria

- [ ] File `quick_access_guide.md` exists
- [ ] Documents alias-based access with actual alias commands
- [ ] Documents PATH-based access with concrete shell configuration commands
- [ ] Documents symlink or `/usr/local/bin` launcher setup with real commands
- [ ] Documents at least 4 distinct methods
- [ ] Uses the actual paths/scripts from the prompt in multiple examples
- [ ] Avoids fabricated shell features or non-existent commands

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    from pathlib import Path
    import re

    SCORE_KEYS = [
        "file_exists",
        "has_alias_method",
        "has_path_method",
        "has_symlink_or_launcher_method",
        "method_coverage",
        "uses_actual_paths",
        "no_fabricated_features",
    ]

    def zero_scores():
        return {k: 0.0 for k in SCORE_KEYS}

    ws = Path(workspace_path)
    guide_file = ws / "quick_access_guide.md"

    if not guide_file.exists():
        return zero_scores()

    try:
        content = guide_file.read_text(encoding="utf-8")
    except Exception:
        return zero_scores()

    text = content.lower()
    scores = zero_scores()
    scores["file_exists"] = 1.0

    # 1) Alias method
    alias_patterns = [
        r"alias\s+\w+\s*=\s*['\"][^'\"]+['\"]",
        r"alias\s+\w+\s*=\s*[^\n]+",
    ]
    scores["has_alias_method"] = 1.0 if any(re.search(p, text) for p in alias_patterns) else 0.0

    # 2) PATH method
    path_signals = [
        "export path=",
        "path=\"$path:",
        "path=$path:",
        ".bashrc",
        ".bash_profile",
        ".profile",
        ".zshrc",
    ]
    has_path_export = ("path" in text) and any(sig in text for sig in path_signals)
    scores["has_path_method"] = 1.0 if has_path_export else 0.0

    # 3) Symlink or launcher in /usr/local/bin
    has_ln_s = bool(re.search(r"\bln\s+-s\b", text) or re.search(r"\bln\s+-sf\b", text))
    has_usr_local_bin = "/usr/local/bin" in text
    has_wrapper = any(term in text for term in ["wrapper script", "launcher", "#!/bin/bash", "#!/usr/bin/env bash"])
    symlink_or_launcher_score = 0.0
    if has_ln_s and has_usr_local_bin:
        symlink_or_launcher_score = 1.0
    elif has_usr_local_bin and has_wrapper:
        symlink_or_launcher_score = 1.0
    elif has_ln_s or (has_usr_local_bin and has_wrapper):
        symlink_or_launcher_score = 0.5
    scores["has_symlink_or_launcher_method"] = symlink_or_launcher_score

    # 4) Count distinct methods with partial credit
    method_flags = {
        "alias": scores["has_alias_method"] > 0,
        "path": scores["has_path_method"] > 0,
        "symlink_or_launcher": scores["has_symlink_or_launcher_method"] > 0,
        "function": ("function " in text) or bool(re.search(r"\n\w+\(\)\s*\{", text)),
        "bookmark": any(term in text for term in ["bookmark", "jump file", "bookmarks file", "shortcut file"]),
        "cdpath": "cdpath" in text,
    }
    method_count = sum(1 for v in method_flags.values() if v)
    scores["method_coverage"] = min(method_count / 4.0, 1.0)

    # 5) Actual prompt paths / filenames used
    actual_refs = [
        "/home/devops/scripts/deploy.sh",
        "/home/devops/scripts/backup.sh",
        "/opt/myproject/bin/healthcheck.py",
        "/var/tools/logrotate_custom.sh",
        "/home/devops/scripts",
        "/opt/myproject/bin",
        "/var/tools",
        "deploy.sh",
        "backup.sh",
        "healthcheck.py",
        "logrotate_custom.sh",
    ]
    ref_hits = sum(1 for item in actual_refs if item.lower() in text)
    scores["uses_actual_paths"] = min(ref_hits / 4.0, 1.0)

    # 6) Fabricated features
    fabricated_terms = [
        "quickjump",
        "pathmark",
        "scriptlink",
        "bashbook",
        "fastcd",
    ]
    scores["no_fabricated_features"] = 0.0 if any(term in text for term in fabricated_terms) else 1.0

    return scores
```