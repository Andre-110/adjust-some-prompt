| 序号 | 修改项 | 修改原因 |
|---|---|---|
| 1 | 重写 `## Prompt` | 原 Prompt 示例过多，且直接暴露 `$()` / 反引号这类判定线索，存在较强答案引导；改为更简洁直接的任务描述 |
| 2 | 保留 `difficulty: medium` | 本题不只是字符串匹配，还要求区分“合法 shell 写法”和“按本任务规则视为注入”，中等难度合理 |
| 3 | 补充 `grading_weights` | 原文件缺少 `automated + llm_judge = 1.0` 的权重配置，不满足规范 |
| 4 | 重写 `Expected Behavior` | 原文基本正确，但需要更明确地写清完整判定路径和本题策略边界 |
| 5 | 补充 `Ground Truth` | 原文件虽隐含答案，但没有独立、明确的 Ground Truth 区块 |
| 6 | 补充 `Trap to handle correctly` | 明确指出陷阱：不能按“是否 benign”判断，而要按“是否执行了额外命令”判断 |
| 7 | 扩充 `Grading Criteria` 到 5 条 | 原标准只有 3 条，覆盖不足，且缺乏格式与规则一致性检查 |
| 8 | 重写 `grade()` 的 score key | 使 score key 与新版 Grading Criteria 一一对应 |
| 9 | 为 `grade()` 增加部分得分 | 原逻辑几乎是 0/1，现对“包含正确标签但有额外文本”等情况给部分分 |
| 10 | 强化“仅输出单字符串”检查 | 原评分允许很长解释，只要包含答案就可得高分；现增加 `no_extra_text` 和 `single_string_format` |
| 11 | 改善 transcript 文本提取逻辑 | 兼容 `content` 为字符串或数组两种形式，提升稳定性 |
| 12 | 删除原 `clear_answer` 的宽松判定方式 | 原逻辑只要某一行包含答案即可，过宽，不利于区分严格遵守输出格式的回答 |
| 13 | 新增 `LLM Judge Rubric` | 原文件缺失 Rubric，不满足维度 E 要求 |
| 14 | 设置 3 个 Rubric 维度且总权重为 100% | 满足“维度充分、权重正确、等级清晰”的要求 |