---
id: task_288_product_information_translator
name: Product Information Translator
category: Data Analysis
subcategory: Data Processing and Management
difficulty: medium
external_dependency: none
verification_method: unit-test
input_modality: text-only
grading_type: hybrid
grading_weights:
  automated: 0.4
  llm_judge: 0.6
timeout_seconds: 180
workspace_files: []
source_line_number: 2013
source_query: "Translate the following product information JSON into all languages listed in target_languages. Translate each non-empty field into every target language and return only those target language translations.  Input JSON: {   \"names\": {\"zh\": \"海底捞筷手小厨 酸汤肥牛调味料 150g\"},   \"allergens\": {},   \"ingredients\": {},   \"target_languages\": [\"bg\",\"cs\",\"da\",\"de\",\"el\",\"en\",\"es\",\"fi\",\"fr\",\"hu\",\"it\",\"ja\",\"ko\",\"nb\",\"nl\",\"pl\",\"pt\",\"ro\",\"ru\",\"sv\",\"tr\",\"zh-cn\",\..."
---

## Prompt

Hey, I need to translate some product info into a bunch of languages. Here's the JSON:

```json
{
  "names": {"zh": "Haidilao Kuaishou Little Chef Sour Soup Fatty Beef Seasoning 150g"},
  "allergens": {},
  "ingredients": {},
  "target_languages": ["bg", "cs", "da", "de", "el", "en", "es", "fi", "fr", "hu", "it", "ja", "ko", "nb", "nl", "pl", "pt", "ro", "ru", "sv", "tr", "zh-cn", "zh-tw"]
}
```
Translate each non-empty field to all the languages in target_languages. So basically just the "names" field here since allergens and ingredients are empty.

Output should be a JSON file called `translations.json` with the translated names for each target language. Format it like:

```json
{
  "names": {
    "bg": "...",
    "cs": "...",
    ...
  }
}
```
Oh and some rules: remove any HTML tags if present, decode HTML entities, normalize bold markers to exactly `**...**`. If there were allergens, you'd bold EU allergens and E-numbers. Also if allergens said something like "for allergens see ingredients in bold", you'd extract those bolded items and list them explicitly. But since allergens and ingredients are empty here, just focus on the names translation.

Only include the target languages in your output, not the original zh.

## Expected Behavior

The agent should:
1. Parse the input JSON and identify that only "names" has content
2. Translate the product name "Haidilao Kuaishou Little Chef Sour Soup Fatty Beef Seasoning 150g" into all 23 target languages
3. Output a valid JSON file `translations.json` with a `names` object containing all 23 target language keys
4. Not include the original "zh" key in the output
5. Leave `allergens` and `ingredients` either absent or as empty objects — must not fabricate content for them

**Ground Truth:** `translations.json` must be valid JSON; `names` must contain all 23 target language keys (bg, cs, da, de, el, en, es, fi, fr, hu, it, ja, ko, nb, nl, pl, pt, ro, ru, sv, tr, zh-cn, zh-tw) with non-empty string values; "zh" must not appear as a key in `names`; `allergens` and `ingredients` must be absent or empty objects.

Tested capabilities: JSON parsing, multilingual translation, following formatting specifications, file output.

## Grading Criteria

- [ ] File `translations.json` exists and is valid JSON
- [ ] Contains `names` object with all 23 target language keys
- [ ] Does not include original "zh" key in `names`
- [ ] Does not fabricate allergens or ingredients content
- [ ] Each name translation is a non-empty string

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    from pathlib import Path
    import json

    scores = {}
    ws = Path(workspace_path)

    target_langs = ["bg", "cs", "da", "de", "el", "en", "es", "fi", "fr", "hu", "it", "ja", "ko", "nb", "nl", "pl", "pt", "ro", "ru", "sv", "tr", "zh-cn", "zh-tw"]

    trans_file = ws / "translations.json"
    scores["file_exists"] = 1.0 if trans_file.exists() else 0.0

    if not trans_file.exists():
        scores["has_all_target_langs"] = 0.0
        scores["no_original_zh"] = 0.0
        scores["no_fabricated_allergens"] = 0.0
        scores["translations_nonempty"] = 0.0
        return scores

    try:
        data = json.loads(trans_file.read_text(encoding="utf-8"))
    except Exception:
        scores["has_all_target_langs"] = 0.0
        scores["no_original_zh"] = 0.0
        scores["no_fabricated_allergens"] = 0.0
        scores["translations_nonempty"] = 0.0
        return scores

    names = data.get("names", {}) if isinstance(data.get("names"), dict) else {}

    present_langs = [lang for lang in target_langs if lang in names and names[lang]]
    scores["has_all_target_langs"] = len(present_langs) / len(target_langs)

    scores["no_original_zh"] = 0.0 if "zh" in names else 1.0

    allergens_fabricated = isinstance(data.get("allergens"), dict) and len(data.get("allergens", {})) > 0
    ingredients_fabricated = isinstance(data.get("ingredients"), dict) and len(data.get("ingredients", {})) > 0
    scores["no_fabricated_allergens"] = 0.0 if (allergens_fabricated or ingredients_fabricated) else 1.0

    nonempty_count = sum(1 for lang in target_langs if lang in names and isinstance(names[lang], str) and len(names[lang]) > 3)
    scores["translations_nonempty"] = nonempty_count / len(target_langs)

    return scores
```

## LLM Judge Rubric

### Criterion 1: Translation Accuracy — English (Weight: 30%)

**Score 1.0**: The English translation accurately conveys the full product name: Haidilao brand, quick-cook / ready-to-use format, sour soup flavor, fatty beef ingredient, seasoning/sauce type, and 150g weight; phrasing is natural and appropriate for a food product label.
**Score 0.75**: English translation captures most elements but omits or slightly mistranslates one component (e.g., "Kuaishou" rendered literally rather than as "quick-cook" or similar).
**Score 0.5**: English translation conveys the general concept (sour soup beef seasoning) but misses the brand name or weight.
**Score 0.25**: English translation is partially correct but garbled or missing several key elements.
**Score 0.0**: English translation is absent, empty, or entirely wrong (e.g., translates a different product).

### Criterion 2: Translation Accuracy — German (Weight: 25%)

**Score 1.0**: German translation is grammatically correct; product name elements are accurately rendered; compound nouns are properly formed (e.g., "Gewürzsauce" / "Rindfleisch"); 150g preserved; brand name Haidilao retained or appropriately adapted.
**Score 0.75**: German translation is mostly correct with one grammatical error or an awkward compound; meaning is clear.
**Score 0.5**: German translation conveys the product type but has notable grammatical issues or incorrect word choice for key food terms.
**Score 0.25**: German translation is partially intelligible but has significant errors or is very incomplete.
**Score 0.0**: German translation is absent, empty, or not in German.

### Criterion 3: Translation Accuracy — Japanese (Weight: 25%)

**Score 1.0**: Japanese translation uses appropriate script: brand name in katakana (ハイディラオ or similar), product description in natural Japanese with kanji/hiragana; 150g preserved; translation is natural and suitable for a product label.
**Score 0.75**: Japanese translation is mostly correct but uses inconsistent scripts (e.g., all katakana for the description) or has a minor unnatural phrasing.
**Score 0.5**: Japanese translation uses correct characters but is awkward or overly literal; brand name may be missing or in wrong script.
**Score 0.25**: Japanese translation is partially correct but contains significant script errors or missing elements.
**Score 0.0**: Japanese translation is absent, empty, uses no Japanese characters, or is entirely wrong.

### Criterion 4: Overall Format and Completeness (Weight: 20%)

**Score 1.0**: All 23 target language keys present with non-empty string values; "zh" not in output; `allergens` and `ingredients` absent or empty; JSON is well-formed.
**Score 0.75**: 20–22 of 23 languages present; no source language contamination; minor structural issue (e.g., one empty string value).
**Score 0.5**: 15–19 languages present; or "zh" included alongside target languages; or one fabricated field.
**Score 0.25**: Fewer than 15 languages present, or only a subset of obvious languages (en, de, fr) with others missing.
**Score 0.0**: Fewer than 5 languages, invalid JSON, or output does not follow the required structure.
```