| 序号 | 修改项 | 修改原因 |
|------|--------|--------|
| 1 | **Expected Behavior** 补充 Ground Truth | 原版无明确可验证答案；补充了文件名、23 个目标语言 key、"zh" 不得出现、allergens/ingredients 为空作为 Ground Truth |
| 2 | **Grading Criteria** 从 9 条精简为 5 条，与 grade() 5 个 key 完全对齐 | 原 9 条中第 6–8 条（English/German/Japanese reasonable）在 grade() 中无对应 key，无法自动检测；这 3 条的评估交由 LLM Judge Rubric 承担，自动检测部分保留可客观验证的 5 条 |
| 3 | **grade() 重构**：删除 `valid_json` 和 `has_names_object` 两个独立 key，合并到前置检查；新增 `translations_nonempty` key | 原 `valid_json` 和 `has_names_object` 在 Grading Criteria 中无独立对应条目；新增 `translations_nonempty`（检测各语言翻译字符串长度 >3）对应第 5 条 Grading Criteria，支持部分得分 |
| 4 | **grade() 空白零分同步更新** | 调整后的 4 个 key 在文件不存在/JSON 解析失败时均提前返回 0.0 |
| 5 | **LLM Judge Rubric 补全各等级描述** | 原 4 个维度每个只有一句话，完全缺少 1.0/0.75/0.5/0.25/0.0 各等级的具体说明，违反维度 E 第 3 条；为每个维度补全了全部 5 个等级描述 |