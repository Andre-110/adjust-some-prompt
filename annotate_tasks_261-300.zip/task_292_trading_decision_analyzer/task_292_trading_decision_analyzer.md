---
id: task_292_trading_decision_analyzer
name: Trading Decision Analyzer
category: Finance
subcategory: Trading Strategy and Backtesting
difficulty: medium
external_dependency: none
verification_method: output-check
input_modality: text-only
grading_type: hybrid
grading_weights:
  automated: 0.4
  llm_judge: 0.6
automated_weight: 0.4
timeout_seconds: 120
workspace_files: []
source_line_number: 9194
source_query: "Using the following signal, market data, and portfolio status, decide whether to BUY/SELL/HOLD, choose a position size as a percentage of available cash (0–20%), assess risk (low/medium/high), and provide a detailed rationale and key factors. Respond ONLY with valid JSON matching the schema provided.  SIGNAL INFORMATION: - Signal: BUY - Confidence: LOW - Patterns Detected: bullish_harami  MARKET DATA: - Current Price: $66.30 - Trend: strong_downtrend - Volume vs Average: 1.29x - Volatility (A..."
---

## Prompt

Please analyze the trading setup below and return a trading decision.

Signal information:
- Signal: BUY
- Confidence: LOW
- Patterns Detected: bullish_harami

Market data:
- Current Price: $66.30
- Trend: strong_downtrend
- Volume vs Average: 1.29x
- Volatility (ATR): $4.11
- Price vs EMA20: below

Portfolio status:
- Available Cash: $979,718.70
- Current Position: 0 shares
- Position Value: $0.00
- Total Portfolio: $979,718.70

Return:
1. A trading action: BUY, SELL, or HOLD
2. A position size as a percentage of available cash from 0 to 20
3. A risk assessment: low, medium, or high
4. A concise but specific rationale
5. Key factors supporting the decision

Important constraints:
- Base the decision only on the data provided above.
- Because there is no existing position, a SELL decision would generally only make sense if explicitly justified from the prompt data.
- Respond with JSON only and do not include any extra text.

Use exactly this schema:
```json
{
  "action": "BUY|SELL|HOLD",
  "position_size_pct": 0,
  "risk_assessment": "low|medium|high",
  "rationale": "string",
  "key_factors": ["string"]
}
````

## Expected Behavior

The ideal response should identify that the setup contains a **bullish signal in a clearly unfavorable market context**:

1. Recognize the main conflict:

   * The signal says **BUY**
   * Confidence is **LOW**
   * The detected pattern is **bullish_harami**
   * But the broader trend is **strong_downtrend**
   * Price is **below EMA20**, which is also bearish / trend-unsupportive

2. Interpret the market context correctly:

   * A single bullish reversal pattern with low confidence is weak evidence when the market is still in a strong downtrend
   * Elevated volatility (ATR = $4.11 relative to price $66.30) increases uncertainty
   * Volume at 1.29x average may indicate activity, but it does not override the bearish trend by itself

3. Handle position logic correctly:

   * Since the portfolio currently holds **0 shares**, a **SELL** decision is generally not appropriate
   * The strongest answers will usually choose **HOLD** with **0%** position size
   * A very cautious **BUY** with a very small size may be arguable, but it is weaker than HOLD unless very well justified

4. Provide a clear grounded conclusion:

   * **Ground truth preference:** `action = HOLD`
   * **Ground truth preference:** `position_size_pct = 0`
   * **Ground truth preference:** `risk_assessment = high` (medium can be acceptable only if very strongly justified)
   * The rationale should explicitly explain that the weak bullish signal is outweighed by the strong downtrend, bearish EMA positioning, and elevated volatility

5. Return valid JSON matching the required schema exactly.

Key trap to handle correctly:

* Do **not** recommend SELL as a default bearish response when there is no current position.
* Do **not** treat the bullish_harami pattern as sufficient confirmation for an aggressive long entry.
* Do **not** ignore the contradiction between the local bullish signal and the broader bearish trend.

Tested capabilities: financial reasoning, conflict resolution, risk assessment, constrained decision-making, JSON formatting.

## Grading Criteria

* [ ] Output is valid JSON and contains no extra non-JSON text
* [ ] JSON contains all required fields: `action`, `position_size_pct`, `risk_assessment`, `rationale`, `key_factors`
* [ ] `action` is a valid value and is logically consistent with the portfolio state (SELL is not appropriate without strong justification when current position is 0)
* [ ] `position_size_pct` is numeric and between 0 and 20 inclusive
* [ ] `risk_assessment` is one of `low`, `medium`, or `high`
* [ ] `key_factors` is a non-empty list of specific factors
* [ ] Rationale explicitly addresses the conflict between the bullish signal and the strong downtrend / below-EMA condition
* [ ] Final decision is appropriately conservative for the provided evidence (best answer: HOLD with 0%; weaker but acceptable alternative: very small BUY with strong justification)
* [ ] Rationale uses the provided data points without fabricating unsupported facts

## Automated Checks

````python
def grade(transcript: list, workspace_path: str) -> dict:
    import json
    import re

    score_keys = [
        "valid_json",
        "has_all_fields",
        "action_valid",
        "position_size_valid",
        "risk_valid",
        "key_factors_nonempty",
        "conflict_analysis",
        "decision_conservatism",
        "no_fabricated_data",
    ]

    def zero_scores():
        return {k: 0.0 for k in score_keys}

    def _get_last_assistant_text(transcript: list) -> str:
        for event in reversed(transcript):
            if event.get("type") != "message":
                continue
            msg = event.get("message", {})
            if msg.get("role") != "assistant":
                continue

            content = msg.get("content", [])
            if isinstance(content, list):
                texts = []
                for item in content:
                    if isinstance(item, dict) and item.get("type") == "text":
                        texts.append(item.get("text", ""))
                if texts:
                    return "\n".join(texts).strip()
            elif isinstance(content, str):
                return content.strip()
        return ""

    output = _get_last_assistant_text(transcript)
    if not output or not output.strip():
        return zero_scores()

    def _extract_json_candidate(text: str) -> str:
        text = text.strip()

        # Prefer fenced json block if present
        fenced = re.search(r"```json\s*([\s\S]*?)\s*```", text, re.IGNORECASE)
        if fenced:
            return fenced.group(1).strip()

        # Otherwise try full text
        if text.startswith("{") and text.endswith("}"):
            return text

        # Fallback: capture outermost object greedily
        match = re.search(r"\{[\s\S]*\}", text)
        if match:
            return match.group(0).strip()

        return ""

    candidate = _extract_json_candidate(output)
    if not candidate:
        return zero_scores()

    try:
        parsed = json.loads(candidate)
    except Exception:
        return zero_scores()

    if not isinstance(parsed, dict):
        return zero_scores()

    scores = zero_scores()
    scores["valid_json"] = 1.0

    required_fields = ["action", "position_size_pct", "risk_assessment", "rationale", "key_factors"]
    present_count = sum(1 for f in required_fields if f in parsed)
    scores["has_all_fields"] = present_count / len(required_fields)

    action_raw = str(parsed.get("action", "")).strip()
    action = action_raw.upper()
    if action in {"BUY", "SELL", "HOLD"}:
        if action == "SELL":
            # SELL is technically allowed by schema, but weak given zero position
            scores["action_valid"] = 0.5
        else:
            scores["action_valid"] = 1.0
    else:
        scores["action_valid"] = 0.0

    pos_size = parsed.get("position_size_pct")
    pos_value = None
    if isinstance(pos_size, (int, float)):
        pos_value = float(pos_size)
    elif isinstance(pos_size, str):
        cleaned = pos_size.strip().replace("%", "")
        try:
            pos_value = float(cleaned)
        except Exception:
            pos_value = None

    if pos_value is not None:
        if 0 <= pos_value <= 20:
            scores["position_size_valid"] = 1.0
        else:
            scores["position_size_valid"] = 0.0
    else:
        scores["position_size_valid"] = 0.0

    risk_raw = str(parsed.get("risk_assessment", "")).strip().lower()
    if risk_raw in {"low", "medium", "high"}:
        scores["risk_valid"] = 1.0
    else:
        scores["risk_valid"] = 0.0

    key_factors = parsed.get("key_factors", [])
    if isinstance(key_factors, list):
        if len(key_factors) >= 2:
            scores["key_factors_nonempty"] = 1.0
        elif len(key_factors) == 1:
            scores["key_factors_nonempty"] = 0.5
        else:
            scores["key_factors_nonempty"] = 0.0
    else:
        scores["key_factors_nonempty"] = 0.0

    rationale = str(parsed.get("rationale", "")).strip().lower()
    factors_text = " ".join(str(x).lower() for x in key_factors) if isinstance(key_factors, list) else ""
    combined = rationale + " " + factors_text

    conflict_terms = [
        "low confidence", "strong_downtrend", "downtrend", "below ema20", "below ema", "ema20",
        "trend", "bullish_harami", "bullish harami", "conflict", "contradict", "bearish"
    ]
    matched_conflict_terms = sum(1 for term in conflict_terms if term in combined)
    if matched_conflict_terms >= 4:
        scores["conflict_analysis"] = 1.0
    elif matched_conflict_terms >= 2:
        scores["conflict_analysis"] = 0.5
    else:
        scores["conflict_analysis"] = 0.0

    # Conservative decision scoring:
    # Best: HOLD with 0
    # Acceptable: BUY with very small size (<=5)
    # Weak: BUY with size >5, or SELL
    if action == "HOLD" and pos_value == 0:
        scores["decision_conservatism"] = 1.0
    elif action == "BUY" and pos_value is not None and 0 <= pos_value <= 5:
        scores["decision_conservatism"] = 0.5
    elif action == "SELL":
        scores["decision_conservatism"] = 0.0
    else:
        scores["decision_conservatism"] = 0.0

    # Fabrication / unsupported-data check
    fabricated = False

    # Penalize mention of obviously inconsistent holdings
    forbidden_position_claims = [
        "current position: 100",
        "holding shares",
        "existing long position",
        "we should trim the position",
        "take profit on current shares",
    ]
    if any(term in combined for term in forbidden_position_claims):
        fabricated = True

    # Penalize clearly incorrect price mentions if the true price is not also referenced
    wrong_price_patterns = [r"\$65(?:\.0+)?", r"\$67(?:\.0+)?", r"\$70(?:\.0+)?", r"\$60(?:\.0+)?", r"\$100(?:\.0+)?"]
    mentions_wrong_price = any(re.search(p, combined) for p in wrong_price_patterns)
    mentions_true_price = "$66.30".lower() in combined or "$66.3".lower() in combined or "66.30" in combined
    if mentions_wrong_price and not mentions_true_price:
        fabricated = True

    scores["no_fabricated_data"] = 0.0 if fabricated else 1.0

    return scores
````

## LLM Judge Rubric

### Dimension 1: Market Conflict Analysis (30%)

Evaluates whether the response correctly interprets the conflict between the local bullish signal and the broader bearish context.

* **1.0**: Clearly explains that the BUY signal / bullish_harami is weakened by LOW confidence, strong_downtrend, and price below EMA20; correctly prioritizes broader trend context.
* **0.75**: Identifies most of the conflict and explains why the setup is risky, but misses one relevant element or gives slightly incomplete reasoning.
* **0.5**: Recognizes some contradiction but the explanation is generic, shallow, or only partially tied to the provided data.
* **0.25**: Mentions isolated facts without connecting them into a coherent conflict analysis.
* **0.0**: Fails to recognize the contradiction, or treats the setup as clearly bullish without addressing the bearish context.

### Dimension 2: Decision Quality and Position Sizing (30%)

Evaluates whether the chosen action and size are appropriate for the evidence.

* **1.0**: Chooses the strongest decision for the setup: HOLD with 0% size; or provides an exceptionally well-justified alternative that remains very conservative.
* **0.75**: Decision is reasonable and cautious; if BUY, the size is very small and justified by uncertainty.
* **0.5**: Decision is somewhat plausible but either too aggressive or not fully justified by the data.
* **0.25**: Decision is weak, poorly justified, or inconsistent with the low-confidence bearish context.
* **0.0**: Recommends an obviously inappropriate action, such as aggressive BUY sizing or unsupported SELL despite zero current position.

### Dimension 3: Risk Assessment Coherence (20%)

Evaluates whether the stated risk level aligns with the evidence and reasoning.

* **1.0**: Risk assessment is fully consistent with the setup; high risk is best, with medium acceptable only if carefully justified.
* **0.75**: Risk assessment is mostly appropriate and reasonably explained.
* **0.5**: Risk assessment is somewhat plausible but weakly justified or slightly inconsistent with the analysis.
* **0.25**: Risk label conflicts with the explanation or ignores key evidence.
* **0.0**: Risk assessment is clearly inappropriate, such as calling this setup low risk.

### Dimension 4: Data Use, Specificity, and JSON Compliance (20%)

Evaluates whether the answer stays grounded in the provided data and follows the response format.

* **1.0**: Returns clean JSON only, uses the required schema, and cites specific provided facts (e.g., low confidence, strong_downtrend, below EMA20, ATR, volume).
* **0.75**: Mostly correct JSON/schema usage and grounded reasoning, with only minor omissions.
* **0.5**: JSON or schema is imperfect but still usable, or reasoning is somewhat vague.
* **0.25**: Significant format issues, weak specificity, or some unsupported claims.
* **0.0**: Not valid JSON, major schema failure, or substantial fabrication / irrelevant content.

Weights:

* Market Conflict Analysis: 30%
* Decision Quality and Position Sizing: 30%
* Risk Assessment Coherence: 20%
* Data Use, Specificity, and JSON Compliance: 20%

