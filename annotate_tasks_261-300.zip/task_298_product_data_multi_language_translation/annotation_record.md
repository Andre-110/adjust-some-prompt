| 序号 | 修改项 | 修改原因 |
|---|---|---|
| 1 | 将 difficulty 从 `medium` 改为 `hard` | 该题不仅是多语言翻译，还要求识别错误源字段、保留品牌名、严格控制 schema，并兼顾 19 个目标语言，复杂度明显高于普通 medium |
| 2 | 重写 Prompt，删除“直接提示正确解法”的表述 | 原 Prompt 明确告诉模型“名字保持不变”“用英文做 source”“fr/it 是错的”，泄露 Expected Behavior，降低题目区分度 |
| 3 | 保留任务意图但减少答案泄露 | 修改后 Prompt 仍明确任务目标和输出格式，但不直接把关键推理结论写进 Prompt |
| 4 | 明确输出只包含需要出现的字段 | 原 Prompt 对“translate every non-empty field”和“skip allergens”同时存在，容易让边界不清；修订后更清楚 |
| 5 | 重写 Expected Behavior，补足可验证 Ground Truth | 原 Expected Behavior 方向对，但未充分结构化，难以作为统一审校标准 |
| 6 | 在 Expected Behavior 中显式加入“源字段不一致”的正确处理 | 这是本题核心陷阱之一，必须明确写出期望模型如何处理，而不是只讲一般失败模式 |
| 7 | 细化 Grading Criteria 并拆分 language code 检查 | 原标准过于合并，不利于独立验证，也不利于形成梯度 |
| 8 | 增加“top-level structure”检查项 | 原评分只检查 allergens 缺失，但未检查是否引入其他不该有的顶层字段 |
| 9 | 将“ingredients are translated”拆成“non-empty”和“not copied”两项 | 提升区分度，避免一个宽泛条目承载太多判定逻辑 |
| 10 | 重写 LLM Judge Rubric 为 4 个维度 | 原 rubric 只有百分比描述，不符合你要求的“至少 3 个维度且每档有具体描述” |
| 11 | 为 LLM Judge Rubric 补齐 1.0 / 0.75 / 0.5 / 0.25 / 0.0 五档描述 | 满足等级描述清晰的要求 |
| 12 | 保持 `grading_weights` 为 automated 0.4 / llm_judge 0.6 | 原权重和为 1.0，符合要求，无需修改 |
| 13 | 重写 `grade()` 的初始化逻辑 | 统一先给所有 score key 赋 0.0，保证主输出不存在时全部零分 |
| 14 | 修复 `grade()` 中 key 与标准不完全对齐的问题 | 原有 key 粒度偏粗，且和修改后的 Criteria 不完全一致；修订后实现一一对应 |
| 15 | 为 `grade()` 增加部分得分逻辑 | 原实现多数是 0/1，不满足部分得分要求；现在对结构、语言覆盖、无伪造项等都支持 0.5 |
| 16 | 改进 top-level 结构检查 | 原实现只看 `allergens` 是否不存在，不足以验证输出 schema 正确 |
| 17 | 保留自动评分只检查“可程序验证部分” | 翻译准确性和自然度无法通过可靠规则自动判定，因此留给 LLM Judge，更符合 hybrid 设计 |
| 18 | 明确自动评分无法验证真实翻译质量，只验证“非拷贝、完整性、结构性” | 避免 automated check 虚假声称能判断翻译正确与自然 |
| 19 | 提高 Criteria 与 hybrid grading 的一致性 | 将机器可检部分与 LLM Judge 可检部分职责分开，减少重复和冲突 |
