---
id: task_298_product_data_multi_language_translation
name: Product Data Multi-Language Translation
category: Data Analysis
subcategory: Data Processing and Management
difficulty: hard
external_dependency: none
verification_method: unit-test
input_modality: text-only
grading_type: hybrid
grading_weights:
  automated: 0.4
  llm_judge: 0.6
timeout_seconds: 240
workspace_files: []
source_line_number: 3629
source_query: "Translate the following product data into the target languages listed in target_languages. Translate each non-empty field (e.g., names, ingredients, allergens) into all target languages, and return only translations for those target languages. Follow sanitization, allergen/additive bolding, and allergen-extraction rules strictly. Input data: {\"names\":{\"en\":\"Sour Patch Kids Fruit Mix\",\"de\":\"Sour Patch Kids Fruit Mix\",\"fr\":\"Sour Patch Kids Fruit Mix\",\"it\":\"Sour Patch Kids Fruit..."
---

## Prompt

Hey, I need help preparing localized product data for our international store.

Please translate the product data below into the languages listed in `target_languages`, and save the result as `translations.json`.

Only include translations for the target languages listed. Translate every non-empty field that should appear in the output. If a field is empty and does not need to appear in the output, omit it.

Use this input data:

```json
{
  "names": {
    "en": "Sour Patch Kids Fruit Mix",
    "de": "Sour Patch Kids Fruit Mix",
    "fr": "Sour Patch Kids Fruit Mix",
    "it": "Sour Patch Kids Fruit Mix"
  },
  "allergens": {},
  "ingredients": {
    "en": "Sugar, glucose syrup, water, starch, gelatine, acid (malic acid), colours (anthocyanins, vegetable carbon, curcumin), concentrated apple juice, acidity regulator (calcium citrates), flavourings, palm oil.",
    "de": "Zucker, Glukosesirup, Wasser, Stärke, Gelatine, Säuerungsmittel (Äpfelsäure), Farbstoffe (Anthocyane, Pflanzenkohle, Kurkumin), Apfelsaftkonzentrat, Säureregulator (Calciumcitrate), Aromen, Palmöl.",
    "fr": "Zucker, Glukosesirup, Wasser, Stärke, Gelatine, Säuerungsmittel (Äpfelsäure), Farbstoffe (Anthocyane, Pflanzenkohle, Kurkumin), Apfelsaftkonzentrat, Säureregulator (Calciumcitrate), Aromen, Palmöl.",
    "it": "Zucker, Glukosesirup, Wasser, Stärke, Gelatine, Säuerungsmittel (Äpfelsäure), Farbstoffe (Anthocyane, Pflanzenkohle, Kurkumin), Apfelsaftkonzentrat, Säureregulator (Calciumcitrate), Aromen, Palmöl."
  },
  "target_languages": ["bg", "cs", "da", "el", "es", "fi", "hu", "ja", "ko", "nb", "nl", "pl", "pt", "ro", "ru", "sv", "tr", "zh-cn", "zh-tw"]
}
````

Return the result in this JSON structure:

```json
{
  "names": {
    "bg": "...",
    "cs": "...",
    "...": "..."
  },
  "ingredients": {
    "bg": "...",
    "cs": "...",
    "...": "..."
  }
}
```

## Expected Behavior

The agent should create a valid JSON file named `translations.json` in the workspace.

The output should satisfy all of the following:

1. The output contains exactly two top-level fields:

   * `names`
   * `ingredients`

2. The output must not include `allergens`, because the input `allergens` object is empty.

3. Both `names` and `ingredients` must contain exactly the following 19 language codes and no others:

* `bg`
* `cs`
* `da`
* `el`
* `es`
* `fi`
* `hu`
* `ja`
* `ko`
* `nb`
* `nl`
* `pl`
* `pt`
* `ro`
* `ru`
* `sv`
* `tr`
* `zh-cn`
* `zh-tw`

4. For `names`, each target language entry should preserve the product name as the brand/product name:

   * `Sour Patch Kids Fruit Mix`

5. For `ingredients`, each target language entry should be a translation of the ingredient list into that target language. The translated ingredient text should:

   * be non-empty
   * correspond to the English ingredient list semantically
   * not simply copy the English source unchanged
   * not simply copy the erroneous German text found in some non-English source fields
   * preserve the ingredient-list structure and food-label meaning

6. The agent should infer and handle the source inconsistency correctly:

   * the English ingredient field is the reliable source for translation
   * the `fr` and `it` ingredient values are incorrect duplicated German text and should not be used as the source text

7. The output may differ in punctuation, script, or local food-label conventions as long as the translation remains accurate and natural for the target language.

Tested capabilities:

* identifying the correct source field when multilingual input contains inconsistent values
* structured multilingual transformation
* omission of empty fields
* exact schema compliance
* preserving brand names while translating descriptive content

## Grading Criteria

* [ ] File `translations.json` exists
* [ ] File content is valid JSON
* [ ] Output contains exactly the required top-level fields and excludes `allergens`
* [ ] `names` contains exactly the 19 required target language codes and no others
* [ ] `ingredients` contains exactly the 19 required target language codes and no others
* [ ] Product names are preserved as `Sour Patch Kids Fruit Mix` for all target languages
* [ ] Ingredient translations are non-empty for all target languages
* [ ] Ingredient translations are not trivial copies of the English or duplicated German source text
* [ ] Output does not introduce fabricated extra language codes or unsupported sections

## LLM Judge Rubric

Use this rubric for the model-judged portion of the score.

### Dimension 1: Ingredient Translation Accuracy (Weight: 40%)

* **1.0**: Ingredient lists across the target languages are accurate, semantically faithful to the English source, and correctly render food-label terms such as sugars, acids, colours, concentrates, and acidity regulators.
* **0.75**: Most ingredient translations are accurate, with only minor terminology or phrasing issues that do not materially distort meaning.
* **0.5**: Ingredient translations are partially correct, but multiple terms are mistranslated, overly literal, or inconsistent.
* **0.25**: Ingredient translations are largely weak, with many incorrect terms, obvious source-copying, or major semantic loss.
* **0.0**: Ingredient translations are missing, mostly untranslated, or fundamentally incorrect.

### Dimension 2: Language Naturalness and Local Label Style (Weight: 25%)

* **1.0**: Translations read naturally in each target language and resemble realistic ingredient-list or product-label wording.
* **0.75**: Translations are generally natural, with a few awkward or overly literal phrases.
* **0.5**: Translations are understandable but noticeably unnatural or inconsistent with normal ingredient-label style.
* **0.25**: Translations are difficult to read, unidiomatic, or clearly machine-like in many places.
* **0.0**: Translations are unusable in the target languages.

### Dimension 3: Source Selection and Instruction Following (Weight: 20%)

* **1.0**: Correctly preserves the brand name, uses the reliable source content, omits empty `allergens`, and follows the requested schema exactly.
* **0.75**: Mostly follows instructions, with only one minor issue in source handling or schema adherence.
* **0.5**: Partially follows instructions, but includes noticeable mistakes such as source confusion or small schema deviations.
* **0.25**: Significant instruction-following failures, including wrong source usage or incorrect inclusion/omission of fields.
* **0.0**: Does not follow the task requirements in any reliable way.

### Dimension 4: Completeness and Coverage (Weight: 15%)

* **1.0**: All 19 target languages are present for both `names` and `ingredients`, with no missing entries.
* **0.75**: Nearly complete, with only one or two missing or weak entries.
* **0.5**: Several required entries are missing or incomplete.
* **0.25**: Many required entries are missing.
* **0.0**: The multilingual output is largely incomplete.

Total rubric weight: 100%

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    from pathlib import Path
    import json

    target_langs = [
        "bg", "cs", "da", "el", "es", "fi", "hu", "ja", "ko",
        "nb", "nl", "pl", "pt", "ro", "ru", "sv", "tr", "zh-cn", "zh-tw"
    ]
    target_set = set(target_langs)

    english_ingredients = (
        "Sugar, glucose syrup, water, starch, gelatine, acid (malic acid), "
        "colours (anthocyanins, vegetable carbon, curcumin), concentrated apple juice, "
        "acidity regulator (calcium citrates), flavourings, palm oil."
    )

    german_ingredients_prefix = "Zucker, Glukosesirup, Wasser, Stärke, Gelatine"

    scores = {
        "file_exists": 0.0,
        "valid_json": 0.0,
        "correct_top_level_structure": 0.0,
        "correct_names_language_codes": 0.0,
        "correct_ingredients_language_codes": 0.0,
        "names_preserved": 0.0,
        "ingredients_non_empty": 0.0,
        "ingredients_not_copied": 0.0,
        "no_fabricated_languages_or_sections": 0.0,
    }

    ws = Path(workspace_path)
    translations_file = ws / "translations.json"

    if not translations_file.exists():
        return scores

    scores["file_exists"] = 1.0

    try:
        data = json.loads(translations_file.read_text(encoding="utf-8"))
        scores["valid_json"] = 1.0
    except Exception:
        return scores

    if not isinstance(data, dict):
        return scores

    top_keys = set(data.keys())
    if top_keys == {"names", "ingredients"}:
        scores["correct_top_level_structure"] = 1.0
    elif "names" in data and "ingredients" in data and "allergens" not in data:
        scores["correct_top_level_structure"] = 0.5

    names = data.get("names", {})
    ingredients = data.get("ingredients", {})

    if isinstance(names, dict):
        names_langs = set(names.keys())
    else:
        names_langs = set()

    if isinstance(ingredients, dict):
        ingredients_langs = set(ingredients.keys())
    else:
        ingredients_langs = set()

    if names_langs == target_set:
        scores["correct_names_language_codes"] = 1.0
    elif names_langs.issubset(target_set) and len(names_langs) >= 15:
        scores["correct_names_language_codes"] = 0.5

    if ingredients_langs == target_set:
        scores["correct_ingredients_language_codes"] = 1.0
    elif ingredients_langs.issubset(target_set) and len(ingredients_langs) >= 15:
        scores["correct_ingredients_language_codes"] = 0.5

    if isinstance(names, dict):
        preserved_count = 0
        for lang in target_langs:
            value = names.get(lang, "")
            if isinstance(value, str) and value.strip() == "Sour Patch Kids Fruit Mix":
                preserved_count += 1
        scores["names_preserved"] = preserved_count / len(target_langs)

    if isinstance(ingredients, dict):
        non_empty_count = 0
        not_copied_count = 0

        for lang in target_langs:
            value = ingredients.get(lang, "")
            if isinstance(value, str):
                stripped = value.strip()
                if stripped:
                    non_empty_count += 1

                lowered = stripped.lower()
                if (
                    stripped
                    and lowered != english_ingredients.lower()
                    and german_ingredients_prefix.lower() not in lowered
                    and len(stripped) > 20
                ):
                    not_copied_count += 1

        scores["ingredients_non_empty"] = non_empty_count / len(target_langs)
        scores["ingredients_not_copied"] = not_copied_count / len(target_langs)

    extra_langs = (names_langs | ingredients_langs) - target_set
    extra_sections = top_keys - {"names", "ingredients"}
    if not extra_langs and not extra_sections:
        scores["no_fabricated_languages_or_sections"] = 1.0
    elif len(extra_langs) <= 1 and not extra_sections:
        scores["no_fabricated_languages_or_sections"] = 0.5

    return scores
```
