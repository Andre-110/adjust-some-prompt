| 序号 | 修改项 | 修改原因 |
|------|--------|--------|
| 1 | **Expected Behavior** 补充 Ground Truth | 原版无明确可验证答案；补充了文件名、必须包含的六类内容（日期、六节、三指数、两板块、成交额、美股）作为 Ground Truth |
| 2 | **Expected Behavior** 新增第 8 条：incorporate US market news | 原版遗漏对美股新闻引用的期望描述，与 Grading Criteria 第 8 条不对应 |
| 3 | **Grading Criteria** 第 8 条：将"No excessive emojis"替换为"US market news incorporated" | 原 grade() 中无对应 `no_excessive_emojis` key，而美股新闻引用是 Prompt 明确要求但无检测的关键点；替换后 key 完全对齐，emoji 检查交由 LLM Judge 处理 |
| 4 | **grade() key 重命名**：`no_fabrication` → `has_us_market_news`，并重写对应逻辑 | 原 `no_fabrication` 检测逻辑极弱（3 个假字符串），几乎永远得满分，无区分度；改为检测美股新闻引用（Dow/Nasdaq/S&P），与 Grading Criteria 第 8 条对齐，并支持部分得分 |
| 5 | **grade() `has_index_data` 逻辑收紧**：由"名字 + 'down'" 改为"名字 + 具体百分比数字" | 原条件中 `"down" in content_lower` 几乎必然命中（全文有大量 "down"），导致任意提及指数名称即得分；改为匹配具体小数（1.26/1.28 等）才计数，区分度更强 |
| 6 | **grade() `has_turnover` 逻辑修复**：`"2000"` 宽泛匹配改为 `re.search(r"199[89]")` + 量词词检测 | 原 "2000" 可被正文任何 "2000" 触发（如年份）；改为匹配实际数据中的 1998/1999，并要求同时出现成交量相关词，避免误判 |
| 7 | **grade() 空白零分同步更新**：`no_fabrication` → `has_us_market_news` | 文件不存在时的提前返回字典 key 同步修正 |
| 8 | **LLM Judge Rubric 补全各等级描述** | 原 Rubric 5 个维度每个只有一句话描述，完全缺少 1.0/0.75/0.5/0.25/0.0 各等级的具体说明，违反维度 E 第 3 条；为每个维度补全了全部 5 个等级的描述 |