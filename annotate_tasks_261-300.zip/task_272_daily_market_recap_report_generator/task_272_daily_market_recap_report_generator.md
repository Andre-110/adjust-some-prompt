---
id: task_272_daily_market_recap_report_generator
name: Daily Market Recap Report Generator
category: Finance
subcategory: Market Analysis and Research
difficulty: medium
external_dependency: none
verification_method: llm-judge
input_modality: text-only
grading_type: hybrid
grading_weights:
  automated: 0.4
  llm_judge: 0.6
timeout_seconds: 180
workspace_files: []
source_line_number: 6108
source_query: "根据以下 2026-02-23 市场数据与新闻，生成一份简洁的大盘复盘报告，并严格按指定模板输出。  输出要求： - 只输出纯 Markdown 文本（禁止 JSON、禁止代码块） - emoji 仅用于标题且每个标题最多 1 个 - 不要输出任何额外说明文字  市场数据： - 日期：2026-02-23 - 主要指数：上证指数 4082.07（↓1.26%）；深证成指 14100.19（↓1.28%）；创业板指 3275.96（↓1.57%）；上证50 3034.35（↓1.47%）；沪深300 4660.41（↓1.25%） - 市场概况：上涨 1540 家｜下跌 3829 家｜平盘 106 家；涨停 40 家｜跌停 19 家；两市成交额 19989 亿元 - 板块表现：领涨 其他数字媒体(+5.00%)、海洋捕捞(+4.22%)、航海装备Ⅲ(+3.99%)；领跌 通信线缆及配套(-4.97%)、稀土(-4.47%)、钨(-3.90%) - 市场新闻要点：周五美股三大股指收盘普涨（道指 +0.48%，纳指 +0.90%，标普 +0.71%），科技股表现分化（英伟达、苹果、谷歌..."
---

## Prompt

Hey, I need you to write a daily market recap report based on this data from 2026-02-23. Just output it as pure Markdown text — no JSON, no code blocks. Keep emojis minimal (max 1 per heading).

Here's the market data:

**Date:** 2026-02-23

**Major Indices:**
- Shanghai Composite: 4082.07 (down 1.26%)
- Shenzhen Component: 14100.19 (down 1.28%)
- ChiNext: 3275.96 (down 1.57%)
- SSE 50: 3034.35 (down 1.47%)
- CSI 300: 4660.41 (down 1.25%)

**Market Overview:**
- Advancers: 1540 | Decliners: 3829 | Unchanged: 106
- Limit Up: 40 | Limit Down: 19
- Total Turnover: 1998.9 billion CNY

**Sector Performance:**
- Top Gainers: Digital Media (+5.00%), Marine Fishing (+4.22%), Marine Equipment (+3.99%)
- Top Losers: Telecom Cables (-4.97%), Rare Earth (-4.47%), Tungsten (-3.90%)

**Market News:**
- US stocks closed higher Friday — Dow +0.48%, Nasdaq +0.90%, S&P +0.71%
- Tech stocks mixed: Nvidia up ~1%, Apple up >1%, Google up >3%, Microsoft slightly down, Amazon up >2%, Meta up >1%, Tesla slightly up
- Some HK stocks snippets and AI analysis articles (can reference if relevant)

Use this exact template structure:

## Market Recap 2026-02-23

### I. Market Summary
### II. Index Commentary
### III. Capital Flow Analysis
### IV. Sector Highlights
### V. Outlook
### VI. Risk Warnings

Just output the report directly, no extra explanations before or after. Save it to `market_recap.md`.

## Expected Behavior

The agent should:
1. Generate a market recap report in pure Markdown format
2. Follow the exact template structure with all 6 sections (I–VI)
3. Include the correct date (2026-02-23) in the main heading
4. Accurately reference the provided data (indices, percentages, sectors, turnover)
5. Use emojis sparingly (only in headings, max 1 per heading)
6. Not output JSON or code blocks
7. Provide meaningful analysis in each section based on the data
8. Incorporate the US market news (Dow/Nasdaq/S&P figures) where relevant
9. Save the output to `market_recap.md`

**Ground Truth:** The file `market_recap.md` must contain the heading `Market Recap 2026-02-23`, all six Roman-numeral sections (I–VI), at least three of the five index names with their correct decline direction, at least two sector names from the provided gainers/losers list, the turnover figure (~1998–1999 billion), and a reference to US market performance on Friday.

Tested capabilities: financial analysis, structured report writing, template adherence, data interpretation.

## Grading Criteria

- [ ] Output file `market_recap.md` exists
- [ ] Contains main heading with correct date (2026-02-23)
- [ ] All 6 required sections present (I through VI)
- [ ] Index data accurately referenced (at least 3 indices mentioned with correct decline)
- [ ] Sector performance mentioned (at least 2 sector names from the provided list)
- [ ] Turnover/volume figure referenced (~1998–1999 billion)
- [ ] No code blocks in output
- [ ] US market news incorporated (Dow/Nasdaq/S&P figures mentioned)

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    from pathlib import Path
    import re

    scores = {}
    ws = Path(workspace_path)

    report_file = ws / "market_recap.md"
    scores["file_exists"] = 1.0 if report_file.exists() else 0.0

    if not report_file.exists():
        scores["has_date"] = 0.0
        scores["has_all_sections"] = 0.0
        scores["has_index_data"] = 0.0
        scores["has_sector_data"] = 0.0
        scores["has_turnover"] = 0.0
        scores["no_code_blocks"] = 0.0
        scores["has_us_market_news"] = 0.0
        return scores

    content = report_file.read_text()
    content_lower = content.lower()

    scores["has_date"] = 1.0 if "2026-02-23" in content else 0.0

    section_patterns = [
        r"###?\s*(I\.?|1\.?)\s*[^\n]*",
        r"###?\s*(II\.?|2\.?)\s*[^\n]*",
        r"###?\s*(III\.?|3\.?)\s*[^\n]*",
        r"###?\s*(IV\.?|4\.?)\s*[^\n]*",
        r"###?\s*(V\.?|5\.?)\s*[^\n]*",
        r"###?\s*(VI\.?|6\.?)\s*[^\n]*",
    ]
    sections_found = sum(1 for p in section_patterns if re.search(p, content, re.IGNORECASE))
    scores["has_all_sections"] = 1.0 if sections_found >= 5 else (sections_found / 6.0)

    # Check each index by name AND its specific percentage to avoid over-broad matching
    index_checks = [
        ("shanghai", "1.26"),
        ("shenzhen", "1.28"),
        ("chinext", "1.57"),
        ("sse", "1.47"),
        ("csi", "1.25"),
    ]
    index_mentions = sum(
        1 for name, pct in index_checks
        if name in content_lower and pct in content
    )
    scores["has_index_data"] = min(1.0, index_mentions / 3.0)

    sector_terms = ["digital media", "marine", "fishing", "telecom", "rare earth", "tungsten", "cable"]
    sector_mentions = sum(1 for t in sector_terms if t in content_lower)
    scores["has_sector_data"] = 1.0 if sector_mentions >= 2 else (sector_mentions / 2.0)

    # Match the actual turnover figure: 1998 or 1999 must appear alongside a volume-related word
    has_turnover_figure = bool(re.search(r"199[89]", content))
    has_volume_word = any(w in content_lower for w in ["turnover", "volume", "billion", "成交"])
    scores["has_turnover"] = 1.0 if (has_turnover_figure and has_volume_word) else 0.0

    code_block_count = content.count("```")
    scores["no_code_blocks"] = 1.0 if code_block_count == 0 else 0.0

    # Check US market news: must mention at least two of Dow/Nasdaq/S&P with a positive move
    us_terms = ["dow", "nasdaq", "s&p", "s&p 500"]
    us_mentions = sum(1 for t in us_terms if t in content_lower)
    scores["has_us_market_news"] = 1.0 if us_mentions >= 2 else (0.5 if us_mentions == 1 else 0.0)

    return scores
```

## LLM Judge Rubric

### Criterion 1: Template Compliance (Weight: 25%)

**Score 1.0**: Report follows the exact 6-section structure with proper heading hierarchy. Main title includes the date `2026-02-23` as specified. Section numbering (I through VI) is fully preserved.
**Score 0.75**: All 6 sections present but minor formatting deviation (e.g., one section heading uses a slightly different numbering style, or the main title format differs slightly).
**Score 0.5**: At least 4 of 6 sections present with recognizable Roman numeral or numeric labels; main title exists but date format is off.
**Score 0.25**: Structure attempted but only 2–3 sections present, or section labels are mostly missing.
**Score 0.0**: No recognizable section structure; output is free-form prose with no headings.

### Criterion 2: Data Accuracy (Weight: 25%)

**Score 1.0**: All referenced index values, percentages, sector names, and turnover figure are correctly cited from the provided data with no fabricated numbers.
**Score 0.75**: Most figures correct; at most one minor numerical error (e.g., rounding difference) or one sector name paraphrased but recognizable.
**Score 0.5**: Key indices mentioned but several specific percentages are wrong or omitted; turnover figure missing or incorrect.
**Score 0.25**: Some market data present but significant errors or omissions; multiple figures appear hallucinated.
**Score 0.0**: No accurate market data referenced, or data is entirely fabricated.

### Criterion 3: Analysis Quality (Weight: 25%)

**Score 1.0**: Each section provides meaningful commentary beyond restating numbers — e.g., connects broad decline ratio (1540 up vs 3829 down) to market sentiment, links sector rotation to macro themes, offers reasoned outlook.
**Score 0.75**: Most sections have substantive analysis; one or two sections are thin (close to number restatement only).
**Score 0.5**: Report reads mostly as a data summary with limited interpretive commentary; connections between data points are sparse.
**Score 0.25**: Very little original analysis; most sections are one-sentence data recaps.
**Score 0.0**: No analysis — purely raw numbers or placeholder text.

### Criterion 4: Professional Tone (Weight: 15%)

**Score 1.0**: Writing is clear, concise, and appropriate for a professional financial report throughout; no casual language, typos, or inappropriate content.
**Score 0.75**: Mostly professional; occasional informal phrasing in one section.
**Score 0.5**: Readable but inconsistent tone — mixes professional and casual language noticeably.
**Score 0.25**: Significant casual or unclear language that undermines credibility.
**Score 0.0**: Unprofessional, incoherent, or inappropriate content throughout.

### Criterion 5: Format Adherence (Weight: 10%)

**Score 1.0**: Pure Markdown with no JSON or code blocks; emojis used only in headings with at most 1 per heading; no extraneous preamble or postamble text.
**Score 0.75**: No code blocks or JSON, but emojis appear in body text or slightly exceed the 1-per-heading limit.
**Score 0.5**: Minor format violations — e.g., one small inline code span, or a brief preamble sentence before the report.
**Score 0.25**: Multiple format violations (code blocks present, or JSON fragments, or excessive emojis throughout).
**Score 0.0**: Output contains JSON, code blocks wrapping the entire report, or is not Markdown at all.
```