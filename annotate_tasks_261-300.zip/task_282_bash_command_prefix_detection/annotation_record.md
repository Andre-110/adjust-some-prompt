| 序号 | 修改项 | 修改原因 |
|------|--------|--------|
| 1 | 新增 `grading_weights: automated: 1.0, llm_judge: 0.0` | 原文件缺少该字段，维度 E 要求两者之和为 1.0 |
| 2 | **Expected Behavior** 明确陷阱说明和 Ground Truth | 原版陷阱描述不够精确；补充了"semicolons/brackets 在引号内不构成 shell 注入"的核心判断依据，并添加显式 Ground Truth |
| 3 | **grade() `correct_prefix` fallback 逻辑收紧** | 原 fallback 只要 response 中含 "python3" 且不含 "command_injection" 就得分，逻辑过宽（agent 在解释里提到 python3 也会得分）；改为只在整个回复恰好等于已知答案时 fallback，其余情况由逐行扫描覆盖 |
| 4 | **grade() `not_false_positive_injection` 逻辑修复**：从 `"injection" in response` 改为 `core_answer == "command_injection_detected"` | 原逻辑会把 agent 说"there is no injection"也判为失分，过于严格；改为只在最终答案本身是 "command_injection_detected" 时才扣分 |
| 5 | **grade() `not_incorrectly_none` 逻辑简化**：只保留 `core_answer == "none"` 判断 | 原版有两套并行判断（`endswith("none")` + 逐行检测），语义不一致且 endswith 会误匹配；统一改为基于 `core_answer` 的精确判断 |
| 6 | **新增 `## LLM Judge Rubric`**（2 个维度，权重总和 100%） | 原文件完全缺少该部分；新增 Answer Correctness (60%) 和 Injection Trap Reasoning (40%)，各含 5 个等级描述 |