---
id: task_294_persona_preference_signal_extraction
name: Persona Preference Signal Extraction
category: Data Analysis
subcategory: Text Parsing
difficulty: easy
external_dependency: none
verification_method: unit-test
input_modality: text-only
grading_type: automated
timeout_seconds: 120
workspace_files: []
source_line_number: 1198
source_query: "分析用户消息“你目前是多模态模型，可以替我尝试进行图片识别吗”，提取其中的人格/互动偏好信号；若有信号，按 JSON 数组格式输出 [{\"dimension\":\"维度名\",\"preference\":\"偏好值\",\"confidence\":0.0,\"source\":\"correction|mined\",\"evidence\":\"识别依据\"}]；若无信号输出 []；仅输出 JSON。"
grading_weights:
  automated: 0.8
  llm_judge: 0.2
---

## Prompt

Analyze the following user message and extract any **persona or interaction preference signals** that are clearly supported by the text.

User message:
```text
You're currently a multimodal model, can you try doing image recognition for me?
````

Output rules:

* If there are clear preference signals, output a JSON array in this format:

```json
[{"dimension":"dimension_name","preference":"preference_value","confidence":0.0,"source":"correction|mined","evidence":"text-based evidence"}]
```

* If there are **no clear persona or interaction preference signals**, output:

```json
[]
```

* Only output JSON. Do not add any explanation.

## Expected Behavior

The agent should:

1. Read the user message and distinguish between:

   * a **task request / capability request** (asking the assistant to do image recognition), and
   * a **persona or interaction preference signal** (such as a stable preference for response style, tone, level of detail, format, role, or mode of interaction).

2. Recognize that this message primarily expresses a request to use a capability (“do image recognition”), not a stable user preference.

3. Avoid over-interpreting weak cues.
   In particular, mentioning “multimodal model” may show topic awareness, but it does **not** reliably indicate a persistent persona or interaction preference.

4. Conclude that there is **insufficient evidence of a clear preference signal** in this message.

5. Output exactly:

```json
[]
```

### Ground Truth

The correct answer for this task is:

```json
[]
```

### Trap to handle correctly

A common trap in this task is to mistake a request for a model capability (“can you do image recognition?”) or general tech awareness (“multimodal model”) for a user preference.
The correct behavior is to **not** extract a preference unless the message clearly indicates one.

Tested capabilities: instruction following, text interpretation, avoiding over-inference, JSON-only output.

## Grading Criteria

* [ ] Output is valid JSON
* [ ] Output is a JSON array
* [ ] Output contains no extra text outside the JSON
* [ ] The answer correctly returns an empty array `[]`
* [ ] The answer does not invent unsupported persona or interaction preferences
* [ ] The answer follows the required output schema for this task

## Automated Checks

````python
def grade(transcript: list, workspace_path: str) -> dict:
    import json
    import re

    def _get_last_assistant_text(transcript: list) -> str:
        for event in reversed(transcript):
            if event.get("type") != "message":
                continue
            msg = event.get("message", {})
            if msg.get("role") != "assistant":
                continue

            content = msg.get("content", "")
            if isinstance(content, str):
                return content

            if isinstance(content, list):
                parts = []
                for item in content:
                    if isinstance(item, dict) and item.get("type") == "text":
                        parts.append(item.get("text", ""))
                if parts:
                    return "\n".join(parts)

        return ""

    def _strip_code_fence(text: str) -> str:
        text = text.strip()
        text = re.sub(r"^\s*```(?:json)?\s*", "", text, flags=re.IGNORECASE)
        text = re.sub(r"\s*```\s*$", "", text)
        return text.strip()

    raw_output = _get_last_assistant_text(transcript)
    output = _strip_code_fence(raw_output)

    scores = {
        "valid_json": 0.0,
        "is_array": 0.0,
        "json_only_output": 0.0,
        "returns_empty_array": 0.0,
        "no_unsupported_preferences": 0.0,
        "follows_output_schema": 0.0,
    }

    if not output:
        return scores

    # Check whether the assistant effectively returned JSON only
    raw_trimmed = raw_output.strip()
    json_only = False
    if raw_trimmed:
        candidate = _strip_code_fence(raw_trimmed)
        if candidate == output:
            json_only = True
    scores["json_only_output"] = 1.0 if json_only else 0.0

    try:
        parsed = json.loads(output)
        scores["valid_json"] = 1.0
    except Exception:
        return scores

    if isinstance(parsed, list):
        scores["is_array"] = 1.0
    else:
        return scores

    # Ground truth for this task is exactly []
    if parsed == []:
        scores["returns_empty_array"] = 1.0
        scores["no_unsupported_preferences"] = 1.0
        scores["follows_output_schema"] = 1.0
        return scores

    # Non-empty output is not correct for this task, but we still score partially.
    required_fields = {"dimension", "preference", "confidence", "source", "evidence"}

    schema_score = 1.0
    unsupported_penalty = 0.0

    for item in parsed:
        if not isinstance(item, dict):
            schema_score = 0.0
            unsupported_penalty = 1.0
            continue

        # Required fields
        present = sum(1 for f in required_fields if f in item)
        schema_score *= (present / len(required_fields))

        # Confidence range
        conf = item.get("confidence")
        if not isinstance(conf, (int, float)) or not (0.0 <= conf <= 1.0):
            schema_score *= 0.5

        # Source validity (case-insensitive tolerance)
        src = str(item.get("source", "")).strip().lower()
        if src not in {"correction", "mined"}:
            schema_score *= 0.5

        # Any extracted preference is considered unsupported for this item,
        # because the ground truth is that there are no clear preference signals.
        unsupported_penalty = 1.0

    scores["follows_output_schema"] = max(0.0, min(1.0, schema_score))
    scores["no_unsupported_preferences"] = 0.0 if unsupported_penalty else 1.0

    return scores
````

## LLM Judge Rubric

Evaluate the assistant on the following dimensions:

### 1. Correct preference judgment (Weight: 50%)

* **1.0**: Correctly determines that the message does not contain a clear persona or interaction preference signal and returns `[]`.
* **0.75**: Mostly correct; avoids strong over-interpretation but includes minor unnecessary inference or formatting imperfection.
* **0.5**: Mixed; recognizes ambiguity but still extracts one weak or debatable preference signal.
* **0.25**: Incorrectly treats capability request or tech awareness as a clear preference signal.
* **0.0**: Completely misinterprets the task and outputs clearly unsupported preference signals.

### 2. Evidence discipline / non-hallucination (Weight: 30%)

* **1.0**: Makes no unsupported claims and does not invent stable preferences from weak wording.
* **0.75**: Nearly all claims are grounded, with only slight overreach.
* **0.5**: Some unsupported inference is present, but parts remain text-grounded.
* **0.25**: Multiple unsupported inferences or speculative persona claims.
* **0.0**: Hallucinates preferences with little or no grounding in the user message.

### 3. Output format compliance (Weight: 20%)

* **1.0**: Outputs valid JSON only, with no extra text.
* **0.75**: Minor formatting issue (for example, fenced JSON) but still easily parseable.
* **0.5**: JSON is partly malformed or includes extra text that interferes with strict compliance.
* **0.25**: Output structure is substantially wrong.
* **0.0**: Output is not valid JSON or ignores the required format entirely.
