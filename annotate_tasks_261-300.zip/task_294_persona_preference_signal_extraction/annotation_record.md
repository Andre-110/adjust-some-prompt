| 序号 | 修改项 | 修改原因 |
|---|---|---|
| 1 | 将 `difficulty: medium` 改为 `easy` | 题目目标单一，Ground Truth 可明确设为 `[]`，难度与 medium 不匹配 |
| 2 | 重写 Prompt | 原 Prompt 用 “personality or interaction preference signals” + 示例维度，容易诱导模型硬提取信号，存在答案泄露和歧义 |
| 3 | 删除 Expected Behavior 中 “These could be extracted as weak signals...” | 原文允许“抽”也允许“不抽”，Ground Truth 不明确，导致不可稳定评分 |
| 4 | 在 Expected Behavior 中补充 Ground Truth | 原文件缺少可验证的明确答案，不满足“答案明确”要求 |
| 5 | 增加 Trap 说明 | 原文件未明确指出本题陷阱：把能力请求/技术认知误判为用户偏好 |
| 6 | 重写 Grading Criteria | 原标准偏重格式，未覆盖核心能力“避免过度推断”；同时需要与 score key 对齐 |
| 7 | 重写 `grade()` 的 score key | 原 key 与新版 Grading Criteria 不完全对齐；现已一一对应 |
| 8 | 修改 `grade()` 为支持部分得分 | 原逻辑多数是纯 0/1，不满足“支持 0.0-1.0 之间部分得分”要求 |
| 9 | 调整 `grade()` 的代码块容忍逻辑 | 原逻辑对 fenced JSON 处理较脆弱，现使用正则更稳健 |
| 10 | 将本题自动评分目标固定为 `[]` | 原评分允许非空数组通过，和任务正确答案不一致 |
| 11 | 放宽 `source` 匹配为大小写不敏感 | 满足“格式容忍”要求 |
| 12 | 新增 `json_only_output` 检查 | 原标准虽要求“Only output JSON”，但自动评分未直接覆盖该点 |
| 13 | 删除原 `no_fabrication` 中基于关键词的脆弱启发式 | 原逻辑容易误判，也不能稳定反映“本题应输出空数组”的核心要求 |
| 14 | 补充 `LLM Judge Rubric` | 原文件缺失整个 Rubric，不满足维度 E 的完整性要求 |
| 15 | 新增 frontmatter 中 `grading_weights` | 原文件缺失 automated 与 llm_judge 权重配置，不满足“权重和为 1.0”要求 |