| 序号 | 修改项 | 修改原因 |
|------|--------|--------|
| 1 | 新增 `grading_weights: automated: 1.0, llm_judge: 0.0` | 原文件缺少该字段，维度 E 要求两者之和为 1.0 |
| 2 | **Expected Behavior** 补充第 4 处缺失逗号并明确 Ground Truth | 原版遗漏了 `payment_diff` 之后的第 4 个缺失逗号；补充后与 grade() 中 4 个检测 pattern 对齐；同时添加显式 Ground Truth |
| 3 | **Grading Criteria** 第 3 条明确为"all 4 missing commas"，第 5 条改为"no extra columns beyond original 7" | 原第 3 条说"proper comma separation"描述模糊；原第 5 条"No fabricated columns"与 grade() `no_fabricated_columns` key 语义对齐 |
| 4 | **grade() `proper_comma_separation` 补充第 4 个 pattern**：`r"as\s+payment_diff\s+round"` | 原版只检测 3 处，漏检 `payment_diff` 之后的缺失逗号；补充后检测全部 4 处，并改为按比例部分得分 `1.0 - comma_issues/4.0` |
| 5 | **grade() `no_fabricated_columns` 逻辑重写**：从"含 FROM/WHERE 等关键词即扣分"改为"检测 AS 后的别名是否超出原始 7 个" | 原逻辑将 `FROM`/`WHERE` 视为捏造，会错误惩罚完整合法的 SQL；新逻辑检测实际别名列表，更准确且支持部分得分 |
| 6 | **新增 `## LLM Judge Rubric`**（3 个维度，权重总和 100%） | 原文件完全缺少该部分；新增 Comma Fix Correctness (50%)、Column Preservation (30%)、Output Format (20%)，各含 5 个等级描述 |