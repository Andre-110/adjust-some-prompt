---
id: task_285_procurement_quality_control_record_tables
name: Procurement Quality Control Record Tables
category: Data Analysis
subcategory: Text Parsing
difficulty: medium
external_dependency: none
verification_method: unit-test
input_modality: text-only
grading_type: automated
timeout_seconds: 180
workspace_files: []
source_line_number: 4922
source_query: "为《采购质量控制管理规定》设计1-9个配套的核心数据记录表（如台账、检查表、申请单），仅输出纯HTML <table>代码，并为每个表格添加 border=\"1\" style=\"width:100%; border-collapse:collapse;\"；表格需包含正规表头（文件编号、版本、日期）、详细记录字段及底部签名栏，不输出其他文字。"
grading_weights:
  automated: 1.0
  llm_judge: 0.0
---

## Prompt

Hey, I need you to design some record tables for our "Procurement Quality Control Management Regulations" document. We need between 1 and 9 core data record tables - stuff like ledgers, inspection checklists, application forms, that kind of thing.

Output pure HTML table code only. Each table needs `border="1" style="width:100%; border-collapse:collapse;"` attributes.

Every table must have:
- A proper header section with document number, version, and date fields
- Detailed record fields appropriate for that type of form
- A signature section at the bottom (reviewer, approver, that sort of thing)

Save everything to a file called `procurement_tables.html`. No extra commentary or explanations in the file - just the raw HTML table code.

## Expected Behavior

The agent should:
1. Design 1–9 procurement quality control record tables
2. Include appropriate table types (supplier evaluation ledger, incoming inspection checklist, quality issue report, material acceptance form, etc.)
3. Every `<table>` tag must carry `border="1"` and `style="width:100%; border-collapse:collapse;"`
4. Every table must include a document header row with document number, version, and date
5. Every table must have relevant record fields for procurement quality control
6. Every table must end with a signature/approval section at the bottom
7. The output file must contain only HTML `<table>` elements — no markdown, no explanatory prose, no code fences

**Ground Truth:** `procurement_tables.html` must exist; contain 1–9 `<table>` tags; every `<table>` tag must include `border="1"` and `width:100%; border-collapse:collapse` in its style; content must reference document-number/version/date fields and signature/approval terms; no markdown fences or explanatory prose at the start of the file.

Tested capabilities: document structure design, HTML table formatting, domain knowledge of procurement quality management.

## Grading Criteria

- [ ] File `procurement_tables.html` exists
- [ ] Contains between 1 and 9 HTML tables
- [ ] All tables have `border="1"` attribute
- [ ] All tables have `style` with `width:100%` and `border-collapse:collapse`
- [ ] Tables contain document header fields (document number, version, date)
- [ ] Tables contain signature-related content
- [ ] File contains only HTML (no markdown fences, no prose explanations)
- [ ] No placeholder/dummy content unrelated to procurement quality control

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    from pathlib import Path
    import re

    scores = {}
    ws = Path(workspace_path)

    html_file = ws / "procurement_tables.html"
    scores["file_exists"] = 1.0 if html_file.exists() else 0.0

    if not html_file.exists():
        scores["table_count_valid"] = 0.0
        scores["border_attribute"] = 0.0
        scores["style_attribute"] = 0.0
        scores["has_doc_header_fields"] = 0.0
        scores["has_signature_section"] = 0.0
        scores["html_only_no_prose"] = 0.0
        scores["no_placeholder_content"] = 0.0
        return scores

    content = html_file.read_text(encoding="utf-8", errors="ignore")
    content_lower = content.lower()

    table_matches = re.findall(r'<table[^>]*>', content_lower)
    table_count = len(table_matches)
    scores["table_count_valid"] = 1.0 if 1 <= table_count <= 9 else 0.0

    tables_with_border = 0
    tables_with_style = 0
    for tag in table_matches:
        if 'border="1"' in tag or "border='1'" in tag or 'border=1' in tag:
            tables_with_border += 1
        tag_nospace = tag.replace(" ", "")
        if 'width:100%' in tag_nospace and 'border-collapse:collapse' in tag_nospace:
            tables_with_style += 1

    if table_count > 0:
        scores["border_attribute"] = tables_with_border / table_count
        scores["style_attribute"] = tables_with_style / table_count
    else:
        scores["border_attribute"] = 0.0
        scores["style_attribute"] = 0.0

    header_keywords = ["document number", "doc number", "doc no", "version", "date", "revision", "rev"]
    header_found = sum(1 for kw in header_keywords if kw in content_lower)
    scores["has_doc_header_fields"] = 1.0 if header_found >= 2 else (0.5 if header_found >= 1 else 0.0)

    signature_keywords = ["signature", "sign", "approval", "approve", "review", "reviewer", "approver", "authorized", "checked by", "prepared by"]
    sig_found = sum(1 for kw in signature_keywords if kw in content_lower)
    scores["has_signature_section"] = 1.0 if sig_found >= 1 else 0.0

    markdown_indicators = ["```", "# ", "## ", "**", "- [ ]"]
    prose_indicators = ["here is", "below are", "i have created", "the following"]
    has_markdown = any(ind in content for ind in markdown_indicators)
    has_prose = any(ind in content_lower[:200] for ind in prose_indicators)
    has_table_tag = "<table" in content_lower
    scores["html_only_no_prose"] = 1.0 if (has_table_tag and not has_markdown and not has_prose) else 0.0

    placeholder_terms = ["lorem ipsum", "placeholder", "sample data only", "your text here"]
    has_placeholder = any(t in content_lower for t in placeholder_terms)
    scores["no_placeholder_content"] = 0.0 if has_placeholder else 1.0

    return scores
```

## LLM Judge Rubric

```yaml
dimensions:
  - name: Table Structure & Format Compliance
    weight: 40%
    description: Do all tables have the required border/style attributes, a proper document header row, and a signature section?
    levels:
      1.0: Every table has border="1" and style="width:100%; border-collapse:collapse;"; every table has a header row with document number, version, and date; every table ends with a signature/approval row
      0.75: Most tables (≥75%) meet all three structural requirements; minor omissions in 1–2 tables
      0.5: Tables present but roughly half are missing one structural element (e.g., no signature row or no header)
      0.25: Tables exist but majority are missing header or signature sections; style/border attributes inconsistently applied
      0.0: No tables present, or tables have none of the required structural elements

  - name: Procurement Domain Appropriateness
    weight: 35%
    description: Are the tables genuinely useful for procurement quality control (supplier evaluation, incoming inspection, quality issue tracking, etc.)?
    levels:
      1.0: 3–9 distinct, well-designed table types each tailored to a specific procurement QC function (e.g., supplier evaluation ledger, incoming inspection checklist, quality issue report); field names are specific and professional
      0.75: 2–3 meaningful procurement QC tables with appropriate fields; remaining tables are generic but not irrelevant
      0.5: Tables exist and have procurement-related terms but fields are very generic (e.g., "Item", "Quantity", "Notes" only) without procurement-specific detail
      0.25: Tables are present but fields are entirely generic with no procurement quality control context
      0.0: Tables contain fields unrelated to procurement (e.g., HR, finance only), or tables are empty shells

  - name: Output Format Purity
    weight: 25%
    description: Does the file contain only raw HTML table code with no markdown, code fences, or explanatory prose?
    levels:
      1.0: File starts directly with a <table> tag or a minimal HTML comment; no markdown, no code fences, no prose anywhere in the file
      0.75: File is mostly pure HTML but has a single brief comment line or a blank preamble line
      0.5: File contains a short preamble sentence or a code fence wrapper (```html ... ```) but the table content itself is complete
      0.25: File has substantial prose explanation alongside the tables, or is wrapped in markdown code blocks throughout
      0.0: File contains no HTML tables, or is entirely prose/markdown with no valid table code
```