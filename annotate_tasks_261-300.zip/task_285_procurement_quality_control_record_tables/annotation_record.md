| 序号 | 修改项 | 修改原因 |
|------|--------|--------|
| 1 | 新增 `grading_weights: automated: 1.0, llm_judge: 0.0` | 原文件缺少该字段，维度 E 要求两者之和为 1.0 |
| 2 | **Expected Behavior** 补充 Ground Truth | 原版无明确可验证答案；补充了文件名、表格数量范围、必须包含的属性和字段类型作为 Ground Truth |
| 3 | **Grading Criteria** 第 8 条：将"No fabricated non-HTML"改为"No placeholder/dummy content" | 原第 8 条对应 `no_fabricated_non_html` key，该 key 逻辑语义不清（检测 lorem ipsum 和 example.com）；重写为更清晰的"无占位内容"描述，与新 key `no_placeholder_content` 对齐 |
| 4 | **grade() `no_fabricated_non_html` 重命名为 `no_placeholder_content`，逻辑重写** | 原逻辑 `"example.com" in content AND table_count == 0` 条件奇怪（example.com 可能出现在合理 HTML 中）；改为只检测真正的占位词（lorem ipsum、placeholder 等），语义更准确 |
| 5 | **grade() `html_only_no_prose` 中 markdown 检测修复**：原用 `\x60\x60\x60` 转义，改为直接使用 ` ``` ` | 原转义写法在字符串中等价但可读性差；直接写反引号更清晰，功能不变 |
| 6 | **新增 `## LLM Judge Rubric`**（3 个维度，权重总和 100%） | 原文件完全缺少该部分；新增 Table Structure & Format Compliance (40%)、Procurement Domain Appropriateness (35%)、Output Format Purity (25%)，各含 5 个等级描述 |