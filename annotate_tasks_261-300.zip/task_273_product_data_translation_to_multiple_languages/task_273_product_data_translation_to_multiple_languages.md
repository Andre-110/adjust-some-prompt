---
id: task_273_product_data_translation_to_multiple_languages
name: Product Data Translation to Multiple Languages
category: Data Analysis
subcategory: Data Processing and Management
difficulty: medium
external_dependency: none
verification_method: unit-test
input_modality: text-only
grading_type: hybrid
grading_weights:
  automated: 0.4
  llm_judge: 0.6
timeout_seconds: 180
workspace_files: []
source_line_number: 7277
source_query: "Translate each non-empty field in the following product data JSON into all languages listed in target_languages. Return only translations for target_languages (same JSON structure). Apply sanitization (strip HTML/decode entities), normalize any bold markers to **, and follow allergen/extraction/bolding rules.  Input: {\"names\": {\"en\": \"Puglia Primitivo Pasqua 6x  75cl\", \"de\": \"Puglia Primitivo Pasqua 6x  75cl\", \"fr\": \"Puglia Primitivo Pasqua 6x  75cl\", \"it\": \"Puglia Primitivo ..."
---

## Prompt

Hey, I need to translate this product data into a bunch of languages. Here's the JSON:

```json
{"names": {"en": "Puglia Primitivo Pasqua 6x  75cl", "de": "Puglia Primitivo Pasqua 6x  75cl", "fr": "Puglia Primitivo Pasqua 6x  75cl", "it": "Puglia Primitivo Pasqua 6x  75cl"}, "allergens": {}, "ingredients": {}, "target_languages": ["bg", "cs", "da", "el", "es", "fi", "hu", "ja", "ko", "nb", "nl", "pl", "pt", "ro", "ru", "sv", "tr", "zh-cn", "zh-tw"]}
```
Translate the `names` field to all the target languages. The allergens and ingredients are empty so just keep those as empty objects.

Output structure should be the same - a JSON object with `names`, `allergens`, and `ingredients` keys. The `names` object should have keys for each target language with the translated product name.

Note: "Puglia Primitivo Pasqua" is a wine brand/name so it shouldn't be translated - just the format/quantity part if needed. Most wine names stay the same across languages, just keep the structure consistent.

Save the result to `translations.json`

## Expected Behavior

The agent should:
1. Parse the input JSON to understand the structure
2. Recognize that only the `names` field has content to translate
3. Understand that "Puglia Primitivo Pasqua" is a proper noun (wine brand) that should remain unchanged in every language
4. Produce a name entry for all 19 target languages: bg, cs, da, el, es, fi, hu, ja, ko, nb, nl, pl, pt, ro, ru, sv, tr, zh-cn, zh-tw
5. Keep allergens and ingredients as empty objects `{}`
6. Output valid JSON saved to `translations.json` with keys: `names`, `allergens`, `ingredients`

**Ground Truth:** The file `translations.json` must be valid JSON containing: (a) a `names` object with exactly the 19 target language keys each holding a non-empty string that includes "Puglia", "Primitivo", and "Pasqua"; (b) `allergens` as `{}`; (c) `ingredients` as `{}`.

## Grading Criteria

- [ ] File `translations.json` exists
- [ ] Output is valid JSON
- [ ] Contains `names` object with all 19 target language keys
- [ ] Contains empty `allergens` object
- [ ] Contains empty `ingredients` object
- [ ] Product name preserved correctly (contains "Puglia Primitivo Pasqua") in all translations
- [ ] No fabricated allergen or ingredient data

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    from pathlib import Path
    import json

    scores = {}
    ws = Path(workspace_path)

    target_langs = ["bg", "cs", "da", "el", "es", "fi", "hu", "ja", "ko", "nb", "nl", "pl", "pt", "ro", "ru", "sv", "tr", "zh-cn", "zh-tw"]

    output_file = ws / "translations.json"
    scores["file_exists"] = 1.0 if output_file.exists() else 0.0

    if not output_file.exists():
        scores["valid_json"] = 0.0
        scores["has_names_object"] = 0.0
        scores["all_target_langs_present"] = 0.0
        scores["allergens_empty"] = 0.0
        scores["ingredients_empty"] = 0.0
        scores["brand_name_preserved"] = 0.0
        scores["no_fabricated_allergens"] = 0.0
        return scores

    try:
        data = json.loads(output_file.read_text(encoding="utf-8"))
        scores["valid_json"] = 1.0
    except Exception:
        scores["valid_json"] = 0.0
        scores["has_names_object"] = 0.0
        scores["all_target_langs_present"] = 0.0
        scores["allergens_empty"] = 0.0
        scores["ingredients_empty"] = 0.0
        scores["brand_name_preserved"] = 0.0
        scores["no_fabricated_allergens"] = 0.0
        return scores

    scores["has_names_object"] = 1.0 if isinstance(data.get("names"), dict) else 0.0

    if isinstance(data.get("names"), dict):
        names = data["names"]
        present_count = sum(1 for lang in target_langs if lang in names)
        scores["all_target_langs_present"] = present_count / len(target_langs)

        brand_preserved_count = 0
        for lang in target_langs:
            if lang in names:
                val = names[lang]
                if isinstance(val, str) and "Puglia" in val and "Primitivo" in val and "Pasqua" in val:
                    brand_preserved_count += 1
        scores["brand_name_preserved"] = brand_preserved_count / len(target_langs) if len(target_langs) > 0 else 0.0
    else:
        scores["all_target_langs_present"] = 0.0
        scores["brand_name_preserved"] = 0.0

    allergens = data.get("allergens")
    if isinstance(allergens, dict) and len(allergens) == 0:
        scores["allergens_empty"] = 1.0
    elif allergens is None:
        scores["allergens_empty"] = 0.5
    else:
        scores["allergens_empty"] = 0.0

    ingredients = data.get("ingredients")
    if isinstance(ingredients, dict) and len(ingredients) == 0:
        scores["ingredients_empty"] = 1.0
    elif ingredients is None:
        scores["ingredients_empty"] = 0.5
    else:
        scores["ingredients_empty"] = 0.0

    if isinstance(allergens, dict) and len(allergens) > 0:
        scores["no_fabricated_allergens"] = 0.0
    elif isinstance(ingredients, dict) and len(ingredients) > 0:
        scores["no_fabricated_allergens"] = 0.0
    else:
        scores["no_fabricated_allergens"] = 1.0

    return scores
```

## LLM Judge Rubric

### Criterion 1: Correct Language Coverage (Weight: 35%)

**Score 1.0**: All 19 target languages are present in the `names` object, each with a non-empty string value.
**Score 0.75**: 16–18 of 19 languages present with non-empty values; at most 3 missing or blank.
**Score 0.5**: 10–15 languages present; notable gaps but majority covered.
**Score 0.25**: Fewer than 10 languages present, or many values are empty/null.
**Score 0.0**: `names` object is missing, empty, or contains only the source languages (en/de/fr/it) without any target languages.

### Criterion 2: Product Name Handling (Weight: 25%)

**Score 1.0**: "Puglia Primitivo Pasqua" is preserved verbatim across all 19 target language entries; no translation of the brand/varietal name attempted.
**Score 0.75**: Brand name preserved in most entries; 1–2 languages have minor alterations (e.g., transliteration of one word).
**Score 0.5**: Brand name mostly intact but partially translated or modified in several languages (e.g., "Primitivo" rendered differently in 3+ entries).
**Score 0.25**: Brand name substantially altered or translated in the majority of entries.
**Score 0.0**: Brand name is translated/replaced entirely in most or all entries, or the names field only contains translated strings unrecognizable as the original product.

### Criterion 3: Format Consistency (Weight: 20%)

**Score 1.0**: The quantity notation "6x 75cl" (or equivalent with consistent spacing) appears uniformly across all 19 entries; no entries omit it or add extraneous content.
**Score 0.75**: Quantity notation present in most entries; minor spacing or formatting variation (e.g., "6 x 75cl" vs "6x 75cl") in a few entries.
**Score 0.5**: Quantity notation present in roughly half the entries; some entries are missing it or have it significantly reformatted.
**Score 0.25**: Quantity notation mostly absent or inconsistently present across entries.
**Score 0.0**: Quantity notation missing from nearly all entries, or entries contain completely different/fabricated format strings.

### Criterion 4: Structure Correctness (Weight: 20%)

**Score 1.0**: Output is valid JSON with exactly the keys `names`, `allergens`, and `ingredients`; `allergens` and `ingredients` are both `{}`; no extra top-level keys.
**Score 0.75**: Correct structure and empty objects, but contains minor extra keys at top level or `target_languages` key passed through unnecessarily.
**Score 0.5**: `names` key present and correct but `allergens` or `ingredients` is missing or `null` instead of `{}`.
**Score 0.25**: JSON is valid but structure deviates significantly — e.g., translations nested differently, or allergens/ingredients contain fabricated data.
**Score 0.0**: Output is not valid JSON, or lacks the `names` key entirely, or top-level structure is completely wrong.
```