| 序号 | 修改项 | 修改原因 |
|---|---|---|
| 1  | Grading Criteria 将"File exists and is valid JSON"拆分为两条独立条目                                                    | 原文合并为 1 条，但 grade() 中对应 `policy_file_exists` 和 `policy_valid_json` 两个 score key，Key 未对齐 |
| 2  | Expected Behavior 补充陷阱说明：`prohibited_items` 只应包含 Brave Search；rationale 不应遗漏 rate limiting 和 cost             | 原文缺少陷阱及其正确处理方式的说明                                                                       |
| 3  | Expected Behavior 补充 Ground Truth 结构描述（JSON 必需字段、prohibited_items 内容、allowed_alternatives 内容、embedding 文件关键词） | 原文缺少可验证对错的明确答案                                                                          |
| 4  | grade() 中 `embedding_has_key_terms` 将 "prohibit" 改为多词容忍匹配（prohibit/forbidden/banned/must not/disallow）        | 原检查只接受 "prohibit" 一个词，embedding 文本使用 "forbidden" 或 "banned" 等同义词时会误判为不包含关键词             |
| 5  | grade() 中 `brave_identified_prohibited` 的匹配词列表增加 "forbidden"、"banned"、"restrict"                              | 同上，放宽格式容忍度，接受合理的同义表达                                                                    |
| 6  | LLM Judge Rubric 全部 5 个维度补充 1.0/0.75/0.5/0.25/0.0 五档等级描述                                                      | 原文每个维度仅一句笼统描述，缺少分数等级的具体判定标准                                                             |
