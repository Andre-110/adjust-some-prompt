---
id: task_264_create_must_not_do_policy_entry_for_search_tool_re
name: Create Must-Not-Do Policy Entry for Search Tool Restriction
category: Knowledge Management
subcategory: Knowledge Base and Semantic Retrieval
difficulty: medium
external_dependency: none
verification_method: unit-test
input_modality: text-only
grading_type: hybrid
grading_weights:
  automated: 0.4
  llm_judge: 0.6
timeout_seconds: 180
workspace_files: []
source_line_number: 2073
source_query: "Create a vectorized "不可为" (must-not-do) policy entry that forbids using, mentioning, or auto-triggering the first search tool (Brave Search) in any automatic search capability; include the rule, rationale, and links to allowed alternatives."
---

## Prompt

Hey, I need to create a "must-not-do" policy entry for our AI assistant's knowledge base. Basically we want to ban the first search tool (Brave Search) from being used in any automatic search capability.

Here's our current tool registry for reference:

```json
{
  "search_tools": [
    {
      "id": "brave_search",
      "name": "Brave Search",
      "endpoint": "https://api.search.brave.com/res/v1/web/search",
      "auto_trigger_enabled": true,
      "priority": 1
    },
    {
      "id": "duckduckgo",
      "name": "DuckDuckGo",
      "endpoint": "https://api.duckduckgo.com/",
      "auto_trigger_enabled": true,
      "priority": 2
    },
    {
      "id": "google_custom",
      "name": "Google Custom Search",
      "endpoint": "https://www.googleapis.com/customsearch/v1",
      "auto_trigger_enabled": false,
      "priority": 3
    },
    {
      "id": "bing_search",
      "name": "Bing Search API",
      "endpoint": "https://api.bing.microsoft.com/v7.0/search",
      "auto_trigger_enabled": true,
      "priority": 4
    }
  ]
}
```
The policy entry needs to:
- clearly state the rule (no using, mentioning, or auto-triggering Brave Search)
- explain the rationale (we're deprecating it due to rate limiting issues and cost concerns)
- list the allowed alternatives with their documentation links

Save it as `policy_entry.json` in a format that can be vectorized for semantic search. Include fields like: policy_id, policy_type, rule_text, rationale, prohibited_items, allowed_alternatives, effective_date (use today), and tags for retrieval.

Also generate an embedding-ready text version in `policy_embedding.txt` - just a clean paragraph that captures all the key info for vector indexing.

## Expected Behavior

The agent should:
1. Create `policy_entry.json` containing a well-structured JSON object with all the fields requested: `policy_id`, `policy_type`, `rule_text`, `rationale`, `prohibited_items`, `allowed_alternatives`, `effective_date`, and `tags`
2. In `rule_text`, clearly state that Brave Search is forbidden from being used, mentioned, or auto-triggered
3. In `rationale`, explain that Brave Search is being deprecated due to rate limiting issues and cost concerns
4. In `prohibited_items`, list only Brave Search (tool id `brave_search`)
5. In `allowed_alternatives`, list the remaining three tools (DuckDuckGo, Google Custom Search, Bing Search API) with realistic documentation links
6. In `tags`, include retrieval-friendly keywords such as "policy", "search", "prohibited", "must-not-do"
7. Create `policy_embedding.txt` containing a clean, natural-language paragraph summarizing the policy, suitable for vector embedding/semantic search indexing

陷阱说明：
- `prohibited_items` 中只应包含 Brave Search。常见错误是误将其他工具也标记为禁止
- Prompt 中明确给出了 rationale（rate limiting + cost），agent 不应编造其他理由而遗漏这两个核心原因

Ground Truth 结构（`policy_entry.json`）：
- 顶层为一个 dict，包含至少 6 个字段：`policy_id`, `policy_type`, `rule_text`, `rationale`, `prohibited_items`, `allowed_alternatives`
- `prohibited_items` 中仅包含 Brave Search 相关条目
- `allowed_alternatives` 中包含 DuckDuckGo、Google Custom Search、Bing Search API 三个条目
- `rationale` 中提及 rate limiting 和/或 cost

Ground Truth（`policy_embedding.txt`）：
- 一段或多段自然语言文本，包含关键词：Brave Search、prohibited/forbidden/banned、policy、alternative(s)/search

## Grading Criteria

- [ ] File `policy_entry.json` exists
- [ ] `policy_entry.json` content is valid JSON
- [ ] File `policy_embedding.txt` exists
- [ ] Policy correctly identifies Brave Search as the prohibited tool
- [ ] Policy includes all three allowed alternatives (DuckDuckGo, Google Custom Search, Bing)
- [ ] Rationale mentions rate limiting and/or cost as reasons
- [ ] JSON contains required fields: policy_id, policy_type, rule_text, rationale, prohibited_items, allowed_alternatives
- [ ] Embedding text contains key terms suitable for semantic retrieval
- [ ] No false prohibition of allowed tools (DuckDuckGo, Google, Bing are NOT marked as prohibited)

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    from pathlib import Path
    import json

    scores = {}
    ws = Path(workspace_path)

    policy_file = ws / "policy_entry.json"
    embedding_file = ws / "policy_embedding.txt"

    # 1. policy_entry.json exists
    scores["policy_file_exists"] = 1.0 if policy_file.exists() else 0.0

    # 2. policy_entry.json is valid JSON
    policy_data = None
    if policy_file.exists():
        try:
            policy_data = json.loads(policy_file.read_text(encoding="utf-8"))
            scores["policy_valid_json"] = 1.0
        except Exception:
            scores["policy_valid_json"] = 0.0
    else:
        scores["policy_valid_json"] = 0.0

    # 3. policy_embedding.txt exists
    scores["embedding_file_exists"] = 1.0 if embedding_file.exists() else 0.0

    if policy_data and isinstance(policy_data, dict):
        # 4. Brave Search identified as prohibited
        policy_text = json.dumps(policy_data).lower()
        brave_prohibited = "brave" in policy_text and any(
            term in policy_text
            for term in ["prohibit", "forbid", "ban", "must-not", "must not",
                         "not allowed", "disallow", "forbidden", "banned", "restrict"]
        )
        scores["brave_identified_prohibited"] = 1.0 if brave_prohibited else 0.0

        # 5. All three allowed alternatives listed
        alternatives = policy_data.get("allowed_alternatives", [])
        if isinstance(alternatives, (list, dict)):
            alt_text = json.dumps(alternatives).lower()
        else:
            alt_text = str(alternatives).lower()

        has_ddg = "duckduckgo" in alt_text or "ddg" in alt_text
        has_google = "google" in alt_text
        has_bing = "bing" in alt_text
        alt_count = sum([has_ddg, has_google, has_bing])
        scores["alternatives_listed"] = alt_count / 3.0

        # 6. Rationale mentions rate limiting and/or cost
        rationale = str(policy_data.get("rationale", "")).lower()
        has_rate_limit = any(
            term in rationale
            for term in ["rate limit", "rate-limit", "ratelimit", "throttl"]
        )
        has_cost = any(
            term in rationale
            for term in ["cost", "expensive", "pricing", "budget"]
        )
        scores["rationale_mentions_reasons"] = 1.0 if (has_rate_limit or has_cost) else 0.0

        # 7. Required fields present
        required_fields = [
            "policy_id", "policy_type", "rule_text",
            "rationale", "prohibited_items", "allowed_alternatives"
        ]
        found_fields = sum(1 for f in required_fields if f in policy_data)
        scores["required_fields_present"] = found_fields / len(required_fields)

        # 9. No false prohibition of allowed tools
        prohibited = policy_data.get("prohibited_items", [])
        if isinstance(prohibited, list):
            prohibited_text = json.dumps(prohibited).lower()
        else:
            prohibited_text = str(prohibited).lower()
        false_prohibition = any(
            tool in prohibited_text
            for tool in ["duckduckgo", "google", "bing"]
        )
        scores["no_false_prohibition"] = 0.0 if false_prohibition else 1.0
    else:
        scores["brave_identified_prohibited"] = 0.0
        scores["alternatives_listed"] = 0.0
        scores["rationale_mentions_reasons"] = 0.0
        scores["required_fields_present"] = 0.0
        scores["no_false_prohibition"] = 0.0

    # 8. Embedding text contains key terms
    if embedding_file.exists():
        try:
            embed_text = embedding_file.read_text(encoding="utf-8").lower()
        except Exception:
            embed_text = ""
        key_terms = [
            "brave",
            "search",
            any(t in embed_text for t in ["prohibit", "forbidden", "banned", "must not", "must-not", "disallow"]),
            "policy",
            any(t in embed_text for t in ["alternative", "allowed", "duckduckgo", "google", "bing"]),
        ]
        # For simple string terms, check membership; for pre-evaluated bools, use directly
        found = 0
        for term in key_terms:
            if isinstance(term, bool):
                found += 1 if term else 0
            else:
                found += 1 if term in embed_text else 0
        scores["embedding_has_key_terms"] = found / len(key_terms)
    else:
        scores["embedding_has_key_terms"] = 0.0

    return scores
```

## LLM Judge Rubric

- **Clarity and Completeness (35%)**:
  - 1.0: Policy entry clearly articulates what is forbidden (using, mentioning, auto-triggering Brave Search), covers all required fields, and provides complete information for enforcement
  - 0.75: Policy is mostly clear with all key information present but one minor aspect is vague or slightly incomplete
  - 0.5: Policy covers the main prohibition but is missing some detail (e.g., does not mention auto-triggering, or omits one required field)
  - 0.25: Policy is vague about what is prohibited or is missing several required fields
  - 0.0: Policy does not clearly state what is prohibited, or is largely incomplete

- **Professional Formatting (25%)**:
  - 1.0: JSON is well-organized with descriptive field names, consistent formatting, proper nesting, and follows knowledge base conventions suitable for vectorization
  - 0.75: JSON structure is clean with minor formatting inconsistencies (e.g., slightly unconventional field naming)
  - 0.5: JSON is valid and readable but disorganized or uses poor field naming conventions
  - 0.25: JSON structure is messy, hard to parse programmatically, or has significant formatting issues
  - 0.0: Output is not valid JSON or completely lacks structure

- **Rationale Quality (20%)**:
  - 1.0: Rationale is coherent, professional, and clearly explains both rate limiting issues and cost concerns with sufficient context
  - 0.75: Rationale mentions both reasons but one is only briefly touched on
  - 0.5: Rationale mentions only one of the two reasons (rate limiting or cost) with reasonable explanation
  - 0.25: Rationale is present but vague, generic, or does not convincingly explain the decision
  - 0.0: No rationale provided, or rationale is completely unrelated to the stated reasons

- **Alternative Documentation (15%)**:
  - 1.0: All three alternatives (DuckDuckGo, Google Custom Search, Bing) are listed with realistic documentation links and useful contextual information
  - 0.75: All three alternatives listed with links, but links or descriptions have minor issues
  - 0.5: All three alternatives listed but missing documentation links, or only two alternatives have complete entries
  - 0.25: Only one or two alternatives listed, or alternatives lack meaningful detail
  - 0.0: No alternatives listed or alternatives section is empty

- **Embedding Text Quality (5%)**:
  - 1.0: Text is well-written, captures all essential policy information in a natural paragraph suitable for semantic search indexing
  - 0.75: Text captures most key information but is slightly awkward or missing a minor detail
  - 0.5: Text is present and contains core info but reads more like bullet points than natural prose, or misses important details
  - 0.25: Text is present but too brief or too noisy to be useful for embedding
  - 0.0: No embedding text file, or content is empty/irrelevant