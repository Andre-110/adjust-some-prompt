---
id: task_270_30_day_productivity_and_health_plan
name: 30-Day Productivity and Health Plan
category: Communication and Scheduling
subcategory: Task and Plan Management
difficulty: hard
external_dependency: none
verification_method: rubric
input_modality: text-only
grading_type: hybrid
timeout_seconds: 300
grading_weights:
  automated: 0.3
  llm_judge: 0.7
workspace_files: []
source_line_number: 9610
source_query: "制定一个"30天工作效率 + 健康计划"。输出需包含：策略层建议（优先级杠杆点、关键指标、风险预警、7/14/21/30天里程碑）、可落地的执行方案（每日时间表模板、每周任务框架、工具推荐、分周行动项、量化指标）、质量审校（科学性/可行性/风险点/改进建议），并在最终收口中明确列出四个角色（junshi/engineer/zhiku/creator）的贡献与一份按优先级排序的最终执行清单。"
---

## Prompt

Hey, I need you to create a comprehensive "30-Day Work Productivity + Health Plan" for me. I want this to feel like a real actionable plan, not just generic advice.

Here's my current situation:

```yaml
profile:
  role: software engineer
  work_hours: 9am-6pm weekdays
  current_issues:
    - often skip lunch, eat at desk
    - average 5.5 hours sleep
    - no exercise routine
    - feel burnt out by 3pm daily
    - too many meetings (avg 4hrs/day)
  goals:
    - increase deep work time to 4+ hours/day
    - sleep 7+ hours consistently
    - exercise 3x per week minimum
    - reduce afternoon energy crashes
  constraints:
    - can't change meeting culture immediately
    - gym is 15min from home
    - have a standing desk but rarely use it
```
I want the plan to have these parts:

1. Strategy layer - give me the high-leverage priority points, key metrics to track, risk warnings, and specific milestones for days 7, 14, 21, and 30

2. Execution plan - daily schedule template, weekly task framework, tool recommendations, week-by-week action items, and quantifiable targets

3. Quality review - check the plan for scientific backing, feasibility, risk points, and improvement suggestions

4. Final summary - I want to see contributions from four different perspectives: strategist (junshi), engineer, think-tank (zhiku), and creator. List what each role contributed. Then give me a final execution checklist sorted by priority.

Save everything to `productivity_health_plan.md`. Make it detailed but readable - use headers, bullet points, tables where helpful.

## Expected Behavior

The agent should:
1. Create a comprehensive 30-day plan addressing both productivity and health
2. Include strategic analysis with milestones at 7/14/21/30 days
3. Provide concrete daily/weekly execution frameworks
4. Include a quality review section with scientific considerations
5. Clearly attribute contributions to four roles (strategist/junshi, engineer, think-tank/zhiku, creator)
6. End with a prioritized execution checklist
7. Save output to `productivity_health_plan.md`

**Ground Truth:** The file `productivity_health_plan.md` must exist in the workspace and contain: (a) all four day milestones (7, 14, 21, 30), (b) a daily schedule template with time blocks, (c) a weekly framework, (d) a quality review section, (e) explicit attribution to all four roles by name, (f) a final checklist with priority ordering. Word count should exceed 500 words to demonstrate substantive content.

Tested capabilities: structured planning, multi-perspective analysis, health/productivity domain knowledge, document organization.

## Grading Criteria

- [ ] File `productivity_health_plan.md` exists
- [ ] Contains all four milestone checkpoints (day 7, 14, 21, 30)
- [ ] Contains daily schedule template with time blocks
- [ ] Contains weekly framework
- [ ] Contains quality review section
- [ ] Lists all four role contributions (junshi/strategist, engineer, zhiku/think-tank, creator)
- [ ] Contains prioritized final checklist
- [ ] Addresses both productivity AND health aspects
- [ ] Document is substantive (word count > 500)

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    from pathlib import Path
    import re

    scores = {}
    ws = Path(workspace_path)

    plan_file = ws / "productivity_health_plan.md"
    scores["file_exists"] = 1.0 if plan_file.exists() else 0.0

    if not plan_file.exists():
        scores["has_milestones"] = 0.0
        scores["has_daily_template"] = 0.0
        scores["has_weekly_framework"] = 0.0
        scores["has_quality_review"] = 0.0
        scores["has_four_roles"] = 0.0
        scores["has_priority_checklist"] = 0.0
        scores["covers_both_domains"] = 0.0
        scores["is_substantive"] = 0.0
        return scores

    text = plan_file.read_text().lower()

    milestone_patterns = [
        r"day\s*7|week\s*1\s*milestone|7[\s-]*day",
        r"day\s*14|week\s*2\s*milestone|14[\s-]*day",
        r"day\s*21|week\s*3\s*milestone|21[\s-]*day",
        r"day\s*30|week\s*4\s*milestone|30[\s-]*day|final\s*milestone"
    ]
    milestone_count = sum(1 for p in milestone_patterns if re.search(p, text))
    scores["has_milestones"] = milestone_count / 4.0

    daily_terms = ["daily schedule", "daily template", "morning routine", "time block", "daily framework", "am", "pm", "9:00", "9am", "wake up"]
    scores["has_daily_template"] = 1.0 if sum(1 for t in daily_terms if t in text) >= 2 else 0.0

    weekly_terms = ["weekly", "week 1", "week 2", "monday", "friday", "weekly task", "weekly framework"]
    scores["has_weekly_framework"] = 1.0 if sum(1 for t in weekly_terms if t in text) >= 2 else 0.0

    review_terms = ["quality review", "scientific", "feasibility", "risk", "improvement", "evidence", "research", "validation"]
    scores["has_quality_review"] = 1.0 if sum(1 for t in review_terms if t in text) >= 3 else 0.0

    role_patterns = [
        r"junshi|strategist|strategy\s*role|strategic\s*advisor",
        r"engineer|engineering\s*perspective|technical\s*role",
        r"zhiku|think[\s-]*tank|research\s*role|analyst",
        r"creator|creative\s*role|design\s*perspective"
    ]
    role_count = sum(1 for p in role_patterns if re.search(p, text))
    scores["has_four_roles"] = role_count / 4.0

    checklist_terms = ["priority", "checklist", "action item", "execution list", "todo", "step 1", "first priority", "ranked"]
    scores["has_priority_checklist"] = 1.0 if sum(1 for t in checklist_terms if t in text) >= 2 else 0.0

    productivity_terms = ["deep work", "focus", "meeting", "productivity", "task", "efficiency", "time management"]
    health_terms = ["sleep", "exercise", "health", "energy", "workout", "rest", "nutrition", "gym"]
    has_productivity = sum(1 for t in productivity_terms if t in text) >= 2
    has_health = sum(1 for t in health_terms if t in text) >= 2
    scores["covers_both_domains"] = 1.0 if (has_productivity and has_health) else 0.5 if (has_productivity or has_health) else 0.0

    word_count = len(text.split())
    scores["is_substantive"] = 1.0 if word_count > 500 else 0.5 if word_count > 200 else 0.0

    return scores
```

## LLM Judge Rubric

### Criterion 1: Strategic Depth and Coherence (Weight: 30%)

**Score 1.0**: Excellent strategic analysis with clear priority leverage points, meaningful KPIs tied to user goals, thoughtful risk identification, and well-structured milestones that build progressively. Shows systems thinking.
**Score 0.75**: Good strategic framework with most elements present. Milestones are logical. Minor gaps in risk analysis or KPI specificity.
**Score 0.5**: Basic strategy present but feels generic. Milestones exist but don't clearly build on each other. Limited insight into leverage points.
**Score 0.25**: Superficial strategic content. Missing key elements or milestones feel arbitrary.
**Score 0.0**: No meaningful strategic layer or completely generic advice.

### Criterion 2: Execution Plan Practicality (Weight: 30%)

**Score 1.0**: Highly actionable plan with realistic daily schedules, specific weekly tasks, appropriate tool recommendations, and quantifiable targets. Clearly accounts for user's constraints (meetings, gym distance, etc.).
**Score 0.75**: Good execution detail with minor gaps. Most recommendations are practical and specific.
**Score 0.5**: Execution plan exists but feels generic or doesn't fully account for stated constraints. Some vague recommendations.
**Score 0.25**: Weak execution detail. Mostly generic advice without specific schedules or quantifiable targets.
**Score 0.0**: No actionable execution plan.

### Criterion 3: Quality Review and Scientific Grounding (Weight: 20%)

**Score 1.0**: Thoughtful quality review that references relevant research/principles (sleep science, deep work concepts, exercise physiology basics). Identifies realistic risks and offers concrete improvements.
**Score 0.75**: Good quality review with some scientific backing. Addresses feasibility and risks adequately.
**Score 0.5**: Quality review present but superficial. Limited scientific grounding or generic risk statements.
**Score 0.25**: Minimal quality review. No meaningful scientific context.
**Score 0.0**: No quality review section.

### Criterion 4: Multi-Role Attribution and Final Synthesis (Weight: 20%)

**Score 1.0**: Clear, distinct contributions from all four roles (strategist, engineer, think-tank, creator) that make sense for each perspective. Final checklist is well-prioritized and actionable.
**Score 0.75**: Four roles present with reasonable differentiation. Checklist is useful but prioritization could be clearer.
**Score 0.5**: Roles mentioned but contributions feel forced or overlapping. Checklist exists but not well-prioritized.
**Score 0.25**: Some roles missing or contributions are indistinguishable. Weak final synthesis.
**Score 0.0**: Missing role attribution or no final checklist.
```