| 序号 | 修改项 | 修改原因 |
|------|--------|--------|
| 1 | **Expected Behavior** 补充 Ground Truth | 原版无明确可验证答案；补充了文件名、17 个目标语言 key、allergens 为 `{}`、无源语言 key、bold markers、百分比、品牌名保留作为 Ground Truth |
| 2 | **Grading Criteria** 第 2 条拆分为"含 17 个目标语言"和"不含源语言" | 原第 2 条把两个独立可验证的检查合并，且 `no_source_languages` key 在 Grading Criteria 中缺少对应条目；拆分后 7 条与 7 个 key 一一对应 |
| 3 | **grade() `correct_languages` 改为部分得分** | 原版全有或全无；改为 `min(names_present, ingr_present) / len(target_langs)`，按实际覆盖比例给分 |
| 4 | **grade() 空白零分同步更新**：新增 `no_source_languages` 到提前返回字典 | 原版提前返回字典缺少该 key；同步补充 |
| 5 | **LLM Judge Rubric 补全各等级描述** | 原 5 个维度每个只有一句话，完全缺少 1.0/0.75/0.5/0.25/0.0 各等级的具体说明，违反维度 E 第 3 条；为每个维度补全了全部 5 个等级描述 |