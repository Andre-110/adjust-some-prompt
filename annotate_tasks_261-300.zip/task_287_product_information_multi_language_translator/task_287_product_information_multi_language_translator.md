---
id: task_287_product_information_multi_language_translator
name: Product Information Multi-Language Translator
category: Data Analysis
subcategory: Data Processing and Management
difficulty: medium
external_dependency: none
verification_method: unit-test
input_modality: text-only
grading_type: hybrid
grading_weights:
  automated: 0.4
  llm_judge: 0.6
timeout_seconds: 240
workspace_files: []
source_line_number: 466
source_query: "Translate the following product information JSON into all languages listed in target_languages. Translate each non-empty field (names, allergens, ingredients) and return output containing only languages in target_languages. Sanitize text (strip HTML, decode entities), normalize bolding to exactly **...**, and keep allergens/additives (e.g., E-numbers) bolded; preserve ingredient order and separators; if a source field is empty, return {} for that field.  Input: {\"names\": {\"de\": \"WONNEMEY..."
---

## Prompt

Hey, I need to translate this product info JSON into a bunch of languages. Here's the data:

```json
{
  "names": {
    "de": "WONNEMEYER Couscous Salat, Paprika, Zwiebeln und Kraeuter",
    "en": "WONNEMEYER Couscous Salad with Paprika, Onions and Herbs",
    "fr": "WONNEMEYER Salade de couscous, poivron, oignons et herbes",
    "it": "WONNEMEYER Insalata di couscous con peperone, cipolle ed erbe aromatiche"
  },
  "allergens": {},
  "ingredients": {
    "de": "Couscous gegart (51%) (Hartweizengriesz, Trinkwasser, Rapsoel), Paprika (17%), Trinkwasser, Rapsoel, Zwiebeln (5%), Zucker, Apfelessig, Petersilie (3%), Speisesalz, Zitronenschale, Gewuerze, Minze, Branntweinessig, Saeureregulator: Natriumacetate. Kann Spuren von **Soja** enthalten.",
    "en": "Cooked couscous (51%) (**durum wheat** semolina, drinking water, rapeseed oil), paprika (17%), drinking water, rapeseed oil, onions (5%), sugar, apple cider vinegar, parsley (3%), table salt, lemon peel, spices, mint, spirit vinegar, acidity regulator: sodium acetates. May contain traces of **soya**.",
    "fr": "Couscous cuit (51%) (semoule de **ble dur**, eau potable, huile de colza), poivron (17%), eau potable, huile de colza, oignons (5%), sucre, vinaigre de cidre, persil (3%), sel de cuisine, zeste de citron, epices, menthe, vinaigre d'alcool, regulateur d'acidite : acetates de sodium. Peut contenir des traces de **soja**.",
    "it": "Couscous cotto (51%) (semola di **grano duro**, acqua potabile, olio di colza), peperone (17%), acqua potabile, olio di colza, cipolle (5%), zucchero, aceto di mele, prezzemolo (3%), sale da cucina, scorza di limone, spezie, menta, aceto di vino, regolatore di acidita: acetati di sodio. Puo contenere tracce di **soia**."
  },
  "target_languages": ["bg", "cs", "da", "el", "es", "fi", "hu", "ja", "ko", "nb", "nl", "pl", "pt", "ro", "ru", "sv", "tr"]
}
```
Translate each non-empty field (names, allergens, ingredients) to all the languages in target_languages. Output should ONLY contain the target languages, not the source ones.

Few things to keep in mind:
- allergens is empty so just return `{}` for that field
- keep allergens and additives bolded using exactly `**...**` format (like **soya**, **durum wheat**)
- preserve the ingredient order and separators (commas, parentheses, percentages etc.)
- strip any HTML tags and decode HTML entities if present

Save the result to `translated_products.json` with this structure:
```json
{
  "names": {"bg": "...", "cs": "...", ...},
  "allergens": {},
  "ingredients": {"bg": "...", "cs": "...", ...}
}
```
## Expected Behavior

The agent should:
1. Parse the input JSON and identify the fields to translate
2. Recognize that allergens is empty and should remain as `{}`
3. Translate the product names into all 17 target languages, preserving the brand name "WONNEMEYER" unchanged
4. Translate the ingredients into all 17 target languages while preserving:
   - Percentage values (51%, 17%, 5%, 3%)
   - Parenthetical groupings
   - Bold markers around allergens (`**soya**`, `**durum wheat**`, and their equivalents)
   - Punctuation and separators
5. Output valid JSON containing only the 17 target languages (no source language keys: de, en, fr, it)

**Ground Truth:** `translated_products.json` must be valid JSON; `names` and `ingredients` must each contain all 17 target language keys; `allergens` must be `{}`; source language keys (de, en, fr, it) must not appear; each ingredient string must contain `**...**` bold markers; percentages 51%, 17%, 5%, 3% must appear in each ingredient string; "WONNEMEYER" must appear in each name string.

Tested capabilities: multi-language translation, JSON processing, format preservation, allergen marking consistency.

## Grading Criteria

- [ ] File `translated_products.json` exists and is valid JSON
- [ ] Output contains all 17 target language keys in `names` and `ingredients`
- [ ] No source language keys (de, en, fr, it) present in output
- [ ] `allergens` field is empty object `{}`
- [ ] Bold markers (`**...**`) preserved in ingredient translations
- [ ] Percentages (51%, 17%, 5%, 3%) preserved in ingredient translations
- [ ] Brand name "WONNEMEYER" preserved unchanged in all name translations

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    from pathlib import Path
    import json
    import re

    scores = {}
    ws = Path(workspace_path)

    output_file = ws / "translated_products.json"
    scores["file_exists"] = 1.0 if output_file.exists() else 0.0

    if not output_file.exists():
        scores["valid_json"] = 0.0
        scores["correct_languages"] = 0.0
        scores["no_source_languages"] = 0.0
        scores["allergens_empty"] = 0.0
        scores["bold_markers_preserved"] = 0.0
        scores["percentages_preserved"] = 0.0
        scores["brand_preserved"] = 0.0
        return scores

    try:
        data = json.loads(output_file.read_text(encoding="utf-8"))
        scores["valid_json"] = 1.0
    except Exception:
        scores["valid_json"] = 0.0
        scores["correct_languages"] = 0.0
        scores["no_source_languages"] = 0.0
        scores["allergens_empty"] = 0.0
        scores["bold_markers_preserved"] = 0.0
        scores["percentages_preserved"] = 0.0
        scores["brand_preserved"] = 0.0
        return scores

    target_langs = ["bg", "cs", "da", "el", "es", "fi", "hu", "ja", "ko", "nb", "nl", "pl", "pt", "ro", "ru", "sv", "tr"]
    source_langs = ["de", "en", "fr", "it"]

    names = data.get("names", {})
    ingredients = data.get("ingredients", {})
    allergens = data.get("allergens", {})

    # Partial credit: count how many of the 17 languages are present in both fields
    names_present = sum(1 for lang in target_langs if lang in names)
    ingr_present = sum(1 for lang in target_langs if lang in ingredients)
    scores["correct_languages"] = min(names_present, ingr_present) / len(target_langs)

    no_source_in_names = all(lang not in names for lang in source_langs)
    no_source_in_ingredients = all(lang not in ingredients for lang in source_langs)
    scores["no_source_languages"] = 1.0 if (no_source_in_names and no_source_in_ingredients) else 0.0

    scores["allergens_empty"] = 1.0 if allergens == {} else 0.0

    bold_count = 0
    total_ingredients = 0
    for lang, text in ingredients.items():
        if lang in target_langs and isinstance(text, str):
            total_ingredients += 1
            if re.search(r"\*\*[^*]+\*\*", text):
                bold_count += 1
    scores["bold_markers_preserved"] = bold_count / max(total_ingredients, 1)

    pct_count = 0
    for lang, text in ingredients.items():
        if lang in target_langs and isinstance(text, str):
            if "51%" in text and "17%" in text and "5%" in text and "3%" in text:
                pct_count += 1
    scores["percentages_preserved"] = pct_count / max(len(target_langs), 1)

    brand_count = 0
    for lang, text in names.items():
        if lang in target_langs and isinstance(text, str):
            if "WONNEMEYER" in text.upper():
                brand_count += 1
    scores["brand_preserved"] = brand_count / max(len(target_langs), 1)

    return scores
```

## LLM Judge Rubric

### Criterion 1: Translation Quality (Weight: 35%)

**Score 1.0**: Translations are accurate and natural-sounding in all 17 target languages; technical food terms (couscous, rapeseed oil, acidity regulator, sodium acetates) are correctly translated; no obvious mistranslations.
**Score 0.75**: Translations are mostly accurate; minor awkwardness or one incorrect food term in a few languages but overall understandable.
**Score 0.5**: Translations convey the meaning but have noticeable errors in several languages or use overly literal phrasing for technical terms.
**Score 0.25**: Translations are partially correct; several languages have significant errors or the ingredient list is garbled in many languages.
**Score 0.0**: Translations are absent, unintelligible, or mostly wrong across languages.

### Criterion 2: Format Preservation (Weight: 25%)

**Score 1.0**: All percentages (51%, 17%, 5%, 3%), parenthetical groupings, commas, colons, and punctuation are preserved exactly as in the source across all 17 ingredient translations.
**Score 0.75**: Format mostly preserved; minor deviations in 1–3 languages (e.g., one percentage missing or a parenthesis dropped).
**Score 0.5**: Percentages present but parenthetical structure is inconsistently preserved; roughly half the languages maintain full format.
**Score 0.25**: Significant format loss; percentages or parentheses missing in the majority of languages.
**Score 0.0**: Format entirely lost; ingredient strings are plain prose with no structural markers.

### Criterion 3: Allergen Marking (Weight: 20%)

**Score 1.0**: All allergens (soya/soy equivalent and durum wheat equivalent) are consistently bolded with `**...**` in all 17 ingredient translations.
**Score 0.75**: Bold markers present in most languages (≥13/17); 1–4 languages missing bold formatting.
**Score 0.5**: Bold markers present in roughly half the languages (8–12/17).
**Score 0.25**: Bold markers present in fewer than 8 languages, or only one allergen is bolded consistently.
**Score 0.0**: No bold markers in any language, or bold markers are completely absent from the output.

### Criterion 4: Completeness (Weight: 15%)

**Score 1.0**: All 17 target languages present in both `names` and `ingredients`; no source languages (de, en, fr, it) in the output; `allergens` is `{}`.
**Score 0.75**: 14–16 of 17 target languages present; no source language contamination; `allergens` correct.
**Score 0.5**: 10–13 languages present; or source language keys appear alongside target languages.
**Score 0.25**: Fewer than 10 target languages; or only `names` is translated but not `ingredients`.
**Score 0.0**: Fewer than 5 languages, or the output only contains source languages, or structure is entirely wrong.

### Criterion 5: JSON Validity (Weight: 5%)

**Score 1.0**: Output is valid JSON with the correct top-level keys (`names`, `allergens`, `ingredients`); parseable without errors.
**Score 0.75**: Valid JSON but contains an extra top-level key (e.g., `target_languages` passed through).
**Score 0.5**: JSON is valid but structure differs (e.g., `ingredients` nested differently).
**Score 0.25**: JSON has minor syntax errors that a lenient parser could handle.
**Score 0.0**: Output is not valid JSON or file is missing.
```