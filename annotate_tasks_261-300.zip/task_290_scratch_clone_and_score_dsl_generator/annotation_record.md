| 序号 | 修改项 | 修改原因 |
|------|--------|--------|
| 1 | 新增 `grading_weights: automated: 1.0, llm_judge: 0.0` | 原文件缺少该字段，维度 E 要求两者之和为 1.0 |
| 2 | **Expected Behavior** 补充 Ground Truth | 原版无明确可验证答案；补充了输出格式（单个 json 代码块）、scripts 数组结构、两个脚本的具体内容要求作为 Ground Truth |
| 3 | **Grading Criteria** 第 1 条调整，合并 `valid_json` 和 `correct_structure` 为 `valid_json_structure` | 原 grade() 有 10 个 key 而 Grading Criteria 只有 9 条，`correct_structure` 无独立对应条目；合并后 9 条与 9 个 key 一一对应 |
| 4 | **grade() `valid_json` + `correct_structure` 合并为 `valid_json_structure`** | 对应 Grading Criteria 修改，同时简化提前返回逻辑：用 `all_zero` 字典统一处理所有失败路径 |
| 5 | **grade() `flag_forever_wait_clone` 增加部分得分** | 原版全有或全无；改为 3 个子条件各占 1/3，支持 0/0.33/0.67/1.0 梯度得分 |
| 6 | **grade() `no_fabrication` 扩展 `standard_scratch_opcodes` 并改为比例得分** | 原 `valid_opcodes` 仅 10 个，`control_if_else`、`data_setvariableto` 等合理 Scratch opcode 也会被误判为"fabricated"；扩展为 30+ 个标准 Scratch opcode，并改为 `1.0 - unknown/total` 比例扣分 |
| 7 | **grade() regex 修复**：将 `\x60\x60\x60json` 改为 ` ```json ` | 原转义写法功能等价但可读性差；直接写反引号更清晰 |
| 8 | **新增 `## LLM Judge Rubric`**（3 个维度，权重总和 100%） | 原文件完全缺少该部分；新增 Script Structure Correctness (50%)、Opcode Accuracy (30%)、Output Format Compliance (20%)，各含 5 个等级描述 |