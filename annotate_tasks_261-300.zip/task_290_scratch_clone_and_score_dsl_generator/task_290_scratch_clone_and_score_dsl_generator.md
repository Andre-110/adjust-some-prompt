---
id: task_290_scratch_clone_and_score_dsl_generator
name: Scratch Clone and Score DSL Generator
category: Data Analysis
subcategory: Data Processing and Management
difficulty: medium
external_dependency: none
verification_method: output-check
input_modality: text-only
grading_type: automated
timeout_seconds: 120
workspace_files: []
source_line_number: 5839
source_query: "生成可直接应用到 Scratch 的 Canonical DSL v1（仅输出 1 个 ```json``` 代码块，结构为 {\"scripts\":[{\"hat\":<opcode>,\"body\":[...]}]}）：当绿旗被点击（event_whenflagclicked）时永远循环，每 1 秒创建一个自己的分身；当作为分身启动（control_start_as_clone）时，如果碰到"小猫"，就删除此分身并将变量"分数"增加 1。"
grading_weights:
  automated: 1.0
  llm_judge: 0.0
---

## Prompt

Hey, I need to generate some Scratch Canonical DSL v1 JSON for a simple game mechanic. Just output a single ```json``` code block with the structure `{"scripts":[{"hat":<opcode>,"body":[...]}]}`.

Here's what I need:
- When the green flag is clicked (event_whenflagclicked), forever loop and create a clone of myself every 1 second
- When starting as a clone (control_start_as_clone), if touching "Cat", delete this clone and increase the variable "score" by 1

The opcodes I want you to use:
- event_whenflagclicked for green flag
- control_forever for forever loop
- control_wait with 1 second
- control_create_clone_of with "_myself_"
- control_start_as_clone for clone start
- sensing_touchingobject with "Cat"
- control_if for the condition
- control_delete_this_clone to remove the clone
- data_changevariableby to add 1 to "score"

Just output the JSON directly in your response, nothing else needed.

## Expected Behavior

The agent should produce valid JSON with exactly 2 scripts:
1. A green flag script: hat is `event_whenflagclicked`, body contains a `control_forever` loop which contains `control_wait` (1 second) and `control_create_clone_of` ("_myself_")
2. A clone start script: hat is `control_start_as_clone`, body contains a `control_if` checking `sensing_touchingobject` for "Cat", with `control_delete_this_clone` and `data_changevariableby` (variable "score", value 1) inside the if-branch

**Ground Truth:** Output must be a single fenced `json` code block; the JSON must have a top-level `scripts` array with exactly 2 objects, each with `hat` and `body` keys; script 1 hat = `event_whenflagclicked` with `control_forever`, `control_wait`, `control_create_clone_of` in body; script 2 hat = `control_start_as_clone` with `sensing_touchingobject`, `control_delete_this_clone`, `data_changevariableby` in body.

Tested capabilities: JSON generation, understanding of Scratch block semantics, proper nesting of control structures, following specific opcode requirements.

## Grading Criteria

- [ ] Output is a single fenced JSON code block containing valid JSON with `{"scripts":[...]}` structure
- [ ] Contains exactly 2 scripts
- [ ] First script has `event_whenflagclicked` hat
- [ ] First script body contains `control_forever`, `control_wait`, and `control_create_clone_of`
- [ ] Second script has `control_start_as_clone` hat
- [ ] Second script contains `sensing_touchingobject` checking "Cat"
- [ ] Second script contains `control_delete_this_clone`
- [ ] Second script contains `data_changevariableby` for "score"
- [ ] No fabricated opcodes (all opcodes are from the required list or standard Scratch opcodes)

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    import json
    import re

    scores = {}

    def _get_last_assistant_text(transcript: list) -> str:
        for event in reversed(transcript):
            if event.get("type") != "message":
                continue
            msg = event.get("message", {})
            if msg.get("role") != "assistant":
                continue
            for item in msg.get("content", []):
                if isinstance(item, dict) and item.get("type") == "text":
                    return item.get("text", "")
            content = msg.get("content", "")
            if isinstance(content, str):
                return content
        return ""

    def find_opcode_in_body(body, opcode):
        if not isinstance(body, list):
            return False
        for block in body:
            if isinstance(block, dict):
                if block.get("opcode") == opcode:
                    return True
                for val in block.values():
                    if isinstance(val, list) and find_opcode_in_body(val, opcode):
                        return True
                    if isinstance(val, dict) and find_opcode_in_body([val], opcode):
                        return True
            elif isinstance(block, list):
                if find_opcode_in_body(block, opcode):
                    return True
        return False

    def find_value_in_structure(obj, target_value):
        if isinstance(obj, dict):
            for v in obj.values():
                if find_value_in_structure(v, target_value):
                    return True
        elif isinstance(obj, list):
            for item in obj:
                if find_value_in_structure(item, target_value):
                    return True
        elif isinstance(obj, str):
            if target_value.lower() in obj.lower():
                return True
        return False

    def collect_opcodes(obj):
        opcodes = set()
        if isinstance(obj, dict):
            if "opcode" in obj:
                opcodes.add(obj["opcode"])
            for v in obj.values():
                opcodes.update(collect_opcodes(v))
        elif isinstance(obj, list):
            for item in obj:
                opcodes.update(collect_opcodes(item))
        return opcodes

    text = _get_last_assistant_text(transcript)

    json_match = re.search(r'```json\s*([\s\S]*?)\s*```', text)
    if not json_match:
        json_match = re.search(r'```\s*([\s\S]*?)\s*```', text)
    if not json_match:
        json_match = re.search(r'(\{[\s\S]*"scripts"[\s\S]*\})', text)

    all_zero = {k: 0.0 for k in [
        "valid_json_structure", "two_scripts", "flag_hat",
        "flag_forever_wait_clone", "clone_hat", "clone_touching_cat",
        "clone_delete", "clone_change_score", "no_fabrication"
    ]}

    if not json_match:
        return all_zero

    json_str = json_match.group(1)
    try:
        data = json.loads(json_str)
    except Exception:
        return all_zero

    if not (isinstance(data, dict) and "scripts" in data and isinstance(data["scripts"], list)):
        return all_zero

    scores["valid_json_structure"] = 1.0

    scripts = data["scripts"]
    scores["two_scripts"] = 1.0 if len(scripts) == 2 else 0.0

    flag_script = next((s for s in scripts if isinstance(s, dict) and s.get("hat") == "event_whenflagclicked"), None)
    clone_script = next((s for s in scripts if isinstance(s, dict) and s.get("hat") == "control_start_as_clone"), None)

    scores["flag_hat"] = 1.0 if flag_script is not None else 0.0
    scores["clone_hat"] = 1.0 if clone_script is not None else 0.0

    if flag_script:
        body = flag_script.get("body", [])
        has_forever = find_opcode_in_body(body, "control_forever")
        has_wait = find_opcode_in_body(body, "control_wait")
        has_clone_create = find_opcode_in_body(body, "control_create_clone_of")
        scores["flag_forever_wait_clone"] = 1.0 if (has_forever and has_wait and has_clone_create) else (
            0.67 if sum([has_forever, has_wait, has_clone_create]) == 2 else (
            0.33 if sum([has_forever, has_wait, has_clone_create]) == 1 else 0.0))
    else:
        scores["flag_forever_wait_clone"] = 0.0

    if clone_script:
        body = clone_script.get("body", [])
        has_touching = find_opcode_in_body(body, "sensing_touchingobject")
        has_cat = find_value_in_structure(body, "cat")
        scores["clone_touching_cat"] = 1.0 if (has_touching and has_cat) else 0.0

        scores["clone_delete"] = 1.0 if find_opcode_in_body(body, "control_delete_this_clone") else 0.0

        has_change_var = find_opcode_in_body(body, "data_changevariableby")
        has_score = find_value_in_structure(body, "score")
        scores["clone_change_score"] = 1.0 if (has_change_var and has_score) else 0.0
    else:
        scores["clone_touching_cat"] = 0.0
        scores["clone_delete"] = 0.0
        scores["clone_change_score"] = 0.0

    # Allow all required opcodes plus other standard Scratch opcodes
    required_opcodes = {
        "event_whenflagclicked", "control_forever", "control_wait",
        "control_create_clone_of", "control_start_as_clone",
        "sensing_touchingobject", "control_if", "control_delete_this_clone",
        "data_changevariableby"
    }
    # Extend with commonly used standard Scratch opcodes that are not fabricated
    standard_scratch_opcodes = required_opcodes | {
        "data_setvariableto", "control_if_else", "control_repeat", "control_repeat_until",
        "control_stop", "motion_movesteps", "motion_turnright", "motion_turnleft",
        "motion_goto", "motion_gotoxy", "motion_changexby", "motion_changeyby",
        "looks_say", "looks_show", "looks_hide", "looks_switchcostumeto",
        "operator_add", "operator_subtract", "operator_equals", "operator_gt", "operator_lt",
        "operator_and", "operator_or", "operator_not",
        "sensing_keypressed", "sensing_mousedown", "sensing_touchingcolor",
        "sound_play", "sound_playuntildone"
    }
    found_opcodes = collect_opcodes(data)
    unknown = found_opcodes - standard_scratch_opcodes
    scores["no_fabrication"] = 1.0 if len(unknown) == 0 else max(0.0, 1.0 - len(unknown) / max(len(found_opcodes), 1))

    return scores
```

## LLM Judge Rubric

```yaml
dimensions:
  - name: Script Structure Correctness
    weight: 50%
    description: Does the JSON contain exactly 2 scripts with the correct hat opcodes, and is the block nesting semantically correct for each script?
    levels:
      1.0: Exactly 2 scripts; script 1 hat=event_whenflagclicked with control_forever containing control_wait and control_create_clone_of; script 2 hat=control_start_as_clone with control_if containing sensing_touchingobject, control_delete_this_clone, and data_changevariableby — all properly nested
      0.75: Both hat opcodes correct; required blocks present but nesting is slightly off (e.g., control_wait outside the forever loop, or delete/change_variable not inside the if-branch)
      0.5: One script is correct; the other is missing a required block or has wrong hat opcode
      0.25: Both scripts present but with significant structural errors; some required opcodes missing
      0.0: Only 1 script, or no scripts array, or no valid JSON

  - name: Opcode Accuracy
    weight: 30%
    description: Are all opcodes exactly as specified, with no fabricated or misspelled opcodes?
    levels:
      1.0: All 9 required opcodes present with exact spelling; no fabricated opcodes; only standard Scratch opcodes used if any extra are present
      0.75: All required opcodes present but one has a minor typo or casing issue (e.g., "control_Forever"); no truly fabricated opcodes
      0.5: One required opcode missing or substituted with a non-standard equivalent; remaining opcodes correct
      0.25: Two or more required opcodes missing or substituted; several fabricated opcodes present
      0.0: Majority of opcodes are fabricated or wrong; the JSON does not resemble valid Scratch DSL

  - name: Output Format Compliance
    weight: 20%
    description: Is the output a single fenced ```json code block with no extra text?
    levels:
      1.0: Exactly one ```json fenced code block; no JSON outside the block; valid JSON inside
      0.75: One code block but fence label missing (``` without "json") or brief preamble present
      0.5: Valid JSON present but not in a code fence, or wrapped in non-json code block
      0.25: JSON embedded in prose with no code fence
      0.0: No JSON present, or multiple code blocks containing different JSON objects
```