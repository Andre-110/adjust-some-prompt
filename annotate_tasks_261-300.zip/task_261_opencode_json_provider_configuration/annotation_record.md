| 序号 | 修改项 | 修改原因 |
|---|---|---|
| 1 | frontmatter 补充 grading_weights: automated: 1.0 | 原文缺少该字段 |
| 2 | Expected Behavior 补充陷阱说明 | 缺少对 thinking 嵌套结构、apiKey 位置、模型名中点号的陷阱说明 |
| 3 | 删除 grade() 中 `no_fabricated_provider` 检查 | 与 Grading Criteria 无对应条目（key 未对齐） |
| 4 | 修复 grade() 中 `provider_config_correct` 的 apiKey 检查位置 | 放宽匹配：同时接受 apiKey 在 options 内或在 provider 顶层 |
| 5 | 修复 grade() 中 `models_configured` 将 `coder_plus_ok` 和 `coder_next_ok` 纳入得分 | 原代码计算了这两个变量但从未使用，是无效代码；纳入得分使评分更完整 |
| 6 | Grading Criteria 补充第 6 条，对应 `coder_plus_ok`/`coder_next_ok` 的 name 字段检查 | 补充 key 对齐 |