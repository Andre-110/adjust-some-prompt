---
id: task_261_opencode_json_provider_configuration
name: OpenCode JSON Provider Configuration
category: Automation
subcategory: Agent and AI Orchestration
difficulty: medium
external_dependency: none
verification_method: unit-test
input_modality: text-only
grading_type: automated
grading_weights:
  automated: 1.0
timeout_seconds: 120
workspace_files: []
source_line_number: 5548
source_query: "根据以下需求生成/配置 opencode.json：新增 provider \"bailian-coding-plan-test\"（npm=@ai-sdk/anthropic，baseURL=https://coding.dashscope.aliyuncs.com/apps/anthropic/v1，apiKey 使用占位符 YOUR_API_KEY），并添加 models：qwen3.5-plus（thinking enabled, budgetTokens=1024）、qwen3-max-2026-01-23（thinking enabled, budgetTokens=1024）、qwen3-coder-plus、qwen3-coder-next；同时说明配置文件应放在项目根目录还是用户主目录，以及需要把 YOUR_API_KEY 替换为实际密钥。"
---

## Prompt

Hey, I need help setting up an opencode.json config file. I want to add a new provider called "bailian-coding-plan-test" with these details:

- npm package: @ai-sdk/anthropic
- baseURL: https://coding.dashscope.aliyuncs.com/apps/anthropic/v1
- apiKey: just use YOUR_API_KEY as a placeholder for now

And I need these models under that provider:
- qwen3.5-plus with thinking enabled and budgetTokens=1024
- qwen3-max-2026-01-23 with thinking enabled and budgetTokens=1024
- qwen3-coder-plus (just needs a display name "Qwen3 Coder Plus")
- qwen3-coder-next (display name "Qwen3 Coder Next")

Save the config to `opencode.json` and also create a `README.md` that explains:
1. Where to put this config file (project root vs user home directory)
2. That users need to replace YOUR_API_KEY with their actual API key

Make sure the JSON includes the schema reference to https://opencode.ai/config.json

## Expected Behavior

The agent should:
1. Create a valid opencode.json with proper structure
2. Include the $schema reference pointing to https://opencode.ai/config.json
3. Configure the provider with correct npm, baseURL, and apiKey placeholder
4. Add all four models with correct options: thinking config (`{"type": "enabled", "budgetTokens": 1024}`) for the first two, and display names for the last two
5. Create a README explaining file placement and API key replacement

Tested capabilities: JSON configuration generation, understanding provider/model hierarchies, documentation writing.

**Trap handling — the agent should correctly navigate the following traps:**

- **thinking config structure**: The thinking option must be a nested object with exactly `{"type": "enabled", "budgetTokens": 1024}`. Writing `"thinking": true` or `"thinking": {"enabled": true}` is structurally incorrect and will not match the expected schema.
- **Model name with dot**: The model key `qwen3.5-plus` contains a dot. It must be written exactly as `"qwen3.5-plus"` in the JSON — not `"qwen35-plus"` or `"qwen3_5_plus"`.
- **apiKey placement**: The `apiKey` should be placed inside the provider's `options` object (alongside `baseURL`), not at the top level of the provider definition.

## Grading Criteria

- [ ] File `opencode.json` exists and is valid JSON
- [ ] Contains $schema reference to opencode.ai/config.json
- [ ] Provider "bailian-coding-plan-test" configured correctly (npm, baseURL, apiKey)
- [ ] All four models present with correct thinking options for the first two
- [ ] qwen3-coder-plus and qwen3-coder-next have appropriate display names
- [ ] README.md exists with file placement and API key instructions

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    from pathlib import Path
    import json

    scores = {}
    ws = Path(workspace_path)

    config_file = ws / "opencode.json"
    scores["config_file_exists"] = 1.0 if config_file.exists() else 0.0

    config = None
    if config_file.exists():
        try:
            config = json.loads(config_file.read_text(errors="ignore"))
            scores["config_valid_json"] = 1.0
        except Exception:
            scores["config_valid_json"] = 0.0
    else:
        scores["config_valid_json"] = 0.0

    if config:
        schema = config.get("$schema", "")
        scores["has_schema_ref"] = 1.0 if "opencode.ai" in schema and "config.json" in schema else 0.0

        provider = config.get("provider", {}).get("bailian-coding-plan-test", {})
        npm_ok = provider.get("npm") == "@ai-sdk/anthropic"

        # apiKey may be in options or at provider top level
        opts = provider.get("options", {})
        url_ok = "coding.dashscope.aliyuncs.com" in opts.get("baseURL", "")
        key_in_opts = opts.get("apiKey") == "YOUR_API_KEY"
        key_at_top = provider.get("apiKey") == "YOUR_API_KEY"
        key_ok = key_in_opts or key_at_top

        scores["provider_config_correct"] = 1.0 if (npm_ok and url_ok and key_ok) else 0.0

        models = provider.get("models", {})

        qwen35 = models.get("qwen3.5-plus", {})
        qwen35_thinking = qwen35.get("options", {}).get("thinking", {})
        qwen35_ok = qwen35_thinking.get("type") == "enabled" and qwen35_thinking.get("budgetTokens") == 1024

        qwenmax = models.get("qwen3-max-2026-01-23", {})
        qwenmax_thinking = qwenmax.get("options", {}).get("thinking", {})
        qwenmax_ok = qwenmax_thinking.get("type") == "enabled" and qwenmax_thinking.get("budgetTokens") == 1024

        coder_plus = models.get("qwen3-coder-plus", {})
        coder_plus_name = coder_plus.get("name", "")
        coder_plus_ok = "qwen3" in coder_plus_name.lower() or "coder" in coder_plus_name.lower()

        coder_next = models.get("qwen3-coder-next", {})
        coder_next_name = coder_next.get("name", "")
        coder_next_ok = "qwen3" in coder_next_name.lower() or "coder" in coder_next_name.lower()

        all_models_present = all(m in models for m in [
            "qwen3.5-plus", "qwen3-max-2026-01-23", "qwen3-coder-plus", "qwen3-coder-next"
        ])

        if all_models_present and qwen35_ok and qwenmax_ok:
            scores["models_configured"] = 1.0
        elif all_models_present:
            scores["models_configured"] = 0.5
        else:
            scores["models_configured"] = 0.0

        if all_models_present and coder_plus_ok and coder_next_ok:
            scores["coder_names_present"] = 1.0
        elif coder_plus_ok or coder_next_ok:
            scores["coder_names_present"] = 0.5
        else:
            scores["coder_names_present"] = 0.0
    else:
        scores["has_schema_ref"] = 0.0
        scores["provider_config_correct"] = 0.0
        scores["models_configured"] = 0.0
        scores["coder_names_present"] = 0.0

    readme_file = ws / "README.md"
    scores["readme_exists"] = 1.0 if readme_file.exists() else 0.0

    if readme_file.exists():
        readme_content = readme_file.read_text(errors="ignore").lower()
        has_placement = any(term in readme_content for term in ["root", "home", "directory", "folder", "~", "project"])
        has_apikey_note = "your_api_key" in readme_content or "api key" in readme_content or "apikey" in readme_content
        scores["readme_has_instructions"] = 1.0 if (has_placement and has_apikey_note) else 0.5 if (has_placement or has_apikey_note) else 0.0
    else:
        scores["readme_has_instructions"] = 0.0

    return scores
```