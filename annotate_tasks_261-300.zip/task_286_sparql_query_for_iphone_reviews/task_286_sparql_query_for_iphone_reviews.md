---
id: task_286_sparql_query_for_iphone_reviews
name: SPARQL Query for iPhone Reviews
category: Knowledge Management
subcategory: Knowledge Base and Semantic Retrieval
difficulty: easy
external_dependency: none
verification_method: output-check
input_modality: text-only
grading_type: automated
timeout_seconds: 120
workspace_files: []
source_line_number: 768
source_query: "根据本体 http://www.example.org/product-review# 生成用于回答"iPhone的评论有哪些"的 SPARQL 查询：查询所有 :Review，并通过 :hasProduct 关联到 :Product，使用 :productName 并用 FILTER(CONTAINS(?name, \"iPhone\")) 过滤；始终使用 PREFIX : <http://www.example.org/product-review#>；只输出 SPARQL 查询语句，不要其他解释。"
grading_weights:
  automated: 1.0
  llm_judge: 0.0
---

## Prompt

Hey, I need help writing a SPARQL query. I'm working with a product review ontology and I want to find all reviews for iPhone products.

Here's the ontology info:

```
Prefix: http://www.example.org/product-review#

Classes:
- Product (has properties: productName, productId, productBrand, productPrice, productDescription)
- Review (has properties: reviewId, reviewTitle, reviewText, reviewDate, helpfulCount, verifiedPurchase)
- Reviewer, Rating, Sentiment, Tag, UsageScenario, Platform, ProductCategory

Key relationships:
- Review hasProduct → Product
- Review writtenBy → Reviewer
- Review hasRating → Rating
- Review postedOn → Platform
- Product belongsTo → ProductCategory
```
Example query for reference (retrieving all products):

```sparql
PREFIX : <http://www.example.org/product-review#>
SELECT ?product ?name WHERE {
  ?product a :Product .
  ?product :productName ?name .
}
```

I need a query that finds all reviews where the product name contains "iPhone". Use the prefix `PREFIX : <http://www.example.org/product-review#>`. The query should select the Review instances and join to Product via hasProduct, then filter on productName using CONTAINS.

Just give me the SPARQL query, nothing else. Save it to `query.sparql`.

## Expected Behavior

The agent should:
1. Write a valid SPARQL query that selects Review instances using `?review a :Review`
2. Join Review to Product using the `:hasProduct` relationship
3. Access the `:productName` property on the Product
4. Apply a `FILTER(CONTAINS(?name, "iPhone"))` clause
5. Include the correct `PREFIX : <http://www.example.org/product-review#>` declaration
6. Save only the query to `query.sparql` with no extra explanation

**Ground Truth:** The file `query.sparql` must contain: the prefix declaration `PREFIX : <http://www.example.org/product-review#>`; a triple binding a review variable to `:Review`; a `:hasProduct` triple; a `:productName` triple; and a `FILTER(CONTAINS(..., "iPhone"))` clause.

Tested capabilities: SPARQL syntax knowledge, understanding ontology relationships, query construction from schema.

## Grading Criteria

- [ ] File `query.sparql` exists
- [ ] Query contains correct PREFIX declaration
- [ ] Query selects from `:Review` class
- [ ] Query uses `:hasProduct` relationship
- [ ] Query uses `:productName` property
- [ ] Query contains `FILTER` with `CONTAINS` for "iPhone"
- [ ] Query does not contain fabricated/non-existent properties

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    from pathlib import Path
    import re

    scores = {}
    ws = Path(workspace_path)

    query_file = ws / "query.sparql"
    scores["file_exists"] = 1.0 if query_file.exists() else 0.0

    if not query_file.exists():
        scores["has_prefix"] = 0.0
        scores["selects_review"] = 0.0
        scores["uses_hasProduct"] = 0.0
        scores["uses_productName"] = 0.0
        scores["has_filter_contains_iphone"] = 0.0
        scores["no_fabricated_properties"] = 0.0
        return scores

    content = query_file.read_text()
    content_lower = content.lower()

    prefix_pattern = r'prefix\s*:\s*<http://www\.example\.org/product-review#>'
    scores["has_prefix"] = 1.0 if re.search(prefix_pattern, content_lower) else 0.0

    review_patterns = [r'\?[\w]+\s+a\s+:review', r'\?[\w]+\s+rdf:type\s+:review']
    has_review = any(re.search(p, content_lower) for p in review_patterns)
    scores["selects_review"] = 1.0 if has_review else 0.0

    scores["uses_hasProduct"] = 1.0 if ':hasproduct' in content_lower else 0.0

    scores["uses_productName"] = 1.0 if ':productname' in content_lower else 0.0

    filter_pattern = r'filter\s*\(\s*contains\s*\(\s*\?[\w]+\s*,\s*["\']iphone["\']\s*\)'
    scores["has_filter_contains_iphone"] = 1.0 if re.search(filter_pattern, content_lower) else 0.0

    fabricated = [':reviewsfor', ':iphoneproduct', ':findreviews', ':getreviews', ':searchproduct']
    has_fabricated = any(f in content_lower for f in fabricated)
    scores["no_fabricated_properties"] = 0.0 if has_fabricated else 1.0

    return scores
```

## LLM Judge Rubric

```yaml
dimensions:
  - name: Query Correctness
    weight: 60%
    description: Is the SPARQL query syntactically valid and semantically correct for finding iPhone reviews?
    levels:
      1.0: Query is syntactically valid SPARQL; correctly uses PREFIX, SELECT, WHERE with ?review a :Review, :hasProduct join, :productName, and FILTER(CONTAINS(..., "iPhone")); would return correct results against the ontology
      0.75: Query is mostly correct but has a minor issue (e.g., missing SELECT variables, or FILTER uses REGEX instead of CONTAINS) that would still return useful results
      0.5: Query has the right structure but a semantic error (e.g., traverses the relationship in the wrong direction, or filters on the wrong variable)
      0.25: Query contains the right keywords but is structurally broken (e.g., missing WHERE clause, wrong bracket nesting)
      0.0: Query is not valid SPARQL, uses entirely wrong properties/classes, or file contains no query

  - name: Ontology Fidelity
    weight: 40%
    description: Does the query use only properties and classes defined in the ontology without inventing non-existent ones?
    levels:
      1.0: Only uses ontology-defined terms (:Review, :Product, :hasProduct, :productName) with correct prefix; no fabricated properties
      0.75: Mostly correct; uses one optional/extra variable or property that is not harmful (e.g., also selects ?name in output)
      0.5: Uses one fabricated or incorrect property name alongside the correct ones
      0.25: Several fabricated properties used; query would fail against the actual ontology
      0.0: Query entirely uses made-up properties/classes with no relation to the given ontology
```