| 序号 | 修改项 | 修改原因 |
|------|--------|--------|
| 1 | **difficulty 从 medium 改为 easy** | 原 Prompt 给出了结构完全相同的 Samsung 示例查询，agent 只需将 "Samsung" 替换为 "iPhone" 即可得到正确答案，实际测试难度为 easy |
| 2 | **Prompt 中删除 Samsung 版本示例查询** | 该示例直接给出了答案模板（结构与正确答案完全一致），严重泄露答案；保留更基础的"获取所有产品"示例作为 SPARQL 语法参考，不再直接给出 Review+hasProduct+FILTER 的模板 |
| 3 | **Expected Behavior** 补充 Ground Truth | 原版无明确可验证答案；补充了必须包含的 5 个查询元素作为 Ground Truth |
| 4 | **grade() `selects_review` 逻辑收紧**：去除过宽的 `r'\?review'` 和 `:review` 纯子串匹配，改为仅匹配三元组模式 | 原 `r'\?review'` 会匹配任何含 `?review` 的变量名（如 `?reviewer`），`r':review'` 会匹配 `:reviewer`；改为仅匹配 `?xxx a :review` 或 `rdf:type :review` 三元组形式，区分度更强 |
| 5 | **grade() `uses_hasProduct` 和 `uses_productName` 简化**：直接用 `in content_lower` 替代多 pattern 列表 | 原版用列表 any() 检测多个变体，但所有变体 lower() 后结果相同；简化为直接字符串包含检测 |
| 6 | **新增 `grading_weights: automated: 1.0, llm_judge: 0.0`** | 原文件缺少该字段，维度 E 要求两者之和为 1.0 |
| 7 | **新增 `## LLM Judge Rubric`**（2 个维度，权重总和 100%） | 原文件完全缺少该部分；新增 Query Correctness (60%) 和 Ontology Fidelity (40%)，各含 5 个等级描述 |