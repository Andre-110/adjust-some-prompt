| 序号 | 修改项 | 修改原因 |
|------|--------|--------|
| 1 | **frontmatter 删除多余的 `automated_weight: 0.4`** | 与 `grading_weights.automated: 0.4` 重复，冗余字段 |
| 2 | **Expected Behavior** 补充 Ground Truth | 原版无明确可验证答案；补充了各字段合法取值范围及预期方向（risk 应为 medium/high，position_size_pct ≤10） |
| 3 | **Grading Criteria** 第 8 条改为"Position size ≤10%"并新增对应 key | 原第 8 条"Position sizing is appropriate"语义模糊且在 grade() 中无对应 key；改为可客观验证的 `≤10%` 阈值，并在 grade() 中新增 `appropriate_position_size` key |
| 4 | **grade() JSON 提取逻辑修复**：优先使用 brace 范围法 | 原代码先用 `r'\{[^{}]*\}'` 不含嵌套的 pattern——这会漏掉含 `key_factors` 数组的 JSON；改为先用 `find`/`rfind` 范围法提取完整 JSON，再 fallback 直接解析 |
| 5 | **grade() `addresses_contradictions` 收紧检测词**：删除过宽的 `"pattern"` | 原 `conflict_terms` 含 `"pattern"`，任何提到 "pattern" 的回复都得分；改为只匹配 "double_bottom"/"double_top"/"double bottom"/"double top" 及具体冲突词 |
| 6 | **grade() 新增 `appropriate_position_size` key**：position_size_pct ≤10 得满分 | 对应新增的 Grading Criteria 第 8 条，区分保守合理的仓位大小 |
| 7 | **grade() 所有 key 在 parsed 为 None 时统一返回 0.0** | 原 else 分支只列了 6 个 key，缺少 `appropriate_position_size`；补全后一致 |
| 8 | **LLM Judge Rubric 补全各等级描述** | 原 4 个维度每个只有一句话，完全缺少各等级具体说明，违反维度 E 第 3 条；为每个维度补全了全部 5 个等级描述 |