---
id: task_289_trading_decision_analysis
name: Trading Decision Analysis
category: Finance
subcategory: Trading Strategy and Backtesting
difficulty: medium
external_dependency: none
verification_method: unit-test
input_modality: text-only
grading_type: hybrid
grading_weights:
  automated: 0.4
  llm_judge: 0.6
timeout_seconds: 120
workspace_files: []
source_line_number: 6175
source_query: "Given the following signal information, market data, and portfolio status, decide whether to BUY/SELL/HOLD, choose position_size_pct (0-20% of available capital), assess risk (low/medium/high), and provide a detailed rationale and key_factors. Respond ONLY with valid JSON in this schema: {\"action\":\"BUY|SELL|HOLD\",\"position_size_pct\":0-20,\"risk_assessment\":\"low|medium|high\",\"rationale\":\"...\",\"key_factors\":[\"...\"]}. Data: Signal=BUY, Confidence=MEDIUM, Patterns=double_bottom,d..."
---

## Prompt

Hey, I need you to analyze this trading setup and tell me what to do. Here's all the info:

Signal stuff:
- Signal: BUY
- Confidence: MEDIUM
- Patterns found: double_bottom, double_top

Market data:
- Current Price: $112.20
- Trend: downtrend
- Volume vs Average: 1.12x
- ATR (volatility): $3.13
- Price vs EMA20: below

My portfolio:
- Available Cash: $1,013,620.35
- Current Position: 0 shares
- Total Portfolio: $1,013,620.35

So basically I need you to decide:
1. Should I trade? (BUY/SELL/HOLD)
2. Position size as % of available capital (0-20%)
3. Risk level (low/medium/high)
4. Why you're recommending this

Think about the signal strength, whether the patterns make sense together, how the trend affects things, and proper position sizing for the confidence level.

Give me your answer as JSON only, nothing else:
```
{
    "action": "BUY|SELL|HOLD",
    "position_size_pct": <number 0-20>,
    "risk_assessment": "low|medium|high",
    "rationale": "<your explanation>",
    "key_factors": ["<factor1>", "<factor2>", ...]
}
```
## Expected Behavior

The agent should:
1. Recognize the conflicting signals (double_bottom is bullish, double_top is bearish)
2. Note the contradiction between BUY signal and downtrend
3. Consider that price is below EMA20 (bearish) but volume is slightly elevated
4. Factor in MEDIUM confidence when sizing the position
5. Make a reasoned decision accounting for these mixed signals
6. Provide coherent rationale that addresses the key contradictions
7. Output valid JSON matching the exact schema

**Key analytical points:**
- Double bottom + double top together is contradictory; both patterns in the same data set are unusual and raise uncertainty
- BUY signal in a downtrend is counter-trend (higher risk)
- MEDIUM confidence should limit position size — expected sizing ≤10% for any action
- No existing position means fresh entry decision with no forced exit constraint

**Ground Truth:** Output must be valid JSON with all five fields; `action` ∈ {BUY, SELL, HOLD}; `position_size_pct` ∈ [0, 20]; `risk_assessment` ∈ {low, medium, high}; `rationale` is a non-empty string >20 chars; `key_factors` is a list with ≥2 items. Given the mixed signals and downtrend, `risk_assessment` should be "medium" or "high" and `position_size_pct` should be ≤10.

## Grading Criteria

- [ ] Output is valid JSON matching the required schema
- [ ] `action` is one of BUY, SELL, or HOLD
- [ ] `position_size_pct` is a number between 0 and 20
- [ ] `risk_assessment` is one of low, medium, or high
- [ ] `rationale` is a non-empty string (>20 chars)
- [ ] `key_factors` is a list with at least 2 items
- [ ] Rationale addresses the conflicting patterns or trend contradiction
- [ ] Position size is ≤10% (appropriate for MEDIUM confidence with mixed signals)

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    import json
    import re

    scores = {}

    def _get_last_assistant_text(transcript: list) -> str:
        for event in reversed(transcript):
            if event.get("type") != "message":
                continue
            msg = event.get("message", {})
            if msg.get("role") != "assistant":
                continue
            for item in msg.get("content", []):
                if isinstance(item, dict) and item.get("type") == "text":
                    return item.get("text", "")
            content = msg.get("content", "")
            if isinstance(content, str):
                return content
        return ""

    output = _get_last_assistant_text(transcript)

    # Use brace-range extraction first to handle nested JSON (arrays in key_factors)
    parsed = None
    brace_start = output.find('{')
    brace_end = output.rfind('}')
    if brace_start != -1 and brace_end > brace_start:
        try:
            parsed = json.loads(output[brace_start:brace_end + 1])
        except Exception:
            pass
    if parsed is None:
        try:
            parsed = json.loads(output.strip())
        except Exception:
            pass

    scores["valid_json"] = 1.0 if parsed is not None else 0.0

    if not parsed or not isinstance(parsed, dict):
        for k in ["valid_action", "valid_position_size", "valid_risk", "has_rationale",
                  "has_key_factors", "addresses_contradictions", "appropriate_position_size"]:
            scores[k] = 0.0
        return scores

    action = parsed.get("action", "")
    scores["valid_action"] = 1.0 if action in ["BUY", "SELL", "HOLD"] else 0.0

    pct = parsed.get("position_size_pct")
    try:
        pct_val = float(pct)
        scores["valid_position_size"] = 1.0 if 0 <= pct_val <= 20 else 0.0
    except (TypeError, ValueError):
        scores["valid_position_size"] = 0.0
        pct_val = -1

    risk = parsed.get("risk_assessment", "")
    scores["valid_risk"] = 1.0 if str(risk).lower() in ["low", "medium", "high"] else 0.0

    rationale = parsed.get("rationale", "")
    scores["has_rationale"] = 1.0 if isinstance(rationale, str) and len(rationale.strip()) > 20 else 0.0

    factors = parsed.get("key_factors", [])
    scores["has_key_factors"] = 1.0 if isinstance(factors, list) and len(factors) >= 2 else 0.0

    combined = (rationale.lower() if isinstance(rationale, str) else "") + " " + \
               " ".join(str(f) for f in factors).lower()
    conflict_terms = ["conflict", "contradict", "mixed", "opposing", "inconsistent",
                      "double_bottom", "double_top", "double bottom", "double top"]
    trend_terms = ["downtrend", "counter-trend", "against the trend", "bearish trend"]
    mentions_conflict = any(t in combined for t in conflict_terms)
    mentions_trend = any(t in combined for t in trend_terms)
    scores["addresses_contradictions"] = 1.0 if (mentions_conflict or mentions_trend) else 0.0

    # Position size ≤10% expected for MEDIUM confidence with mixed signals
    try:
        scores["appropriate_position_size"] = 1.0 if 0 <= float(pct_val) <= 10 else 0.0
    except (TypeError, ValueError):
        scores["appropriate_position_size"] = 0.0

    return scores
```

## LLM Judge Rubric

### Criterion 1: Signal Analysis Quality (Weight: 30%)

**Score 1.0**: Response explicitly identifies and addresses both conflicts: (a) double_bottom (bullish) vs double_top (bearish) as contradictory patterns, and (b) BUY signal vs downtrend as counter-trend; analysis explains how these contradictions affect the decision.
**Score 0.75**: Identifies one of the two main contradictions clearly and mentions the other in passing; reasoning is mostly sound.
**Score 0.5**: Mentions mixed signals in general terms but does not specifically analyze the double_bottom/double_top conflict or the BUY-vs-downtrend tension.
**Score 0.25**: Acknowledges that signals are mixed but provides only superficial analysis without naming specific contradictions.
**Score 0.0**: No mention of conflicting signals; treats all inputs as uniformly bullish or uniformly bearish without addressing contradictions.

### Criterion 2: Risk Assessment Coherence (Weight: 25%)

**Score 1.0**: Risk assessment is "medium" or "high" — logically consistent with downtrend, price below EMA20, and contradictory patterns; rationale explains why these factors elevate risk.
**Score 0.75**: Risk is "medium" or "high" with reasonable but incomplete justification; main risk factors mentioned.
**Score 0.5**: Risk assessment is present but only weakly justified, or is "low" with a partial acknowledgment that conditions are mixed.
**Score 0.25**: Risk is "low" despite clear bearish indicators, with minimal or no justification.
**Score 0.0**: Risk field missing, invalid value, or risk is "low" with no acknowledgment of the adverse conditions.

### Criterion 3: Position Sizing Rationale (Weight: 25%)

**Score 1.0**: Position size is ≤10% with explicit reasoning tied to MEDIUM confidence and/or mixed signals; sizing choice is directly explained in rationale.
**Score 0.75**: Position size is ≤10% with general reasoning ("conservative due to uncertainty") but not explicitly linked to the confidence level or specific contradictions.
**Score 0.5**: Position size is 10–15% with some rationale; or size is ≤10% but with no sizing explanation at all.
**Score 0.25**: Position size is >15% with minimal risk acknowledgment, or size is 0% with no explanation.
**Score 0.0**: Position size is out of [0, 20] range, or is >15% in a HOLD recommendation, or no rationale for size is provided.

### Criterion 4: Completeness of Key Factors (Weight: 20%)

**Score 1.0**: key_factors list contains ≥3 items covering: pattern conflict (double bottom vs top), trend direction (downtrend), confidence level (MEDIUM), and at least one additional market indicator (EMA20, volume, or ATR).
**Score 0.75**: key_factors contains ≥2 items covering pattern conflict and trend direction; confidence level or a market indicator may be missing.
**Score 0.5**: key_factors contains ≥2 items but misses both pattern conflict and trend direction; focuses on less critical factors.
**Score 0.25**: key_factors contains only 1 item, or items are very generic ("market conditions", "signals").
**Score 0.0**: key_factors is empty, missing, not a list, or contains fabricated data not present in the input.
```