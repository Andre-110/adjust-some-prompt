| 序号 | 修改项 | 修改原因 |
|---|---|---|
| 1  | 调整 `difficulty` 为 `easy`     | 题目只要求根据已给定本体关系写一条基础 SPARQL 查询并保存到文件，复杂度与 `medium` 不匹配，更接近 `easy`                    |
| 2  | 改写 Prompt 表述                 | 原 Prompt 基本清楚，但“PREFIX: URL”表达不够标准，且对“只输出查询语句”约束可再明确，避免把解释、Markdown 代码块等写入文件        |
| 3  | 补充 Expected Behavior         | 原 Expected Behavior 缺少对 Ground Truth 的明确描述，也缺少对“不要杜撰本体字段”“查询语句本身即可，不要求解释”的陷阱说明      |
| 4  | 重写 Grading Criteria          | 原标准数量合适，但独立性和可验证性还能加强；补成与自动评分 key 更清晰对齐的一组标准                                        |
| 5  | 修正 `grade()` 的部分得分能力不足       | 原自动评分全部是 0/1，不满足“支持 0.0-1.0 之间部分得分”要求，因此补充部分得分逻辑                                    |
| 6  | 修正 `grade()` 对 SPARQL 结构判断不足 | 原评分只检查几个关键词，无法有效区分“像查询”和“真正合理的查询”；新增 `SELECT` / `WHERE` 基础结构检查                      |
| 7  | 提升 `grade()` 的格式容忍           | 原实现未指定编码容错，也未兼容较常见的前缀书写和变量命名差异；增加 `lower()`、正则宽松匹配和编码容错                             |
| 8  | 调整 fabricated property 检查逻辑  | 原 `valid_props` 明显超出了题目提供的本体范围，会导致题目与评分依据不一致；按题目已给 ontology 收缩到明确允许的类/属性/关系         |
| 9  | 补充空白零分逻辑                     | 原文件不存在时已能返回 0，但结构上未显式初始化所有 score key；改成统一初始化，避免遗漏                                   |
| 10 | 增补 LLM Judge Rubric          | 原题 `grading_type: automated`，没有 LLM rubric 不算错误；因此不新增 rubric，保持 automated-only 设定一致 |