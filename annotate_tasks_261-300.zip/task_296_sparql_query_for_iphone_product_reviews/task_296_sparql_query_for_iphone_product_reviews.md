---
id: task_296_sparql_query_for_iphone_product_reviews
name: SPARQL Query for iPhone Product Reviews
category: Data Analysis
subcategory: Text Parsing
difficulty: easy
external_dependency: none
verification_method: unit-test
input_modality: text-only
grading_type: automated
timeout_seconds: 120
workspace_files: []
source_line_number: 8959
source_query: "根据给定本体（PREFIX : <http://www.example.org/product-review#>；:Review 通过 :hasProduct 关联 :Product；:Product 有 :productName；:Review 有 :reviewId、:reviewTitle、:reviewText、:reviewDate 等属性），编写 SPARQL 查询，检索产品名称包含“iPhone”的所有评论；使用 FILTER(CONTAINS(?name, \"iPhone\"))；只输出 SPARQL 查询语句，不要其他解释。"
---

## Prompt

Please write a SPARQL query for the following ontology and save it to `query.sparql`.

Use this prefix:

`PREFIX : <http://www.example.org/product-review#>`

Ontology facts:
- `:Review` is linked to `:Product` via `:hasProduct`
- `:Product` has `:productName`
- `:Review` has `:reviewId`, `:reviewTitle`, `:reviewText`, and `:reviewDate`

Task:
- retrieve reviews whose product name contains `"iPhone"`
- use `FILTER(CONTAINS(?name, "iPhone"))`
- save only the SPARQL query itself to `query.sparql`
- do not include explanations, comments, or extra prose outside the query

## Expected Behavior

The agent should:

1. Create a file named `query.sparql`.
2. Write a syntactically plausible SPARQL query with the exact namespace prefix:
   `PREFIX : <http://www.example.org/product-review#>`.
3. Traverse from `:Review` to `:Product` using `:hasProduct`.
4. Bind the product name from `:productName` to a variable (commonly `?name`, but any variable name is acceptable if used consistently).
5. Apply a filter equivalent to `FILTER(CONTAINS(?name, "iPhone"))`.
6. Select at least the review resource or one or more review fields so that the query meaningfully retrieves matching reviews.
7. Avoid introducing properties or relationships not defined in the task statement.
8. Save only the query text itself in `query.sparql`.

Traps / special handling:
- The task does **not** require any explanation or markdown formatting; the file should contain only the query.
- The task does **not** require use of every review property, but the query should meaningfully retrieve reviews.
- The agent should **not** fabricate extra ontology fields beyond those explicitly provided in the prompt.

Ground truth:
- The output file must be `query.sparql`.
- The query must use the provided prefix and ontology relations.
- The query must filter product names containing `"iPhone"` with `CONTAINS`.
- The query must stay within the ontology elements stated in the prompt.

Tested capabilities: SPARQL syntax knowledge, ontology traversal, query construction, instruction following.

## Grading Criteria

- [ ] File `query.sparql` exists
- [ ] Query includes the correct prefix declaration for `http://www.example.org/product-review#`
- [ ] Query includes basic SPARQL query structure (`SELECT` and `WHERE`)
- [ ] Query joins review and product through `:hasProduct`
- [ ] Query retrieves `:productName`
- [ ] Query applies `FILTER(CONTAINS(..., "iPhone"))`
- [ ] Query selects review-related output (review node and/or review properties)
- [ ] Query does not use fabricated ontology properties or relationships

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    from pathlib import Path
    import re

    ws = Path(workspace_path)

    scores = {
        "file_exists": 0.0,
        "has_prefix": 0.0,
        "has_basic_query_structure": 0.0,
        "has_hasProduct": 0.0,
        "has_productName": 0.0,
        "has_filter_contains": 0.0,
        "selects_review_output": 0.0,
        "no_fabricated_props": 0.0,
    }

    query_file = ws / "query.sparql"
    if not query_file.exists():
        return scores

    scores["file_exists"] = 1.0

    try:
        content = query_file.read_text(encoding="utf-8", errors="ignore")
    except Exception:
        content = ""

    content_lower = content.lower()

    # PREFIX check
    prefix_pattern = r'prefix\s*:\s*<http://www\.example\.org/product-review#>'
    if re.search(prefix_pattern, content_lower, re.IGNORECASE):
        scores["has_prefix"] = 1.0

    # Basic SPARQL structure
    has_select = re.search(r'\bselect\b', content, re.IGNORECASE) is not None
    has_where = re.search(r'\bwhere\b', content, re.IGNORECASE) is not None
    if has_select and has_where:
        scores["has_basic_query_structure"] = 1.0
    elif has_select or has_where:
        scores["has_basic_query_structure"] = 0.5

    # Ontology traversal
    if re.search(r':hasproduct\b', content, re.IGNORECASE):
        scores["has_hasProduct"] = 1.0

    if re.search(r':productname\b', content, re.IGNORECASE):
        scores["has_productName"] = 1.0

    # FILTER(CONTAINS(..., "iPhone")) with some formatting tolerance
    filter_pattern = r'filter\s*\(\s*contains\s*\(\s*\?\w+\s*,\s*["\']iphone["\']\s*\)\s*\)'
    if re.search(filter_pattern, content, re.IGNORECASE):
        scores["has_filter_contains"] = 1.0

    # Review-related output in SELECT
    select_match = re.search(r'select\s+(.*?)\bwhere\b', content, re.IGNORECASE | re.DOTALL)
    if select_match:
        select_clause = select_match.group(1).lower()
        review_vars = re.findall(r'\?\w+', select_clause)
        if review_vars:
            # full credit if obviously selecting review or review fields
            if any(v in select_clause for v in ["?review", "?reviewid", "?reviewtitle", "?reviewtext", "?reviewdate"]):
                scores["selects_review_output"] = 1.0
            else:
                scores["selects_review_output"] = 0.5

    # Fabricated ontology element detection
    # Allowed classes/properties/relations only from the task statement
    allowed_terms = {
        "review",
        "product",
        "hasproduct",
        "productname",
        "reviewid",
        "reviewtitle",
        "reviewtext",
        "reviewdate",
    }

    # Capture prefixed names like :Review, :hasProduct, etc.
    found_terms = re.findall(r':([A-Za-z_][A-Za-z0-9_]*)', content)

    fabricated = []
    for term in found_terms:
        term_lower = term.lower()
        if term_lower not in allowed_terms:
            fabricated.append(term_lower)

    scores["no_fabricated_props"] = 1.0 if not fabricated else 0.0

    return scores
```