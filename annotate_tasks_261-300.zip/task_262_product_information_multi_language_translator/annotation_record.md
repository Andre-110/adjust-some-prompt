| 序号 | 修改项 | 修改原因 |
|---|---|---|
| 1  | Prompt 移除"从 ingredients 加粗文本中提取过敏原并列在占位符前"的指令                   | 输入 allergens 为空字典，该指令不适用且像考试题，不符合自然度要求                            |
| 2  | Prompt 将文本清理指令改为口语化表述                                           | 原文命令式列表不像真实用户请求，调整自然度                                             |
| 3  | Expected Behavior 补充陷阱说明：空 allergens 不应被捏造；文本清理对本数据是空操作         | 原文缺少陷阱及其正确处理方式的说明                                                 |
| 4  | Expected Behavior 补充 Ground Truth 结构描述（顶层 key、子 key 范围、各字段内容特征） | 原文缺少可验证对错的明确答案描述                                                  |
| 5  | Grading Criteria 将"文件存在且是合法 JSON"拆分为两条独立条目                      | 与 grade() 中 `output_file_exists` 和 `valid_json` 两个 score key 一一对应 |
| 6  | grade() 中 `no_fabricated_allergens` 兜底分数从 `0.5` 改为 `0.0`        | allergens 既非 dict 也非空 dict/None 说明结构严重错误，不应给部分分                   |
| 7  | LLM Judge Rubric 四个维度均补充 1.0/0.75/0.5/0.25/0.0 五档等级描述           | 原文每个维度仅一句笼统描述，缺少分数等级的具体判定标准                                       |
