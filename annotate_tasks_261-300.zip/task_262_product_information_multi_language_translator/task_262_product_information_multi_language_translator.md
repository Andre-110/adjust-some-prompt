---
id: task_262_product_information_multi_language_translator
name: Product Information Multi-Language Translator
category: Data Analysis
subcategory: Data Processing and Management
difficulty: medium
external_dependency: none
verification_method: unit-test
input_modality: text-only
grading_type: hybrid
grading_weights:
  automated: 0.4
  llm_judge: 0.6
timeout_seconds: 240
workspace_files: []
source_line_number: 3115
source_query: "Translate the following product information JSON into all languages listed in `target_languages`. Translate each non-empty value in `names`, `allergens`, and `ingredients` into every target language, and return an output JSON that contains only target-language keys (do not include non-target languages). Sanitize text by removing HTML tags and decoding HTML entities; normalize bold markers to exactly `**...**`; bold EU allergens and any E-number additives; if an allergens value is a placeholde..."
---

## Prompt

Hey, I need to translate this product info JSON into a bunch of languages. Translate all the non-empty values in `names`, `allergens`, and `ingredients` into every language listed in `target_languages`. The output should only have the target language keys — don't include the original languages (en, de, fr, it).

Also, please clean up the text while translating: strip out any HTML tags if present, decode HTML entities, and normalize any bold markers to `**...**` format. If you encounter EU allergens or E-number additives in the text, bold them.

Here's the input:

```json
{"names": {"en": "IP-Suisse Boskoop Apples 500g", "de": "Äpfel Boskoop säuerlich IP-Suisse ca. 500g", "fr": "Pommes Boskoop IP-Suisse 500g", "it": "Mele Boskoop IP-Suisse 500g"}, "allergens": {}, "ingredients": {"en": "Labels Country of production Switzerland Description IP-Suisse Boskoop Apples impress with their aromatic, tart flavor and are versatile in their uses. Ideal for delicious desserts, baking, or as a refreshing snack. Bearing the IP-Suisse logo, they represent a sustainable choice. More information Article number 7055478 Supplier Coop P.O. Box, CH-4002 Basel 0848 888 444 www.coop.ch", "de": "Labels Produktionsland Schweiz Beschreibung Äpfel Boskoop säuerlich IP-Suisse überzeugen mit ihrem aromatisch-säuerlichen Geschmack und sind vielseitig einsetzbar. Ideal für leckere Desserts, zum Backen oder als erfrischender Snack. Mit dem IP-Suisse-Logo stehen sie für eine nachhaltige Wahl. Mehr Informationen Artikelnummer 7055478 Inverkehrbringer Coop Postfach, CH-4002 Basel 0848 888 444 www.coop.ch", "fr": "Labels Pays de production Suisse Description Les pommes acidulées Boskoop IP-Suisse séduisent par leur saveur aromatique et acidulée et se prêtent à de multiples usages. Idéales pour de délicieux desserts, la pâtisserie ou comme en-cas rafraîchissant, elles arborent le logo IP-Suisse et représentent un choix durable. Plus d'informations Numéro d'article 7055478 Distributeur Coop Case postale, CH-4002 Bâle 0848 888 444 www.coop.ch", "it": "Labels Paese di produzione Svizzera Descrizione Le mele aspre Boskoop IP-Suisse colpiscono per il loro sapore aromatico e aspro e sono versatili nei loro usi. Ideali per deliziosi dessert, prodotti da forno o come spuntino rinfrescante. Con il logo IP-Suisse, rappresentano una scelta sostenibile. Più informazioni Codice articolo 7055478 Distributore Coop Casella postale, CH-4002 Basilea 0848 888 444 www.coop.ch"}, "target_languages": ["bg", "cs", "da", "el", "es", "fi", "hu", "ja", "ko", "nb", "nl", "pl", "pt", "ro", "ru", "sv", "tr", "zh-cn", "zh-tw"]}
```

Save the result to `translated_product.json`.

## Expected Behavior

The agent should:
1. Parse the input JSON and identify the source languages (en, de, fr, it) and the 19 target languages
2. Translate `names` values into all 19 target languages — each translated name should be a product name related to apples/Boskoop
3. Translate `ingredients` values into all 19 target languages — each should be a translated product description
4. Since `allergens` is an empty dict `{}`, the output `allergens` should also be empty (either `{}` or empty/null values for each target language). The agent must NOT fabricate or invent allergen entries
5. Exclude the original source languages (en, de, fr, it) from the output — only target language codes should appear as keys
6. Apply text sanitization (remove HTML tags, decode entities) during translation — though for this particular input there are no HTML tags or entities, so sanitization should be effectively a no-op
7. Save a valid, well-structured JSON file to `translated_product.json`

Traps and pitfalls:
- The allergens dict is empty. A common mistake is to fabricate allergen information or copy unrelated data into the allergens fields. The correct behavior is to keep allergens empty
- The text sanitization instructions (HTML removal, bold normalization) are general rules that do not apply to this specific input data. The agent should not introduce artificial bold markers or modify clean text unnecessarily

Ground Truth structure:
- Top-level keys: `names`, `allergens`, `ingredients`
- Each should contain sub-keys from the 19 target languages only
- `names[lang]` should be a short product name string (containing apple/Boskoop references)
- `ingredients[lang]` should be a longer product description string
- `allergens` should be empty or have empty values

## Grading Criteria

- [ ] File `translated_product.json` exists
- [ ] File content is valid JSON
- [ ] Output contains all 19 target language codes as keys
- [ ] No source languages (en, de, fr, it) appear in the output
- [ ] JSON has correct top-level structure with `names`, `ingredients`, and `allergens` keys
- [ ] `names` contains non-trivial translations (not empty, not just copied source text) for all target languages
- [ ] `ingredients` contains non-trivial translated descriptions (not empty, not just copied source text) for all target languages
- [ ] Allergens are not fabricated — allergens section is empty or has only empty values since input allergens were empty

## LLM Judge Rubric

- **Translation Quality (40%)**:
  - 1.0: Translations are accurate, natural-sounding, and convey the same product meaning as the source across all 19 languages
  - 0.75: Translations are mostly accurate with minor awkwardness or small errors in a few languages
  - 0.5: Translations are understandable but contain noticeable errors, unnatural phrasing, or some languages are clearly machine-translated with low quality
  - 0.25: Many translations are inaccurate, nonsensical, or clearly wrong; significant meaning loss
  - 0.0: No meaningful translations provided, or output is just copied source text

- **Language Coverage (25%)**:
  - 1.0: All 19 target languages present with substantive, unique translations (not duplicated from source)
  - 0.75: 15–18 target languages have meaningful translations
  - 0.5: 10–14 target languages have meaningful translations
  - 0.25: 5–9 target languages have meaningful translations
  - 0.0: Fewer than 5 target languages have translations, or translations are just the source text repeated

- **Text Sanitization (20%)**:
  - 1.0: Output text is clean — no HTML tags, no raw HTML entities, bold markers (if any) use `**...**` format consistently
  - 0.75: Mostly clean with one or two minor issues (e.g., a stray entity or inconsistent marker)
  - 0.5: Some HTML artifacts or improperly formatted bold markers remain in the output
  - 0.25: Significant HTML contamination or widespread formatting issues
  - 0.0: HTML tags and entities left throughout, no sanitization attempted

- **Structural Correctness (15%)**:
  - 1.0: Output JSON is valid, properly nested with `names`, `ingredients`, `allergens` top-level keys, contains only target language codes, and allergens correctly empty
  - 0.75: Structure is mostly correct with a minor issue (e.g., one extraneous field or a source language key included)
  - 0.5: Structure has noticeable issues — missing a top-level key, or several source languages included, or allergens incorrectly populated
  - 0.25: Major structural problems — wrong nesting, many missing keys, or substantially incorrect format
  - 0.0: Output is not valid JSON, or structure is completely wrong

## Automated Checks

```python
def grade(transcript: list, workspace_path: str) -> dict:
    from pathlib import Path
    import json

    scores = {}
    ws = Path(workspace_path)

    output_file = ws / "translated_product.json"
    scores["output_file_exists"] = 1.0 if output_file.exists() else 0.0

    if not output_file.exists():
        scores["valid_json"] = 0.0
        scores["has_all_target_langs"] = 0.0
        scores["no_source_langs"] = 0.0
        scores["correct_structure"] = 0.0
        scores["names_populated"] = 0.0
        scores["ingredients_populated"] = 0.0
        scores["no_fabricated_allergens"] = 0.0
        return scores

    try:
        data = json.loads(output_file.read_text(encoding="utf-8"))
        scores["valid_json"] = 1.0
    except Exception:
        scores["valid_json"] = 0.0
        scores["has_all_target_langs"] = 0.0
        scores["no_source_langs"] = 0.0
        scores["correct_structure"] = 0.0
        scores["names_populated"] = 0.0
        scores["ingredients_populated"] = 0.0
        scores["no_fabricated_allergens"] = 0.0
        return scores

    target_langs = [
        "bg", "cs", "da", "el", "es", "fi", "hu", "ja", "ko",
        "nb", "nl", "pl", "pt", "ro", "ru", "sv", "tr", "zh-cn", "zh-tw"
    ]
    source_langs = ["en", "de", "fr", "it"]

    # Check top-level structure
    has_names = isinstance(data.get("names"), dict)
    has_ingredients = isinstance(data.get("ingredients"), dict)
    has_allergens = "allergens" in data
    scores["correct_structure"] = 1.0 if (has_names and has_ingredients and has_allergens) else 0.0

    # Collect all language keys across sections
    all_keys = set()
    if has_names:
        all_keys.update(data["names"].keys())
    if has_ingredients:
        all_keys.update(data["ingredients"].keys())
    if isinstance(data.get("allergens"), dict):
        all_keys.update(data["allergens"].keys())

    # Check target language coverage
    target_count = sum(1 for lang in target_langs if lang in all_keys)
    scores["has_all_target_langs"] = target_count / len(target_langs)

    # Check no source languages leaked into output
    source_found = any(lang in all_keys for lang in source_langs)
    scores["no_source_langs"] = 0.0 if source_found else 1.0

    # Check names are populated with meaningful content
    if has_names:
        names_with_content = sum(
            1 for lang in target_langs
            if lang in data["names"]
            and data["names"][lang]
            and len(str(data["names"][lang]).strip()) > 3
        )
        scores["names_populated"] = names_with_content / len(target_langs)
    else:
        scores["names_populated"] = 0.0

    # Check ingredients are populated with meaningful content
    if has_ingredients:
        ingredients_with_content = sum(
            1 for lang in target_langs
            if lang in data["ingredients"]
            and data["ingredients"][lang]
            and len(str(data["ingredients"][lang]).strip()) > 20
        )
        scores["ingredients_populated"] = ingredients_with_content / len(target_langs)
    else:
        scores["ingredients_populated"] = 0.0

    # Check allergens are not fabricated (input was empty)
    if isinstance(data.get("allergens"), dict):
        non_empty_values = [
            v for v in data["allergens"].values()
            if v is not None and str(v).strip() != ""
        ]
        scores["no_fabricated_allergens"] = 1.0 if len(non_empty_values) == 0 else 0.0
    elif data.get("allergens") == {} or data.get("allergens") is None or data.get("allergens") == []:
        scores["no_fabricated_allergens"] = 1.0
    else:
        scores["no_fabricated_allergens"] = 0.0

    return scores
```